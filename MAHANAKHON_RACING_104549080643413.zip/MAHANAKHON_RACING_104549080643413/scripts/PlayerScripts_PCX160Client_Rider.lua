-- Path: Players/ygggggg55551/PlayerScripts/PCX160Client/Rider
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = require(game:GetService("ReplicatedStorage"):WaitForChild("NetSeal"))
local v_u_2 = game:GetService("Players")
local v_u_3 = game:GetService("ReplicatedStorage")
local v_u_4 = require(v_u_3:WaitForChild("PCX160Shared"))
local v_u_5 = require(script.Parent:WaitForChild("Camera"))
local v_u_6 = script.Parent:FindFirstChild("TuckAnim")
local v8, v9 = pcall(function()
	-- upvalues: (copy) v_u_6
	local v7 = v_u_6
	if v7 then
		v7 = require(v_u_6)
	end
	return v7
end)
local v_u_10 = v8 and v9 and v9 or nil
local v_u_11 = { "HipBallSocket", "KneeBallSocket", "AnkleBallSocket" }
local v_u_12 = {}
v_u_12.__index = v_u_12
function v_u_12.new(p13) -- name: new
	-- upvalues: (copy) v_u_12, (copy) v_u_4
	local v14 = p13:WaitForChild("Chassis", 10)
	local v15 = p13:WaitForChild("VehicleSeat", 10)
	if not (v14 and v15) then
		return nil
	end
	local v16 = v_u_12
	local v17 = setmetatable({}, v16)
	v17.model = p13
	v17.chassis = v14
	v17.seat = v15
	v17.steerRoot = p13:FindFirstChild("SteerRoot")
	local v18 = v17.steerRoot
	if v18 then
		v18 = v17.steerRoot:FindFirstChild("GripLeft")
	end
	v17.gripLeft = v18
	local v19 = v17.gripLeft
	if v19 then
		v19 = v17.gripLeft.CFrame
	end
	v17.gripLeftBase = v19
	local v20 = p13:GetAttribute("RiderGripTilt")
	v17.gripTilt = typeof(v20) ~= "number" and 0 or math.rad(v20)
	v17.seatPoint = v14:FindFirstChild("Seat")
	local v21 = v17.seatPoint and v17.seatPoint.CFrame or CFrame.identity
	v17.seatLocal = v21
	v17.tuckScale = 1
	local v22 = p13:GetAttribute("RiderLean")
	local v23
	if typeof(v22) == "number" then
		v23 = math.rad(v22)
	else
		v23 = v_u_4.RIDER_LEAN
	end
	v17.lean = v23
	local v24 = p13:GetAttribute("RiderHunch")
	v17.hunchScale = typeof(v24) ~= "number" and 1 or v24
	local v25 = p13:GetAttribute("RiderSeatOffset")
	local v26
	if typeof(v25) == "Vector3" then
		v26 = CFrame.new(v25)
	else
		v26 = CFrame.identity
	end
	v17.seatOffset = v26
	v17.fitFeet = p13:GetAttribute("RiderFootFit") == true
	v17.tuckFloorFeet = p13:GetAttribute("TuckFeetOnFloor") == true
	v17.tuckGrips = p13:GetAttribute("TuckHandsOnGrips") == true
	v17.wingStyle = p13:GetAttribute("TuckStyle") == "Wing"
	v17.wing = 0
	v17.elbowPoles = {}
	for _, v27 in { "Left", "Right" } do
		local v28 = v14:FindFirstChild("ElbowPole" .. v27)
		local v29
		if v28 then
			v29 = v28:GetAttribute("RidePosition")
		else
			v29 = v28
		end
		local v30
		if v28 then
			v30 = v28:GetAttribute("TuckPosition")
		else
			v30 = v28
		end
		if not v28 or typeof(v29) ~= "Vector3" and typeof(v30) ~= "Vector3" then
			continue
		end
		if typeof(v29) ~= "Vector3" then
			v29 = v28.Position
		end
		local v31 = v17.elbowPoles
		local v32 = {
			["attachment"] = v28,
			["base"] = v28.Position,
			["ride"] = v29
		}
		if typeof(v30) == "Vector3" then
			v29 = v30
		end
		v32.tuck = v29
		table.insert(v31, v32)
	end
	v17.feet = {}
	for _, v33 in {
		{ "Right", 1 },
		{ "Left", -1 }
	} do
		local v34 = v14:FindFirstChild("Foot" .. v33[1])
		local v35 = v14:FindFirstChild("KneePole" .. v33[1])
		if not v34 then
			continue
		end
		local v36 = v33[2]
		local v37 = Vector3.new(v36, 1, 1)
		local v38 = v34:GetAttribute("FloorPosition")
		local v39 = v17.feet
		local v40 = v33[1]
		local v41 = {
			["sign"] = nil,
			["attachment"] = nil,
			["base"] = nil,
			["floor"] = nil,
			["tuck"] = nil,
			["knee"] = nil,
			["kneeBase"] = nil,
			["kneeTuck"] = nil,
			["down"] = 1,
			["lift"] = 0,
			["sign"] = v33[2],
			["attachment"] = v34,
			["base"] = v34.CFrame
		}
		local v42
		if typeof(v38) == "Vector3" then
			v42 = CFrame.new(v38)
		else
			v42 = v34.CFrame
		end
		v41.floor = v42
		v41.tuck = v21 * CFrame.new(v_u_4.TUCK_FOOT_OFFSET * v37) * CFrame.Angles(v_u_4.TUCK_PITCH, 0, 0)
		v41.knee = v35
		if v35 then
			v35 = v35.CFrame
		end
		v41.kneeBase = v35
		v41.kneeTuck = v21 * CFrame.new(v_u_4.TUCK_KNEE_POLE_OFFSET * v37)
		v39[v40] = v41
	end
	v17.params = RaycastParams.new()
	v17.params.FilterType = Enum.RaycastFilterType.Exclude
	v17.mode = "both"
	v17.stance = 1
	v17.tuck = 0
	v17.ride = 0
	v17.mount = 0
	v17.occupant = nil
	v17.speed = 0
	v17.accel = 0
	v17.bob = 0
	v17.bobVelocity = 0
	v17.lastVy = 0
	v17.squeeze = 0
	v17.glance = 0
	v17.glanceTarget = 0
	v17.glanceUntil = 0
	v17.nextGlance = os.clock() + 4
	v17.time = 0
	v17.nextSitCheck = 0
	return v17
end
function v_u_12.fittedPose(p43, p44) -- name: fittedPose
	-- upvalues: (copy) v_u_3
	local v45 = v_u_3:FindFirstChild("TuckPoses")
	if v45 then
		v45 = v45:FindFirstChild(p44)
	end
	if v45 then
		v45 = v45:GetAttribute("VehicleIds")
	end
	local v46 = p43.model:GetAttribute("VehicleId") or p43.model.Name
	if type(v45) ~= "string" then
		return false
	end
	for _, v47 in v45:split(",") do
		if v47:match("^%s*(.-)%s*$") ~= v46 then
			continue
		end
		return true
	end
	return false
end
function v_u_12.fitTuck(p48) -- name: fitTuck
	-- upvalues: (copy) v_u_4
	local v_u_49 = p48.character
	local v50, v51 = pcall(function()
		-- upvalues: (copy) v_u_49
		return v_u_49:GetScale()
	end)
	p48.tuckScale = (not v50 or typeof(v51) ~= "number") and 1 or v51 / v_u_4.DEFAULT_BIKE_SCALE
	p48.charScale = (not v50 or typeof(v51) ~= "number") and 1 or v51
	for _, v52 in p48.feet do
		local v53 = v52.sign
		local v54 = Vector3.new(v53, 1, 1) * p48.tuckScale
		v52.tuck = p48.seatLocal * CFrame.new(v_u_4.TUCK_FOOT_OFFSET * v54) * CFrame.Angles(v_u_4.TUCK_PITCH, 0, 0)
		v52.kneeTuck = p48.seatLocal * CFrame.new(v_u_4.TUCK_KNEE_POLE_OFFSET * v54)
	end
end
function v_u_12.legReach(_, p55, p56) -- name: legReach
	local v57 = p55:FindFirstChild("LowerTorso")
	local v58 = p55:FindFirstChild(p56 .. "UpperLeg")
	local v59 = p55:FindFirstChild(p56 .. "LowerLeg")
	local v60 = p55:FindFirstChild(p56 .. "Foot")
	if v57 then
		v57 = v57:FindFirstChild(p56 .. "HipRigAttachment")
	end
	if not (v57 and (v58 and (v59 and v60))) then
		return nil
	end
	local v61 = v60:FindFirstChild(p56 .. "AnkleRigAttachment")
	local v62 = v60.Size.Y / 2 + (not v61 and 0 or v61.Position.Y)
	local v63 = v58:FindFirstChild(p56 .. "HipRigAttachment")
	local v64 = v58:FindFirstChild(p56 .. "KneeRigAttachment")
	local v65
	if v63 and v64 then
		v65 = (v63.Position - v64.Position).Magnitude
	else
		v65 = v58.Size.Y
	end
	local v66 = v59:FindFirstChild(p56 .. "KneeRigAttachment")
	local v67 = v59:FindFirstChild(p56 .. "AnkleRigAttachment")
	local v68
	if v66 and v67 then
		v68 = (v66.Position - v67.Position).Magnitude
	else
		v68 = v59.Size.Y
	end
	return v65 + v68, v62, v57.WorldPosition
end
function v_u_12.tuckFoot(p69, p70, p71, p72) -- name: tuckFoot
	-- upvalues: (copy) v_u_4
	local v73 = p70:FindFirstChild("LowerTorso")
	local v74 = p70:FindFirstChild(p71 .. "UpperLeg")
	local v75 = p70:FindFirstChild(p71 .. "LowerLeg")
	local v76 = p70:FindFirstChild(p71 .. "Foot")
	if v73 then
		v73 = v73:FindFirstChild(p71 .. "HipRigAttachment")
	end
	if not (v73 and (v74 and (v75 and v76))) then
		return nil
	end
	local v77 = v76:FindFirstChild(p71 .. "AnkleRigAttachment")
	local v78 = v76.Size.Y / 2 + (not v77 and 0 or v77.Position.Y)
	local v79 = v74:FindFirstChild(p71 .. "HipRigAttachment")
	local v80 = v74:FindFirstChild(p71 .. "KneeRigAttachment")
	local v81
	if v79 and v80 then
		v81 = (v79.Position - v80.Position).Magnitude
	else
		v81 = v74.Size.Y
	end
	local v82 = v75:FindFirstChild(p71 .. "KneeRigAttachment")
	local v83 = v75:FindFirstChild(p71 .. "AnkleRigAttachment")
	local v84
	if v82 and v83 then
		v84 = (v82.Position - v83.Position).Magnitude
	else
		v84 = v75.Size.Y
	end
	local v85 = (v81 + v84) * 0.96 + v78
	local v86 = p72:PointToObjectSpace(v73.WorldPosition)
	local v87 = p69.seatLocal:VectorToWorldSpace(Vector3.new(0, -0.17364818, 0.9848077))
	return CFrame.new(v86 + v87 * v85) * p69.seatLocal.Rotation * CFrame.Angles(v_u_4.TUCK_PITCH, 0, 0)
end
function v_u_12.addTurn(p88, p89, p90) -- name: addTurn
	if p89 and (p89:IsA("Motor6D") or p89:IsA("AnimationConstraint")) then
		local v91 = p88.turnMem
		if not v91 then
			v91 = {}
			p88.turnMem = v91
		end
		local v92 = v91[p89]
		local v93 = p89.Transform
		if v92 and v93 == v92.wrote then
			v93 = v92.base
		end
		if p90 == 0 then
			if v92 then
				p89.Transform = v93
				v91[p89] = nil
			end
		else
			local v94 = v93 * CFrame.Angles(p90, 0, 0)
			p89.Transform = v94
			v91[p89] = {
				["base"] = v93,
				["wrote"] = v94
			}
		end
	else
		return
	end
end
function v_u_12.setLegLimits(p95, p96, p97) -- name: setLegLimits
	-- upvalues: (copy) v_u_11
	if p95.legLimitsOn ~= p97 and p96 then
		p95.legLimitsOn = p97
		for _, v98 in { "Left", "Right" } do
			for _, v99 in v_u_11 do
				local v100 = p96:FindFirstChild(v98 .. v99, true)
				if not (v100 and v100:IsA("BallSocketConstraint")) then
					continue
				end
				v100.LimitsEnabled = p97
				v100.TwistLimitsEnabled = p97
			end
		end
	end
end
local v_u_101 = { "ShoulderBallSocket", "ElbowBallSocket", "WristBallSocket" }
function v_u_12.setArmLimits(p102, p103, p104) -- name: setArmLimits
	-- upvalues: (copy) v_u_101
	if p103 then
		if p104 then
			if p102.armSaved then
				for v105, v106 in p102.armSaved do
					if not v105.Parent then
						continue
					end
					v105.LimitsEnabled = v106[1]
					v105.TwistLimitsEnabled = v106[2]
				end
				p102.armSaved = nil
			end
			return
		elseif not p102.armSaved then
			p102.armSaved = {}
			for _, v107 in { "Left", "Right" } do
				for _, v108 in v_u_101 do
					local v109 = p103:FindFirstChild(v107 .. v108, true)
					if not (v109 and v109:IsA("BallSocketConstraint")) then
						continue
					end
					p102.armSaved[v109] = { v109.LimitsEnabled, v109.TwistLimitsEnabled }
					v109.LimitsEnabled = false
					v109.TwistLimitsEnabled = false
				end
			end
		end
	else
		return
	end
end
local v_u_110 = {
	["Hip"] = true,
	["Knee"] = true,
	["Ankle"] = true
}
local function v_u_116(p111, p112) -- name: legJoints
	-- upvalues: (copy) v_u_110
	local v113 = {}
	for v114 in v_u_110 do
		local v115 = p111:FindFirstChild(p112 .. (v114 == "Hip" and "UpperLeg" or (v114 == "Knee" and "LowerLeg" or "Foot")))
		if v115 then
			v115 = v115:FindFirstChild(p112 .. v114)
		end
		if not (v115 and (v115:IsA("AnimationConstraint") and (v115.Attachment0 and v115.Attachment1))) then
			return nil
		end
		v113[v114] = v115
	end
	return v113
end
local function v_u_124(p117, p118, p119, p120) -- name: boneRotation
	local v121 = (p118 - p117 * p118:Dot(p117)).Unit
	local v122 = (p120 - p119 * p120:Dot(p119)).Unit
	local v123 = CFrame.fromMatrix(Vector3.new(0, 0, 0), p117, v121, p117:Cross(v121))
	return CFrame.fromMatrix(Vector3.new(0, 0, 0), p119, v122, p119:Cross(v122)) * v123:Inverse()
end
function v_u_12.solveLeg(_, p125, p126, p127, p128) -- name: solveLeg
	-- upvalues: (copy) v_u_116, (copy) v_u_124
	local v129 = v_u_116(p125, p126)
	local v130 = p125:FindFirstChild("LowerTorso")
	local v131 = p125:FindFirstChild(p126 .. "UpperLeg")
	local v132 = p125:FindFirstChild(p126 .. "LowerLeg")
	local v133 = p125:FindFirstChild(p126 .. "Foot")
	if v129 and (v130 and (v131 and (v132 and v133))) then
		local v134 = v129.Hip
		local v135 = v129.Knee
		local v136 = v129.Ankle
		local v137 = v134.Attachment1.Position
		local v138 = v135.Attachment0.Position
		local v139 = v135.Attachment1.Position
		local v140 = v136.Attachment0.Position
		local v141 = (v138 - v137).Magnitude
		local v142 = (v140 - v139).Magnitude
		local v143 = p127.attachment.WorldCFrame * CFrame.new(0, v133.Size.Y / 2, 0)
		local v144 = (v130.CFrame * v134.Attachment0.CFrame).Position
		local v145 = v143 * v136.Attachment1.Position
		local v146 = v145 - v144
		local v147 = v146.Magnitude
		if v147 >= 0.001 then
			local v148 = v146 / v147
			local v149 = v141 - v142
			local v150 = math.abs(v149) + 0.01
			local v151 = (v141 + v142) * 0.999
			local v152 = math.clamp(v147, v150, v151)
			if v152 < v147 then
				v145 = v144 + v148 * v152
				v143 = v143 + (v145 - v143 * v136.Attachment1.Position)
			end
			local v153 = (p127.knee and p127.knee.WorldPosition or v144 + v130.CFrame.LookVector) - v144
			local v154 = v153 - v148 * v153:Dot(v148)
			if v154.Magnitude < 0.001 then
				v154 = v130.CFrame.LookVector - v148 * v130.CFrame.LookVector:Dot(v148)
			end
			local v155 = v154.Unit
			local v156 = (v141 * v141 - v142 * v142 + v152 * v152) / (v152 * 2)
			local v157 = v141 * v141 - v156 * v156
			local v158 = math.max(v157, 0)
			local v159 = math.sqrt(v158)
			local v160 = v144 + v148 * v156 + v155 * v159
			local v161 = v_u_124((v138 - v137).Unit, Vector3.new(0, 0, -1), (v160 - v144).Unit, v155)
			local v162 = CFrame.new(v144 - v161:VectorToWorldSpace(v137)) * v161
			local v163 = v_u_124((v140 - v139).Unit, Vector3.new(0, 0, -1), (v145 - v160).Unit, v155)
			local v164 = CFrame.new(v160 - v163:VectorToWorldSpace(v139)) * v163
			local v165 = (v130.CFrame * v134.Attachment0.CFrame):Inverse() * (v162 * v134.Attachment1.CFrame)
			local v166 = (v162 * v135.Attachment0.CFrame):Inverse() * (v164 * v135.Attachment1.CFrame)
			local v167 = (v164 * v136.Attachment0.CFrame):Inverse() * (v143 * v136.Attachment1.CFrame)
			if p128 < 1 then
				v165 = v134.Transform:Lerp(v165, p128)
				v166 = v135.Transform:Lerp(v166, p128)
				v167 = v136.Transform:Lerp(v167, p128)
			end
			v134.Transform = v165
			v135.Transform = v166
			v136.Transform = v167
		end
	else
		return
	end
end
function v_u_12.release(p168) -- name: release
	-- upvalues: (ref) v_u_10
	for _, v169 in p168.feet do
		v169.attachment.CFrame = v169.base
		if v169.knee then
			v169.knee.CFrame = v169.kneeBase
		end
		v169.down = 1
		v169.lift = 0
		v169.settled = false
		v169.stuckTries = 0
	end
	if p168.gripLeft and p168.gripLeftBase then
		p168.gripLeft.CFrame = p168.gripLeftBase
	end
	for _, v170 in p168.elbowPoles do
		v170.attachment.Position = v170.base
	end
	p168.wing = 0
	local v171 = p168.character
	if v171 and v171.Parent then
		p168:setLegLimits(v171, true)
		p168:setArmLimits(v171, true)
		local v172 = v171:FindFirstChild("Head")
		if v172 then
			v172 = v172:FindFirstChild("Neck")
		end
		if v172 then
			v172.Transform = CFrame.identity
		end
		local v173 = v171:FindFirstChild("UpperTorso")
		if v173 then
			v173 = v173:FindFirstChild("Waist")
		end
		if v173 then
			v173.Transform = CFrame.identity
		end
		if v_u_10 and (p168.animPlaying and p168.occupant) then
			v_u_10.stop(p168.occupant)
		end
		local v174 = v171:FindFirstChild("Torso")
		if v174 then
			for _, v175 in R6_LIMBS do
				local v176 = v174:FindFirstChild(v175)
				if not (v176 and v176:IsA("Motor6D")) then
					continue
				end
				v176.Transform = CFrame.identity
			end
		end
	end
	p168.character = nil
	p168.weld = nil
	p168.dismountSent = nil
	p168.animTuck = 0
	p168.animPose = nil
	p168.animIsPark = false
	p168.parked = false
	p168.animPlaying = false
	p168.armSaved = nil
end
function v_u_12.stopSitTrack(p177, p178) -- name: stopSitTrack
	if os.clock() < p177.nextSitCheck then
		return
	else
		p177.nextSitCheck = os.clock() + 0.25
		local v179 = p178:FindFirstChildOfClass("Animator")
		if v179 then
			for _, v180 in v179:GetPlayingAnimationTracks() do
				local v181 = v180.Animation
				if not (v181 and v181.Name or v180.Name):lower():find("sit", 1, true) then
					continue
				end
				v180:Stop(0.2)
			end
		end
	end
end
local function v_u_200(p182, p183, p184) -- name: aimJoint
	local v185 = p182.Part0
	local v186 = p182.Part1
	if v185 and v186 then
		local v187 = v185.CFrame * p182.C0
		local v188 = p182.C1:Inverse()
		local v189 = -v186.Size.Y / 2
		local v190 = v188 * Vector3.new(0, v189, 0)
		local v191 = v187:PointToObjectSpace(p183)
		local v192 = v190.Unit
		local v193 = v191.Unit
		local v194 = v192:Cross(v193)
		local v195 = v194.Magnitude
		local v196
		if v195 < 0.00001 or v191.Magnitude < 0.001 then
			v196 = CFrame.identity
		else
			local v197 = CFrame.fromAxisAngle
			local v198 = v194 / v195
			local v199 = v192:Dot(v193)
			v196 = v197(v198, (math.atan2(v195, v199)))
		end
		p182.Transform = CFrame.identity:Lerp(v196, p184)
	end
end
local function v_u_204(p201, p202) -- name: setIK
	for _, v203 in p201:GetChildren() do
		if not v203:IsA("IKControl") or v203.Name:sub(1, 7) ~= "PCX160_" then
			continue
		end
		if v203.Name:find("Arm$") then
			v203.Weight = p202
		else
			if not v203.Name:find("Leg$") then
				continue
			end
			v203.Weight = 0
		end
	end
end
function v_u_12.groundAt(p205, p206) -- name: groundAt
	local v207 = p205.chassis.CFrame:PointToWorldSpace(p206 + Vector3.new(0, 3, 0))
	local v208 = workspace:Raycast(v207, Vector3.new(0, -14, 0), p205.params)
	return v208 and v208.Position or v207 - Vector3.new(0, 7, 0)
end
function v_u_12.step(p209, p210) -- name: step
	-- upvalues: (copy) v_u_2, (copy) v_u_4, (ref) v_u_10, (copy) v_u_204, (copy) v_u_200, (copy) v_u_5, (copy) v_u_3, (copy) v_u_1
	local v211 = p209.seat
	local v212 = v211.Occupant
	if v212 ~= p209.occupant then
		p209:release()
		p209.occupant = v212
		if v212 then
			p209.character = v212.Parent
			p209:fitTuck()
			p209.mount = 0
			p209.stance = 1
			p209.mode = "both"
			p209.params.FilterDescendantsInstances = { p209.model, v212.Parent }
		end
	end
	if v212 then
		local v213 = v212.Parent
		local v214
		if v213 then
			v214 = v213:FindFirstChild("HumanoidRootPart")
		else
			v214 = v213
		end
		local v215 = v211:FindFirstChild("SeatWeld")
		if v214 and (v215 and v215:IsA("Weld")) then
			if v215 ~= p209.weld then
				p209.weld = v215
				p209.weldBase = v215.C0
			end
			local v216 = v_u_2.LocalPlayer.Character == v213
			local v217 = p209.model
			local v218 = p209.chassis
			local v219 = v218.CFrame
			local v220 = v217:GetAttribute("DismountStart") ~= nil
			local v221 = v212.RigType == Enum.HumanoidRigType.R6
			if v216 then
				p209:stopSitTrack(v212)
			end
			p209.time = p209.time + p210
			local v222 = v218.Anchored and 0 or v218.AssemblyLinearVelocity:Dot(v219.LookVector)
			local v223 = (v222 - p209.speed) / math.max(p210, 0.004166666666666667)
			p209.speed = v222
			p209.accel = p209.accel + (v223 - p209.accel) * v_u_4.alpha(4, p210)
			local v224 = v211.ThrottleFloat
			local v225 = v217:GetAttribute("Tuck") == true
			if v220 or v217:GetAttribute("StandDown") ~= false then
				p209.mode = "both"
			elseif v225 then
				p209.mode = "none"
			else
				p209.mode = v_u_4.standFootMode(v_u_4.footMode(p209.mode, v222, v224), v222, v211.SteerFloat)
			end
			local v226 = p209.stance
			local _ = p209.mode == "none"
			local v227 = 0
			local v228
			if v226 < v227 then
				local v229 = v226 + 2.857142857142857 * p210
				v228 = math.min(v229, v227)
			else
				local v230 = v226 - 2.857142857142857 * p210
				v228 = math.max(v230, v227)
			end
			p209.stance = v228
			local v231
			if v221 or not v_u_10 then
				v231 = nil
			else
				v231 = v_u_10.forBike(v_u_10.selected(v_u_2:GetPlayerFromCharacter(v213)), v217)
			end
			if v231 and (p209.wingStyle and not p209:fittedPose(v231)) then
				v231 = nil
			end
			local v232 = p209.wingStyle
			if v232 then
				v232 = not v221
				if v232 then
					v232 = not v231
				end
			end
			local v233 = p209.tuck
			local v234 = v225 and (p209.mode == "none" and not (v231 or v232)) and 1 or 0
			local v235
			if v233 < v234 then
				local v236 = v233 + 5 * p210
				v235 = math.min(v236, v234)
			else
				local v237 = v233 - 5 * p210
				v235 = math.max(v237, v234)
			end
			p209.tuck = v235
			local v238 = p209.wing
			local v239 = v232 and (v225 and p209.mode == "none") and 1 or 0
			local v240
			if v238 < v239 then
				local v241 = v238 + 5 * p210
				v240 = math.min(v241, v239)
			else
				local v242 = v238 - 5 * p210
				v240 = math.max(v242, v239)
			end
			p209.wing = v240
			local v243 = p209.wing
			local v244 = math.clamp(v243, 0, 1)
			local v245 = v244 * v244 * (3 - 2 * v244)
			for _, v246 in p209.elbowPoles do
				v246.attachment.Position = v246.ride:Lerp(v246.tuck, v245)
			end
			local v247
			if v221 or (not v_u_10 or (not v_u_10.parkFor or v217:GetAttribute("ParkPick") == false)) then
				v247 = nil
			else
				v247 = v_u_10.parkFor(v217)
			end
			local v248 = math.abs(v222) < (p209.parked and 1 or 0.3)
			local v249 = v247 ~= nil and not v220
			if v249 then
				if p209.mount > 0.98 then
					v249 = v217:GetAttribute("StandDown") ~= false and true or (v217:GetAttribute("EngineOn") ~= true and true or v248)
				else
					v249 = false
				end
			end
			p209.parked = v249
			if v225 then
				if p209.mode == "none" then
					v225 = v231 ~= nil
				else
					v225 = false
				end
			end
			if v225 then
				p209.animPose = v231
				p209.animIsPark = false
			elseif p209.parked then
				p209.animPose = v247
				p209.animIsPark = true
			elseif v231 and (p209.animTuck or 0) <= 0 then
				p209.animPose = v231
				p209.animIsPark = false
			end
			local v250 = p209.animTuck or 0
			local v251 = (v225 or p209.parked) and 1 or 0
			local v252 = p209.animIsPark and 2.5 or 5
			local v253
			if v250 < v251 then
				local v254 = v250 + v252 * p210
				v253 = math.min(v254, v251)
			else
				local v255 = v250 - v252 * p210
				v253 = math.max(v255, v251)
			end
			p209.animTuck = v253
			local v256
			if v220 then
				local _ = p209.stance > 0.98
				v256 = math.abs(v222) < 1.5 and 0 or 1
			else
				v256 = 1
			end
			local v257 = p209.mount
			local v258 = 1 / (v256 == 0 and 0.5 or 0.6)
			local v259
			if v257 < v256 then
				local v260 = v257 + v258 * p210
				v259 = math.min(v260, v256)
			else
				local v261 = v257 - v258 * p210
				v259 = math.max(v261, v256)
			end
			p209.mount = v259
			local v262 = p209.feet
			local v263 = p209.mode == "left" and true or p209.mode == "both"
			local v264
			if p209.mode == "right" then
				v264 = true
			else
				local _ = p209.mode == "both"
				v264 = false
			end
			if v262.Left then
				local v265 = v262.Left
				local v266 = v262.Left.down
				local v267 = v263 and 1 or 0
				local v268
				if v266 < v267 then
					local v269 = v266 + 2.857142857142857 * p210
					v268 = math.min(v269, v267)
				else
					local v270 = v266 - 2.857142857142857 * p210
					v268 = math.max(v270, v267)
				end
				v265.down = v268
			end
			if v262.Right then
				local v271 = v262.Right
				local v272 = v262.Right.down
				local v273 = v264 and 1 or 0
				local v274
				if v272 < v273 then
					local v275 = v272 + 2.857142857142857 * p210
					v274 = math.min(v275, v273)
				else
					local v276 = v272 - 2.857142857142857 * p210
					v274 = math.max(v276, v273)
				end
				v271.down = v274
			end
			local v277 = p209.mount
			local v278 = math.clamp(v277, 0, 1)
			local v279 = v278 * v278 * (3 - 2 * v278)
			local v280 = p209.stance
			local v281 = math.clamp(v280, 0, 1)
			local v282 = v281 * v281 * (3 - 2 * v281)
			local v283 = p209.tuck
			local v284 = math.clamp(v283, 0, 1)
			local v285 = v284 * v284 * (3 - 2 * v284)
			local v286 = p209.animTuck or 0
			local v287 = math.clamp(v286, 0, 1)
			local v288 = v287 * v287 * (3 - 2 * v287)
			if v288 > 0 and p209.animPose then
				if v_u_10.play(v212, p209.animPose, v288, p209.animIsPark) then
					p209.animPlaying = true
				else
					v288 = 0
				end
			elseif p209.animPlaying then
				v_u_10.stop(v212)
				p209.animPlaying = false
			end
			if p209.tuckGrips and not v221 then
				local v289 = p209.animIsPark and 0 or v288
				local v290 = math.max(v245, v289, v285)
				for _, v291 in p209.elbowPoles do
					local v292 = v291.attachment:GetAttribute("TuckPosition")
					local v293 = v291.attachment
					local v294 = v291.ride
					if typeof(v292) ~= "Vector3" then
						v292 = v291.tuck
					end
					v293.Position = v294:Lerp(v292, v290)
				end
			end
			local v295 = v224 <= 0.1 and not v216
			if v295 then
				v295 = p209.accel > 2
			end
			local v296 = v295 and (v222 > 2 and p209.mode == "none") and 1 or 0
			local v297 = p209.ride
			local v298 = p209.ride < v296 and 0.8333333333333334 or 0.625
			local v299
			if v297 < v296 then
				local v300 = v297 + v298 * p210
				v299 = math.min(v300, v296)
			else
				local v301 = v297 - v298 * p210
				v299 = math.max(v301, v296)
			end
			p209.ride = v299
			local v302 = p209.ride
			local v303 = math.clamp(v302, 0, 1)
			local v304 = v303 * v303 * (3 - 2 * v303) * (1 - v282) * (1 - v285)
			if v216 then
				local v305 = (v217:GetAttribute("RideHunch") or 0) - v304
				if math.abs(v305) > 0.01 then
					v217:SetAttribute("RideHunch", v304)
				end
			end
			local v306 = p209.steerRoot
			if v306 then
				v306 = p209.steerRoot:FindFirstChild("GripRight")
			end
			local v307 = not v306 and -1 or v219:PointToObjectSpace(v306.WorldPosition).Z
			local v308 = v307 + 0.6
			local v309 = p209:groundAt((Vector3.new(0, 0, v308)))
			local v310 = v221 and 3 or v212.HipHeight + v214.Size.Y / 2
			local v311 = v_u_4.flatRotation(v219)
			local v312 = -v219.RightVector.Y
			local v313 = math.clamp(v312, -1, 1)
			local v314 = math.asin(v313)
			local v315 = p209.mode == "left" and -0.1 or (p209.mode == "right" and 0.1 or 0)
			local v316 = v219:PointToWorldSpace((Vector3.new(v315, 0, v308)))
			local v317 = CFrame.new(v316.X, v309.Y + v310, v316.Z) * v311 * CFrame.Angles(-0.10471975511965978, 0, -v314 * v_u_4.STAND_RIDER_LEAN)
			local v318 = v307 + 1.3
			local v319 = v219:PointToWorldSpace((Vector3.new(-2.4, 0, v318)))
			local v320 = CFrame.new(v319.X, v309.Y + v310, v319.Z) * v311
			local v321 = p209.accel / 25
			local v322 = math.clamp(v321, 0, 1)
			local v323 = -p209.accel / 25
			local v324 = math.clamp(v323, 0, 1)
			local v325 = p209.lean + v304 * 0.05235987755982989 * p209.hunchScale - v322 * 0.10471975511965978 + v324 * 0.13962634015954636 + v245 * 0.10471975511965978
			local v326 = -v219.RightVector.Y
			local v327 = math.clamp(v326, -1, 1)
			local v328 = math.asin(v327)
			local v329 = v218.AssemblyLinearVelocity.Y
			p209.bobVelocity = p209.bobVelocity + ((v329 - p209.lastVy) * -0.02 * 60 - p209.bob * 160 - p209.bobVelocity * 16) * p210
			p209.lastVy = v329
			local v330 = p209.bob + p209.bobVelocity * p210
			p209.bob = math.clamp(v330, -0.12, 0.12)
			local v331 = CFrame.new(0, v211.Size.Y / 2, 0)
			local v332, v333
			if v262.Left and v262.Right then
				local v334 = v262.Left.down
				local v335 = math.clamp(v334, 0, 1)
				local v336 = v335 * v335 * (3 - 2 * v335)
				local v337 = v262.Right.down
				local v338 = math.clamp(v337, 0, 1)
				local v339 = v338 * v338 * (3 - 2 * v338)
				v332 = (v339 - v336) * 0.35
				v333 = -math.max(v336, v339) * 0.25
			else
				v332 = 0
				v333 = 0
			end
			local v340 = v331 * CFrame.new(v328 * 0.55 + v332, p209.bob + v333, 0) * CFrame.Angles(-v325, 0, -v328 * 0.5) * v331:Inverse() * p209.seatOffset * p209.weldBase
			local v341 = v211.CFrame
			local v342 = v217:GetAttribute("TuckRootOffset")
			local v343
			if typeof(v342) == "Vector3" then
				v343 = CFrame.new(v342 * (p209.charScale or 1))
			else
				v343 = CFrame.identity
			end
			if v285 > 0 and p209.seatPoint then
				v340 = v340:Lerp(v341:ToObjectSpace(p209.seatPoint.WorldCFrame * v343 * CFrame.new(v_u_4.TUCK_HIP_OFFSET * p209.tuckScale) * CFrame.Angles(v_u_4.TUCK_PITCH, 0, 0)) * v215.C1, v285)
			end
			if v288 > 0 and p209.seatPoint then
				local v344 = p209.seatPoint.WorldCFrame
				if p209.animIsPark then
					v343 = CFrame.identity
				end
				v340 = v340:Lerp(v341:ToObjectSpace(v344 * v343 * CFrame.new(v_u_10.anchor(p209.animPose) * (p209.charScale or 1))) * v215.C1, v288)
			end
			if v282 > 0 then
				v340 = v340:Lerp(v341:ToObjectSpace(v317) * v215.C1, v282)
			end
			if v279 < 1 then
				v340 = (v341:ToObjectSpace(v320) * v215.C1):Lerp(v340, v279)
			end
			v215.C0 = v340
			local v345 = 0
			for v346, v347 in v262 do
				if p209.tuckFloorFeet then
					v347.tuck = v347.base
				elseif v285 > 0 and not v221 then
					v347.tuck = p209:tuckFoot(v213, v346, v219) or v347.tuck
				end
				local v348 = v347.base:Lerp(v347.tuck, v285):Lerp(v347.floor, v282)
				local v349
				if p209.seatPoint then
					v349 = p209.seatPoint.Position.Z - 0.5
				else
					v349 = v308 - 0.05
				end
				local v350 = v347.sign * 0.8
				local v351 = p209:groundAt((Vector3.new(v350, 0, v349)))
				local v352 = v347.down
				local v353 = math.clamp(v352, 0, 1)
				local v354 = v353 * v353 * (3 - 2 * v353)
				v345 = math.max(v345, v354)
				local v355 = not v221
				if v355 then
					v355 = v213:FindFirstChild(v346 .. "Foot")
				end
				if v355 and (v354 > 0.98 and v279 > 0.98) then
					local v356 = v355.Position - v355.CFrame.UpVector * (v355.Size.Y / 2)
					local v357 = v351.Y - v356.Y
					if v347.settled and math.abs(v357) > 0.45 then
						v347.offTime = (v347.offTime or 0) + p210
						if v347.offTime > 0.6 then
							v347.settled = false
						end
					else
						v347.offTime = 0
					end
					if not v347.settled then
						if math.abs(v357) < 0.08 then
							v347.settled = true
						else
							local v358 = v347.lift
							local v359 = 4 * p210
							local v360 = v358 + v357 * math.min(1, v359)
							local v361 = -v355.Size.Y
							local v362 = v355.Size.Y * 1.5
							v347.lift = math.clamp(v360, v361, v362)
						end
					end
				elseif v354 < 0.5 then
					v347.lift = 0
					v347.settled = false
				end
				local v363 = CFrame.new
				local v364 = v347.lift
				local v365 = v363(v219:PointToObjectSpace(v351 + Vector3.new(0, v364, 0))) * CFrame.Angles(0, -v347.sign * 0.17453292519943295, 0)
				local v366 = v348:Lerp(v365, v354)
				local v367 = 3.141592653589793 * v354
				local v368 = math.sin(v367) * 0.35
				local v369 = v366 + Vector3.new(0, v368, 0)
				if v279 < 1 then
					local v370 = -2.4 + v347.sign * 0.45
					local v371 = v219:PointToObjectSpace(p209:groundAt((Vector3.new(v370, 0, v318))))
					v369 = CFrame.new(v371):Lerp(v369, v279)
				end
				if p209.fitFeet and (not v221 and (v354 < 0.98 and v285 < 0.02)) then
					local v372, v373, v374 = p209:legReach(v213, v346)
					if v372 then
						local v375 = v219:PointToObjectSpace(v374)
						local v376 = v372 * 0.93 + v373
						local v377 = v369.Position
						local v378 = v376 * v376 - (v377.X - v375.X) ^ 2 - (v377.Y - v375.Y) ^ 2
						if v378 > 0 and v375.Z - v377.Z > math.sqrt(v378) then
							v369 = CFrame.new(v377.X, v377.Y, v375.Z - math.sqrt(v378)) * v369.Rotation
						elseif v378 <= 0 then
							local v379 = v377.X
							local v380 = v377.Y
							local v381 = v375.Z
							local v382 = Vector3.new(v379, v380, v381)
							v369 = CFrame.new(v375 + (v382 - v375).Unit * v376) * v369.Rotation
						end
					end
				end
				if not v221 and v354 > 0.02 then
					local v383, v384, v385 = p209:legReach(v213, v346)
					if v383 then
						local v386 = v219:PointToObjectSpace(v385)
						local v387 = v383 * 0.93 + v384
						local v388 = v369.Position - v386
						if v387 < v388.Magnitude then
							v369 = CFrame.new(v386 + v388.Unit * v387) * v369.Rotation
							v347.settled = true
							v347.offTime = 0
						end
					end
				end
				v347.attachment.CFrame = v369
				local v389
				if v355 then
					v389 = v212:FindFirstChild("PCX160_" .. v346 .. "Leg")
				else
					v389 = v355
				end
				if v389 then
					if v354 > 0.5 then
						if v389.Pole ~= v347.knee then
							v389.Pole = v347.knee
						end
						v347.stuckTime = 0
					elseif v354 < 0.02 and (v285 < 0.02 and (v282 < 0.02 and v279 > 0.98)) then
						if (v355.Position - v355.CFrame.UpVector * (v355.Size.Y / 2) - v347.attachment.WorldPosition).Magnitude > 0.35 and (v347.stuckTries or 0) < 2 then
							v347.stuckTime = (v347.stuckTime or 0) + p210
							if v347.stuckTime > 0.4 then
								v347.stuckTime = 0
								v347.stuckTries = (v347.stuckTries or 0) + 1
								local v390
								if v389.Pole then
									v390 = nil
								else
									v390 = v347.knee
								end
								v389.Pole = v390
							end
						else
							v347.stuckTime = 0
						end
					end
				end
				if not v347.knee then
					continue
				end
				local v391 = v328 * v347.sign
				local v392 = math.max(0, v391) * 1.4 * (1 - v282) * (1 - v285)
				local v393
				if p209.tuckFloorFeet then
					v393 = v347.kneeBase
				else
					v393 = v347.kneeTuck
				end
				local v394 = (v347.kneeBase:Lerp(v393, v285) + Vector3.new(v332, v333, 0)) * CFrame.new(v347.sign * v392, 0, 0)
				if v354 > 0 and p209.seatPoint then
					local v395 = (p209.seatPoint.Position + v365.Position) / 2
					local v396 = v347.sign * 0.3
					local v397 = v395 + Vector3.new(v396, 0, -3)
					v394 = v394:Lerp(CFrame.new(v397), v354)
				end
				v347.knee.CFrame = v394
			end
			local v398 = (p209.animIsPark or p209.tuckFloorFeet) and 0 or v288
			v_u_204(v212, v279 * (1 - (p209.tuckGrips and not p209.animIsPark and 0 or v288)))
			if not v221 then
				for v399, v400 in v262 do
					p209:solveLeg(v213, v399, v400, v279 * (1 - v398))
				end
				if v345 > 0.5 or v398 > 0 then
					p209:setLegLimits(v213, false)
				elseif v345 < 0.1 then
					p209:setLegLimits(v213, true)
				end
				p209:setArmLimits(v213, v288 <= 0)
			end
			if v221 then
				local v401 = v213:FindFirstChild("Torso")
				local v402 = {}
				local v403 = p209.steerRoot
				if v403 then
					v403 = p209.steerRoot:FindFirstChild("GripRight")
				end
				v402.Right = v403
				v402.Left = p209.gripLeft
				for _, v404 in { "Right", "Left" } do
					local v405
					if v401 then
						v405 = v401:FindFirstChild(v404 .. " Shoulder")
					else
						v405 = v401
					end
					if v405 and v402[v404] then
						v_u_200(v405, v402[v404].WorldPosition, v279)
					end
					local v406
					if v401 then
						v406 = v401:FindFirstChild(v404 .. " Hip")
					else
						v406 = v401
					end
					if not (v406 and v262[v404]) then
						continue
					end
					v_u_200(v406, v262[v404].attachment.WorldPosition, v279)
				end
			end
			local v407 = v212:FindFirstChild("PCX160_Look")
			if v407 then
				v407.Weight = v285
			end
			local v408 = v217:GetAttribute("Gear")
			if typeof(v408) == "number" then
				if p209.lastGear and (p209.lastGear < v408 and os.clock() - (p209.shiftAt or -10) > 0.3) then
					p209.shiftAt = os.clock()
				end
				p209.lastGear = v408
			end
			local v409 = v217:GetAttribute("ShiftStyle") == "Lift"
			local v410 = v409 and 0 or 0.12
			local v411 = v409 and 0 or 1
			local v412 = 0
			local v413 = 0
			local v414 = os.clock() - (p209.shiftAt or -10)
			if v409 and v414 >= 0.12 then
				v414 = v414 < 0.16999999999999998 and 0.12 or v414 - 0.05
			end
			local v415 = v212:FindFirstChild("PCX160_LeftArm")
			if v415 and v415:IsA("IKControl") then
				local v416 = v409 and v414 < 0.27 and 0 or 0.05
				if v415.SmoothTime ~= v416 then
					v415.SmoothTime = v416
				end
			end
			if v414 < 0.12 then
				local v417 = v414 / 0.12
				v412 = 1 - (1 - v417) * (1 - v417)
			elseif v414 < 0.19 then
				local v418 = (v414 - 0.12) / 0.07
				v412 = 1 - (v410 + 1) * v418 * v418
				v413 = v418 * v411
			elseif v414 < 0.27 then
				local v419 = (v414 - 0.12 - 0.07) / 0.08
				v412 = -v410 * (1 - v419)
				v413 = v411
			elseif v414 < 0.42000000000000004 then
				v413 = (1 - (v414 - 0.12 - 0.07 - 0.08) / 0.15) * v411
			end
			if p209.gripLeft and p209.gripLeftBase then
				local v420 = p209.squeeze
				local v421 = v224 < 0 and math.abs(v222) > 0.3 and 1 or 0
				local v422
				if v420 < v421 then
					local v423 = v420 + 8 * p210
					v422 = math.min(v423, v421)
				else
					local v424 = v420 - 8 * p210
					v422 = math.max(v424, v421)
				end
				p209.squeeze = v422
				local v425 = p209.gripLeft
				local v426 = CFrame.new((v409 and Vector3.new(-0.05, 0.75, 0.1) or Vector3.new(-0.06, 0.45, 0.14)) * v412) * p209.gripLeftBase
				local v427 = CFrame.Angles
				local v428 = p209.gripTilt
				local v429 = p209.squeeze
				v425.CFrame = v426 * v427(v428 - math.max(v429, v413) * 0.24434609527920614, 0, 0)
			end
			local v430 = os.clock()
			if math.abs(v222) < 0.5 and (v217:GetAttribute("EngineOn") == true and (p209.mode == "both" and p209.nextGlance < v430)) then
				p209.glanceTarget = (math.random() < 0.5 and -1 or 1) * 0.5235987755982988
				p209.glanceUntil = v430 + 1.2
				p209.nextGlance = v430 + 5 + math.random() * 4
			end
			if p209.glanceUntil < v430 then
				p209.glanceTarget = 0
			end
			p209.glance = p209.glance + (p209.glanceTarget - p209.glance) * v_u_4.alpha(4, p210)
			local v431 = v211.SteerFloat * 0.2617993877991494 + p209.glance
			local v432
			if v216 and v_u_5.mode() == "first" then
				local v433, v434 = v_u_5.look()
				v431 = v433 * 0.8
				v432 = v434 * 0.6
			else
				v432 = 0
			end
			local v435 = v213:FindFirstChild("Head")
			local v436
			if v221 then
				v436 = v213:FindFirstChild("Torso")
			else
				v436 = v221
			end
			if v436 then
				v435 = v436:FindFirstChild("Neck")
			elseif v435 then
				v435 = v435:FindFirstChild("Neck")
			end
			if v435 and v285 < 0.5 then
				local v437 = v328 * 1.5 * 0.35 * (1 - v282)
				local v438 = (0.06981317007977318 * (1 - v282) * (1 - v285) + v304 * 0.29670597283903605 * p209.hunchScale) * 0.8 * (1 - v245) - v245 * 0.20943951023931956
				local v439
				if v221 then
					v439 = CFrame.Angles(-(v432 + v438), v437, v431)
				else
					v439 = CFrame.Angles(v432 + v438, v431, v437)
				end
				if v288 > 0 then
					v439 = v439:Lerp(v435.Transform, v288)
				end
				v435.Transform = v439
			end
			local v440 = v213:FindFirstChild("UpperTorso")
			if v440 then
				v440 = v440:FindFirstChild("Waist")
			end
			if v440 then
				local v441 = 0.06981317007977318 * (1 - v282) * (1 - v285) + v304 * 0.24434609527920614 * p209.hunchScale + v245 * 0.24434609527920614
				local v442 = CFrame.Angles
				local v443 = -v441
				local v444 = p209.time * 0.25 * 2 * 3.141592653589793
				local v445 = v442(v443 + math.sin(v444) * 0.013962634015954637, 0, 0)
				if v288 > 0 then
					v445 = v445:Lerp(v440.Transform, v288)
				end
				v440.Transform = v445
			end
			if v288 > 0 and v288 < 1 then
				local v446 = v213:FindFirstChild("LowerTorso")
				local v447 = v446 and v446:FindFirstChild("Root") or v214:FindFirstChild("Root")
				if v447 and (v447:IsA("AnimationConstraint") or v447:IsA("Motor6D")) then
					v447.Transform = CFrame.identity:Lerp(v447.Transform, v288)
				end
			end
			if not v221 then
				local v448 = p209.animIsPark and 0 or v288
				local v449 = math.max(v448, v285)
				local v450 = v213:FindFirstChild("LowerTorso")
				if v450 then
					v450 = v450:FindFirstChild("Root")
				end
				local v451 = v217:GetAttribute("TuckBackUp")
				p209:addTurn(v450, typeof(v451) ~= "number" and 0 or math.rad(v451) * v449)
				local v452 = v217:GetAttribute("TuckWaistBend")
				p209:addTurn(v440, -(typeof(v452) ~= "number" and 0 or math.rad(v452) * v449))
				if v285 < 0.5 then
					local v453 = v217:GetAttribute("TuckHeadUp")
					p209:addTurn(v435, typeof(v453) ~= "number" and 0 or math.rad(v453) * v449)
				end
			end
			if v220 and (v216 and (p209.mount <= 0 and not p209.dismountSent)) then
				p209.dismountSent = true
				local v454 = v_u_3:FindFirstChild(v_u_4.REMOTE_NAME)
				if v454 then
					v_u_1.fire(v454, "Dismount", v320)
				end
			end
		end
	else
		return
	end
end
function v_u_12.destroy(p455) -- name: destroy
	p455:release()
end
return v_u_12