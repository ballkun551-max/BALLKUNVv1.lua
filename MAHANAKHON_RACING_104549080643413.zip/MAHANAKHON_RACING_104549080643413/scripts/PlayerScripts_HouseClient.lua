-- Path: Players/ygggggg55551/PlayerScripts/HouseClient
-- Class: LocalScript  true/Enum.RunContext.Legacy
-- Decompiled by BALL KUN Universal Map Dump

local v1 = game:GetService("CollectionService")
local v2 = game:GetService("Players").LocalPlayer.UserId
local v_u_3 = tostring(v2)
local function v10(p_u_4) -- name: watch
	-- upvalues: (copy) v_u_3
	local v5 = false
	for v6 in string.gmatch(p_u_4:GetAttribute("Allowed") or "", "%d+") do
		if v6 ~= v_u_3 then
			continue
		end
		v5 = true
	end
	p_u_4.CanCollide = not v5
	p_u_4:GetAttributeChangedSignal("Allowed"):Connect(function()
		-- upvalues: (copy) p_u_4, (ref) v_u_3
		local v7 = p_u_4
		local v8 = false
		for v9 in string.gmatch(v7:GetAttribute("Allowed") or "", "%d+") do
			if v9 ~= v_u_3 then
				continue
			end
			v8 = true
		end
		v7.CanCollide = not v8
	end)
end
for _, v_u_11 in v1:GetTagged("HouseBarrier") do
	local v12 = false
	for v13 in string.gmatch(v_u_11:GetAttribute("Allowed") or "", "%d+") do
		if v13 ~= v_u_3 then
			continue
		end
		v12 = true
	end
	v_u_11.CanCollide = not v12
	v_u_11:GetAttributeChangedSignal("Allowed"):Connect(function()
		-- upvalues: (copy) v_u_11, (copy) v_u_3
		local v14 = v_u_11
		local v15 = false
		for v16 in string.gmatch(v14:GetAttribute("Allowed") or "", "%d+") do
			if v16 ~= v_u_3 then
				continue
			end
			v15 = true
		end
		v14.CanCollide = not v15
	end)
end
v1:GetInstanceAddedSignal("HouseBarrier"):Connect(v10)