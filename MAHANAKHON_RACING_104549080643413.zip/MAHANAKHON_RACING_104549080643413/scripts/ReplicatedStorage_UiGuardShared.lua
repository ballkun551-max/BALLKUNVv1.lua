-- Path: ReplicatedStorage/UiGuardShared
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = {
	["REMOTE"] = "UiGuard",
	["CHECK_REMOTE"] = "UiCheck",
	["KNOWN"] = {}
}
for _, v2 in {
	"AdminPanel",
	"ArenaChoice",
	"CarTune",
	"ClanWindow",
	"Donate",
	"DuelRace",
	"FarmCheck",
	"FreeCamUI",
	"GameDash",
	"GameHud",
	"GameToast",
	"GarageWindow",
	"GroupReward",
	"HelmetRoom",
	"JobPicker",
	"JobPickerTitle",
	"LoadingScreen",
	"MainMenu",
	"MapUI",
	"Minigame",
	"Minimap",
	"PCX160Paint",
	"Phone",
	"PistonShop",
	"PlateEditor",
	"PlateUI",
	"RaceCountdown",
	"StoreWindow",
	"TopBar",
	"TouchPedals",
	"TuneHub",
	"TuneRideIn",
	"TuneShop",
	"VehicleCare",
	"VehicleCareTop",
	"VehicleHint",
	"WarpWindow",
	"WorkHud",
	"UiCheckView",
	"GraphicsPicker",
	"AdminGift",
	"BanMenu",
	"StickerEditor",
	"EcuTune",
	"TouchItems",
	"ControlLayout",
	"CargoMenu",
	"DashcamShop",
	"DashcamEditor",
	"DashcamRideIn",
	"DashcamViewPicker",
	"DashcamViewButton",
	"HudToggle",
	"CarWash",
	"ServerPanel",
	"Interface",
	"EngineStartUI",
	"Freecam",
	"TouchGui",
	"ProximityPrompts",
	"BubbleChat",
	"Chat",
	"RbxCameraUI",
	"AbilitiesGui"
} do
	v_u_1.KNOWN[v2] = true
end
v_u_1.ODD_OK = {
	["Lighting"] = {
		["MenuBlur"] = true,
		["WeatherGrade"] = true,
		["LightningFlash"] = true,
		["Sky:*"] = true
	},
	["Camera"] = {
		["AudioListener"] = true,
		["CarFirstPersonHands"] = true,
		["WeatherFX"] = true,
		["IceCreamWork"] = true,
		["CarWashFX"] = true,
		["CamFxCache"] = true
	},
	["ReplicatedStorage"] = {},
	["Player"] = {
		["HoverBike"] = true,
		["ControlLayoutStudioTest"] = true
	},
	["S:SoundService"] = {
		["Sound:*"] = true,
		["SoundGroup:*"] = true,
		["AudioDeviceOutput:*"] = true
	},
	["Body"] = {},
	["Vehicle"] = {}
}
v_u_1.ODD_SERVICES = {
	"SoundService",
	"ReplicatedFirst",
	"StarterGui",
	"TestService",
	"Teams",
	"Chat",
	"LocalizationService",
	"JointsService",
	"InsertService"
}
for _, v3 in v_u_1.ODD_SERVICES do
	v_u_1.ODD_OK["S:" .. v3] = v_u_1.ODD_OK["S:" .. v3] or {}
end
v_u_1.LOG_WORDS = {
	"luarmor",
	"getgenv",
	"hookfunction",
	"hookmetamethod",
	"queue_on_teleport",
	"rayfield",
	"orionlib",
	"infinite yield",
	"keysystem",
	"key system",
	"script hub",
	"autofarm",
	"auto farm",
	"anti afk",
	"antiafk",
	"anti-afk",
	"davinci",
	"mahanakornautofarm",
	"mahanakorn autofarm",
	"lunode",
	"d0tfrosty",
	"dotfrosty",
	"mahanakhon suite",
	"krakenhub",
	"kraken hub",
	"loading script",
	"honymoon",
	"xdspyz",
	"arsyny1x",
	"astraui"
}
function v_u_1.oddOk(p4, p5) -- name: oddOk
	-- upvalues: (copy) v_u_1
	if p4 == "S:SoundService" and p5.Name == "Sound" then
		return false
	end
	local v6 = v_u_1.ODD_OK[p4]
	return not v6 and true or (v6[p5.Name] == true and true or v6[p5.ClassName .. ":*"] == true)
end
v_u_1.EMPTY_ONLY = {
	["ScreenGui"] = true
}
v_u_1.NOT_MARKED = {
	["Interface"] = true,
	["EngineStartUI"] = true,
	["LoadingScreen"] = true,
	["Freecam"] = true,
	["TouchGui"] = true,
	["ProximityPrompts"] = true,
	["BubbleChat"] = true,
	["Chat"] = true,
	["RbxCameraUI"] = true,
	["AbilitiesGui"] = true
}
function v_u_1.isMarked(p7) -- name: isMarked
	-- upvalues: (copy) v_u_1
	local v8
	if v_u_1.KNOWN[p7] == true then
		v8 = not v_u_1.NOT_MARKED[p7]
	else
		v8 = false
	end
	return v8
end
v_u_1.NO_BUTTONS = {
	["Chat"] = true,
	["BubbleChat"] = true
}
v_u_1.MAX_INSIDE = 8
v_u_1.STAFF_ONLY = {
	["AdminPanel"] = "AdminWindow",
	["AdminGift"] = true,
	["UiCheckView"] = true,
	["BanMenu"] = "BanWindow"
}
v_u_1.LAYER_OK = "^Leaderboard_"
v_u_1.SWEEP_SKIP = {
	["AdminPanel"] = true,
	["AdminGift"] = true,
	["BanMenu"] = true,
	["UiCheckView"] = true,
	["ClanWindow"] = true,
	["ServerPanel"] = true,
	["PlateEditor"] = true,
	["PlateUI"] = true,
	["GameToast"] = true,
	["StickerEditor"] = true,
	["EcuTune"] = true
}
v_u_1.TOOLS = {
	["MahanakhonTunerRun"] = {
		["where"] = "PlayerScripts",
		["class"] = "BindableEvent",
		["tool"] = "ECU.lua (MahanakhonTunerRun)"
	},
	["ECUSettings"] = {
		["where"] = "PlayerGui",
		["class"] = "ScreenGui",
		["order"] = 10000,
		["tool"] = "ECU.lua (ECUSettings)"
	},
	["RayVinzBlur"] = {
		["where"] = "Lighting",
		["class"] = "BlurEffect",
		["tool"] = "TaTarzx / RayVinz UI (RayVinzBlur)"
	},
	["Cascade"] = {
		["where"] = "PlayerGui",
		["class"] = "ScreenGui",
		["order"] = 200,
		["tool"] = "Cascade UI (Davinci.dev AutoFarm)"
	},
	["KrakenHub_Mahanakhon_UI"] = {
		["where"] = "PlayerGui",
		["class"] = "ScreenGui",
		["tool"] = "KrakenHub (\224\184\171\224\184\153\224\185\137\224\184\178\224\184\149\224\185\136\224\184\178\224\184\135\224\184\171\224\184\165\224\184\177\224\184\129)"
	},
	["KrakenHub_Mahanakhon_Btn"] = {
		["where"] = "PlayerGui",
		["class"] = "ScreenGui",
		["tool"] = "KrakenHub (\224\184\155\224\184\184\224\185\136\224\184\161\224\185\128\224\184\155\224\184\180\224\184\148\224\185\128\224\184\161\224\184\153\224\184\185)"
	},
	["Kraken_ESPHighlight"] = {
		["where"] = "PlayerGui",
		["class"] = "Highlight",
		["tool"] = "KrakenHub (ESP)"
	},
	["Kraken_ESPBillboard"] = {
		["where"] = "PlayerGui",
		["class"] = "BillboardGui",
		["tool"] = "KrakenHub (ESP)"
	},
	["PlateEditor"] = {
		["where"] = "PlayerGui",
		["class"] = "ScreenGui",
		["order"] = 15,
		["tool"] = "MKN Suite / Davinci.dev (\224\184\171\224\184\153\224\185\137\224\184\178\224\184\149\224\185\136\224\184\178\224\184\135\224\184\155\224\184\165\224\184\173\224\184\161\224\184\138\224\184\183\224\185\136\224\184\173 PlateEditor)"
	},
	["StickerEditor"] = {
		["where"] = "PlayerGui",
		["class"] = "ScreenGui",
		["order"] = 999,
		["tool"] = "MKN Suite / Davinci.dev (\224\184\155\224\184\184\224\185\136\224\184\161\224\184\165\224\184\173\224\184\162\224\184\155\224\184\165\224\184\173\224\184\161\224\184\138\224\184\183\224\185\136\224\184\173 StickerEditor)"
	},
	["MarioHub"] = {
		["where"] = "PlayerGui",
		["class"] = "ScreenGui",
		["tool"] = "Honymoon Hub (\224\184\171\224\184\153\224\185\137\224\184\178\224\184\149\224\185\136\224\184\178\224\184\135\224\184\171\224\184\165\224\184\177\224\184\129 MarioHub)"
	},
	["MarioVisuals"] = {
		["where"] = "PlayerGui",
		["class"] = "ScreenGui",
		["tool"] = "Honymoon Hub (\224\184\138\224\184\177\224\185\137\224\184\153 ESP MarioVisuals)"
	},
	["MarioPhase"] = {
		["where"] = "Workspace",
		["class"] = "Folder",
		["tool"] = "Honymoon Hub (\224\185\130\224\184\159\224\184\165\224\185\128\224\184\148\224\184\173\224\184\163\224\185\140\224\184\130\224\184\177\224\184\154\224\184\151\224\184\176\224\184\165\224\184\184 MarioPhase)"
	},
	["MarioAvoid"] = {
		["where"] = "Workspace",
		["class"] = "Folder",
		["tool"] = "Honymoon Hub (\224\185\130\224\184\159\224\184\165\224\185\128\224\184\148\224\184\173\224\184\163\224\185\140\224\184\151\224\184\176\224\184\165\224\184\184\224\184\163\224\184\150 MarioAvoid)"
	},
	["MarioSimWalkVisuals"] = {
		["where"] = "Workspace",
		["class"] = "Folder",
		["tool"] = "Honymoon Hub (\224\185\128\224\184\170\224\185\137\224\184\153\224\184\151\224\184\178\224\184\135\224\184\153\224\184\181\224\184\173\224\184\173\224\184\153 MarioSimWalkVisuals)"
	},
	["AstraUI"] = {
		["where"] = "PlayerGui",
		["class"] = "ScreenGui",
		["order"] = 50,
		["tool"] = "arsyny1x / Astra UI (\224\184\171\224\184\153\224\185\137\224\184\178\224\184\149\224\185\136\224\184\178\224\184\135 AstraUI)"
	},
	["NoclipYHold"] = {
		["where"] = "Vehicle",
		["class"] = "LinearVelocity",
		["tool"] = "arsyny1x (\224\184\149\224\184\177\224\184\167\224\184\162\224\184\182\224\184\148\224\184\132\224\184\167\224\184\178\224\184\161\224\184\170\224\184\185\224\184\135\224\184\149\224\184\173\224\184\153\224\184\130\224\184\177\224\184\154\224\184\151\224\184\176\224\184\165\224\184\184 NoclipYHold)"
	},
	["NoclipCenterAttachment"] = {
		["where"] = "Vehicle",
		["class"] = "Attachment",
		["tool"] = "arsyny1x (\224\184\136\224\184\184\224\184\148\224\184\162\224\184\182\224\184\148\224\184\130\224\184\177\224\184\154\224\184\151\224\184\176\224\184\165\224\184\184 NoclipCenterAttachment)"
	}
}
v_u_1.TAMPER = {
	["NetSeal"] = { "fire", "invoke" },
	["PCX160Shared"] = {
		"CRASH_MIN_SPEED",
		"CRASH_SPEED_DROP",
		"CRASH_SIDE_SPEED",
		"CRASH_RAGDOLL_TIME",
		"BRAKE_DECEL",
		"TUCK_SPEED_BONUS",
		"THROTTLE_ACCEL",
		"ACCEL_TAPER",
		"STEER_RATE_SLOW"
	},
	["CarShared"] = {
		"IMPACT_MIN_SPEED",
		"IMPACT_SPEED_DROP",
		"BRAKE_DECEL",
		"ACCEL"
	},
	["EcuShared"] = {
		"TOP_KMH",
		"TUCK_TOP_KMH",
		"ABS_KMH",
		"gain"
	},
	["CareShared"] = {
		"damage",
		"health",
		"healthPower",
		"healthTop"
	},
	["GearShared"] = { "pull" },
	["GameUI.Theme"] = { "isTouch" },
	["VehicleFx"] = { "report", "shake" }
}
v_u_1.GLOBALS = {
	"KrakenHub_Mahanakhon",
	"_KrakenHub_InitUI_Error",
	"_MahanakhonScriptId",
	"_DavinciVerified",
	"_DavinciVerifiedKey",
	"_DavinciKey",
	"_DavinciExpiresAt",
	"__MahanakhonKeyGate",
	"__MahanakhonRefreshAfterKey",
	"__MahanakhonMainStage",
	"__MahanakhonMainError",
	"MKN_Cleanup",
	"MKN_State",
	"MKN_StartFarmLoop",
	"MKN_FarmToggle",
	"MKN_VehicleService",
	"MKN_TuningService",
	"MKN_MaintenanceService",
	"MKN_CollisionDefenseService",
	"MKN_PistonSentryService",
	"MKN_CheckCashTarget",
	"MKN_stopAllAndReset",
	"MKN_UiControls",
	"MKN_ConfigManager",
	"MKN_AutoFarm_Running",
	"__MahanakhonAstraWindow",
	"__MahanakhonStopJobTask",
	"__MahanakhonStopAutoTune",
	"__MahanakhonStopAutoRefuel",
	"__MahanakhonStopAutoRepair",
	"__FarmCheckAutoStop",
	"__FocusSpoofCleanup",
	"__StaffDetectorCleanup",
	"__VehicleAutoDriveCleanup",
	"__PCX160AutoDriveCleanup",
	"__ActiveJobStop",
	"__BuilderJobStop"
}
v_u_1.MOVERS = {
	["BodyVelocity"] = true,
	["BodyGyro"] = true,
	["BodyPosition"] = true,
	["BodyForce"] = true,
	["BodyThrust"] = true,
	["BodyAngularVelocity"] = true,
	["RocketPropulsion"] = true
}
v_u_1.LOG_MARKS = {
	"[KrakenHub",
	"[Davinci.dev]",
	"Maclib UI: ",
	"Key UI: ",
	"[Honymoon Hub]",
	"[Mario Hub] ",
	"[AstraUI] ",
	"[FarmCheck] \224\184\170\224\185\136\224\184\135\224\184\132\224\184\179\224\184\149\224\184\173\224\184\154 ",
	"[FarmCheck] \224\184\149\224\184\173\224\184\154\224\185\132\224\184\161\224\185\136\224\184\150\224\184\185\224\184\129\224\184\149\224\185\137\224\184\173\224\184\135: ",
	"[VehicleSelect] \224\185\128\224\184\165\224\184\183\224\184\173\224\184\129\224\184\158\224\184\178\224\184\171\224\184\153\224\184\176\224\184\170\224\184\179\224\184\171\224\184\163\224\184\177\224\184\154\224\184\159\224\184\178\224\184\163\224\185\140\224\184\161",
	"[string \""
}
v_u_1.CORE_ONLY = {
	"^CoreGui%.",
	"^CorePackages%.",
	"^RobloxGui",
	"^BuiltInPlugins%."
}
function v_u_1.isCoreOnly(p9) -- name: isCoreOnly
	-- upvalues: (copy) v_u_1
	if type(p9) ~= "string" then
		return false
	end
	for _, v10 in v_u_1.CORE_ONLY do
		if not string.find(p9, v10) then
			continue
		end
		return true
	end
	return false
end
function v_u_1.tool(p11, p12) -- name: tool
	-- upvalues: (copy) v_u_1
	local v13 = v_u_1.TOOLS[p12.Name]
	if v13 and (v13.where == p11 and (p12.ClassName == v13.class and (v13.order == nil or p12:IsA("ScreenGui") and p12.DisplayOrder == v13.order))) then
		return v13
	else
		return v_u_1.shape(p11, p12.ClassName, p12.Name)
	end
end
v_u_1.TOOL_SHAPES = {
	{
		["where"] = "Lighting",
		["class"] = "DepthOfFieldEffect",
		["pattern"] = "^{%x%x%x%x%x%x%x%x%-%x%x%x%x%-%x%x%x%x%-%x%x%x%x%-%x%x%x%x%x%x%x%x%x%x%x%x}$",
		["tool"] = "MacLib UI (\224\184\149\224\184\178\224\184\149\224\185\137\224\184\178\224\185\128\224\184\173\224\184\135\224\184\136\224\184\177\224\185\138\224\184\159 / KrakenHub): \224\185\128\224\184\154\224\184\165\224\184\173\224\184\171\224\184\165\224\184\177\224\184\135\224\184\171\224\184\153\224\185\137\224\184\178\224\184\149\224\185\136\224\184\178\224\184\135\224\185\130\224\184\155\224\184\163"
	},
	{
		["where"] = "Camera",
		["class"] = "Part",
		["pattern"] = "^{%x%x%x%x%x%x%x%x%-%x%x%x%x%-%x%x%x%x%-%x%x%x%x%-%x%x%x%x%x%x%x%x%x%x%x%x}$",
		["tool"] = "MacLib UI (\224\184\149\224\184\178\224\184\149\224\185\137\224\184\178\224\185\128\224\184\173\224\184\135\224\184\136\224\184\177\224\185\138\224\184\159 / KrakenHub): \224\185\129\224\184\156\224\185\136\224\184\153\224\184\129\224\184\163\224\184\176\224\184\136\224\184\129\224\184\171\224\184\165\224\184\177\224\184\135\224\184\171\224\184\153\224\185\137\224\184\178\224\184\149\224\185\136\224\184\178\224\184\135\224\185\130\224\184\155\224\184\163"
	},
	{
		["where"] = "CameraFolder",
		["class"] = "Part",
		["pattern"] = "^Body$",
		["tool"] = "Fluent UI: \224\185\129\224\184\156\224\185\136\224\184\153\224\184\129\224\184\163\224\184\176\224\184\136\224\184\129\224\184\171\224\184\165\224\184\177\224\184\135\224\184\171\224\184\153\224\185\137\224\184\178\224\184\149\224\185\136\224\184\178\224\184\135\224\185\130\224\184\155\224\184\163 (Project+ / hub \224\184\151\224\184\181\224\185\136\224\185\131\224\184\138\224\185\137 Fluent)"
	},
	{
		["where"] = "CameraFolder",
		["class"] = "Part",
		["pattern"] = "^Part$",
		["tool"] = "Cascade UI: \224\185\129\224\184\156\224\185\136\224\184\153\224\184\129\224\184\163\224\184\176\224\184\136\224\184\129\224\184\171\224\184\165\224\184\177\224\184\135\224\184\171\224\184\153\224\185\137\224\184\178\224\184\149\224\185\136\224\184\178\224\184\135\224\185\130\224\184\155\224\184\163 (Davinci.dev AutoFarm)"
	}
}
function v_u_1.shape(p14, p15, p16) -- name: shape
	-- upvalues: (copy) v_u_1
	if type(p16) ~= "string" then
		return nil
	end
	for _, v17 in v_u_1.TOOL_SHAPES do
		if v17.where ~= p14 or (v17.class ~= p15 or not string.match(p16, v17.pattern)) then
			continue
		end
		return v17
	end
	return nil
end
v_u_1.CORE_SOURCES = {
	"^CoreGui%.",
	"^CorePackages%.",
	"^RobloxGui",
	"^BuiltInPlugins%.",
	"^StarterPlayer%.StarterPlayerScripts%.PlayerModule"
}
function v_u_1.isCore(p18) -- name: isCore
	-- upvalues: (copy) v_u_1
	for _, v19 in v_u_1.CORE_SOURCES do
		if not string.find(p18, v19) then
			continue
		end
		return true
	end
	return false
end
v_u_1.HUBS = {
	"d0tfrosty",
	"dotfrosty",
	"d0t frosty",
	"\224\184\148\224\184\173\224\184\151\224\184\159\224\184\173\224\184\170\224\184\149\224\184\181\224\185\137",
	"\224\184\148\224\184\173\224\184\151\224\184\159\224\184\163\224\184\173\224\184\170\224\184\149\224\184\181\224\185\137",
	"\224\184\148\224\184\173\224\184\151\224\184\159\224\184\173\224\184\170\224\184\149\224\184\181",
	"\224\184\148\224\184\173\224\184\151\224\184\159\224\184\163\224\184\173\224\184\170\224\184\149\224\184\181",
	"admin panel x",
	"infinite yield",
	"infiniteyield",
	"script hub",
	"scripthub",
	"fates admin",
	"nameless admin",
	"cmd-x",
	"owl hub",
	"redz hub",
	"hoho hub",
	"speed hub x",
	"banana hub",
	"solix hub",
	"zenith hub",
	"vynixius",
	"dex explorer",
	"dark dex",
	"hydroxide",
	"simplespy",
	"simple spy",
	"remote spy",
	"remotespy",
	"rayfield",
	"orion",
	"kavo",
	"linoria",
	"venyx",
	"windui",
	"wind ui",
	"rayvinz",
	"luarmor",
	"executor",
	"arceus",
	"fluxus",
	"krnl",
	"synapse",
	"macsploit",
	"seliware",
	"lunode",
	"davinci.dev",
	"mahanakhon suite",
	"krakenhub",
	"kraken hub",
	"mkn suite",
	"honymoon hub",
	"honymoon",
	"mario hub",
	"xdspyz",
	"arsyny1x",
	"astraui"
}
v_u_1.STRONG = {
	"noclip",
	"no clip",
	"walkspeed",
	"walk speed",
	"speed hack",
	"speedhack",
	"jumppower",
	"jump power",
	"aimbot",
	"auto farm",
	"autofarm",
	"auto-farm",
	"kill aura",
	"god mode",
	"godmode",
	"admin cmds",
	"tpwalk",
	"tp walk",
	"fly gui",
	"flygui",
	"click tp",
	"clicktp",
	"inf jump",
	"infinite jump",
	"auto deliver",
	"autodeliver",
	"auto job",
	"autojob",
	"auto money",
	"auto cash",
	"\224\184\173\224\184\173\224\185\130\224\184\149\224\185\137\224\184\159\224\184\178\224\184\163\224\185\140\224\184\161",
	"\224\184\159\224\184\178\224\184\163\224\185\140\224\184\161\224\184\173\224\184\173\224\185\130\224\184\149\224\185\137",
	"\224\185\130\224\184\155\224\184\163\224\184\167\224\184\178\224\184\163\224\185\140\224\184\155",
	"\224\185\130\224\184\155\224\184\163\224\184\154\224\184\180\224\184\153",
	"\224\184\151\224\184\179\224\184\135\224\184\178\224\184\153\224\184\173\224\184\177\224\184\149\224\185\130\224\184\153\224\184\161\224\184\177\224\184\149\224\184\180",
	"anti afk",
	"anti-afk",
	"antiafk",
	"auto parcel",
	"auto rider",
	"auto grab",
	"auto ride",
	"admin panel",
	"\224\184\163\224\184\177\224\184\154\224\184\132\224\184\181\224\184\162\224\185\140",
	"\224\184\139\224\184\183\224\185\137\224\184\173\224\184\132\224\184\181\224\184\162\224\185\140",
	"\224\184\162\224\184\183\224\184\153\224\184\162\224\184\177\224\184\153\224\184\132\224\184\181\224\184\162\224\185\140",
	"\224\185\132\224\184\161\224\185\136\224\184\149\224\185\137\224\184\173\224\184\135\224\185\131\224\184\170\224\185\136\224\184\132\224\184\181\224\184\162\224\185\140",
	"\224\185\131\224\184\170\224\185\136\224\184\132\224\184\181\224\184\162\224\185\140"
}
v_u_1.WEAK = {
	"fly",
	"esp",
	"hub",
	"teleport",
	"tween",
	"execute",
	"inject",
	"exploit",
	"delta",
	"dex",
	"cmd",
	"cmds",
	"fluent",
	"hydrogen",
	"codex",
	"solara",
	"vega",
	"trigon",
	"tp",
	"bypass",
	"loadstring",
	"frosty",
	"keyless",
	"get key",
	"discord",
	"\224\185\128\224\184\130\224\185\137\224\184\178\224\184\163\224\185\136\224\184\167\224\184\161\224\184\148\224\184\180\224\184\170\224\184\132\224\184\173\224\184\163\224\185\140\224\184\148",
	"\224\185\131\224\184\171\224\185\137\224\185\128\224\184\135\224\184\180\224\184\153"
}
local function v_u_31(p20, p21) -- name: has
	local v22 = 1
	while true do
		local v23, v24 = string.find(p20, p21, v22, true)
		if not v23 then
			break
		end
		local v25
		if v23 > 1 then
			local v26 = v23 - 1
			local v27 = v23 - 1
			v25 = string.sub(p20, v26, v27)
		else
			v25 = ""
		end
		local v28 = v24 + 1
		local v29 = v24 + 1
		local v30 = string.sub(p20, v28, v29)
		if not (string.find(v25, "%w") or string.find(v30, "%w")) then
			return true
		end
		v22 = v23 + 1
	end
	return false
end
function v_u_1.judge(p32, p33) -- name: judge
	-- upvalues: (copy) v_u_1, (copy) v_u_31
	local v34 = { string.lower((tostring(p32 or ""))) }
	for _, v35 in p33 or {} do
		local v36 = string.lower
		local v37 = tostring(v35)
		table.insert(v34, v36(v37))
	end
	local v38 = nil
	local v39 = nil
	local v40 = {}
	local v41 = {}
	for _, v42 in v34 do
		for _, v43 in v_u_1.HUBS do
			if v38 or not v_u_31(v42, v43) then
				continue
			end
			v38 = v43
		end
		for _, v44 in v_u_1.STRONG do
			if v39 or not v_u_31(v42, v44) then
				continue
			end
			v39 = v44
		end
		for _, v45 in v_u_1.WEAK do
			if v40[v45] or not v_u_31(v42, v45) then
				continue
			end
			v40[v45] = true
			table.insert(v41, v45)
		end
	end
	local v46 = {
		["hub"] = v38,
		["strong"] = v39,
		["weak"] = v41,
		["exploit"] = (v38 ~= nil or v39 ~= nil) and true or #v41 >= 2
	}
	if v38 then
		v39 = v38
	elseif not v39 then
		if #v41 > 0 then
			v39 = table.concat(v41, " + ")
		else
			v39 = nil
		end
	end
	v46.word = v39
	return v46
end
function v_u_1.suspicious(p47) -- name: suspicious
	-- upvalues: (copy) v_u_1
	return v_u_1.judge(p47, {}).word
end
v_u_1.BEAT_EVERY = 20
v_u_1.SILENT_AFTER = 75
v_u_1.FIRST_BEAT_WITHIN = 120
v_u_1.MAX_BOXES = 300
v_u_1.MAX_TEXT = 48
function v_u_1.onScreen(p48) -- name: onScreen
	while p48 do
		if p48:IsA("GuiObject") and not p48.Visible or p48:IsA("LayerCollector") and not p48.Enabled then
			return false
		end
		p48 = p48.Parent
	end
	return true
end
function v_u_1.cut(p49) -- name: cut
	-- upvalues: (copy) v_u_1
	local v50 = tostring(p49):gsub("%s+", " ")
	if #v50 > v_u_1.MAX_TEXT then
		return v50:sub(1, v_u_1.MAX_TEXT)
	else
		return v50
	end
end
function v_u_1.describe(p51) -- name: describe
	-- upvalues: (copy) v_u_1
	local v52 = v_u_1.cut
	local v53 = p51:GetDescendants()
	table.insert(v53, p51)
	local v54 = 0
	local v55 = 0
	local v56 = 0
	local v57 = 0
	local v58 = {}
	local v59 = {}
	for _, v60 in v53 do
		if not v60:IsA("GuiObject") then
			continue
		end
		v54 = v54 + 1
		if v60:IsA("GuiButton") then
			v55 = v55 + 1
		end
		local v61 = v60.AbsoluteSize.X
		v56 = math.max(v56, v61)
		local v62 = v60.AbsoluteSize.Y
		v57 = math.max(v57, v62)
		if not (v60:IsA("TextLabel") or (v60:IsA("TextButton") or v60:IsA("TextBox"))) or #v58 >= 16 then
			continue
		end
		local v63 = v52(v60.Text)
		if v63 == "" or (v63 == " " or v59[v63]) then
			continue
		end
		v59[v63] = true
		table.insert(v58, v63)
	end
	return {
		["name"] = v52(p51.Name),
		["class"] = p51.ClassName,
		["parts"] = v54,
		["buttons"] = v55,
		["texts"] = v58,
		["w"] = math.floor(v56),
		["h"] = math.floor(v57)
	}
end
local v_u_64 = 0
function v_u_1.sealed(p65, p66) -- name: sealed
	-- upvalues: (ref) v_u_64, (copy) v_u_1
	if v_u_64 < v_u_1.MAX_INSIDE and p66.Parent then
		v_u_64 = v_u_64 + 1
		local v67 = game:GetService("ReplicatedStorage")
		local v68 = require(v67:WaitForChild("NetSeal"))
		local v69 = require(v67:WaitForChild("GameShared"))
		local v70 = v_u_1.describe(p66)
		v70.name = v_u_1.cut(p65 .. "/" .. p66.Name)
		v70.soft = true
		v70.sealed = true
		local v71 = require(v67:WaitForChild("UiOwn"))
		v70.by = v71.madeBy(p66)
		v70.copy = not v71.mine(p66)
		v70.shown = v_u_1.onScreen(p66)
		local v72 = v68.fire
		local v73 = v67:WaitForChild(v69.REMOTES):WaitForChild(v_u_1.REMOTE)
		pcall(v72, v73, "Found", v70)
	end
end
function v_u_1.isChunk(p74) -- name: isChunk
	if type(p74) ~= "string" or p74 == "" then
		return false
	end
	local v75 = string.sub(p74, 1, 1)
	return (string.sub(p74, 1, 9) == "[string \"" or v75 == "=") and true or v75 == "@"
end
local function v_u_82(p76, p77) -- name: sig
	-- upvalues: (copy) v_u_82
	if type(p76) ~= "table" then
		return tostring(p76)
	end
	if p77 > 4 then
		return "{...}"
	end
	local v78 = {}
	for v79, v80 in p76 do
		local v81 = tostring(v79) .. "=" .. v_u_82(v80, p77 + 1)
		table.insert(v78, v81)
	end
	table.sort(v78)
	return "{" .. table.concat(v78, ",") .. "}"
end
function v_u_1.entries(p83) -- name: entries
	-- upvalues: (copy) v_u_82
	local v84 = {}
	for v85, v86 in p83 do
		local v87
		if type(v85) == "number" then
			v87 = "#" .. v_u_82(v86, 1)
		else
			v87 = tostring(v85) .. "=" .. v_u_82(v86, 1)
		end
		v84[string.sub(v87, 1, 120)] = true
	end
	return v84
end
local v_u_88 = {}
local v_u_89 = {}
for v90, v91 in v_u_1 do
	v_u_88[v90] = v91
	local v92
	if type(v91) == "table" then
		v92 = v_u_82(v91, 0)
	else
		v92 = nil
	end
	v_u_89[v90] = v92
end
local v_u_93 = {}
for v94, v95 in v_u_1 do
	if type(v95) ~= "table" then
		continue
	end
	v_u_93[v94] = v_u_1.entries(v95)
end
local v_u_96 = v_u_1.entries
function v_u_1.drift() -- name: drift
	-- upvalues: (copy) v_u_88, (copy) v_u_1, (copy) v_u_82, (copy) v_u_89, (copy) v_u_96, (copy) v_u_93
	local v97 = {}
	for v98, v99 in v_u_88 do
		local v100 = v_u_1
		local v101 = rawget(v100, v98)
		if type(v99) == "table" then
			if type(v101) == "table" then
				if v_u_82(v101, 0) == v_u_89[v98] then
					continue
				end
				local v102 = v_u_96(v101)
				local v103 = v_u_93[v98]
				local v104 = {}
				local v105 = {}
				for v106 in v102 do
					if v103[v106] or #v104 >= 6 then
						continue
					end
					table.insert(v104, v106)
				end
				for v107 in v103 do
					if v102[v107] or #v105 >= 6 then
						continue
					end
					table.insert(v105, v107)
				end
				table.insert(v97, {
					["name"] = v98,
					["added"] = v104,
					["removed"] = v105
				})
			else
				local v108 = {
					["name"] = v98,
					["value"] = tostring(v101)
				}
				table.insert(v97, v108)
			end
		elseif type(v99) == "function" then
			if rawequal(v101, v99) then
				continue
			end
			table.insert(v97, {
				["name"] = nil,
				["fn"] = true,
				["name"] = v98
			})
		else
			if v101 == v99 then
				continue
			end
			local v109 = {
				["name"] = v98,
				["value"] = tostring(v101)
			}
			table.insert(v97, v109)
		end
	end
	for v110 in v_u_1 do
		if v_u_88[v110] ~= nil then
			continue
		end
		local v111 = {
			["name"] = nil,
			["newField"] = true,
			["name"] = tostring(v110)
		}
		table.insert(v97, v111)
	end
	return v97
end
v_u_88.drift = v_u_1.drift
return v_u_1