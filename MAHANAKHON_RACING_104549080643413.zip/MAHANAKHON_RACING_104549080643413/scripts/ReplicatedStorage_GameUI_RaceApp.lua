-- Path: ReplicatedStorage/GameUI/RaceApp
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = require(game:GetService("ReplicatedStorage"):WaitForChild("NetSeal"))
local v_u_2 = game:GetService("Players")
local v_u_3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = require(v_u_3:WaitForChild("GameShared"))
local v_u_6 = require(v_u_3:WaitForChild("RaceShared"))
local v_u_7 = require(script.Parent:WaitForChild("Theme"))
local v_u_8 = require(script.Parent:WaitForChild("Icons"))
local v_u_9 = require(script.Parent:WaitForChild("Toast"))
local v10 = {}
local v_u_11 = Color3.new(1, 1, 1)
local v_u_12 = Color3.fromRGB(28, 30, 36)
local v_u_13 = Color3.fromRGB(112, 116, 128)
local v_u_14 = Color3.fromRGB(243, 244, 247)
local v_u_15 = Color3.fromRGB(232, 40, 60)
local v_u_16 = Color3.fromRGB(40, 22, 30)
local v_u_17 = Color3.fromRGB(64, 222, 120)
local v_u_18 = Color3.fromRGB(16, 156, 84)
local v_u_19 = TweenInfo.new(0.3, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
local v_u_20 = v_u_2.LocalPlayer
local function v_u_38(p21, p22, p23, p24, p25, p26, p27, p28, p29, p30) -- name: label
	-- upvalues: (copy) v_u_7
	local v31 = v_u_7.text
	local v32 = {
		["Text"] = p22
	}
	local v33
	if p29 then
		v33 = v_u_7.FONT_BOLD
	else
		v33 = v_u_7.FONT
	end
	v32.FontFace = v33
	v32.TextSize = p27
	v32.TextColor3 = p28
	v32.TextXAlignment = Enum.TextXAlignment.Left
	v32.TextTruncate = Enum.TextTruncate.AtEnd
	v32.Position = UDim2.new(0, p23, 0, p24)
	local v34
	if p25 then
		v34 = UDim2.fromOffset(p25, p26)
	else
		v34 = UDim2.new(1, -p23 - 8, 0, p26)
	end
	v32.Size = v34
	v32.Parent = p21
	local v35 = v31(v32)
	for v36, v37 in p30 or {} do
		v35[v36] = v37
	end
	return v35
end
local function v_u_46(p39, p40, p41) -- name: card
	-- upvalues: (copy) v_u_7, (copy) v_u_11
	local v42 = {
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.92,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = Color3.new(0, 0, 0),
		["Position"] = UDim2.new(0, 14, 0, p40 + 3),
		["Size"] = UDim2.new(1, -28, 0, p41),
		["Parent"] = p39
	}
	local v43 = v_u_7.new("Frame", v42)
	v_u_7.corner(v43, 14)
	local v44 = {
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_11,
		["Position"] = UDim2.new(0, 14, 0, p40),
		["Size"] = UDim2.new(1, -28, 0, p41),
		["Parent"] = p39
	}
	local v45 = v_u_7.new("Frame", v44)
	v_u_7.corner(v45, 14)
	return v45
end
function v10.build(p47, p_u_48) -- name: build
	-- upvalues: (copy) v_u_3, (copy) v_u_5, (copy) v_u_6, (copy) v_u_14, (copy) v_u_7, (copy) v_u_11, (copy) v_u_15, (copy) v_u_16, (copy) v_u_8, (copy) v_u_38, (copy) v_u_46, (copy) v_u_12, (copy) v_u_13, (copy) v_u_17, (copy) v_u_18, (copy) v_u_4, (copy) v_u_20, (copy) v_u_1, (copy) v_u_9, (copy) v_u_2, (copy) v_u_19
	local v_u_49 = v_u_3:WaitForChild(v_u_5.REMOTES):WaitForChild(v_u_6.REMOTE)
	local v50 = {}
	local v51 = {
		["Name"] = "RaceApp",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["Visible"] = false,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_14,
		["Size"] = UDim2.fromScale(1, 1),
		["Parent"] = p47
	}
	local v_u_52 = v_u_7.new("Frame", v51)
	local v_u_53 = v_u_7.new("UIScale", {
		["Parent"] = v_u_52
	})
	v50.frame = v_u_52
	local v54 = {
		["Name"] = "Header",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_11,
		["Size"] = UDim2.new(1, 0, 0, 92),
		["Parent"] = v_u_52
	}
	local v55 = v_u_7.new("Frame", v54)
	local v56 = {
		["Rotation"] = 25,
		["Color"] = nil,
		["Parent"] = nil,
		["Color"] = ColorSequence.new(v_u_15, v_u_16),
		["Parent"] = v55
	}
	v_u_7.new("UIGradient", v56)
	local v57 = {
		["Name"] = "Back",
		["Text"] = "",
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Position"] = UDim2.fromOffset(4, 42),
		["Size"] = UDim2.fromOffset(30, 44),
		["Parent"] = v55
	}
	local v58 = v_u_7.new("TextButton", v57)
	local v59 = v_u_8.make("arrow", v_u_11, 20)
	v59.AnchorPoint = Vector2.new(0.5, 0.5)
	v59.Position = UDim2.fromScale(0.5, 0.5)
	v59.Parent = v58
	v58.Activated:Connect(function()
		-- upvalues: (copy) p_u_48
		p_u_48()
	end)
	v_u_38(v55, "Race", 38, 40, nil, 26, 22, v_u_11, true)
	v_u_38(v55, "3 2 1 Go! for the riders around you", 38, 66, nil, 16, 12, v_u_11, false, {
		["TextTransparency"] = 0.12
	})
	local v60 = v_u_46(v_u_52, 104, 52 + (v_u_6.MAX_RACERS - 1) * 40)
	local v_u_61 = v_u_38(v60, "", 14, 10, nil, 20, 15, v_u_12, true)
	local v62 = v_u_38
	local v63 = v_u_6.RADIUS * 0.28 + 0.5
	v62(v60, ("Within %d m, up to %d riders"):format(math.floor(v63), v_u_6.MAX_RACERS), 14, 30, nil, 16, 11, v_u_13, false)
	local v_u_64 = {}
	for v65 = 1, v_u_6.MAX_RACERS - 1 do
		local v66 = (v65 - 1) * 40 + 50
		local v67 = {
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Position"] = nil,
			["Size"] = nil,
			["Visible"] = false,
			["Parent"] = nil,
			["BackgroundColor3"] = v_u_14,
			["Position"] = UDim2.new(0, 10, 0, v66),
			["Size"] = UDim2.new(1, -20, 0, 34),
			["Parent"] = v60
		}
		local v68 = v_u_7.new("Frame", v67)
		v_u_7.corner(v68, 10)
		local v69 = {
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0, 0.5),
			["Position"] = UDim2.new(0, 10, 0.5, 0),
			["Size"] = UDim2.fromOffset(10, 10),
			["Parent"] = v68
		}
		local v70 = v_u_7.new("Frame", v69)
		v_u_7.corner(v70, 5)
		v_u_64[v65] = {
			["frame"] = v68,
			["dot"] = v70,
			["name"] = v_u_38(v68, "", 28, 0, 130, 34, 13, v_u_12, true),
			["far"] = v_u_38(v68, "", 0, 0, nil, 34, 12, v_u_13, false, {
				["TextXAlignment"] = Enum.TextXAlignment.Right,
				["Position"] = UDim2.new(0, 0, 0, 0),
				["Size"] = UDim2.new(1, -10, 1, 0)
			})
		}
	end
	local v_u_71 = v_u_38(v60, "No one nearby yet: ride up next to your friends", 14, 58, nil, 34, 12, v_u_13, false, {
		["TextWrapped"] = true,
		["TextTruncate"] = nil,
		["TextTruncate"] = Enum.TextTruncate.None
	})
	local v72 = {
		["Name"] = "Start",
		["Text"] = "",
		["AutoButtonColor"] = false,
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_11,
		["AnchorPoint"] = Vector2.new(0.5, 1),
		["Position"] = UDim2.new(0.5, 0, 1, -34),
		["Size"] = UDim2.new(1, -28, 0, 64),
		["Parent"] = v_u_52
	}
	local v73 = v_u_7.new("TextButton", v72)
	v_u_7.corner(v73, 18)
	local v74 = {
		["Rotation"] = 90,
		["Color"] = nil,
		["Parent"] = nil,
		["Color"] = ColorSequence.new(v_u_17, v_u_18),
		["Parent"] = v73
	}
	local v_u_75 = v_u_7.new("UIGradient", v74)
	local v_u_76 = v_u_38(v73, "START  3 \194\183 2 \194\183 1", 0, 0, nil, 64, 22, v_u_11, true, {
		["TextXAlignment"] = Enum.TextXAlignment.Center,
		["Size"] = UDim2.fromScale(1, 1)
	})
	local v_u_77 = v_u_7.new("UIScale", {
		["Parent"] = v73
	})
	v73.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_4, (copy) v_u_77
		v_u_4:Create(v_u_77, TweenInfo.new(0.1), {
			["Scale"] = 0.94
		}):Play()
	end)
	for _, v78 in { v73.MouseButton1Up, v73.MouseLeave } do
		v78:Connect(function()
			-- upvalues: (ref) v_u_4, (copy) v_u_77
			v_u_4:Create(v_u_77, TweenInfo.new(0.1), {
				["Scale"] = 1
			}):Play()
		end)
	end
	local v_u_79 = v_u_3:WaitForChild(v_u_5.REMOTES):WaitForChild("DuelQueue", 10)
	local v80 = {
		["Name"] = "FindRacer",
		["Text"] = "",
		["AutoButtonColor"] = true,
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_11,
		["AnchorPoint"] = Vector2.new(0.5, 1),
		["Position"] = UDim2.new(0.5, 0, 1, -108),
		["Size"] = UDim2.new(1, -28, 0, 56),
		["Parent"] = v_u_52
	}
	local v81 = v_u_7.new("TextButton", v80)
	v_u_7.corner(v81, 18)
	local v82 = {
		["Rotation"] = 90,
		["Color"] = nil,
		["Parent"] = nil,
		["Color"] = ColorSequence.new(v_u_15, v_u_16),
		["Parent"] = v81
	}
	local v_u_83 = v_u_7.new("UIGradient", v82)
	local v_u_84 = v_u_38(v81, "", 0, 0, nil, 56, 17, v_u_11, true, {
		["TextXAlignment"] = Enum.TextXAlignment.Center,
		["Size"] = UDim2.fromScale(1, 1)
	})
	local function v88() -- name: drawDuel
		-- upvalues: (ref) v_u_20, (copy) v_u_84, (copy) v_u_83, (ref) v_u_15, (ref) v_u_16
		local v85 = v_u_20:GetAttribute("DuelQueue") == true
		v_u_84.Text = v85 and "Looking for a racer\226\128\166  (tap to stop)" or "Find a racer (any server)"
		local v86 = v_u_83
		local v87
		if v85 then
			v87 = ColorSequence.new(Color3.fromRGB(255, 196, 46), Color3.fromRGB(200, 120, 20))
		else
			v87 = ColorSequence.new(v_u_15, v_u_16)
		end
		v86.Color = v87
	end
	v_u_20:GetAttributeChangedSignal("DuelQueue"):Connect(v88)
	v88()
	local v_u_89 = false
	v81.Activated:Connect(function()
		-- upvalues: (ref) v_u_89, (copy) v_u_79, (ref) v_u_1, (ref) v_u_20, (ref) v_u_9
		if not v_u_89 and v_u_79 then
			v_u_89 = true
			local v90 = v_u_1.invoke
			local v91 = v_u_79
			local v92 = v_u_20:GetAttribute("DuelQueue") and "Leave" or "Join"
			local v93, v94, v95 = pcall(v90, v91, v92)
			v_u_89 = false
			if v93 and v95 then
				v_u_9.show(v95, v94 and "ok" or "error")
			end
		end
	end)
	local v_u_96 = 0
	local v_u_97 = false
	v73.Activated:Connect(function()
		-- upvalues: (ref) v_u_97, (ref) v_u_96, (ref) v_u_1, (copy) v_u_49, (ref) v_u_6, (copy) p_u_48, (ref) v_u_9
		if not v_u_97 and os.clock() >= v_u_96 then
			v_u_97 = true
			local v98 = v_u_1.invoke
			local v99 = v_u_49
			local v100, v101, v102 = pcall(v98, v99, "Start")
			v_u_97 = false
			if v100 and v101 then
				v_u_96 = os.clock() + v_u_6.COOLDOWN
				p_u_48()
			end
			if v100 and v102 then
				v_u_9.show(v102, v101 and "ok" or "error")
			end
		end
	end)
	local function v_u_114() -- name: refresh
		-- upvalues: (ref) v_u_20, (ref) v_u_6, (ref) v_u_2, (copy) v_u_61, (copy) v_u_71, (copy) v_u_64, (ref) v_u_18, (ref) v_u_13, (ref) v_u_96, (copy) v_u_75, (copy) v_u_76, (ref) v_u_17
		local v103 = v_u_20.Character
		if v103 then
			v103 = v_u_20.Character:FindFirstChild("HumanoidRootPart")
		end
		local v104 = not v103 and {} or v_u_6.nearby(v_u_2:GetPlayers(), v103.Position, v_u_20, v_u_6.MAX_RACERS - 1)
		v_u_61.Text = #v104 == 0 and "Just you" or ("You + %d %s"):format(#v104, #v104 == 1 and "rider" or "riders")
		v_u_71.Visible = #v104 == 0
		for v105, v106 in v_u_64 do
			local v107 = v104[v105]
			v106.frame.Visible = v107 ~= nil
			if not v107 then
				continue
			end
			v106.name.Text = v107.player.DisplayName
			local v108 = v106.far
			local v109 = v107.riding and "on a ride \194\183 " or "on foot \194\183 "
			local v110 = v107.distance * 0.28 + 0.5
			v108.Text = v109 .. ("%d m"):format((math.floor(v110)))
			local v111 = v106.dot
			local v112
			if v107.riding then
				v112 = v_u_18
			else
				v112 = v_u_13
			end
			v111.BackgroundColor3 = v112
		end
		local v113 = v_u_96 - os.clock()
		if v113 > 0 then
			v_u_75.Color = ColorSequence.new(Color3.fromRGB(190, 194, 204), Color3.fromRGB(150, 154, 166))
			v_u_76.Text = ("Again in %d s"):format((math.ceil(v113)))
		else
			v_u_75.Color = ColorSequence.new(v_u_17, v_u_18)
			v_u_76.Text = "START  3 \194\183 2 \194\183 1"
		end
	end
	local v_u_115 = false
	function v50.show() -- name: show
		-- upvalues: (ref) v_u_115, (copy) v_u_52, (copy) v_u_114, (copy) v_u_53, (ref) v_u_4, (ref) v_u_19
		v_u_115 = true
		v_u_52.Visible = true
		v_u_114()
		v_u_53.Scale = 0.92
		v_u_4:Create(v_u_53, v_u_19, {
			["Scale"] = 1
		}):Play()
	end
	function v50.hide() -- name: hide
		-- upvalues: (ref) v_u_115, (copy) v_u_52
		v_u_115 = false
		v_u_52.Visible = false
	end
	function v50.isShown() -- name: isShown
		-- upvalues: (ref) v_u_115
		return v_u_115
	end
	task.spawn(function()
		-- upvalues: (copy) v_u_52, (ref) v_u_115, (copy) v_u_114
		while v_u_52.Parent do
			task.wait(0.5)
			if not v_u_115 then
				continue
			end
			v_u_114()
		end
	end)
	return v50
end
return v10