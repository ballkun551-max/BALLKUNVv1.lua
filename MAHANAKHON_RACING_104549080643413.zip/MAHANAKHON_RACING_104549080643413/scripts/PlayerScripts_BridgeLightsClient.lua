-- Path: Players/ygggggg55551/PlayerScripts/BridgeLightsClient
-- Class: LocalScript  true/Enum.RunContext.Legacy
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = game:GetService("Lighting")
local v_u_2 = workspace:WaitForChild("Map"):WaitForChild("MemorialBridge", 60)
if v_u_2 then
	v_u_2 = v_u_2:WaitForChild("Lights", 60)
end
if v_u_2 then
	local v_u_3 = nil
	local function v_u_8(p4) -- name: apply
		-- upvalues: (copy) v_u_1, (ref) v_u_3, (copy) v_u_2
		local v5 = v_u_1.ClockTime
		local v6
		if v5 >= 18 or v5 < 6 then
			v6 = not v_u_1:GetAttribute("LowGfx")
		else
			v6 = false
		end
		if v6 ~= v_u_3 or p4 then
			v_u_3 = v6
			for _, v7 in v_u_2:GetDescendants() do
				if not v7:IsA("Light") then
					continue
				end
				v7.Enabled = v6
			end
		end
	end
	v_u_1:GetPropertyChangedSignal("ClockTime"):Connect(function()
		-- upvalues: (copy) v_u_8
		v_u_8(false)
	end)
	v_u_1:GetAttributeChangedSignal("LowGfx"):Connect(function()
		-- upvalues: (copy) v_u_8
		v_u_8(false)
	end)
	v_u_2.DescendantAdded:Connect(function(p9)
		-- upvalues: (copy) v_u_1
		if p9:IsA("Light") then
			local v10 = v_u_1.ClockTime
			local v11
			if v10 >= 18 or v10 < 6 then
				v11 = not v_u_1:GetAttribute("LowGfx")
			else
				v11 = false
			end
			p9.Enabled = v11
		end
	end)
	v_u_8(true)
end