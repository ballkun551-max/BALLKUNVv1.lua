-- Path: ReplicatedStorage/GameUI/Dash
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = require(game:GetService("ReplicatedStorage"):WaitForChild("NetSeal"))
local v_u_2 = game:GetService("Lighting")
local v_u_3 = game:GetService("Players")
local v_u_4 = game:GetService("ReplicatedStorage")
local v_u_5 = game:GetService("TweenService")
local v_u_6 = require(v_u_4:WaitForChild("GameShared"))
local v_u_7 = require(script.Parent:WaitForChild("Theme"))
local v_u_8 = require(script.Parent:WaitForChild("Icons"))
require(script.Parent:WaitForChild("Phone"))
local v_u_9 = require(script.Parent:WaitForChild("ControlLayout"))
local v_u_10 = require(v_u_4:WaitForChild("PCX160Shared"))
local v_u_11 = Color3.fromRGB(60, 220, 90)
local v_u_12 = Color3.fromRGB(230, 60, 50)
local v_u_13 = Color3.fromRGB(16, 18, 24)
local v_u_14 = Color3.fromRGB(255, 255, 255)
local v_u_15 = Color3.fromRGB(56, 170, 80)
local v_u_16 = Color3.fromRGB(120, 255, 130)
local v_u_17 = Color3.fromRGB(220, 50, 46)
local v_u_18 = {
	["horn"] = "horn",
	["lights"] = "light",
	["tail"] = "light",
	["engine"] = "engine",
	["stand"] = "stand",
	["left"] = "left",
	["hazard"] = "hazard",
	["right"] = "right",
	["tuck"] = "side",
	["wheelie"] = "side",
	["view"] = "side",
	["exit"] = "side",
	["rainbow"] = "side",
	["cam360"] = "side",
	["gearDown"] = "gearDown",
	["gearUp"] = "gearUp"
}
local v_u_19 = {
	["tuck"] = "Tuck",
	["wheelie"] = "Wheelie",
	["view"] = "Camera",
	["exit"] = "Get off",
	["phone"] = "Phone",
	["rainbow"] = "RGB",
	["cam360"] = "Dashcam"
}
local v_u_20 = {
	["horn"] = "horn",
	["lights"] = "headlight",
	["tail"] = "headlight",
	["engine"] = "power",
	["stand"] = "parking",
	["left"] = "arrow",
	["hazard"] = "hazard",
	["right"] = "arrow",
	["tuck"] = "tuck",
	["wheelie"] = "wheelie",
	["view"] = "camera",
	["phone"] = "phone",
	["exit"] = "exit",
	["rainbow"] = "bulb",
	["gearDown"] = "arrow",
	["gearUp"] = "arrow",
	["cam360"] = "camera"
}
local v_u_21 = {
	["tuck"] = 0,
	["wheelie"] = 1,
	["view"] = 2,
	["rainbow"] = 3,
	["exit"] = 4,
	["cam360"] = 5
}
local v_u_22 = {
	["horn"] = "\224\185\129\224\184\149\224\184\163",
	["light"] = "\224\185\132\224\184\159\224\184\171\224\184\153\224\185\137\224\184\178",
	["engine"] = "\224\185\128\224\184\132\224\184\163\224\184\183\224\185\136\224\184\173\224\184\135",
	["stand"] = "\224\184\130\224\184\178\224\184\149\224\184\177\224\185\137\224\184\135",
	["gearDown"] = "\224\185\128\224\184\129\224\184\181\224\184\162\224\184\163\224\185\140\224\184\165\224\184\135",
	["gearUp"] = "\224\185\128\224\184\129\224\184\181\224\184\162\224\184\163\224\185\140\224\184\130\224\184\182\224\185\137\224\184\153"
}
local v_u_23 = {
	"tuck",
	"wheelie",
	"view",
	"rainbow",
	"cam360",
	"horn",
	"lights",
	"engine",
	"stand",
	"left",
	"hazard",
	"right",
	"gearDown",
	"gearUp"
}
local v_u_24 = {}
local v_u_25 = nil
local v_u_26 = nil
local v_u_27 = nil
local v_u_28 = nil
local v_u_29 = nil
local v_u_30 = 0
local v_u_31 = nil
local v_u_32 = nil
local function v_u_39(p33, p34, p35, p36, p37) -- name: chip
	-- upvalues: (copy) v_u_7
	local v38 = v_u_7.text({
		["Name"] = nil,
		["Text"] = nil,
		["TextSize"] = 12,
		["FontFace"] = nil,
		["TextColor3"] = nil,
		["BackgroundTransparency"] = 0,
		["BackgroundColor3"] = nil,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = nil,
		["Visible"] = false,
		["Parent"] = nil,
		["Name"] = p34,
		["Text"] = p35,
		["FontFace"] = v_u_7.FONT_BOLD,
		["TextColor3"] = Color3.new(1, 1, 1),
		["BackgroundColor3"] = p36,
		["Size"] = UDim2.fromOffset(0, 18),
		["AutomaticSize"] = Enum.AutomaticSize.X,
		["LayoutOrder"] = p37,
		["Parent"] = p33
	})
	v_u_7.corner(v38, 4)
	v_u_7.new("UIPadding", {
		["PaddingLeft"] = UDim.new(0, 6),
		["PaddingRight"] = UDim.new(0, 6),
		["Parent"] = v38
	})
	return v38
end
local function v_u_67() -- name: build
	-- upvalues: (ref) v_u_25, (copy) v_u_7, (copy) v_u_3, (ref) v_u_31, (ref) v_u_26, (ref) v_u_29, (ref) v_u_27, (ref) v_u_28, (copy) v_u_8, (copy) v_u_39, (copy) v_u_4, (copy) v_u_6, (ref) v_u_32, (copy) v_u_1, (copy) v_u_24, (ref) v_u_30
	v_u_25 = v_u_7.screen("GameDash", 5, v_u_3.LocalPlayer:WaitForChild("PlayerGui"))
	v_u_31 = nil
	v_u_25.Enabled = false
	v_u_26 = v_u_7.new("Frame", {
		["Name"] = "Root",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Parent"] = nil,
		["Size"] = UDim2.fromOffset(260, 150),
		["Parent"] = v_u_25
	})
	v_u_29 = v_u_7.autoScale(v_u_26)
	v_u_27 = v_u_7.panel({
		["Name"] = "Lcd",
		["Size"] = nil,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.06,
		["Parent"] = nil,
		["Size"] = UDim2.fromOffset(260, 150),
		["BackgroundColor3"] = v_u_7.LCD,
		["Parent"] = v_u_26
	})
	v_u_28 = {
		["ticks"] = {}
	}
	for v40 = 1, 20 do
		local v41 = (v40 - 0.5) / 20
		local v42 = v41 * 0.7330382858376184 + -0.3665191429188092
		local v43 = math.sin(v42) * 270 + 130
		local v44 = 301 - math.cos(v42) * 270
		local v45 = v41 * 9 + 6
		v_u_28.ticks[v40] = v_u_7.new("Frame", {
			["Name"] = nil,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Rotation"] = nil,
			["BorderSizePixel"] = 0,
			["BackgroundColor3"] = nil,
			["Parent"] = nil,
			["Name"] = "Tick" .. v40,
			["AnchorPoint"] = Vector2.new(0.5, 1),
			["Position"] = UDim2.fromOffset(v43, v44 + 4),
			["Size"] = UDim2.fromOffset(7, v45),
			["Rotation"] = math.deg(v42),
			["BackgroundColor3"] = v_u_7.LCD_UNLIT,
			["Parent"] = v_u_27
		})
	end
	v_u_28.rpmLabel = v_u_7.text({
		["Text"] = "x1000 rpm",
		["TextSize"] = 10,
		["TextColor3"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["TextColor3"] = v_u_7.TEXT_DIM,
		["Position"] = UDim2.fromOffset(0, 40),
		["Size"] = UDim2.new(1, 0, 0, 12),
		["Parent"] = v_u_27
	})
	v_u_28.left = v_u_8.make("arrow", v_u_7.LCD_UNLIT, 24)
	v_u_28.left.Position = UDim2.fromOffset(10, 8)
	v_u_28.left.Parent = v_u_27
	v_u_28.right = v_u_8.make("arrow", v_u_7.LCD_UNLIT, 24)
	v_u_28.right.Position = UDim2.fromOffset(226, 8)
	v_u_28.right.Rotation = 180
	v_u_28.right.Parent = v_u_27
	local v46 = v_u_28
	local v47 = {
		["Name"] = "Speed",
		["Text"] = "0",
		["TextSize"] = 48,
		["TextXAlignment"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["TextXAlignment"] = Enum.TextXAlignment.Right,
		["Position"] = UDim2.fromOffset(20, 52),
		["Size"] = UDim2.fromOffset(130, 48),
		["Parent"] = v_u_27,
		["FontFace"] = v_u_7.FONT_DIGITS
	}
	v46.speed = v_u_7.text(v47)
	v_u_28.unit = v_u_7.text({
		["Name"] = "Unit",
		["Text"] = "km/h",
		["TextSize"] = 14,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["TextColor3"] = v_u_7.TEXT_DIM,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["Position"] = UDim2.fromOffset(156, 78),
		["Size"] = UDim2.fromOffset(60, 16),
		["Parent"] = v_u_27
	})
	v_u_28.gearBox = v_u_7.new("Frame", {
		["Name"] = "Gear",
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Position"] = UDim2.fromOffset(208, 56),
		["Size"] = UDim2.fromOffset(40, 40),
		["Parent"] = v_u_27
	})
	v_u_7.corner(v_u_28.gearBox, 6)
	v_u_7.border(v_u_28.gearBox, v_u_7.TEXT_DIM, 0.4, 1.5)
	local v48 = v_u_28
	local v49 = {
		["Text"] = "N",
		["TextSize"] = 28,
		["Size"] = nil,
		["Parent"] = nil,
		["Size"] = UDim2.fromScale(1, 1),
		["Parent"] = v_u_28.gearBox,
		["FontFace"] = v_u_7.FONT_DIGITS
	}
	v48.gear = v_u_7.text(v49)
	local v50 = v_u_7.new("Frame", {
		["Name"] = "Chips",
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Position"] = UDim2.fromOffset(12, 104),
		["Size"] = UDim2.new(1, -24, 0, 18),
		["Parent"] = v_u_27
	}, { v_u_7.new("UIListLayout", {
			["FillDirection"] = Enum.FillDirection.Horizontal,
			["Padding"] = UDim.new(0, 6),
			["SortOrder"] = Enum.SortOrder.LayoutOrder
		}) })
	v_u_28.engineChip = v_u_39(v50, "EngineOff", "Engine off  R", v_u_7.RED, 1)
	v_u_28.standChip = v_u_39(v50, "Stand", "Stand", v_u_7.ORANGE, 2)
	v_u_28.lightChip = v_u_39(v50, "Headlight", "Lights", v_u_7.BLUE, 3);
	(function(p51, p52, p53, p54) -- name: small
		-- upvalues: (ref) v_u_7, (ref) v_u_27
		return v_u_7.text({
			["Text"] = nil,
			["TextSize"] = 11,
			["FontFace"] = nil,
			["TextColor3"] = nil,
			["TextXAlignment"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["Text"] = p51,
			["FontFace"] = v_u_7.FONT_BOLD,
			["TextColor3"] = v_u_7.TEXT_DIM,
			["TextXAlignment"] = p54 or Enum.TextXAlignment.Left,
			["Position"] = UDim2.fromOffset(p52, 128),
			["Size"] = UDim2.fromOffset(p53, 14),
			["Parent"] = v_u_27
		})
	end)("ODO", 12, 30)
	local v55 = v_u_28
	local v56 = {
		["Text"] = "000,000",
		["TextSize"] = 14,
		["TextXAlignment"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["Position"] = UDim2.fromOffset(40, 127),
		["Size"] = UDim2.fromOffset(64, 16),
		["Parent"] = v_u_27,
		["FontFace"] = v_u_7.FONT_DIGITS
	}
	v55.odo = v_u_7.text(v56)
	v_u_28.trip = v_u_7.text({
		["ClassName"] = "TextButton",
		["Name"] = "Trip",
		["Text"] = "",
		["AutoButtonColor"] = false,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Position"] = UDim2.fromOffset(108, 124),
		["Size"] = UDim2.fromOffset(88, 22),
		["Parent"] = v_u_27
	})
	v_u_7.text({
		["Text"] = "TRIP",
		["TextSize"] = 11,
		["FontFace"] = nil,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["FontFace"] = v_u_7.FONT_BOLD,
		["TextColor3"] = v_u_7.TEXT_DIM,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["Position"] = UDim2.fromOffset(4, 4),
		["Size"] = UDim2.fromOffset(30, 14),
		["Parent"] = v_u_28.trip
	})
	local v57 = v_u_28
	local v58 = {
		["Text"] = "0.0",
		["TextSize"] = 14,
		["TextXAlignment"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["Position"] = UDim2.fromOffset(36, 3),
		["Size"] = UDim2.fromOffset(50, 16),
		["Parent"] = v_u_28.trip,
		["FontFace"] = v_u_7.FONT_DIGITS
	}
	v57.tripValue = v_u_7.text(v58)
	v_u_28.trip.Activated:Connect(function()
		-- upvalues: (ref) v_u_4, (ref) v_u_6, (ref) v_u_32, (ref) v_u_3, (ref) v_u_1
		local v_u_59 = v_u_4:FindFirstChild(v_u_6.REMOTES)
		if v_u_59 then
			v_u_59 = v_u_59:FindFirstChild("Garage")
		end
		if v_u_59 and (v_u_32 and (v_u_32.model and v_u_32.model:GetAttribute("OwnerUserId") == v_u_3.LocalPlayer.UserId)) then
			task.spawn(function()
				-- upvalues: (ref) v_u_1, (copy) v_u_59
				local v60 = v_u_1.invoke
				local v61 = v_u_59
				pcall(v60, v61, "ResetTrip")
			end)
		end
	end)
	local v62 = v_u_28
	local v63 = {
		["Text"] = "12:00",
		["TextSize"] = 14,
		["TextXAlignment"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["TextXAlignment"] = Enum.TextXAlignment.Right,
		["Position"] = UDim2.fromOffset(188, 127),
		["Size"] = UDim2.fromOffset(60, 16),
		["Parent"] = v_u_27,
		["FontFace"] = v_u_7.FONT_DIGITS
	}
	v62.clock = v_u_7.text(v63)
	v_u_28.legend = v_u_7.new("Frame", {
		["Name"] = "Legend",
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(1, 1),
		["Position"] = UDim2.new(1, 0, 0, -8),
		["Size"] = UDim2.fromOffset(330, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y,
		["Parent"] = v_u_26
	}, { v_u_7.new("UIListLayout", {
			["FillDirection"] = nil,
			["HorizontalAlignment"] = nil,
			["VerticalAlignment"] = nil,
			["Wraps"] = true,
			["Padding"] = nil,
			["SortOrder"] = nil,
			["FillDirection"] = Enum.FillDirection.Horizontal,
			["HorizontalAlignment"] = Enum.HorizontalAlignment.Right,
			["VerticalAlignment"] = Enum.VerticalAlignment.Bottom,
			["Padding"] = UDim.new(0, 10),
			["SortOrder"] = Enum.SortOrder.LayoutOrder
		}) })
	v_u_27.MouseEnter:Connect(function()
		-- upvalues: (ref) v_u_32
		if v_u_32 then
			local v64 = v_u_32
			local v65 = v_u_32.legendUntil
			local v66 = os.clock() + 4
			v64.legendUntil = math.max(v65, v66)
		end
	end)
	v_u_29:GetPropertyChangedSignal("Scale"):Connect(function()
		-- upvalues: (ref) v_u_24, (ref) v_u_30
		v_u_24.liftKeys(v_u_30)
	end)
	v_u_24.liftKeys(v_u_30)
end
local function v_u_73(p68, p69, p70) -- name: legendItem
	-- upvalues: (copy) v_u_7, (ref) v_u_28
	local v71 = v_u_7.new("Frame", {
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = nil,
		["Parent"] = nil,
		["Size"] = UDim2.fromOffset(0, 20),
		["AutomaticSize"] = Enum.AutomaticSize.X,
		["LayoutOrder"] = p70,
		["Parent"] = v_u_28.legend
	}, { v_u_7.new("UIListLayout", {
			["FillDirection"] = Enum.FillDirection.Horizontal,
			["VerticalAlignment"] = Enum.VerticalAlignment.Center,
			["Padding"] = UDim.new(0, 5),
			["SortOrder"] = Enum.SortOrder.LayoutOrder
		}) })
	local v72 = v_u_7.text({
		["Text"] = nil,
		["TextSize"] = 12,
		["FontFace"] = nil,
		["BackgroundTransparency"] = 0.25,
		["BackgroundColor3"] = nil,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = 1,
		["Parent"] = nil,
		["Text"] = p68,
		["FontFace"] = v_u_7.FONT_BOLD,
		["BackgroundColor3"] = v_u_7.PANEL,
		["Size"] = UDim2.fromOffset(0, 20),
		["AutomaticSize"] = Enum.AutomaticSize.X,
		["Parent"] = v71
	})
	v72:SetAttribute("KeyBox", true)
	v_u_7.corner(v72, 4)
	v_u_7.border(v72, v_u_7.BORDER, 0.55, 1)
	v_u_7.new("UIPadding", {
		["PaddingLeft"] = UDim.new(0, 6),
		["PaddingRight"] = UDim.new(0, 6),
		["Parent"] = v72
	})
	v_u_7.text({
		["Text"] = nil,
		["TextSize"] = 13,
		["TextStrokeTransparency"] = 0.6,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = 2,
		["Parent"] = nil,
		["Text"] = p69,
		["Size"] = UDim2.fromOffset(0, 20),
		["AutomaticSize"] = Enum.AutomaticSize.X,
		["Parent"] = v71
	})
end
local function v_u_101() -- name: buildTouch
	-- upvalues: (copy) v_u_7, (ref) v_u_25, (ref) v_u_31, (copy) v_u_13, (copy) v_u_14, (copy) v_u_22, (copy) v_u_9
	local v74 = v_u_7.driveArea(v_u_25)
	v_u_31 = {
		["area"] = v74,
		["slots"] = {},
		["side"] = v_u_7.new("Frame", {
			["Name"] = "Side",
			["BackgroundTransparency"] = 1,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0, 1),
			["Position"] = UDim2.new(0, 0, 1, -140),
			["Size"] = UDim2.fromOffset(v_u_7.DRIVE_SIDE_W, 0),
			["Parent"] = v74
		})
	}
	local v_u_75 = v_u_7.new("Frame", {
		["Name"] = "Center",
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 1),
		["Position"] = UDim2.new(0.5, 0, 1, -5),
		["Size"] = UDim2.fromOffset(258, 96),
		["Parent"] = v74
	})
	local function v82(p76, p77, p78, p79, p80) -- name: face
		-- upvalues: (ref) v_u_7, (ref) v_u_13, (copy) v_u_75
		local v81 = v_u_7.new("Frame", {
			["Name"] = nil,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.32,
			["BorderSizePixel"] = 0,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["Name"] = p76,
			["BackgroundColor3"] = v_u_13,
			["Position"] = UDim2.fromOffset(p77, p78),
			["Size"] = UDim2.fromOffset(p79, 45),
			["Parent"] = p80 or v_u_75
		})
		v_u_7.corner(v81, 12)
		v_u_7.new("UIStroke", {
			["ApplyStrokeMode"] = nil,
			["Color"] = nil,
			["Transparency"] = 0.8,
			["Thickness"] = 1,
			["Parent"] = nil,
			["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
			["Color"] = Color3.new(1, 1, 1),
			["Parent"] = v81
		})
		return v81
	end
	local function v88(p83, p84, p85, p86, p87) -- name: slot
		-- upvalues: (ref) v_u_31, (ref) v_u_7, (copy) v_u_75
		v_u_31.slots[p83] = v_u_7.new("Frame", {
			["Name"] = nil,
			["BackgroundTransparency"] = 1,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["Name"] = p83,
			["Position"] = UDim2.fromOffset(p84, p85),
			["Size"] = UDim2.fromOffset(p86 or 50, 45),
			["Parent"] = p87 or v_u_75
		})
	end
	v88("horn", 0, 0)
	v88("light", 208, 0)
	v88("engine", 0, 51)
	v88("stand", 208, 51)
	for v89, v90 in {
		["gearDown"] = -54,
		["gearUp"] = 262
	} do
		v88(v89, v90, 0)
		v_u_31.slots[v89].Size = UDim2.fromOffset(50, 96)
	end
	local v91 = v82("Speed", 54, 0, 150)
	local v92 = v_u_31
	local v93 = {
		["Text"] = "0",
		["TextSize"] = 25,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["TextColor3"] = v_u_14,
		["TextXAlignment"] = Enum.TextXAlignment.Right,
		["Position"] = UDim2.fromOffset(4, 0),
		["Size"] = UDim2.fromOffset(58, 45),
		["Parent"] = v91,
		["FontFace"] = v_u_7.FONT_DIGITS
	}
	v92.speed = v_u_7.text(v93)
	v_u_31.unit = v_u_7.text({
		["Text"] = "km/h",
		["TextSize"] = 18,
		["FontFace"] = nil,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["FontFace"] = v_u_7.FONT_BOLD,
		["TextColor3"] = v_u_14,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["Position"] = UDim2.fromOffset(76, 0),
		["Size"] = UDim2.fromOffset(70, 45),
		["Parent"] = v91
	})
	v_u_31.gearChip = v_u_7.new("Frame", {
		["Name"] = "Gear",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Visible"] = false,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_7.ACCENT,
		["AnchorPoint"] = Vector2.new(0, 0.5),
		["Position"] = UDim2.new(0, 6, 0.5, 0),
		["Size"] = UDim2.fromOffset(32, 33),
		["Parent"] = v91
	})
	v_u_7.corner(v_u_31.gearChip, 8)
	local v94 = v_u_31
	local v95 = {
		["Text"] = "N",
		["TextSize"] = 22,
		["TextColor3"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["TextColor3"] = v_u_7.DARK_TEXT,
		["Size"] = UDim2.fromScale(1, 1),
		["Parent"] = v_u_31.gearChip,
		["FontFace"] = v_u_7.FONT_DIGITS
	}
	v94.gear = v_u_7.text(v95)
	local v96 = v82("Signals", 54, 51, 150)
	for v97, v98 in { "left", "hazard", "right" } do
		v88(v98, (v97 - 1) * 150 / 3, 0, 50, v96)
	end
	for v99, v100 in v_u_22 do
		v_u_9.register("dash." .. v99, v_u_31.slots[v99], v100, true)
	end
	v_u_9.register("dash.speed", v91, "\224\184\132\224\184\167\224\184\178\224\184\161\224\185\128\224\184\163\224\185\135\224\184\167")
	v_u_9.register("dash.signals", v96, "\224\185\132\224\184\159\224\185\128\224\184\165\224\184\181\224\185\137\224\184\162\224\184\167")
end
local function v_u_117() -- name: layoutSide
	-- upvalues: (ref) v_u_31, (copy) v_u_7, (copy) v_u_9, (copy) v_u_19
	local v102 = {}
	for _, v103 in v_u_31.side:GetChildren() do
		if not v103:IsA("GuiButton") then
			continue
		end
		table.insert(v102, v103)
	end
	table.sort(v102, function(p104, p105)
		return p104.LayoutOrder < p105.LayoutOrder
	end)
	local v106 = #v102 / 2
	local v107 = math.ceil(v106)
	local v108 = v_u_31.side
	local v109 = UDim2.fromOffset
	local v110 = v_u_7.DRIVE_SIDE_W
	local v111 = v107 * 58 + (v107 - 1) * 4
	v108.Size = v109(v110, (math.max(0, v111)))
	for v112, v113 in v102 do
		local v114 = UDim2.fromOffset
		local v115 = (v112 - 1) % 2 * 62
		local v116 = (v112 - 1) / 2
		v113.Position = v114(v115, math.floor(v116) * 62)
		v_u_9.register("side." .. v113.Name, v113, v_u_19[v113.Name] or v113.Name)
	end
end
local function v_u_122(p118, p_u_119) -- name: wire
	if p_u_119.hold then
		p118.InputBegan:Connect(function(p120)
			-- upvalues: (copy) p_u_119
			if p120.UserInputType == Enum.UserInputType.Touch or p120.UserInputType == Enum.UserInputType.MouseButton1 then
				p_u_119.press()
			end
		end)
		p118.InputEnded:Connect(function(p121)
			-- upvalues: (copy) p_u_119
			if (p121.UserInputType == Enum.UserInputType.Touch or p121.UserInputType == Enum.UserInputType.MouseButton1) and p_u_119.release then
				p_u_119.release()
			end
		end)
	else
		p118.Activated:Connect(function()
			-- upvalues: (copy) p_u_119
			p_u_119.press()
		end)
	end
end
local function v_u_136(p123) -- name: touchButton
	-- upvalues: (copy) v_u_18, (copy) v_u_7, (copy) v_u_13, (copy) v_u_21, (ref) v_u_31, (copy) v_u_15, (copy) v_u_17, (copy) v_u_14, (copy) v_u_8, (copy) v_u_20, (copy) v_u_19, (copy) v_u_122, (ref) v_u_32
	local v124 = v_u_18[p123.id]
	if v124 then
		local v125 = v124 == "side"
		local v126 = (v124 == "left" or v124 == "hazard") and true or v124 == "right"
		local v127 = v126 and 1 or 0.32
		local v128 = v_u_7.new
		local v129 = "TextButton"
		local v130 = {
			["Name"] = nil,
			["Text"] = "",
			["AutoButtonColor"] = false,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["LayoutOrder"] = nil,
			["Parent"] = nil,
			["Name"] = p123.id,
			["BackgroundColor3"] = v_u_13,
			["BackgroundTransparency"] = v127
		}
		local v131
		if v125 then
			v131 = UDim2.fromOffset(58, 58)
		else
			v131 = UDim2.fromScale(1, 1)
		end
		v130.Size = v131
		v130.LayoutOrder = v_u_21[p123.id] or 0
		local v132
		if v125 then
			v132 = v_u_31.side
		else
			v132 = v_u_31.slots[v124]
		end
		v130.Parent = v132
		local v133 = v128(v129, v130)
		v_u_7.corner(v133, v125 and 29 or 12)
		if not v126 then
			v_u_7.new("UIStroke", {
				["ApplyStrokeMode"] = nil,
				["Color"] = nil,
				["Transparency"] = 0.8,
				["Thickness"] = 1,
				["Parent"] = nil,
				["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
				["Color"] = Color3.new(1, 1, 1),
				["Parent"] = v133
			})
		end
		local v134
		if p123.id == "left" or p123.id == "right" then
			v134 = v_u_15
		elseif p123.id == "hazard" then
			v134 = v_u_17
		else
			v134 = v_u_14
		end
		local v135 = v_u_8.make(v_u_20[p123.id], v134, v125 and 26 or 24)
		v135.AnchorPoint = Vector2.new(0.5, 0.5)
		v135.Position = UDim2.fromScale(0.5, 0.5)
		if v125 and v_u_19[p123.id] then
			v135.Position = UDim2.new(0.5, 0, 0.5, -8)
			v_u_7.text({
				["Text"] = nil,
				["TextSize"] = 15,
				["FontFace"] = nil,
				["TextColor3"] = nil,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["Text"] = v_u_19[p123.id],
				["FontFace"] = v_u_7.FONT_BOLD,
				["TextColor3"] = v_u_14,
				["AnchorPoint"] = Vector2.new(0.5, 1),
				["Position"] = UDim2.new(0.5, 0, 1, -3),
				["Size"] = UDim2.new(1, 0, 0, 17),
				["Parent"] = v133
			})
		end
		if p123.id == "right" then
			v135.Rotation = 180
		elseif p123.id == "gearUp" or p123.id == "gearDown" then
			v135.Rotation = p123.id == "gearUp" and 90 or -90
			v135.Position = UDim2.new(0.5, 0, 0.5, -8)
			v_u_7.text({
				["Text"] = nil,
				["TextSize"] = 14,
				["FontFace"] = nil,
				["TextColor3"] = nil,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["Text"] = p123.id == "gearUp" and "G+" or "G-",
				["FontFace"] = v_u_7.FONT_BOLD,
				["TextColor3"] = v_u_14,
				["AnchorPoint"] = Vector2.new(0.5, 1),
				["Position"] = UDim2.new(0.5, 0, 1, -6),
				["Size"] = UDim2.new(1, 0, 0, 16),
				["Parent"] = v133
			})
		end
		v135.Parent = v133
		v_u_122(v133, p123)
		v_u_32.buttons[p123.id] = {
			["button"] = nil,
			["touch"] = true,
			["idle"] = nil,
			["icon"] = nil,
			["button"] = v133,
			["idle"] = v127,
			["icon"] = v135
		}
	end
end
local function v_u_162(p137) -- name: buildControls
	-- upvalues: (ref) v_u_28, (ref) v_u_32, (copy) v_u_7, (copy) v_u_73, (ref) v_u_31, (copy) v_u_101, (copy) v_u_3, (copy) v_u_4, (copy) v_u_136, (copy) v_u_117
	for _, v138 in v_u_28.legend:GetChildren() do
		if not v138:IsA("GuiObject") then
			continue
		end
		v138:Destroy()
	end
	v_u_32.buttons = {}
	local v139 = v_u_7.isTouch()
	v_u_28.legend.Visible = not v139
	if v139 then
		if not v_u_31 then
			v_u_101()
		end
		local v140 = { v_u_31.side }
		for _, v141 in v_u_31.slots do
			table.insert(v140, v141)
		end
		for _, v142 in v140 do
			for _, v143 in v142:GetChildren() do
				if not v143:IsA("GuiObject") then
					continue
				end
				v143:Destroy()
			end
		end
		local v144 = table.clone(p137.controls or {})
		local v146 = {
			["id"] = "exit",
			["label"] = "Get off",
			["slot"] = "left",
			["order"] = 99,
			["press"] = nil,
			["press"] = function() -- name: press
				-- upvalues: (ref) v_u_3
				local v145 = v_u_3.LocalPlayer.Character
				if v145 then
					v145 = v145:FindFirstChildOfClass("Humanoid")
				end
				if v145 then
					v145.Jump = true
				end
			end
		}
		table.insert(v144, v146)
		local v147 = false
		for _, v148 in v144 do
			v147 = v147 or v148.id == "cam360"
		end
		if not v147 then
			local v154 = {
				["id"] = "cam360",
				["label"] = "Dashcam",
				["press"] = nil,
				["press"] = function() -- name: press
					-- upvalues: (ref) v_u_32, (ref) v_u_4
					local v149 = v_u_32
					if v149 then
						v149 = v_u_32.model
					end
					if v149 then
						local v150 = require
						local v151 = v_u_4
						local v152, v153 = pcall(v150, v151:WaitForChild("DashcamView"))
						if v152 then
							v153.toggle(v149)
						end
					end
				end
			}
			table.insert(v144, v154)
		end
		for _, v155 in v144 do
			v_u_136(v155)
		end
		v_u_117()
		local v156 = v_u_32.buttons.cam360
		if v156 and v_u_32.model then
			local v157 = v156.button
			local v158 = v_u_32.model
			local v159
			if v158 == nil then
				v159 = false
			else
				v159 = type(v158:GetAttribute("CamParts")) == "string" and true or v158:GetAttribute("Cam360") ~= nil
			end
			v157.Visible = v159
		end
	else
		for v160, v161 in p137.legend or {} do
			v_u_73(v161[1], v161[2], v160)
		end
	end
end
local function v_u_163() -- name: place
	-- upvalues: (ref) v_u_26, (copy) v_u_7
	v_u_26.Visible = not v_u_7.isTouch()
	if not v_u_7.isTouch() then
		v_u_26.AnchorPoint = Vector2.new(1, 1)
		v_u_26.Position = UDim2.new(1, -v_u_7.EDGE, 1, -v_u_7.EDGE)
	end
end
function v_u_24.show(p164, p165) -- name: show
	-- upvalues: (ref) v_u_25, (copy) v_u_67, (ref) v_u_32, (ref) v_u_28, (copy) v_u_162, (ref) v_u_31, (copy) v_u_163
	if not (v_u_25 and v_u_25.Parent) then
		v_u_67()
	end
	local v166 = p165 or {}
	v_u_32 = {
		["model"] = nil,
		["options"] = nil,
		["buttons"] = nil,
		["blinkMode"] = "Off",
		["blinkStart"] = nil,
		["legendUntil"] = nil,
		["model"] = p164,
		["options"] = v166,
		["buttons"] = {},
		["blinkStart"] = os.clock(),
		["legendUntil"] = os.clock() + 10
	}
	v_u_28.gearBox.Visible = v166.gear == true
	v_u_28.speed.Position = UDim2.fromOffset(v166.gear and 4 or 20, 52)
	v_u_28.unit.Position = UDim2.fromOffset(v166.gear and 140 or 156, 78)
	v_u_162(v166)
	if v_u_31 and v_u_31.gearChip then
		local v167 = v166.gear == true
		v_u_31.gearChip.Visible = v167
		v_u_31.speed.Position = UDim2.fromOffset(v167 and 40 or 4, 0)
		v_u_31.speed.Size = UDim2.fromOffset(v167 and 52 or 58, 45)
		v_u_31.unit.Position = UDim2.fromOffset(v167 and 96 or 76, 0)
		v_u_31.unit.TextSize = v167 and 15 or 18
	end
	v_u_163()
	v_u_25.Enabled = true
end
function v_u_24.setLegend(p168) -- name: setLegend
	-- upvalues: (ref) v_u_32, (copy) v_u_7, (ref) v_u_28, (copy) v_u_73
	if v_u_32 and not v_u_7.isTouch() then
		v_u_32.options.legend = p168
		for _, v169 in v_u_28.legend:GetChildren() do
			if not v169:IsA("GuiObject") then
				continue
			end
			v169:Destroy()
		end
		for v170, v171 in p168 do
			v_u_73(v171[1], v171[2], v170)
		end
		local v172 = v_u_32
		local v173 = v_u_32.legendUntil
		local v174 = os.clock() + 10
		v172.legendUntil = math.max(v173, v174)
		v_u_32.legendShown = nil
	end
end
function v_u_24.hide() -- name: hide
	-- upvalues: (ref) v_u_32, (ref) v_u_25
	v_u_32 = nil
	if v_u_25 then
		v_u_25.Enabled = false
	end
end
function v_u_24.isShown() -- name: isShown
	-- upvalues: (ref) v_u_32
	return v_u_32 ~= nil
end
function v_u_24.frame() -- name: frame
	-- upvalues: (ref) v_u_32, (ref) v_u_26
	if v_u_32 and (v_u_26 and v_u_26.Visible) then
		return v_u_26
	else
		return nil
	end
end
function v_u_24.liftKeys(p175) -- name: liftKeys
	-- upvalues: (ref) v_u_30, (ref) v_u_28, (ref) v_u_29
	v_u_30 = p175 or 0
	if v_u_28 and v_u_28.legend then
		local v176 = not v_u_29 and 1 or v_u_29.Scale
		v_u_28.legend.Position = UDim2.new(1, 0, 0, -8 - v_u_30 / math.max(v176, 0.01))
	end
end
function v_u_24.setActive(p177, p178) -- name: setActive
	-- upvalues: (ref) v_u_32, (copy) v_u_7, (copy) v_u_13
	local v179 = v_u_32
	if v179 then
		v179 = v_u_32.buttons[p177]
	end
	if v179 and v179.touch then
		local v180 = v179.button
		local v181
		if p178 then
			v181 = v_u_7.YELLOW
		else
			v181 = v_u_13
		end
		v180.BackgroundColor3 = v181
		v179.button.BackgroundTransparency = p178 and 0.15 or v179.idle
	elseif v179 then
		local v182 = v179.button
		local v183
		if p178 then
			v183 = v_u_7.YELLOW
		else
			v183 = v_u_7.PANEL
		end
		v182.BackgroundColor3 = v183
		local v184 = v179.button
		local v185
		if p178 then
			v185 = v_u_7.PANEL
		else
			v185 = v_u_7.TEXT
		end
		v184.TextColor3 = v185
	end
end
local function v_u_188(p186) -- name: blinkLit
	-- upvalues: (ref) v_u_32, (copy) v_u_10
	if p186 == "Off" or p186 == nil then
		v_u_32.blinkMode = "Off"
		return false
	else
		local v187
		if v_u_32.model == nil then
			v187 = false
		else
			v187 = v_u_32.model:GetAttribute("BlinkRate") ~= nil
		end
		if v_u_32.options.blinkFromChange then
			if v_u_32.blinkMode ~= p186 then
				v_u_32.blinkMode = p186
				v_u_32.blinkStart = os.clock()
			end
			if v187 then
				return v_u_10.blinkAt(v_u_32.model, os.clock() - v_u_32.blinkStart)
			else
				return (os.clock() - v_u_32.blinkStart) % 0.7 < 0.38
			end
		elseif v187 then
			return v_u_10.blinkAt(v_u_32.model, workspace:GetServerTimeNow())
		else
			return workspace:GetServerTimeNow() % 0.7 < 0.38
		end
	end
end
function v_u_24.update(p189) -- name: update
	-- upvalues: (ref) v_u_32, (copy) v_u_2, (copy) v_u_7, (ref) v_u_28, (copy) v_u_12, (copy) v_u_188, (copy) v_u_8, (copy) v_u_11, (ref) v_u_31, (copy) v_u_16, (copy) v_u_15, (copy) v_u_5
	if v_u_32 then
		local v190 = v_u_32.buttons.cam360
		if v190 and (v190.touch and v_u_32.model) then
			local v191 = v_u_32.model
			local v192
			if v191 == nil then
				v192 = false
			else
				v192 = type(v191:GetAttribute("CamParts")) == "string" and true or v191:GetAttribute("Cam360") ~= nil
			end
			if v190.button.Visible ~= v192 then
				v190.button.Visible = v192
			end
		end
		local v193 = v_u_2.ClockTime
		local v194
		if v193 >= 18.3 and true or v193 < 6.2 then
			v194 = v_u_7.NIGHT_TEXT
		else
			v194 = v_u_7.TEXT
		end
		local v195 = v_u_28.speed
		local v196 = p189.kmh or 0
		local v197 = math.abs(v196) + 0.5
		local v198 = math.floor(v197)
		v195.Text = tostring(v198)
		v_u_28.speed.TextColor3 = v194
		v_u_28.gear.Text = p189.gear or "N"
		v_u_28.gear.TextColor3 = v194
		local v199 = p189.rpm or 0
		local v200 = math.clamp(v199, 0, 1) * 20 + 0.5
		local v201 = math.floor(v200)
		for v202, v203 in v_u_28.ticks do
			if v202 <= v201 then
				local v204
				if v202 / 20 > 0.8 then
					v204 = v_u_12
				else
					v204 = v_u_7.YELLOW
				end
				v203.BackgroundColor3 = v204
			else
				v203.BackgroundColor3 = v_u_7.LCD_UNLIT
			end
		end
		local v205 = v_u_188(p189.indicator)
		local v206
		if v205 then
			v206 = p189.indicator == "Left" and true or p189.indicator == "Hazard"
		else
			v206 = v205
		end
		if v205 then
			v205 = p189.indicator == "Right" and true or p189.indicator == "Hazard"
		end
		local v207 = v_u_8.tint
		local v208 = v_u_28.left
		local v209
		if v206 then
			v209 = v_u_11
		else
			v209 = v_u_7.LCD_UNLIT
		end
		v207(v208, v209)
		local v210 = v_u_8.tint
		local v211 = v_u_28.right
		local v212
		if v205 then
			v212 = v_u_11
		else
			v212 = v_u_7.LCD_UNLIT
		end
		v210(v211, v212)
		if v_u_31 and v_u_7.isTouch() then
			v_u_31.speed.Text = v_u_28.speed.Text
			if v_u_31.gear then
				local v213 = p189.gear or "N"
				local v214 = tostring(v213)
				if v_u_31.gear.Text ~= v214 then
					v_u_31.gear.Text = v214
				end
			end
			for v215, v216 in {
				["left"] = v206,
				["right"] = v205
			} do
				local v217 = v_u_32.buttons[v215]
				if not v217 then
					continue
				end
				local v218 = v_u_8.tint
				local v219 = v217.icon
				local v220
				if v216 then
					v220 = v_u_16
				else
					v220 = v_u_15
				end
				v218(v219, v220)
			end
		end
		v_u_28.engineChip.Visible = p189.engine == false
		v_u_28.standChip.Visible = p189.stand == true
		v_u_28.lightChip.Visible = p189.lights == true
		local v221 = v_u_32.model
		local v222 = v_u_28.odo
		local v223 = v221 and (v221:GetAttribute("OdoKm") or 0) or 0
		local v224 = math.floor(v223)
		local v225 = string.format("%06d", (math.min(v224, 999999)))
		v222.Text = v225:sub(1, 3) .. "," .. v225:sub(4)
		v_u_28.odo.TextColor3 = v194
		v_u_28.tripValue.Text = string.format("%.1f", v221 and v221:GetAttribute("TripKm") or 0)
		v_u_28.tripValue.TextColor3 = v194
		local v226 = math.floor(v193) % 24
		local v227 = v_u_28.clock
		local v228 = string.format
		local v229 = v193 % 1 * 60
		v227.Text = v228("%02d:%02d", v226, (math.floor(v229)))
		v_u_28.clock.TextColor3 = v194
		local v230 = os.clock() < v_u_32.legendUntil
		if v_u_28.legend.Visible and v230 ~= v_u_32.legendShown then
			v_u_32.legendShown = v230
			for _, v231 in v_u_28.legend:GetDescendants() do
				if v231:IsA("TextLabel") then
					local v232 = v231:GetAttribute("KeyBox") == true
					v_u_5:Create(v231, v_u_7.FADE, {
						["TextTransparency"] = v230 and 0 or 1,
						["TextStrokeTransparency"] = v230 and not v232 and 0.6 or 1,
						["BackgroundTransparency"] = v230 and v232 and 0.25 or 1
					}):Play()
				else
					if not v231:IsA("UIStroke") then
						continue
					end
					v_u_5:Create(v231, v_u_7.FADE, {
						["Transparency"] = v230 and 0.55 or 1
					}):Play()
				end
			end
		end
	end
end
v_u_9.changed.Event:Connect(function(p233)
	-- upvalues: (copy) v_u_7, (ref) v_u_32, (copy) v_u_23, (copy) v_u_24
	if v_u_7.isTouch() then
		if p233 and not v_u_32 then
			local v234 = {}
			for _, v235 in v_u_23 do
				table.insert(v234, {
					["id"] = v235,
					["label"] = v235,
					["press"] = function() -- name: press end
				})
			end
			v_u_24.show(nil, {
				["gear"] = true,
				["controls"] = nil,
				["controls"] = v234
			})
			v_u_32.preview = true
		elseif not p233 and (v_u_32 and v_u_32.preview) then
			v_u_24.hide()
		end
	else
		return
	end
end)
return v_u_24