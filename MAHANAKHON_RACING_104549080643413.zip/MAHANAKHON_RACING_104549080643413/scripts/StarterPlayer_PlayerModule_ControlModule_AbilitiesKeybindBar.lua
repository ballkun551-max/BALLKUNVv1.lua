-- Path: StarterPlayer/PlayerModule/ControlModule/AbilitiesKeybindBar
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = game:GetService("UserInputService")
local v2 = require(script.Parent.Parent:WaitForChild("CommonUtils"))
local v_u_3 = require(script.Parent:WaitForChild("InputSlots"))
local v_u_4 = v2.get("ConnectionUtil")
local v_u_5 = Enum.KeyCode.DPadUp
local v_u_6 = Enum.KeyCode.M
local v_u_7 = Color3.fromRGB(18, 18, 21)
local v_u_8 = Enum.Font.BuilderSans
local v_u_9 = Color3.fromRGB(247, 247, 248)
local v_u_10 = Enum.Font.BuilderSansBold
local v_u_11 = Color3.fromRGB(247, 247, 248)
local v_u_12 = Color3.fromRGB(18, 18, 21)
local v_u_13 = {}
for _, v14 in {
	Enum.KeyCode.ButtonA,
	Enum.KeyCode.ButtonB,
	Enum.KeyCode.ButtonX,
	Enum.KeyCode.ButtonY,
	Enum.KeyCode.ButtonL1,
	Enum.KeyCode.ButtonR1,
	Enum.KeyCode.ButtonL2,
	Enum.KeyCode.ButtonR2,
	Enum.KeyCode.ButtonL3,
	Enum.KeyCode.ButtonR3,
	Enum.KeyCode.ButtonStart,
	Enum.KeyCode.ButtonSelect,
	Enum.KeyCode.DPadLeft,
	Enum.KeyCode.DPadRight,
	Enum.KeyCode.DPadUp,
	Enum.KeyCode.DPadDown,
	Enum.KeyCode.Thumbstick1,
	Enum.KeyCode.Thumbstick2
} do
	v_u_13[v14] = true
end
local v_u_15 = {
	[Enum.KeyCode.ButtonCenter] = true,
	[Enum.KeyCode.ButtonUp] = true,
	[Enum.KeyCode.ButtonDown] = true,
	[Enum.KeyCode.ButtonLeft] = true,
	[Enum.KeyCode.ButtonRight] = true
}
local function v_u_20(p16) -- name: actionKeyCode
	-- upvalues: (copy) v_u_1, (copy) v_u_13, (copy) v_u_15
	for _, v17 in p16:GetChildren() do
		if not v17:IsA("InputBinding") then
			continue
		end
		local v18 = v17.KeyCode
		local v19
		if v_u_1.PreferredInput == Enum.PreferredInput.Gamepad then
			v19 = v_u_13[v18] == true
		else
			v19 = v18 ~= Enum.KeyCode.None and not v_u_13[v18]
			if v19 then
				v19 = not v_u_15[v18]
			end
		end
		if not v19 then
			continue
		end
		return v18
	end
	return nil
end
local function v_u_27(p21, p22, p23) -- name: createEntryFrame
	local v24 = Instance.new("Frame")
	v24.Name = p22
	v24.LayoutOrder = p23
	v24.Size = UDim2.new(0, 0, 0, 28)
	v24.AutomaticSize = Enum.AutomaticSize.X
	v24.BackgroundTransparency = 1
	v24.BorderSizePixel = 0
	v24.Parent = p21
	local v25 = Instance.new("UIPadding")
	v25.PaddingRight = UDim.new(0, 8)
	v25.Parent = v24
	local v26 = Instance.new("UIListLayout")
	v26.FillDirection = Enum.FillDirection.Horizontal
	v26.VerticalAlignment = Enum.VerticalAlignment.Center
	v26.SortOrder = Enum.SortOrder.LayoutOrder
	v26.Padding = UDim.new(0, 4)
	v26.Parent = v24
	return v24
end
local function v_u_38(p28, p29, p30) -- name: createKeyIndicator
	-- upvalues: (copy) v_u_1, (copy) v_u_11, (copy) v_u_10, (copy) v_u_12
	if p29 and v_u_1.PreferredInput == Enum.PreferredInput.Gamepad then
		local v31 = v_u_1:GetImageForKeyCode(p29)
		if v31 ~= "" then
			local v32 = Instance.new("ImageLabel")
			v32.Name = "Key"
			v32.LayoutOrder = p30
			v32.Size = UDim2.new(0, 24, 0, 24)
			v32.BackgroundTransparency = 1
			v32.Image = v31
			v32.Parent = p28
			return
		end
	end
	local v33
	if p29 and p29 ~= Enum.KeyCode.None then
		v33 = v_u_1:GetStringForKeyCode(p29, Enum.KeyCodeStringFormat.Abbreviated)
		if v33:match("^%s*$") then
			v33 = p29.Name
		end
	else
		v33 = "?"
	end
	local v34 = Instance.new("TextLabel")
	v34.Name = "Key"
	v34.LayoutOrder = p30
	v34.AutomaticSize = Enum.AutomaticSize.XY
	v34.Size = UDim2.new(0, 0, 0, 0)
	v34.BackgroundColor3 = v_u_11
	v34.BackgroundTransparency = 0
	v34.BorderSizePixel = 0
	v34.Font = v_u_10
	v34.TextSize = 14
	v34.TextColor3 = v_u_12
	v34.Text = v33
	v34.Parent = p28
	local v35 = Instance.new("UICorner")
	v35.CornerRadius = UDim.new(0, 2)
	v35.Parent = v34
	local v36 = Instance.new("UISizeConstraint")
	v36.MinSize = Vector2.new(10, 10)
	v36.Parent = v34
	local v37 = Instance.new("UIPadding")
	v37.PaddingLeft = UDim.new(0, 5)
	v37.PaddingRight = UDim.new(0, 5)
	v37.PaddingTop = UDim.new(0, 1)
	v37.PaddingBottom = UDim.new(0, 2)
	v37.Parent = v34
end
local function v_u_44(p39, p40, p41) -- name: createLabel
	-- upvalues: (copy) v_u_8, (copy) v_u_9
	local v42 = Instance.new("TextLabel")
	v42.Name = "Label"
	v42.LayoutOrder = p41
	v42.AutomaticSize = Enum.AutomaticSize.X
	v42.Size = UDim2.new(0, 0, 0, 28)
	v42.BackgroundTransparency = 1
	v42.Font = v_u_8
	v42.TextSize = 18
	v42.TextColor3 = v_u_9
	v42.Text = p40
	v42.Parent = p39
	local v43 = Instance.new("UIPadding")
	v43.PaddingTop = UDim.new(0, -0)
	v43.PaddingBottom = UDim.new(0, 0)
	v43.Parent = v42
end
local v_u_45 = {}
v_u_45.__index = v_u_45
function v_u_45.new(p46) -- name: new
	-- upvalues: (copy) v_u_45, (copy) v_u_4
	local v47 = v_u_45
	local v48 = setmetatable({}, v47)
	v48.parent = p46
	v48.characterContext = nil
	v48.created = false
	v48.enabled = false
	v48.bar = nil
	v48.connections = v_u_4.new()
	v48.contextConnections = v_u_4.new()
	return v48
end
function v_u_45.GetInputContextsParent(_) -- name: GetInputContextsParent
	return script:FindFirstAncestor("PlayerModule")
end
function v_u_45.ResolveCharacterContext(p49) -- name: ResolveCharacterContext
	local v50 = p49:GetInputContextsParent()
	if v50 then
		v50 = v50:FindFirstChild("InputContexts")
	end
	if v50 then
		return v50:FindFirstChild("CharacterContext")
	else
		return nil
	end
end
function v_u_45.ResolveAndBind(p_u_51) -- name: ResolveAndBind
	p_u_51.connections:disconnect("ResolveWatcher")
	local v52 = p_u_51:ResolveCharacterContext()
	if v52 then
		p_u_51:BindCharacterContext(v52)
		return
	else
		local v53 = p_u_51:GetInputContextsParent()
		if v53 then
			local function v_u_57(p54) -- name: bindWhenCharacterContextReady
				-- upvalues: (copy) p_u_51
				local v55 = p54:FindFirstChild("CharacterContext")
				if v55 then
					p_u_51.connections:disconnect("ResolveWatcher")
					p_u_51:BindCharacterContext(v55)
				else
					p_u_51.connections:trackConnection("ResolveWatcher", p54.ChildAdded:Connect(function(p56)
						-- upvalues: (ref) p_u_51
						if p56.Name == "CharacterContext" then
							p_u_51.connections:disconnect("ResolveWatcher")
							p_u_51:BindCharacterContext(p56)
						end
					end))
				end
			end
			local v58 = v53:FindFirstChild("InputContexts")
			if v58 then
				v_u_57(v58)
			else
				p_u_51.connections:trackConnection("ResolveWatcher", v53.ChildAdded:Connect(function(p59)
					-- upvalues: (copy) v_u_57
					if p59.Name == "InputContexts" then
						v_u_57(p59)
					end
				end))
			end
		else
			return
		end
	end
end
function v_u_45.BindCharacterContext(p_u_60, p61) -- name: BindCharacterContext
	-- upvalues: (copy) v_u_3
	p_u_60.characterContext = p61
	p_u_60.contextConnections:disconnectAll()
	if p61 then
		local function v_u_63(p62) -- name: watchAction
			-- upvalues: (copy) p_u_60
			p_u_60.contextConnections:trackConnection(p62.Name .. "_Enabled", p62:GetPropertyChangedSignal("Enabled"):Connect(function()
				-- upvalues: (ref) p_u_60
				p_u_60:Rebuild()
			end))
			p_u_60.contextConnections:trackConnection(p62.Name .. "_AttributeChanged", p62.AttributeChanged:Connect(function()
				-- upvalues: (ref) p_u_60
				p_u_60:Rebuild()
			end))
		end
		for v64 = 1, v_u_3.GetNumAbilitySlots() do
			local v65 = p61:FindFirstChild("AbilityAction" .. v64)
			if not v65 then
				continue
			end
			v_u_63(v65)
		end
		p_u_60.contextConnections:trackConnection("ChildAdded", p61.ChildAdded:Connect(function(p66)
			-- upvalues: (copy) v_u_63, (copy) p_u_60
			if p66:IsA("InputAction") and string.match(p66.Name, "^AbilityAction%d+$") then
				v_u_63(p66)
				p_u_60:Rebuild()
			end
		end))
		p_u_60.contextConnections:trackConnection("ChildRemoved", p61.ChildRemoved:Connect(function(p67)
			-- upvalues: (copy) p_u_60
			if p67:IsA("InputAction") and string.match(p67.Name, "^AbilityAction%d+$") then
				p_u_60.contextConnections:disconnect(p67.Name .. "_Enabled")
				p_u_60.contextConnections:disconnect(p67.Name .. "_AttributeChanged")
				p_u_60:Rebuild()
			end
		end))
	end
	p_u_60:Rebuild()
end
function v_u_45.IsVisiblePlatform(_) -- name: IsVisiblePlatform
	-- upvalues: (copy) v_u_1
	local v68 = v_u_1.PreferredInput
	return v68 == Enum.PreferredInput.KeyboardAndMouse and true or v68 == Enum.PreferredInput.Gamepad
end
function v_u_45.Enable(p69, p70) -- name: Enable
	if p69.enabled ~= p70 then
		p69.enabled = p70
		if p70 and not p69.created then
			p69:Create()
			p69.created = true
		end
		p69:Rebuild()
	end
end
function v_u_45.CreateEntry(p71, p72, p73, p74) -- name: CreateEntry
	-- upvalues: (copy) v_u_27, (copy) v_u_38, (copy) v_u_44
	local v75 = v_u_27(p71.bar, "Slot" .. p72, p72)
	v_u_38(v75, p74, 1)
	v_u_44(v75, p73, 2)
end
function v_u_45.CreateActionEntry(p76, p77, p78, p79, p80) -- name: CreateActionEntry
	-- upvalues: (copy) v_u_27, (copy) v_u_38, (copy) v_u_44
	local v81 = v_u_27(p76.bar, p77, p78)
	v_u_38(v81, p80, 1)
	v_u_44(v81, p79, 2)
end
function v_u_45.Rebuild(p82) -- name: Rebuild
	-- upvalues: (copy) v_u_1, (copy) v_u_3, (copy) v_u_5, (copy) v_u_6, (copy) v_u_20
	if p82.bar then
		for _, v83 in p82.bar:GetChildren() do
			if not v83:IsA("Frame") then
				continue
			end
			v83:Destroy()
		end
		local v84 = p82.characterContext
		if p82.enabled and (p82:IsVisiblePlatform() and v84) then
			local v85 = false
			local v86 = v_u_1.PreferredInput
			if #v_u_3.GetAbilitiesInOverflow() > 0 then
				local v87
				if v86 == Enum.PreferredInput.Gamepad then
					v87 = v_u_5
				elseif v86 == Enum.PreferredInput.KeyboardAndMouse then
					v87 = v_u_6
				else
					v87 = nil
				end
				if v87 then
					p82:CreateActionEntry("MoreActions", v_u_3.GetNumAbilitySlots() + 1, "More Actions", v87)
					v85 = true
				end
			end
			for v88 = 1, v_u_3.GetNumAbilitySlots() do
				local v89 = v84:FindFirstChild("AbilityAction" .. v88)
				if not (v89 and v89.Enabled) then
					continue
				end
				local v90 = v89.DisplayName
				if type(v90) ~= "string" or v90 == "" then
					continue
				end
				p82:CreateEntry(v88, v90, (v_u_20(v89)))
				v85 = true
			end
			p82.bar.Visible = v85
		else
			p82.bar.Visible = false
		end
	else
		return
	end
end
function v_u_45.Create(p_u_91) -- name: Create
	-- upvalues: (copy) v_u_7, (copy) v_u_1, (copy) v_u_3
	if p_u_91.parent then
		local v92 = Instance.new("Frame")
		v92.Name = "AbilityKeybindBar"
		v92.AnchorPoint = Vector2.new(1, 1)
		v92.Position = UDim2.new(1, -17, 1, -17)
		v92.Size = UDim2.new(0, 0, 0, 28)
		v92.AutomaticSize = Enum.AutomaticSize.XY
		v92.BackgroundColor3 = v_u_7
		v92.BackgroundTransparency = 0.4
		v92.BorderSizePixel = 0
		v92.Visible = false
		v92.Parent = p_u_91.parent
		p_u_91.bar = v92
		local v93 = Instance.new("UICorner")
		v93.CornerRadius = UDim.new(1, 0)
		v93.Parent = v92
		local v94 = Instance.new("UIPadding")
		v94.PaddingLeft = UDim.new(0, 16)
		v94.PaddingRight = UDim.new(0, 12)
		v94.PaddingTop = UDim.new(0, 4)
		v94.PaddingBottom = UDim.new(0, 4)
		v94.Parent = v92
		local v95 = Instance.new("UIListLayout")
		v95.FillDirection = Enum.FillDirection.Horizontal
		v95.HorizontalAlignment = Enum.HorizontalAlignment.Center
		v95.VerticalAlignment = Enum.VerticalAlignment.Center
		v95.SortOrder = Enum.SortOrder.LayoutOrder
		v95.Padding = UDim.new(0, 8)
		v95.Parent = v92
		p_u_91.connections:trackConnection("PreferredInput", v_u_1:GetPropertyChangedSignal("PreferredInput"):Connect(function()
			-- upvalues: (copy) p_u_91
			p_u_91:Rebuild()
		end))
		p_u_91.connections:trackConnection("SlotMapChanged", v_u_3.GetSlotMapChangedSignal():Connect(function()
			-- upvalues: (copy) p_u_91
			p_u_91:Rebuild()
		end))
		p_u_91.connections:trackConnection("ParentDestroying", p_u_91.parent.Destroying:Connect(function()
			-- upvalues: (copy) p_u_91
			p_u_91:Teardown()
		end))
		p_u_91:ResolveAndBind()
	end
end
function v_u_45.Teardown(p96) -- name: Teardown
	p96.connections:disconnectAll()
	p96.contextConnections:disconnectAll()
	if p96.bar then
		p96.bar:Destroy()
		p96.bar = nil
	end
	p96.created = false
end
return v_u_45