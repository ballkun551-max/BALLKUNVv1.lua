-- Path: Players/ygggggg55551/PlayerScripts/ArenaChoiceClient
-- Class: LocalScript  true/Enum.RunContext.Legacy
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = require(game:GetService("ReplicatedStorage"):WaitForChild("NetSeal"))
local v2 = game:GetService("Players")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("TweenService")
local v5 = require(v3:WaitForChild("GameShared"))
local v6 = v3:WaitForChild("GameUI")
local v_u_7 = require(v6:WaitForChild("Theme"))
local v_u_8 = require(v6:WaitForChild("Toast"))
local v_u_9 = v2.LocalPlayer
local v10 = v3:WaitForChild(v5.REMOTES)
local v_u_11 = v10:WaitForChild("Duel")
local v_u_12 = v10:WaitForChild("DuelQueue", 30)
local v_u_13 = v_u_7.screen("ArenaChoice", 15, v_u_9:WaitForChild("PlayerGui"))
local v_u_14 = v_u_7.panel({
	["Name"] = "Choice",
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Visible"] = false,
	["Parent"] = nil,
	["AnchorPoint"] = Vector2.new(0.5, 1),
	["Position"] = UDim2.new(0.5, 0, 1, -24),
	["Size"] = UDim2.fromOffset(640, 170),
	["Parent"] = v_u_13
})
v_u_14.UICorner.CornerRadius = UDim.new(0, 18)
v_u_7.padding(v_u_14, 16)
local v_u_15 = v_u_7.new("UIScale", {
	["Parent"] = v_u_14
})
v_u_7.text({
	["Text"] = "\224\184\136\224\184\176\224\185\129\224\184\130\224\185\136\224\184\135\224\185\129\224\184\154\224\184\154\224\185\132\224\184\171\224\184\153?",
	["TextSize"] = 24,
	["FontFace"] = nil,
	["TextXAlignment"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["FontFace"] = v_u_7.FONT_DISPLAY,
	["TextXAlignment"] = Enum.TextXAlignment.Left,
	["Size"] = UDim2.new(1, 0, 0, 28),
	["Parent"] = v_u_14
})
v_u_7.text({
	["Text"] = "\224\184\171\224\184\163\224\184\183\224\184\173\224\184\163\224\184\173\224\185\131\224\184\171\224\185\137\224\184\132\224\184\153\224\184\161\224\184\178\224\184\162\224\184\183\224\184\153\224\185\129\224\184\151\224\185\136\224\184\153\224\184\130\224\185\137\224\184\178\224\184\135\224\185\134 \224\184\129\224\185\135\224\185\132\224\184\148\224\185\137",
	["TextSize"] = 14,
	["TextColor3"] = nil,
	["TextXAlignment"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["TextColor3"] = v_u_7.TEXT_DIM,
	["TextXAlignment"] = Enum.TextXAlignment.Left,
	["Position"] = UDim2.fromOffset(0, 30),
	["Size"] = UDim2.new(1, 0, 0, 18),
	["Parent"] = v_u_14
})
local v_u_16 = v_u_7.new("Frame", {
	["BackgroundTransparency"] = 1,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["Position"] = UDim2.fromOffset(0, 62),
	["Size"] = UDim2.new(1, 0, 0, 72),
	["Parent"] = v_u_14
})
v_u_7.new("UIListLayout", {
	["FillDirection"] = Enum.FillDirection.Horizontal,
	["Padding"] = UDim.new(0, 10),
	["Parent"] = v_u_16
})
local function v21(p17, p18, p19) -- name: choice
	-- upvalues: (copy) v_u_7, (copy) v_u_16
	local v20 = v_u_7.button({
		["text"] = nil,
		["grad"] = nil,
		["textSize"] = 17,
		["size"] = nil,
		["parent"] = nil,
		["radius"] = 14,
		["text"] = p17,
		["grad"] = p18,
		["size"] = UDim2.new(0.3333333333333333, -7, 1, 0),
		["parent"] = v_u_16
	})
	v20.Activated:Connect(p19)
	return v20
end
v21("\224\185\129\224\184\130\224\185\136\224\184\135\224\184\129\224\184\177\224\184\154\224\184\154\224\184\173\224\184\151", "blue", function()
	-- upvalues: (copy) v_u_1, (copy) v_u_11, (copy) v_u_14
	v_u_1.fire(v_u_11, "Mode", "bot")
	v_u_14.Visible = false
end)
local v_u_28 = v21("\224\184\171\224\184\178\224\184\132\224\184\185\224\185\136\224\184\151\224\184\177\224\185\136\224\184\167\224\184\151\224\184\177\224\185\137\224\184\135\224\185\129\224\184\161\224\184\158", "red", function()
	-- upvalues: (copy) v_u_12, (copy) v_u_9, (copy) v_u_1, (copy) v_u_8
	if v_u_12 then
		local v22 = v_u_9:GetAttribute("DuelQueue") == true
		local v23 = v_u_1.invoke
		local v24 = v_u_12
		local v25, v26, v27 = pcall(v23, v24, v22 and "Leave" or "Join")
		if v25 and v27 then
			v_u_8.show(v27, v26 and "ok" or "error")
		end
	end
end)
v21("\224\184\167\224\184\180\224\185\136\224\184\135\224\184\132\224\184\153\224\185\128\224\184\148\224\184\181\224\184\162\224\184\167", "green", function()
	-- upvalues: (copy) v_u_1, (copy) v_u_11, (copy) v_u_14
	v_u_1.fire(v_u_11, "Mode", "solo")
	v_u_14.Visible = false
end)
v_u_9:GetAttributeChangedSignal("DuelQueue"):Connect(function() -- name: drawFind
	-- upvalues: (copy) v_u_9, (copy) v_u_7, (copy) v_u_28
	local v29 = v_u_9:GetAttribute("DuelQueue") == true
	local v30 = v_u_7.setButton
	local v31 = v_u_28
	local v32 = v29 and "gold" or "red"
	local v33 = v29 and "\224\184\129\224\184\179\224\184\165\224\184\177\224\184\135\224\184\171\224\184\178\226\128\166 (\224\184\129\224\184\148\224\184\162\224\184\129\224\185\128\224\184\165\224\184\180\224\184\129)" or "\224\184\171\224\184\178\224\184\132\224\184\185\224\185\136\224\184\151\224\184\177\224\185\136\224\184\167\224\184\151\224\184\177\224\185\137\224\184\135\224\185\129\224\184\161\224\184\158"
	local v34
	if v29 then
		v34 = v_u_7.DARK_TEXT
	else
		v34 = Color3.new(1, 1, 1)
	end
	v30(v31, v32, v33, v34)
end)
local v35 = v_u_9:GetAttribute("DuelQueue") == true
local v36 = v_u_7.setButton
local v37 = v35 and "gold" or "red"
local v38 = v35 and "\224\184\129\224\184\179\224\184\165\224\184\177\224\184\135\224\184\171\224\184\178\226\128\166 (\224\184\129\224\184\148\224\184\162\224\184\129\224\185\128\224\184\165\224\184\180\224\184\129)" or "\224\184\171\224\184\178\224\184\132\224\184\185\224\185\136\224\184\151\224\184\177\224\185\136\224\184\167\224\184\151\224\184\177\224\185\137\224\184\135\224\185\129\224\184\161\224\184\158"
local v39
if v35 then
	v39 = v_u_7.DARK_TEXT
else
	v39 = Color3.new(1, 1, 1)
end
v36(v_u_28, v37, v38, v39)
v_u_11.OnClientEvent:Connect(function(p40, p41)
	-- upvalues: (copy) v_u_13, (copy) v_u_14, (copy) v_u_15, (copy) v_u_4, (copy) v_u_7, (copy) v_u_9, (copy) v_u_12, (copy) v_u_1
	if p40 == "Choose" then
		if p41 then
			v_u_13.Enabled = true
			v_u_14.Visible = true
			v_u_15.Scale = 0.85
			v_u_4:Create(v_u_15, v_u_7.POP, {
				["Scale"] = v_u_7.isTouch() and 0.8 or 1
			}):Play()
		else
			v_u_14.Visible = false
			if v_u_9:GetAttribute("DuelQueue") and v_u_12 then
				local v42 = v_u_1.invoke
				local v43 = v_u_12
				pcall(v42, v43, "Leave")
			end
		end
	else
		return
	end
end)