-- Path: ReplicatedStorage/UiOwn
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v1 = game:GetService("HttpService")
local v_u_2 = game:GetService("Players")
local v_u_3 = game:GetService("ReplicatedFirst")
local v_u_4 = game:GetService("ReplicatedStorage")
local v5 = game:GetService("RunService")
local v_u_6 = Instance
local v_u_7 = {}
local v_u_8 = "u" .. v1:GenerateGUID(false):gsub("-", ""):sub(1, 10)
local v_u_9 = v5:IsClient()
local v_u_10 = {}
local v_u_11 = {}
local v_u_12 = {}
local v_u_13 = {}
local v_u_14 = (-1 / 0)
local function v_u_22() -- name: scan
	-- upvalues: (ref) v_u_14, (copy) v_u_2, (copy) v_u_4, (copy) v_u_3, (copy) v_u_13
	v_u_14 = os.clock()
	local v15 = v_u_2.LocalPlayer
	local v16 = {}
	local v17 = v_u_4
	local v18 = v_u_3
	local v19
	if v15 then
		v19 = v15.Character
	else
		v19 = v15
	end
	__set_list(v16, 1, {v17, v18, v15, v19})
	for _, v20 in v16 do
		for _, v21 in v20:GetDescendants() do
			if not v21:IsA("LuaSourceContainer") then
				continue
			end
			v_u_13[v21:GetFullName()] = true
		end
	end
end
local function v_u_26(p23) -- name: gameSource
	-- upvalues: (copy) v_u_13, (ref) v_u_14, (copy) v_u_22
	if v_u_13[p23] then
		return true
	else
		local v24 = game
		for v25 in string.gmatch(p23, "[^%.]+") do
			v24 = v24:FindFirstChild(v25)
			if v24 then
				continue
			end
		end
		if v24 and (v24 ~= game and v24:IsA("LuaSourceContainer")) then
			v_u_13[p23] = true
			return true
		else
			if os.clock() - v_u_14 > 5 then
				v_u_22()
			end
			return v_u_13[p23] == true
		end
	end
end
local function v_u_31() -- name: outsider
	-- upvalues: (copy) v_u_26, (copy) v_u_12
	local v27 = nil
	for v28 = 2, 64 do
		local v29, v30 = debug.info(v28, "sf")
		if v29 == nil then
			break
		end
		if v29 == "[C]" then
			continue
		end
		if not v_u_26(v29) then
			return v29
		end
		v27 = v30
	end
	return v27 and v_u_12[v27] and "(a thread started in the game\'s UI builder)" or nil
end
local function v_u_34(p_u_32, p33) -- name: take
	-- upvalues: (copy) v_u_9, (copy) v_u_8, (copy) v_u_11, (copy) v_u_10
	if p_u_32:IsA("GuiBase2d") then
		if v_u_9 then
			if p33 then
				v_u_11[p_u_32] = p33
				p_u_32.Destroying:Once(function()
					-- upvalues: (ref) v_u_11, (copy) p_u_32
					v_u_11[p_u_32] = nil
				end)
			else
				v_u_10[p_u_32] = true
				p_u_32:SetAttribute(v_u_8, true)
				p_u_32.Destroying:Once(function()
					-- upvalues: (ref) v_u_10, (copy) p_u_32
					v_u_10[p_u_32] = nil
				end)
			end
		else
			p_u_32:SetAttribute(v_u_8, true)
			return
		end
	else
		return
	end
end
function v_u_7.mark(p35) -- name: mark
	-- upvalues: (copy) v_u_34, (copy) v_u_9, (copy) v_u_31
	if p35:IsA("GuiBase2d") then
		local v36 = v_u_34
		local v37
		if v_u_9 then
			v37 = v_u_31()
		else
			v37 = nil
		end
		v36(p35, v37)
	end
	return p35
end
function v_u_7.mine(p38) -- name: mine
	-- upvalues: (copy) v_u_9, (copy) v_u_8, (copy) v_u_10
	if v_u_9 then
		return v_u_10[p38] == true
	else
		return p38:GetAttribute(v_u_8) == true
	end
end
function v_u_7.copied(p39) -- name: copied
	-- upvalues: (copy) v_u_9, (copy) v_u_10, (copy) v_u_8
	local v40 = v_u_9
	if v40 then
		if v_u_10[p39] == nil then
			v40 = p39:GetAttribute(v_u_8) == true
		else
			v40 = false
		end
	end
	return v40
end
function v_u_7.madeBy(p41) -- name: madeBy
	-- upvalues: (copy) v_u_11
	return v_u_11[p41]
end
function v_u_7.gameSource(p42) -- name: gameSource
	-- upvalues: (copy) v_u_26
	local v43
	if type(p42) == "string" then
		v43 = v_u_26(p42)
	else
		v43 = false
	end
	return v43
end
function v_u_7.entry(p44) -- name: entry
	-- upvalues: (copy) v_u_12
	if type(p44) == "function" then
		v_u_12[p44] = true
	end
	return p44
end
function v_u_7.clone(p45) -- name: clone
	-- upvalues: (copy) v_u_9, (copy) v_u_31, (copy) v_u_34
	local v46 = p45:Clone()
	local v47
	if v_u_9 then
		v47 = v_u_31()
	else
		v47 = nil
	end
	v_u_34(v46, v47)
	for _, v48 in v46:GetDescendants() do
		v_u_34(v48, v47)
	end
	return v46
end
v_u_7.Instance = setmetatable({
	["new"] = function(p49, p50) -- name: new
		-- upvalues: (copy) v_u_7, (copy) v_u_6
		local v51 = v_u_7.mark(v_u_6.new(p49))
		if p50 then
			v51.Parent = p50
		end
		return v51
	end
}, {
	["__index"] = v_u_6
})
for _, v52 in { v_u_7.mark, v_u_7.clone, v_u_7.Instance.new } do
	v_u_7.entry(v52)
end
return v_u_7