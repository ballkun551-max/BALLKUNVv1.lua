-- Path: Players/ygggggg55551/PlayerScripts/PCX160Client/PaintMenu
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = require(game:GetService("ReplicatedStorage"):WaitForChild("UiOwn")).Instance
local v2 = game:GetService("Players")
local v_u_3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("UserInputService")
local v_u_5 = require(v_u_3:WaitForChild("PCX160Shared"))
local v_u_6 = require(v_u_3:WaitForChild("PartsShared"))
local v_u_7 = require(v_u_3:WaitForChild("GameUI"):WaitForChild("Skin"))
local v_u_8 = require(v_u_3:WaitForChild("GameUI"):WaitForChild("Theme"))
local v_u_9 = require(v_u_3:WaitForChild("GameUI"):WaitForChild("ColorField"))
local v_u_10 = v2.LocalPlayer
local v_u_11 = require(v_u_3:WaitForChild("GameShared"))
local v12 = v_u_3:WaitForChild("GameUI")
local v_u_13 = require(v12:WaitForChild("Icons"))
local v_u_14 = require(v12:WaitForChild("Toast"))
local v_u_15 = require(v12:WaitForChild("Store"))
local v_u_16 = require(v12:WaitForChild("ModePanel"))
local v_u_17 = {
	{
		["id"] = "Body",
		["label"] = "Body",
		["group"] = "Paint"
	},
	{
		["id"] = "Shock",
		["label"] = "Shock spring",
		["group"] = "Paint"
	},
	{
		["id"] = "Wheel",
		["label"] = "Wheels",
		["group"] = "Paint"
	},
	{
		["id"] = "Logo",
		["label"] = "\224\185\130\224\184\165\224\185\130\224\184\129\224\185\137",
		["group"] = "Paint"
	},
	{
		["id"] = "Accent",
		["label"] = "\224\184\170\224\184\181\224\184\163\224\184\173\224\184\135",
		["group"] = "Paint"
	},
	{
		["id"] = "TailLight",
		["label"] = "Tail light",
		["group"] = "Paint"
	},
	{
		["id"] = "Bolt",
		["label"] = "\224\184\170\224\184\129\224\184\185\224\184\165",
		["group"] = "Paint"
	},
	{
		["id"] = "Grip",
		["label"] = "\224\184\155\224\184\165\224\184\173\224\184\129\224\185\129\224\184\174\224\184\153\224\184\148\224\185\140",
		["group"] = "Paint"
	},
	{
		["id"] = "BarCap",
		["label"] = "\224\185\129\224\184\174\224\184\153 / \224\184\157\224\184\178\224\184\153\224\185\137\224\184\179\224\184\161\224\184\177\224\184\153",
		["group"] = "Paint"
	},
	{
		["id"] = "ExhaustLogo",
		["label"] = "\224\185\130\224\184\165\224\185\130\224\184\129\224\185\137\224\184\151\224\185\136\224\184\173",
		["group"] = "Paint"
	},
	{
		["id"] = "Swingarm",
		["label"] = "\224\184\170\224\184\167\224\184\180\224\184\135\224\184\173\224\184\178\224\184\163\224\185\140\224\184\161",
		["group"] = "Paint"
	},
	{
		["id"] = "Footrest",
		["label"] = "\224\184\158\224\184\177\224\184\129\224\185\128\224\184\151\224\185\137\224\184\178",
		["group"] = "Paint"
	},
	{
		["id"] = "Fan",
		["label"] = "\224\185\131\224\184\154\224\184\158\224\184\177\224\184\148",
		["group"] = "Paint"
	},
	{
		["id"] = "Shield",
		["label"] = "\224\184\138\224\184\180\224\184\167",
		["group"] = "Paint"
	},
	{
		["id"] = "Carbon",
		["label"] = "Carbon",
		["group"] = "Paint"
	},
	{
		["id"] = "DRL",
		["label"] = "DRL lights",
		["group"] = "Other"
	},
	{
		["id"] = "Lower",
		["label"] = "Lowering",
		["group"] = "Other"
	},
	{
		["id"] = "Glass",
		["label"] = "Glass",
		["group"] = "Other"
	},
	{
		["id"] = "Signals",
		["label"] = "\224\185\132\224\184\159\224\185\128\224\184\165\224\184\181\224\185\137\224\184\162\224\184\167",
		["group"] = "Other"
	},
	{
		["id"] = "Acc",
		["label"] = "\224\184\130\224\184\173\224\184\135\224\185\129\224\184\149\224\185\136\224\184\135",
		["group"] = "Other"
	},
	{
		["id"] = "PartWheel",
		["label"] = "\224\184\165\224\185\137\224\184\173",
		["group"] = "Parts"
	},
	{
		["id"] = "PartExhaust",
		["label"] = "\224\184\151\224\185\136\224\184\173",
		["group"] = "Parts"
	},
	{
		["id"] = "PartExhaustSound",
		["label"] = "\224\185\128\224\184\170\224\184\181\224\184\162\224\184\135\224\184\151\224\185\136\224\184\173",
		["group"] = "Parts"
	},
	{
		["id"] = "PartEngineSound",
		["label"] = "\224\185\128\224\184\170\224\184\181\224\184\162\224\184\135\224\184\163\224\184\150\224\184\173\224\184\173\224\185\130\224\184\149\224\185\137",
		["group"] = "Parts"
	},
	{
		["id"] = "PopTune",
		["label"] = "\224\184\136\224\184\185\224\184\153\224\184\162\224\184\180\224\184\135",
		["group"] = "Parts"
	},
	{
		["id"] = "PartShock",
		["label"] = "\224\185\130\224\184\138\224\185\138\224\184\132",
		["group"] = "Parts"
	},
	{
		["id"] = "PartRadiator",
		["label"] = "\224\184\171\224\184\161\224\185\137\224\184\173\224\184\153\224\185\137\224\184\179",
		["group"] = "Parts"
	},
	{
		["id"] = "PartSeat",
		["label"] = "\224\185\128\224\184\154\224\184\178\224\184\176",
		["group"] = "Parts"
	},
	{
		["id"] = "PartEngineCover",
		["label"] = "\224\184\157\224\184\178\224\184\132\224\184\163\224\184\173\224\184\154\224\185\128\224\184\132\224\184\163\224\184\183\224\185\136\224\184\173\224\184\135",
		["group"] = "Parts"
	},
	{
		["id"] = "PartRoundCover",
		["label"] = "\224\184\157\224\184\178\224\184\132\224\184\163\224\184\173\224\184\154\224\184\129\224\184\165\224\184\161",
		["group"] = "Parts"
	}
}
local v18 = #v_u_17
local function v_u_22(p19, p20) -- name: lockMark
	-- upvalues: (copy) v_u_13
	if p19 then
		local v21 = p19:FindFirstChild("LockMark")
		if p20 and not v21 then
			v21 = v_u_13.make("lock", Color3.new(1, 1, 1), 16)
			v21.Name = "LockMark"
			v21.AnchorPoint = Vector2.new(1, 0.5)
			v21.Position = UDim2.new(1, -6, 0.5, 0)
			v21.Parent = p19
		end
		if v21 then
			v21.Visible = p20
		end
	end
end
for v23, v24 in v_u_17 do
	if v24.id ~= "Shield" then
		continue
	end
	v18 = v23
end
for v25, v26 in v_u_11.TINT_GROUPS do
	local v27 = v18 + v25
	local v28 = {
		["id"] = nil,
		["label"] = nil,
		["group"] = "Paint",
		["id"] = "Tint_" .. v26.id,
		["label"] = v26.th
	}
	table.insert(v_u_17, v27, v28)
end
local v_u_29 = {
	["Logo"] = true,
	["Accent"] = true,
	["TailLight"] = true,
	["Bolt"] = true,
	["Grip"] = true,
	["BarCap"] = true,
	["ExhaustLogo"] = true,
	["Swingarm"] = true,
	["Footrest"] = true,
	["Fan"] = true
}
local v_u_30 = {
	["PartWheel"] = "Wheel",
	["PartExhaust"] = "Exhaust",
	["PartExhaustSound"] = "ExhaustSound",
	["PartEngineSound"] = "EngineSound",
	["PartShock"] = "Shock",
	["PartRadiator"] = "Radiator",
	["PartSeat"] = "Seat",
	["PartEngineCover"] = "EngineCover",
	["PartRoundCover"] = "RoundCover"
}
local v_u_31 = Color3.new(1, 1, 1)
local v_u_32 = { Color3.fromRGB(255, 214, 64), Color3.fromRGB(255, 140, 26), Color3.fromRGB(235, 52, 24) }
local v_u_33 = Color3.fromRGB(148, 151, 165)
local v_u_34 = {
	{
		["id"] = "Shield",
		["label"] = "Windshield",
		["part"] = "Windshield"
	},
	{
		["id"] = "Mirrors",
		["label"] = "Side mirrors",
		["part"] = "Mirror"
	}
}
local v_u_35 = {
	{
		["label"] = "\224\184\170\224\185\137\224\184\161 (\224\185\128\224\184\148\224\184\180\224\184\161)",
		["color"] = nil,
		["stock"] = true,
		["color"] = v_u_5.SIGNAL_DEFAULT_COLOR
	},
	{
		["label"] = "\224\185\128\224\184\171\224\184\165\224\184\183\224\184\173\224\184\135",
		["color"] = nil,
		["color"] = Color3.fromRGB(255, 215, 0)
	},
	{
		["label"] = "\224\184\130\224\184\178\224\184\167",
		["color"] = nil,
		["color"] = Color3.fromRGB(240, 245, 255)
	},
	{
		["label"] = "\224\185\129\224\184\148\224\184\135",
		["color"] = nil,
		["color"] = Color3.fromRGB(255, 30, 40)
	},
	{
		["label"] = "\224\184\138\224\184\161\224\184\158\224\184\185",
		["color"] = nil,
		["color"] = Color3.fromRGB(255, 70, 200)
	},
	{
		["label"] = "\224\184\161\224\185\136\224\184\167\224\184\135",
		["color"] = nil,
		["color"] = Color3.fromRGB(150, 60, 255)
	},
	{
		["label"] = "\224\184\159\224\185\137\224\184\178",
		["color"] = nil,
		["color"] = Color3.fromRGB(0, 200, 255)
	},
	{
		["label"] = "\224\185\128\224\184\130\224\184\181\224\184\162\224\184\167",
		["color"] = nil,
		["color"] = Color3.fromRGB(40, 255, 90)
	}
}
local v_u_36 = {
	{
		["label"] = "\224\185\128\224\184\148\224\184\180\224\184\161",
		["stock"] = true
	},
	{
		["label"] = "\224\184\138\224\184\178\224\184\148\224\184\179",
		["color"] = nil,
		["color"] = Color3.fromRGB(25, 25, 30)
	},
	{
		["label"] = "\224\184\130\224\184\178\224\184\167",
		["color"] = nil,
		["color"] = Color3.fromRGB(225, 235, 245)
	},
	{
		["label"] = "\224\184\159\224\185\137\224\184\178",
		["color"] = nil,
		["color"] = Color3.fromRGB(0, 170, 255)
	},
	{
		["label"] = "\224\184\153\224\185\137\224\184\179\224\185\128\224\184\135\224\184\180\224\184\153",
		["color"] = nil,
		["color"] = Color3.fromRGB(20, 60, 210)
	},
	{
		["label"] = "\224\184\161\224\185\136\224\184\167\224\184\135",
		["color"] = nil,
		["color"] = Color3.fromRGB(140, 50, 230)
	},
	{
		["label"] = "\224\184\138\224\184\161\224\184\158\224\184\185",
		["color"] = nil,
		["color"] = Color3.fromRGB(255, 80, 190)
	},
	{
		["label"] = "\224\185\129\224\184\148\224\184\135",
		["color"] = nil,
		["color"] = Color3.fromRGB(220, 30, 40)
	},
	{
		["label"] = "\224\184\170\224\185\137\224\184\161",
		["color"] = nil,
		["color"] = Color3.fromRGB(255, 130, 0)
	}
}
local v_u_37 = {
	{
		["label"] = "\224\184\151\224\184\182\224\184\154",
		["t"] = 0
	},
	{
		["label"] = "\224\184\138\224\184\178\224\185\128\224\184\130\224\185\137\224\184\161",
		["t"] = 0.35
	},
	{
		["label"] = "\224\185\128\224\184\148\224\184\180\224\184\161",
		["stock"] = true
	},
	{
		["label"] = "\224\185\131\224\184\170\224\184\170\224\184\184\224\184\148",
		["t"] = nil,
		["t"] = v_u_11.SHIELD_CLEAR_MAX
	}
}
local v_u_38 = {
	{
		["label"] = "\224\184\155\224\184\129\224\184\149\224\184\180",
		["rate"] = 1
	},
	{
		["label"] = "\224\185\128\224\184\163\224\185\135\224\184\167",
		["rate"] = 3
	},
	{
		["label"] = "\224\185\128\224\184\163\224\185\135\224\184\167\224\184\161\224\184\178\224\184\129",
		["rate"] = 8
	},
	{
		["label"] = "\224\184\132\224\185\137\224\184\178\224\184\135",
		["rate"] = nil,
		["rate"] = v_u_5.BLINK_RATE_MAX
	}
}
local v_u_39 = Vector2.new(540, 436)
local v_u_40 = Vector2.new(264, 316)
local v_u_41 = {
	{
		["id"] = false,
		["label"] = "Spring"
	},
	{
		["id"] = true,
		["label"] = "Whole shock"
	}
}
local v_u_42 = {
	{
		["id"] = "Gloss",
		["label"] = "Gloss"
	},
	{
		["id"] = "Matte",
		["label"] = "Matte"
	},
	{
		["id"] = "Chrome",
		["label"] = "Chrome"
	}
}
local v_u_43 = {
	Color3.fromRGB(240, 240, 240),
	Color3.fromRGB(20, 20, 22),
	Color3.fromRGB(110, 112, 118),
	Color3.fromRGB(190, 192, 198),
	Color3.fromRGB(200, 20, 30),
	Color3.fromRGB(110, 10, 20),
	Color3.fromRGB(255, 120, 0),
	Color3.fromRGB(255, 210, 0),
	Color3.fromRGB(200, 160, 60),
	Color3.fromRGB(20, 150, 60),
	Color3.fromRGB(150, 230, 40),
	Color3.fromRGB(0, 190, 200),
	Color3.fromRGB(20, 90, 220),
	Color3.fromRGB(15, 30, 90),
	Color3.fromRGB(130, 50, 200),
	Color3.fromRGB(255, 110, 180),
	Color3.fromRGB(110, 70, 40),
	Color3.fromRGB(90, 100, 60)
}
local v_u_44 = {
	{
		["id"] = "Rainbow",
		["label"] = "Rainbow"
	},
	{
		["id"] = "Solid",
		["label"] = "Solid"
	},
	{
		["id"] = "Gradient",
		["label"] = "Gradient"
	},
	{
		["id"] = "Mode",
		["label"] = "Modes"
	}
}
local v_u_45 = {
	Color3.fromRGB(70, 140, 255),
	Color3.fromRGB(30, 60, 255),
	Color3.fromRGB(0, 220, 255),
	Color3.fromRGB(255, 255, 255),
	Color3.fromRGB(255, 215, 160),
	Color3.fromRGB(150, 60, 255),
	Color3.fromRGB(255, 70, 200),
	Color3.fromRGB(255, 30, 40),
	Color3.fromRGB(255, 120, 0),
	Color3.fromRGB(255, 220, 0),
	Color3.fromRGB(40, 255, 90),
	Color3.fromRGB(90, 255, 200)
}
local v_u_46 = {
	{ Color3.fromRGB(0, 200, 255), Color3.fromRGB(160, 60, 255) },
	{ Color3.fromRGB(40, 110, 255), Color3.fromRGB(220, 240, 255) },
	{ Color3.fromRGB(255, 30, 40), Color3.fromRGB(255, 90, 200) },
	{ Color3.fromRGB(40, 255, 120), Color3.fromRGB(0, 160, 255) },
	{ Color3.fromRGB(255, 90, 0), Color3.fromRGB(255, 230, 40) },
	{ Color3.fromRGB(255, 80, 200), Color3.fromRGB(110, 40, 255) }
}
local v_u_47 = v_u_7.PANEL
local v_u_48 = v_u_7.IDLE
local v_u_49 = v_u_7.SELECTED
local v_u_50 = v_u_7.DISABLED
local v_u_51 = {}
local v_u_52 = nil
local v_u_53 = nil
local v_u_54 = nil
local v_u_55 = nil
local v_u_56 = nil
local v_u_57 = nil
local v_u_58 = nil
local v_u_59 = nil
local v_u_60 = nil
local v_u_61 = nil
local v_u_62 = nil
local v_u_63 = nil
local v_u_64 = nil
local v_u_65 = {}
local v_u_66 = {}
local v_u_67 = {}
local v_u_68 = {}
local v_u_69 = {}
local v_u_70 = nil
local v_u_71 = nil
local v_u_72 = nil
local v_u_73 = nil
local v_u_74 = nil
local v_u_75 = {}
local v_u_76 = {}
local v_u_77 = nil
local v_u_78 = nil
local v_u_79 = nil
local v_u_80 = nil
local v_u_81 = {}
local v_u_82 = {}
local v_u_83 = nil
local v_u_84 = nil
local v_u_85 = nil
local v_u_86 = nil
local v_u_87 = nil
local v_u_88 = nil
local v_u_89 = nil
local v_u_90 = {}
local v_u_91 = nil
local v_u_92 = nil
local v_u_93 = {}
local v_u_94 = nil
local v_u_95 = nil
local v_u_96 = nil
local v_u_97 = {}
local v_u_98 = nil
local v_u_99 = nil
local v_u_100 = {}
local v_u_101 = nil
local v_u_102 = nil
local v_u_103 = nil
local v_u_104 = nil
local v_u_105 = nil
local v_u_106 = nil
local v_u_107 = nil
local v_u_108 = {}
local v_u_109 = {}
local v_u_110 = false
local v_u_111 = nil
local v_u_112 = v_u_11.TUNE_PRICES
local v_u_113 = {
	["model"] = nil,
	["fire"] = nil,
	["tab"] = "Body",
	["finish"] = "Gloss",
	["wholeShock"] = false,
	["slot"] = 1,
	["h"] = 0,
	["s"] = 0,
	["v"] = 1,
	["group"] = nil
}
local function v_u_130(p114) -- name: tabOffered
	-- upvalues: (copy) v_u_113, (copy) v_u_11, (copy) v_u_6, (copy) v_u_30, (copy) v_u_17, (copy) v_u_5, (copy) v_u_29
	if v_u_113.model and v_u_11.atExhaustShop(v_u_113.model) then
		if p114 == "PartEngineSound" then
			local v115 = v_u_6.fitted(v_u_113.model:GetAttribute("VehicleId") or v_u_113.model.Name)
			local v116
			if v115 == nil or v115.EngineSound == nil then
				v116 = false
			else
				v116 = #v115.EngineSound > 0 and true or v_u_113.model:GetAttribute("PartEngineSound") ~= nil
			end
			return v116
		end
		if p114 ~= "PopTune" then
			return p114 == "PartExhaustSound"
		end
		local v117 = v_u_6.fitted(v_u_113.model:GetAttribute("VehicleId") or v_u_113.model.Name)
		local v118
		if v117 == nil or v117.ExhaustSound == nil then
			v118 = false
		else
			v118 = v_u_6.popTuneTunable(v_u_113.model)
		end
		return v118
	elseif (p114 == "PartExhaustSound" or (p114 == "PartEngineSound" or p114 == "PopTune")) and not v_u_11.atExhaustShop(v_u_113.model) then
		return false
	elseif v_u_30[p114] then
		local v119 = v_u_113.model
		if v119 then
			v119 = v_u_6.fitted(v_u_113.model:GetAttribute("VehicleId") or v_u_113.model.Name)
		end
		local v120
		if v119 == nil then
			v120 = false
		else
			v120 = v119[v_u_30[p114]] ~= nil
		end
		return v120
	else
		if v_u_113.model and v_u_113.model:GetAttribute("NoPaint") == true then
			for _, v121 in v_u_17 do
				if v121.id ~= p114 or (v121.group ~= "Paint" or v_u_5.paintAllowed(v_u_113.model, p114)) then
					continue
				end
				return false
			end
		end
		if p114 == "Glass" then
			local v122
			if v_u_113.glass == nil then
				v122 = false
			else
				v122 = v_u_113.glass.Shield or v_u_113.glass.Mirrors
			end
			return v122
		elseif p114 == "Carbon" then
			local v123
			if v_u_113.carbon == nil then
				v123 = false
			else
				v123 = #v_u_113.carbon > 0
			end
			return v123
		elseif p114 == "Acc" then
			local v124
			if v_u_113.acc == nil then
				v124 = false
			else
				v124 = #v_u_113.acc > 0
			end
			return v124
		elseif p114 == "Signals" then
			return v_u_113.model ~= nil
		else
			local v125 = p114:match("^Tint_(.+)$")
			if v125 then
				if not v_u_113.model then
					return false
				end
				for _, v126 in v_u_113.model:GetDescendants() do
					if not v126:IsA("BasePart") or v126:GetAttribute("TintGroup") ~= v125 then
						continue
					end
					return true
				end
				return false
			elseif p114 == "Shield" then
				local v127
				if v_u_113.model == nil or (v_u_113.model:GetAttribute("ShieldTune") ~= true or v_u_113.glass == nil) then
					v127 = false
				else
					v127 = v_u_113.glass.Shield == true
				end
				return v127
			elseif v_u_29[p114] then
				if not v_u_113.model then
					return false
				end
				for _, v128 in v_u_113.model:GetDescendants() do
					if not v128:IsA("BasePart") or v128:GetAttribute("PaintGroup") ~= p114 then
						continue
					end
					return true
				end
				return false
			else
				local v129 = p114 == "DRL" and v_u_113.model
				if v129 then
					v129 = v_u_113.model:GetAttribute("NoDRL") == true
				end
				return not v129
			end
		end
	end
end
local function v_u_134(p131, p132) -- name: hasPart
	for _, v133 in p131:GetDescendants() do
		if not (v133:IsA("BasePart") and v133:GetAttribute(p132)) then
			continue
		end
		return true
	end
	return false
end
local v_u_135 = {
	{
		["id"] = "Front",
		["label"] = "Front"
	},
	{
		["id"] = "Rear",
		["label"] = "Rear"
	}
}
local v_u_136 = {}
local function v_u_144(p137, p138, p139, p140, p141) -- name: textButton
	-- upvalues: (copy) v_u_1, (copy) v_u_48
	local v142 = v_u_1.new("TextButton")
	v142.Name = p137
	v142.Text = p138
	v142.Position = p139
	v142.Size = p140
	v142.BackgroundColor3 = v_u_48
	v142.TextColor3 = Color3.new(1, 1, 1)
	v142.Font = Enum.Font.GothamBold
	v142.TextSize = 18
	v142.Parent = p141
	local v143 = v_u_1.new("UICorner")
	v143.CornerRadius = UDim.new(0, 10)
	v143.Parent = v142
	return v142
end
local function v_u_159(p145, p146, p147, p148, p149, p_u_150) -- name: swatchGrid
	-- upvalues: (copy) v_u_1
	local v151 = v_u_1.new("Frame")
	v151.Name = p145
	v151.BackgroundTransparency = 1
	v151.Position = p147
	v151.Size = p148
	v151.Parent = p149
	local v152 = v_u_1.new("UIGridLayout")
	v152.CellSize = UDim2.fromOffset(44, 44)
	v152.CellPadding = UDim2.fromOffset(12, 12)
	v152.SortOrder = Enum.SortOrder.LayoutOrder
	v152.Parent = v151
	for v153, v_u_154 in p146 do
		local v155 = v_u_1.new("TextButton")
		v155.Name = "Swatch" .. v153
		v155.LayoutOrder = v153
		v155.Text = ""
		v155.AutoButtonColor = false
		v155.BackgroundColor3 = v_u_154
		v155:SetAttribute("Color", v_u_154)
		v155.Parent = v151
		local v156 = v_u_1.new("UICorner")
		v156.CornerRadius = UDim.new(0, 22)
		v156.Parent = v155
		local v157 = v_u_1.new("UIGradient")
		v157.Rotation = 90
		v157.Color = ColorSequence.new(Color3.new(1, 1, 1), Color3.fromRGB(150, 150, 150))
		v157.Parent = v155
		local v158 = v_u_1.new("UIStroke")
		v158.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
		v158.Color = Color3.fromRGB(255, 255, 255)
		v158.Transparency = 0.8
		v158.Parent = v155
		v155.Activated:Connect(function()
			-- upvalues: (copy) p_u_150, (copy) v_u_154
			p_u_150(v_u_154)
		end)
	end
	return v151
end
local function v_u_163(p160) -- name: partCount
	-- upvalues: (copy) v_u_113
	local v161 = 0
	if v_u_113.model then
		for _, v162 in v_u_113.model:GetDescendants() do
			if not v162:IsA("BasePart") or v162:GetAttribute("PaintGroup") ~= p160 then
				continue
			end
			v161 = v161 + 1
		end
	end
	return v161
end
local function v_u_168(p164, ...) -- name: fire
	-- upvalues: (copy) v_u_113, (copy) v_u_11, (copy) v_u_10, (copy) v_u_14, (copy) v_u_15
	if v_u_113.fire and v_u_113.model then
		local v165, _, v166 = ...
		local v167
		if p164 == "Paint" and v166 == "Chrome" then
			v167 = true
		elseif p164 == "DRL" then
			v167 = v165 == "Gradient" and true or v166 ~= nil
		else
			v167 = false
		end
		if v167 and v_u_11.passLocked(v_u_10, "Custom") then
			v_u_14.show("That\'s in the Custom pass", "info")
			v_u_15.open("Passes")
		else
			v_u_113.fire(p164, ...)
		end
	else
		return
	end
end
local function v_u_175(p169) -- name: paint
	-- upvalues: (copy) v_u_168, (copy) v_u_113
	local v170 = v_u_168
	local v171 = "Paint"
	local v172 = v_u_113.tab
	local v173 = v_u_113.finish
	local v174
	if v_u_113.tab == "Shock" then
		v174 = v_u_113.wholeShock
	else
		v174 = false
	end
	v170(v171, v172, p169, v173, v174)
end
local function v_u_195() -- name: refreshPrices
	-- upvalues: (copy) v_u_113, (copy) v_u_11, (copy) v_u_42, (copy) v_u_112, (copy) v_u_66, (copy) v_u_44, (copy) v_u_67, (ref) v_u_70, (copy) v_u_93, (copy) v_u_97, (copy) v_u_5, (ref) v_u_96
	local v176 = v_u_113.model
	local v177 = v_u_11.tuneOwned(v176)
	local v178 = v177["Paint_" .. v_u_113.tab] == true
	for _, v179 in v_u_42 do
		local v180 = (v178 and 0 or v_u_112.Paint) + v_u_11.tuneCost(v177, "Finish_" .. v179.id, v_u_112.Finish[v179.id] or 0)
		v_u_66[v179.id].Text = v179.label .. "  " .. (v180 <= 0 and "Owned" or v_u_11.priceText(v180))
	end
	for _, v181 in v_u_44 do
		v_u_67[v181.id].Text = v181.label .. "  " .. v_u_11.tunePriceText(v176, "Light_" .. v181.id, v_u_112.Light[v181.id])
	end
	v_u_70.Text = v177.Lower and "Drag right to go lower, as low as this bike goes before the tire hits. Lowering kit owned: any height, free" or ("Drag right to go lower, as low as this bike goes before the tire hits. Lowering kit %s, bought once for this bike: then any height, free"):format(v_u_11.priceText(v_u_112.Lower))
	for v182, v183 in v_u_93 do
		local v184 = v176:GetAttribute("CarbonPrice_" .. v182)
		local v185 = v183.on
		local v186 = "\224\184\132\224\184\178\224\184\163\224\185\140\224\184\154\224\184\173\224\184\153  "
		local v187 = v_u_11.tunePriceText
		local v188 = "Carbon_" .. v182
		if typeof(v184) ~= "number" then
			v184 = v_u_112.BikeCarbon
		end
		v185.Text = v186 .. v187(v176, v188, v184)
	end
	local v189 = false
	for v190, v191 in v_u_97 do
		local v192 = v_u_5.accessory(v190)
		local v193 = v176:GetAttribute("AccPrice_" .. v190)
		local v194
		if typeof(v193) == "number" then
			v194 = v193
		elseif v192 and v192.price then
			v194 = v192.price
		else
			v194 = v_u_112.Accessory
		end
		if not v189 then
			if typeof(v193) == "number" then
				v189 = true
			elseif v192 == nil then
				v189 = false
			else
				v189 = v192.price ~= nil
			end
		end
		v191.on.Text = (v192 and v192.remove and "\224\184\150\224\184\173\224\184\148\224\184\173\224\184\173\224\184\129  " or "\224\185\131\224\184\170\224\185\136  ") .. v_u_11.tunePriceText(v176, "Acc_" .. v190, v194)
	end
	if v_u_96 then
		v_u_96.Text = v189 and "\224\184\136\224\185\136\224\184\178\224\184\162\224\184\132\224\184\163\224\184\177\224\185\137\224\184\135\224\185\128\224\184\148\224\184\181\224\184\162\224\184\167\224\184\149\224\185\136\224\184\173\224\184\132\224\184\177\224\184\153\224\184\149\224\184\178\224\184\161\224\184\163\224\184\178\224\184\132\224\184\178\224\184\151\224\184\181\224\185\136\224\184\155\224\184\184\224\185\136\224\184\161 \194\183 \224\184\171\224\184\165\224\184\177\224\184\135\224\184\136\224\184\178\224\184\129\224\184\153\224\184\177\224\185\137\224\184\153\224\184\150\224\184\173\224\184\148\224\184\173\224\184\173\224\184\129 / \224\185\131\224\184\170\224\185\136\224\184\129\224\184\165\224\184\177\224\184\154\224\184\159\224\184\163\224\184\181 \194\183 \224\184\129\224\184\148 Confirm \224\184\149\224\184\173\224\184\153\224\185\129\224\184\149\224\185\136\224\184\135\224\185\128\224\184\170\224\184\163\224\185\135\224\184\136\224\184\136\224\184\182\224\184\135\224\184\136\224\185\136\224\184\178\224\184\162" or ("\224\184\130\224\184\173\224\184\135\224\185\129\224\184\149\224\185\136\224\184\135\224\185\128\224\184\170\224\184\163\224\184\180\224\184\161 \224\184\138\224\184\180\224\185\137\224\184\153\224\184\165\224\184\176 %s \194\183 \224\184\139\224\184\183\224\185\137\224\184\173\224\184\132\224\184\163\224\184\177\224\185\137\224\184\135\224\185\128\224\184\148\224\184\181\224\184\162\224\184\167\224\184\149\224\185\136\224\184\173\224\184\132\224\184\177\224\184\153 \224\184\150\224\184\173\224\184\148\224\184\173\224\184\173\224\184\129 / \224\185\131\224\184\170\224\185\136\224\184\129\224\184\165\224\184\177\224\184\154\224\184\159\224\184\163\224\184\181 \194\183 \224\184\129\224\184\148 Confirm \224\184\149\224\184\173\224\184\153\224\185\129\224\184\149\224\185\136\224\184\135\224\185\128\224\184\170\224\184\163\224\185\135\224\184\136\224\184\136\224\184\182\224\184\135\224\184\136\224\185\136\224\184\178\224\184\162"):format(v_u_11.priceText(v_u_112.Accessory))
	end
end
local function v_u_207() -- name: buildAccRows
	-- upvalues: (copy) v_u_97, (copy) v_u_113, (copy) v_u_5, (copy) v_u_1, (ref) v_u_95, (copy) v_u_144, (copy) v_u_168
	for _, v196 in v_u_97 do
		v196.frame:Destroy()
	end
	table.clear(v_u_97)
	for v197, v_u_198 in v_u_113.acc or {} do
		local v199 = v_u_5.accessory(v_u_198)
		local v200 = v_u_1.new("Frame")
		v200.Name = "Row" .. v_u_198
		v200.BackgroundTransparency = 1
		v200.LayoutOrder = v197
		v200.Size = UDim2.new(1, -8, 0, 48)
		v200.Parent = v_u_95
		local v201 = v_u_113.model:GetAttribute("AccLabel_" .. v_u_198) or v199.th
		local v202 = UDim2.fromOffset(0, 0)
		local v203 = UDim2.new(1, -262, 1, 0)
		local v204 = v_u_1.new("TextLabel")
		v204.BackgroundTransparency = 1
		v204.Position = v202
		v204.Size = v203
		v204.Font = Enum.Font.GothamBold
		v204.TextSize = 17
		v204.TextWrapped = true
		v204.TextColor3 = Color3.fromRGB(200, 200, 200)
		v204.Text = v201
		v204.Parent = v200
		v204.TextXAlignment = Enum.TextXAlignment.Left
		v204.TextColor3 = Color3.new(1, 1, 1)
		v204.TextSize = 15
		if v199 then
			v199 = v199.remove == true
		end
		local v205 = v_u_144("On", v199 and "\224\184\150\224\184\173\224\184\148\224\184\173\224\184\173\224\184\129" or "\224\185\131\224\184\170\224\185\136", UDim2.new(1, -256, 0, 2), UDim2.fromOffset(150, 44), v200)
		v205.TextSize = 15
		local v206 = v_u_144("Off", v199 and "\224\185\131\224\184\170\224\185\136\224\185\132\224\184\167\224\185\137" or "\224\184\150\224\184\173\224\184\148", UDim2.new(1, -98, 0, 2), UDim2.fromOffset(92, 44), v200)
		v206.TextSize = 15
		v205.Activated:Connect(function()
			-- upvalues: (ref) v_u_168, (copy) v_u_198
			v_u_168("Accessory", v_u_198, true)
		end)
		v206.Activated:Connect(function()
			-- upvalues: (ref) v_u_168, (copy) v_u_198
			v_u_168("Accessory", v_u_198, false)
		end)
		v_u_97[v_u_198] = {
			["frame"] = v200,
			["name"] = v204,
			["on"] = v205,
			["off"] = v206
		}
	end
end
local function v_u_219() -- name: buildCarbonRows
	-- upvalues: (copy) v_u_93, (copy) v_u_113, (copy) v_u_5, (copy) v_u_1, (ref) v_u_92, (copy) v_u_144, (copy) v_u_168
	for _, v208 in v_u_93 do
		v208.frame:Destroy()
	end
	table.clear(v_u_93)
	for v209, v_u_210 in v_u_113.carbon or {} do
		local v211 = v_u_5.carbonPart(v_u_210)
		local v212 = v_u_1.new("Frame")
		v212.Name = "Row" .. v_u_210
		v212.BackgroundTransparency = 1
		v212.LayoutOrder = v209
		v212.Size = UDim2.new(1, -8, 0, 48)
		v212.Parent = v_u_92
		local v213 = v_u_113.model:GetAttribute("CarbonLabel_" .. v_u_210) or v211.th
		local v214 = UDim2.fromOffset(0, 0)
		local v215 = UDim2.new(1, -262, 1, 0)
		local v216 = v_u_1.new("TextLabel")
		v216.BackgroundTransparency = 1
		v216.Position = v214
		v216.Size = v215
		v216.Font = Enum.Font.GothamBold
		v216.TextSize = 17
		v216.TextWrapped = true
		v216.TextColor3 = Color3.fromRGB(200, 200, 200)
		v216.Text = v213
		v216.Parent = v212
		v216.TextXAlignment = Enum.TextXAlignment.Left
		v216.TextColor3 = Color3.new(1, 1, 1)
		v216.TextSize = 15
		local v217 = v_u_144("On", "\224\184\132\224\184\178\224\184\163\224\185\140\224\184\154\224\184\173\224\184\153", UDim2.new(1, -256, 0, 2), UDim2.fromOffset(150, 44), v212)
		v217.TextSize = 15
		local v218 = v_u_144("Off", "\224\185\128\224\184\148\224\184\180\224\184\161", UDim2.new(1, -98, 0, 2), UDim2.fromOffset(92, 44), v212)
		v218.TextSize = 15
		v217.Activated:Connect(function()
			-- upvalues: (ref) v_u_168, (copy) v_u_210
			v_u_168("Carbon", v_u_210, true)
		end)
		v218.Activated:Connect(function()
			-- upvalues: (ref) v_u_168, (copy) v_u_210
			v_u_168("Carbon", v_u_210, false)
		end)
		v_u_93[v_u_210] = {
			["frame"] = v212,
			["name"] = v216,
			["on"] = v217,
			["off"] = v218
		}
	end
end
local function v_u_234(p_u_220) -- name: buildPartRows
	-- upvalues: (copy) v_u_100, (ref) v_u_99, (copy) v_u_6, (copy) v_u_113, (copy) v_u_1, (copy) v_u_144, (copy) v_u_168
	for _, v221 in v_u_100 do
		v221.frame:Destroy()
	end
	table.clear(v_u_100)
	v_u_99.CanvasPosition = Vector2.zero
	local v222 = { false }
	for _, v223 in v_u_6.fitted(v_u_113.model:GetAttribute("VehicleId") or v_u_113.model.Name)[p_u_220] do
		table.insert(v222, v223)
	end
	local v224 = v_u_6.attr(p_u_220)
	if v224 then
		v224 = v_u_113.model:GetAttribute(v224)
	end
	if typeof(v224) == "string" and (v_u_6.RETIRED_KITS and (v_u_6.RETIRED_KITS[v224] and not table.find(v222, v224))) then
		table.insert(v222, v224)
	end
	for v225, v_u_226 in v222 do
		local v227
		if v_u_226 then
			v227 = v_u_6.KITS[v_u_226]
		else
			v227 = v_u_226
		end
		local v228 = v_u_1.new("Frame")
		v228.Name = "Row" .. tostring(v_u_226)
		v228.BackgroundTransparency = 1
		v228.LayoutOrder = v225
		v228.Size = UDim2.new(1, -8, 0, 48)
		v228.Parent = v_u_99
		local v229 = not v227 and "\224\184\130\224\184\173\224\184\135\224\185\128\224\184\148\224\184\180\224\184\161" or v227.th
		local v230 = UDim2.fromOffset(0, 0)
		local v231 = UDim2.new(1, -160, 1, 0)
		local v232 = v_u_1.new("TextLabel")
		v232.BackgroundTransparency = 1
		v232.Position = v230
		v232.Size = v231
		v232.Font = Enum.Font.GothamBold
		v232.TextSize = 17
		v232.TextWrapped = true
		v232.TextColor3 = Color3.fromRGB(200, 200, 200)
		v232.Text = v229
		v232.Parent = v228
		v232.TextXAlignment = Enum.TextXAlignment.Left
		v232.TextColor3 = Color3.new(1, 1, 1)
		v232.TextSize = 15
		local v233 = v_u_144("Use", "", UDim2.new(1, -152, 0, 2), UDim2.fromOffset(148, 44), v228)
		v233.TextSize = 15
		v233.Activated:Connect(function()
			-- upvalues: (ref) v_u_168, (ref) v_u_6, (copy) p_u_220, (copy) v_u_226
			v_u_168(v_u_6.REMOTE_ACTION, p_u_220, v_u_226 or nil)
		end)
		v_u_100[v225] = {
			["frame"] = v228,
			["button"] = v233,
			["kit"] = v_u_226,
			["price"] = not v227 and 0 or v227.price
		}
	end
end
local function v_u_242() -- name: shieldStock
	-- upvalues: (copy) v_u_113
	local v235 = v_u_113.tab
	if v235 then
		v235 = v_u_113.tab:match("^Tint_(.+)$")
	end
	if v235 and v_u_113.model then
		for _, v236 in v_u_113.model:GetDescendants() do
			if not v236:IsA("BasePart") or v236:GetAttribute("TintGroup") ~= v235 then
				continue
			end
			local v237 = v236:GetAttribute("TintBaseColor")
			local v238 = v236:GetAttribute("TintBaseTransparency")
			if typeof(v237) ~= "Color3" then
				v237 = v236.Color
			end
			if type(v238) == "number" then
				return v237, v238
			else
				return v237, v236.Transparency
			end
		end
	end
	if v_u_113.model then
		for _, v239 in v_u_113.model:GetDescendants() do
			if not (v239:IsA("BasePart") and v239:GetAttribute("Windshield")) then
				continue
			end
			local v240 = v239:GetAttribute("ShieldBaseColor")
			local v241 = v239:GetAttribute("ShieldBaseTransparency")
			if typeof(v240) ~= "Color3" then
				v240 = v239.Color
			end
			if type(v241) == "number" then
				return v240, v241
			else
				return v240, v239:GetAttribute("BaseTransparency") or v239.Transparency
			end
		end
	end
	return Color3.fromRGB(17, 17, 17), 0.7
end
local function v_u_250() -- name: shieldNow
	-- upvalues: (copy) v_u_242, (copy) v_u_113
	local v243, v244 = v_u_242()
	local v245 = v_u_113.tab
	if v245 then
		v245 = v_u_113.tab:match("^Tint_(.+)$")
	end
	local v246 = v_u_113.model
	if v246 then
		v246 = v_u_113.model:GetAttribute(not v245 and "ShieldColor" or "TintColor_" .. v245)
	end
	local v247 = v_u_113.model
	if v247 then
		v247 = v_u_113.model:GetAttribute(not v245 and "ShieldTransparency" or "TintClear_" .. v245)
	end
	local v248 = typeof(v246) == "Color3"
	local v249 = type(v247) == "number"
	if not v248 then
		v246 = v243
	end
	if v249 then
		v244 = v247
	end
	return v246, v244, v248, v249
end
local v_u_251 = 0
local function v_u_261() -- name: startSignalPreview
	-- upvalues: (copy) v_u_113, (ref) v_u_251
	if not v_u_113.preview and v_u_113.model then
		v_u_113.preview = {
			["before"] = v_u_113.model:GetAttribute("Indicator") or "Off"
		}
		local v_u_252 = v_u_113.model
		local v_u_253 = v_u_113.fire
		if v_u_252 then
			if not v_u_253 then
				return
			end
			v_u_251 = v_u_251 + 1
			local v_u_254 = v_u_251
			local v_u_255 = 0
			local v_u_256 = "Hazard"
			local function v_u_260() -- name: step
				-- upvalues: (copy) v_u_254, (ref) v_u_251, (copy) v_u_252, (copy) v_u_256, (ref) v_u_255, (copy) v_u_253, (copy) v_u_260
				if v_u_254 == v_u_251 and v_u_252.Parent then
					local v257 = v_u_252:GetAttribute("Indicator") or "Off"
					if v257 ~= v_u_256 and v_u_255 < 4 then
						v_u_255 = v_u_255 + 1
						local v258 = v_u_253
						local v259 = "Indicator"
						if v_u_256 ~= "Off" then
							v257 = v_u_256
						end
						v258(v259, v257)
						task.delay(0.3, v_u_260)
					end
				else
					return
				end
			end
			v_u_260()
		end
	end
end
local function v_u_464() -- name: refresh
	-- upvalues: (ref) v_u_53, (copy) v_u_195, (copy) v_u_17, (copy) v_u_65, (copy) v_u_113, (copy) v_u_49, (copy) v_u_48, (copy) v_u_130, (copy) v_u_39, (copy) v_u_1, (copy) v_u_30, (ref) v_u_98, (copy) v_u_234, (copy) v_u_6, (copy) v_u_100, (copy) v_u_11, (ref) v_u_55, (ref) v_u_52, (ref) v_u_56, (ref) v_u_60, (ref) v_u_71, (ref) v_u_91, (ref) v_u_94, (ref) v_u_101, (ref) v_u_102, (ref) v_u_105, (copy) v_u_8, (copy) v_u_33, (ref) v_u_107, (ref) v_u_106, (ref) v_u_103, (copy) v_u_112, (ref) v_u_104, (copy) v_u_108, (copy) v_u_31, (copy) v_u_97, (ref) v_u_73, (copy) v_u_5, (ref) v_u_74, (copy) v_u_75, (copy) v_u_76, (ref) v_u_77, (ref) v_u_78, (ref) v_u_79, (ref) v_u_85, (copy) v_u_250, (copy) v_u_242, (ref) v_u_80, (copy) v_u_82, (copy) v_u_81, (ref) v_u_83, (ref) v_u_84, (copy) v_u_93, (ref) v_u_61, (ref) v_u_86, (ref) v_u_87, (ref) v_u_64, (ref) v_u_63, (copy) v_u_10, (copy) v_u_22, (copy) v_u_66, (copy) v_u_67, (copy) v_u_69, (copy) v_u_68, (copy) v_u_136, (copy) v_u_34, (copy) v_u_90, (ref) v_u_72, (ref) v_u_54, (ref) v_u_57, (ref) v_u_58, (ref) v_u_59, (ref) v_u_111, (copy) v_u_163
	if v_u_53 then
		v_u_195()
		local v262 = {}
		for _, v263 in v_u_17 do
			local v264 = v_u_65[v263.id]
			local v265
			if v263.id == v_u_113.tab then
				v265 = v_u_49
			else
				v265 = v_u_48
			end
			v264.BackgroundColor3 = v265
			local v266
			if v_u_113.group == nil or v263.group == v_u_113.group then
				v266 = v_u_130(v263.id)
			else
				v266 = false
			end
			v264.Visible = v266
			if not v264.Visible then
				continue
			end
			table.insert(v262, v264)
		end
		local v267 = v_u_39.X - 32 - (#v262 - 1) * 8
		local v268 = #v262
		local v269 = v267 / math.max(v268, 1)
		local v270 = math.floor(v269)
		local v271 = math.min(96, v270)
		for v272, v273 in v262 do
			v273.Position = UDim2.fromOffset(16 + (v272 - 1) * (v271 + 8), 56)
			v273.Size = UDim2.fromOffset(v271, 44)
			v273.TextWrapped = v271 < 80
			v273.TextSize = v271 < 64 and 12 or (v271 < 80 and 14 or 18)
			v273.TextScaled = v271 < 56
			local v274 = v273:FindFirstChild("TabTextLimit")
			if v271 >= 56 or v274 then
				continue
			end
			local v275 = v_u_1.new("UITextSizeConstraint")
			v275.Name = "TabTextLimit"
			v275.MaxTextSize = 12
			v275.MinTextSize = 8
			v275.Parent = v273
		end
		local v276 = v_u_113.tab == "DRL"
		local v277 = v_u_113.tab == "Lower"
		local v278 = v_u_113.tab == "Glass"
		local v279 = v_u_113.tab == "Carbon"
		local v280 = v_u_113.tab == "Signals"
		local v281
		if v_u_113.tab == "Shield" then
			v281 = true
		else
			local v282 = v_u_113.tab
			if v282 then
				v282 = v_u_113.tab:match("^Tint_(.+)$")
			end
			v281 = v282 ~= nil
		end
		local v283 = v_u_30[v_u_113.tab]
		local v284 = v_u_113.tab == "Acc"
		local v285 = v_u_113.tab == "PopTune"
		local v286 = v277 or (v278 or (v279 or (v284 or (v285 or v283 ~= nil))))
		v_u_98.Visible = v283 ~= nil
		if v283 and v_u_113.model then
			local v287 = v_u_113.model
			local v288 = v283 .. "/" .. tostring(v287:GetAttribute("VehicleId"))
			if v_u_113.partRowsFor ~= v288 then
				v_u_113.partRowsFor = v288
				v_u_234(v283)
			end
			local v289 = v_u_113.model:GetAttribute(v_u_6.attr(v283))
			for _, v290 in v_u_100 do
				local v291 = (v290.kit or nil) == v289
				local v292 = v290.button
				local v293
				if v291 then
					v293 = v_u_49
				else
					v293 = v_u_48
				end
				v292.BackgroundColor3 = v293
				v290.button.Text = v291 and "\224\185\131\224\184\170\224\185\136\224\184\173\224\184\162\224\184\185\224\185\136" or (not v290.kit and "\224\184\159\224\184\163\224\184\181" or v_u_11.tunePriceText(v_u_113.model, "Part_" .. v290.kit, v290.price))
			end
		end
		local v294
		if v_u_113.pickerFolded == true and v_u_113.pickerShown == true then
			v294 = not v286
		else
			v294 = false
		end
		local v295 = v_u_55
		local v296 = not (v276 or (v280 or v281))
		if v296 then
			v296 = not v286
			if v296 then
				v296 = not v294
			end
		end
		v295.Visible = v296
		if v_u_55.Visible and v_u_52 then
			local v297 = v_u_113.model
			if v297 then
				v297 = v_u_113.model:GetAttribute("Paint" .. v_u_113.tab)
			end
			for _, v298 in v_u_52:GetChildren() do
				local v299 = v298:IsA("TextButton")
				if v299 then
					v299 = v298:FindFirstChildOfClass("UIStroke")
				end
				if not v299 then
					continue
				end
				local v300
				if typeof(v297) == "Color3" then
					local v301 = v298:GetAttribute("Color")
					local v302 = v297.R - v301.R
					if math.abs(v302) < 0.01 then
						local v303 = v297.G - v301.G
						if math.abs(v303) < 0.01 then
							local v304 = v297.B - v301.B
							v300 = math.abs(v304) < 0.01
						else
							v300 = false
						end
					else
						v300 = false
					end
				else
					v300 = false
				end
				v299.Thickness = v300 and 3 or 1
				v299.Transparency = v300 and 0 or 0.8
			end
		end
		local v305 = v_u_56
		local v306
		if v276 then
			v306 = not v294
		else
			v306 = v276
		end
		v305.Visible = v306
		v_u_60.Visible = v277
		v_u_71.Visible = v278
		v_u_91.Visible = v279
		v_u_94.Visible = v284
		v_u_101.Visible = v285
		if v285 then
			local v307 = v_u_6.popTuneOn(v_u_113.model)
			local v308 = v_u_6.popTuneBuiltIn(v_u_113.model)
			v_u_102.Visible = not v307
			local v309
			if v_u_113.model == nil then
				v309 = false
			else
				v309 = v_u_11.tuneOwned(v_u_113.model).PopTune ~= nil
			end
			v_u_105.Text = v308 and "\226\151\143  \224\184\161\224\184\178\224\184\129\224\184\177\224\184\154\224\184\163\224\184\150" or (v307 and "\226\151\143  ON" or (v309 and "OFF" or "LOCKED"))
			local v310 = v_u_105
			local v311
			if v307 then
				v311 = v_u_8.ACCENT_LIGHT
			else
				v311 = v_u_33
			end
			v310.TextColor3 = v311
			v_u_107.Visible = v307
			local v312 = v_u_106
			local v313
			if v307 then
				v313 = not v308
			else
				v313 = v307
			end
			v312.Visible = v313
			v_u_106.Text = v309 and "\224\184\155\224\184\180\224\184\148\224\184\136\224\184\185\224\184\153\224\184\162\224\184\180\224\184\135  \194\183  \224\185\128\224\184\155\224\184\180\224\184\148\224\185\131\224\184\171\224\184\161\224\185\136\224\184\159\224\184\163\224\184\181" or "\224\184\155\224\184\180\224\184\148\224\184\136\224\184\185\224\184\153\224\184\162\224\184\180\224\184\135"
			local v314 = v_u_107
			local v315
			if v_u_106.Visible then
				v315 = UDim2.new(0.5, -20, 0, 38)
			else
				v315 = UDim2.new(1, -32, 0, 38)
			end
			v314.Size = v315
			v_u_103.Text = v309 and "\224\185\128\224\184\155\224\184\180\224\184\148\224\184\173\224\184\181\224\184\129\224\184\132\224\184\163\224\184\177\224\185\137\224\184\135   \224\184\159\224\184\163\224\184\181" or "\224\185\128\224\184\155\224\184\180\224\184\148\224\185\131\224\184\138\224\185\137\224\184\135\224\184\178\224\184\153   " .. v_u_11.priceText(v_u_112.PopTune)
			v_u_104.Text = v309 and "\224\184\139\224\184\183\224\185\137\224\184\173\224\185\129\224\184\165\224\185\137\224\184\167\224\184\170\224\184\179\224\184\171\224\184\163\224\184\177\224\184\154\224\184\132\224\184\177\224\184\153\224\184\153\224\184\181\224\185\137 \194\183 \224\185\128\224\184\155\224\184\180\224\184\148 / \224\184\155\224\184\180\224\184\148\224\185\132\224\184\148\224\185\137\224\184\159\224\184\163\224\184\181\224\184\149\224\184\165\224\184\173\224\184\148 \224\185\132\224\184\161\224\185\136\224\184\149\224\185\137\224\184\173\224\184\135\224\184\139\224\184\183\224\185\137\224\184\173\224\185\131\224\184\171\224\184\161\224\185\136" or "\224\184\165\224\184\173\224\184\135\224\185\132\224\184\148\224\185\137\224\184\129\224\185\136\224\184\173\224\184\153 \224\184\136\224\185\136\224\184\178\224\184\162\224\184\149\224\184\173\224\184\153\224\184\129\224\184\148 Confirm \194\183 \224\184\139\224\184\183\224\185\137\224\184\173\224\184\132\224\184\163\224\184\177\224\185\137\224\184\135\224\185\128\224\184\148\224\184\181\224\184\162\224\184\167\224\184\149\224\185\136\224\184\173\224\184\132\224\184\177\224\184\153"
			for _, v316 in v_u_108 do
				local v317
				if v316.dragging or v316.wantAt and os.clock() - v316.wantAt < 1 then
					v317 = v316.want
				else
					v317 = v_u_6.popTune(v_u_113.model, v316.spec.key)
				end
				if not v316.dragging then
					local v318 = v316.spec
					local v319
					if v317 == nil then
						local v320
						if v_u_113.model == nil then
							v320 = false
						else
							v320 = v_u_113.model:GetAttribute("ExhaustPopFlame") == true
						end
						v319 = v320 and 75 or 0
					else
						v319 = v317
					end
					local v321 = (v319 - v318.min) / (v318.max - v318.min)
					v316.value = math.clamp(v321, 0, 1)
				end
				local v322
				if v307 then
					local v323 = v316.value * 20
					v322 = math.round(v323)
				else
					v322 = 0
				end
				for v324, v325 in v316.cells do
					local v326 = v324 <= v322
					local v327
					if v326 then
						v327 = v316.litColor(v324)
					else
						v327 = v_u_31
					end
					v325.BackgroundColor3 = v327
					v325.BackgroundTransparency = v326 and 0 or 0.9
				end
				v316.valueLabel.Text = not v307 and "\226\128\148" or (v317 == nil and "<font size=\"13\">\224\185\128\224\184\148\224\184\180\224\184\161</font>" or ("%d<font size=\"11\" color=\"#9497A5\">%%</font>"):format(v317))
			end
		end
		for v328, v329 in v_u_97 do
			local v330
			if v_u_113.model == nil then
				v330 = false
			else
				v330 = v_u_113.model:GetAttribute("Acc_" .. v328) == true
			end
			local v331 = v329.on
			local v332
			if v330 then
				v332 = v_u_49
			else
				v332 = v_u_48
			end
			v331.BackgroundColor3 = v332
			local v333 = v329.off
			local v334
			if v330 then
				v334 = v_u_48
			else
				v334 = v_u_49
			end
			v333.BackgroundColor3 = v334
		end
		local v335 = v_u_73
		local v336
		if v280 then
			v336 = not v294
		else
			v336 = v280
		end
		v335.Visible = v336
		if v280 then
			local v337 = v_u_5.blinkRate(v_u_113.model)
			local v338 = v_u_74
			if not v338.dragging then
				local v339 = v_u_5.BLINK_RATE_MAX
				local v340 = math.clamp(v337, 1, v339)
				local v341 = math.log(v340)
				local v342 = v_u_5.BLINK_RATE_MAX
				v338.value = v341 / math.log(v342)
			end
			if v338.dragging then
				local v343 = v338.value
				if v343 >= 0.985 then
					v337 = v_u_5.BLINK_RATE_MAX
				elseif v343 <= 0.01 then
					v337 = 1
				else
					local v344 = v_u_5.BLINK_RATE_MAX ^ v343 * 100
					v337 = math.round(v344) / 100
				end
			end
			v338.knob.Position = UDim2.fromScale(v338.value, 0.5)
			v338.fill.Size = UDim2.fromScale(v338.value, 1)
			v338.readout.Text = v_u_5.BLINK_RATE_MAX <= v337 and "\224\184\132\224\185\137\224\184\178\224\184\135  (\224\185\132\224\184\161\224\185\136\224\184\129\224\184\163\224\184\176\224\184\158\224\184\163\224\184\180\224\184\154)" or ("%s  x%.1f  \194\183  %.1f \224\184\132\224\184\163\224\184\177\224\185\137\224\184\135/\224\184\167\224\184\180\224\184\153\224\184\178\224\184\151\224\184\181"):format(v337 <= 1.001 and "\224\184\155\224\184\129\224\184\149\224\184\180" or "\224\185\128\224\184\163\224\185\135\224\184\167\224\184\130\224\184\182\224\185\137\224\184\153", v337, v337 / v_u_5.BLINK_PERIOD)
			for _, v345 in v_u_75 do
				local v346 = v345.button
				local v347 = v345.rate - v337
				local v348
				if math.abs(v347) < 0.05 then
					v348 = v_u_49
				else
					v348 = v_u_48
				end
				v346.BackgroundColor3 = v348
			end
			local v349 = v_u_5.signalColor(v_u_113.model)
			local v350 = nil
			for _, v351 in v_u_76 do
				local v352
				if v350 == nil then
					local v353 = v351.color
					local v354 = v353.R - v349.R
					if math.abs(v354) < 0.01 then
						local v355 = v353.G - v349.G
						if math.abs(v355) < 0.01 then
							local v356 = v353.B - v349.B
							v352 = math.abs(v356) < 0.01
						else
							v352 = false
						end
					else
						v352 = false
					end
				else
					v352 = false
				end
				v351.stroke.Transparency = v352 and 0 or 0.6
				v351.stroke.Thickness = v352 and 3 or 1
				if not v352 then
					continue
				end
				v350 = v351.label
			end
			v_u_77.Text = v350 or "\224\184\129\224\184\179\224\184\171\224\184\153\224\184\148\224\185\128\224\184\173\224\184\135"
			local v357 = v_u_78
			local v358
			if v_u_113.pickerShown then
				v358 = v_u_49
			else
				v358 = v_u_48
			end
			v357.BackgroundColor3 = v358
			v_u_78.Dot.BackgroundColor3 = v349
			v_u_78.Dot.Visible = v350 == nil
		end
		local v359 = v_u_79
		local v360
		if v281 then
			v360 = not v294
		else
			v360 = v281
		end
		v359.Visible = v360
		if v281 then
			local v361 = v_u_85
			local v362 = v_u_113.tab
			if v362 then
				v362 = v_u_113.tab:match("^Tint_(.+)$")
			end
			local v363
			if v362 then
				local v364 = "\224\184\170\224\184\181"
				local v365 = v_u_11.tintLabel
				local v366 = v_u_113.tab
				if v366 then
					v366 = v_u_113.tab:match("^Tint_(.+)$")
				end
				v363 = v364 .. v365(v366)
			else
				v363 = "\224\184\170\224\184\181\224\184\138\224\184\180\224\184\167"
			end
			v361.Text = v363
			local v367, v368, v369, v370 = v_u_250()
			local v371 = v_u_242()
			local v372 = v_u_80
			if not v372.dragging then
				v372.value = v368 / v_u_11.SHIELD_CLEAR_MAX
			end
			if v372.dragging then
				v368 = v372.value * v_u_11.SHIELD_CLEAR_MAX
			end
			v372.knob.Position = UDim2.fromScale(v372.value, 0.5)
			v372.fill.Size = UDim2.fromScale(v372.value, 1)
			local v373 = v_u_11.tuneOwned(v_u_113.model)
			local v374 = v372.readout
			local v375 = "\224\185\131\224\184\170 %d%%  \194\183  %s"
			local v376 = v368 * 100
			local v377 = math.round(v376)
			local v378 = v370 or v372.dragging
			local v379 = v_u_113.tab
			if v379 then
				v379 = v_u_113.tab:match("^Tint_(.+)$")
			end
			local v380
			if v379 then
				v380 = v_u_11.tintClearKey(v379, v368)
			else
				v380 = v_u_11.shieldClearKey(v368)
			end
			local v381 = v_u_112.ShieldClear
			v374.Text = v375:format(v377, not v378 and "\224\184\159\224\184\163\224\184\181" or (v373[v380] and "\224\184\136\224\185\136\224\184\178\224\184\162\224\185\129\224\184\165\224\185\137\224\184\167" or v_u_11.priceText(v381) .. " \224\184\149\224\184\173\224\184\153 Confirm"))
			for _, v382 in v_u_82 do
				local v383
				if v382.stock then
					v383 = not v370
					if v383 then
						v383 = not v372.dragging
					end
				else
					v383 = v370 or v372.dragging
					if v383 then
						local v384 = v382.t - v368
						v383 = math.abs(v384) < 0.01
					end
				end
				local v385 = v382.button
				local v386
				if v383 then
					v386 = v_u_49
				else
					v386 = v_u_48
				end
				v385.BackgroundColor3 = v386
			end
			local v387 = nil
			for _, v388 in v_u_81 do
				if v388.stock then
					v388.button.BackgroundColor3 = v371
				end
				local v389
				if v387 == nil then
					if v388.stock then
						v389 = not v369
					elseif v369 then
						local v390 = v388.color
						local v391 = v390.R - v367.R
						if math.abs(v391) < 0.01 then
							local v392 = v390.G - v367.G
							if math.abs(v392) < 0.01 then
								local v393 = v390.B - v367.B
								v389 = math.abs(v393) < 0.01
							else
								v389 = false
							end
						else
							v389 = false
						end
					else
						v389 = v369
					end
				else
					v389 = false
				end
				v388.stroke.Transparency = v389 and 0 or 0.6
				v388.stroke.Thickness = v389 and 3 or 1
				if not v389 then
					continue
				end
				v387 = v388.label
			end
			local v394 = v_u_83
			local v395 = v387 or "\224\184\129\224\184\179\224\184\171\224\184\153\224\184\148\224\185\128\224\184\173\224\184\135"
			local v396 = "  \194\183  "
			local v397
			if v369 then
				local v398 = v_u_113.tab
				if v398 then
					v398 = v_u_113.tab:match("^Tint_(.+)$")
				end
				if v398 then
					v397 = v_u_11.tintColorKey(v398, v367)
				else
					v397 = v_u_11.shieldColorKey(v367)
				end
			else
				v397 = ""
			end
			local v399 = v_u_112.ShieldColor
			v394.Text = v395 .. v396 .. (not v369 and "\224\184\159\224\184\163\224\184\181" or (v373[v397] and "\224\184\136\224\185\136\224\184\178\224\184\162\224\185\129\224\184\165\224\185\137\224\184\167" or v_u_11.priceText(v399) .. " \224\184\149\224\184\173\224\184\153 Confirm"))
			local v400 = v_u_84
			local v401
			if v_u_113.pickerShown then
				v401 = v_u_49
			else
				v401 = v_u_48
			end
			v400.BackgroundColor3 = v401
			v_u_84.Dot.BackgroundColor3 = v367
			v_u_84.Dot.Visible = v387 == nil
		end
		for v402, v403 in v_u_93 do
			local v404
			if v_u_113.model == nil then
				v404 = false
			else
				v404 = v_u_113.model:GetAttribute("Carbon_" .. v402) == true
			end
			local v405 = v403.on
			local v406
			if v404 then
				v406 = v_u_49
			else
				v406 = v_u_48
			end
			v405.BackgroundColor3 = v406
			local v407 = v403.off
			local v408
			if v404 then
				v408 = v_u_48
			else
				v408 = v_u_49
			end
			v407.BackgroundColor3 = v408
		end
		local v409 = v_u_61
		local v410 = not v286
		if v410 then
			if v280 or v281 then
				v410 = v_u_113.pickerShown == true
			else
				v410 = not v_u_113.pickerFolded or v_u_113.pickerShown == true
			end
		end
		v409.Visible = v410
		local v411 = v_u_86
		local v412
		if v280 then
			v412 = "\224\184\170\224\184\181\224\185\132\224\184\159\224\185\128\224\184\165\224\184\181\224\185\137\224\184\162\224\184\167 (\224\184\165\224\184\178\224\184\129\224\185\128\224\184\165\224\184\183\224\184\173\224\184\129)"
		elseif v281 then
			local v413 = v_u_113.tab
			if v413 then
				v413 = v_u_113.tab:match("^Tint_(.+)$")
			end
			if v413 then
				local v414 = "\224\184\170\224\184\181"
				local v415 = v_u_11.tintLabel
				local v416 = v_u_113.tab
				if v416 then
					v416 = v_u_113.tab:match("^Tint_(.+)$")
				end
				v412 = v414 .. v415(v416) .. " (\224\184\165\224\184\178\224\184\129\224\185\128\224\184\165\224\184\183\224\184\173\224\184\129)"
			else
				v412 = "\224\184\170\224\184\181\224\184\138\224\184\180\224\184\167 (\224\184\165\224\184\178\224\184\129\224\185\128\224\184\165\224\184\183\224\184\173\224\184\129)"
			end
		else
			v412 = "Custom color (drag)"
		end
		v411.Text = v412
		v_u_87.Text = (v280 or v281) and "\224\185\131\224\184\138\224\185\137\224\184\170\224\184\181\224\184\153\224\184\181\224\185\137" or "Use this color"
		local v417 = v_u_64
		local v418
		if v_u_113.pickerFolded == true then
			v418 = not v286
		else
			v418 = false
		end
		v417.Visible = v418
		local v419 = v_u_64
		local v420
		if v_u_113.pickerShown then
			v420 = v_u_49
		else
			v420 = v_u_48
		end
		v419.BackgroundColor3 = v420
		local v421 = v_u_63
		local v422
		if v276 then
			v422 = (v_u_113.model and v_u_113.model:GetAttribute("DRLStyle") or "Rainbow") == "Gradient"
		else
			v422 = v276
		end
		v421.Visible = v422
		local v423 = v_u_11.passLocked(v_u_10, "Custom")
		v_u_22(v_u_66.Chrome, v423)
		v_u_22(v_u_67.Gradient, v423)
		local v424 = v_u_22
		local v425 = v_u_61
		if v425 then
			v425 = v_u_61:FindFirstChild("Apply")
		end
		v424(v425, v423)
		for v426, v427 in v_u_69 do
			local v428
			if v426 == v_u_113.slot then
				v428 = v_u_49
			else
				v428 = v_u_48
			end
			v427.BackgroundColor3 = v428
		end
		for _, v429 in v_u_68 do
			v429.Visible = v_u_113.tab == "Shock"
			local v430
			if v429:GetAttribute("Whole") == v_u_113.wholeShock then
				v430 = v_u_49
			else
				v430 = v_u_48
			end
			v429.BackgroundColor3 = v430
		end
		if v277 then
			local v431 = v_u_113.model
			local v432 = v431 and (v431:GetAttribute("LowerLevel") or 0) or 0
			local v433, v434
			if v431 then
				v433, v434 = v_u_5.lowerSteps(v431)
			else
				v434 = 0
				v433 = 0
			end
			for v435, v436 in v_u_136 do
				if not v436.dragging then
					local v437
					if v431 then
						v437 = v431:GetAttribute("Lower" .. v435) or v432
					else
						v437 = v432
					end
					v436.value = v437 / v_u_5.LOWER_LEVELS
				end
				local v438
				if v435 == "Front" then
					v438 = v433
				else
					v438 = v434
				end
				local v439 = v438 * v_u_5.LOWER_LEVELS * 28
				v436.knob.Position = UDim2.fromScale(v436.value, 0.5)
				v436.fill.Size = UDim2.fromScale(v436.value, 1)
				v436.readout.Text = v439 < 0.5 and "This bike can\'t be lowered" or ("Lowered %.1f / %.1f cm"):format(v436.value * v439, v439)
				v436.track.Active = v439 >= 0.5
			end
			return
		elseif v278 then
			local v440 = v_u_113.model
			local v441 = 112
			for _, v442 in v_u_34 do
				local v443 = v_u_90[v442.id]
				local v444
				if v_u_113.glass == nil then
					v444 = false
				else
					v444 = v_u_113.glass[v442.id] == true
				end
				local v445 = v443.name
				local v446 = v443.on
				local v447 = v443.off
				v445.Visible = v444
				v446.Visible = v444
				v447.Visible = v444
				if not v444 then
					continue
				end
				local v448
				if v442.id == "Shield" then
					v448 = v440:GetAttribute("ShieldOff") ~= true
				else
					v448 = v440:GetAttribute("ShowMirrors") == true
				end
				v443.name.Position = UDim2.fromOffset(16, v441)
				v443.on.Position = UDim2.fromOffset(16, v441 + 34)
				v443.off.Position = UDim2.fromOffset(274, v441 + 34)
				local v449 = v443.on
				local v450
				if v448 then
					v450 = v_u_49
				else
					v450 = v_u_48
				end
				v449.BackgroundColor3 = v450
				local v451 = v443.off
				local v452
				if v448 then
					v452 = v_u_48
				else
					v452 = v_u_49
				end
				v451.BackgroundColor3 = v452
				v441 = v441 + 104
			end
			v_u_72.Position = UDim2.fromOffset(16, v441 + 4)
			return
		elseif v284 or v285 then
			v_u_54.Text = ""
			return
		elseif v276 then
			local v453 = v_u_113.model and v_u_113.model:GetAttribute("DRLStyle") or "Rainbow"
			local v454 = v_u_113.model
			if v454 then
				v454 = v_u_113.model:GetAttribute("RainbowOn") == true
			end
			for v455, v456 in v_u_67 do
				local v457
				if v454 and v455 == v453 then
					v457 = v_u_49
				else
					v457 = v_u_48
				end
				v456.BackgroundColor3 = v457
			end
			v_u_57.Visible = v453 == "Solid"
			v_u_58.Visible = v453 == "Gradient"
			v_u_59.Visible = v453 == "Rainbow"
			v_u_111:setVisible(v453 == "Mode")
			v_u_111:refresh(v_u_113.model)
		else
			for v458, v459 in v_u_66 do
				local v460
				if v458 == v_u_113.finish then
					v460 = v_u_49
				else
					v460 = v_u_48
				end
				v459.BackgroundColor3 = v460
			end
			local v461 = v_u_163(v_u_113.tab) > 0
			local v462 = v_u_113.tab
			for _, v463 in v_u_17 do
				if v463.id ~= v_u_113.tab then
					continue
				end
				v462 = v463.label
			end
			v_u_54.Text = v461 and "" or ("This bike has no separate %s parts to paint"):format(v462)
			v_u_55.Swatches.Visible = v461
		end
	else
		return
	end
end
local function v_u_478(p465, p466) -- name: popStep
	-- upvalues: (copy) v_u_6, (copy) v_u_113, (copy) v_u_109, (ref) v_u_110, (copy) v_u_168, (copy) v_u_464
	if v_u_6.popTuneOn(v_u_113.model) then
		local v467
		if p465.dragging or p465.wantAt and os.clock() - p465.wantAt < 1 then
			v467 = p465.want
		else
			v467 = v_u_6.popTune(v_u_113.model, p465.spec.key)
		end
		if v467 == nil then
			local v468
			if v_u_113.model == nil then
				v468 = false
			else
				v468 = v_u_113.model:GetAttribute("ExhaustPopFlame") == true
			end
			v467 = v468 and 75 or 0
		end
		local v469 = math.round(v467) + p466
		local v470 = p465.spec.min
		local v471 = p465.spec.max
		local v472 = math.clamp(v469, v470, v471)
		local v473 = os.clock()
		p465.want = v472
		p465.wantAt = v473
		local v474 = v_u_109
		local v475 = p465.spec.key
		if v472 == nil then
			v472 = false
		end
		v474[v475] = v472
		if not v_u_110 then
			v_u_110 = true
			task.spawn(function()
				-- upvalues: (ref) v_u_109, (ref) v_u_168, (ref) v_u_110, (ref) v_u_464
				while next(v_u_109) ~= nil do
					local v476
					if v_u_109.On == nil then
						if v_u_109.Reset == nil then
							v476 = next(v_u_109)
						else
							v476 = "Reset"
						end
					else
						v476 = "On"
					end
					local v477 = v_u_109[v476]
					v_u_109[v476] = nil
					v_u_168("PopTune", v476, v477)
					task.wait(0.2)
				end
				v_u_110 = false
				task.delay(0.3, v_u_464)
			end)
		end
		v_u_464()
		task.delay(1.05, v_u_464)
	end
end
local function v_u_484() -- name: popResetAll
	-- upvalues: (copy) v_u_109, (copy) v_u_108, (ref) v_u_110, (copy) v_u_168, (copy) v_u_464
	table.clear(v_u_109)
	v_u_109.Reset = true
	for _, v479 in v_u_108 do
		local v480 = v479.spec.default
		local v481 = os.clock()
		v479.want = v480
		v479.wantAt = v481
	end
	if not v_u_110 then
		v_u_110 = true
		task.spawn(function()
			-- upvalues: (ref) v_u_109, (ref) v_u_168, (ref) v_u_110, (ref) v_u_464
			while next(v_u_109) ~= nil do
				local v482
				if v_u_109.On == nil then
					if v_u_109.Reset == nil then
						v482 = next(v_u_109)
					else
						v482 = "Reset"
					end
				else
					v482 = "On"
				end
				local v483 = v_u_109[v482]
				v_u_109[v482] = nil
				v_u_168("PopTune", v482, v483)
				task.wait(0.2)
			end
			v_u_110 = false
			task.delay(0.3, v_u_464)
		end)
	end
	v_u_464()
	task.delay(1.05, v_u_464)
end
local function v_u_485() -- name: updatePicker
	-- upvalues: (ref) v_u_61, (ref) v_u_88, (copy) v_u_113, (ref) v_u_62, (ref) v_u_89
	if v_u_61 then
		v_u_88:set(v_u_113.h, v_u_113.s, v_u_113.v)
		v_u_62.BackgroundColor3 = Color3.fromHSV(v_u_113.h, v_u_113.s, v_u_113.v)
		if not v_u_89:IsFocused() then
			v_u_89.Text = "#" .. Color3.fromHSV(v_u_113.h, v_u_113.s, v_u_113.v):ToHex():upper()
		end
	end
end
local function v_u_488() -- name: currentColor
	-- upvalues: (copy) v_u_113, (copy) v_u_5, (copy) v_u_250
	local v486 = v_u_113.model
	if v486 then
		if v_u_113.tab == "DRL" then
			if v_u_113.slot == 2 then
				return v486:GetAttribute("DRLColor2")
			else
				return v486:GetAttribute("DRLColor")
			end
		else
			if v_u_113.tab == "Signals" then
				return v_u_5.signalColor(v486)
			end
			if v_u_113.tab ~= "Shield" then
				local v487 = v_u_113.tab
				if v487 then
					v487 = v_u_113.tab:match("^Tint_(.+)$")
				end
				if not v487 then
					return v486:GetAttribute("Paint" .. v_u_113.tab)
				end
			end
			return v_u_250()
		end
	else
		return nil
	end
end
local function v_u_499() -- name: applyPicked
	-- upvalues: (copy) v_u_11, (copy) v_u_10, (copy) v_u_14, (copy) v_u_15, (copy) v_u_113, (copy) v_u_168, (copy) v_u_464, (copy) v_u_46
	if v_u_11.passLocked(v_u_10, "Custom") then
		v_u_14.show("That\'s in the Custom pass", "info")
		v_u_15.open("Passes")
		return
	else
		local v489 = Color3.fromHSV(v_u_113.h, v_u_113.s, v_u_113.v)
		if v_u_113.tab == "Signals" then
			v_u_168("SignalColor", v489)
			task.delay(0.2, v_u_464)
		else
			if v_u_113.tab ~= "Shield" then
				local v490 = v_u_113.tab
				if v490 then
					v490 = v_u_113.tab:match("^Tint_(.+)$")
				end
				if not v490 then
					if v_u_113.tab == "DRL" then
						if (v_u_113.model and v_u_113.model:GetAttribute("DRLStyle") or "Rainbow") == "Gradient" and v_u_113.model:GetAttribute("RainbowOn") == true then
							local v491 = v_u_113.model:GetAttribute("DRLColor") or v_u_46[1][1]
							local v492 = v_u_113.model:GetAttribute("DRLColor2") or v_u_46[1][2]
							if v_u_113.slot ~= 2 then
								v491 = v489
								v489 = v492
							end
							v_u_168("DRL", "Gradient", v491, v489)
						else
							v_u_168("DRL", "Solid", v489)
						end
						task.delay(0.2, v_u_464)
					elseif v_u_113.tab ~= "Lower" then
						local v493 = v_u_168
						local v494 = "Paint"
						local v495 = v_u_113.tab
						local v496 = v_u_113.finish
						local v497
						if v_u_113.tab == "Shock" then
							v497 = v_u_113.wholeShock
						else
							v497 = false
						end
						v493(v494, v495, v489, v496, v497)
					end
				end
			end
			local v498 = v_u_113.tab
			if v498 then
				v498 = v_u_113.tab:match("^Tint_(.+)$")
			end
			if v498 then
				v_u_168("TintColor", v498, v489)
			else
				v_u_168("ShieldColor", v489)
			end
			task.delay(0.2, v_u_464)
		end
	end
end
local function v_u_519(p500) -- name: selectTab
	-- upvalues: (copy) v_u_113, (copy) v_u_261, (ref) v_u_251, (copy) v_u_5, (copy) v_u_488, (copy) v_u_485, (copy) v_u_464
	v_u_113.tab = p500
	v_u_113.pickerShown = false
	if p500 == "Signals" then
		v_u_261()
	else
		local v501 = v_u_113.preview
		v_u_113.preview = nil
		if v501 then
			local v_u_502 = v501.before
			local v_u_503 = v_u_113.model
			local v_u_504 = v_u_113.fire
			if v_u_503 and v_u_504 then
				v_u_251 = v_u_251 + 1
				local v_u_505 = v_u_251
				local v_u_506 = 0
				local function v_u_510() -- name: step
					-- upvalues: (copy) v_u_505, (ref) v_u_251, (copy) v_u_503, (copy) v_u_502, (ref) v_u_506, (copy) v_u_504, (copy) v_u_510
					if v_u_505 == v_u_251 and v_u_503.Parent then
						local v507 = v_u_503:GetAttribute("Indicator") or "Off"
						if v507 ~= v_u_502 and v_u_506 < 4 then
							v_u_506 = v_u_506 + 1
							local v508 = v_u_504
							local v509 = "Indicator"
							if v_u_502 ~= "Off" then
								v507 = v_u_502
							end
							v508(v509, v507)
							task.delay(0.3, v_u_510)
						end
					else
						return
					end
				end
				v_u_510()
			end
		end
	end
	local v511 = v_u_113.model and table.find(v_u_5.PAINT_GROUPS, p500)
	if v511 then
		v511 = v_u_113.model:GetAttribute("Finish" .. p500)
	end
	if v511 then
		v_u_113.finish = v511
	end
	if v_u_113.model and p500 == "Shock" then
		v_u_113.wholeShock = v_u_113.model:GetAttribute("PaintWholeShock") == true
	end
	local v512 = v_u_488()
	if typeof(v512) == "Color3" then
		local v513 = v_u_113
		local v514 = v_u_113
		local v515 = v_u_113
		local v516, v517, v518 = v512:ToHSV()
		v513.h = v516
		v514.s = v517
		v515.v = v518
	end
	v_u_485()
	v_u_464()
end
local function v_u_528(p520) -- name: selectStyle
	-- upvalues: (copy) v_u_168, (copy) v_u_113, (copy) v_u_5, (copy) v_u_46, (ref) v_u_111, (copy) v_u_464
	if p520 == "Solid" then
		v_u_168("DRL", "Solid", v_u_113.model:GetAttribute("DRLColor") or v_u_5.DRL_DEFAULT_COLOR)
	elseif p520 == "Gradient" then
		local v521 = v_u_46[1]
		v_u_168("DRL", "Gradient", v_u_113.model:GetAttribute("DRLColor") or v521[1], v_u_113.model:GetAttribute("DRLColor2") or v521[2])
	elseif p520 == "Mode" then
		v_u_111:refresh(v_u_113.model)
		local v522 = v_u_168
		local v523 = "DRLMode"
		local v524 = v_u_111.mode
		local v525 = v_u_111.speed
		local v526 = v_u_111.split
		local v527
		if v_u_111.split then
			v527 = v_u_111.modeRight
		else
			v527 = nil
		end
		v522(v523, v524, v525, v526, v527, v_u_111.modeRear)
	else
		v_u_168("DRL", "Rainbow")
	end
	task.delay(0.2, v_u_464)
end
local function v_u_975() -- name: build
	-- upvalues: (ref) v_u_53, (copy) v_u_1, (copy) v_u_10, (copy) v_u_7, (copy) v_u_47, (copy) v_u_8, (copy) v_u_144, (copy) v_u_51, (ref) v_u_64, (copy) v_u_113, (copy) v_u_464, (copy) v_u_17, (copy) v_u_519, (copy) v_u_65, (ref) v_u_55, (ref) v_u_52, (copy) v_u_159, (copy) v_u_43, (copy) v_u_175, (ref) v_u_54, (copy) v_u_42, (copy) v_u_11, (copy) v_u_112, (copy) v_u_14, (copy) v_u_15, (copy) v_u_168, (copy) v_u_66, (copy) v_u_41, (copy) v_u_68, (copy) v_u_50, (ref) v_u_56, (copy) v_u_44, (copy) v_u_528, (copy) v_u_67, (ref) v_u_57, (copy) v_u_45, (ref) v_u_58, (copy) v_u_46, (ref) v_u_59, (ref) v_u_111, (copy) v_u_16, (copy) v_u_39, (ref) v_u_60, (copy) v_u_135, (copy) v_u_48, (copy) v_u_49, (copy) v_u_136, (copy) v_u_5, (copy) v_u_4, (ref) v_u_70, (ref) v_u_71, (copy) v_u_34, (copy) v_u_90, (ref) v_u_72, (ref) v_u_73, (ref) v_u_74, (copy) v_u_38, (copy) v_u_75, (ref) v_u_77, (copy) v_u_35, (copy) v_u_485, (copy) v_u_76, (ref) v_u_78, (ref) v_u_79, (ref) v_u_85, (ref) v_u_83, (copy) v_u_36, (copy) v_u_242, (copy) v_u_81, (ref) v_u_84, (copy) v_u_250, (ref) v_u_80, (copy) v_u_37, (copy) v_u_82, (ref) v_u_91, (ref) v_u_92, (ref) v_u_94, (ref) v_u_95, (ref) v_u_96, (ref) v_u_98, (ref) v_u_99, (ref) v_u_101, (copy) v_u_33, (ref) v_u_105, (copy) v_u_6, (copy) v_u_31, (copy) v_u_32, (copy) v_u_108, (copy) v_u_109, (ref) v_u_110, (copy) v_u_478, (ref) v_u_102, (copy) v_u_13, (ref) v_u_103, (ref) v_u_104, (ref) v_u_107, (copy) v_u_484, (ref) v_u_106, (ref) v_u_61, (ref) v_u_86, (ref) v_u_62, (ref) v_u_89, (copy) v_u_499, (ref) v_u_88, (copy) v_u_9, (ref) v_u_63, (copy) v_u_488, (copy) v_u_69, (ref) v_u_87
	v_u_53 = v_u_1.new("ScreenGui")
	v_u_53.Name = "PCX160Paint"
	v_u_53.ResetOnSpawn = false
	v_u_53.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
	v_u_53.DisplayOrder = 5
	v_u_53.Enabled = false
	v_u_53.Parent = v_u_10:WaitForChild("PlayerGui")
	v_u_7.apply(v_u_53)
	local v529 = v_u_1.new("Frame")
	v529.Name = "Panel"
	v529.AnchorPoint = Vector2.new(0.5, 0.5)
	v529.Position = UDim2.fromScale(0.5, 0.55)
	v529.Size = UDim2.fromOffset(540, 436)
	v529.BackgroundColor3 = v_u_47
	v529.BackgroundTransparency = 0.1
	v529.Parent = v_u_53
	local v530 = v_u_1.new("UICorner")
	v530.CornerRadius = UDim.new(0, 16)
	v530.Parent = v529
	local v531 = UDim2.fromOffset(20, 10)
	local v532 = UDim2.fromOffset(200, 12)
	local v533 = v_u_1.new("TextLabel")
	v533.BackgroundTransparency = 1
	v533.Position = v531
	v533.Size = v532
	v533.Font = Enum.Font.GothamBold
	v533.TextSize = 17
	v533.TextWrapped = true
	v533.TextColor3 = Color3.fromRGB(200, 200, 200)
	v533.Text = "C\226\128\137U\226\128\137S\226\128\137T\226\128\137O\226\128\137M\226\128\137I\226\128\137Z\226\128\137E"
	v533.Parent = v529
	v533.Name = "Kicker"
	v533.TextSize = 11
	v533.TextColor3 = v_u_8.ACCENT_LIGHT
	v533.TextXAlignment = Enum.TextXAlignment.Left
	local v534 = UDim2.fromOffset(20, 18)
	local v535 = UDim2.new(1, -250, 0, 28)
	local v536 = v_u_1.new("TextLabel")
	v536.BackgroundTransparency = 1
	v536.Position = v534
	v536.Size = v535
	v536.Font = Enum.Font.GothamBold
	v536.TextSize = 17
	v536.TextWrapped = true
	v536.TextColor3 = Color3.fromRGB(200, 200, 200)
	v536.Text = "Bike Tuning"
	v536.Parent = v529
	v536.Font = Enum.Font.GothamBlack
	v536.TextSize = 21
	v536.TextColor3 = Color3.new(1, 1, 1)
	v536.TextXAlignment = Enum.TextXAlignment.Left
	local v537 = v_u_1.new("Frame")
	v537.Name = "TitleBar"
	v537.BorderSizePixel = 0
	v537.BackgroundColor3 = v_u_8.ACCENT
	v537.Position = UDim2.fromOffset(20, 46)
	v537.Size = UDim2.fromOffset(34, 3)
	v537.Parent = v529
	local v538 = v_u_1.new("UICorner")
	v538.CornerRadius = UDim.new(0, 2)
	v538.Parent = v537
	local v539 = v_u_1.new("Frame")
	v539.Name = "TabsLine"
	v539.BorderSizePixel = 0
	v539.BackgroundColor3 = Color3.new(1, 1, 1)
	v539.BackgroundTransparency = 0.92
	v539.Position = UDim2.fromOffset(16, 101)
	v539.Size = UDim2.new(1, -32, 0, 1)
	v539.Parent = v529
	v_u_144("Close", "Close", UDim2.new(1, -72, 0, 8), UDim2.fromOffset(60, 44), v529).Activated:Connect(function()
		-- upvalues: (ref) v_u_51
		v_u_51.close()
	end)
	v_u_64 = v_u_144("PickerToggle", "Custom color", UDim2.new(1, -184, 0, 8), UDim2.fromOffset(104, 44), v529)
	v_u_64.TextSize = 16
	v_u_64.Visible = false
	v_u_64.Activated:Connect(function()
		-- upvalues: (ref) v_u_113, (ref) v_u_464
		v_u_113.pickerShown = not v_u_113.pickerShown
		v_u_464()
	end)
	for v540, v_u_541 in v_u_17 do
		local v542 = v_u_144("Tab" .. v_u_541.id, v_u_541.label, UDim2.fromOffset(16 + (v540 - 1) * 104, 56), UDim2.fromOffset(96, 44), v529)
		v542.Activated:Connect(function()
			-- upvalues: (ref) v_u_519, (copy) v_u_541
			v_u_519(v_u_541.id)
		end)
		v_u_65[v_u_541.id] = v542
	end
	v_u_55 = v_u_1.new("Frame")
	v_u_55.Name = "PaintPage"
	v_u_55.BackgroundTransparency = 1
	v_u_55.Size = UDim2.fromScale(1, 1)
	v_u_55.Parent = v529
	v_u_52 = v_u_159("Swatches", v_u_43, UDim2.fromOffset(20, 116), UDim2.new(1, -40, 0, 156), v_u_55, v_u_175)
	local v543 = UDim2.fromOffset(16, 150)
	local v544 = UDim2.new(1, -32, 0, 60)
	local v545 = v_u_55
	local v546 = v_u_1.new("TextLabel")
	v546.BackgroundTransparency = 1
	v546.Position = v543
	v546.Size = v544
	v546.Font = Enum.Font.GothamBold
	v546.TextSize = 17
	v546.TextWrapped = true
	v546.TextColor3 = Color3.fromRGB(200, 200, 200)
	v546.Text = ""
	v546.Parent = v545
	v_u_54 = v546
	local v547 = UDim2.fromOffset(20, 252)
	local v548 = UDim2.fromOffset(200, 14)
	local v549 = v_u_55
	local v550 = v_u_1.new("TextLabel")
	v550.BackgroundTransparency = 1
	v550.Position = v547
	v550.Size = v548
	v550.Font = Enum.Font.GothamBold
	v550.TextSize = 17
	v550.TextWrapped = true
	v550.TextColor3 = Color3.fromRGB(200, 200, 200)
	v550.Text = "F\226\128\137I\226\128\137N\226\128\137I\226\128\137S\226\128\137H"
	v550.Parent = v549
	v550.Name = "FinishHead"
	v550.TextSize = 11
	v550.TextColor3 = Color3.fromRGB(148, 151, 165)
	v550.TextXAlignment = Enum.TextXAlignment.Left
	for v551, v_u_552 in v_u_42 do
		local v553 = v_u_144("Finish" .. v_u_552.id, v_u_552.label .. "  " .. v_u_11.priceText(v_u_112.Paint + (v_u_112.Finish[v_u_552.id] or 0)), UDim2.fromOffset(16 + (v551 - 1) * 140, 276), UDim2.fromOffset(128, 44), v_u_55)
		v553.TextSize = 15
		v553.Activated:Connect(function()
			-- upvalues: (copy) v_u_552, (ref) v_u_11, (ref) v_u_10, (ref) v_u_14, (ref) v_u_15, (ref) v_u_113, (ref) v_u_464, (ref) v_u_168
			local v554 = v_u_552.id
			if v554 == "Chrome" and v_u_11.passLocked(v_u_10, "Custom") then
				v_u_14.show("That\'s in the Custom pass", "info")
				v_u_15.open("Passes")
			else
				v_u_113.finish = v554
				v_u_464()
				local v555 = v_u_113.model
				if v555 then
					v555 = v_u_113.model:GetAttribute("Paint" .. v_u_113.tab)
				end
				if v555 then
					local v556 = v_u_168
					local v557 = "Paint"
					local v558 = v_u_113.tab
					local v559 = v_u_113.finish
					local v560
					if v_u_113.tab == "Shock" then
						v560 = v_u_113.wholeShock
					else
						v560 = false
					end
					v556(v557, v558, v555, v559, v560)
				end
			end
		end)
		v_u_66[v_u_552.id] = v553
	end
	for v561, v_u_562 in v_u_41 do
		local v563 = v_u_144("ShockTarget" .. v561, v_u_562.label, UDim2.fromOffset(16 + (v561 - 1) * 140, 328), UDim2.fromOffset(128, 44), v_u_55)
		v563:SetAttribute("Whole", v_u_562.id)
		v563.Activated:Connect(function()
			-- upvalues: (ref) v_u_113, (copy) v_u_562, (ref) v_u_464, (ref) v_u_168
			v_u_113.wholeShock = v_u_562.id
			v_u_464()
			local v564 = v_u_113.model
			if v564 then
				v564 = v_u_113.model:GetAttribute("PaintShock")
			end
			if v564 then
				local v565 = v_u_168
				local v566 = "Paint"
				local v567 = v_u_113.tab
				local v568 = v_u_113.finish
				local v569
				if v_u_113.tab == "Shock" then
					v569 = v_u_113.wholeShock
				else
					v569 = false
				end
				v565(v566, v567, v564, v568, v569)
			end
		end)
		local v570 = v_u_68
		table.insert(v570, v563)
	end
	local v571 = v_u_144("Reset", "Original color  (free)", UDim2.fromOffset(16, 380), UDim2.new(1, -32, 0, 44), v_u_55)
	v571.BackgroundColor3 = v_u_50
	v571.Activated:Connect(function()
		-- upvalues: (ref) v_u_168, (ref) v_u_113
		local v572 = v_u_168
		local v573 = "Paint"
		local v574 = v_u_113.tab
		local v575 = false
		local v576 = v_u_113.finish
		local v577
		if v_u_113.tab == "Shock" then
			v577 = v_u_113.wholeShock
		else
			v577 = false
		end
		v572(v573, v574, v575, v576, v577)
	end)
	v_u_56 = v_u_1.new("Frame")
	v_u_56.Name = "DrlPage"
	v_u_56.BackgroundTransparency = 1
	v_u_56.Size = UDim2.fromScale(1, 1)
	v_u_56.Visible = false
	v_u_56.Parent = v529
	for v578, v_u_579 in v_u_44 do
		local v580 = v_u_144("Style" .. v_u_579.id, v_u_579.label .. "  " .. v_u_11.priceText(v_u_112.Light[v_u_579.id]), UDim2.fromOffset(16 + (v578 - 1) * 127, 112), UDim2.fromOffset(119, 44), v_u_56)
		v580.TextSize = 14
		v580.Activated:Connect(function()
			-- upvalues: (ref) v_u_528, (copy) v_u_579
			v_u_528(v_u_579.id)
		end)
		v_u_67[v_u_579.id] = v580
	end
	v_u_57 = v_u_159("LedSwatches", v_u_45, UDim2.fromOffset(16, 168), UDim2.new(1, -32, 0, 148), v_u_56, function(p581)
		-- upvalues: (ref) v_u_168
		v_u_168("DRL", "Solid", p581)
	end)
	v_u_58 = v_u_1.new("Frame")
	v_u_58.Name = "Gradients"
	v_u_58.BackgroundTransparency = 1
	v_u_58.Position = UDim2.fromOffset(16, 168)
	v_u_58.Size = UDim2.new(1, -32, 0, 148)
	v_u_58.Parent = v_u_56
	local v582 = v_u_1.new("UIGridLayout")
	v582.CellSize = UDim2.fromOffset(128, 44)
	v582.CellPadding = UDim2.fromOffset(12, 10)
	v582.SortOrder = Enum.SortOrder.LayoutOrder
	v582.Parent = v_u_58
	for v583, v_u_584 in v_u_46 do
		local v585 = v_u_1.new("TextButton")
		v585.Name = "Gradient" .. v583
		v585.LayoutOrder = v583
		v585.Text = ""
		v585.BackgroundColor3 = Color3.new(1, 1, 1)
		v585.Parent = v_u_58
		local v586 = v_u_1.new("UICorner")
		v586.CornerRadius = UDim.new(0, 10)
		v586.Parent = v585
		local v587 = v_u_1.new("UIGradient")
		v587.Color = ColorSequence.new(v_u_584[1], v_u_584[2])
		v587.Parent = v585
		v585.Activated:Connect(function()
			-- upvalues: (ref) v_u_168, (copy) v_u_584
			v_u_168("DRL", "Gradient", v_u_584[1], v_u_584[2])
		end)
	end
	local v588 = UDim2.fromOffset(16, 180)
	local v589 = UDim2.new(1, -32, 0, 60)
	local v590 = v_u_56
	local v591 = v_u_1.new("TextLabel")
	v591.BackgroundTransparency = 1
	v591.Position = v588
	v591.Size = v589
	v591.Font = Enum.Font.GothamBold
	v591.TextSize = 17
	v591.TextWrapped = true
	v591.TextColor3 = Color3.fromRGB(200, 200, 200)
	v591.Text = "The rainbow flows from the middle of the V outward; the tail light follows"
	v591.Parent = v590
	v_u_59 = v591
	v_u_111 = v_u_16.new(v_u_56, UDim2.fromOffset(16, 166), v_u_39.X - 32, function(p592, p593, p594, p595, p596)
		-- upvalues: (ref) v_u_168
		v_u_168("DRLMode", p592, p593, p594, p595, p596)
	end)
	v_u_111:setVisible(false)
	local v597 = v_u_144("DrlOff", "Lights off (back to white)", UDim2.fromOffset(16, 380), UDim2.new(1, -32, 0, 44), v_u_56)
	v597.BackgroundColor3 = v_u_50
	v597.Activated:Connect(function()
		-- upvalues: (ref) v_u_168, (ref) v_u_464
		v_u_168("DRL", "Off")
		task.delay(0.2, v_u_464)
	end)
	v_u_60 = v_u_1.new("Frame")
	v_u_60.Name = "LowerPage"
	v_u_60.BackgroundTransparency = 1
	v_u_60.Size = UDim2.fromScale(1, 1)
	v_u_60.Visible = false
	v_u_60.Parent = v529
	for v598, v_u_599 in v_u_135 do
		local v600 = 112 + (v598 - 1) * 96
		local v601 = "Lower " .. v_u_599.label
		local v602 = UDim2.fromOffset(16, v600)
		local v603 = UDim2.fromOffset(120, 28)
		local v604 = v_u_60
		local v605 = v_u_1.new("TextLabel")
		v605.BackgroundTransparency = 1
		v605.Position = v602
		v605.Size = v603
		v605.Font = Enum.Font.GothamBold
		v605.TextSize = 17
		v605.TextWrapped = true
		v605.TextColor3 = Color3.fromRGB(200, 200, 200)
		v605.Text = v601
		v605.Parent = v604
		v605.TextXAlignment = Enum.TextXAlignment.Left
		v605.TextColor3 = Color3.new(1, 1, 1)
		local v606 = UDim2.new(0, 140, 0, v600)
		local v607 = UDim2.new(1, -156, 0, 28)
		local v608 = v_u_60
		local v609 = v_u_1.new("TextLabel")
		v609.BackgroundTransparency = 1
		v609.Position = v606
		v609.Size = v607
		v609.Font = Enum.Font.GothamBold
		v609.TextSize = 17
		v609.TextWrapped = true
		v609.TextColor3 = Color3.fromRGB(200, 200, 200)
		v609.Text = ""
		v609.Parent = v608
		v609.TextXAlignment = Enum.TextXAlignment.Right
		v609.TextSize = 15
		local v_u_610 = v_u_1.new("TextButton")
		v_u_610.Name = "Lower" .. v_u_599.id
		v_u_610.Text = ""
		v_u_610.AutoButtonColor = false
		v_u_610.BackgroundColor3 = v_u_48
		v_u_610.Position = UDim2.fromOffset(28, v600 + 40)
		v_u_610.Size = UDim2.new(1, -56, 0, 22)
		v_u_610.Parent = v_u_60
		local v611 = v_u_1.new("UICorner")
		v611.CornerRadius = UDim.new(0, 11)
		v611.Parent = v_u_610
		local v612 = v_u_1.new("Frame")
		v612.Name = "Fill"
		v612.BackgroundColor3 = v_u_49
		v612.Size = UDim2.fromScale(0, 1)
		v612.Parent = v_u_610
		local v613 = v_u_1.new("UICorner")
		v613.CornerRadius = UDim.new(0, 11)
		v613.Parent = v612
		local v614 = v_u_1.new("Frame")
		v614.Name = "Knob"
		v614.AnchorPoint = Vector2.new(0.5, 0.5)
		v614.Size = UDim2.fromOffset(34, 34)
		v614.BackgroundColor3 = Color3.new(1, 1, 1)
		v614.Parent = v_u_610
		local v615 = v_u_1.new("UICorner")
		v615.CornerRadius = UDim.new(0, 17)
		v615.Parent = v614
		local v_u_616 = {
			["track"] = nil,
			["fill"] = nil,
			["knob"] = nil,
			["readout"] = nil,
			["value"] = 0,
			["dragging"] = false,
			["sentAt"] = 0,
			["track"] = v_u_610,
			["fill"] = v612,
			["knob"] = v614,
			["readout"] = v609
		}
		v_u_136[v_u_599.id] = v_u_616
		local function v_u_619() -- name: send
			-- upvalues: (copy) v_u_616, (ref) v_u_168, (ref) v_u_5, (copy) v_u_599
			v_u_616.sentAt = os.clock()
			local v617 = v_u_168
			local v618 = v_u_616.value * v_u_5.LOWER_LEVELS * 100
			v617("Lower", math.round(v618) / 100, v_u_599.id)
		end
		v_u_610.InputBegan:Connect(function(p620)
			-- upvalues: (copy) v_u_610, (copy) v_u_616, (ref) v_u_168, (ref) v_u_5, (copy) v_u_599, (ref) v_u_464
			if v_u_610.Active and (p620.UserInputType == Enum.UserInputType.MouseButton1 or p620.UserInputType == Enum.UserInputType.Touch) then
				v_u_616.dragging = true
				local v621 = v_u_616
				local v622 = (p620.Position.X - v_u_610.AbsolutePosition.X) / v_u_610.AbsoluteSize.X
				v621.value = math.clamp(v622, 0, 1)
				if os.clock() - v_u_616.sentAt > 0.2 then
					v_u_616.sentAt = os.clock()
					local v623 = v_u_168
					local v624 = v_u_616.value * v_u_5.LOWER_LEVELS * 100
					v623("Lower", math.round(v624) / 100, v_u_599.id)
				end
				v_u_464()
			end
		end)
		v_u_4.InputChanged:Connect(function(p625)
			-- upvalues: (copy) v_u_616, (copy) v_u_610, (ref) v_u_168, (ref) v_u_5, (copy) v_u_599, (ref) v_u_464
			if v_u_616.dragging and (p625.UserInputType == Enum.UserInputType.MouseMovement or p625.UserInputType == Enum.UserInputType.Touch) then
				local v626 = v_u_616
				local v627 = (p625.Position.X - v_u_610.AbsolutePosition.X) / v_u_610.AbsoluteSize.X
				v626.value = math.clamp(v627, 0, 1)
				if os.clock() - v_u_616.sentAt > 0.2 then
					v_u_616.sentAt = os.clock()
					local v628 = v_u_168
					local v629 = v_u_616.value * v_u_5.LOWER_LEVELS * 100
					v628("Lower", math.round(v629) / 100, v_u_599.id)
				end
				v_u_464()
			end
		end)
		v_u_4.InputEnded:Connect(function(p630)
			-- upvalues: (copy) v_u_616, (copy) v_u_619, (ref) v_u_464
			if v_u_616.dragging and (p630.UserInputType == Enum.UserInputType.MouseButton1 or p630.UserInputType == Enum.UserInputType.Touch) then
				v_u_616.dragging = false
				local v631 = task.delay
				local v632 = 0.2 - (os.clock() - v_u_616.sentAt)
				v631(math.max(0, v632), v_u_619)
				task.delay(0.5, v_u_464)
			end
		end)
	end
	local v633 = v_u_144("LowerStock", "Stock height  (free)", UDim2.fromOffset(16, 312), UDim2.new(1, -32, 0, 44), v_u_60)
	v633.BackgroundColor3 = v_u_50
	v633.Activated:Connect(function()
		-- upvalues: (ref) v_u_168, (ref) v_u_464
		v_u_168("Lower", 0, "Front")
		task.delay(0.2, v_u_168, "Lower", 0, "Rear")
		task.delay(0.5, v_u_464)
	end)
	local v634 = ("Drag right to go lower, as low as this bike goes before the tire hits. Lowering kit %s, bought once for this bike: then any height, free"):format(v_u_11.priceText(v_u_112.Lower))
	local v635 = UDim2.fromOffset(16, 364)
	local v636 = UDim2.new(1, -32, 0, 56)
	local v637 = v_u_60
	local v638 = v_u_1.new("TextLabel")
	v638.BackgroundTransparency = 1
	v638.Position = v635
	v638.Size = v636
	v638.Font = Enum.Font.GothamBold
	v638.TextSize = 17
	v638.TextWrapped = true
	v638.TextColor3 = Color3.fromRGB(200, 200, 200)
	v638.Text = v634
	v638.Parent = v637
	v_u_70 = v638
	v_u_70.TextSize = 14
	v_u_71 = v_u_1.new("Frame")
	v_u_71.Name = "GlassPage"
	v_u_71.BackgroundTransparency = 1
	v_u_71.Size = UDim2.fromScale(1, 1)
	v_u_71.Visible = false
	v_u_71.Parent = v529
	for _, v_u_639 in v_u_34 do
		local v640 = v_u_639.label
		local v641 = UDim2.fromOffset(16, 112)
		local v642 = UDim2.new(1, -32, 0, 28)
		local v643 = v_u_71
		local v644 = v_u_1.new("TextLabel")
		v644.BackgroundTransparency = 1
		v644.Position = v641
		v644.Size = v642
		v644.Font = Enum.Font.GothamBold
		v644.TextSize = 17
		v644.TextWrapped = true
		v644.TextColor3 = Color3.fromRGB(200, 200, 200)
		v644.Text = v640
		v644.Parent = v643
		v644.TextXAlignment = Enum.TextXAlignment.Left
		v644.TextColor3 = Color3.new(1, 1, 1)
		local v645 = v_u_144(v_u_639.id .. "On", "Fitted", UDim2.fromOffset(16, 146), UDim2.fromOffset(250, 52), v_u_71)
		local v646 = v_u_144(v_u_639.id .. "Off", "Removed", UDim2.fromOffset(274, 146), UDim2.fromOffset(250, 52), v_u_71)
		v645.Activated:Connect(function()
			-- upvalues: (ref) v_u_168, (copy) v_u_639
			v_u_168(v_u_639.id, true)
		end)
		v646.Activated:Connect(function()
			-- upvalues: (ref) v_u_168, (copy) v_u_639
			v_u_168(v_u_639.id, false)
		end)
		v_u_90[v_u_639.id] = {
			["name"] = v644,
			["on"] = v645,
			["off"] = v646
		}
	end
	local v647 = UDim2.fromOffset(16, 216)
	local v648 = UDim2.new(1, -32, 0, 60)
	local v649 = v_u_71
	local v650 = v_u_1.new("TextLabel")
	v650.BackgroundTransparency = 1
	v650.Position = v647
	v650.Size = v648
	v650.Font = Enum.Font.GothamBold
	v650.TextSize = 17
	v650.TextWrapped = true
	v650.TextColor3 = Color3.fromRGB(200, 200, 200)
	v650.Text = "Free: take it off or put it back any time. The bike keeps it when you put it away."
	v650.Parent = v649
	v_u_72 = v650
	v_u_72.TextSize = 15
	v_u_73 = v_u_1.new("Frame")
	v_u_73.Name = "SignalsPage"
	v_u_73.BackgroundTransparency = 1
	v_u_73.Size = UDim2.fromScale(1, 1)
	v_u_73.Visible = false
	v_u_73.Parent = v529
	local v651 = UDim2.fromOffset(16, 112)
	local v652 = UDim2.fromOffset(170, 28)
	local v653 = v_u_73
	local v654 = v_u_1.new("TextLabel")
	v654.BackgroundTransparency = 1
	v654.Position = v651
	v654.Size = v652
	v654.Font = Enum.Font.GothamBold
	v654.TextSize = 17
	v654.TextWrapped = true
	v654.TextColor3 = Color3.fromRGB(200, 200, 200)
	v654.Text = "\224\184\132\224\184\167\224\184\178\224\184\161\224\185\132\224\184\167\224\185\132\224\184\159\224\185\128\224\184\165\224\184\181\224\185\137\224\184\162\224\184\167"
	v654.Parent = v653
	v654.TextXAlignment = Enum.TextXAlignment.Left
	v654.TextColor3 = Color3.new(1, 1, 1)
	local v655 = UDim2.new(0, 190, 0, 112)
	local v656 = UDim2.new(1, -206, 0, 28)
	local v657 = v_u_73
	local v658 = v_u_1.new("TextLabel")
	v658.BackgroundTransparency = 1
	v658.Position = v655
	v658.Size = v656
	v658.Font = Enum.Font.GothamBold
	v658.TextSize = 17
	v658.TextWrapped = true
	v658.TextColor3 = Color3.fromRGB(200, 200, 200)
	v658.Text = ""
	v658.Parent = v657
	v658.TextXAlignment = Enum.TextXAlignment.Right
	v658.TextSize = 15
	local v_u_659 = v_u_1.new("TextButton")
	v_u_659.Name = "BlinkRate"
	v_u_659.Text = ""
	v_u_659.AutoButtonColor = false
	v_u_659.BackgroundColor3 = v_u_48
	v_u_659.Position = UDim2.fromOffset(28, 152)
	v_u_659.Size = UDim2.new(1, -56, 0, 22)
	v_u_659.Parent = v_u_73
	local v660 = v_u_1.new("UICorner")
	v660.CornerRadius = UDim.new(0, 11)
	v660.Parent = v_u_659
	local v661 = v_u_1.new("Frame")
	v661.Name = "Fill"
	v661.BackgroundColor3 = Color3.fromRGB(255, 140, 0)
	v661.Size = UDim2.fromScale(0, 1)
	v661.Parent = v_u_659
	local v662 = v_u_1.new("UICorner")
	v662.CornerRadius = UDim.new(0, 11)
	v662.Parent = v661
	local v663 = v_u_1.new("Frame")
	v663.Name = "Knob"
	v663.AnchorPoint = Vector2.new(0.5, 0.5)
	v663.Size = UDim2.fromOffset(34, 34)
	v663.BackgroundColor3 = Color3.new(1, 1, 1)
	v663.Parent = v_u_659
	local v664 = v_u_1.new("UICorner")
	v664.CornerRadius = UDim.new(0, 17)
	v664.Parent = v663
	for v665, v666 in { "\224\184\155\224\184\129\224\184\149\224\184\180", "\224\184\132\224\185\137\224\184\178\224\184\135" } do
		local v667 = UDim2.new(v665 == 1 and 0 or 1, v665 == 1 and 16 or -116, 0, 182)
		local v668 = UDim2.fromOffset(100, 22)
		local v669 = v_u_73
		local v670 = v_u_1.new("TextLabel")
		v670.BackgroundTransparency = 1
		v670.Position = v667
		v670.Size = v668
		v670.Font = Enum.Font.GothamBold
		v670.TextSize = 17
		v670.TextWrapped = true
		v670.TextColor3 = Color3.fromRGB(200, 200, 200)
		v670.Text = v666
		v670.Parent = v669
		v670.TextSize = 14
		local v671
		if v665 == 1 then
			v671 = Enum.TextXAlignment.Left
		else
			v671 = Enum.TextXAlignment.Right
		end
		v670.TextXAlignment = v671
	end
	local v_u_672 = {
		["track"] = nil,
		["fill"] = nil,
		["knob"] = nil,
		["readout"] = nil,
		["value"] = 0,
		["dragging"] = false,
		["sentAt"] = 0,
		["track"] = v_u_659,
		["fill"] = v661,
		["knob"] = v663,
		["readout"] = v658
	}
	v_u_74 = v_u_672
	local function v_u_678() -- name: send
		-- upvalues: (copy) v_u_672, (ref) v_u_168, (ref) v_u_5
		v_u_672.sentAt = os.clock()
		local v673 = v_u_168
		local v674 = "BlinkRate"
		local v675 = v_u_672.value
		local v676
		if v675 >= 0.985 then
			v676 = v_u_5.BLINK_RATE_MAX
		elseif v675 <= 0.01 then
			v676 = 1
		else
			local v677 = v_u_5.BLINK_RATE_MAX ^ v675 * 100
			v676 = math.round(v677) / 100
		end
		v673(v674, v676)
	end
	v_u_659.InputBegan:Connect(function(p679)
		-- upvalues: (copy) v_u_672, (copy) v_u_659, (ref) v_u_168, (ref) v_u_5, (ref) v_u_464
		if p679.UserInputType == Enum.UserInputType.MouseButton1 or p679.UserInputType == Enum.UserInputType.Touch then
			v_u_672.dragging = true
			local v680 = v_u_672
			local v681 = (p679.Position.X - v_u_659.AbsolutePosition.X) / v_u_659.AbsoluteSize.X
			v680.value = math.clamp(v681, 0, 1)
			if os.clock() - v_u_672.sentAt > 0.2 then
				v_u_672.sentAt = os.clock()
				local v682 = v_u_168
				local v683 = "BlinkRate"
				local v684 = v_u_672.value
				local v685
				if v684 >= 0.985 then
					v685 = v_u_5.BLINK_RATE_MAX
				elseif v684 <= 0.01 then
					v685 = 1
				else
					local v686 = v_u_5.BLINK_RATE_MAX ^ v684 * 100
					v685 = math.round(v686) / 100
				end
				v682(v683, v685)
			end
			v_u_464()
		end
	end)
	v_u_4.InputChanged:Connect(function(p687)
		-- upvalues: (copy) v_u_672, (copy) v_u_659, (ref) v_u_168, (ref) v_u_5, (ref) v_u_464
		if v_u_672.dragging and (p687.UserInputType == Enum.UserInputType.MouseMovement or p687.UserInputType == Enum.UserInputType.Touch) then
			local v688 = v_u_672
			local v689 = (p687.Position.X - v_u_659.AbsolutePosition.X) / v_u_659.AbsoluteSize.X
			v688.value = math.clamp(v689, 0, 1)
			if os.clock() - v_u_672.sentAt > 0.2 then
				v_u_672.sentAt = os.clock()
				local v690 = v_u_168
				local v691 = "BlinkRate"
				local v692 = v_u_672.value
				local v693
				if v692 >= 0.985 then
					v693 = v_u_5.BLINK_RATE_MAX
				elseif v692 <= 0.01 then
					v693 = 1
				else
					local v694 = v_u_5.BLINK_RATE_MAX ^ v692 * 100
					v693 = math.round(v694) / 100
				end
				v690(v691, v693)
			end
			v_u_464()
		end
	end)
	v_u_4.InputEnded:Connect(function(p695)
		-- upvalues: (copy) v_u_672, (copy) v_u_678, (ref) v_u_464
		if v_u_672.dragging and (p695.UserInputType == Enum.UserInputType.MouseButton1 or p695.UserInputType == Enum.UserInputType.Touch) then
			v_u_672.dragging = false
			local v696 = task.delay
			local v697 = 0.2 - (os.clock() - v_u_672.sentAt)
			v696(math.max(0, v697), v_u_678)
			task.delay(0.5, v_u_464)
		end
	end)
	local v698 = (v_u_39.X - 32 - (#v_u_38 - 1) * 8) / #v_u_38
	local v699 = math.floor(v698)
	for v700, v_u_701 in v_u_38 do
		local v702 = v_u_144("Blink" .. v700, v_u_701.label, UDim2.fromOffset(16 + (v700 - 1) * (v699 + 8), 216), UDim2.fromOffset(v699, 44), v_u_73)
		v702.TextSize = 16
		v702.Activated:Connect(function()
			-- upvalues: (ref) v_u_168, (copy) v_u_701, (ref) v_u_464
			v_u_168("BlinkRate", v_u_701.rate)
			task.delay(0.2, v_u_464)
		end)
		local v703 = v_u_75
		local v704 = {
			["button"] = v702,
			["rate"] = v_u_701.rate
		}
		table.insert(v703, v704)
	end
	local v705 = UDim2.fromOffset(16, 272)
	local v706 = UDim2.fromOffset(170, 28)
	local v707 = v_u_73
	local v708 = v_u_1.new("TextLabel")
	v708.BackgroundTransparency = 1
	v708.Position = v705
	v708.Size = v706
	v708.Font = Enum.Font.GothamBold
	v708.TextSize = 17
	v708.TextWrapped = true
	v708.TextColor3 = Color3.fromRGB(200, 200, 200)
	v708.Text = "\224\184\170\224\184\181\224\185\132\224\184\159\224\185\128\224\184\165\224\184\181\224\185\137\224\184\162\224\184\167"
	v708.Parent = v707
	v708.TextXAlignment = Enum.TextXAlignment.Left
	v708.TextColor3 = Color3.new(1, 1, 1)
	local v709 = UDim2.new(0, 190, 0, 272)
	local v710 = UDim2.new(1, -206, 0, 28)
	local v711 = v_u_73
	local v712 = v_u_1.new("TextLabel")
	v712.BackgroundTransparency = 1
	v712.Position = v709
	v712.Size = v710
	v712.Font = Enum.Font.GothamBold
	v712.TextSize = 17
	v712.TextWrapped = true
	v712.TextColor3 = Color3.fromRGB(200, 200, 200)
	v712.Text = ""
	v712.Parent = v711
	v_u_77 = v712
	v_u_77.TextXAlignment = Enum.TextXAlignment.Right
	v_u_77.TextSize = 15
	local v713 = (v_u_39.X - 32 - 88 - 8 - (#v_u_35 - 1) * 6) / #v_u_35
	local v714 = math.floor(v713)
	for v715, v_u_716 in v_u_35 do
		local v717 = v_u_1.new("TextButton")
		v717.Name = "SignalColor" .. v715
		v717.Text = v_u_716.stock and "\224\185\128\224\184\148\224\184\180\224\184\161" or ""
		v717.Font = Enum.Font.GothamBold
		v717.TextSize = 13
		v717.TextColor3 = Color3.fromRGB(45, 25, 0)
		v717.BackgroundColor3 = v_u_716.color
		v717.Position = UDim2.fromOffset(16 + (v715 - 1) * (v714 + 6), 304)
		v717.Size = UDim2.fromOffset(v714, 44)
		v717.Parent = v_u_73
		local v718 = v_u_1.new("UICorner")
		v718.CornerRadius = UDim.new(0, 10)
		v718.Parent = v717
		local v719 = v_u_1.new("UIStroke")
		v719.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
		v719.Color = Color3.new(1, 1, 1)
		v719.Transparency = 0.6
		v719.Parent = v717
		v717.Activated:Connect(function()
			-- upvalues: (ref) v_u_168, (copy) v_u_716, (ref) v_u_113, (ref) v_u_485, (ref) v_u_464
			local v720 = v_u_168
			local v721 = "SignalColor"
			local v722
			if v_u_716.stock then
				v722 = false
			else
				v722 = v_u_716.color
			end
			v720(v721, v722)
			local v723 = v_u_716.color
			if typeof(v723) == "Color3" then
				local v724 = v_u_113
				local v725 = v_u_113
				local v726 = v_u_113
				local v727, v728, v729 = v723:ToHSV()
				v724.h = v727
				v725.s = v728
				v726.v = v729
			end
			v_u_485()
			task.delay(0.2, v_u_464)
		end)
		local v730 = v_u_76
		local v731 = {
			["button"] = v717,
			["stroke"] = v719,
			["color"] = v_u_716.color,
			["label"] = v_u_716.label
		}
		table.insert(v730, v731)
	end
	v_u_78 = v_u_144("SignalCustom", "\224\184\129\224\184\179\224\184\171\224\184\153\224\184\148\224\185\128\224\184\173\224\184\135", UDim2.new(1, -104, 0, 304), UDim2.fromOffset(88, 44), v_u_73)
	v_u_78.TextSize = 14
	local v732 = v_u_1.new("Frame")
	v732.Name = "Dot"
	v732.AnchorPoint = Vector2.new(1, 0)
	v732.Position = UDim2.new(1, -5, 0, 5)
	v732.Size = UDim2.fromOffset(10, 10)
	v732.Visible = false
	v732.Parent = v_u_78
	local v733 = v_u_1.new("UICorner")
	v733.CornerRadius = UDim.new(0, 5)
	v733.Parent = v732
	v_u_78.Activated:Connect(function()
		-- upvalues: (ref) v_u_113, (ref) v_u_5, (ref) v_u_485, (ref) v_u_464
		v_u_113.pickerShown = not v_u_113.pickerShown
		local v734 = v_u_5.signalColor(v_u_113.model)
		if typeof(v734) == "Color3" then
			local v735 = v_u_113
			local v736 = v_u_113
			local v737 = v_u_113
			local v738, v739, v740 = v734:ToHSV()
			v735.h = v738
			v736.s = v739
			v737.v = v740
		end
		v_u_485()
		v_u_464()
	end)
	local v741 = UDim2.fromOffset(16, 358)
	local v742 = UDim2.new(1, -32, 0, 66)
	local v743 = v_u_73
	local v744 = v_u_1.new("TextLabel")
	v744.BackgroundTransparency = 1
	v744.Position = v741
	v744.Size = v742
	v744.Font = Enum.Font.GothamBold
	v744.TextSize = 17
	v744.TextWrapped = true
	v744.TextColor3 = Color3.fromRGB(200, 200, 200)
	v744.Text = "\224\184\165\224\184\178\224\184\129\224\185\132\224\184\155\224\184\151\224\184\178\224\184\135\224\184\130\224\184\167\224\184\178\224\185\131\224\184\171\224\185\137\224\184\129\224\184\163\224\184\176\224\184\158\224\184\163\224\184\180\224\184\154\224\185\128\224\184\163\224\185\135\224\184\167\224\184\130\224\184\182\224\185\137\224\184\153 \224\184\170\224\184\184\224\184\148\224\184\151\224\184\178\224\184\135\224\184\132\224\184\183\224\184\173\224\185\132\224\184\159\224\184\132\224\185\137\224\184\178\224\184\135 \194\183 \224\184\129\224\184\148\224\184\170\224\184\181 \224\184\171\224\184\163\224\184\183\224\184\173 \224\184\129\224\184\179\224\184\171\224\184\153\224\184\148\224\185\128\224\184\173\224\184\135 \224\185\128\224\184\158\224\184\183\224\185\136\224\184\173\224\184\165\224\184\178\224\184\129\224\185\128\224\184\165\224\184\183\224\184\173\224\184\129\224\184\170\224\184\181\224\185\128\224\184\173\224\184\135 \194\183 \224\185\128\224\184\155\224\184\180\224\184\148\224\185\132\224\184\159\224\184\156\224\185\136\224\184\178\224\184\171\224\184\161\224\184\178\224\184\129\224\185\131\224\184\171\224\185\137\224\184\148\224\184\185\224\184\173\224\184\162\224\184\185\224\185\136 \194\183 \224\184\159\224\184\163\224\184\181 \224\185\128\224\184\155\224\184\165\224\184\181\224\185\136\224\184\162\224\184\153\224\185\132\224\184\148\224\185\137\224\184\149\224\184\165\224\184\173\224\184\148 \224\184\163\224\184\150\224\184\136\224\184\179\224\185\132\224\184\167\224\185\137\224\184\149\224\184\173\224\184\153\224\185\128\224\184\129\224\185\135\224\184\154"
	v744.Parent = v743
	v744.TextSize = 14
	v_u_79 = v_u_1.new("Frame")
	v_u_79.Name = "ShieldPage"
	v_u_79.BackgroundTransparency = 1
	v_u_79.Size = UDim2.fromScale(1, 1)
	v_u_79.Visible = false
	v_u_79.Parent = v529
	local v745 = UDim2.fromOffset(16, 112)
	local v746 = UDim2.fromOffset(150, 28)
	local v747 = v_u_79
	local v748 = v_u_1.new("TextLabel")
	v748.BackgroundTransparency = 1
	v748.Position = v745
	v748.Size = v746
	v748.Font = Enum.Font.GothamBold
	v748.TextSize = 17
	v748.TextWrapped = true
	v748.TextColor3 = Color3.fromRGB(200, 200, 200)
	v748.Text = "\224\184\170\224\184\181\224\184\138\224\184\180\224\184\167"
	v748.Parent = v747
	v_u_85 = v748
	local v749 = v_u_85
	v749.TextXAlignment = Enum.TextXAlignment.Left
	v749.TextColor3 = Color3.new(1, 1, 1)
	local v750 = UDim2.new(0, 150, 0, 112)
	local v751 = UDim2.new(1, -166, 0, 28)
	local v752 = v_u_79
	local v753 = v_u_1.new("TextLabel")
	v753.BackgroundTransparency = 1
	v753.Position = v750
	v753.Size = v751
	v753.Font = Enum.Font.GothamBold
	v753.TextSize = 17
	v753.TextWrapped = true
	v753.TextColor3 = Color3.fromRGB(200, 200, 200)
	v753.Text = ""
	v753.Parent = v752
	v_u_83 = v753
	v_u_83.TextXAlignment = Enum.TextXAlignment.Right
	v_u_83.TextSize = 15
	local v754 = (v_u_39.X - 32 - 88 - 8 - (#v_u_36 - 1) * 6) / #v_u_36
	local v755 = math.floor(v754)
	for v756, v_u_757 in v_u_36 do
		local v758 = v_u_1.new("TextButton")
		v758.Name = "ShieldColor" .. v756
		v758.Text = v_u_757.stock and "\224\185\128\224\184\148\224\184\180\224\184\161" or ""
		v758.Font = Enum.Font.GothamBold
		v758.TextSize = 13
		v758.TextColor3 = Color3.new(1, 1, 1)
		v758.BackgroundColor3 = v_u_757.color or Color3.fromRGB(17, 17, 17)
		v758.Position = UDim2.fromOffset(16 + (v756 - 1) * (v755 + 6), 144)
		v758.Size = UDim2.fromOffset(v755, 44)
		v758.Parent = v_u_79
		local v759 = v_u_1.new("UICorner")
		v759.CornerRadius = UDim.new(0, 10)
		v759.Parent = v758
		local v760 = v_u_1.new("UIStroke")
		v760.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
		v760.Color = Color3.new(1, 1, 1)
		v760.Transparency = 0.6
		v760.Parent = v758
		v758.Activated:Connect(function()
			-- upvalues: (copy) v_u_757, (ref) v_u_113, (ref) v_u_168, (ref) v_u_242, (ref) v_u_485, (ref) v_u_464
			local v761
			if v_u_757.stock then
				v761 = false
			else
				v761 = v_u_757.color
			end
			local v762 = v_u_113.tab
			if v762 then
				v762 = v_u_113.tab:match("^Tint_(.+)$")
			end
			if v762 then
				v_u_168("TintColor", v762, v761)
			else
				v_u_168("ShieldColor", v761)
			end
			local v763 = v_u_757.color or v_u_242()
			if typeof(v763) == "Color3" then
				local v764 = v_u_113
				local v765 = v_u_113
				local v766 = v_u_113
				local v767, v768, v769 = v763:ToHSV()
				v764.h = v767
				v765.s = v768
				v766.v = v769
			end
			v_u_485()
			task.delay(0.2, v_u_464)
		end)
		local v770 = v_u_81
		local v771 = {
			["button"] = v758,
			["stroke"] = v760,
			["color"] = v_u_757.color,
			["label"] = v_u_757.label,
			["stock"] = v_u_757.stock
		}
		table.insert(v770, v771)
	end
	v_u_84 = v_u_144("ShieldCustom", "\224\184\129\224\184\179\224\184\171\224\184\153\224\184\148\224\185\128\224\184\173\224\184\135", UDim2.new(1, -104, 0, 144), UDim2.fromOffset(88, 44), v_u_79)
	v_u_84.TextSize = 14
	local v772 = v_u_1.new("Frame")
	v772.Name = "Dot"
	v772.AnchorPoint = Vector2.new(1, 0)
	v772.Position = UDim2.new(1, -5, 0, 5)
	v772.Size = UDim2.fromOffset(10, 10)
	v772.Visible = false
	v772.Parent = v_u_84
	local v773 = v_u_1.new("UICorner")
	v773.CornerRadius = UDim.new(0, 5)
	v773.Parent = v772
	v_u_84.Activated:Connect(function()
		-- upvalues: (ref) v_u_113, (ref) v_u_250, (ref) v_u_485, (ref) v_u_464
		v_u_113.pickerShown = not v_u_113.pickerShown
		local v774 = v_u_250()
		if typeof(v774) == "Color3" then
			local v775 = v_u_113
			local v776 = v_u_113
			local v777 = v_u_113
			local v778, v779, v780 = v774:ToHSV()
			v775.h = v778
			v776.s = v779
			v777.v = v780
		end
		v_u_485()
		v_u_464()
	end)
	local v781 = UDim2.fromOffset(16, 204)
	local v782 = UDim2.fromOffset(150, 28)
	local v783 = v_u_79
	local v784 = v_u_1.new("TextLabel")
	v784.BackgroundTransparency = 1
	v784.Position = v781
	v784.Size = v782
	v784.Font = Enum.Font.GothamBold
	v784.TextSize = 17
	v784.TextWrapped = true
	v784.TextColor3 = Color3.fromRGB(200, 200, 200)
	v784.Text = "\224\184\132\224\184\167\224\184\178\224\184\161\224\185\131\224\184\170 / \224\184\151\224\184\182\224\184\154"
	v784.Parent = v783
	v784.TextXAlignment = Enum.TextXAlignment.Left
	v784.TextColor3 = Color3.new(1, 1, 1)
	local v785 = UDim2.new(0, 150, 0, 204)
	local v786 = UDim2.new(1, -166, 0, 28)
	local v787 = v_u_79
	local v788 = v_u_1.new("TextLabel")
	v788.BackgroundTransparency = 1
	v788.Position = v785
	v788.Size = v786
	v788.Font = Enum.Font.GothamBold
	v788.TextSize = 17
	v788.TextWrapped = true
	v788.TextColor3 = Color3.fromRGB(200, 200, 200)
	v788.Text = ""
	v788.Parent = v787
	v788.TextXAlignment = Enum.TextXAlignment.Right
	v788.TextSize = 15
	local v_u_789 = v_u_1.new("TextButton")
	v_u_789.Name = "ShieldClear"
	v_u_789.Text = ""
	v_u_789.AutoButtonColor = false
	v_u_789.BackgroundColor3 = v_u_48
	v_u_789.Position = UDim2.fromOffset(28, 244)
	v_u_789.Size = UDim2.new(1, -56, 0, 22)
	v_u_789.Parent = v_u_79
	local v790 = v_u_1.new("UICorner")
	v790.CornerRadius = UDim.new(0, 11)
	v790.Parent = v_u_789
	local v791 = v_u_1.new("Frame")
	v791.Name = "Fill"
	v791.BackgroundColor3 = Color3.fromRGB(150, 205, 255)
	v791.Size = UDim2.fromScale(0, 1)
	v791.Parent = v_u_789
	local v792 = v_u_1.new("UICorner")
	v792.CornerRadius = UDim.new(0, 11)
	v792.Parent = v791
	local v793 = v_u_1.new("Frame")
	v793.Name = "Knob"
	v793.AnchorPoint = Vector2.new(0.5, 0.5)
	v793.Size = UDim2.fromOffset(34, 34)
	v793.BackgroundColor3 = Color3.new(1, 1, 1)
	v793.Parent = v_u_789
	local v794 = v_u_1.new("UICorner")
	v794.CornerRadius = UDim.new(0, 17)
	v794.Parent = v793
	for v795, v796 in { "\224\184\151\224\184\182\224\184\154", "\224\185\131\224\184\170" } do
		local v797 = UDim2.new(v795 == 1 and 0 or 1, v795 == 1 and 16 or -116, 0, 274)
		local v798 = UDim2.fromOffset(100, 22)
		local v799 = v_u_79
		local v800 = v_u_1.new("TextLabel")
		v800.BackgroundTransparency = 1
		v800.Position = v797
		v800.Size = v798
		v800.Font = Enum.Font.GothamBold
		v800.TextSize = 17
		v800.TextWrapped = true
		v800.TextColor3 = Color3.fromRGB(200, 200, 200)
		v800.Text = v796
		v800.Parent = v799
		v800.TextSize = 14
		local v801
		if v795 == 1 then
			v801 = Enum.TextXAlignment.Left
		else
			v801 = Enum.TextXAlignment.Right
		end
		v800.TextXAlignment = v801
	end
	local v_u_802 = {
		["track"] = nil,
		["fill"] = nil,
		["knob"] = nil,
		["readout"] = nil,
		["value"] = 0,
		["dragging"] = false,
		["sentAt"] = 0,
		["track"] = v_u_789,
		["fill"] = v791,
		["knob"] = v793,
		["readout"] = v788
	}
	v_u_80 = v_u_802
	local function v_u_806() -- name: send
		-- upvalues: (copy) v_u_802, (ref) v_u_11, (ref) v_u_113, (ref) v_u_168
		v_u_802.sentAt = os.clock()
		local v803 = v_u_802.value * v_u_11.SHIELD_CLEAR_MAX * 100
		local v804 = math.round(v803) / 100
		local v805 = v_u_113.tab
		if v805 then
			v805 = v_u_113.tab:match("^Tint_(.+)$")
		end
		if v805 then
			v_u_168("TintClear", v805, v804)
		else
			v_u_168("ShieldClear", v804)
		end
	end
	v_u_789.InputBegan:Connect(function(p807)
		-- upvalues: (copy) v_u_802, (copy) v_u_789, (ref) v_u_11, (ref) v_u_113, (ref) v_u_168, (ref) v_u_464
		if p807.UserInputType == Enum.UserInputType.MouseButton1 or p807.UserInputType == Enum.UserInputType.Touch then
			v_u_802.dragging = true
			local v808 = v_u_802
			local v809 = (p807.Position.X - v_u_789.AbsolutePosition.X) / v_u_789.AbsoluteSize.X
			v808.value = math.clamp(v809, 0, 1)
			if os.clock() - v_u_802.sentAt > 0.2 then
				v_u_802.sentAt = os.clock()
				local v810 = v_u_802.value * v_u_11.SHIELD_CLEAR_MAX * 100
				local v811 = math.round(v810) / 100
				local v812 = v_u_113.tab
				if v812 then
					v812 = v_u_113.tab:match("^Tint_(.+)$")
				end
				if v812 then
					v_u_168("TintClear", v812, v811)
				else
					v_u_168("ShieldClear", v811)
				end
			end
			v_u_464()
		end
	end)
	v_u_4.InputChanged:Connect(function(p813)
		-- upvalues: (copy) v_u_802, (copy) v_u_789, (ref) v_u_11, (ref) v_u_113, (ref) v_u_168, (ref) v_u_464
		if v_u_802.dragging and (p813.UserInputType == Enum.UserInputType.MouseMovement or p813.UserInputType == Enum.UserInputType.Touch) then
			local v814 = v_u_802
			local v815 = (p813.Position.X - v_u_789.AbsolutePosition.X) / v_u_789.AbsoluteSize.X
			v814.value = math.clamp(v815, 0, 1)
			if os.clock() - v_u_802.sentAt > 0.2 then
				v_u_802.sentAt = os.clock()
				local v816 = v_u_802.value * v_u_11.SHIELD_CLEAR_MAX * 100
				local v817 = math.round(v816) / 100
				local v818 = v_u_113.tab
				if v818 then
					v818 = v_u_113.tab:match("^Tint_(.+)$")
				end
				if v818 then
					v_u_168("TintClear", v818, v817)
				else
					v_u_168("ShieldClear", v817)
				end
			end
			v_u_464()
		end
	end)
	v_u_4.InputEnded:Connect(function(p819)
		-- upvalues: (copy) v_u_802, (copy) v_u_806, (ref) v_u_464
		if v_u_802.dragging and (p819.UserInputType == Enum.UserInputType.MouseButton1 or p819.UserInputType == Enum.UserInputType.Touch) then
			v_u_802.dragging = false
			local v820 = task.delay
			local v821 = 0.2 - (os.clock() - v_u_802.sentAt)
			v820(math.max(0, v821), v_u_806)
			task.delay(0.5, v_u_464)
		end
	end)
	local v822 = (v_u_39.X - 32 - (#v_u_37 - 1) * 8) / #v_u_37
	local v823 = math.floor(v822)
	for v824, v_u_825 in v_u_37 do
		local v826 = v_u_144("ShieldClear" .. v824, v_u_825.label, UDim2.fromOffset(16 + (v824 - 1) * (v823 + 8), 304), UDim2.fromOffset(v823, 44), v_u_79)
		v826.TextSize = 16
		v826.Activated:Connect(function()
			-- upvalues: (copy) v_u_825, (ref) v_u_113, (ref) v_u_168, (ref) v_u_464
			local v827
			if v_u_825.stock then
				v827 = false
			else
				v827 = v_u_825.t
			end
			local v828 = v_u_113.tab
			if v828 then
				v828 = v_u_113.tab:match("^Tint_(.+)$")
			end
			if v828 then
				v_u_168("TintClear", v828, v827)
			else
				v_u_168("ShieldClear", v827)
			end
			task.delay(0.2, v_u_464)
		end)
		local v829 = v_u_82
		local v830 = {
			["button"] = v826,
			["t"] = v_u_825.t,
			["stock"] = v_u_825.stock
		}
		table.insert(v829, v830)
	end
	local v831 = ("\224\184\165\224\184\173\224\184\135\224\185\132\224\184\148\224\185\137\224\184\159\224\184\163\224\184\181 \194\183 \224\184\129\224\184\148 Confirm \224\184\136\224\185\136\224\184\178\224\184\162\224\184\151\224\184\184\224\184\129\224\184\132\224\184\163\224\184\177\224\185\137\224\184\135\224\184\151\224\184\181\224\185\136\224\185\128\224\184\155\224\184\165\224\184\181\224\185\136\224\184\162\224\184\153: \224\184\170\224\184\181 %s \194\183 \224\184\132\224\184\167\224\184\178\224\184\161\224\185\131\224\184\170 %s \194\183 \224\184\129\224\184\165\224\184\177\224\184\154\224\185\128\224\184\155\224\185\135\224\184\153\224\185\128\224\184\148\224\184\180\224\184\161\224\184\159\224\184\163\224\184\181 \194\183 \224\184\163\224\184\150\224\184\136\224\184\179\224\185\132\224\184\167\224\185\137\224\184\149\224\184\173\224\184\153\224\185\128\224\184\129\224\185\135\224\184\154"):format(v_u_11.priceText(v_u_112.ShieldColor), v_u_11.priceText(v_u_112.ShieldClear))
	local v832 = UDim2.fromOffset(16, 358)
	local v833 = UDim2.new(1, -32, 0, 66)
	local v834 = v_u_79
	local v835 = v_u_1.new("TextLabel")
	v835.BackgroundTransparency = 1
	v835.Position = v832
	v835.Size = v833
	v835.Font = Enum.Font.GothamBold
	v835.TextSize = 17
	v835.TextWrapped = true
	v835.TextColor3 = Color3.fromRGB(200, 200, 200)
	v835.Text = v831
	v835.Parent = v834
	v835.TextSize = 14
	v_u_91 = v_u_1.new("Frame")
	v_u_91.Name = "CarbonPage"
	v_u_91.BackgroundTransparency = 1
	v_u_91.Size = UDim2.fromScale(1, 1)
	v_u_91.Visible = false
	v_u_91.Parent = v529
	v_u_92 = v_u_1.new("ScrollingFrame")
	v_u_92.Name = "Rows"
	v_u_92.BackgroundTransparency = 1
	v_u_92.BorderSizePixel = 0
	v_u_92.Position = UDim2.fromOffset(16, 110)
	v_u_92.Size = UDim2.new(1, -32, 0, 262)
	v_u_92.CanvasSize = UDim2.new()
	v_u_92.AutomaticCanvasSize = Enum.AutomaticSize.Y
	v_u_92.ScrollBarThickness = 5
	v_u_92.Parent = v_u_91
	local v836 = v_u_1.new("UIListLayout")
	v836.Padding = UDim.new(0, 6)
	v836.SortOrder = Enum.SortOrder.LayoutOrder
	v836.Parent = v_u_92
	local v837 = UDim2.fromOffset(16, 378)
	local v838 = UDim2.new(1, -32, 0, 48)
	local v839 = v_u_91
	local v840 = v_u_1.new("TextLabel")
	v840.BackgroundTransparency = 1
	v840.Position = v837
	v840.Size = v838
	v840.Font = Enum.Font.GothamBold
	v840.TextSize = 17
	v840.TextWrapped = true
	v840.TextColor3 = Color3.fromRGB(200, 200, 200)
	v840.Text = "\224\184\165\224\184\178\224\184\162\224\184\132\224\184\178\224\184\163\224\185\140\224\184\154\224\184\173\224\184\153\224\185\128\224\184\148\224\184\181\224\184\162\224\184\167\224\184\129\224\184\177\224\184\154\224\184\163\224\184\150\224\184\162\224\184\153\224\184\149\224\185\140 \194\183 \224\185\131\224\184\170\224\185\136\224\185\132\224\184\148\224\185\137\224\185\128\224\184\137\224\184\158\224\184\178\224\184\176\224\184\158\224\184\165\224\184\178\224\184\170\224\184\149\224\184\180\224\184\129\224\184\148\224\184\179\224\184\149\224\184\177\224\184\167\224\184\163\224\184\150 \194\183 \224\184\139\224\184\183\224\185\137\224\184\173\224\184\132\224\184\163\224\184\177\224\185\137\224\184\135\224\185\128\224\184\148\224\184\181\224\184\162\224\184\167\224\184\149\224\185\136\224\184\173\224\184\138\224\184\180\224\185\137\224\184\153 \224\184\150\224\184\173\224\184\148\224\184\129\224\184\165\224\184\177\224\184\154\224\185\128\224\184\155\224\185\135\224\184\153\224\185\128\224\184\148\224\184\180\224\184\161\224\184\159\224\184\163\224\184\181"
	v840.Parent = v839
	v840.TextSize = 14
	v_u_94 = v_u_1.new("Frame")
	v_u_94.Name = "AccPage"
	v_u_94.BackgroundTransparency = 1
	v_u_94.Size = UDim2.fromScale(1, 1)
	v_u_94.Visible = false
	v_u_94.Parent = v_u_91.Parent
	v_u_95 = v_u_1.new("ScrollingFrame")
	v_u_95.Name = "Rows"
	v_u_95.BackgroundTransparency = 1
	v_u_95.BorderSizePixel = 0
	v_u_95.Position = UDim2.fromOffset(16, 110)
	v_u_95.Size = UDim2.new(1, -32, 0, 262)
	v_u_95.CanvasSize = UDim2.new()
	v_u_95.AutomaticCanvasSize = Enum.AutomaticSize.Y
	v_u_95.ScrollBarThickness = 5
	v_u_95.Parent = v_u_94
	local v841 = v_u_1.new("UIListLayout")
	v841.Padding = UDim.new(0, 6)
	v841.SortOrder = Enum.SortOrder.LayoutOrder
	v841.Parent = v_u_95
	local v842 = ("\224\184\130\224\184\173\224\184\135\224\185\129\224\184\149\224\185\136\224\184\135\224\185\128\224\184\170\224\184\163\224\184\180\224\184\161 \224\184\138\224\184\180\224\185\137\224\184\153\224\184\165\224\184\176 %s \194\183 \224\184\139\224\184\183\224\185\137\224\184\173\224\184\132\224\184\163\224\184\177\224\185\137\224\184\135\224\185\128\224\184\148\224\184\181\224\184\162\224\184\167\224\184\149\224\185\136\224\184\173\224\184\132\224\184\177\224\184\153 \224\184\150\224\184\173\224\184\148\224\184\173\224\184\173\224\184\129 / \224\185\131\224\184\170\224\185\136\224\184\129\224\184\165\224\184\177\224\184\154\224\184\159\224\184\163\224\184\181 \194\183 \224\184\129\224\184\148 Confirm \224\184\149\224\184\173\224\184\153\224\185\129\224\184\149\224\185\136\224\184\135\224\185\128\224\184\170\224\184\163\224\185\135\224\184\136\224\184\136\224\184\182\224\184\135\224\184\136\224\185\136\224\184\178\224\184\162"):format(v_u_11.priceText(v_u_112.Accessory))
	local v843 = UDim2.fromOffset(16, 378)
	local v844 = UDim2.new(1, -32, 0, 48)
	local v845 = v_u_94
	local v846 = v_u_1.new("TextLabel")
	v846.BackgroundTransparency = 1
	v846.Position = v843
	v846.Size = v844
	v846.Font = Enum.Font.GothamBold
	v846.TextSize = 17
	v846.TextWrapped = true
	v846.TextColor3 = Color3.fromRGB(200, 200, 200)
	v846.Text = v842
	v846.Parent = v845
	v_u_96 = v846
	v_u_96.TextSize = 14
	v_u_98 = v_u_1.new("Frame")
	v_u_98.Name = "PartsPage"
	v_u_98.BackgroundTransparency = 1
	v_u_98.Size = UDim2.fromScale(1, 1)
	v_u_98.Visible = false
	v_u_98.Parent = v529
	v_u_99 = v_u_1.new("ScrollingFrame")
	v_u_99.Name = "Rows"
	v_u_99.BackgroundTransparency = 1
	v_u_99.BorderSizePixel = 0
	v_u_99.Position = UDim2.fromOffset(16, 110)
	v_u_99.Size = UDim2.new(1, -32, 0, 262)
	v_u_99.CanvasSize = UDim2.new()
	v_u_99.AutomaticCanvasSize = Enum.AutomaticSize.Y
	v_u_99.ScrollBarThickness = 5
	v_u_99.Parent = v_u_98
	local v847 = v_u_1.new("UIListLayout")
	v847.Padding = UDim.new(0, 6)
	v847.SortOrder = Enum.SortOrder.LayoutOrder
	v847.Parent = v_u_99
	local v848 = UDim2.fromOffset(16, 378)
	local v849 = UDim2.new(1, -32, 0, 48)
	local v850 = v_u_98
	local v851 = v_u_1.new("TextLabel")
	v851.BackgroundTransparency = 1
	v851.Position = v848
	v851.Size = v849
	v851.Font = Enum.Font.GothamBold
	v851.TextSize = 17
	v851.TextWrapped = true
	v851.TextColor3 = Color3.fromRGB(200, 200, 200)
	v851.Text = "\224\184\165\224\184\173\224\184\135\224\185\131\224\184\170\224\185\136\224\185\132\224\184\148\224\185\137\224\184\159\224\184\163\224\184\181 \224\184\136\224\185\136\224\184\178\224\184\162\224\184\149\224\184\173\224\184\153\224\184\129\224\184\148 Confirm \224\184\139\224\184\183\224\185\137\224\184\173\224\184\132\224\184\163\224\184\177\224\185\137\224\184\135\224\185\128\224\184\148\224\184\181\224\184\162\224\184\167\224\184\149\224\185\136\224\184\173\224\184\132\224\184\177\224\184\153 \224\185\129\224\184\165\224\185\137\224\184\167\224\184\170\224\184\165\224\184\177\224\184\154\224\185\132\224\184\148\224\185\137\224\184\149\224\184\165\224\184\173\224\184\148 \194\183 \224\184\130\224\184\173\224\184\135\224\185\129\224\184\149\224\185\136\224\184\135\224\184\173\224\184\162\224\185\136\224\184\178\224\184\135\224\185\128\224\184\148\224\184\181\224\184\162\224\184\167 \224\185\132\224\184\161\224\185\136\224\184\161\224\184\181\224\184\156\224\184\165\224\184\129\224\184\177\224\184\154\224\184\132\224\184\167\224\184\178\224\184\161\224\185\128\224\184\163\224\185\135\224\184\167"
	v851.Parent = v850
	v851.TextSize = 14
	v_u_101 = v_u_1.new("Frame")
	v_u_101.Name = "PopTunePage"
	v_u_101.BackgroundTransparency = 1
	v_u_101.Size = UDim2.fromScale(1, 1)
	v_u_101.Visible = false
	v_u_101.Parent = v529
	local v852 = UDim2.fromOffset(20, 114)
	local v853 = UDim2.fromOffset(260, 16)
	local v854 = v_u_101
	local v855 = v_u_1.new("TextLabel")
	v855.BackgroundTransparency = 1
	v855.Position = v852
	v855.Size = v853
	v855.Font = Enum.Font.GothamBold
	v855.TextSize = 17
	v855.TextWrapped = true
	v855.TextColor3 = Color3.fromRGB(200, 200, 200)
	v855.Text = "B A C K F I R E   T U N E"
	v855.Parent = v854
	v855.Name = "PopHead"
	v855.TextSize = 11
	v855.TextColor3 = v_u_33
	v855.TextXAlignment = Enum.TextXAlignment.Left
	local v856 = UDim2.new(1, -176, 0, 112)
	local v857 = UDim2.fromOffset(156, 20)
	local v858 = v_u_101
	local v859 = v_u_1.new("TextLabel")
	v859.BackgroundTransparency = 1
	v859.Position = v856
	v859.Size = v857
	v859.Font = Enum.Font.GothamBold
	v859.TextSize = 17
	v859.TextWrapped = true
	v859.TextColor3 = Color3.fromRGB(200, 200, 200)
	v859.Text = ""
	v859.Parent = v858
	v_u_105 = v859
	v_u_105.Name = "PopStatus"
	v_u_105.Font = Enum.Font.GothamBlack
	v_u_105.TextSize = 12
	v_u_105.TextXAlignment = Enum.TextXAlignment.Right
	local v860 = v_u_1.new("Frame")
	v860.Name = "Strips"
	v860.BackgroundTransparency = 1
	v860.Position = UDim2.fromOffset(16, 138)
	v860.Size = UDim2.new(1, -32, 0, #v_u_6.POP_TUNE * 50 - 6)
	v860.Parent = v_u_101
	for v861, v_u_862 in v_u_6.POP_TUNE do
		local v863 = v_u_1.new("Frame")
		v863.Name = "Row" .. v_u_862.key
		v863.BackgroundColor3 = Color3.fromRGB(8, 9, 12)
		v863.BackgroundTransparency = 0.35
		v863.BorderSizePixel = 0
		v863.Position = UDim2.fromOffset(0, (v861 - 1) * 50)
		v863.Size = UDim2.new(1, 0, 0, 44)
		v863.Parent = v860
		local v864 = v_u_1.new("UICorner")
		v864.CornerRadius = UDim.new(0, 10)
		v864.Parent = v863
		local v865 = v_u_862.th
		local v866 = UDim2.fromOffset(14, 0)
		local v867 = UDim2.new(0, 100, 1, 0)
		local v868 = v_u_1.new("TextLabel")
		v868.BackgroundTransparency = 1
		v868.Position = v866
		v868.Size = v867
		v868.Font = Enum.Font.GothamBold
		v868.TextSize = 17
		v868.TextWrapped = true
		v868.TextColor3 = Color3.fromRGB(200, 200, 200)
		v868.Text = v865
		v868.Parent = v863
		v868.Name = "Name"
		v868.TextXAlignment = Enum.TextXAlignment.Left
		v868.TextColor3 = Color3.new(1, 1, 1)
		v868.TextSize = 15
		local v869 = v_u_144("Minus", "\226\136\146", UDim2.fromOffset(116, 6), UDim2.fromOffset(32, 32), v863)
		local v870 = v_u_144("Plus", "+", UDim2.new(1, -104, 0, 6), UDim2.fromOffset(32, 32), v863)
		for _, v871 in { v869, v870 } do
			v871.TextSize = 20
			local v872 = v_u_1.new("UICorner")
			v872.CornerRadius = UDim.new(0, 8)
			v872.Parent = v871
		end
		local v_u_873 = v_u_1.new("TextButton")
		v_u_873.Name = "Meter"
		v_u_873.Text = ""
		v_u_873.AutoButtonColor = false
		v_u_873.BackgroundTransparency = 1
		v_u_873.Position = UDim2.fromOffset(158, 7)
		v_u_873.Size = UDim2.new(1, -270, 0, 30)
		v_u_873.Parent = v863
		local v874 = {}
		for v875 = 1, 20 do
			local v876 = v_u_1.new("Frame")
			v876.Name = "Cell" .. v875
			v876.BorderSizePixel = 0
			v876.BackgroundColor3 = v_u_31
			v876.BackgroundTransparency = 0.9
			v876.Position = UDim2.new((v875 - 1) / 20, 1, 0, 6)
			v876.Size = UDim2.new(0.05, -3, 1, -10)
			v876.Parent = v_u_873
			local v877 = v_u_1.new("UICorner")
			v877.CornerRadius = UDim.new(0, 2)
			v877.Parent = v876
			v874[v875] = v876
		end
		if v_u_862.default then
			local v878 = v_u_1.new("Frame")
			v878.Name = "StockNotch"
			v878.BorderSizePixel = 0
			v878.BackgroundColor3 = Color3.new(1, 1, 1)
			v878.BackgroundTransparency = 0.25
			v878.AnchorPoint = Vector2.new(0.5, 0)
			local v879 = UDim2.new
			local v880 = (v_u_862.default - v_u_862.min) / (v_u_862.max - v_u_862.min)
			v878.Position = v879(math.clamp(v880, 0, 1), v_u_862.default >= v_u_862.max and -2 or 0, 0, 0)
			v878.Size = UDim2.fromOffset(2, 4)
			v878.Parent = v_u_873
		end
		local v881 = v_u_1.new("TextLabel")
		v881.Name = "Value"
		v881.BackgroundColor3 = Color3.new(0, 0, 0)
		v881.BackgroundTransparency = 0.45
		v881.Position = UDim2.new(1, -64, 0, 7)
		v881.Size = UDim2.fromOffset(54, 30)
		v881.FontFace = v_u_8.FONT_DISPLAY
		v881.TextSize = 15
		v881.TextColor3 = Color3.new(1, 1, 1)
		v881.RichText = true
		v881.Text = "\226\128\148"
		v881.Parent = v863
		local v882 = v_u_1.new("UICorner")
		v882.CornerRadius = UDim.new(0, 6)
		v882.Parent = v881
		local v883 = v_u_1.new("UIStroke")
		v883.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
		v883.Color = Color3.new(1, 1, 1)
		v883.Transparency = 0.88
		v883.Parent = v881
		local v_u_884 = v_u_862.key == "Flame"
		local v_u_887 = {
			["spec"] = nil,
			["cells"] = nil,
			["valueLabel"] = nil,
			["value"] = 0,
			["dragging"] = false,
			["spec"] = v_u_862,
			["cells"] = v874,
			["valueLabel"] = v881,
			["litColor"] = function(p885) -- name: litColor
				-- upvalues: (copy) v_u_884, (ref) v_u_8, (ref) v_u_32
				if v_u_884 then
					local v886 = (p885 - 1) / 19
					if v886 < 0.5 then
						return v_u_32[1]:Lerp(v_u_32[2], v886 * 2)
					else
						return v_u_32[2]:Lerp(v_u_32[3], (v886 - 0.5) * 2)
					end
				else
					return v_u_8.ACCENT
				end
			end
		}
		v_u_108[v_u_862.key] = v_u_887
		local function v_u_898(p888) -- name: setFrom
			-- upvalues: (ref) v_u_6, (ref) v_u_113, (copy) v_u_887, (copy) v_u_873, (copy) v_u_862, (ref) v_u_109, (ref) v_u_110, (ref) v_u_168, (ref) v_u_464
			if v_u_6.popTuneOn(v_u_113.model) then
				local v889 = v_u_887
				local v890 = (p888 - v_u_873.AbsolutePosition.X) / v_u_873.AbsoluteSize.X
				v889.value = math.clamp(v890, 0, 1)
				local v891 = v_u_862.min + v_u_887.value * (v_u_862.max - v_u_862.min)
				local v892 = math.round(v891)
				local v893 = v_u_887
				local v894 = v_u_887
				local v895 = os.clock()
				v893.want = v892
				v894.wantAt = v895
				v_u_109[v_u_862.key] = v892
				if not v_u_110 then
					v_u_110 = true
					task.spawn(function()
						-- upvalues: (ref) v_u_109, (ref) v_u_168, (ref) v_u_110, (ref) v_u_464
						while next(v_u_109) ~= nil do
							local v896
							if v_u_109.On == nil then
								if v_u_109.Reset == nil then
									v896 = next(v_u_109)
								else
									v896 = "Reset"
								end
							else
								v896 = "On"
							end
							local v897 = v_u_109[v896]
							v_u_109[v896] = nil
							v_u_168("PopTune", v896, v897)
							task.wait(0.2)
						end
						v_u_110 = false
						task.delay(0.3, v_u_464)
					end)
				end
				v_u_464()
			end
		end
		v_u_873.InputBegan:Connect(function(p899)
			-- upvalues: (ref) v_u_6, (ref) v_u_113, (copy) v_u_887, (copy) v_u_898
			if (p899.UserInputType == Enum.UserInputType.MouseButton1 and true or p899.UserInputType == Enum.UserInputType.Touch) and v_u_6.popTuneOn(v_u_113.model) then
				v_u_887.dragging = true
				v_u_898(p899.Position.X)
			end
		end)
		v_u_4.InputChanged:Connect(function(p900)
			-- upvalues: (copy) v_u_887, (copy) v_u_898
			if v_u_887.dragging and (p900.UserInputType == Enum.UserInputType.MouseMovement or p900.UserInputType == Enum.UserInputType.Touch) then
				v_u_898(p900.Position.X)
			end
		end)
		local v_u_901 = 0
		v_u_4.InputEnded:Connect(function(p902)
			-- upvalues: (ref) v_u_901, (copy) v_u_887, (ref) v_u_464
			if p902.UserInputType == Enum.UserInputType.MouseButton1 and true or p902.UserInputType == Enum.UserInputType.Touch then
				v_u_901 = v_u_901 + 1
				if v_u_887.dragging then
					v_u_887.dragging = false
					v_u_887.wantAt = os.clock()
					task.delay(1.05, v_u_464)
				end
			end
		end)
		local v_u_903 = v_u_901
		for _, v904 in {
			{ v869, -1 },
			{ v870, 1 }
		} do
			local v905 = v904[1]
			local v_u_906 = v904[2]
			v905.InputBegan:Connect(function(p907)
				-- upvalues: (ref) v_u_903, (ref) v_u_478, (copy) v_u_887, (copy) v_u_906, (ref) v_u_53, (ref) v_u_101
				if p907.UserInputType == Enum.UserInputType.MouseButton1 and true or p907.UserInputType == Enum.UserInputType.Touch then
					v_u_903 = v_u_903 + 1
					local v_u_908 = v_u_903
					v_u_478(v_u_887, v_u_906)
					task.delay(0.35, function()
						-- upvalues: (ref) v_u_903, (copy) v_u_908, (ref) v_u_53, (ref) v_u_101, (ref) v_u_478, (ref) v_u_887, (ref) v_u_906
						while v_u_903 == v_u_908 and (v_u_53.Enabled and v_u_101.Visible) do
							v_u_478(v_u_887, v_u_906)
							task.wait(0.06)
						end
					end)
				end
			end)
		end
	end
	v_u_102 = v_u_1.new("TextButton")
	v_u_102.Name = "Locked"
	v_u_102.Text = ""
	v_u_102.AutoButtonColor = false
	v_u_102.BackgroundColor3 = v_u_47
	v_u_102.BackgroundTransparency = 0.12
	v_u_102.Position = v860.Position
	v_u_102.Size = v860.Size
	v_u_102.ZIndex = 2
	v_u_102:SetAttribute("SkinSkip", true)
	v_u_102.Parent = v_u_101
	local v909 = v_u_102
	local v910 = v_u_1.new("UICorner")
	v910.CornerRadius = UDim.new(0, 12)
	v910.Parent = v909
	local v911 = v_u_1.new("UIStroke")
	v911.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v911.Color = Color3.new(1, 1, 1)
	v911.Transparency = 0.9
	v911.Parent = v_u_102
	local v912 = v_u_13.make("lock", v_u_8.ACCENT_LIGHT, 22)
	v912.AnchorPoint = Vector2.new(0.5, 0)
	v912.Position = UDim2.new(0.5, 0, 0, 18)
	v912.Parent = v_u_102
	local v913 = UDim2.fromOffset(0, 46)
	local v914 = UDim2.new(1, 0, 0, 26)
	local v915 = v_u_102
	local v916 = v_u_1.new("TextLabel")
	v916.BackgroundTransparency = 1
	v916.Position = v913
	v916.Size = v914
	v916.Font = Enum.Font.GothamBold
	v916.TextSize = 17
	v916.TextWrapped = true
	v916.TextColor3 = Color3.fromRGB(200, 200, 200)
	v916.Text = "\224\184\136\224\184\185\224\184\153\224\184\162\224\184\180\224\184\135"
	v916.Parent = v915
	v916.Name = "Title"
	v916.Font = Enum.Font.GothamBlack
	v916.TextSize = 20
	v916.TextColor3 = Color3.new(1, 1, 1)
	local v917 = UDim2.fromOffset(16, 74)
	local v918 = UDim2.new(1, -32, 0, 22)
	local v919 = v_u_102
	local v920 = v_u_1.new("TextLabel")
	v920.BackgroundTransparency = 1
	v920.Position = v917
	v920.Size = v918
	v920.Font = Enum.Font.GothamBold
	v920.TextSize = 17
	v920.TextWrapped = true
	v920.TextColor3 = Color3.fromRGB(200, 200, 200)
	v920.Text = "\224\184\155\224\184\163\224\184\177\224\184\154\224\185\130\224\184\173\224\184\129\224\184\178\224\184\170\224\184\162\224\184\180\224\184\135 \224\184\155\224\184\163\224\184\180\224\184\161\224\184\178\224\184\147 \224\184\132\224\184\167\224\184\178\224\184\161\224\184\150\224\184\181\224\185\136 \224\185\129\224\184\165\224\184\176\224\185\132\224\184\159\224\184\162\224\184\180\224\184\135\224\184\130\224\184\173\224\184\135\224\184\151\224\185\136\224\184\173"
	v920.Parent = v919
	v920.Name = "Text"
	v920.TextSize = 14
	v_u_103 = v_u_144("Unlock", "\224\185\128\224\184\155\224\184\180\224\184\148\224\185\131\224\184\138\224\185\137\224\184\135\224\184\178\224\184\153", UDim2.new(0.5, -130, 0, 106), UDim2.fromOffset(260, 44), v_u_102)
	v_u_103.BackgroundColor3 = v_u_49
	v_u_103.TextSize = 17
	v_u_103.Activated:Connect(function()
		-- upvalues: (ref) v_u_109, (ref) v_u_110, (ref) v_u_168, (ref) v_u_464
		v_u_109.On = true
		if not v_u_110 then
			v_u_110 = true
			task.spawn(function()
				-- upvalues: (ref) v_u_109, (ref) v_u_168, (ref) v_u_110, (ref) v_u_464
				while next(v_u_109) ~= nil do
					local v921
					if v_u_109.On == nil then
						if v_u_109.Reset == nil then
							v921 = next(v_u_109)
						else
							v921 = "Reset"
						end
					else
						v921 = "On"
					end
					local v922 = v_u_109[v921]
					v_u_109[v921] = nil
					v_u_168("PopTune", v921, v922)
					task.wait(0.2)
				end
				v_u_110 = false
				task.delay(0.3, v_u_464)
			end)
		end
	end)
	local v923 = UDim2.fromOffset(16, 156)
	local v924 = UDim2.new(1, -32, 0, 20)
	local v925 = v_u_102
	local v926 = v_u_1.new("TextLabel")
	v926.BackgroundTransparency = 1
	v926.Position = v923
	v926.Size = v924
	v926.Font = Enum.Font.GothamBold
	v926.TextSize = 17
	v926.TextWrapped = true
	v926.TextColor3 = Color3.fromRGB(200, 200, 200)
	v926.Text = "\224\184\165\224\184\173\224\184\135\224\185\132\224\184\148\224\185\137\224\184\129\224\185\136\224\184\173\224\184\153 \224\184\136\224\185\136\224\184\178\224\184\162\224\184\149\224\184\173\224\184\153\224\184\129\224\184\148 Confirm \194\183 \224\184\139\224\184\183\224\185\137\224\184\173\224\184\132\224\184\163\224\184\177\224\185\137\224\184\135\224\185\128\224\184\148\224\184\181\224\184\162\224\184\167\224\184\149\224\185\136\224\184\173\224\184\132\224\184\177\224\184\153"
	v926.Parent = v925
	v_u_104 = v926
	v_u_104.Name = "Note"
	v_u_104.TextSize = 12
	v_u_104.TextColor3 = v_u_33
	v_u_107 = v_u_144("PopReset", "\224\184\132\224\185\136\224\184\178\224\185\128\224\184\148\224\184\180\224\184\161\224\184\151\224\184\177\224\185\137\224\184\135\224\184\171\224\184\161\224\184\148", UDim2.fromOffset(16, 342), UDim2.new(0.5, -20, 0, 38), v_u_101)
	v_u_107.TextSize = 15
	v_u_107.BackgroundColor3 = v_u_50
	v_u_107.Activated:Connect(v_u_484)
	v_u_106 = v_u_144("PopOff", "\224\184\155\224\184\180\224\184\148\224\184\136\224\184\185\224\184\153\224\184\162\224\184\180\224\184\135", UDim2.new(0.5, 4, 0, 342), UDim2.new(0.5, -20, 0, 38), v_u_101)
	v_u_106.TextSize = 15
	v_u_106.BackgroundColor3 = v_u_50
	v_u_106.Activated:Connect(function()
		-- upvalues: (ref) v_u_109, (ref) v_u_110, (ref) v_u_168, (ref) v_u_464
		v_u_109.On = false
		if not v_u_110 then
			v_u_110 = true
			task.spawn(function()
				-- upvalues: (ref) v_u_109, (ref) v_u_168, (ref) v_u_110, (ref) v_u_464
				while next(v_u_109) ~= nil do
					local v927
					if v_u_109.On == nil then
						if v_u_109.Reset == nil then
							v927 = next(v_u_109)
						else
							v927 = "Reset"
						end
					else
						v927 = "On"
					end
					local v928 = v_u_109[v927]
					v_u_109[v927] = nil
					v_u_168("PopTune", v927, v928)
					task.wait(0.2)
				end
				v_u_110 = false
				task.delay(0.3, v_u_464)
			end)
		end
	end)
	local v929 = UDim2.fromOffset(16, 388)
	local v930 = UDim2.new(1, -32, 0, 36)
	local v931 = v_u_101
	local v932 = v_u_1.new("TextLabel")
	v932.BackgroundTransparency = 1
	v932.Position = v929
	v932.Size = v930
	v932.Font = Enum.Font.GothamBold
	v932.TextSize = 17
	v932.TextWrapped = true
	v932.TextColor3 = Color3.fromRGB(200, 200, 200)
	v932.Text = "\224\184\155\224\184\165\224\185\136\224\184\173\224\184\162\224\184\132\224\184\177\224\184\153\224\185\128\224\184\163\224\185\136\224\184\135\224\184\149\224\184\173\224\184\153\224\184\163\224\184\173\224\184\154\224\184\170\224\184\185\224\184\135\224\185\128\224\184\158\224\184\183\224\185\136\224\184\173\224\184\159\224\184\177\224\184\135\224\184\156\224\184\165 \194\183 \226\136\146 / + \224\184\151\224\184\181\224\184\165\224\184\176 1% \224\184\129\224\184\148\224\184\132\224\185\137\224\184\178\224\184\135\224\185\132\224\184\148\224\185\137 \194\183 \224\184\163\224\184\150\224\184\136\224\184\179\224\184\132\224\185\136\224\184\178\224\185\132\224\184\167\224\185\137\224\184\149\224\184\173\224\184\153\224\185\128\224\184\129\224\185\135\224\184\154"
	v932.Parent = v931
	v932.Name = "PopHint"
	v932.TextSize = 12
	v932.TextColor3 = v_u_33
	v_u_61 = v_u_1.new("Frame")
	v_u_61.Name = "Picker"
	v_u_61.AnchorPoint = Vector2.new(0, 0.5)
	v_u_61.Position = UDim2.new(0.5, 282, 0.55, 0)
	v_u_61.Size = UDim2.fromOffset(264, 316)
	v_u_61.BackgroundColor3 = v_u_47
	v_u_61.BackgroundTransparency = 0.1
	v_u_61.ZIndex = 2
	v_u_61.Parent = v_u_53
	local v933 = v_u_61
	local v934 = v_u_1.new("UICorner")
	v934.CornerRadius = UDim.new(0, 16)
	v934.Parent = v933
	local v935 = UDim2.fromOffset(14, 8)
	local v936 = UDim2.new(1, -28, 0, 30)
	local v937 = v_u_61
	local v938 = v_u_1.new("TextLabel")
	v938.BackgroundTransparency = 1
	v938.Position = v935
	v938.Size = v936
	v938.Font = Enum.Font.GothamBold
	v938.TextSize = 17
	v938.TextWrapped = true
	v938.TextColor3 = Color3.fromRGB(200, 200, 200)
	v938.Text = "Custom color (drag)"
	v938.Parent = v937
	v_u_86 = v938
	v_u_86.TextColor3 = Color3.new(1, 1, 1)
	v_u_86.TextXAlignment = Enum.TextXAlignment.Left
	v_u_62 = v_u_1.new("Frame")
	v_u_62.Name = "Preview"
	v_u_62.Position = UDim2.fromOffset(14, 200)
	v_u_62.Size = UDim2.fromOffset(32, 32)
	v_u_62.Parent = v_u_61
	local v939 = v_u_62
	local v940 = v_u_1.new("UICorner")
	v940.CornerRadius = UDim.new(0, 16)
	v940.Parent = v939
	local v941 = v_u_1.new("UIStroke")
	v941.Color = Color3.new(1, 1, 1)
	v941.Transparency = 0.6
	v941.Thickness = 2
	v941.Parent = v_u_62
	v_u_89 = v_u_1.new("TextBox")
	v_u_89.Name = "Hex"
	v_u_89.Text = ""
	v_u_89.PlaceholderText = "#RRGGBB"
	v_u_89.ClearTextOnFocus = true
	v_u_89.FontFace = v_u_8.FONT_DISPLAY
	v_u_89.TextSize = 16
	v_u_89.TextColor3 = Color3.new(1, 1, 1)
	v_u_89.PlaceholderColor3 = Color3.fromRGB(120, 123, 136)
	v_u_89.TextXAlignment = Enum.TextXAlignment.Left
	v_u_89.BackgroundColor3 = Color3.fromRGB(8, 9, 12)
	v_u_89.BackgroundTransparency = 0.2
	v_u_89.Position = UDim2.fromOffset(56, 200)
	v_u_89.Size = UDim2.fromOffset(150, 32)
	v_u_89.Parent = v_u_61
	local v942 = v_u_89
	local v943 = v_u_1.new("UICorner")
	v943.CornerRadius = UDim.new(0, 8)
	v943.Parent = v942
	local v944 = v_u_1.new("UIPadding")
	v944.PaddingLeft = UDim.new(0, 10)
	v944.Parent = v_u_89
	local v_u_945 = v_u_1.new("UIStroke")
	v_u_945.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v_u_945.Color = Color3.new(1, 1, 1)
	v_u_945.Transparency = 0.85
	v_u_945.Parent = v_u_89
	v_u_89.Focused:Connect(function()
		-- upvalues: (copy) v_u_945, (ref) v_u_8
		v_u_945.Color = v_u_8.ACCENT
		v_u_945.Transparency = 0.2
	end)
	v_u_89.FocusLost:Connect(function(_)
		-- upvalues: (copy) v_u_945, (ref) v_u_89, (ref) v_u_113, (ref) v_u_485, (ref) v_u_499
		v_u_945.Color = Color3.new(1, 1, 1)
		v_u_945.Transparency = 0.85
		local v946 = v_u_89.Text:gsub("%s", ""):gsub("^#", ""):match("(%x%x%x%x%x%x)$")
		local v947, v948
		if v946 then
			local v949 = Color3.fromHex
			v947, v948 = pcall(v949, v946)
		else
			v947 = false
			v948 = nil
		end
		if v947 and typeof(v948) == "Color3" then
			local v950 = v_u_113
			local v951 = v_u_113
			local v952 = v_u_113
			local v953, v954, v955 = v948:ToHSV()
			v950.h = v953
			v951.s = v954
			v952.v = v955
			v_u_485()
			v_u_499()
		else
			v_u_485()
		end
	end)
	local v956 = UDim2.fromOffset(216, 200)
	local v957 = UDim2.fromOffset(120, 32)
	local v958 = v_u_61
	local v959 = v_u_1.new("TextLabel")
	v959.BackgroundTransparency = 1
	v959.Position = v956
	v959.Size = v957
	v959.Font = Enum.Font.GothamBold
	v959.TextSize = 17
	v959.TextWrapped = true
	v959.TextColor3 = Color3.fromRGB(200, 200, 200)
	v959.Text = "\224\184\129\224\184\148 Enter"
	v959.Parent = v958
	v959.Name = "HexHint"
	v959.TextSize = 12
	v959.TextColor3 = Color3.fromRGB(120, 123, 136)
	v959.TextXAlignment = Enum.TextXAlignment.Left
	v_u_88 = v_u_9.new(v_u_61, {
		["position"] = UDim2.fromOffset(14, 40),
		["size"] = UDim2.new(1, -28, 0, 150),
		["onChange"] = function(p960, p961, p962) -- name: onChange
			-- upvalues: (ref) v_u_113, (ref) v_u_485
			local v963 = v_u_113
			local v964 = v_u_113
			v_u_113.h = p960
			v963.s = p961
			v964.v = p962
			v_u_485()
		end,
		["onRelease"] = function() -- name: onRelease
			-- upvalues: (ref) v_u_499
			v_u_499()
		end
	})
	v_u_63 = v_u_1.new("Frame")
	v_u_63.Name = "Slots"
	v_u_63.BackgroundTransparency = 1
	v_u_63.Position = UDim2.fromOffset(14, 238)
	v_u_63.Size = UDim2.new(1, -28, 0, 40)
	v_u_63.Parent = v_u_61
	for v_u_965, v966 in { "Start (middle)", "End" } do
		local v967 = v_u_144("Slot" .. v_u_965, v966, UDim2.fromOffset((v_u_965 - 1) * 122, 0), UDim2.fromOffset(114, 38), v_u_63)
		v967.TextSize = 15
		v967.Activated:Connect(function()
			-- upvalues: (ref) v_u_113, (copy) v_u_965, (ref) v_u_488, (ref) v_u_485, (ref) v_u_464
			v_u_113.slot = v_u_965
			local v968 = v_u_488()
			if typeof(v968) == "Color3" then
				local v969 = v_u_113
				local v970 = v_u_113
				local v971 = v_u_113
				local v972, v973, v974 = v968:ToHSV()
				v969.h = v972
				v970.s = v973
				v971.v = v974
			end
			v_u_485()
			v_u_464()
		end)
		v_u_69[v_u_965] = v967
	end
	v_u_87 = v_u_144("Apply", "Use this color", UDim2.fromOffset(14, 276), UDim2.new(1, -28, 0, 34), v_u_61)
	v_u_87.BackgroundColor3 = v_u_49
	v_u_87.Activated:Connect(v_u_499)
	v_u_485()
end
local function v_u_1007(p976) -- name: dock
	-- upvalues: (ref) v_u_53, (copy) v_u_3, (copy) v_u_39, (copy) v_u_113, (ref) v_u_61, (copy) v_u_40, (copy) v_u_1
	local v977 = v_u_53.Panel
	local v978 = require(v_u_3:WaitForChild("GameUI"):WaitForChild("TuneDock"))
	if p976 and v978.set then
		if v978.insets then
			v_u_53.ScreenInsets = v978.insets
		end
		local v979 = v978.size or v_u_53.AbsoluteSize
		local v980 = v979.Y - v978.top - v978.bottom
		local v981 = v979.X - v978.left - v978.right
		local v982 = v978.max or 1
		local v983 = v980 / v_u_39.Y
		local v984 = v981 / v_u_39.X
		local v985 = math.min(v983, v984, v982)
		local v986 = math.max(v982, 0.45)
		local v987 = math.clamp(v985, 0.45, v986)
		v_u_113.pickerFolded = true
		v_u_113.pickerShown = false
		v_u_61.Parent = v977
		v_u_61.Size = UDim2.fromOffset(v_u_39.X - 32, v_u_40.Y)
		for _, v988 in { v977, v_u_61 } do
			local v989 = v988:FindFirstChild("DockScale") or v_u_1.new("UIScale")
			v989.Name = "DockScale"
			v989.Scale = v988 == v_u_61 and 1 or v987
			v989.Parent = v988
		end
		if v978.anchor == "left" then
			v977.AnchorPoint = Vector2.new(0, 0)
			v977.Position = UDim2.new(0, v978.left, 0, v978.top)
		else
			v977.AnchorPoint = Vector2.new(1, 0)
			v977.Position = UDim2.new(1, -v978.right, 0, v978.top)
		end
		v_u_61.AnchorPoint = Vector2.new(0.5, 0)
		v_u_61.Position = UDim2.new(0.5, 0, 0, 108)
		return
	else
		v_u_53.ScreenInsets = Enum.ScreenInsets.CoreUISafeInsets
		v_u_61.Size = UDim2.fromOffset(v_u_40.X, v_u_40.Y)
		local v990
		if v_u_53.AbsoluteSize.Y > 0 then
			v990 = v_u_53.AbsoluteSize
		else
			v990 = workspace.CurrentCamera.ViewportSize
		end
		local v991 = v_u_39.Y + 12 + v_u_40.Y
		local v992, v993
		if p976 then
			local v994 = (v990.Y - 24) / v991
			local v995 = (v990.X - 230) / (v_u_39.X + 24)
			local v996 = math.min(v994, v995, 1)
			local v997 = (v990.Y - 24) / v_u_39.Y
			local v998 = (v990.X - 150) / (v_u_39.X + v_u_40.X + 36)
			local v999 = math.min(v997, v998, 1)
			v992 = v999 - 0.05 <= v996
			if not v992 then
				v996 = v999
			end
			v993 = math.max(v996, 0.45)
		else
			v992 = true
			v993 = 1
		end
		local v1000 = v_u_113
		local v1001
		if p976 then
			v1001 = not v992
		else
			v1001 = p976
		end
		v1000.pickerFolded = v1001
		v_u_113.pickerShown = false
		local v1002 = v_u_61
		local v1003
		if v_u_113.pickerFolded then
			v1003 = v977
		else
			v1003 = v_u_53
		end
		v1002.Parent = v1003
		for _, v1004 in { v977, v_u_61 } do
			local v1005 = v1004:FindFirstChild("DockScale") or v_u_1.new("UIScale")
			v1005.Name = "DockScale"
			v1005.Scale = v1004 == v_u_61 and v_u_113.pickerFolded and 1 or v993
			v1005.Parent = v1004
		end
		if p976 and v992 then
			local v1006 = -v991 * v993 / 2
			v977.AnchorPoint = Vector2.new(1, 0)
			v977.Position = UDim2.new(1, -12, 0.5, v1006)
			v_u_61.AnchorPoint = Vector2.new(1, 0)
			v_u_61.Position = UDim2.new(1, -12, 0.5, v1006 + (v_u_39.Y + 12) * v993)
			return
		elseif p976 then
			v977.AnchorPoint = Vector2.new(1, 0.5)
			v977.Position = UDim2.new(1, -12, 0.5, 0)
			v_u_61.AnchorPoint = Vector2.new(0.5, 0)
			v_u_61.Position = UDim2.new(0.5, 0, 0, 108)
		else
			v977.AnchorPoint = Vector2.new(0.5, 0.5)
			v977.Position = UDim2.fromScale(0.5, 0.55)
			v_u_61.AnchorPoint = Vector2.new(0, 0.5)
			v_u_61.Position = UDim2.new(0.5, 282, 0.55, 0)
		end
	end
end
function v_u_51.open(p1008, p1009, p1010) -- name: open
	-- upvalues: (ref) v_u_53, (copy) v_u_975, (copy) v_u_113, (copy) v_u_134, (copy) v_u_5, (copy) v_u_219, (copy) v_u_207, (copy) v_u_109, (copy) v_u_108, (copy) v_u_11, (copy) v_u_464, (copy) v_u_130, (copy) v_u_17, (copy) v_u_1007, (copy) v_u_519
	if not (v_u_53 and v_u_53.Parent) then
		v_u_975()
	end
	local v1011 = p1010 or {}
	v_u_113.model = p1008
	v_u_113.fire = p1009
	v_u_113.group = v1011.group
	v_u_113.glass = {
		["Shield"] = v_u_134(p1008, "Windshield"),
		["Mirrors"] = v_u_134(p1008, "Mirror")
	}
	local v1012 = {}
	for _, v1013 in p1008:GetDescendants() do
		if not (v1013:IsA("BasePart") and v1013:GetAttribute("CarbonKey")) then
			continue
		end
		v1012[v1013:GetAttribute("CarbonKey")] = true
	end
	v_u_113.carbon = {}
	for _, v1014 in v_u_5.CARBON_PARTS do
		if not v1012[v1014.key] then
			continue
		end
		local v1015 = v_u_113.carbon
		local v1016 = v1014.key
		table.insert(v1015, v1016)
	end
	v_u_219()
	local v1017 = {}
	for _, v1018 in p1008:GetDescendants() do
		if not v1018:IsA("BasePart") or type(v1018:GetAttribute("Accessory")) ~= "string" then
			continue
		end
		v1017[v1018:GetAttribute("Accessory")] = true
	end
	v_u_113.acc = {}
	for _, v1019 in v_u_5.ACCESSORIES do
		if not v1017[v1019.key] then
			continue
		end
		local v1020 = v_u_113.acc
		local v1021 = v1019.key
		table.insert(v1020, v1021)
	end
	v_u_207()
	table.clear(v_u_109)
	for _, v1022 in v_u_108 do
		v1022.want = nil
		v1022.wantAt = nil
		v1022.dragging = false
	end
	if v_u_113.ownedWatch then
		v_u_113.ownedWatch:Disconnect()
	end
	v_u_113.ownedWatch = p1008.AttributeChanged:Connect(function(p1023)
		-- upvalues: (ref) v_u_11, (ref) v_u_464
		if p1023 == "TuneOwned" or (p1023 == "ShieldOff" or (p1023 == "ShowMirrors" or (p1023 == "BlinkRate" or (p1023 == "SignalColor" or (v_u_11.isTuneAttribute(p1023) or p1023:sub(1, 7) == "PopTune"))))) then
			v_u_464()
		end
	end)
	if v_u_113.group == "Paint" and (p1008:GetAttribute("NoPaint") == true and type(p1008:GetAttribute("PaintAllow")) ~= "string") then
		v_u_113.group = "Other"
		v_u_113.tab = "DRL"
	end
	local v1024 = v_u_130(v_u_113.tab)
	if v_u_113.group then
		for _, v1025 in v_u_17 do
			if not v1024 then
				continue
			end
			local v1026
			if v1025.id == v_u_113.tab then
				v1026 = v1025.group ~= v_u_113.group
			else
				v1026 = false
			end
			v1024 = not v1026
		end
	end
	if not v1024 then
		for _, v1027 in v_u_17 do
			if v_u_113.group ~= nil and v1027.group ~= v_u_113.group or not v_u_130(v1027.id) then
				continue
			end
			v_u_113.tab = v1027.id
		end
	end
	v_u_1007(v1011.dock == true)
	v_u_519(v_u_113.tab)
	v_u_53.Enabled = true
end
function v_u_51.close() -- name: close
	-- upvalues: (copy) v_u_113, (ref) v_u_251, (ref) v_u_53
	local v1028 = v_u_113.preview
	v_u_113.preview = nil
	if v1028 then
		local v_u_1029 = v1028.before
		local v_u_1030 = v_u_113.model
		local v_u_1031 = v_u_113.fire
		if v_u_1030 and v_u_1031 then
			v_u_251 = v_u_251 + 1
			local v_u_1032 = v_u_251
			local v_u_1033 = 0
			local function v_u_1037() -- name: step
				-- upvalues: (copy) v_u_1032, (ref) v_u_251, (copy) v_u_1030, (copy) v_u_1029, (ref) v_u_1033, (copy) v_u_1031, (copy) v_u_1037
				if v_u_1032 == v_u_251 and v_u_1030.Parent then
					local v1034 = v_u_1030:GetAttribute("Indicator") or "Off"
					if v1034 ~= v_u_1029 and v_u_1033 < 4 then
						v_u_1033 = v_u_1033 + 1
						local v1035 = v_u_1031
						local v1036 = "Indicator"
						if v_u_1029 ~= "Off" then
							v1034 = v_u_1029
						end
						v1035(v1036, v1034)
						task.delay(0.3, v_u_1037)
					end
				else
					return
				end
			end
			v_u_1037()
		end
	end
	if v_u_53 then
		v_u_53.Enabled = false
	end
	if v_u_113.ownedWatch then
		v_u_113.ownedWatch:Disconnect()
		v_u_113.ownedWatch = nil
	end
	v_u_113.model = nil
	v_u_113.fire = nil
	v_u_113.partRowsFor = nil
end
function v_u_51.toggle(p1038, p1039) -- name: toggle
	-- upvalues: (copy) v_u_51
	if v_u_51.isOpen() then
		v_u_51.close()
	else
		v_u_51.open(p1038, p1039)
	end
end
function v_u_51.isOpen() -- name: isOpen
	-- upvalues: (ref) v_u_53
	local v1040
	if v_u_53 == nil then
		v1040 = false
	else
		v1040 = v_u_53.Enabled
	end
	return v1040
end
return v_u_51