-- Path: StarterPlayer/PlayerModule/ControlModule/AvatarAbilitiesInterface
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v1 = game:GetService("Players")
local v2 = require(script.Parent.Parent:WaitForChild("CommonUtils")).get("FlagUtil")
local v3 = v2.getUserFlag("UserPlayerScriptsCCLIntegrationD") or v2.getUserFlag("UserPlayerScriptsCCLIntegrationDGA")
local v_u_4 = v2.getUserFlag("UserPlayerScriptsPlayerControlState2") or v2.getUserFlag("UserPlayerScriptsPlayerControlState2GA")
local v_u_5 = v2.getUserFlag("UserPlayerScriptsTaskDeferSimulation")
local v_u_6 = v2.getUserFlag("UserPlayerScriptsImportWaitForAbilitiesFolder")
local v7 = v2.getUserFlag("UserAbilitiesUserInterfaceD")
local v_u_8
if v_u_6 then
	v_u_8 = nil
else
	local function v_u_20(p9, p_u_10, p11) -- name: waitForChildren
		if #p_u_10 == 0 then
			return nil
		end
		for _, v12 in p_u_10 do
			local v13 = p9:FindFirstChild(v12)
			if not v13 then
				continue
			end
			return v13
		end
		local v_u_14 = coroutine.running()
		local v_u_15 = nil
		local v_u_16 = false
		local v18 = p9.ChildAdded:Connect(function(p17)
			-- upvalues: (copy) p_u_10, (ref) v_u_16, (ref) v_u_15, (copy) v_u_14
			if table.find(p_u_10, p17.Name) then
				if v_u_16 then
					return
				end
				v_u_16 = true
				v_u_15 = p17
				task.spawn(v_u_14)
			end
		end)
		local v19
		if p11 then
			v19 = task.delay(p11, function()
				-- upvalues: (ref) v_u_16, (ref) v_u_15, (copy) v_u_14
				if not v_u_16 then
					v_u_16 = true
					v_u_15 = nil
					task.spawn(v_u_14)
				end
			end)
		else
			v19 = nil
		end
		coroutine.yield()
		v18:Disconnect()
		if v19 and coroutine.status(v19) == "suspended" then
			task.cancel(v19)
		end
		return v_u_15
	end
	v_u_8 = function(p21, p22)
		-- upvalues: (copy) v_u_20
		if p21 then
			local v23
			if p22 then
				v23 = time() + p22
			else
				v23 = nil
			end
			local v24 = v_u_20
			local v25 = { "AbilityManagerActor", "Abilities" }
			local v26
			if v23 then
				local v27 = v23 - time()
				v26 = math.max(v27, 0)
			else
				v26 = nil
			end
			local v28 = v24(p21, v25, v26)
			if v28 then
				if v28.Name == "Abilities" then
					if v28:IsA("Folder") then
						return v28
					else
						return nil
					end
				else
					local v29
					if v23 then
						local v30 = v23 - time()
						v29 = math.max(v30, 0)
					else
						v29 = nil
					end
					local v31
					if v29 then
						v31 = v28:WaitForChild("Abilities", v29)
					else
						v31 = v28:WaitForChild("Abilities")
					end
					if v31 and v31:IsA("Folder") then
						return v31
					else
						return nil
					end
				end
			else
				return nil
			end
		else
			return nil
		end
	end
end
if not v3 then
	local v_u_32 = game:GetService("Players")
	local v33 = {}
	local v_u_34 = nil
	local v_u_35 = nil
	local v_u_36 = Instance.new("BindableEvent")
	local v_u_37 = nil
	local v_u_38 = false
	local function v_u_40(p39) -- name: characterAdded
		-- upvalues: (ref) v_u_34, (ref) v_u_35, (ref) v_u_37, (copy) v_u_36
		v_u_34 = nil
		v_u_35 = nil
		if v_u_37 then
			v_u_37:Disconnect()
			v_u_37 = nil
		end
		if p39 then
			v_u_34 = p39:FindFirstChild("AbilityManagerActor")
			v_u_35 = p39:FindFirstChildOfClass("Humanoid")
			while not v_u_35 do
				p39.ChildAdded:wait()
				v_u_35 = p39:FindFirstChildOfClass("Humanoid")
			end
			v_u_36:Fire()
			v_u_37 = v_u_35:GetPropertyChangedSignal("EvaluateStateMachine"):Connect(function()
				-- upvalues: (ref) v_u_36
				v_u_36:Fire()
			end)
		end
	end
	function v33.isEnabled() -- name: isEnabled
		-- upvalues: (ref) v_u_38, (copy) v_u_32, (copy) v_u_40, (ref) v_u_34, (ref) v_u_35
		if not v_u_38 then
			v_u_38 = true
			local v41 = v_u_32.LocalPlayer
			if v41 then
				v41.characterAdded:Connect(v_u_40)
				if v41.Character then
					v_u_40(v41.Character)
				end
			end
		end
		local v42 = v_u_34 ~= nil and v_u_35
		if v42 then
			v42 = not v_u_35.EvaluateStateMachine
		end
		return v42
	end
	function v33.GetEnabledChangedSignal() -- name: GetEnabledChangedSignal
		-- upvalues: (ref) v_u_38, (copy) v_u_32, (copy) v_u_40, (copy) v_u_36
		if not v_u_38 then
			v_u_38 = true
			local v43 = v_u_32.LocalPlayer
			if v43 then
				v43.characterAdded:Connect(v_u_40)
				if v43.Character then
					v_u_40(v43.Character)
				end
			end
		end
		return v_u_36.Event
	end
	return v33
end
local v_u_44 = {}
v_u_44.__index = v_u_44
local v_u_45 = {}
v1.PlayerRemoving:Connect(function(p46)
	-- upvalues: (copy) v_u_45
	wait(1)
	local v47 = v_u_45[p46.UserId]
	if v47 then
		v47:destroy()
		v_u_45[p46.UserId] = nil
	end
end)
local function v_u_52(p48) -- name: createAbilitiesByInputNameTable
	local v49 = {}
	for _, v50 in p48:GetChildren() do
		if not v50:IsA("Configuration") then
			continue
		end
		local v51 = v50:GetAttribute("InputName")
		if not v51 then
			continue
		end
		v49[v51] = v50
	end
	return v49
end
local function v_u_59(p53, p_u_54) -- name: notifyAbilitiesChanged
	local v_u_56 = p53.ChildAdded:Connect(function(p55)
		-- upvalues: (copy) p_u_54
		if p55:IsA("Configuration") then
			p_u_54(p55, "added")
		end
	end)
	local v_u_58 = p53.ChildRemoved:Connect(function(p57)
		-- upvalues: (copy) p_u_54
		if p57:IsA("Configuration") then
			p_u_54(p57, "removed")
		end
	end)
	return function()
		-- upvalues: (copy) v_u_56, (copy) v_u_58
		v_u_56:Disconnect()
		v_u_58:Disconnect()
	end
end
function v_u_44._new(p_u_60) -- name: _new
	-- upvalues: (copy) v_u_44, (copy) v_u_4, (copy) v_u_5
	local v61 = v_u_44
	local v_u_62 = setmetatable({}, v61)
	v_u_62._player = p_u_60
	v_u_62._data = {}
	v_u_62._character = nil
	v_u_62._humanoid = nil
	v_u_62._enabledChangedEvent = Instance.new("BindableEvent")
	v_u_62._abilitiesChangedEvent = Instance.new("BindableEvent")
	v_u_62._evaluateStateMachineChangedConnection = nil
	v_u_62._abilityChangedEvents = {}
	v_u_62._abilityChangedConnections = {}
	v_u_62._abilitiesByInputName = {}
	v_u_62._disconnectAbilitiesChanged = nil
	if v_u_4 and not v_u_5 then
		task.spawn(function()
			-- upvalues: (copy) v_u_62, (copy) p_u_60
			v_u_62._characterAddedConnection = p_u_60.CharacterAdded:Connect(function(p63)
				-- upvalues: (ref) v_u_62
				v_u_62:_onCharacterAdded(p63)
			end)
		end)
	else
		v_u_62._characterAddedConnection = p_u_60.CharacterAdded:Connect(function(p64)
			-- upvalues: (copy) v_u_62
			v_u_62:_onCharacterAdded(p64)
		end)
	end
	if p_u_60.Character then
		v_u_62:_onCharacterAdded(p_u_60.Character)
	end
	return v_u_62
end
local v_u_65 = nil
function v_u_44._avatarAbilities() -- name: _avatarAbilities
	-- upvalues: (ref) v_u_65
	if not v_u_65 then
		local v66 = game:GetService("ReplicatedStorage"):FindFirstChild("Packages")
		local v67
		if v66 then
			v67 = v66:FindFirstChild("AvatarAbilities")
		else
			v67 = nil
		end
		local v68
		if v67 then
			v68 = require(v67)
		else
			v68 = nil
		end
		v_u_65 = v68
		if not v_u_65 then
			v_u_65 = require("@rbx/AvatarAbilities")
		end
	end
	return v_u_65
end
function v_u_44.get(p69) -- name: get
	-- upvalues: (copy) v_u_45, (copy) v_u_44
	if not p69 or p69.UserId == 0 then
		return nil
	end
	local v70 = v_u_45[p69.UserId]
	if not v70 then
		v70 = v_u_44._new(p69)
		v_u_45[p69.UserId] = v70
	end
	return v70
end
function v_u_44._hookUpAbilityChangedEvent(p_u_71, p_u_72, p_u_73) -- name: _hookUpAbilityChangedEvent
	local v74 = p_u_71._abilitiesByInputName[p_u_72]
	if v74 then
		local v75 = v74:FindFirstChild("SyncedState")
		if v75 then
			if not p_u_71._abilityChangedConnections[p_u_73] then
				p_u_71._abilityChangedConnections[p_u_73] = {}
			end
			if p_u_71._abilityChangedConnections[p_u_73][p_u_72] then
				p_u_71._abilityChangedConnections[p_u_73][p_u_72]:Disconnect()
				p_u_71._abilityChangedConnections[p_u_73][p_u_72] = nil
			end
			p_u_71._abilityChangedConnections[p_u_73][p_u_72] = v75:GetAttributeChangedSignal(p_u_73):Connect(function()
				-- upvalues: (copy) p_u_71, (copy) p_u_73, (copy) p_u_72
				p_u_71._abilityChangedEvents[p_u_73][p_u_72]:Fire()
			end)
		end
	else
		return
	end
end
function v_u_44._onCharacterAdded(p_u_76, p_u_77) -- name: _onCharacterAdded
	-- upvalues: (copy) v_u_6, (ref) v_u_8, (copy) v_u_59, (copy) v_u_52
	p_u_76._humanoid = nil
	p_u_76._character = p_u_77
	p_u_76._abilitiesByInputName = {}
	p_u_76._data = {}
	if p_u_76._disconnectAbilitiesChanged then
		p_u_76._disconnectAbilitiesChanged()
		p_u_76._disconnectAbilitiesChanged = nil
	end
	for _, v78 in p_u_76._abilityChangedConnections do
		for _, v79 in v78 do
			v79:Disconnect()
		end
	end
	p_u_76._abilityChangedConnections = {}
	if p_u_76._evaluateStateMachineChangedConnection then
		p_u_76._evaluateStateMachineChangedConnection:Disconnect()
		p_u_76._evaluateStateMachineChangedConnection = nil
	end
	if p_u_76._character then
		task.spawn(function()
			-- upvalues: (ref) v_u_6, (copy) p_u_76, (copy) p_u_77, (ref) v_u_8, (ref) v_u_59, (ref) v_u_52
			local v_u_80
			if v_u_6 then
				v_u_80 = p_u_76._avatarAbilities().waitForAbilitiesFolder(p_u_77)
			else
				v_u_80 = v_u_8(p_u_77)
			end
			if v_u_80 and p_u_76._character == p_u_77 then
				p_u_76._humanoid = p_u_77:FindFirstChildOfClass("Humanoid")
				while not p_u_76._humanoid do
					p_u_77.ChildAdded:Wait()
					if p_u_76._character ~= p_u_77 then
						return
					end
					p_u_76._humanoid = p_u_77:FindFirstChildOfClass("Humanoid")
				end
				if p_u_76._evaluateStateMachineChangedConnection then
					p_u_76._evaluateStateMachineChangedConnection:Disconnect()
					p_u_76._evaluateStateMachineChangedConnection = nil
				end
				local function v_u_92() -- name: enabledChanged
					-- upvalues: (ref) p_u_76, (ref) v_u_59, (ref) v_u_80, (ref) v_u_52
					if p_u_76._disconnectAbilitiesChanged then
						p_u_76._disconnectAbilitiesChanged()
						p_u_76._disconnectAbilitiesChanged = nil
					end
					if p_u_76:isEnabled() then
						p_u_76._disconnectAbilitiesChanged = v_u_59(v_u_80, function(p81, p82)
							-- upvalues: (ref) p_u_76
							local v83 = p81:GetAttribute("InputName")
							if v83 then
								if p82 == "added" then
									p_u_76._abilitiesByInputName[v83] = p81
									for v84, v85 in p_u_76._abilityChangedEvents do
										if not v85[v83] then
											continue
										end
										p_u_76:_hookUpAbilityChangedEvent(v83, v84)
									end
								elseif p_u_76._abilitiesByInputName[v83] == p81 then
									p_u_76._abilitiesByInputName[v83] = nil
									for _, v86 in p_u_76._abilityChangedConnections do
										local v87 = v86[v83]
										if not v87 then
											continue
										end
										v87:Disconnect()
										v86[v83] = nil
									end
								end
								p_u_76._abilitiesChangedEvent:Fire()
							end
						end)
						p_u_76._abilitiesByInputName = v_u_52(v_u_80)
						p_u_76._abilitiesChangedEvent:Fire()
						for v88, v89 in p_u_76._abilityChangedEvents do
							for v90, v91 in v89 do
								v91:Fire()
								p_u_76:_hookUpAbilityChangedEvent(v90, v88)
							end
						end
					end
					p_u_76._enabledChangedEvent:Fire()
				end
				p_u_76._evaluateStateMachineChangedConnection = p_u_76._humanoid:GetPropertyChangedSignal("EvaluateStateMachine"):Connect(function()
					-- upvalues: (copy) v_u_92
					v_u_92()
				end)
				v_u_92()
			end
		end)
	end
end
function v_u_44.isEnabled(p93) -- name: isEnabled
	local v94
	if p93._humanoid == nil then
		v94 = false
	else
		v94 = not p93._humanoid.EvaluateStateMachine
	end
	return v94
end
function v_u_44.GetEnabledChangedSignal(p95) -- name: GetEnabledChangedSignal
	return p95._enabledChangedEvent.Event
end
function v_u_44.SendInput(p96, p97, p98) -- name: SendInput
	if p96:isEnabled() then
		if p98 ~= p96._data[p97] then
			p96._data[p97] = p98
			p96._avatarAbilities().setAbilityManagerCommand(p96._character, p97, p98)
		end
	end
end
function v_u_44.GetAbilityAttribute(p99, p100, p101, p102) -- name: GetAbilityAttribute
	local v103 = p99._abilitiesByInputName[p100]
	if v103 then
		local v104 = v103:FindFirstChild("SyncedState")
		if v104 then
			local v105 = v104:GetAttribute(p101)
			if v105 == nil then
				return p102
			else
				return v105
			end
		else
			return p102
		end
	else
		return p102
	end
end
function v_u_44.GetAbilityAttributeChangedSignal(p106, p107, p108) -- name: GetAbilityAttributeChangedSignal
	if not p106._abilityChangedEvents[p108] then
		p106._abilityChangedEvents[p108] = {}
	end
	if p106._abilityChangedEvents[p108][p107] then
		return p106._abilityChangedEvents[p108][p107].Event
	end
	local v109 = Instance.new("BindableEvent")
	p106._abilityChangedEvents[p108][p107] = v109
	p106:_hookUpAbilityChangedEvent(p107, p108)
	return v109.Event
end
function v_u_44.GetAbilityUIState(p110, p111) -- name: GetAbilityUIState
	return p110:GetAbilityAttribute(p111, "UIState", nil)
end
function v_u_44.GetAbilityUIStateChangedSignal(p112, p113) -- name: GetAbilityUIStateChangedSignal
	return p112:GetAbilityAttributeChangedSignal(p113, "UIState")
end
if not v7 then
	function v_u_44.GetAbilityActive(p114, p115) -- name: GetAbilityActive
		return p114:GetAbilityAttribute(p115, "Active", false)
	end
	function v_u_44.GetAbilityActiveChangedSignal(p116, p117) -- name: GetAbilityActiveChangedSignal
		return p116:GetAbilityAttributeChangedSignal(p117, "Active")
	end
	function v_u_44.GetAbilityValid(p118, p119) -- name: GetAbilityValid
		return p118:GetAbilityAttribute(p119, "IsValid", true)
	end
	function v_u_44.GetAbilityValidChangedSignal(p120, p121) -- name: GetAbilityValidChangedSignal
		return p120:GetAbilityAttributeChangedSignal(p121, "IsValid")
	end
end
function v_u_44.GetAbilities(p122) -- name: GetAbilities
	local v123 = {}
	for v124 in p122._abilitiesByInputName do
		table.insert(v123, v124)
	end
	return v123
end
function v_u_44.GetAbilitiesChangedSignal(p125) -- name: GetAbilitiesChangedSignal
	return p125._abilitiesChangedEvent.Event
end
function v_u_44.GetAbilityConfig(p126, p127) -- name: GetAbilityConfig
	local v128 = {
		["Slot"] = -1
	}
	local v129 = p126._abilitiesByInputName[p127]
	if not v129 then
		return v128
	end
	local v130 = v129:GetAttribute("ActionSlot")
	return v130 and {
		["Slot"] = tonumber(v130),
		["ButtonAssetId"] = v129:GetAttribute("CustomIcon"),
		["ButtonPressedAssetId"] = v129:GetAttribute("CustomIconActive"),
		["ButtonInvalidAssetId"] = v129:GetAttribute("CustomIconInvalid")
	} or v128
end
function v_u_44.destroy(p131) -- name: destroy
	if p131._characterAddedConnection then
		p131._characterAddedConnection:Disconnect()
		p131._characterAddedConnection = nil
	end
	if p131._evaluateStateMachineChangedConnection then
		p131._evaluateStateMachineChangedConnection:Disconnect()
		p131._evaluateStateMachineChangedConnection = nil
	end
	if p131._disconnectAbilitiesChanged then
		p131._disconnectAbilitiesChanged()
		p131._disconnectAbilitiesChanged = nil
	end
	for _, v132 in p131._abilityChangedConnections do
		for _, v133 in v132 do
			v133:Disconnect()
		end
	end
	p131._abilityChangedConnections = {}
end
return v_u_44