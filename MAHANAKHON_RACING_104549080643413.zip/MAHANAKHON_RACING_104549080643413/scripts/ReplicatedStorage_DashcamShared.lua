-- Path: ReplicatedStorage/DashcamShared
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = game:GetService("HttpService")
local v_u_2 = {
	["REMOTE"] = "Dashcam",
	["PROMPT"] = "DashcamShop",
	["NAME"] = "MHNK DASHCAM",
	["WHERE"] = "\224\184\163\224\185\137\224\184\178\224\184\153 MHNK DASHCAM \224\184\139\224\184\173\224\184\162 42",
	["REACH"] = 65,
	["BAY_MIN"] = Vector3.new(-228.5, -4, 2594),
	["BAY_MAX"] = Vector3.new(-166.5, 20, 2638.5)
}
v_u_2.CENTER = (v_u_2.BAY_MIN + v_u_2.BAY_MAX) / 2
v_u_2.COUNTER = Vector3.new(-246.4, 4.5, 2615)
v_u_2.COUNTER_REACH = 18
v_u_2.CAMERAS = {
	{
		["id"] = "Cam360",
		["item"] = "Cam360",
		["hidden"] = true,
		["th"] = "\224\184\129\224\184\165\224\185\137\224\184\173\224\184\135 360",
		["line"] = "\224\184\149\224\184\180\224\184\148\224\185\129\224\184\174\224\184\153\224\184\148\224\185\140\224\184\171\224\184\163\224\184\183\224\184\173\224\184\151\224\185\137\224\184\178\224\184\162\224\184\163\224\184\150 \194\183 \224\184\148\224\184\185\224\184\161\224\184\184\224\184\161\224\184\129\224\184\165\224\185\137\224\184\173\224\184\135: \224\184\155\224\184\184\224\185\136\224\184\161 U (\224\184\155\224\184\184\224\185\136\224\184\161 360) \224\184\149\224\184\173\224\184\153\224\184\130\224\184\181\224\185\136",
		["mounts"] = nil,
		["mounts"] = {
			{
				["id"] = "Bar",
				["th"] = "\224\184\149\224\184\180\224\184\148\224\185\129\224\184\174\224\184\153\224\184\148\224\185\140"
			},
			{
				["id"] = "Tail",
				["th"] = "\224\184\149\224\184\180\224\184\148\224\184\151\224\185\137\224\184\178\224\184\162\224\184\163\224\184\150"
			}
		}
	}
}
v_u_2.PARTS_ATTR = "CamParts"
v_u_2.PARTS_FOLDER = "DashcamParts"
v_u_2.VISUALS = "CamPartVisuals"
v_u_2.EDITING = "CamPartsEditing"
v_u_2.MAX_PARTS = 1
v_u_2.SCALE_STEP = 0.1
v_u_2.MIN_SCALE = 0.8
v_u_2.MAX_SCALE = 1.2
v_u_2.REACH_OFF = 3
v_u_2.PARTS = {
	{
		["id"] = "ActionCam",
		["item"] = "CamAction",
		["th"] = "\224\184\129\224\184\165\224\185\137\224\184\173\224\184\135\224\185\129\224\184\173\224\185\135\224\184\132\224\184\138\224\184\177\224\185\136\224\184\153\224\185\129\224\184\132\224\184\161",
		["line"] = "\224\184\129\224\184\165\224\185\137\224\184\173\224\184\135\224\184\149\224\184\177\224\184\167\224\185\128\224\184\165\224\185\135\224\184\129\224\184\158\224\184\163\224\185\137\224\184\173\224\184\161\224\184\130\224\184\178\224\184\136\224\184\177\224\184\154 \224\184\149\224\184\180\224\184\148\224\185\132\224\184\148\224\185\137\224\184\151\224\184\184\224\184\129\224\184\136\224\184\184\224\184\148\224\184\154\224\184\153\224\184\163\224\184\150 \194\183 \224\184\129\224\184\148 U \224\184\148\224\184\185\224\184\161\224\184\184\224\184\161\224\184\129\224\184\165\224\185\137\224\184\173\224\184\135",
		["lens"] = Vector3.new(0.01, 0.225, -0.09)
	},
	{
		["id"] = "PoleCam360",
		["item"] = "CamPole360",
		["th"] = "\224\184\129\224\184\165\224\185\137\224\184\173\224\184\135 360 \224\184\130\224\184\178\224\184\136\224\184\177\224\184\154",
		["line"] = "\224\184\129\224\184\165\224\185\137\224\184\173\224\184\135 360 \224\184\154\224\184\153\224\184\129\224\185\137\224\184\178\224\184\153 \224\184\149\224\184\180\224\184\148\224\184\149\224\184\163\224\184\135\224\185\132\224\184\171\224\184\153\224\184\129\224\185\135\224\185\132\224\184\148\224\185\137 \194\183 \224\184\129\224\184\148 U \224\184\148\224\184\185\224\184\161\224\184\184\224\184\161 360",
		["lens"] = Vector3.new(0, 0.8, 0)
	}
}
v_u_2.LENS = {
	{
		["id"] = "planet",
		["th"] = "PLANET",
		["f"] = 150,
		["d"] = 0.6
	},
	{
		["id"] = "mega",
		["th"] = "MEGA",
		["f"] = 145,
		["d"] = 0.9
	},
	{
		["id"] = "ultra",
		["th"] = "ULTRA",
		["f"] = 130.8,
		["d"] = 0.95
	},
	{
		["id"] = "dewarp",
		["th"] = "DEWARP",
		["f"] = 110,
		["d"] = 0.7
	},
	{
		["id"] = "linear",
		["th"] = "LINEAR",
		["f"] = 85,
		["d"] = 0.4
	}
}
v_u_2.LENS_DEFAULT = "ultra"
v_u_2.FOV_MIN = 60
v_u_2.FOV_MAX = 150
v_u_2.PULL = 1.6
v_u_2.PLANET_UP = 0.8
function v_u_2.lens(p3) -- name: lens
	-- upvalues: (copy) v_u_2
	for _, v4 in v_u_2.LENS do
		if v4.id ~= p3 then
			continue
		end
		return v4
	end
	return nil
end
function v_u_2.viewOf(p5) -- name: viewOf
	-- upvalues: (copy) v_u_2
	local v6 = v_u_2.lens
	local v7
	if p5 then
		v7 = p5.m
	else
		v7 = p5
	end
	local v8 = v6(v7) or v_u_2.lens(v_u_2.LENS_DEFAULT)
	local v9, v10, v11, v12, v13
	if p5 then
		local v14 = p5.f
		if typeof(v14) == "number" then
			v9 = p5.f
			if not p5 then
				v10 = v8.d
				v11 = v8.id
				v12 = v_u_2.FOV_MIN
				v13 = v_u_2.FOV_MAX
				return v11, math.clamp(v9, v12, v13), math.clamp(v10, 0, 1)
			end
		else
			v9 = v8.f
			if not p5 then
				v10 = v8.d
				v11 = v8.id
				v12 = v_u_2.FOV_MIN
				v13 = v_u_2.FOV_MAX
				return v11, math.clamp(v9, v12, v13), math.clamp(v10, 0, 1)
			end
		end
	else
		v9 = v8.f
		if not p5 then
			v10 = v8.d
			v11 = v8.id
			v12 = v_u_2.FOV_MIN
			v13 = v_u_2.FOV_MAX
			return v11, math.clamp(v9, v12, v13), math.clamp(v10, 0, 1)
		end
	end
	local v15 = p5.d
	if typeof(v15) == "number" then
		v10 = p5.d
		v11 = v8.id
		v12 = v_u_2.FOV_MIN
		v13 = v_u_2.FOV_MAX
		return v11, math.clamp(v9, v12, v13), math.clamp(v10, 0, 1)
	else
		v10 = v8.d
		v11 = v8.id
		v12 = v_u_2.FOV_MIN
		v13 = v_u_2.FOV_MAX
		return v11, math.clamp(v9, v12, v13), math.clamp(v10, 0, 1)
	end
end
function v_u_2.vfov(p16, p17) -- name: vfov
	local v18 = math.rad(p16) / 2
	local v19 = math.tan(v18) / math.max(p17, 0.1)
	local v20 = math.atan(v19) * 2
	local v21 = math.deg(v20)
	return math.clamp(v21, 20, 120)
end
function v_u_2.across(p22, p23) -- name: across
	local v24 = math.rad(p22) / 2
	local v25 = math.tan(v24) * p23
	local v26 = math.atan(v25) * 2
	return math.deg(v26)
end
function v_u_2.viewThrough(p27, p28, p29, p30, p31, p32, p33, p34) -- name: viewThrough
	-- upvalues: (copy) v_u_2
	local v35 = v_u_2.part(p27.c)
	local v36 = p28:PointToWorldSpace((v35 and v35.lens or Vector3.new(0, 0, 0)) * (p27.s or 1))
	local v37, v38, v39 = v_u_2.viewOf(p27)
	local v40 = v_u_2.vfov(v38, p29) + (p34 or 0)
	local v41 = math.clamp(v40, 20, 120)
	local v42 = p30 + (p32 or 0)
	if v37 ~= "planet" then
		local v43 = p31 + (p33 or 0)
		local v44 = math.clamp(v43, -1.4835298641951802, 1.4835298641951802)
		return CFrame.new(v36) * CFrame.fromEulerAnglesYXZ(v44, v42, 0) * CFrame.new(0, 0, (1 - v39) * v_u_2.PULL), v41
	end
	local v45 = -1.53588974175501 + (p33 or 0)
	local v46 = math.clamp(v45, -1.5533430342749532, -0.3490658503988659)
	local v47 = v36 + Vector3.new(0, 1, 0) * (v_u_2.PLANET_UP + (1 - v39) * 2.4)
	return CFrame.new(v47) * CFrame.fromEulerAnglesYXZ(v46, v42, 0), v41
end
local v_u_48 = { "collider", "hitbox" }
local v_u_49 = {
	["StickerVisuals"] = true,
	["CamPartVisuals"] = true
}
function v_u_2.part(p50) -- name: part
	-- upvalues: (copy) v_u_2
	for _, v51 in v_u_2.PARTS do
		if v51.id ~= p50 then
			continue
		end
		return v51
	end
	return nil
end
function v_u_2.template(p52) -- name: template
	-- upvalues: (copy) v_u_2
	local v53 = game:GetService("ReplicatedStorage"):FindFirstChild(v_u_2.PARTS_FOLDER)
	if v53 then
		v53 = v53:FindFirstChild(p52)
	end
	return v53
end
function v_u_2.mountable(p54, p55) -- name: mountable
	-- upvalues: (copy) v_u_49, (copy) v_u_48
	if not p54:IsA("BasePart") or (not p54:IsDescendantOf(p55) or p54.Transparency >= 0.95) then
		return false
	end
	while p54 and p54 ~= p55 do
		if v_u_49[p54.Name] then
			return false
		end
		local v56 = p54.Name:lower()
		for _, v57 in v_u_48 do
			if not v56:find(v57, 1, true) then
				continue
			end
			return false
		end
		p54 = p54.Parent
	end
	return true
end
function v_u_2.keyOf(p58, p59) -- name: keyOf
	local v60 = p59:GetAttribute("Panel")
	if type(v60) == "string" then
		return "P:" .. v60
	else
		local v61 = p59
		local v62 = {}
		while p59 and p59 ~= p58 do
			local v63 = 0
			for _, v64 in p59.Parent:GetChildren() do
				if v64.Name == p59.Name then
					v63 = v63 + 1
				end
				if v64 ~= p59 then
					continue
				end
			end
			local v65 = 1
			local v66
			if v63 > 1 then
				v66 = p59.Name .. "#" .. v63
			else
				v66 = p59.Name
			end
			table.insert(v62, v65, v66)
			p59 = p59.Parent
		end
		if p59 == p58 then
			return table.concat(v62, "/") .. ("|%.2f,%.2f,%.2f"):format(v61.Size.X, v61.Size.Y, v61.Size.Z)
		else
			return nil
		end
	end
end
function v_u_2.find(p67, p68) -- name: find
	if type(p68) == "string" and p68 ~= "" then
		if p68:sub(1, 2) == "P:" then
			local v69 = p68:sub(3)
			for _, v70 in p67:GetDescendants() do
				if not v70:IsA("BasePart") or v70:GetAttribute("Panel") ~= v69 then
					continue
				end
				return v70
			end
			return nil
		else
			local v71, v72 = p68:match("^(.*)|([^|]*)$")
			local v73 = v71 or p68
			local v74
			if v72 then
				local v75, v76
				v74, v75, v76 = v72:match("^([%d%.%-]+),([%d%.%-]+),([%d%.%-]+)$")
				if v74 then
					local v77 = tonumber(v74)
					local v78 = tonumber(v75)
					local v79 = tonumber(v76)
					v74 = Vector3.new(v77, v78, v79)
				end
			else
				v74 = nil
			end
			local v80 = string.split(v73, "/")
			for v81, v82 in v80 do
				local v83, v84 = v82:match("^(.*)#(%d+)$")
				local v85 = tonumber(v84) or 1
				p67 = nil
				local v86 = v83 or v82
				local v87 = 0
				local v88 = nil
				for _, v89 in p67:GetChildren() do
					if v89.Name ~= v86 then
						continue
					end
					v87 = v87 + 1
					if v87 == v85 then
						v88 = v89
					end
					if v81 ~= #v80 or (not v74 or p67) then
						continue
					end
					local v90 = v89:IsA("BasePart")
					if v90 then
						v90 = (v89.Size - v74).Magnitude < 0.03
					end
					if not v90 then
						continue
					end
					p67 = v89
				end
				if v81 == #v80 and v74 then
					if v88 then
						local v91 = v88:IsA("BasePart")
						if v91 then
							v91 = (v88.Size - v74).Magnitude < 0.03
						end
						if v91 then
							p67 = v88
						end
					end
				else
					p67 = v88
				end
				if p67 then
					break
				end
				return nil
			end
			if p67:IsA("BasePart") then
				return p67
			else
				return nil
			end
		end
	else
		return nil
	end
end
function v_u_2.offset(p92) -- name: offset
	local v93 = CFrame.new(p92.o)
	local v94 = CFrame.fromEulerAnglesXYZ
	local v95 = p92.r.X
	local v96 = math.rad(v95)
	local v97 = p92.r.Y
	local v98 = math.rad(v97)
	local v99 = p92.r.Z
	return v93 * v94(v96, v98, (math.rad(v99)))
end
function v_u_2.entry(p100, p101, p102, p103) -- name: entry
	local v104, v105, v106 = p102:ToEulerAnglesXYZ()
	local v107 = {
		["c"] = p100,
		["k"] = p101,
		["o"] = p102.Position
	}
	local v108 = math.deg(v104)
	local v109 = math.deg(v105)
	local v110 = math.deg(v106)
	v107.r = Vector3.new(v108, v109, v110)
	v107.s = p103
	return v107
end
function v_u_2.decode(p111) -- name: decode
	-- upvalues: (copy) v_u_1, (copy) v_u_2
	local v112 = {}
	if type(p111) == "string" then
		local v113 = v_u_1.JSONDecode
		local v114 = v_u_1
		local v115
		v115, p111 = pcall(v113, v114, p111)
		if not v115 then
			p111 = nil
		end
	end
	if type(p111) ~= "table" then
		return v112
	end
	for _, v116 in p111 do
		if #v112 >= v_u_2.MAX_PARTS then
			break
		end
		if type(v116) ~= "table" then
			continue
		end
		local v117 = v116.c
		if type(v117) ~= "string" or not v_u_2.part(v116.c) then
			continue
		end
		local v118 = v116.k
		if type(v118) ~= "string" or #v116.k > 200 then
			continue
		end
		local v119 = v116.o
		local v120
		if type(v119) == "table" then
			local v121 = v119[1]
			local v122
			if typeof(v121) == "number" and v121 == v121 then
				v122 = math.abs(v121) < 100000
			else
				v122 = false
			end
			if v122 then
				local v123 = v119[2]
				local v124
				if typeof(v123) == "number" and v123 == v123 then
					v124 = math.abs(v123) < 100000
				else
					v124 = false
				end
				if v124 then
					local v125 = v119[3]
					local v126
					if typeof(v125) == "number" and v125 == v125 then
						v126 = math.abs(v125) < 100000
					else
						v126 = false
					end
					if v126 then
						local v127 = v119[1]
						local v128 = v119[2]
						local v129 = v119[3]
						v120 = Vector3.new(v127, v128, v129)
					else
						v120 = nil
					end
				else
					v120 = nil
				end
			else
				v120 = nil
			end
		else
			v120 = nil
		end
		local v130 = v116.r
		local v131
		if type(v130) == "table" then
			local v132 = v130[1]
			local v133
			if typeof(v132) == "number" and v132 == v132 then
				v133 = math.abs(v132) < 100000
			else
				v133 = false
			end
			if v133 then
				local v134 = v130[2]
				local v135
				if typeof(v134) == "number" and v134 == v134 then
					v135 = math.abs(v134) < 100000
				else
					v135 = false
				end
				if v135 then
					local v136 = v130[3]
					local v137
					if typeof(v136) == "number" and v136 == v136 then
						v137 = math.abs(v136) < 100000
					else
						v137 = false
					end
					if v137 then
						local v138 = v130[1]
						local v139 = v130[2]
						local v140 = v130[3]
						v131 = Vector3.new(v138, v139, v140)
					else
						v131 = nil
					end
				else
					v131 = nil
				end
			else
				v131 = nil
			end
		else
			v131 = nil
		end
		local v141 = v116.s
		local v142
		if typeof(v141) == "number" and v141 == v141 then
			v142 = math.abs(v141) < 100000
		else
			v142 = false
		end
		local v143
		if v142 then
			local v144 = v116.s
			local v145 = v_u_2.MIN_SCALE
			local v146 = v_u_2.MAX_SCALE
			v143 = math.clamp(v144, v145, v146)
		else
			v143 = 1
		end
		if not (v120 and v131) then
			continue
		end
		local v147 = v116.m
		local v148
		if type(v147) == "string" and v_u_2.lens(v116.m) then
			v148 = v116.m
		else
			v148 = nil
		end
		local v149 = v116.f
		local v150
		if typeof(v149) == "number" and v149 == v149 then
			v150 = math.abs(v149) < 100000
		else
			v150 = false
		end
		local v151
		if v150 then
			local v152 = v116.f
			local v153 = v_u_2.FOV_MIN
			local v154 = v_u_2.FOV_MAX
			v151 = math.clamp(v152, v153, v154)
		else
			v151 = nil
		end
		local v155 = v116.d
		local v156
		if typeof(v155) == "number" and v155 == v155 then
			v156 = math.abs(v155) < 100000
		else
			v156 = false
		end
		local v157
		if v156 then
			local v158 = v116.d
			v157 = math.clamp(v158, 0, 1)
		else
			v157 = nil
		end
		local v159 = {
			["c"] = v116.c,
			["k"] = v116.k,
			["o"] = v120,
			["r"] = v131,
			["s"] = v143,
			["m"] = v148,
			["f"] = v151,
			["d"] = v157
		}
		table.insert(v112, v159)
	end
	return v112
end
function v_u_2.wire(p160) -- name: wire
	local v161 = {}
	for _, v162 in p160 do
		local v163 = {
			["c"] = v162.c,
			["k"] = v162.k
		}
		local v164 = {}
		local v165 = v162.o.X / 0.001
		local v166 = math.round(v165) * 0.001
		local v167 = v162.o.Y / 0.001
		local v168 = math.round(v167) * 0.001
		local v169 = v162.o.Z / 0.001
		__set_list(v164, 1, {v166, v168, math.round(v169) * 0.001})
		v163.o = v164
		local v170 = {}
		local v171 = v162.r.X / 0.1
		local v172 = math.round(v171) * 0.1
		local v173 = v162.r.Y / 0.1
		local v174 = math.round(v173) * 0.1
		local v175 = v162.r.Z / 0.1
		__set_list(v170, 1, {v172, v174, math.round(v175) * 0.1})
		v163.r = v170
		local v176 = v162.s / 0.01
		v163.s = math.round(v176) * 0.01
		v163.m = v162.m
		local v177 = v162.f
		local v178
		if typeof(v177) == "number" then
			local v179 = v162.f / 0.1
			v178 = math.round(v179) * 0.1
		else
			v178 = nil
		end
		v163.f = v178
		local v180 = v162.d
		local v181
		if typeof(v180) == "number" then
			local v182 = v162.d / 0.01
			v181 = math.round(v182) * 0.01
		else
			v181 = nil
		end
		v163.d = v181
		table.insert(v161, v163)
	end
	return v161
end
function v_u_2.encode(p183) -- name: encode
	-- upvalues: (copy) v_u_1, (copy) v_u_2
	return v_u_1:JSONEncode(v_u_2.wire(p183))
end
function v_u_2.read(p184) -- name: read
	-- upvalues: (copy) v_u_2
	return v_u_2.decode(p184:GetAttribute(v_u_2.PARTS_ATTR))
end
function v_u_2.check(p185, p186) -- name: check
	-- upvalues: (copy) v_u_2
	if not (v_u_2.part(p185.c) and v_u_2.template(p185.c)) then
		return false, "\224\185\132\224\184\161\224\185\136\224\184\161\224\184\181\224\184\129\224\184\165\224\185\137\224\184\173\224\184\135\224\184\163\224\184\184\224\185\136\224\184\153\224\184\153\224\184\181\224\185\137"
	end
	local v187 = v_u_2.find(p186, p185.k)
	if not (v187 and v_u_2.mountable(v187, p186)) then
		return false, "\224\184\171\224\184\178\224\184\138\224\184\180\224\185\137\224\184\153\224\184\170\224\185\136\224\184\167\224\184\153\224\184\153\224\184\181\224\185\137\224\184\154\224\184\153\224\184\163\224\184\150\224\185\132\224\184\161\224\185\136\224\185\128\224\184\136\224\184\173 \224\184\165\224\184\173\224\184\135\224\184\149\224\184\180\224\184\148\224\184\129\224\184\165\224\185\137\224\184\173\224\184\135\224\185\131\224\184\171\224\184\161\224\185\136"
	end
	local v188 = v187.Size / 2 + Vector3.new(1, 1, 1) * v_u_2.REACH_OFF
	local v189 = p185.o.X
	if math.abs(v189) <= v188.X then
		local v190 = p185.o.Y
		if math.abs(v190) <= v188.Y then
			local v191 = p185.o.Z
			if math.abs(v191) <= v188.Z then
				if p185.s < v_u_2.MIN_SCALE - 1e-6 or p185.s > v_u_2.MAX_SCALE + 1e-6 then
					return false, "\224\184\130\224\184\153\224\184\178\224\184\148\224\185\132\224\184\161\224\185\136\224\184\150\224\184\185\224\184\129\224\184\149\224\185\137\224\184\173\224\184\135"
				else
					return true
				end
			end
		end
	end
	return false, "\224\184\129\224\184\165\224\185\137\224\184\173\224\184\135\224\184\171\224\184\165\224\184\184\224\184\148\224\184\173\224\184\173\224\184\129\224\184\136\224\184\178\224\184\129\224\184\149\224\184\177\224\184\167\224\184\163\224\184\150"
end
function v_u_2.makeModel(p192, p193) -- name: makeModel
	-- upvalues: (copy) v_u_2
	local v194 = v_u_2.template(p192)
	if not v194 then
		return nil
	end
	local v195 = v194:Clone()
	local v196 = p193 - 1
	if math.abs(v196) > 0.001 then
		v195:ScaleTo(p193)
	end
	return v195
end
function v_u_2.build(p197, p198, p199) -- name: build
	-- upvalues: (copy) v_u_2
	for v200, v201 in p198 do
		local v202 = v_u_2.find(p197, v201.k)
		local v203
		if v202 then
			v203 = v_u_2.makeModel(v201.c, v201.s)
		else
			v203 = v202
		end
		if not v203 then
			continue
		end
		v203.Name = "C" .. v200
		v203:PivotTo(v202.CFrame * v_u_2.offset(v201))
		for _, v204 in v203:GetDescendants() do
			if not v204:IsA("BasePart") then
				continue
			end
			v204.Anchored = false
		end
		local v205 = Instance.new("WeldConstraint")
		v205.Name = "OnVehicle"
		local v206 = v203.PrimaryPart
		v205.Part0 = v202
		v205.Part1 = v206
		v205.Parent = v203.PrimaryPart
		v203.Parent = p199
	end
end
function v_u_2.camera(p207) -- name: camera
	-- upvalues: (copy) v_u_2
	for _, v208 in v_u_2.CAMERAS do
		if v208.id ~= p207 then
			continue
		end
		return v208
	end
	return nil
end
function v_u_2.mount(p209, p210) -- name: mount
	for _, v211 in p209.mounts do
		if v211.id ~= p210 then
			continue
		end
		return v211
	end
	return nil
end
function v_u_2.inBay(p212) -- name: inBay
	-- upvalues: (copy) v_u_2
	local v213 = v_u_2.BAY_MIN
	local v214 = v_u_2.BAY_MAX
	local v215
	if p212.X >= v213.X and (p212.X <= v214.X and (p212.Y >= v213.Y and (p212.Y <= v214.Y and p212.Z >= v213.Z))) then
		v215 = p212.Z <= v214.Z
	else
		v215 = false
	end
	return v215
end
function v_u_2.driven(p216) -- name: driven
	local v217 = p216.Character
	if v217 then
		v217 = p216.Character:FindFirstChildOfClass("Humanoid")
	end
	if v217 then
		v217 = v217.SeatPart
	end
	if not v217 or v217.Name ~= "VehicleSeat" and v217.Name ~= "DriverSeat" then
		return nil
	end
	local v218 = workspace:FindFirstChild("SpawnedVehicles")
	local v219 = v217.Parent
	while v219 and v219 ~= workspace do
		if v219.Parent == v218 then
			return v219
		end
		v219 = v219.Parent
	end
	return nil
end
function v_u_2.vehicleInBay(p220) -- name: vehicleInBay
	-- upvalues: (copy) v_u_2
	local v221 = workspace:FindFirstChild("SpawnedVehicles")
	for _, v222 in not v221 and {} or v221:GetChildren() do
		if not v222:IsA("Model") or (v222:GetAttribute("OwnerUserId") ~= p220 or not v_u_2.inBay(v222:GetPivot().Position)) then
			continue
		end
		return v222
	end
	return nil
end
return v_u_2