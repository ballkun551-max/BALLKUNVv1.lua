-- Path: StarterPlayer/StarterPlayerScripts/StickerEditorClient
-- Class: LocalScript  true/Enum.RunContext.Legacy
-- Decompiled by BALL KUN Universal Map Dump

local v1 = game:GetService("ReplicatedStorage"):FindFirstChild("UiOwn")
local v_u_2
if v1 then
	v_u_2 = require(v1).Instance
else
	v_u_2 = Instance
end
local v_u_3 = require(game:GetService("ReplicatedStorage"):WaitForChild("NetSeal"))
local v4 = game:GetService("Players")
local v5 = game:GetService("ReplicatedStorage")
local v6 = game:GetService("RunService")
local v_u_7 = game:GetService("UserInputService")
local v_u_8 = game:GetService("CollectionService")
local v_u_9 = game:GetService("GuiService")
local v_u_10 = require(v5:WaitForChild("GameShared"))
local v_u_11 = require(v5:WaitForChild("StickerBuilder"))
local v_u_12 = require(v5:WaitForChild("StickerCatalog"))
local v_u_13 = require(v5:WaitForChild("GameUI"):WaitForChild("Toast"))
local v_u_14 = require(v5:WaitForChild("GameUI"):WaitForChild("Theme"))
local v15 = require(v5:WaitForChild("GameUI"):WaitForChild("Skin"))
local v_u_16 = require(v5:WaitForChild("StickerZone"))
local v_u_17 = v4.LocalPlayer
local v_u_18 = v5:WaitForChild(v_u_10.REMOTES)
local v_u_19 = v_u_18:WaitForChild("Sticker")
local v_u_20 = v_u_18:WaitForChild("StickerHold")
local v_u_21 = {
	["panel"] = v_u_14.PANEL,
	["card"] = v15.IDLE,
	["cardHi"] = Color3.fromRGB(72, 76, 96),
	["well"] = v_u_14.CARD_DARK,
	["line"] = Color3.fromRGB(78, 82, 102),
	["text"] = v_u_14.TEXT,
	["dim"] = v_u_14.TEXT_DIM,
	["accent"] = v_u_14.YELLOW,
	["pink"] = v_u_14.GRAD.pink[1],
	["good"] = v_u_14.ACCENT,
	["warn"] = v_u_14.ORANGE,
	["danger"] = v_u_14.RED,
	["admin"] = Color3.fromRGB(255, 110, 118),
	["btn"] = v15.IDLE,
	["thumb"] = Color3.fromRGB(48, 50, 64),
	["picked"] = Color3.fromRGB(70, 60, 30),
	["onAccent"] = v_u_14.DARK_TEXT
}
local v_u_22 = Enum.Font.GothamBold
local v_u_23 = Enum.Font.GothamMedium
local function v_u_39(p24, p25, p26, p27, p28, p29, p30) -- name: bar
	-- upvalues: (copy) v_u_2
	local v31 = {
		["AnchorPoint"] = nil,
		["Size"] = nil,
		["Position"] = nil,
		["Rotation"] = nil,
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Size"] = UDim2.fromOffset(p25, p26),
		["Position"] = UDim2.new(0.5, p29 or 0, 0.5, p30 or 0),
		["Rotation"] = p27,
		["BackgroundColor3"] = p28
	}
	local v32 = v_u_2.new("Frame")
	for v33, v34 in v31 do
		v32[v33] = v34
	end
	v32.Parent = p24
	local v35 = {
		["CornerRadius"] = UDim.new(0, 2)
	}
	local v36 = v_u_2.new("UICorner")
	for v37, v38 in v35 do
		v36[v37] = v38
	end
	v36.Parent = v32
	return v32
end
local v_u_40 = {}
local v41 = {
	["Name"] = "StickerEditor",
	["ResetOnSpawn"] = false,
	["DisplayOrder"] = 7,
	["ZIndexBehavior"] = nil,
	["ZIndexBehavior"] = Enum.ZIndexBehavior.Sibling
}
local v42 = v_u_17:WaitForChild("PlayerGui")
local v43 = v_u_2.new("ScreenGui")
local function v_u_56(p44, p45, p46, p47, p48, p49) -- name: label
	-- upvalues: (copy) v_u_23, (copy) v_u_2
	local v50 = {
		["BackgroundTransparency"] = 1,
		["Text"] = nil,
		["TextSize"] = nil,
		["TextColor3"] = nil,
		["Font"] = nil,
		["TextXAlignment"] = nil,
		["TextYAlignment"] = nil,
		["Text"] = p45,
		["TextSize"] = p46,
		["TextColor3"] = p47,
		["Font"] = p48 or v_u_23,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["TextYAlignment"] = Enum.TextYAlignment.Center
	}
	local v51 = v_u_2.new("TextLabel")
	for v52, v53 in v50 do
		v51[v52] = v53
	end
	v51.Parent = p44
	for v54, v55 in p49 or {} do
		v51[v54] = v55
	end
	return v51
end
local function v_u_72(p57, p58, p59, p60, p61) -- name: button
	-- upvalues: (copy) v_u_22, (copy) v_u_21, (copy) v_u_2
	local v62 = {
		["Text"] = nil,
		["Font"] = nil,
		["TextSize"] = 14,
		["TextColor3"] = nil,
		["BackgroundColor3"] = nil,
		["AutoButtonColor"] = true,
		["BorderSizePixel"] = 0,
		["Text"] = p58,
		["Font"] = v_u_22,
		["TextColor3"] = p61 or v_u_21.text,
		["BackgroundColor3"] = p60 or v_u_21.btn
	}
	local v63 = v_u_2.new("TextButton")
	for v64, v65 in v62 do
		v63[v64] = v65
	end
	v63.Parent = p57
	for v66, v67 in p59 or {} do
		v63[v66] = v67
	end
	local v68 = {
		["CornerRadius"] = UDim.new(0, 8)
	}
	local v69 = v_u_2.new("UICorner")
	for v70, v71 in v68 do
		v69[v70] = v71
	end
	v69.Parent = v63
	return v63
end
local function v_u_80(p73, p74, p75) -- name: icon
	-- upvalues: (copy) v_u_2, (copy) v_u_39
	local v76 = {
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.5),
		["Size"] = UDim2.fromOffset(16, 16)
	}
	local v77 = v_u_2.new("Frame")
	for v78, v79 in v76 do
		v77[v78] = v79
	end
	v77.Parent = p73
	if p74 == "up" then
		v_u_39(v77, 9, 2.5, -45, p75, -2.8, 0)
		v_u_39(v77, 9, 2.5, 45, p75, 2.8, 0)
		return v77
	end
	if p74 == "down" then
		v_u_39(v77, 9, 2.5, 45, p75, -2.8, 0)
		v_u_39(v77, 9, 2.5, -45, p75, 2.8, 0)
		return v77
	end
	if p74 == "left" then
		v_u_39(v77, 9, 2.5, -45, p75, 0, -2.8)
		v_u_39(v77, 9, 2.5, 45, p75, 0, 2.8)
		return v77
	end
	if p74 == "right" then
		v_u_39(v77, 9, 2.5, 45, p75, 0, -2.8)
		v_u_39(v77, 9, 2.5, -45, p75, 0, 2.8)
		return v77
	end
	if p74 == "x" then
		v_u_39(v77, 13, 2.5, 45, p75)
		v_u_39(v77, 13, 2.5, -45, p75)
		return v77
	end
	if p74 ~= "plus" then
		if p74 == "minus" then
			v_u_39(v77, 13, 2.5, 0, p75)
		end
		return v77
	end
	v_u_39(v77, 13, 2.5, 0, p75)
	v_u_39(v77, 13, 2.5, 90, p75)
	return v77
end
local function v133(p81, p82, p83, p84, p_u_85, p_u_86) -- name: makeSlider
	-- upvalues: (copy) v_u_21, (copy) v_u_2, (copy) v_u_40
	local v87 = {
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Position"] = UDim2.fromOffset(p82, p83),
		["Size"] = UDim2.fromOffset(p84, 6),
		["BackgroundColor3"] = v_u_21.btn
	}
	local v_u_88 = v_u_2.new("Frame")
	for v89, v90 in v87 do
		v_u_88[v89] = v90
	end
	v_u_88.Parent = p81
	local v91 = {
		["CornerRadius"] = UDim.new(0, 3)
	}
	local v92 = v_u_2.new("UICorner")
	for v93, v94 in v91 do
		v92[v93] = v94
	end
	v92.Parent = v_u_88
	local v95 = {
		["Size"] = nil,
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = UDim2.fromScale(0, 1),
		["BackgroundColor3"] = v_u_21.accent
	}
	local v_u_96 = v_u_2.new("Frame")
	for v97, v98 in v95 do
		v_u_96[v97] = v98
	end
	v_u_96.Parent = v_u_88
	local v99 = {
		["CornerRadius"] = UDim.new(0, 3)
	}
	local v100 = v_u_2.new("UICorner")
	for v101, v102 in v99 do
		v100[v101] = v102
	end
	v100.Parent = v_u_96
	local v103 = {
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["ZIndex"] = 3,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0, 0.5),
		["Size"] = UDim2.fromOffset(18, 18),
		["BackgroundColor3"] = Color3.new(1, 1, 1)
	}
	local v_u_104 = v_u_2.new("Frame")
	for v105, v106 in v103 do
		v_u_104[v105] = v106
	end
	v_u_104.Parent = v_u_88
	local v107 = {
		["CornerRadius"] = UDim.new(0, 9)
	}
	local v108 = v_u_2.new("UICorner")
	for v109, v110 in v107 do
		v108[v109] = v110
	end
	v108.Parent = v_u_104
	local v111 = {
		["Color"] = nil,
		["Thickness"] = 2,
		["ApplyStrokeMode"] = nil,
		["Color"] = v_u_21.accent,
		["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border
	}
	local v112 = v_u_2.new("UIStroke")
	for v113, v114 in v111 do
		v112[v113] = v114
	end
	v112.Parent = v_u_104
	local v115 = {
		["Text"] = "",
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["AutoButtonColor"] = false,
		["ZIndex"] = 4,
		["Position"] = UDim2.new(0, -12, 0, -13),
		["Size"] = UDim2.new(1, 24, 0, 32)
	}
	local v116 = v_u_2.new("TextButton")
	for v117, v118 in v115 do
		v116[v117] = v118
	end
	v116.Parent = v_u_88
	local v_u_120 = {
		["value"] = 0,
		["dragging"] = false,
		["set"] = function(p119) -- name: set
			-- upvalues: (copy) v_u_120, (copy) v_u_96, (copy) v_u_104
			v_u_120.value = math.clamp(p119, 0, 1)
			v_u_96.Size = UDim2.fromScale(v_u_120.value, 1)
			v_u_104.Position = UDim2.fromScale(v_u_120.value, 0.5)
		end
	}
	v116.InputBegan:Connect(function(p121)
		-- upvalues: (copy) v_u_120, (copy) v_u_88, (copy) p_u_85
		local v122 = p121.UserInputType
		if v122 == Enum.UserInputType.MouseButton1 or v122 == Enum.UserInputType.Touch then
			v_u_120.dragging = true
			local v123 = v_u_120.set
			local v124 = p121.Position.X - v_u_88.AbsolutePosition.X
			local v125 = v_u_88.AbsoluteSize.X
			local v126 = v124 / math.max(1, v125)
			v123((math.clamp(v126, 0, 1)))
			p_u_85(v_u_120.value)
		end
	end)
	function v_u_120.move(p127)
		-- upvalues: (copy) v_u_120, (copy) v_u_88, (copy) p_u_85
		if v_u_120.dragging then
			local v128 = v_u_120.set
			local v129 = p127.Position.X - v_u_88.AbsolutePosition.X
			local v130 = v_u_88.AbsoluteSize.X
			local v131 = v129 / math.max(1, v130)
			v128((math.clamp(v131, 0, 1)))
			p_u_85(v_u_120.value)
		end
	end
	function v_u_120.stop()
		-- upvalues: (copy) v_u_120, (copy) p_u_86
		if v_u_120.dragging then
			v_u_120.dragging = false
			p_u_86(v_u_120.value)
		end
	end
	local v132 = v_u_40
	table.insert(v132, v_u_120)
	return v_u_120
end
local function v_u_140(p134, p135, p136) -- name: new
	-- upvalues: (copy) v_u_2
	local v137 = v_u_2.new(p134)
	for v138, v139 in p135 do
		v137[v138] = v139
	end
	v137.Parent = p136
	return v137
end
local function v_u_147(p141, p142) -- name: corner
	-- upvalues: (copy) v_u_2
	local v143 = {
		["CornerRadius"] = UDim.new(0, p142)
	}
	local v144 = v_u_2.new("UICorner")
	for v145, v146 in v143 do
		v144[v145] = v146
	end
	v144.Parent = p141
	return v144
end
local function v_u_155(p148, p149, p150) -- name: stroke
	-- upvalues: (copy) v_u_2
	local v151 = {
		["Color"] = p149,
		["Thickness"] = p150 or 1,
		["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border
	}
	local v152 = v_u_2.new("UIStroke")
	for v153, v154 in v151 do
		v152[v153] = v154
	end
	v152.Parent = p148
	return v152
end
for v156, v157 in v41 do
	v43[v156] = v157
end
v43.Parent = v42
v15.apply(v43)
local v158 = {
	["Name"] = "TileSticker",
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["BackgroundColor3"] = nil,
	["BackgroundTransparency"] = 0.05,
	["Text"] = "",
	["AutoButtonColor"] = true,
	["Visible"] = false,
	["AnchorPoint"] = Vector2.new(0, 0.5),
	["Position"] = UDim2.new(0, 14, 0.4, 132),
	["Size"] = UDim2.fromOffset(190, 64),
	["BackgroundColor3"] = v_u_21.card
}
local v_u_159 = v_u_2.new("TextButton")
for v160, v161 in v158 do
	v_u_159[v160] = v161
end
v_u_159.Parent = v43
local v162 = {
	["CornerRadius"] = UDim.new(0, 14)
}
local v163 = v_u_2.new("UICorner")
for v164, v165 in v162 do
	v163[v164] = v165
end
v163.Parent = v_u_159
local v166 = {
	["Color"] = nil,
	["Thickness"] = 1,
	["ApplyStrokeMode"] = nil,
	["Color"] = Color3.new(1, 1, 1),
	["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border
}
local v167 = v_u_2.new("UIStroke")
for v168, v169 in v166 do
	v167[v168] = v169
end
v167.Parent = v_u_159
v167.Transparency = 0.85
local v170 = v_u_14.badge(v_u_159, "brush", "gold", 40)
v170.AnchorPoint = Vector2.new(0, 0.5)
v170.Position = UDim2.new(0, 12, 0.5, 0)
local v_u_171 = v_u_56(v_u_159, "\224\184\170\224\184\149\224\184\180\224\185\138\224\184\129\224\185\128\224\184\129\224\184\173\224\184\163\224\185\140", 20, v_u_21.text, v_u_22, {
	["Position"] = UDim2.fromOffset(62, 9),
	["Size"] = UDim2.fromOffset(120, 26)
})
local v_u_172 = v_u_56(v_u_159, "\224\185\129\224\184\155\224\184\176\224\184\165\224\184\178\224\184\162\224\184\154\224\184\153\224\184\163\224\184\150", 13, v_u_21.dim, v_u_23, {
	["Position"] = UDim2.fromOffset(62, 35),
	["Size"] = UDim2.fromOffset(120, 18),
	["TextTruncate"] = Enum.TextTruncate.AtEnd
})
local v173 = {
	["Name"] = "Panel",
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["BackgroundColor3"] = nil,
	["BackgroundTransparency"] = 0.03,
	["Visible"] = false,
	["Active"] = true,
	["AnchorPoint"] = Vector2.new(0, 0.5),
	["Position"] = UDim2.new(0, 202, 0.5, 0),
	["Size"] = UDim2.fromOffset(340, 610),
	["BackgroundColor3"] = v_u_21.panel
}
local v_u_174 = v_u_2.new("Frame")
for v175, v176 in v173 do
	v_u_174[v175] = v176
end
v_u_174.Parent = v43
local v177 = {
	["CornerRadius"] = UDim.new(0, 16)
}
local v178 = v_u_2.new("UICorner")
for v179, v180 in v177 do
	v178[v179] = v180
end
v178.Parent = v_u_174
local v_u_181 = v_u_2.new("UIScale")
for v182, v183 in {} do
	v_u_181[v182] = v183
end
v_u_181.Parent = v_u_174
local v184, _, v_u_185 = v_u_14.header(v_u_174, "brush", "gold", "\224\184\170\224\184\149\224\184\180\224\185\138\224\184\129\224\185\128\224\184\129\224\184\173\224\184\163\224\185\140", "")
v184.Position = UDim2.fromOffset(14, 10)
v184.Size = UDim2.new(1, -28, 0, 46)
local v186 = {
	["BackgroundColor3"] = nil,
	["BorderSizePixel"] = 0,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["BackgroundColor3"] = v_u_14.GRAD.gold[1],
	["AnchorPoint"] = Vector2.new(0.5, 0),
	["Position"] = UDim2.new(0.5, 0, 0, 0),
	["Size"] = UDim2.new(0.5, 0, 0, 3)
}
local v187 = v_u_2.new("Frame")
for v188, v189 in v186 do
	v187[v188] = v189
end
v187.Parent = v_u_174
local v190 = {
	["Transparency"] = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(0.5, 0), NumberSequenceKeypoint.new(1, 1) })
}
local v191 = v_u_2.new("UIGradient")
for v192, v193 in v190 do
	v191[v192] = v193
end
v191.Parent = v187
local v194 = {
	["Position"] = nil,
	["Size"] = nil,
	["BackgroundColor3"] = nil,
	["Text"] = "0 / 20",
	["TextColor3"] = nil,
	["Font"] = nil,
	["TextSize"] = 13,
	["Position"] = UDim2.fromOffset(250, 18),
	["Size"] = UDim2.fromOffset(72, 26),
	["BackgroundColor3"] = v_u_21.card,
	["TextColor3"] = v_u_21.text,
	["Font"] = v_u_22
}
local v_u_195 = v_u_2.new("TextLabel")
for v196, v197 in v194 do
	v_u_195[v196] = v197
end
v_u_195.Parent = v_u_174
local v198 = {
	["CornerRadius"] = UDim.new(0, 13)
}
local v199 = v_u_2.new("UICorner")
for v200, v201 in v198 do
	v199[v200] = v201
end
v199.Parent = v_u_195
local v202 = {
	["Position"] = nil,
	["Size"] = nil,
	["BackgroundTransparency"] = 1,
	["BorderSizePixel"] = 0,
	["ScrollBarThickness"] = 0,
	["ScrollingDirection"] = nil,
	["AutomaticCanvasSize"] = nil,
	["CanvasSize"] = nil,
	["Position"] = UDim2.fromOffset(14, 66),
	["Size"] = UDim2.fromOffset(312, 30),
	["ScrollingDirection"] = Enum.ScrollingDirection.X,
	["AutomaticCanvasSize"] = Enum.AutomaticSize.X,
	["CanvasSize"] = UDim2.new()
}
local v_u_203 = v_u_2.new("ScrollingFrame")
for v204, v205 in v202 do
	v_u_203[v204] = v205
end
v_u_203.Parent = v_u_174
local v206 = {
	["FillDirection"] = Enum.FillDirection.Horizontal,
	["VerticalAlignment"] = Enum.VerticalAlignment.Center,
	["Padding"] = UDim.new(0, 6),
	["SortOrder"] = Enum.SortOrder.LayoutOrder
}
local v207 = v_u_2.new("UIListLayout")
for v208, v209 in v206 do
	v207[v208] = v209
end
v207.Parent = v_u_203
local v210 = {
	["PaddingLeft"] = UDim.new(0, 4),
	["PaddingRight"] = UDim.new(0, 4)
}
local v211 = v_u_2.new("UIPadding")
for v212, v213 in v210 do
	v211[v212] = v213
end
v211.Parent = v_u_203
local v214 = {
	["Name"] = "Grid",
	["Position"] = nil,
	["Size"] = nil,
	["BackgroundColor3"] = nil,
	["BorderSizePixel"] = 0,
	["ScrollBarThickness"] = 4,
	["ScrollBarImageColor3"] = nil,
	["AutomaticCanvasSize"] = nil,
	["CanvasSize"] = nil,
	["Position"] = UDim2.fromOffset(12, 104),
	["Size"] = UDim2.fromOffset(316, 236),
	["BackgroundColor3"] = v_u_21.well,
	["ScrollBarImageColor3"] = v_u_21.line,
	["AutomaticCanvasSize"] = Enum.AutomaticSize.Y,
	["CanvasSize"] = UDim2.new()
}
local v_u_215 = v_u_2.new("ScrollingFrame")
for v216, v217 in v214 do
	v_u_215[v216] = v217
end
v_u_215.Parent = v_u_174
local v218 = {
	["CornerRadius"] = UDim.new(0, 10)
}
local v219 = v_u_2.new("UICorner")
for v220, v221 in v218 do
	v219[v220] = v221
end
v219.Parent = v_u_215
local v222 = {
	["PaddingLeft"] = UDim.new(0, 8),
	["PaddingTop"] = UDim.new(0, 8),
	["PaddingBottom"] = UDim.new(0, 8)
}
local v223 = v_u_2.new("UIPadding")
for v224, v225 in v222 do
	v223[v224] = v225
end
v223.Parent = v_u_215
local v226 = {
	["CellSize"] = UDim2.fromOffset(94, 110),
	["CellPadding"] = UDim2.fromOffset(6, 6),
	["SortOrder"] = Enum.SortOrder.LayoutOrder
}
local v227 = v_u_2.new("UIGridLayout")
for v228, v229 in v226 do
	v227[v228] = v229
end
v227.Parent = v_u_215
local v_u_230 = v_u_56(v_u_174, "\224\184\154\224\184\153\224\184\163\224\184\150\224\184\132\224\184\177\224\184\153\224\184\153\224\184\181\224\185\137", 13, v_u_21.text, v_u_22, {
	["Position"] = UDim2.fromOffset(18, 350),
	["Size"] = UDim2.fromOffset(150, 18)
})
local v231 = {
	["Position"] = nil,
	["Size"] = nil,
	["BackgroundTransparency"] = 1,
	["Text"] = "\224\184\165\224\184\154\224\184\151\224\184\177\224\185\137\224\184\135\224\184\171\224\184\161\224\184\148",
	["TextColor3"] = nil,
	["Font"] = nil,
	["TextSize"] = 12,
	["TextXAlignment"] = nil,
	["Position"] = UDim2.fromOffset(222, 348),
	["Size"] = UDim2.fromOffset(100, 22),
	["TextColor3"] = v_u_21.dim,
	["Font"] = v_u_23,
	["TextXAlignment"] = Enum.TextXAlignment.Right
}
local v_u_232 = v_u_2.new("TextButton")
for v233, v234 in v231 do
	v_u_232[v233] = v234
end
v_u_232.Parent = v_u_174
local v235 = {
	["Position"] = nil,
	["Size"] = nil,
	["BackgroundColor3"] = nil,
	["BorderSizePixel"] = 0,
	["ScrollBarThickness"] = 4,
	["ScrollBarImageColor3"] = nil,
	["AutomaticCanvasSize"] = nil,
	["CanvasSize"] = nil,
	["Position"] = UDim2.fromOffset(12, 374),
	["Size"] = UDim2.fromOffset(316, 128),
	["BackgroundColor3"] = v_u_21.well,
	["ScrollBarImageColor3"] = v_u_21.line,
	["AutomaticCanvasSize"] = Enum.AutomaticSize.Y,
	["CanvasSize"] = UDim2.new()
}
local v_u_236 = v_u_2.new("ScrollingFrame")
for v237, v238 in v235 do
	v_u_236[v237] = v238
end
v_u_236.Parent = v_u_174
local v239 = {
	["CornerRadius"] = UDim.new(0, 10)
}
local v240 = v_u_2.new("UICorner")
for v241, v242 in v239 do
	v240[v241] = v242
end
v240.Parent = v_u_236
local v243 = {
	["PaddingLeft"] = UDim.new(0, 6),
	["PaddingRight"] = UDim.new(0, 6),
	["PaddingTop"] = UDim.new(0, 6),
	["PaddingBottom"] = UDim.new(0, 6)
}
local v244 = v_u_2.new("UIPadding")
for v245, v246 in v243 do
	v244[v245] = v246
end
v244.Parent = v_u_236
local v247 = {
	["Padding"] = UDim.new(0, 4),
	["SortOrder"] = Enum.SortOrder.LayoutOrder
}
local v248 = v_u_2.new("UIListLayout")
for v249, v250 in v247 do
	v248[v249] = v250
end
v248.Parent = v_u_236
local v_u_251 = v_u_56(v_u_236, "\224\184\162\224\184\177\224\184\135\224\185\132\224\184\161\224\185\136\224\184\161\224\184\181\224\184\170\224\184\149\224\184\180\224\185\138\224\184\129\224\185\128\224\184\129\224\184\173\224\184\163\224\185\140 \194\183 \224\185\128\224\184\165\224\184\183\224\184\173\224\184\129\224\184\165\224\184\178\224\184\162\224\184\148\224\185\137\224\184\178\224\184\153\224\184\154\224\184\153 \224\185\129\224\184\165\224\185\137\224\184\167\224\184\132\224\184\165\224\184\180\224\184\129\224\184\154\224\184\153\224\184\163\224\184\150", 12, v_u_21.dim, v_u_23, {
	["Size"] = nil,
	["TextWrapped"] = true,
	["TextXAlignment"] = nil,
	["LayoutOrder"] = 0,
	["Size"] = UDim2.new(1, 0, 0, 40),
	["TextXAlignment"] = Enum.TextXAlignment.Center
})
local v252 = {
	["Position"] = nil,
	["Size"] = nil,
	["BackgroundColor3"] = nil,
	["BorderSizePixel"] = 0,
	["Position"] = UDim2.fromOffset(16, 514),
	["Size"] = UDim2.new(1, -32, 0, 1),
	["BackgroundColor3"] = v_u_21.line
}
local v253 = v_u_2.new("Frame")
for v254, v255 in v252 do
	v253[v254] = v255
end
v253.Parent = v_u_174
v_u_56(v_u_174, "\224\184\149\224\185\137\224\184\173\224\184\135\224\184\136\224\185\136\224\184\178\224\184\162", 12, v_u_21.dim, v_u_23, {
	["Position"] = UDim2.fromOffset(18, 522),
	["Size"] = UDim2.fromOffset(100, 14)
})
local v_u_256 = v_u_56(v_u_174, "\226\128\148", 17, v_u_21.text, v_u_22, {
	["Position"] = UDim2.fromOffset(18, 537),
	["Size"] = UDim2.fromOffset(160, 20)
})
local v_u_257 = v_u_56(v_u_174, "", 12, v_u_21.dim, v_u_23, {
	["Position"] = UDim2.fromOffset(170, 522),
	["Size"] = UDim2.fromOffset(152, 14),
	["TextXAlignment"] = Enum.TextXAlignment.Right
})
local v258 = v_u_72(v_u_174, "\224\184\162\224\184\129\224\185\128\224\184\165\224\184\180\224\184\129", {
	["Position"] = UDim2.fromOffset(16, 562),
	["Size"] = UDim2.fromOffset(100, 36)
}, v_u_21.btn)
local v_u_259 = v_u_72(v_u_174, "\224\184\154\224\184\177\224\184\153\224\184\151\224\184\182\224\184\129", {
	["Position"] = UDim2.fromOffset(124, 562),
	["Size"] = UDim2.fromOffset(200, 36)
}, v_u_21.good, v_u_14.DARK_TEXT)
local v260 = {
	["Name"] = "Inspector",
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["BackgroundColor3"] = nil,
	["BackgroundTransparency"] = 0.03,
	["Visible"] = false,
	["Active"] = true,
	["AnchorPoint"] = Vector2.new(0.5, 0),
	["Position"] = UDim2.fromOffset(800, 12),
	["Size"] = UDim2.fromOffset(600, 118),
	["BackgroundColor3"] = v_u_21.panel
}
local v_u_261 = v_u_2.new("Frame")
for v262, v263 in v260 do
	v_u_261[v262] = v263
end
v_u_261.Parent = v43
local v264 = {
	["CornerRadius"] = UDim.new(0, 16)
}
local v265 = v_u_2.new("UICorner")
for v266, v267 in v264 do
	v265[v266] = v267
end
v265.Parent = v_u_261
local v_u_268 = v_u_2.new("UIScale")
for v269, v270 in {} do
	v_u_268[v269] = v270
end
v_u_268.Parent = v_u_261
local v271 = {
	["Position"] = nil,
	["Size"] = nil,
	["BackgroundColor3"] = nil,
	["BorderSizePixel"] = 0,
	["Position"] = UDim2.fromOffset(12, 12),
	["Size"] = UDim2.fromOffset(52, 52),
	["BackgroundColor3"] = v_u_21.thumb
}
local v272 = v_u_2.new("Frame")
for v273, v274 in v271 do
	v272[v273] = v274
end
v272.Parent = v_u_261
local v275 = {
	["CornerRadius"] = UDim.new(0, 10)
}
local v276 = v_u_2.new("UICorner")
for v277, v278 in v275 do
	v276[v277] = v278
end
v276.Parent = v272
local v279 = {
	["BackgroundTransparency"] = 1,
	["Position"] = nil,
	["Size"] = nil,
	["ScaleType"] = nil,
	["Position"] = UDim2.fromOffset(5, 5),
	["Size"] = UDim2.new(1, -10, 1, -10),
	["ScaleType"] = Enum.ScaleType.Fit
}
local v_u_280 = v_u_2.new("ImageLabel")
for v281, v282 in v279 do
	v_u_280[v281] = v282
end
v_u_280.Parent = v272
local v_u_283 = v_u_56(v_u_261, "", 14, v_u_21.text, v_u_22, {
	["Position"] = UDim2.fromOffset(76, 14),
	["Size"] = UDim2.fromOffset(150, 18),
	["TextTruncate"] = Enum.TextTruncate.AtEnd
})
local v_u_284 = v_u_56(v_u_261, "", 12, v_u_21.dim, v_u_23, {
	["Position"] = nil,
	["Size"] = nil,
	["TextWrapped"] = true,
	["TextYAlignment"] = nil,
	["Position"] = UDim2.fromOffset(76, 34),
	["Size"] = UDim2.fromOffset(150, 28),
	["TextYAlignment"] = Enum.TextYAlignment.Top
})
v_u_56(v_u_261, "\224\184\130\224\184\153\224\184\178\224\184\148", 12, v_u_21.dim, v_u_23, {
	["Position"] = UDim2.fromOffset(238, 14),
	["Size"] = UDim2.fromOffset(80, 16)
})
local v_u_285 = v_u_56(v_u_261, "", 12, v_u_21.text, v_u_22, {
	["Position"] = UDim2.fromOffset(338, 14),
	["Size"] = UDim2.fromOffset(60, 16),
	["TextXAlignment"] = Enum.TextXAlignment.Right
})
v_u_56(v_u_261, "\224\184\171\224\184\161\224\184\184\224\184\153", 12, v_u_21.dim, v_u_23, {
	["Position"] = UDim2.fromOffset(418, 14),
	["Size"] = UDim2.fromOffset(80, 16)
})
local v_u_286 = v_u_56(v_u_261, "", 12, v_u_21.text, v_u_22, {
	["Position"] = UDim2.fromOffset(528, 14),
	["Size"] = UDim2.fromOffset(60, 16),
	["TextXAlignment"] = Enum.TextXAlignment.Right
})
local v287 = {
	["BackgroundTransparency"] = 1,
	["Position"] = nil,
	["Size"] = nil,
	["Position"] = UDim2.fromOffset(76, 78),
	["Size"] = UDim2.fromOffset(282, 26)
}
local v_u_288 = v_u_2.new("Frame")
for v289, v290 in v287 do
	v_u_288[v289] = v290
end
v_u_288.Parent = v_u_261
local v_u_291 = v_u_56(v_u_261, "\224\184\165\224\184\178\224\184\162\224\184\153\224\184\181\224\185\137\224\184\162\224\185\137\224\184\173\224\184\161\224\184\170\224\184\181\224\185\132\224\184\161\224\185\136\224\185\132\224\184\148\224\185\137", 12, v_u_21.dim, v_u_23, {
	["Position"] = UDim2.fromOffset(76, 78),
	["Size"] = UDim2.fromOffset(200, 26)
})
local v_u_292 = {}
for v293, v294 in v_u_11.COLORS do
	local v295 = {
		["Text"] = "",
		["BackgroundColor3"] = nil,
		["AutoButtonColor"] = true,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = Color3.fromHex(v294),
		["Position"] = UDim2.fromOffset((v293 - 1) * 28, 2),
		["Size"] = UDim2.fromOffset(22, 22)
	}
	local v296 = v_u_2.new("TextButton")
	for v297, v298 in v295 do
		v296[v297] = v298
	end
	v296.Parent = v_u_288
	local v299 = {
		["CornerRadius"] = UDim.new(0, 11)
	}
	local v300 = v_u_2.new("UICorner")
	for v301, v302 in v299 do
		v300[v301] = v302
	end
	v300.Parent = v296
	local v303 = {
		["Color"] = nil,
		["Thickness"] = 1,
		["ApplyStrokeMode"] = nil,
		["Color"] = Color3.fromRGB(80, 82, 96),
		["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border
	}
	local v304 = v_u_2.new("UIStroke")
	for v305, v306 in v303 do
		v304[v305] = v306
	end
	v304.Parent = v296
	v304.Name = "Ring"
	v_u_292[v294] = v296
end
local v_u_307 = v_u_72(v_u_261, "\224\184\167\224\184\178\224\184\135\224\184\173\224\184\181\224\184\129\224\184\157\224\184\177\224\185\136\224\184\135", {
	["Position"] = nil,
	["Size"] = nil,
	["TextSize"] = 13,
	["Position"] = UDim2.fromOffset(366, 76),
	["Size"] = UDim2.fromOffset(92, 30)
})
local v_u_308 = v_u_72(v_u_261, "\224\184\162\224\185\137\224\184\178\224\184\162", {
	["Position"] = nil,
	["Size"] = nil,
	["TextSize"] = 13,
	["Position"] = UDim2.fromOffset(464, 76),
	["Size"] = UDim2.fromOffset(60, 30)
})
local v_u_309 = v_u_72(v_u_261, "\224\184\165\224\184\154", {
	["Position"] = nil,
	["Size"] = nil,
	["TextSize"] = 13,
	["Position"] = UDim2.fromOffset(530, 76),
	["Size"] = UDim2.fromOffset(58, 30)
}, v_u_21.danger)
local v_u_310 = v_u_72(v_u_261, "\224\185\128\224\184\165\224\184\180\224\184\129\224\184\167\224\184\178\224\184\135", {
	["Position"] = nil,
	["Size"] = nil,
	["TextSize"] = 13,
	["Position"] = UDim2.fromOffset(500, 76),
	["Size"] = UDim2.fromOffset(88, 30)
})
local v311 = {
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["AutomaticSize"] = nil,
	["BackgroundColor3"] = nil,
	["BackgroundTransparency"] = 0.1,
	["Text"] = "",
	["TextColor3"] = nil,
	["Font"] = nil,
	["TextSize"] = 14,
	["Visible"] = false,
	["AnchorPoint"] = Vector2.new(0.5, 0),
	["Position"] = UDim2.fromOffset(800, 12),
	["Size"] = UDim2.fromOffset(0, 30),
	["AutomaticSize"] = Enum.AutomaticSize.X,
	["BackgroundColor3"] = v_u_21.panel,
	["TextColor3"] = v_u_21.text,
	["Font"] = v_u_23
}
local v_u_312 = v_u_2.new("TextLabel")
for v313, v314 in v311 do
	v_u_312[v313] = v314
end
v_u_312.Parent = v43
local v315 = {
	["CornerRadius"] = UDim.new(0, 15)
}
local v316 = v_u_2.new("UICorner")
for v317, v318 in v315 do
	v316[v317] = v318
end
v316.Parent = v_u_312
local v319 = {
	["Color"] = nil,
	["Thickness"] = 1,
	["ApplyStrokeMode"] = nil,
	["Color"] = Color3.new(1, 1, 1),
	["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border
}
local v320 = v_u_2.new("UIStroke")
for v321, v322 in v319 do
	v320[v321] = v322
end
v320.Parent = v_u_312
v320.Transparency = 0.84
local v323 = {
	["PaddingLeft"] = UDim.new(0, 14),
	["PaddingRight"] = UDim.new(0, 14)
}
local v324 = v_u_2.new("UIPadding")
for v325, v326 in v323 do
	v324[v325] = v326
end
v324.Parent = v_u_312
local v327 = {
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["BackgroundColor3"] = nil,
	["BackgroundTransparency"] = 0.15,
	["Visible"] = false,
	["Active"] = true,
	["AnchorPoint"] = Vector2.new(1, 0.5),
	["Position"] = UDim2.new(1, -14, 0.5, -30),
	["Size"] = UDim2.fromOffset(104, 152),
	["BackgroundColor3"] = v_u_21.panel
}
local v_u_328 = v_u_2.new("Frame")
for v329, v330 in v327 do
	v_u_328[v329] = v330
end
v_u_328.Parent = v43
local v331 = {
	["CornerRadius"] = UDim.new(0, 12)
}
local v332 = v_u_2.new("UICorner")
for v333, v334 in v331 do
	v332[v333] = v334
end
v332.Parent = v_u_328
v_u_56(v_u_328, "\224\184\129\224\184\165\224\185\137\224\184\173\224\184\135", 11, v_u_21.dim, v_u_23, {
	["Position"] = UDim2.fromOffset(0, 4),
	["Size"] = UDim2.new(1, 0, 0, 14),
	["TextXAlignment"] = Enum.TextXAlignment.Center
})
local v335 = {}
for _, v336 in {
	{ "left", 6, 22 },
	{ "right", 54, 22 },
	{ "up", 6, 66 },
	{ "down", 54, 66 },
	{ "plus", 6, 110 },
	{ "minus", 54, 110 }
} do
	local v337 = v336[1]
	local v338 = v336[1]
	local v339 = v_u_72(v_u_328, "", {
		["Position"] = UDim2.fromOffset(v336[2], v336[3]),
		["Size"] = UDim2.fromOffset(44, 38)
	}, v_u_21.btn)
	v_u_80(v339, v338, v_u_21.text)
	v335[v337] = v339
end
local v340 = workspace
local v_u_341 = v_u_2.new("Folder")
local v_u_342 = false
local v_u_343 = nil
local v_u_344 = nil
local v_u_345 = "\224\184\151\224\184\177\224\185\137\224\184\135\224\184\171\224\184\161\224\184\148"
local v_u_346 = false
local v_u_347 = "select"
local v_u_348 = nil
local v_u_349 = nil
local v_u_350 = nil
local v_u_351 = nil
local v_u_352 = nil
local v_u_353 = nil
local v_u_354 = nil
for v355, v356 in {
	["Name"] = "StickerEditorGhost"
} do
	v_u_341[v355] = v356
end
v_u_341.Parent = v340
local v_u_357 = nil
local v_u_358 = nil
local v_u_359 = {}
local v_u_360 = v_u_7.TouchEnabled
if v_u_360 then
	v_u_360 = not v_u_7.MouseEnabled
end
local v_u_361 = nil
local v_u_362 = nil
local v_u_363 = nil
local v_u_364 = nil
local function v_u_367() -- name: drivenModel
	-- upvalues: (copy) v_u_17, (copy) v_u_8
	local v365 = v_u_17.Character
	if v365 then
		v365 = v_u_17.Character:FindFirstChildOfClass("Humanoid")
	end
	if v365 then
		v365 = v365.SeatPart
	end
	if not v365 or v365.Name ~= "VehicleSeat" and v365.Name ~= "DriverSeat" then
		return nil
	end
	local v366 = v365.Parent
	while v366 and v366 ~= workspace do
		if v366:IsA("Model") and (v_u_8:HasTag(v366, "GTACar") or v_u_8:HasTag(v366, "PCX160")) then
			return v366
		end
		v366 = v366.Parent
	end
	return nil
end
local function v_u_373(p368, ...) -- name: call
	-- upvalues: (copy) v_u_3
	local v369 = v_u_3.invoke
	local v370, v371, v372 = pcall(v369, p368, ...)
	if v370 then
		return v371, v372
	else
		return false, "\224\185\128\224\184\138\224\184\183\224\185\136\224\184\173\224\184\161\224\184\149\224\185\136\224\184\173\224\185\128\224\184\139\224\184\180\224\184\163\224\185\140\224\184\159\224\185\128\224\184\167\224\184\173\224\184\163\224\185\140\224\185\132\224\184\161\224\185\136\224\185\132\224\184\148\224\185\137"
	end
end
local function v_u_375(p374) -- name: wire
	return {
		["s"] = p374.s,
		["p"] = p374.p,
		["o"] = { p374.o.X, p374.o.Y, p374.o.Z },
		["n"] = { p374.n.X, p374.n.Y, p374.n.Z },
		["u"] = { p374.u.X, p374.u.Y, p374.u.Z },
		["w"] = p374.w,
		["c"] = p374.c,
		["t"] = p374.t,
		["d"] = p374.d,
		["a"] = p374.a,
		["b"] = p374.b
	}
end
local function v_u_377(p376) -- name: copy
	return {
		["s"] = p376.s,
		["p"] = p376.p,
		["o"] = p376.o,
		["n"] = p376.n,
		["u"] = p376.u,
		["w"] = p376.w,
		["c"] = p376.c,
		["t"] = p376.t,
		["d"] = p376.d,
		["a"] = p376.a,
		["b"] = p376.b
	}
end
local function v_u_383(p378) -- name: refUp
	-- upvalues: (ref) v_u_343
	local v379 = v_u_343
	if v379 then
		v379 = v_u_343.seat
	end
	local v380 = not v379 and Vector3.new(0, 1, 0) or v379.CFrame.UpVector
	local v381 = v380 - p378 * v380:Dot(p378)
	if v381.Magnitude < 0.25 then
		local v382 = not v379 and Vector3.new(0, 0, 1) or v379.CFrame.LookVector
		v381 = v382 - p378 * v382:Dot(p378)
	end
	return v381.Magnitude <= 0.001 and Vector3.new(0, 1, 0) or v381.Unit
end
local function v_u_393(p384) -- name: angleOf
	-- upvalues: (ref) v_u_343, (copy) v_u_11, (copy) v_u_383
	local v385 = v_u_343.panels[p384.p]
	if not v385 then
		return 0
	end
	local v386 = v_u_11.frame(p384, v385)
	local v387 = v386.LookVector
	local v388 = v386.UpVector
	local v389 = v_u_383(v387)
	local v390 = v389:Cross(v388):Dot(v387)
	local v391 = v389:Dot(v388)
	local v392 = math.atan2(v390, v391)
	return -math.deg(v392)
end
local function v_u_399(p394, p395) -- name: setAngle
	-- upvalues: (ref) v_u_343, (copy) v_u_383
	local v396 = v_u_343.panels[p394.p]
	if v396 then
		local v397 = v396.CFrame:VectorToWorldSpace(p394.n).Unit
		local v398 = CFrame.fromAxisAngle(v397, -math.rad(p395)):VectorToWorldSpace((v_u_383(v397)))
		p394.u = v396.CFrame:VectorToObjectSpace(v398).Unit
	end
end
local function v_u_405(p400, p401, p402) -- name: castAt
	-- upvalues: (ref) v_u_343
	local v403 = workspace.CurrentCamera:ViewportPointToRay(p400, p401)
	local v404 = RaycastParams.new()
	v404.FilterType = Enum.RaycastFilterType.Include
	v404.FilterDescendantsInstances = p402 or v_u_343.blockers
	return workspace:Raycast(v403.Origin, v403.Direction * 300, v404)
end
local function v_u_415(p406, p407, p408, p409, p410, p411, p412, p413) -- name: entryAt
	-- upvalues: (copy) v_u_11, (copy) v_u_383, (ref) v_u_343, (copy) v_u_399
	local v414 = v_u_11.fromHit(p407, p406.Instance, p406.Position, p406.Normal, v_u_383(p406.Normal), p408, p409)
	v414.d = p411
	v414.a = p412
	v414.b = p413
	v_u_11.settle(v414, v_u_343.panels, v_u_343.include)
	v_u_399(v414, p410)
	return v414
end
local function v_u_423(p416, p417) -- name: validate
	-- upvalues: (copy) v_u_11, (ref) v_u_343
	local v418, v419 = v_u_11.check(p416, v_u_343.model, v_u_343.panels)
	if v418 then
		local v420 = not v_u_343 and {} or v_u_11.read(v_u_343.model)
		local v421 = #v420 + (p417 and 0 or 1)
		local v422 = v_u_11.tiles(v420) - (not (p417 and v420[p417]) and 0 or v420[p417].t ^ 2) + p416.t ^ 2
		if v_u_11.maxFor(v_u_343.model) < v421 then
			return false, ("\224\185\129\224\184\155\224\184\176\224\185\132\224\184\148\224\185\137\224\184\170\224\184\185\224\184\135\224\184\170\224\184\184\224\184\148 %d \224\185\129\224\184\156\224\185\136\224\184\153\224\184\149\224\185\136\224\184\173\224\184\132\224\184\177\224\184\153"):format(v_u_11.maxFor(v_u_343.model))
		elseif v_u_11.MAX_TILES < v422 then
			return false, "\224\184\170\224\184\149\224\184\180\224\185\138\224\184\129\224\185\128\224\184\129\224\184\173\224\184\163\224\185\140\224\184\154\224\184\153\224\184\132\224\184\177\224\184\153\224\184\153\224\184\181\224\185\137\224\184\165\224\184\176\224\185\128\224\184\173\224\184\181\224\184\162\224\184\148\224\185\128\224\184\129\224\184\180\224\184\153\224\185\132\224\184\155\224\185\129\224\184\165\224\185\137\224\184\167"
		else
			return true
		end
	else
		return false, v419
	end
end
local v_u_424 = nil
local function v_u_429(p425) -- name: hideReal
	-- upvalues: (ref) v_u_343, (ref) v_u_424
	local v426 = v_u_343
	if v426 then
		v426 = v_u_343.model:FindFirstChild("StickerVisuals")
	end
	if v_u_424 and (v426 and v426:FindFirstChild("S" .. v_u_424)) then
		for _, v427 in v426["S" .. v_u_424]:GetDescendants() do
			if not v427:IsA("Texture") then
				continue
			end
			v427.Transparency = 0
		end
	end
	v_u_424 = p425
	if p425 and (v426 and v426:FindFirstChild("S" .. p425)) then
		for _, v428 in v426["S" .. p425]:GetDescendants() do
			if not v428:IsA("Texture") then
				continue
			end
			v428.Transparency = 1
		end
	end
end
local function v_u_451(p430, p431) -- name: outline
	-- upvalues: (ref) v_u_343, (copy) v_u_11, (copy) v_u_341, (copy) v_u_2
	local v432 = v_u_343
	if v432 then
		v432 = v_u_343.panels[p430.p]
	end
	if not v432 then
		return nil
	end
	local v433, v434, v435 = v_u_11.frame(p430, v432)
	if p430.d and p430.d ~= 0 then
		v433 = v433 + v433.LookVector * p430.d
	end
	local v436 = v_u_11.tiltFrame(v433, v434, v435, p430)
	local v437 = math.max(v434, v435) * 0.04
	local v438 = math.clamp(v437, 0.03, 0.12)
	local v439 = {
		["Name"] = "StickerOutline",
		["Anchored"] = true,
		["CanCollide"] = false,
		["CanQuery"] = false,
		["CanTouch"] = false,
		["CastShadow"] = false,
		["Transparency"] = 1,
		["Size"] = nil,
		["CFrame"] = nil
	}
	local v440 = v434 + v438 * 2
	local v441 = v435 + v438 * 2
	v439.Size = Vector3.new(v440, v441, 0.01)
	v439.CFrame = v436 + v436.LookVector * 0.03
	local v442 = v_u_341
	local v443 = v_u_2.new("Part")
	for v444, v445 in v439 do
		v443[v444] = v445
	end
	v443.Parent = v442
	local v446 = {
		["Adornee"] = nil,
		["Color3"] = nil,
		["SurfaceTransparency"] = 1,
		["LineThickness"] = nil,
		["Adornee"] = v443,
		["Color3"] = p431
	}
	local v447 = math.max(v434, v435) * 0.012
	v446.LineThickness = math.clamp(v447, 0.01, 0.035)
	local v448 = v_u_2.new("SelectionBox")
	for v449, v450 in v446 do
		v448[v449] = v450
	end
	v448.Parent = v443
	return v443
end
local function v_u_460(p452, p453, p454) -- name: showGhost
	-- upvalues: (copy) v_u_341, (copy) v_u_359, (ref) v_u_357, (copy) v_u_11, (ref) v_u_343, (copy) v_u_423, (copy) v_u_451, (copy) v_u_21
	v_u_341:ClearAllChildren()
	table.clear(v_u_359)
	v_u_357 = p452
	local v455 = v_u_11.buildOne(v_u_343.model, p452, p453, v_u_341, {
		["anchored"] = true,
		["ghost"] = true,
		["panels"] = nil,
		["include"] = nil,
		["panels"] = v_u_343.panels,
		["include"] = v_u_343.include
	})
	local v456 = v_u_423(p452, p454)
	if v455 and not v456 then
		for _, v457 in v455:GetDescendants() do
			if not v457:IsA("Texture") then
				continue
			end
			v457.Color3 = Color3.fromRGB(255, 70, 70)
		end
	end
	local v458 = v_u_451
	local v459
	if v456 then
		v459 = v_u_21.accent
	else
		v459 = Color3.fromRGB(255, 80, 80)
	end
	v458(p452, v459)
end
local v_u_461 = {}
local v_u_462 = {}
local v_u_463 = nil
local v_u_464 = nil
local v_u_465 = nil
local v_u_466 = v_u_56(v_u_174, "", 12, v_u_21.dim, v_u_23, {
	["Position"] = nil,
	["Size"] = nil,
	["TextWrapped"] = true,
	["TextXAlignment"] = nil,
	["ZIndex"] = 2,
	["Visible"] = false,
	["Position"] = UDim2.fromOffset(12, 104),
	["Size"] = UDim2.fromOffset(316, 236),
	["TextXAlignment"] = Enum.TextXAlignment.Center
})
local function v_u_518(p_u_467, p468) -- name: makeCard
	-- upvalues: (copy) v_u_21, (copy) v_u_215, (copy) v_u_2, (copy) v_u_56, (copy) v_u_23, (copy) v_u_22, (ref) v_u_465
	local v469 = {
		["Name"] = nil,
		["LayoutOrder"] = nil,
		["BackgroundColor3"] = nil,
		["AutoButtonColor"] = false,
		["Image"] = "",
		["BorderSizePixel"] = 0,
		["Name"] = p_u_467.id,
		["LayoutOrder"] = p468,
		["BackgroundColor3"] = v_u_21.card
	}
	local v470 = v_u_215
	local v_u_471 = v_u_2.new("ImageButton")
	for v472, v473 in v469 do
		v_u_471[v472] = v473
	end
	v_u_471.Parent = v470
	local v474 = {
		["CornerRadius"] = UDim.new(0, 10)
	}
	local v475 = v_u_2.new("UICorner")
	for v476, v477 in v474 do
		v475[v476] = v477
	end
	v475.Parent = v_u_471
	local v478 = {
		["Color"] = nil,
		["Thickness"] = 2,
		["ApplyStrokeMode"] = nil,
		["Color"] = v_u_21.card,
		["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border
	}
	local v479 = v_u_2.new("UIStroke")
	for v480, v481 in v478 do
		v479[v480] = v481
	end
	v479.Parent = v_u_471
	local v482 = {
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Position"] = UDim2.fromOffset(6, 6),
		["Size"] = UDim2.new(1, -12, 0, 62),
		["BackgroundColor3"] = v_u_21.thumb
	}
	local v483 = v_u_2.new("Frame")
	for v484, v485 in v482 do
		v483[v484] = v485
	end
	v483.Parent = v_u_471
	local v486 = {
		["CornerRadius"] = UDim.new(0, 8)
	}
	local v487 = v_u_2.new("UICorner")
	for v488, v489 in v486 do
		v487[v488] = v489
	end
	v487.Parent = v483
	local v490 = {
		["BackgroundTransparency"] = 1,
		["Image"] = nil,
		["ScaleType"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Image"] = p_u_467.image,
		["ScaleType"] = Enum.ScaleType.Fit,
		["Position"] = UDim2.fromOffset(6, 6),
		["Size"] = UDim2.new(1, -12, 1, -12)
	}
	local v491 = v_u_2.new("ImageLabel")
	for v492, v493 in v490 do
		v491[v492] = v493
	end
	v491.Parent = v483
	if p_u_467.tint then
		local v494 = {
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Position"] = UDim2.new(1, -16, 0, 6),
			["Size"] = UDim2.fromOffset(10, 10),
			["BackgroundColor3"] = Color3.new(1, 1, 1)
		}
		local v495 = v_u_2.new("Frame")
		for v496, v497 in v494 do
			v495[v496] = v497
		end
		v495.Parent = v483
		local v498 = {
			["CornerRadius"] = UDim.new(0, 5)
		}
		local v499 = v_u_2.new("UICorner")
		for v500, v501 in v498 do
			v499[v500] = v501
		end
		v499.Parent = v495
		local v502 = {
			["Color"] = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(255, 80, 80)), ColorSequenceKeypoint.new(0.5, Color3.fromRGB(80, 220, 120)), ColorSequenceKeypoint.new(1, Color3.fromRGB(80, 140, 255)) })
		}
		local v503 = v_u_2.new("UIGradient")
		for v504, v505 in v502 do
			v503[v504] = v505
		end
		v503.Parent = v495
	end
	v_u_56(v_u_471, p_u_467.name, 11, v_u_21.text, v_u_23, {
		["Position"] = UDim2.fromOffset(8, 70),
		["Size"] = UDim2.new(1, -16, 0, 16),
		["TextTruncate"] = Enum.TextTruncate.AtEnd
	})
	local v506 = {
		["Name"] = "Chip",
		["Position"] = nil,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["BackgroundColor3"] = nil,
		["Text"] = "",
		["TextSize"] = 10,
		["Font"] = nil,
		["TextColor3"] = nil,
		["Position"] = UDim2.fromOffset(8, 88),
		["Size"] = UDim2.fromOffset(0, 16),
		["AutomaticSize"] = Enum.AutomaticSize.X,
		["BackgroundColor3"] = v_u_21.well,
		["Font"] = v_u_22,
		["TextColor3"] = v_u_21.warn
	}
	local v507 = v_u_2.new("TextLabel")
	for v508, v509 in v506 do
		v507[v508] = v509
	end
	v507.Parent = v_u_471
	local v510 = {
		["CornerRadius"] = UDim.new(0, 8)
	}
	local v511 = v_u_2.new("UICorner")
	for v512, v513 in v510 do
		v511[v512] = v513
	end
	v511.Parent = v507
	local v514 = {
		["PaddingLeft"] = UDim.new(0, 7),
		["PaddingRight"] = UDim.new(0, 7)
	}
	local v515 = v_u_2.new("UIPadding")
	for v516, v517 in v514 do
		v515[v516] = v517
	end
	v515.Parent = v507
	v_u_471.MouseEnter:Connect(function()
		-- upvalues: (copy) v_u_471, (ref) v_u_21
		v_u_471.BackgroundColor3 = v_u_21.cardHi
	end)
	v_u_471.MouseLeave:Connect(function()
		-- upvalues: (copy) v_u_471, (ref) v_u_21
		v_u_471.BackgroundColor3 = v_u_21.card
	end)
	v_u_471.Activated:Connect(function()
		-- upvalues: (ref) v_u_465, (copy) p_u_467
		v_u_465(p_u_467.id)
	end)
	return {
		["card"] = v_u_471,
		["edge"] = v479,
		["chip"] = v507,
		["info"] = p_u_467
	}
end
local function v_u_547() -- name: rebuildCatalog
	-- upvalues: (copy) v_u_461, (copy) v_u_462, (copy) v_u_12, (copy) v_u_17, (copy) v_u_22, (copy) v_u_21, (copy) v_u_203, (copy) v_u_2, (ref) v_u_464, (ref) v_u_345, (copy) v_u_518, (ref) v_u_349, (copy) v_u_341, (copy) v_u_359, (ref) v_u_357, (ref) v_u_358
	for _, v519 in v_u_461 do
		v519.card:Destroy()
	end
	table.clear(v_u_461)
	for _, v520 in v_u_462 do
		v520:Destroy()
	end
	table.clear(v_u_462)
	local v521 = { "\224\184\151\224\184\177\224\185\137\224\184\135\224\184\171\224\184\161\224\184\148" }
	for _, v522 in v_u_12.list do
		if not v522.category or table.find(v521, v522.category) then
			continue
		end
		local v523 = v522.category
		table.insert(v521, v523)
	end
	if v_u_12.isAdmin(v_u_17) then
		table.insert(v521, "\0admin")
	end
	for v524, v_u_525 in v521 do
		local v526 = v_u_525 == "\0admin"
		local v527 = {
			["Name"] = nil,
			["Text"] = nil,
			["Font"] = nil,
			["TextSize"] = 12,
			["TextColor3"] = nil,
			["BackgroundColor3"] = nil,
			["AutoButtonColor"] = true,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["LayoutOrder"] = nil,
			["BorderSizePixel"] = 0,
			["Name"] = v526 and "AdminTab" or "Tab",
			["Text"] = v526 and "\224\185\129\224\184\173\224\184\148\224\184\161\224\184\180\224\184\153" or v_u_525,
			["Font"] = v_u_22
		}
		local v528
		if v526 then
			v528 = v_u_21.admin
		else
			v528 = v_u_21.dim
		end
		v527.TextColor3 = v528
		v527.BackgroundColor3 = v_u_21.card
		v527.Size = UDim2.fromOffset(0, 28)
		v527.AutomaticSize = Enum.AutomaticSize.X
		v527.LayoutOrder = v524
		local v529 = v_u_203
		local v530 = v_u_2.new("TextButton")
		for v531, v532 in v527 do
			v530[v531] = v532
		end
		v530.Parent = v529
		local v533 = {
			["CornerRadius"] = UDim.new(0, 14)
		}
		local v534 = v_u_2.new("UICorner")
		for v535, v536 in v533 do
			v534[v535] = v536
		end
		v534.Parent = v530
		if v526 then
			local v537 = {
				["Color"] = nil,
				["Thickness"] = 1,
				["ApplyStrokeMode"] = nil,
				["Color"] = v_u_21.admin,
				["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border
			}
			local v538 = v_u_2.new("UIStroke")
			for v539, v540 in v537 do
				v538[v539] = v540
			end
			v538.Parent = v530
		end
		local v541 = {
			["PaddingLeft"] = UDim.new(0, 12),
			["PaddingRight"] = UDim.new(0, 12)
		}
		local v542 = v_u_2.new("UIPadding")
		for v543, v544 in v541 do
			v542[v543] = v544
		end
		v542.Parent = v530
		v530.Activated:Connect(function()
			-- upvalues: (ref) v_u_464, (copy) v_u_525
			v_u_464(v_u_525)
		end)
		v_u_462[v_u_525] = v530
	end
	if not v_u_462[v_u_345] then
		v_u_345 = "\224\184\151\224\184\177\224\185\137\224\184\135\224\184\171\224\184\161\224\184\148"
	end
	for v545, v546 in v_u_12.list do
		v_u_461[v546.id] = v_u_518(v546, v545)
	end
	if v_u_349 and not v_u_12.get(v_u_349.s) then
		v_u_349 = nil
		v_u_341:ClearAllChildren()
		table.clear(v_u_359)
		v_u_357 = nil
		v_u_358 = nil
	end
end
local v_u_548 = {}
local v_u_549 = nil
local function v_u_591(p550) -- name: rebuildLayers
	-- upvalues: (copy) v_u_548, (copy) v_u_251, (copy) v_u_12, (ref) v_u_351, (copy) v_u_21, (copy) v_u_236, (copy) v_u_2, (copy) v_u_56, (copy) v_u_23, (copy) v_u_72, (copy) v_u_80, (copy) v_u_39, (ref) v_u_343, (ref) v_u_349, (copy) v_u_341, (copy) v_u_359, (ref) v_u_357, (ref) v_u_358, (ref) v_u_549, (ref) v_u_363, (ref) v_u_364
	for _, v551 in v_u_548 do
		v551:Destroy()
	end
	table.clear(v_u_548)
	v_u_251.Visible = #p550 == 0
	for v_u_552 = #p550, 1, -1 do
		local v553 = p550[v_u_552]
		local v554 = v_u_12.get(v553.s)
		local v555 = {
			["Name"] = nil,
			["Text"] = "",
			["AutoButtonColor"] = true,
			["Size"] = nil,
			["LayoutOrder"] = nil,
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Name"] = "Layer" .. v_u_552,
			["Size"] = UDim2.new(1, 0, 0, 36),
			["LayoutOrder"] = #p550 - v_u_552 + 1
		}
		local v556
		if v_u_552 == v_u_351 then
			v556 = v_u_21.picked
		else
			v556 = v_u_21.card
		end
		v555.BackgroundColor3 = v556
		local v557 = v_u_236
		local v558 = v_u_2.new("TextButton")
		for v559, v560 in v555 do
			v558[v559] = v560
		end
		v558.Parent = v557
		local v561 = {
			["CornerRadius"] = UDim.new(0, 8)
		}
		local v562 = v_u_2.new("UICorner")
		for v563, v564 in v561 do
			v562[v563] = v564
		end
		v562.Parent = v558
		if v_u_552 == v_u_351 then
			local v565 = {
				["Color"] = nil,
				["Thickness"] = 1.5,
				["ApplyStrokeMode"] = nil,
				["Color"] = v_u_21.accent,
				["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border
			}
			local v566 = v_u_2.new("UIStroke")
			for v567, v568 in v565 do
				v566[v567] = v568
			end
			v566.Parent = v558
		end
		local v569 = {
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Position"] = UDim2.fromOffset(4, 4),
			["Size"] = UDim2.fromOffset(28, 28),
			["BackgroundColor3"] = v_u_21.thumb
		}
		local v570 = v_u_2.new("Frame")
		for v571, v572 in v569 do
			v570[v571] = v572
		end
		v570.Parent = v558
		local v573 = {
			["CornerRadius"] = UDim.new(0, 6)
		}
		local v574 = v_u_2.new("UICorner")
		for v575, v576 in v573 do
			v574[v575] = v576
		end
		v574.Parent = v570
		local v577 = {
			["BackgroundTransparency"] = 1,
			["Image"] = nil,
			["ScaleType"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["ImageColor3"] = nil,
			["Image"] = v554 and (v554.image or "") or "",
			["ScaleType"] = Enum.ScaleType.Fit,
			["Position"] = UDim2.fromOffset(3, 3),
			["Size"] = UDim2.new(1, -6, 1, -6)
		}
		local v578
		if v554 and (v554.tint and v553.c) then
			v578 = Color3.fromHex(v553.c)
		else
			v578 = Color3.new(1, 1, 1)
		end
		v577.ImageColor3 = v578
		local v579 = v_u_2.new("ImageLabel")
		for v580, v581 in v577 do
			v579[v580] = v581
		end
		v579.Parent = v570
		v_u_56(v558, ("%d \194\183 %s"):format(v_u_552, v554 and v554.name or "\224\184\165\224\184\178\224\184\162\224\184\151\224\184\181\224\185\136\224\185\128\224\184\165\224\184\180\224\184\129\224\184\130\224\184\178\224\184\162\224\185\129\224\184\165\224\185\137\224\184\167"), 12, v_u_21.text, v_u_23, {
			["Position"] = UDim2.fromOffset(40, 0),
			["Size"] = UDim2.new(1, -150, 1, 0),
			["TextTruncate"] = Enum.TextTruncate.AtEnd
		})
		local v582 = v_u_72(v558, "", {
			["Position"] = UDim2.new(1, -98, 0, 4),
			["Size"] = UDim2.fromOffset(28, 28)
		}, v_u_21.btn)
		v_u_80(v582, "up", v_u_21.text)
		local v583 = v_u_72(v558, "", {
			["Position"] = UDim2.new(1, -66, 0, 4),
			["Size"] = UDim2.fromOffset(28, 28)
		}, v_u_21.btn)
		v_u_80(v583, "down", v_u_21.text)
		local v584 = v_u_72(v558, "", {
			["Position"] = UDim2.new(1, -32, 0, 4),
			["Size"] = UDim2.fromOffset(28, 28)
		}, Color3.fromRGB(70, 40, 46) or v_u_21.btn)
		local v585 = v_u_21.text
		local v586 = {
			["BackgroundTransparency"] = 1,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5, 0.5),
			["Size"] = UDim2.fromOffset(16, 16)
		}
		local v587 = v_u_2.new("Frame")
		for v588, v589 in v586 do
			v587[v588] = v589
		end
		v587.Parent = v584
		v_u_39(v587, 13, 2.5, 45, v585)
		v_u_39(v587, 13, 2.5, -45, v585)
		local v590 = v_u_548
		table.insert(v590, v558)
		v558.Activated:Connect(function()
			-- upvalues: (ref) v_u_343, (ref) v_u_349, (ref) v_u_341, (ref) v_u_359, (ref) v_u_357, (ref) v_u_358, (ref) v_u_351, (copy) v_u_552, (ref) v_u_549
			if v_u_343 then
				v_u_349 = nil
				v_u_341:ClearAllChildren()
				table.clear(v_u_359)
				v_u_357 = nil
				v_u_358 = nil
				v_u_351 = v_u_552
				v_u_549 = nil
			end
		end)
		v582.Activated:Connect(function()
			-- upvalues: (ref) v_u_363, (copy) v_u_552
			v_u_363(v_u_552, 1)
		end)
		v583.Activated:Connect(function()
			-- upvalues: (ref) v_u_363, (copy) v_u_552
			v_u_363(v_u_552, -1)
		end)
		v584.Activated:Connect(function()
			-- upvalues: (ref) v_u_364, (copy) v_u_552
			v_u_364(v_u_552)
		end)
	end
end
local function v_u_592() -- name: hintText
	-- upvalues: (ref) v_u_348, (ref) v_u_349, (ref) v_u_342, (copy) v_u_360, (ref) v_u_347, (ref) v_u_351
	return v_u_348 and "\224\184\165\224\184\178\224\184\129\224\185\132\224\184\155\224\184\167\224\184\178\224\184\135\224\184\149\224\184\163\224\184\135\224\184\151\224\184\181\224\185\136\224\184\149\224\185\137\224\184\173\224\184\135\224\184\129\224\184\178\224\184\163 \224\185\129\224\184\165\224\185\137\224\184\167\224\184\155\224\184\165\224\185\136\224\184\173\224\184\162\224\185\128\224\184\161\224\184\178\224\184\170\224\185\140 \194\183 Esc = \224\184\162\224\184\129\224\185\128\224\184\165\224\184\180\224\184\129" or (v_u_349 and v_u_349.moving and "\224\184\132\224\184\165\224\184\180\224\184\129\224\184\154\224\184\153\224\184\163\224\184\150\224\184\149\224\184\163\224\184\135\224\184\151\224\184\181\224\185\136\224\184\136\224\184\176\224\184\162\224\185\137\224\184\178\224\184\162\224\185\132\224\184\155 \194\183 Esc = \224\184\162\224\184\129\224\185\128\224\184\165\224\184\180\224\184\129" or (v_u_349 and v_u_342 and "\224\184\149\224\184\163\224\184\135\224\184\153\224\184\181\224\185\137\224\185\129\224\184\155\224\184\176\224\185\132\224\184\161\224\185\136\224\185\132\224\184\148\224\185\137 \194\183 \224\185\128\224\184\165\224\184\183\224\185\136\224\184\173\224\184\153\224\185\132\224\184\155\224\184\154\224\184\153\224\184\149\224\184\177\224\184\167\224\184\150\224\184\177\224\184\135 / \224\185\129\224\184\159\224\184\163\224\184\180\224\185\136\224\184\135 / \224\184\154\224\184\177\224\184\135\224\185\130\224\184\132\224\184\165\224\184\153" or (v_u_349 and (v_u_360 and "\224\185\129\224\184\149\224\184\176\224\184\154\224\184\153\224\184\163\224\184\150\224\185\128\224\184\158\224\184\183\224\185\136\224\184\173\224\184\167\224\184\178\224\184\135 \194\183 \224\184\155\224\184\163\224\184\177\224\184\154\224\184\130\224\184\153\224\184\178\224\184\148 / \224\184\171\224\184\161\224\184\184\224\184\153\224\184\151\224\184\181\224\185\136\224\185\129\224\184\150\224\184\154\224\184\148\224\185\137\224\184\178\224\184\153\224\184\154\224\184\153" or "\224\184\132\224\184\165\224\184\180\224\184\129\224\184\154\224\184\153\224\184\163\224\184\150\224\185\128\224\184\158\224\184\183\224\185\136\224\184\173\224\184\167\224\184\178\224\184\135 \194\183 Shift \224\184\132\224\185\137\224\184\178\224\184\135 = \224\184\167\224\184\178\224\184\135\224\184\171\224\184\165\224\184\178\224\184\162\224\185\129\224\184\156\224\185\136\224\184\153 \194\183 Esc = \224\185\128\224\184\165\224\184\180\224\184\129\224\184\167\224\184\178\224\184\135") or (v_u_347 == "camera" and (v_u_360 and "\224\184\165\224\184\178\224\184\129\224\184\153\224\184\180\224\185\137\224\184\167 = \224\185\128\224\184\165\224\184\183\224\185\136\224\184\173\224\184\153\224\184\129\224\184\165\224\185\137\224\184\173\224\184\135 \194\183 \224\184\155\224\184\184\224\185\136\224\184\161 + / \226\136\146 \224\184\151\224\184\178\224\184\135\224\184\130\224\184\167\224\184\178 = \224\184\139\224\184\185\224\184\161\224\185\128\224\184\130\224\185\137\224\184\178\224\185\131\224\184\129\224\184\165\224\185\137" or "\224\184\165\224\184\178\224\184\129\224\185\128\224\184\161\224\184\178\224\184\170\224\185\140\224\184\139\224\185\137\224\184\178\224\184\162 = \224\185\128\224\184\165\224\184\183\224\185\136\224\184\173\224\184\153\224\184\129\224\184\165\224\185\137\224\184\173\224\184\135 \194\183 \224\184\165\224\184\185\224\184\129\224\184\129\224\184\165\224\184\180\224\185\137\224\184\135 / W S = \224\185\128\224\184\130\224\185\137\224\184\178\224\185\131\224\184\129\224\184\165\224\185\137-\224\184\173\224\184\173\224\184\129 \194\183 A D = \224\184\139\224\185\137\224\184\178\224\184\162-\224\184\130\224\184\167\224\184\178 \194\183 Q E = \224\184\165\224\184\135-\224\184\130\224\184\182\224\185\137\224\184\153 \194\183 \224\184\132\224\184\165\224\184\180\224\184\129\224\184\130\224\184\167\224\184\178\224\184\165\224\184\178\224\184\129 = \224\184\171\224\184\161\224\184\184\224\184\153") or (v_u_351 and v_u_347 == "move" and "\224\184\165\224\184\178\224\184\129\224\184\165\224\184\185\224\184\129\224\184\168\224\184\163\224\185\128\224\184\158\224\184\183\224\185\136\224\184\173\224\185\128\224\184\165\224\184\183\224\185\136\224\184\173\224\184\153\224\185\132\224\184\155\224\184\149\224\184\178\224\184\161\224\184\156\224\184\180\224\184\167\224\184\163\224\184\150 (\224\185\128\224\184\130\224\185\137\224\184\178\224\184\139\224\184\173\224\184\129\224\184\151\224\184\181\224\185\136\224\184\132\224\184\165\224\184\180\224\184\129\224\185\132\224\184\161\224\185\136\224\184\150\224\184\182\224\184\135\224\185\132\224\184\148\224\185\137) \194\183 \224\184\155\224\184\184\224\185\136\224\184\161\224\184\165\224\184\185\224\184\129\224\184\168\224\184\163 = \224\184\130\224\184\162\224\184\177\224\184\154\224\184\151\224\184\181\224\184\165\224\184\176\224\184\153\224\184\180\224\184\148 \194\183 Shift = \224\184\151\224\184\181\224\184\165\224\184\176\224\184\161\224\184\178\224\184\129" or (v_u_351 and v_u_347 == "depth" and "\224\184\165\224\184\178\224\184\129\224\184\155\224\184\184\224\185\136\224\184\161\224\184\138\224\184\161\224\184\158\224\184\185\224\184\130\224\184\182\224\185\137\224\184\153 = \224\184\148\224\184\182\224\184\135\224\184\173\224\184\173\224\184\129 \194\183 \224\184\165\224\184\135 = \224\184\148\224\184\177\224\184\153\224\185\128\224\184\130\224\185\137\224\184\178 (\224\184\149\224\184\180\224\184\148\224\184\165\224\184\154\224\185\132\224\184\148\224\185\137 \224\184\151\224\184\176\224\184\165\224\184\184\224\184\165\224\184\135\224\185\131\224\184\149\224\185\137\224\184\156\224\184\180\224\184\167) \194\183 + / \226\136\146 \224\184\129\224\184\148\224\184\132\224\185\137\224\184\178\224\184\135\224\185\132\224\184\148\224\185\137 \194\183 PageUp / PageDown \224\184\129\224\185\135\224\185\132\224\184\148\224\185\137" or (v_u_347 == "depth" and "\224\184\132\224\184\165\224\184\180\224\184\129\224\184\170\224\184\149\224\184\180\224\185\138\224\184\129\224\185\128\224\184\129\224\184\173\224\184\163\224\185\140\224\184\154\224\184\153\224\184\163\224\184\150\224\184\129\224\185\136\224\184\173\224\184\153 \224\185\129\224\184\165\224\185\137\224\184\167\224\184\148\224\184\182\224\184\135\224\185\128\224\184\130\224\185\137\224\184\178-\224\184\173\224\184\173\224\184\129\224\184\148\224\185\137\224\184\167\224\184\162\224\184\155\224\184\184\224\185\136\224\184\161\224\184\138\224\184\161\224\184\158\224\184\185\224\184\151\224\184\181\224\185\136\224\184\130\224\184\182\224\185\137\224\184\153\224\184\130\224\185\137\224\184\178\224\184\135 \224\185\134" or (v_u_351 and v_u_347 == "tilt" and "\224\184\165\224\184\178\224\184\129\224\184\155\224\184\184\224\185\136\224\184\161\224\184\159\224\185\137\224\184\178 \224\184\139\224\185\137\224\184\178\224\184\162-\224\184\130\224\184\167\224\184\178 = \224\185\128\224\184\137\224\184\181\224\184\162\224\184\135\224\184\139\224\185\137\224\184\178\224\184\162\224\184\130\224\184\167\224\184\178 \194\183 \224\184\130\224\184\182\224\185\137\224\184\153-\224\184\165\224\184\135 = \224\185\128\224\184\137\224\184\181\224\184\162\224\184\135\224\184\154\224\184\153\224\184\165\224\185\136\224\184\178\224\184\135 \194\183 \224\184\155\224\184\184\224\185\136\224\184\161\224\184\165\224\184\185\224\184\129\224\184\168\224\184\163 = \224\184\151\224\184\181\224\184\165\224\184\176 5\194\176 (Shift 15\194\176) \194\183 \224\184\155\224\184\184\224\185\136\224\184\161 0 = \224\184\129\224\184\165\224\184\177\224\184\154\224\184\161\224\184\178\224\184\149\224\184\163\224\184\135" or (v_u_347 == "tilt" and "\224\184\132\224\184\165\224\184\180\224\184\129\224\184\170\224\184\149\224\184\180\224\185\138\224\184\129\224\185\128\224\184\129\224\184\173\224\184\163\224\185\140\224\184\154\224\184\153\224\184\163\224\184\150\224\184\129\224\185\136\224\184\173\224\184\153 \224\185\129\224\184\165\224\185\137\224\184\167\224\184\155\224\184\163\224\184\177\224\184\154\224\185\128\224\184\137\224\184\181\224\184\162\224\184\135\224\184\148\224\185\137\224\184\167\224\184\162\224\184\155\224\184\184\224\185\136\224\184\161\224\184\159\224\185\137\224\184\178\224\184\151\224\184\181\224\185\136\224\184\130\224\184\182\224\185\137\224\184\153\224\184\130\224\185\137\224\184\178\224\184\135 \224\185\134" or (v_u_351 and v_u_347 == "scale" and "\224\184\165\224\184\178\224\184\129\224\184\136\224\184\184\224\184\148\224\184\151\224\184\181\224\185\136\224\184\130\224\184\173\224\184\154\224\185\128\224\184\158\224\184\183\224\185\136\224\184\173\224\184\162\224\185\136\224\184\173 / \224\184\130\224\184\162\224\184\178\224\184\162 \194\183 \224\184\155\224\184\184\224\185\136\224\184\161\224\184\165\224\184\185\224\184\129\224\184\168\224\184\163 = \224\184\130\224\184\162\224\184\177\224\184\154\224\184\151\224\184\181\224\184\165\224\184\176\224\184\153\224\184\180\224\184\148" or (v_u_351 and v_u_347 == "rotate" and "\224\184\165\224\184\178\224\184\129\224\184\167\224\184\135\224\185\129\224\184\171\224\184\167\224\184\153\224\185\128\224\184\158\224\184\183\224\185\136\224\184\173\224\184\171\224\184\161\224\184\184\224\184\153 (\224\184\151\224\184\181\224\184\165\224\184\176 5\194\176) \194\183 \224\184\155\224\184\184\224\185\136\224\184\161\224\184\165\224\184\185\224\184\129\224\184\168\224\184\163 = \224\184\130\224\184\162\224\184\177\224\184\154\224\184\151\224\184\181\224\184\165\224\184\176\224\184\153\224\184\180\224\184\148" or (v_u_351 and (v_u_360 and "\224\184\155\224\184\163\224\184\177\224\184\154\224\184\151\224\184\181\224\185\136\224\185\129\224\184\150\224\184\154\224\184\148\224\185\137\224\184\178\224\184\153\224\184\154\224\184\153 \194\183 \224\185\129\224\184\149\224\184\176 \224\184\162\224\185\137\224\184\178\224\184\162 \224\185\129\224\184\165\224\185\137\224\184\167\224\185\129\224\184\149\224\184\176\224\184\136\224\184\184\224\184\148\224\185\131\224\184\171\224\184\161\224\185\136" or "\224\184\165\224\184\178\224\184\129\224\184\170\224\184\149\224\184\180\224\185\138\224\184\129\224\185\128\224\184\129\224\184\173\224\184\163\224\185\140\224\185\128\224\184\158\224\184\183\224\185\136\224\184\173\224\184\162\224\185\137\224\184\178\224\184\162 \194\183 \224\184\155\224\184\163\224\184\177\224\184\154\224\184\130\224\184\153\224\184\178\224\184\148 / \224\184\171\224\184\161\224\184\184\224\184\153 / \224\184\170\224\184\181\224\184\151\224\184\181\224\185\136\224\185\129\224\184\150\224\184\154\224\184\148\224\185\137\224\184\178\224\184\153\224\184\154\224\184\153 \194\183 Delete = \224\184\165\224\184\154 \194\183 Esc = \224\185\128\224\184\165\224\184\180\224\184\129\224\185\128\224\184\165\224\184\183\224\184\173\224\184\129") or (v_u_360 and "\224\185\128\224\184\165\224\184\183\224\184\173\224\184\129\224\184\165\224\184\178\224\184\162\224\184\136\224\184\178\224\184\129\224\185\129\224\184\156\224\184\135\224\184\139\224\185\137\224\184\178\224\184\162 \224\184\171\224\184\163\224\184\183\224\184\173\224\185\129\224\184\149\224\184\176\224\184\170\224\184\149\224\184\180\224\185\138\224\184\129\224\185\128\224\184\129\224\184\173\224\184\163\224\185\140\224\184\154\224\184\153\224\184\163\224\184\150\224\185\128\224\184\158\224\184\183\224\185\136\224\184\173\224\185\129\224\184\129\224\185\137 \194\183 \224\184\165\224\184\178\224\184\129\224\184\153\224\184\180\224\185\137\224\184\167 = \224\184\171\224\184\161\224\184\184\224\184\153\224\184\129\224\184\165\224\185\137\224\184\173\224\184\135" or "\224\185\128\224\184\165\224\184\183\224\184\173\224\184\129\224\184\165\224\184\178\224\184\162\224\184\136\224\184\178\224\184\129\224\185\129\224\184\156\224\184\135\224\184\139\224\185\137\224\184\178\224\184\162 \224\184\171\224\184\163\224\184\183\224\184\173\224\184\132\224\184\165\224\184\180\224\184\129\224\184\170\224\184\149\224\184\180\224\185\138\224\184\129\224\185\128\224\184\129\224\184\173\224\184\163\224\185\140\224\184\154\224\184\153\224\184\163\224\184\150\224\185\128\224\184\158\224\184\183\224\185\136\224\184\173\224\185\129\224\184\129\224\185\137 \194\183 \224\184\132\224\184\165\224\184\180\224\184\129\224\184\130\224\184\167\224\184\178\224\184\165\224\184\178\224\184\129 = \224\184\171\224\184\161\224\184\184\224\184\153\224\184\129\224\184\165\224\185\137\224\184\173\224\184\135 \194\183 \224\184\165\224\184\185\224\184\129\224\184\129\224\184\165\224\184\180\224\185\137\224\184\135 = \224\184\139\224\184\185\224\184\161")))))))))))))
end
local function v_u_595() -- name: compactForPhone
	-- upvalues: (copy) v_u_174
	if not v_u_174:GetAttribute("Compact") then
		v_u_174:SetAttribute("Compact", true)
		for _, v593 in v_u_174:GetChildren() do
			if not v593:IsA("GuiObject") then
				continue
			end
			local v594 = v593.Position.Y.Offset
			if v593.Name == "Grid" then
				v593.Size = UDim2.fromOffset(v593.Size.X.Offset, v593.Size.Y.Offset - 116)
			elseif v594 >= 500 then
				v593.Position = UDim2.fromOffset(v593.Position.X.Offset, v594 - 116 - 44)
			else
				if v594 < 340 then
					continue
				end
				v593.Position = UDim2.fromOffset(v593.Position.X.Offset, v594 - 116)
				if v593.Size.Y.Offset <= 100 then
					continue
				end
				v593.Size = UDim2.fromOffset(v593.Size.X.Offset, v593.Size.Y.Offset - 44)
			end
		end
		v_u_174.Size = UDim2.fromOffset(340, 450)
		v_u_174.Position = UDim2.new(0, 8, 0.5, 0)
	end
end
local function v_u_608() -- name: layout
	-- upvalues: (copy) v_u_9, (copy) v_u_14, (copy) v_u_595, (copy) v_u_181, (copy) v_u_174, (copy) v_u_268, (copy) v_u_261, (copy) v_u_312, (ref) v_u_350, (ref) v_u_344
	local v596 = workspace.CurrentCamera.ViewportSize
	local v597 = v_u_9:GetGuiInset()
	if v_u_14.isPhone(v596) then
		v_u_595()
	end
	local v598 = v_u_181
	local v599 = (v596.Y - v597.Y - 20) / v_u_174.Size.Y.Offset
	v598.Scale = math.clamp(v599, 0.55, 1)
	local v600 = v_u_174.AbsolutePosition.X + v_u_174.AbsoluteSize.X
	local v601 = v596.X - 130 - v600
	local v602 = math.max(200, v601)
	local v603 = v_u_268
	local v604 = (v602 - 24) / 600
	v603.Scale = math.clamp(v604, 0.55, 1)
	local v605 = v600 + v602 / 2
	local v606 = math.floor(v605)
	v_u_261.Position = UDim2.fromOffset(v606, 12)
	local v607 = not v_u_261.Visible and 12 or 12 + 118 * v_u_268.Scale + 8
	v_u_312.Position = UDim2.fromOffset(v606, v607)
	if v_u_350 then
		v_u_344.Scale = v_u_268.Scale
		v_u_350.Position = UDim2.fromOffset(v606, v596.Y - v597.Y - 14)
	end
end
local function v_u_681() -- name: refresh
	-- upvalues: (ref) v_u_343, (copy) v_u_11, (ref) v_u_351, (copy) v_u_195, (copy) v_u_10, (copy) v_u_256, (copy) v_u_21, (copy) v_u_259, (copy) v_u_257, (copy) v_u_17, (copy) v_u_461, (ref) v_u_345, (ref) v_u_349, (copy) v_u_462, (copy) v_u_14, (ref) v_u_463, (copy) v_u_215, (copy) v_u_230, (copy) v_u_232, (copy) v_u_236, (copy) v_u_466, (copy) v_u_12, (ref) v_u_549, (copy) v_u_591, (ref) v_u_352, (copy) v_u_393, (copy) v_u_261, (copy) v_u_280, (copy) v_u_283, (copy) v_u_284, (ref) v_u_361, (ref) v_u_362, (copy) v_u_285, (copy) v_u_286, (copy) v_u_288, (copy) v_u_291, (copy) v_u_292, (copy) v_u_307, (copy) v_u_308, (copy) v_u_309, (copy) v_u_310, (ref) v_u_342, (copy) v_u_312, (copy) v_u_592, (copy) v_u_608, (copy) v_u_359, (ref) v_u_348, (copy) v_u_451
	if v_u_343 then
		local v609 = v_u_343.model
		local v610 = not v_u_343 and {} or v_u_11.read(v_u_343.model)
		if v_u_351 and not v610[v_u_351] then
			v_u_351 = nil
		end
		v_u_195.Text = ("%d / %d"):format(#v610, v_u_11.maxFor(v609))
		local v611 = v_u_10.tuneDue(v609)
		v_u_256.Text = v611 <= 0 and "\226\128\148" or v_u_10.priceText(v611)
		local v612 = v_u_256
		local v613
		if v611 > 0 then
			v613 = v_u_21.warn
		else
			v613 = v_u_21.dim
		end
		v612.TextColor3 = v613
		v_u_259.Text = v611 <= 0 and "\224\184\154\224\184\177\224\184\153\224\184\151\224\184\182\224\184\129" or "\224\184\154\224\184\177\224\184\153\224\184\151\224\184\182\224\184\129 \194\183 " .. v_u_10.priceText(v611)
		v_u_257.Text = "\224\185\128\224\184\135\224\184\180\224\184\153 " .. v_u_10.formatCash(v_u_17:GetAttribute("Cash") or 0)
		local v614 = v_u_10.tuneOwned(v609) or {}
		for v615, v616 in v_u_461 do
			local v617 = v616.info
			v616.card.Visible = v_u_345 == "\224\184\151\224\184\177\224\185\137\224\184\135\224\184\171\224\184\161\224\184\148" and true or v617.category == v_u_345
			if v614["Sticker_" .. v615] then
				local v618 = v616.chip
				local v619 = v616.chip
				local v620 = v_u_21.good
				v618.Text = "\224\184\161\224\184\181\224\185\129\224\184\165\224\185\137\224\184\167"
				v619.TextColor3 = v620
			elseif (v617.price or 0) <= 0 then
				local v621 = v616.chip
				local v622 = v616.chip
				local v623 = v_u_21.good
				v621.Text = "\224\184\159\224\184\163\224\184\181"
				v622.TextColor3 = v623
			else
				local v624 = v616.chip
				local v625 = v616.chip
				local v626 = v_u_10.priceText(v617.price)
				local v627 = v_u_21.warn
				v624.Text = v626
				v625.TextColor3 = v627
			end
			local v628
			if v_u_349 == nil or v_u_349.s ~= v615 then
				v628 = false
			else
				v628 = not v_u_349.moving
			end
			local v629 = v616.edge
			local v630
			if v628 then
				v630 = v_u_21.accent
			else
				v630 = v_u_21.card
			end
			v629.Color = v630
		end
		for v631, v632 in v_u_462 do
			local v633 = v631 == v_u_345
			local v634 = v631 == "\0admin"
			local v635
			if v633 then
				if v634 then
					v635 = v_u_14.RED
				else
					v635 = v_u_21.accent
				end
			else
				v635 = v_u_21.card
			end
			v632.BackgroundColor3 = v635
			local v636
			if v633 then
				if v634 then
					v636 = v_u_21.text
				else
					v636 = v_u_21.onAccent
				end
			elseif v634 then
				v636 = v_u_21.admin
			else
				v636 = v_u_21.dim
			end
			v632.TextColor3 = v636
		end
		local v637
		if v_u_345 == "\0admin" then
			v637 = v_u_463 ~= nil
		else
			v637 = false
		end
		v_u_215.Visible = not v637
		local v638 = v_u_232
		local v639 = v_u_236
		v_u_230.Visible = not v637
		v638.Visible = not v637
		v639.Visible = not v637
		if v_u_463 then
			v_u_463.frame.Visible = v637
		end
		local v640 = false
		for _, v641 in v_u_461 do
			if not v641.card.Visible then
				continue
			end
			v640 = true
		end
		local v642 = v_u_466
		local v643 = not v637
		if v643 then
			v643 = not v640
		end
		v642.Visible = v643
		v_u_466.Text = v_u_12.isAdmin(v_u_17) and "\224\184\162\224\184\177\224\184\135\224\185\132\224\184\161\224\185\136\224\184\161\224\184\181\224\184\165\224\184\178\224\184\162\224\184\170\224\184\149\224\184\180\224\185\138\224\184\129\224\185\128\224\184\129\224\184\173\224\184\163\224\185\140\224\185\131\224\184\153\224\184\163\224\185\137\224\184\178\224\184\153\n\224\185\128\224\184\158\224\184\180\224\185\136\224\184\161\224\184\165\224\184\178\224\184\162\224\185\132\224\184\148\224\185\137\224\184\151\224\184\181\224\185\136\224\185\129\224\184\151\224\185\135\224\184\154 \224\185\129\224\184\173\224\184\148\224\184\161\224\184\180\224\184\153" or "\224\184\162\224\184\177\224\184\135\224\185\132\224\184\161\224\185\136\224\184\161\224\184\181\224\184\165\224\184\178\224\184\162\224\184\170\224\184\149\224\184\180\224\185\138\224\184\129\224\185\128\224\184\129\224\184\173\224\184\163\224\185\140\224\185\131\224\184\153\224\184\163\224\185\137\224\184\178\224\184\153"
		local v644 = v_u_11.ATTR
		local v645 = tostring(v609:GetAttribute(v644))
		local v646 = v_u_351
		local v647 = v645 .. "|" .. tostring(v646)
		if v647 ~= v_u_549 then
			v_u_549 = v647
			v_u_591(v610)
		end
		local v648 = nil
		local v649 = nil
		local v650 = nil
		local v651 = nil
		local v652 = nil
		if v_u_349 then
			local v653 = v_u_349.moving
			if v653 then
				v653 = v610[v_u_349.moving]
			end
			v648 = v_u_349.s
			v649 = v_u_349.w
			v650 = v_u_349.rot
			v651 = v_u_349.c
			if v653 then
				v652 = "\224\184\129\224\184\179\224\184\165\224\184\177\224\184\135\224\184\162\224\185\137\224\184\178\224\184\162 \194\183 \224\184\132\224\184\165\224\184\180\224\184\129\224\184\136\224\184\184\224\184\148\224\185\131\224\184\171\224\184\161\224\185\136\224\184\154\224\184\153\224\184\163\224\184\150"
			else
				v652 = "\224\184\129\224\184\179\224\184\165\224\184\177\224\184\135\224\184\167\224\184\178\224\184\135 \194\183 \224\184\132\224\184\165\224\184\180\224\184\129\224\184\154\224\184\153\224\184\163\224\184\150"
			end
		elseif v_u_351 then
			local v654
			if v_u_352 then
				v654 = v_u_352.entry
			else
				v654 = v610[v_u_351]
			end
			v648 = v654.s
			v649 = v654.w
			v651 = v654.c
			v650 = v_u_393(v654)
			v652 = ("\224\185\129\224\184\156\224\185\136\224\184\153\224\184\151\224\184\181\224\185\136 %d \224\184\136\224\184\178\224\184\129 %d"):format(v_u_351, #v610)
		end
		v_u_261.Visible = v648 ~= nil
		if v648 then
			local v655 = v_u_12.get(v648)
			v_u_280.Image = v655 and (v655.image or "") or ""
			local v656 = v_u_280
			local v657
			if v655 and (v655.tint and v651) then
				v657 = Color3.fromHex(v651)
			else
				v657 = Color3.new(1, 1, 1)
			end
			v656.ImageColor3 = v657
			v_u_283.Text = v655 and (v655.name or "\224\184\165\224\184\178\224\184\162\224\184\151\224\184\181\224\185\136\224\185\128\224\184\165\224\184\180\224\184\129\224\184\130\224\184\178\224\184\162\224\185\129\224\184\165\224\185\137\224\184\167 (\224\184\129\224\184\148\224\184\165\224\184\154\224\185\132\224\184\148\224\185\137)") or "\224\184\165\224\184\178\224\184\162\224\184\151\224\184\181\224\185\136\224\185\128\224\184\165\224\184\180\224\184\129\224\184\130\224\184\178\224\184\162\224\185\129\224\184\165\224\185\137\224\184\167 (\224\184\129\224\184\148\224\184\165\224\184\154\224\185\132\224\184\148\224\185\137)"
			v_u_284.Text = v652
			if not v_u_361.dragging then
				local v658 = v_u_361.set
				local v659 = v649 - v_u_11.MIN_W
				local v660 = v_u_12.get(v648)
				local v661 = v_u_11.MAX_W
				local v662 = v660 and v660.maxSize or v_u_11.MAX_W
				local v663 = math.min(v661, v662) - v_u_11.MIN_W
				v658(v659 / math.max(0.01, v663))
			end
			if not v_u_362.dragging then
				v_u_362.set((v650 + 180) / 360)
			end
			v_u_285.Text = ("%.1f"):format(v649)
			local v664 = v_u_286
			local v665 = v650 + 0.5
			v664.Text = ("%d\194\176"):format((math.floor(v665)))
			local v666
			if v655 == nil then
				v666 = false
			else
				v666 = v655.tint == true
			end
			v_u_288.Visible = v666
			v_u_291.Visible = not v666
			for v667, v668 in v_u_292 do
				local v669
				if v666 then
					v669 = (v651 or "ffffff") == v667
				else
					v669 = v666
				end
				local v670 = v668.Ring
				local v671
				if v669 then
					v671 = v_u_21.accent
				else
					v671 = Color3.fromRGB(80, 82, 96)
				end
				v670.Color = v671
				v668.Ring.Thickness = v669 and 2.5 or 1
			end
			local v672
			if v_u_351 == nil then
				v672 = false
			else
				v672 = not v_u_349
			end
			local v673 = v_u_308
			local v674 = v_u_309
			v_u_307.Visible = v672
			v673.Visible = v672
			v674.Visible = v672
			v_u_310.Visible = v_u_349 ~= nil
		end
		if not v_u_349 then
			v_u_342 = false
		end
		v_u_312.Text = v_u_592()
		local v675 = v_u_312
		local v676
		if v_u_349 and v_u_342 then
			v676 = v_u_21.warn
		else
			v676 = v_u_21.text
		end
		v675.TextColor3 = v676
		v_u_608()
		for _, v677 in v_u_359 do
			v677:Destroy()
		end
		table.clear(v_u_359)
		local v678 = v_u_351 and not v_u_349 and not (v_u_348 or v_u_352)
		if v678 then
			v678 = (not v_u_343 and {} or v_u_11.read(v_u_343.model))[v_u_351]
		end
		local v679 = v678 and v_u_451(v678, v_u_21.accent)
		if v679 then
			local v680 = v_u_359
			table.insert(v680, v679)
		end
	end
end
v_u_363 = function(p682, p683) -- name: sendLayer
	-- upvalues: (ref) v_u_346, (copy) v_u_373, (copy) v_u_19, (copy) v_u_13, (ref) v_u_351, (ref) v_u_549, (copy) v_u_681
	local v684, v685
	if v_u_346 then
		v684 = false
		v685 = nil
	else
		v_u_346 = true
		v684, v685 = v_u_373(v_u_19, "layer", p682, p683)
		v_u_346 = false
		if not v684 and v685 then
			v_u_13.show(v685, "error")
		end
	end
	if v684 then
		v_u_351 = v685
	end
	v_u_549 = nil
	v_u_681()
end
v_u_364 = function(p686) -- name: sendRemove
	-- upvalues: (ref) v_u_346, (copy) v_u_373, (copy) v_u_19, (copy) v_u_13, (ref) v_u_351, (ref) v_u_549, (copy) v_u_681
	local v687
	if v_u_346 then
		v687 = false
	else
		v_u_346 = true
		local v688
		v687, v688 = v_u_373(v_u_19, "remove", p686, nil)
		v_u_346 = false
		if not v687 and v688 then
			v_u_13.show(v688, "error")
		end
	end
	if v687 then
		if v_u_351 == p686 then
			v_u_351 = nil
		elseif v_u_351 and p686 < v_u_351 then
			v_u_351 = v_u_351 - 1
		end
	end
	v_u_549 = nil
	v_u_681()
end
local function v_u_701(p689) -- name: placeAt
	-- upvalues: (copy) v_u_423, (ref) v_u_349, (copy) v_u_13, (copy) v_u_375, (ref) v_u_346, (copy) v_u_373, (copy) v_u_19, (ref) v_u_351, (copy) v_u_7, (copy) v_u_341, (copy) v_u_359, (ref) v_u_357, (ref) v_u_358, (ref) v_u_343, (ref) v_u_424, (copy) v_u_681
	local v690 = v_u_423
	local v691 = v_u_349
	if v691 then
		v691 = v_u_349.moving
	end
	local v692, v693 = v690(p689, v691)
	if v692 then
		local v694 = v_u_349.moving
		local v695, v696
		if v694 then
			local v697 = v_u_375(p689)
			if v_u_346 then
				v695 = false
				v696 = nil
			else
				v_u_346 = true
				v695, v696 = v_u_373(v_u_19, "edit", v694, v697)
				v_u_346 = false
				if not v695 and v696 then
					v_u_13.show(v696, "error")
				end
			end
		else
			local v698 = v_u_375(p689)
			if v_u_346 then
				v695 = false
				v696 = nil
			else
				v_u_346 = true
				v695, v696 = v_u_373(v_u_19, "place", v698, nil)
				v_u_346 = false
				if not v695 and v696 then
					v_u_13.show(v696, "error")
				end
			end
		end
		if v695 then
			v_u_351 = v696
			if v694 or not v_u_7:IsKeyDown(Enum.KeyCode.LeftShift) then
				v_u_349 = nil
				v_u_341:ClearAllChildren()
				table.clear(v_u_359)
				v_u_357 = nil
				v_u_358 = nil
				local v699 = v_u_343
				if v699 then
					v699 = v_u_343.model:FindFirstChild("StickerVisuals")
				end
				if v_u_424 and (v699 and v699:FindFirstChild("S" .. v_u_424)) then
					for _, v700 in v699["S" .. v_u_424]:GetDescendants() do
						if not v700:IsA("Texture") then
							continue
						end
						v700.Transparency = 0
					end
				end
				v_u_424 = nil
			end
		end
		v_u_358 = nil
		v_u_681()
	else
		v_u_13.show(v693, "error")
	end
end
local function v_u_703() -- name: startEdit
	-- upvalues: (ref) v_u_352, (ref) v_u_351, (ref) v_u_349, (ref) v_u_343, (copy) v_u_11, (copy) v_u_377, (copy) v_u_429
	local v702 = (not v_u_352 and (v_u_351 and not v_u_349) and true or false) and (not v_u_343 and {} or v_u_11.read(v_u_343.model))[v_u_351]
	if v702 then
		v_u_352 = {
			["index"] = v_u_351,
			["entry"] = v_u_377(v702)
		}
		v_u_429(v_u_351)
	end
	return v_u_352
end
v_u_361 = v133(v_u_261, 238, 44, 160, function(p704)
	-- upvalues: (ref) v_u_349, (copy) v_u_11, (copy) v_u_12, (ref) v_u_358, (copy) v_u_703, (ref) v_u_352, (ref) v_u_343, (copy) v_u_460, (copy) v_u_681
	if v_u_349 then
		local v705 = v_u_349
		local v706 = v_u_349.s
		local v707 = v_u_11.MIN_W
		local v708 = v_u_12.get(v706)
		local v709 = v_u_11.MAX_W
		local v710 = v708 and v708.maxSize or v_u_11.MAX_W
		v705.w = v707 + p704 * (math.min(v709, v710) - v_u_11.MIN_W)
		v_u_358 = nil
	elseif v_u_703() then
		local v711 = v_u_352.entry
		local v712 = v_u_352.entry.s
		local v713 = v_u_11.MIN_W
		local v714 = v_u_12.get(v712)
		local v715 = v_u_11.MAX_W
		local v716 = v714 and v714.maxSize or v_u_11.MAX_W
		v711.w = v713 + p704 * (math.min(v715, v716) - v_u_11.MIN_W)
		v_u_11.settle(v_u_352.entry, v_u_343.panels, v_u_343.include)
		if v_u_352 then
			v_u_460(v_u_352.entry, v_u_352.index, v_u_352.index)
		end
	end
	v_u_681()
end, function()
	-- upvalues: (ref) v_u_352, (copy) v_u_423, (copy) v_u_13, (copy) v_u_375, (ref) v_u_346, (copy) v_u_373, (copy) v_u_19, (ref) v_u_351, (copy) v_u_341, (copy) v_u_359, (ref) v_u_357, (ref) v_u_358, (ref) v_u_343, (ref) v_u_424, (ref) v_u_549, (copy) v_u_681
	if v_u_352 then
		local v717 = v_u_352
		v_u_352 = nil
		local v718 = v717.index
		local v719 = v717.entry
		local v720, v721 = v_u_423(v719, v718)
		if v720 then
			local v722 = v_u_375(v719)
			local v723, v724
			if v_u_346 then
				v723 = false
				v724 = nil
			else
				v_u_346 = true
				v723, v724 = v_u_373(v_u_19, "edit", v718, v722)
				v_u_346 = false
				if not v723 and v724 then
					v_u_13.show(v724, "error")
				end
			end
			if v723 then
				v_u_351 = v724
			end
		else
			v_u_13.show(v721, "error")
		end
		v_u_341:ClearAllChildren()
		table.clear(v_u_359)
		v_u_357 = nil
		v_u_358 = nil
		local v725 = v_u_343
		if v725 then
			v725 = v_u_343.model:FindFirstChild("StickerVisuals")
		end
		if v_u_424 and (v725 and v725:FindFirstChild("S" .. v_u_424)) then
			for _, v726 in v725["S" .. v_u_424]:GetDescendants() do
				if not v726:IsA("Texture") then
					continue
				end
				v726.Transparency = 0
			end
		end
		v_u_424 = nil
		v_u_549 = nil
		v_u_681()
	end
end)
v_u_362 = v133(v_u_261, 418, 44, 170, function(p727)
	-- upvalues: (ref) v_u_349, (ref) v_u_358, (copy) v_u_703, (copy) v_u_399, (ref) v_u_352, (copy) v_u_460, (copy) v_u_681
	local v728 = (p727 * 360 - 180) / 5 + 0.5
	local v729 = math.floor(v728) * 5
	if v_u_349 then
		v_u_349.rot = v729
		v_u_358 = nil
	elseif v_u_703() then
		v_u_399(v_u_352.entry, v729)
		if v_u_352 then
			v_u_460(v_u_352.entry, v_u_352.index, v_u_352.index)
		end
	end
	v_u_681()
end, function()
	-- upvalues: (ref) v_u_352, (copy) v_u_423, (copy) v_u_13, (copy) v_u_375, (ref) v_u_346, (copy) v_u_373, (copy) v_u_19, (ref) v_u_351, (copy) v_u_341, (copy) v_u_359, (ref) v_u_357, (ref) v_u_358, (ref) v_u_343, (ref) v_u_424, (ref) v_u_549, (copy) v_u_681
	if v_u_352 then
		local v730 = v_u_352
		v_u_352 = nil
		local v731 = v730.index
		local v732 = v730.entry
		local v733, v734 = v_u_423(v732, v731)
		if v733 then
			local v735 = v_u_375(v732)
			local v736, v737
			if v_u_346 then
				v736 = false
				v737 = nil
			else
				v_u_346 = true
				v736, v737 = v_u_373(v_u_19, "edit", v731, v735)
				v_u_346 = false
				if not v736 and v737 then
					v_u_13.show(v737, "error")
				end
			end
			if v736 then
				v_u_351 = v737
			end
		else
			v_u_13.show(v734, "error")
		end
		v_u_341:ClearAllChildren()
		table.clear(v_u_359)
		v_u_357 = nil
		v_u_358 = nil
		local v738 = v_u_343
		if v738 then
			v738 = v_u_343.model:FindFirstChild("StickerVisuals")
		end
		if v_u_424 and (v738 and v738:FindFirstChild("S" .. v_u_424)) then
			for _, v739 in v738["S" .. v_u_424]:GetDescendants() do
				if not v739:IsA("Texture") then
					continue
				end
				v739.Transparency = 0
			end
		end
		v_u_424 = nil
		v_u_549 = nil
		v_u_681()
	end
end)
local function v_u_767(p740) -- name: resize
	-- upvalues: (ref) v_u_349, (copy) v_u_11, (copy) v_u_12, (ref) v_u_358, (copy) v_u_703, (ref) v_u_352, (ref) v_u_343, (copy) v_u_423, (copy) v_u_13, (copy) v_u_375, (ref) v_u_346, (copy) v_u_373, (copy) v_u_19, (ref) v_u_351, (copy) v_u_341, (copy) v_u_359, (ref) v_u_357, (ref) v_u_424, (ref) v_u_549, (copy) v_u_681
	if v_u_349 then
		local v741 = v_u_349
		local v742 = v_u_349.w * p740
		local v743 = v_u_11.MIN_W
		local v744 = v_u_349.s
		local v745 = v_u_12.get(v744)
		local v746 = v_u_11.MAX_W
		local v747 = v745 and v745.maxSize or v_u_11.MAX_W
		local v748 = math.min(v746, v747)
		v741.w = math.clamp(v742, v743, v748)
		v_u_358 = nil
	elseif v_u_703() then
		local v749 = v_u_352.entry
		local v750 = v_u_352.entry.w * p740
		local v751 = v_u_11.MIN_W
		local v752 = v_u_352.entry.s
		local v753 = v_u_12.get(v752)
		local v754 = v_u_11.MAX_W
		local v755 = v753 and v753.maxSize or v_u_11.MAX_W
		local v756 = math.min(v754, v755)
		v749.w = math.clamp(v750, v751, v756)
		v_u_11.settle(v_u_352.entry, v_u_343.panels, v_u_343.include)
		if v_u_352 then
			local v757 = v_u_352
			v_u_352 = nil
			local v758 = v757.index
			local v759 = v757.entry
			local v760, v761 = v_u_423(v759, v758)
			if v760 then
				local v762 = v_u_375(v759)
				local v763, v764
				if v_u_346 then
					v763 = false
					v764 = nil
				else
					v_u_346 = true
					v763, v764 = v_u_373(v_u_19, "edit", v758, v762)
					v_u_346 = false
					if not v763 and v764 then
						v_u_13.show(v764, "error")
					end
				end
				if v763 then
					v_u_351 = v764
				end
			else
				v_u_13.show(v761, "error")
			end
			v_u_341:ClearAllChildren()
			table.clear(v_u_359)
			v_u_357 = nil
			v_u_358 = nil
			local v765 = v_u_343
			if v765 then
				v765 = v_u_343.model:FindFirstChild("StickerVisuals")
			end
			if v_u_424 and (v765 and v765:FindFirstChild("S" .. v_u_424)) then
				for _, v766 in v765["S" .. v_u_424]:GetDescendants() do
					if not v766:IsA("Texture") then
						continue
					end
					v766.Transparency = 0
				end
			end
			v_u_424 = nil
			v_u_549 = nil
			v_u_681()
		end
	end
	v_u_681()
end
local v_u_768 = v_u_463
local v_u_769 = v_u_364
local v_u_770 = v_u_424
local v_u_771 = v_u_549
for v_u_772, v773 in v_u_292 do
	v773.Activated:Connect(function()
		-- upvalues: (ref) v_u_349, (copy) v_u_772, (ref) v_u_358, (copy) v_u_703, (ref) v_u_352, (copy) v_u_423, (copy) v_u_13, (copy) v_u_375, (ref) v_u_346, (copy) v_u_373, (copy) v_u_19, (ref) v_u_351, (copy) v_u_341, (copy) v_u_359, (ref) v_u_357, (ref) v_u_343, (ref) v_u_770, (ref) v_u_771, (copy) v_u_681
		if v_u_349 then
			v_u_349.c = v_u_772
			v_u_358 = nil
		elseif v_u_703() then
			v_u_352.entry.c = v_u_772
			if v_u_352 then
				local v774 = v_u_352
				v_u_352 = nil
				local v775 = v774.index
				local v776 = v774.entry
				local v777, v778 = v_u_423(v776, v775)
				if v777 then
					local v779 = v_u_375(v776)
					local v780, v781
					if v_u_346 then
						v780 = false
						v781 = nil
					else
						v_u_346 = true
						v780, v781 = v_u_373(v_u_19, "edit", v775, v779)
						v_u_346 = false
						if not v780 and v781 then
							v_u_13.show(v781, "error")
						end
					end
					if v780 then
						v_u_351 = v781
					end
				else
					v_u_13.show(v778, "error")
				end
				v_u_341:ClearAllChildren()
				table.clear(v_u_359)
				v_u_357 = nil
				v_u_358 = nil
				local v782 = v_u_343
				if v782 then
					v782 = v_u_343.model:FindFirstChild("StickerVisuals")
				end
				if v_u_770 and (v782 and v782:FindFirstChild("S" .. v_u_770)) then
					for _, v783 in v782["S" .. v_u_770]:GetDescendants() do
						if not v783:IsA("Texture") then
							continue
						end
						v783.Transparency = 0
					end
				end
				v_u_770 = nil
				v_u_771 = nil
				v_u_681()
			end
		end
		v_u_681()
	end)
end
local v_u_784 = {
	{
		["key"] = "select",
		["label"] = "\224\185\128\224\184\165\224\184\183\224\184\173\224\184\129",
		["keyCode"] = nil,
		["keyCode"] = Enum.KeyCode.One
	},
	{
		["key"] = "move",
		["label"] = "\224\185\128\224\184\132\224\184\165\224\184\183\224\185\136\224\184\173\224\184\153\224\184\162\224\185\137\224\184\178\224\184\162",
		["keyCode"] = nil,
		["keyCode"] = Enum.KeyCode.Two
	},
	{
		["key"] = "depth",
		["label"] = "\224\184\148\224\184\182\224\184\135\224\185\128\224\184\130\224\185\137\224\184\178\224\184\173\224\184\173\224\184\129",
		["keyCode"] = nil,
		["keyCode"] = Enum.KeyCode.Three
	},
	{
		["key"] = "scale",
		["label"] = "\224\184\155\224\184\163\224\184\177\224\184\154\224\184\130\224\184\153\224\184\178\224\184\148",
		["keyCode"] = nil,
		["keyCode"] = Enum.KeyCode.Four
	},
	{
		["key"] = "rotate",
		["label"] = "\224\184\171\224\184\161\224\184\184\224\184\153",
		["keyCode"] = nil,
		["keyCode"] = Enum.KeyCode.Five
	},
	{
		["key"] = "tilt",
		["label"] = "\224\185\128\224\184\137\224\184\181\224\184\162\224\184\135",
		["keyCode"] = nil,
		["keyCode"] = Enum.KeyCode.Seven
	},
	{
		["key"] = "camera",
		["label"] = "\224\184\129\224\184\165\224\185\137\224\184\173\224\184\135",
		["keyCode"] = nil,
		["keyCode"] = Enum.KeyCode.Six
	}
}
local v785 = v_u_140("Frame", {
	["Name"] = "ToolBar",
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["BackgroundColor3"] = nil,
	["BackgroundTransparency"] = 0.05,
	["Visible"] = false,
	["Active"] = true,
	["AnchorPoint"] = Vector2.new(0.5, 1),
	["Position"] = UDim2.fromOffset(800, 700),
	["Size"] = UDim2.fromOffset(#v_u_784 * 64 + (#v_u_784 - 1) * 4 + 12, 64),
	["BackgroundColor3"] = v_u_21.panel
}, v43)
v_u_147(v785, 16)
local _ = v_u_140("UIScale", {}, v785)
v_u_140("UIPadding", {
	["PaddingLeft"] = UDim.new(0, 6),
	["PaddingRight"] = UDim.new(0, 6),
	["PaddingTop"] = UDim.new(0, 6),
	["PaddingBottom"] = UDim.new(0, 6)
}, v785)
v_u_140("UIListLayout", {
	["FillDirection"] = Enum.FillDirection.Horizontal,
	["Padding"] = UDim.new(0, 4),
	["SortOrder"] = Enum.SortOrder.LayoutOrder
}, v785)
local v_u_786 = {}
local v_u_787 = v785
local function v_u_794(p788) -- name: setTool
	-- upvalues: (ref) v_u_347, (copy) v_u_786, (copy) v_u_21, (copy) v_u_681
	v_u_347 = p788
	for v789, v790 in v_u_786 do
		local v791 = v789 == p788
		local v792 = v790.button
		local v793
		if v791 then
			v793 = v_u_21.picked
		else
			v793 = v_u_21.card
		end
		v792.BackgroundColor3 = v793
		v790.edge.Enabled = v791
	end
	v_u_681()
end
local function v851(p795, p796) -- name: toolIcon
	-- upvalues: (copy) v_u_2, (copy) v_u_21, (copy) v_u_39
	local v797 = {
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.new(0.5, 0, 0, 17),
		["Size"] = UDim2.fromOffset(22, 22)
	}
	local v798 = v_u_2.new("Frame")
	for v799, v800 in v797 do
		v798[v799] = v800
	end
	v798.Parent = p796
	local v801 = v_u_21.text
	if p795 == "select" then
		local v802 = {
			["BackgroundTransparency"] = 1,
			["Image"] = "rbxasset://textures/Cursors/KeyboardMouse/ArrowCursor.png",
			["ScaleType"] = nil,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["ScaleType"] = Enum.ScaleType.Fit,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.new(0.5, 4, 0.5, 4),
			["Size"] = UDim2.fromOffset(30, 30)
		}
		local v803 = v_u_2.new("ImageLabel")
		for v804, v805 in v802 do
			v803[v804] = v805
		end
		v803.Parent = v798
		return v798
	end
	if p795 == "move" then
		v_u_39(v798, 18, 2, 0, v801)
		v_u_39(v798, 18, 2, 90, v801)
		for _, v806 in {
			{ 45, 7.25, -1.75 },
			{ -45, 7.25, 1.75 },
			{ -45, -7.25, -1.75 },
			{ 45, -7.25, 1.75 },
			{ -45, -1.75, -7.25 },
			{ 45, 1.75, -7.25 },
			{ 45, -1.75, 7.25 },
			{ -45, 1.75, 7.25 }
		} do
			v_u_39(v798, 5, 2, v806[1], v801, v806[2], v806[3])
		end
		return v798
	end
	if p795 == "scale" then
		local v807 = {
			["BackgroundTransparency"] = 1,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.new(0.5, -3, 0.5, 3),
			["Size"] = UDim2.fromOffset(11, 11)
		}
		local v808 = v_u_2.new("Frame")
		for v809, v810 in v807 do
			v808[v809] = v810
		end
		v808.Parent = v798
		local v811 = {
			["Color"] = nil,
			["Thickness"] = 2,
			["ApplyStrokeMode"] = nil,
			["Color"] = v801,
			["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border
		}
		local v812 = v_u_2.new("UIStroke")
		for v813, v814 in v811 do
			v812[v813] = v814
		end
		v812.Parent = v808
		v_u_39(v798, 12, 2, -45, v801, 2.5, -2.5)
		v_u_39(v798, 6, 2, 0, v801, 6, -7)
		v_u_39(v798, 6, 2, 90, v801, 8, -5)
		return v798
	end
	if p795 == "depth" then
		v_u_39(v798, 20, 2, 0, v801, 0, 9)
		v_u_39(v798, 14, 2, 90, v801, 0, -1)
		v_u_39(v798, 5, 2, -45, v801, -1.75, -6.75)
		v_u_39(v798, 5, 2, 45, v801, 1.75, -6.75)
		v_u_39(v798, 5, 2, 45, v801, -1.75, 4.25)
		v_u_39(v798, 5, 2, -45, v801, 1.75, 4.25)
		return v798
	end
	if p795 ~= "camera" then
		if p795 ~= "tilt" then
			if p795 == "rotate" then
				local v815 = {
					["BackgroundTransparency"] = 1,
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["AnchorPoint"] = Vector2.new(0.5, 0.5),
					["Position"] = UDim2.fromScale(0.5, 0.5),
					["Size"] = UDim2.fromOffset(16, 16)
				}
				local v816 = v_u_2.new("Frame")
				for v817, v818 in v815 do
					v816[v817] = v818
				end
				v816.Parent = v798
				local v819 = {
					["CornerRadius"] = UDim.new(0, 8)
				}
				local v820 = v_u_2.new("UICorner")
				for v821, v822 in v819 do
					v820[v821] = v822
				end
				v820.Parent = v816
				local v823 = {
					["Color"] = nil,
					["Thickness"] = 2,
					["ApplyStrokeMode"] = nil,
					["Color"] = v801,
					["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border
				}
				local v824 = v_u_2.new("UIStroke")
				for v825, v826 in v823 do
					v824[v825] = v826
				end
				v824.Parent = v816
				v_u_39(v798, 5, 2, 45, v801, 2.2, -9.6)
				v_u_39(v798, 5, 2, -45, v801, 2.2, -6.4)
			end
			return v798
		end
		v_u_39(v798, 16, 2, 0, v801, 2, -6)
		v_u_39(v798, 16, 2, 0, v801, -2, 6)
		v_u_39(v798, 12.6, 2, 108.4, v801, -8, 0)
		v_u_39(v798, 12.6, 2, 108.4, v801, 8, 0)
		return v798
	end
	local v827 = {
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.new(0.5, 0, 0.5, 2),
		["Size"] = UDim2.fromOffset(20, 14)
	}
	local v828 = v_u_2.new("Frame")
	for v829, v830 in v827 do
		v828[v829] = v830
	end
	v828.Parent = v798
	local v831 = {
		["CornerRadius"] = UDim.new(0, 3)
	}
	local v832 = v_u_2.new("UICorner")
	for v833, v834 in v831 do
		v832[v833] = v834
	end
	v832.Parent = v828
	local v835 = {
		["Color"] = nil,
		["Thickness"] = 2,
		["ApplyStrokeMode"] = nil,
		["Color"] = v801,
		["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border
	}
	local v836 = v_u_2.new("UIStroke")
	for v837, v838 in v835 do
		v836[v837] = v838
	end
	v836.Parent = v828
	local v839 = {
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.5),
		["Size"] = UDim2.fromOffset(7, 7)
	}
	local v840 = v_u_2.new("Frame")
	for v841, v842 in v839 do
		v840[v841] = v842
	end
	v840.Parent = v828
	local v843 = {
		["CornerRadius"] = UDim.new(0, 4)
	}
	local v844 = v_u_2.new("UICorner")
	for v845, v846 in v843 do
		v844[v845] = v846
	end
	v844.Parent = v840
	local v847 = {
		["Color"] = nil,
		["Thickness"] = 2,
		["ApplyStrokeMode"] = nil,
		["Color"] = v801,
		["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border
	}
	local v848 = v_u_2.new("UIStroke")
	for v849, v850 in v847 do
		v848[v849] = v850
	end
	v848.Parent = v840
	v_u_39(v798, 6, 2, 0, v801, -4, -7)
	return v798
end
for v852, v_u_853 in v_u_784 do
	local v854 = v_u_140("TextButton", {
		["Name"] = nil,
		["Text"] = "",
		["AutoButtonColor"] = true,
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["LayoutOrder"] = nil,
		["Name"] = v_u_853.key,
		["BackgroundColor3"] = v_u_21.card,
		["Size"] = UDim2.fromOffset(64, 52),
		["LayoutOrder"] = v852
	}, v_u_787)
	v_u_147(v854, 9)
	local v855 = v_u_155(v854, v_u_21.accent, 1.5)
	v851(v_u_853.key, v854)
	v_u_56(v854, v_u_853.label, 11, v_u_21.text, v_u_23, {
		["Position"] = UDim2.fromOffset(0, 32),
		["Size"] = UDim2.new(1, 0, 0, 16),
		["TextXAlignment"] = Enum.TextXAlignment.Center
	})
	v854.Activated:Connect(function()
		-- upvalues: (copy) v_u_794, (copy) v_u_853
		v_u_794(v_u_853.key)
	end)
	v_u_786[v_u_853.key] = {
		["button"] = v854,
		["edge"] = v855
	}
end
local v_u_856 = v_u_140("Frame", {
	["Name"] = "StickerGizmo",
	["BackgroundTransparency"] = 1,
	["Size"] = nil,
	["Visible"] = false,
	["Size"] = UDim2.fromScale(1, 1)
}, v43)
local function v875(p857, p858, p859, p860) -- name: knob
	-- upvalues: (copy) v_u_856, (copy) v_u_2
	local v861 = {
		["Name"] = nil,
		["Text"] = "",
		["AutoButtonColor"] = false,
		["AnchorPoint"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["ZIndex"] = 6,
		["Visible"] = false,
		["Name"] = p857,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Size"] = UDim2.fromOffset(p859, p859),
		["BackgroundColor3"] = p858
	}
	local v862 = v_u_856
	local v863 = v_u_2.new("TextButton")
	for v864, v865 in v861 do
		v863[v864] = v865
	end
	v863.Parent = v862
	local v866 = not p860 and 4 or p859 / 2
	local v867 = {
		["CornerRadius"] = UDim.new(0, v866)
	}
	local v868 = v_u_2.new("UICorner")
	for v869, v870 in v867 do
		v868[v869] = v870
	end
	v868.Parent = v863
	local v871 = {
		["Color"] = nil,
		["Thickness"] = 2,
		["ApplyStrokeMode"] = nil,
		["Color"] = Color3.new(1, 1, 1),
		["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border
	}
	local v872 = v_u_2.new("UIStroke")
	for v873, v874 in v871 do
		v872[v873] = v874
	end
	v872.Parent = v863
	return v863
end
local v_u_876 = {}
local v_u_877 = {}
for v878 = 1, 4 do
	local v879 = v875("Move" .. v878, v_u_21.accent, 28, true)
	local v880 = v_u_80(v879, "right", Color3.fromRGB(10, 20, 28))
	v880.ZIndex = 7
	for _, v881 in v880:GetDescendants() do
		if not v881:IsA("GuiObject") then
			continue
		end
		v881.ZIndex = 7
	end
	v_u_876[v878] = {
		["button"] = v879,
		["icon"] = v880
	}
	v_u_877[v878] = v875("Scale" .. v878, Color3.fromRGB(110, 220, 140), 16, false)
end
local v_u_882 = v875("Rotate", v_u_21.warn, 26, true)
local v883 = v_u_140("Frame", {
	["BackgroundTransparency"] = 1,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["ZIndex"] = 7,
	["AnchorPoint"] = Vector2.new(0.5, 0.5),
	["Position"] = UDim2.fromScale(0.5, 0.5),
	["Size"] = UDim2.fromOffset(12, 12)
}, v_u_882)
v_u_147(v883, 6)
v_u_155(v883, Color3.fromRGB(40, 30, 10), 2)
local v_u_884 = v_u_140("Frame", {
	["BackgroundColor3"] = nil,
	["BorderSizePixel"] = 0,
	["AnchorPoint"] = nil,
	["Size"] = nil,
	["ZIndex"] = 5,
	["Visible"] = false,
	["BackgroundColor3"] = v_u_21.warn,
	["AnchorPoint"] = Vector2.new(0.5, 0.5),
	["Size"] = UDim2.fromOffset(2, 2)
}, v_u_856)
local v_u_885 = v875("Depth", v_u_21.pink, 30, true)
v_u_885.Size = UDim2.fromOffset(30, 48)
v_u_147(v_u_885, 15)
for _, v886 in {
	{ "up", 14 },
	{ "down", 34 }
} do
	local v887 = v_u_80(v_u_885, v886[1], Color3.fromRGB(40, 10, 28))
	v887.Position = UDim2.new(0.5, 0, 0, v886[2])
	for _, v888 in v887:GetDescendants() do
		if not v888:IsA("GuiObject") then
			continue
		end
		v888.ZIndex = 7
	end
end
local v_u_889 = v_u_56(v_u_885, "\224\184\148\224\184\182\224\184\135\224\184\173\224\184\173\224\184\129 0.00", 12, v_u_21.text, v_u_22, {
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["BackgroundTransparency"] = 0.2,
	["BackgroundColor3"] = nil,
	["TextXAlignment"] = nil,
	["ZIndex"] = 7,
	["AnchorPoint"] = Vector2.new(0, 0.5),
	["Position"] = UDim2.new(1, 8, 0.5, 0),
	["Size"] = UDim2.fromOffset(86, 22),
	["BackgroundColor3"] = v_u_21.panel,
	["TextXAlignment"] = Enum.TextXAlignment.Center
})
v_u_147(v_u_889, 6)
local v_u_890 = v875("DepthPlus", v_u_21.pink, 26, true)
local v_u_891 = v875("DepthMinus", v_u_21.pink, 26, true)
for _, v892 in {
	{ v_u_890, "plus" },
	{ v_u_891, "minus" }
} do
	for _, v893 in v_u_80(v892[1], v892[2], Color3.fromRGB(40, 10, 28)):GetDescendants() do
		if not v893:IsA("GuiObject") then
			continue
		end
		v893.ZIndex = 7
	end
end
local v_u_894 = Color3.fromRGB(90, 180, 255)
local v_u_895 = v875("Tilt", v_u_894, 34, true)
v_u_147(v_u_140("Frame", {
	["BackgroundColor3"] = nil,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["BorderSizePixel"] = 0,
	["ZIndex"] = 7,
	["BackgroundColor3"] = Color3.fromRGB(10, 30, 50),
	["AnchorPoint"] = Vector2.new(0.5, 0.5),
	["Position"] = UDim2.fromScale(0.5, 0.5),
	["Size"] = UDim2.fromOffset(8, 8)
}, v_u_895), 4)
local v_u_896 = {}
for _, v897 in {
	{
		"left",
		-1,
		0,
		-44,
		0
	},
	{
		"right",
		1,
		0,
		44,
		0
	},
	{
		"up",
		0,
		1,
		0,
		-44
	},
	{
		"down",
		0,
		-1,
		0,
		44
	}
} do
	local v898 = v875("Tilt" .. v897[1], v_u_894, 26, true)
	for _, v899 in v_u_80(v898, v897[1], Color3.fromRGB(10, 30, 50)):GetDescendants() do
		if not v899:IsA("GuiObject") then
			continue
		end
		v899.ZIndex = 7
	end
	v_u_896[v897[1]] = {
		["button"] = v898,
		["da"] = v897[2],
		["db"] = v897[3],
		["off"] = Vector2.new(v897[4], v897[5])
	}
end
local v_u_900 = v_u_56(v_u_856, "", 12, v_u_21.text, v_u_22, {
	["AnchorPoint"] = nil,
	["Size"] = nil,
	["BackgroundTransparency"] = 0.2,
	["BackgroundColor3"] = nil,
	["TextXAlignment"] = nil,
	["ZIndex"] = 7,
	["Visible"] = false,
	["AnchorPoint"] = Vector2.new(0.5, 0),
	["Size"] = UDim2.fromOffset(170, 22),
	["BackgroundColor3"] = v_u_21.panel,
	["TextXAlignment"] = Enum.TextXAlignment.Center
})
v_u_147(v_u_900, 6)
local v_u_901 = v_u_140("TextButton", {
	["Name"] = "TiltReset",
	["Text"] = "0",
	["Font"] = nil,
	["TextSize"] = 13,
	["TextColor3"] = nil,
	["AutoButtonColor"] = true,
	["AnchorPoint"] = nil,
	["Size"] = nil,
	["BackgroundColor3"] = nil,
	["BorderSizePixel"] = 0,
	["ZIndex"] = 6,
	["Visible"] = false,
	["Font"] = v_u_22,
	["TextColor3"] = Color3.fromRGB(10, 30, 50),
	["AnchorPoint"] = Vector2.new(0.5, 0.5),
	["Size"] = UDim2.fromOffset(26, 26),
	["BackgroundColor3"] = Color3.fromRGB(230, 236, 245)
}, v_u_856)
v_u_147(v_u_901, 13)
local function v_u_920(p902, p903, p904, p905) -- name: slide
	-- upvalues: (ref) v_u_343, (copy) v_u_11, (copy) v_u_383, (copy) v_u_399
	local v906 = RaycastParams.new()
	v906.FilterType = Enum.RaycastFilterType.Include
	v906.FilterDescendantsInstances = v_u_343.include
	local v907 = math.abs(p904)
	local v908 = p904 < 0 and -1 or 1
	local v909 = p902
	local v910 = false
	while true do
		local v911 = v907 > 0.001 and v_u_343.panels[p902.p]
		if not v911 then
			break
		end
		local v912 = v_u_11.frame(p902, v911)
		local v913 = v912.LookVector
		local v914 = p903 - v913 * p903:Dot(v913)
		if v914.Magnitude < 0.001 then
			break
		end
		local v915 = math.min(0.2, v907)
		local v916 = v912.Position + v914.Unit * v915 * v908
		local v917 = workspace:Raycast(v916 + v913 * 0.6, -v913 * 1.4, v906)
		if not v917 or (v917.Normal:Dot(v913) < 0.2 or not v_u_343.panels[v917.Instance:GetAttribute("Panel") or ""]) then
			break
		end
		p902 = v_u_11.fromHit(p902.s, v917.Instance, v917.Position, v917.Normal, v_u_383(v917.Normal), p902.w, p902.c)
		v907 = v907 - v915
		v910 = true
	end
	if not v910 then
		return nil
	end
	p902.d = v909.d
	local v918 = v909.a
	local v919 = v909.b
	p902.a = v918
	p902.b = v919
	v_u_11.settle(p902, v_u_343.panels, v_u_343.include)
	v_u_399(p902, p905)
	return p902
end
local v_u_921 = nil
local function v_u_951(p922, p923) -- name: beginKnob
	-- upvalues: (ref) v_u_921, (copy) v_u_703, (copy) v_u_377, (ref) v_u_352, (ref) v_u_343, (copy) v_u_11, (copy) v_u_9, (copy) v_u_393, (copy) v_u_7
	if v_u_921 or not v_u_703() then
		return
	else
		local v924 = v_u_377(v_u_352.entry)
		local v925 = v_u_343.panels[v924.p]
		if v925 then
			local v926, v927, v928 = v_u_11.frame(v924, v925)
			if v924.d and v924.d ~= 0 then
				v926 = v926 + v926.LookVector * v924.d
			end
			local v929 = v_u_11.tiltFrame(v926, v927, v928, v924)
			local v930 = v929.Position
			local v931 = workspace.CurrentCamera:WorldToViewportPoint(v930)
			local v932 = Vector2.new(v931.X, v931.Y) - v_u_9:GetGuiInset()
			local _ = v931.Z > 0
			local v933 = {
				["kind"] = nil,
				["e0"] = nil,
				["rot"] = nil,
				["from"] = nil,
				["c"] = nil,
				["at"] = 0,
				["kind"] = p922,
				["e0"] = v924,
				["rot"] = v_u_393(v924)
			}
			local v934 = v_u_7:GetMouseLocation()
			v933.from = Vector2.new(v934.X, v934.Y) - v_u_9:GetGuiInset()
			v933.c = v932
			if p922 == "move" then
				v933.axis = ({
					-v929.RightVector,
					v929.UpVector,
					v929.RightVector,
					-v929.UpVector
				})[p923]
				local v935 = v929.Position + v933.axis
				local v936 = workspace.CurrentCamera:WorldToViewportPoint(v935)
				local v937 = Vector2.new(v936.X, v936.Y) - v_u_9:GetGuiInset()
				local _ = v936.Z > 0
				local v938 = v937 - v932
				local v939
				if v938.Magnitude > 0.001 then
					v939 = v938.Unit
				else
					v939 = Vector2.xAxis
				end
				v933.sdir = v939
				local v940 = v938.Magnitude
				v933.pps = math.max(v940, 1)
			elseif p922 == "tilt" then
				v933.pps = 3
			elseif p922 == "depth" then
				v933.pps = 80
			elseif p922 == "scale" then
				local v941 = {
					-v929.RightVector,
					v929.UpVector,
					v929.RightVector,
					-v929.UpVector
				}
				local v942 = v929.Position + v941[(p923 == 1 or p923 == 4) and 1 or 3] * (v927 / 2) + v941[p923 <= 2 and 2 or 4] * (v928 / 2)
				local v943 = workspace.CurrentCamera:WorldToViewportPoint(v942)
				local v944 = Vector2.new(v943.X, v943.Y) - v_u_9:GetGuiInset()
				local _ = v943.Z > 0
				local v945 = v944 - v932
				local v946
				if v945.Magnitude > 0.001 then
					v946 = v945.Unit
				else
					v946 = Vector2.xAxis
				end
				v933.sdir = v946
				local v947 = v945.Magnitude
				v933.half = math.max(v947, 4)
			else
				local v948 = v933.from
				local v949 = v948.Y - v932.Y
				local v950 = v948.X - v932.X
				v933.a0 = math.atan2(v949, v950)
			end
			v_u_921 = v933
		end
	end
end
local function v_u_977(p952) -- name: updateKnobDrag
	-- upvalues: (ref) v_u_921, (ref) v_u_352, (copy) v_u_7, (copy) v_u_9, (copy) v_u_920, (copy) v_u_377, (copy) v_u_11, (copy) v_u_12, (ref) v_u_343, (copy) v_u_399, (copy) v_u_460, (copy) v_u_681
	local v953 = v_u_921
	if v953 and v_u_352 then
		if p952 or os.clock() - v953.at >= 0.04 then
			v953.at = os.clock()
			local v954 = v_u_7:GetMouseLocation()
			local v955 = Vector2.new(v954.X, v954.Y) - v_u_9:GetGuiInset()
			local v956
			if v953.kind == "move" then
				local v957 = (v955 - v953.from):Dot(v953.sdir) / v953.pps
				if math.abs(v957) > 0.001 then
					v956 = v_u_920(v953.e0, v953.axis, v957, v953.rot)
				else
					v956 = v_u_377(v953.e0)
				end
			elseif v953.kind == "depth" then
				v956 = v_u_377(v953.e0)
				v956.d = v_u_11.out((v953.e0.d or 0) + (v953.from.Y - v955.Y) / v953.pps)
			elseif v953.kind == "tilt" then
				v956 = v_u_377(v953.e0)
				local v958 = v_u_11.tilt
				local v959 = (v953.e0.a or 0) + (v955.X - v953.from.X) / v953.pps
				v956.a = v958((math.round(v959)))
				local v960 = v_u_11.tilt
				local v961 = (v953.e0.b or 0) + (v953.from.Y - v955.Y) / v953.pps
				v956.b = v960((math.round(v961)))
			elseif v953.kind == "scale" then
				local v962 = (v955 - v953.from):Dot(v953.sdir)
				v956 = v_u_377(v953.e0)
				local v963 = v953.e0.w * (v953.half + v962) / v953.half
				local v964 = v_u_11.MIN_W
				local v965 = v953.e0.s
				local v966 = v_u_12.get(v965)
				local v967 = v_u_11.MAX_W
				local v968 = v966 and v966.maxSize or v_u_11.MAX_W
				local v969 = math.min(v967, v968)
				v956.w = math.clamp(v963, v964, v969)
				v_u_11.settle(v956, v_u_343.panels, v_u_343.include)
				v_u_399(v956, v953.rot)
			else
				local v970 = v955.Y - v953.c.Y
				local v971 = v955.X - v953.c.X
				local v972 = math.atan2(v970, v971)
				local v973 = v953.rot
				local v974 = v972 - v953.a0
				local v975 = (v973 + math.deg(v974)) / 5 + 0.5
				local v976 = (math.floor(v975) * 5 + 180) % 360 - 180
				v956 = v_u_377(v953.e0)
				v_u_399(v956, v976)
			end
			if v956 then
				v_u_352.entry = v956
				if v_u_352 then
					v_u_460(v_u_352.entry, v_u_352.index, v_u_352.index)
				end
				v_u_681()
			end
		end
	else
		return
	end
end
local v_u_978 = v_u_921
local function v984(p979, p_u_980, p_u_981) -- name: hookKnob
	-- upvalues: (copy) v_u_951
	p979.InputBegan:Connect(function(p982)
		-- upvalues: (ref) v_u_951, (copy) p_u_980, (copy) p_u_981
		local v983 = p982.UserInputType
		if v983 == Enum.UserInputType.MouseButton1 or v983 == Enum.UserInputType.Touch then
			v_u_951(p_u_980, p_u_981)
		end
	end)
end
for v985 = 1, 4 do
	v984(v_u_876[v985].button, "move", v985)
	v984(v_u_877[v985], "scale", v985)
end
v984(v_u_882, "rotate", 0)
v984(v_u_885, "depth", 0)
v984(v_u_895, "tilt", 0)
for _, v_u_986 in v_u_896 do
	v_u_986.button.Activated:Connect(function()
		-- upvalues: (copy) v_u_986, (ref) v_u_349, (ref) v_u_351, (ref) v_u_352, (ref) v_u_343, (copy) v_u_703, (copy) v_u_11, (copy) v_u_423, (copy) v_u_13, (copy) v_u_375, (ref) v_u_346, (copy) v_u_373, (copy) v_u_19, (copy) v_u_341, (copy) v_u_359, (ref) v_u_357, (ref) v_u_358, (ref) v_u_770, (ref) v_u_771, (copy) v_u_681
		local v987 = v_u_986.da * 5
		local v988 = v_u_986.db * 5
		if not v_u_349 and (v_u_351 and not v_u_352) then
			if not v_u_343 then
				return
			end
			if v_u_703() then
				local v989 = v_u_352.entry
				v989.a = v_u_11.tilt((v989.a or 0) + v987)
				v989.b = v_u_11.tilt((v989.b or 0) + v988)
				if v_u_352 then
					local v990 = v_u_352
					v_u_352 = nil
					local v991 = v990.index
					local v992 = v990.entry
					local v993, v994 = v_u_423(v992, v991)
					if v993 then
						local v995 = v_u_375(v992)
						local v996, v997
						if v_u_346 then
							v996 = false
							v997 = nil
						else
							v_u_346 = true
							v996, v997 = v_u_373(v_u_19, "edit", v991, v995)
							v_u_346 = false
							if not v996 and v997 then
								v_u_13.show(v997, "error")
							end
						end
						if v996 then
							v_u_351 = v997
						end
					else
						v_u_13.show(v994, "error")
					end
					v_u_341:ClearAllChildren()
					table.clear(v_u_359)
					v_u_357 = nil
					v_u_358 = nil
					local v998 = v_u_343
					if v998 then
						v998 = v_u_343.model:FindFirstChild("StickerVisuals")
					end
					if v_u_770 and (v998 and v998:FindFirstChild("S" .. v_u_770)) then
						for _, v999 in v998["S" .. v_u_770]:GetDescendants() do
							if not v999:IsA("Texture") then
								continue
							end
							v999.Transparency = 0
						end
					end
					v_u_770 = nil
					v_u_771 = nil
					v_u_681()
				end
			end
		end
	end)
end
v_u_901.Activated:Connect(function()
	-- upvalues: (ref) v_u_349, (ref) v_u_351, (ref) v_u_352, (ref) v_u_343, (copy) v_u_703, (copy) v_u_423, (copy) v_u_13, (copy) v_u_375, (ref) v_u_346, (copy) v_u_373, (copy) v_u_19, (copy) v_u_341, (copy) v_u_359, (ref) v_u_357, (ref) v_u_358, (ref) v_u_770, (ref) v_u_771, (copy) v_u_681
	if not v_u_349 and (v_u_351 and not v_u_352) then
		if not v_u_343 then
			return
		end
		if v_u_703() then
			local v1000 = v_u_352.entry
			v1000.a = nil
			v1000.b = nil
			if v_u_352 then
				local v1001 = v_u_352
				v_u_352 = nil
				local v1002 = v1001.index
				local v1003 = v1001.entry
				local v1004, v1005 = v_u_423(v1003, v1002)
				if v1004 then
					local v1006 = v_u_375(v1003)
					local v1007, v1008
					if v_u_346 then
						v1007 = false
						v1008 = nil
					else
						v_u_346 = true
						v1007, v1008 = v_u_373(v_u_19, "edit", v1002, v1006)
						v_u_346 = false
						if not v1007 and v1008 then
							v_u_13.show(v1008, "error")
						end
					end
					if v1007 then
						v_u_351 = v1008
					end
				else
					v_u_13.show(v1005, "error")
				end
				v_u_341:ClearAllChildren()
				table.clear(v_u_359)
				v_u_357 = nil
				v_u_358 = nil
				local v1009 = v_u_343
				if v1009 then
					v1009 = v_u_343.model:FindFirstChild("StickerVisuals")
				end
				if v_u_770 and (v1009 and v1009:FindFirstChild("S" .. v_u_770)) then
					for _, v1010 in v1009["S" .. v_u_770]:GetDescendants() do
						if not v1010:IsA("Texture") then
							continue
						end
						v1010.Transparency = 0
					end
				end
				v_u_770 = nil
				v_u_771 = nil
				v_u_681()
			end
		end
	end
end)
local v_u_1011 = nil
local function v1022() -- name: stopDepthHold
	-- upvalues: (ref) v_u_1011, (ref) v_u_352, (copy) v_u_423, (copy) v_u_13, (copy) v_u_375, (ref) v_u_346, (copy) v_u_373, (copy) v_u_19, (ref) v_u_351, (copy) v_u_341, (copy) v_u_359, (ref) v_u_357, (ref) v_u_358, (ref) v_u_343, (ref) v_u_770, (ref) v_u_771, (copy) v_u_681
	if v_u_1011 then
		v_u_1011 = nil
		if v_u_352 then
			local v1012 = v_u_352
			v_u_352 = nil
			local v1013 = v1012.index
			local v1014 = v1012.entry
			local v1015, v1016 = v_u_423(v1014, v1013)
			if v1015 then
				local v1017 = v_u_375(v1014)
				local v1018, v1019
				if v_u_346 then
					v1018 = false
					v1019 = nil
				else
					v_u_346 = true
					v1018, v1019 = v_u_373(v_u_19, "edit", v1013, v1017)
					v_u_346 = false
					if not v1018 and v1019 then
						v_u_13.show(v1019, "error")
					end
				end
				if v1018 then
					v_u_351 = v1019
				end
			else
				v_u_13.show(v1016, "error")
			end
			v_u_341:ClearAllChildren()
			table.clear(v_u_359)
			v_u_357 = nil
			v_u_358 = nil
			local v1020 = v_u_343
			if v1020 then
				v1020 = v_u_343.model:FindFirstChild("StickerVisuals")
			end
			if v_u_770 and (v1020 and v1020:FindFirstChild("S" .. v_u_770)) then
				for _, v1021 in v1020["S" .. v_u_770]:GetDescendants() do
					if not v1021:IsA("Texture") then
						continue
					end
					v1021.Transparency = 0
				end
			end
			v_u_770 = nil
			v_u_771 = nil
			v_u_681()
		end
	end
end
local v_u_1023 = v_u_1011
for _, v1024 in {
	{ v_u_890, 1 },
	{ v_u_891, -1 }
} do
	local v1025 = v1024[1]
	local v_u_1026 = v1024[2]
	v1025.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_978, (ref) v_u_1023, (ref) v_u_352, (copy) v_u_1026, (ref) v_u_349, (ref) v_u_351, (ref) v_u_343, (copy) v_u_703, (copy) v_u_11, (copy) v_u_460, (copy) v_u_681
		if v_u_978 or (v_u_1023 or v_u_352) then
			return
		else
			local v1027 = {}
			v_u_1023 = v1027
			local v1028 = v_u_1026 * 0.05
			local v1029
			if v_u_349 or not (v_u_351 and (v_u_343 and v_u_703())) then
				v1029 = false
			else
				v_u_352.entry.d = v_u_11.out((v_u_352.entry.d or 0) + v1028)
				if v_u_352 then
					v_u_460(v_u_352.entry, v_u_352.index, v_u_352.index)
				end
				v_u_681()
				v1029 = true
			end
			if v1029 then
				task.wait(0.3)
				local v1030 = 0.05
				while v_u_1023 == v1027 and v_u_343 do
					local v1031 = v_u_1026 * v1030
					if not v_u_349 and (v_u_351 and (v_u_343 and v_u_703())) then
						v_u_352.entry.d = v_u_11.out((v_u_352.entry.d or 0) + v1031)
						if v_u_352 then
							v_u_460(v_u_352.entry, v_u_352.index, v_u_352.index)
						end
						v_u_681()
					end
					local v1032 = v1030 * 1.05
					v1030 = math.min(v1032, 0.12)
					task.wait(0.08)
				end
			else
				v_u_1023 = nil
			end
		end
	end)
	v1025.MouseButton1Up:Connect(v1022)
	v1025.MouseLeave:Connect(v1022)
end
v_u_7.InputEnded:Connect(function(p1033)
	-- upvalues: (ref) v_u_1023, (ref) v_u_352, (copy) v_u_423, (copy) v_u_13, (copy) v_u_375, (ref) v_u_346, (copy) v_u_373, (copy) v_u_19, (ref) v_u_351, (copy) v_u_341, (copy) v_u_359, (ref) v_u_357, (ref) v_u_358, (ref) v_u_343, (ref) v_u_770, (ref) v_u_771, (copy) v_u_681
	if (p1033.UserInputType == Enum.UserInputType.MouseButton1 or p1033.UserInputType == Enum.UserInputType.Touch) and v_u_1023 then
		v_u_1023 = nil
		if v_u_352 then
			local v1034 = v_u_352
			v_u_352 = nil
			local v1035 = v1034.index
			local v1036 = v1034.entry
			local v1037, v1038 = v_u_423(v1036, v1035)
			if v1037 then
				local v1039 = v_u_375(v1036)
				local v1040, v1041
				if v_u_346 then
					v1040 = false
					v1041 = nil
				else
					v_u_346 = true
					v1040, v1041 = v_u_373(v_u_19, "edit", v1035, v1039)
					v_u_346 = false
					if not v1040 and v1041 then
						v_u_13.show(v1041, "error")
					end
				end
				if v1040 then
					v_u_351 = v1041
				end
			else
				v_u_13.show(v1038, "error")
			end
			v_u_341:ClearAllChildren()
			table.clear(v_u_359)
			v_u_357 = nil
			v_u_358 = nil
			local v1042 = v_u_343
			if v1042 then
				v1042 = v_u_343.model:FindFirstChild("StickerVisuals")
			end
			if v_u_770 and (v1042 and v1042:FindFirstChild("S" .. v_u_770)) then
				for _, v1043 in v1042["S" .. v_u_770]:GetDescendants() do
					if not v1043:IsA("Texture") then
						continue
					end
					v1043.Transparency = 0
				end
			end
			v_u_770 = nil
			v_u_771 = nil
			v_u_681()
		end
	end
end)
local function v_u_1060(p1044, p1045, p1046) -- name: nudge
	-- upvalues: (ref) v_u_349, (ref) v_u_351, (ref) v_u_352, (ref) v_u_343, (copy) v_u_703, (copy) v_u_920, (copy) v_u_393, (copy) v_u_423, (copy) v_u_13, (copy) v_u_375, (ref) v_u_346, (copy) v_u_373, (copy) v_u_19, (copy) v_u_341, (copy) v_u_359, (ref) v_u_357, (ref) v_u_358, (ref) v_u_770, (ref) v_u_771, (copy) v_u_681
	if not v_u_349 and (v_u_351 and (not v_u_352 and v_u_343)) then
		local v1047 = workspace.CurrentCamera.CFrame
		local v1048 = v1047.RightVector * p1044 + v1047.UpVector * p1045
		if v_u_703() then
			local v1049 = v_u_920(v_u_352.entry, v1048.Unit, p1046, (v_u_393(v_u_352.entry)))
			if v1049 then
				v_u_352.entry = v1049
			end
			if v_u_352 then
				local v1050 = v_u_352
				v_u_352 = nil
				local v1051 = v1050.index
				local v1052 = v1050.entry
				local v1053, v1054 = v_u_423(v1052, v1051)
				if v1053 then
					local v1055 = v_u_375(v1052)
					local v1056, v1057
					if v_u_346 then
						v1056 = false
						v1057 = nil
					else
						v_u_346 = true
						v1056, v1057 = v_u_373(v_u_19, "edit", v1051, v1055)
						v_u_346 = false
						if not v1056 and v1057 then
							v_u_13.show(v1057, "error")
						end
					end
					if v1056 then
						v_u_351 = v1057
					end
				else
					v_u_13.show(v1054, "error")
				end
				v_u_341:ClearAllChildren()
				table.clear(v_u_359)
				v_u_357 = nil
				v_u_358 = nil
				local v1058 = v_u_343
				if v1058 then
					v1058 = v_u_343.model:FindFirstChild("StickerVisuals")
				end
				if v_u_770 and (v1058 and v1058:FindFirstChild("S" .. v_u_770)) then
					for _, v1059 in v1058["S" .. v_u_770]:GetDescendants() do
						if not v1059:IsA("Texture") then
							continue
						end
						v1059.Transparency = 0
					end
				end
				v_u_770 = nil
				v_u_771 = nil
				v_u_681()
			end
		end
	end
end
v6.RenderStepped:Connect(function()
	-- upvalues: (ref) v_u_343, (ref) v_u_349, (ref) v_u_787, (ref) v_u_351, (ref) v_u_348, (ref) v_u_347, (ref) v_u_352, (copy) v_u_11, (copy) v_u_9, (copy) v_u_856, (copy) v_u_876, (copy) v_u_877, (copy) v_u_882, (copy) v_u_884, (copy) v_u_885, (copy) v_u_890, (copy) v_u_891, (copy) v_u_889, (copy) v_u_21, (copy) v_u_895, (copy) v_u_900, (copy) v_u_901, (copy) v_u_896, (copy) v_u_894
	local v1061
	if v_u_343 == nil then
		v1061 = false
	else
		v1061 = not v_u_349
	end
	v_u_787.Visible = v1061
	local v1062
	if v1061 and (v_u_351 and (not v_u_348 and (v_u_347 ~= "select" and v_u_347 ~= "camera"))) then
		if v_u_352 then
			v1062 = v_u_352.entry
		else
			v1062 = (not v_u_343 and {} or v_u_11.read(v_u_343.model))[v_u_351]
		end
	else
		v1062 = nil
	end
	local v1063
	if v1062 then
		v1063 = v_u_343.panels[v1062.p]
	else
		v1063 = v1062
	end
	local v1064, v1065, v1066
	if v1063 then
		local v1067
		v1067, v1064, v1065 = v_u_11.frame(v1062, v1063)
		if v1062.d and v1062.d ~= 0 then
			v1067 = v1067 + v1067.LookVector * v1062.d
		end
		v1066 = v_u_11.tiltFrame(v1067, v1064, v1065, v1062)
	else
		v1066 = nil
		v1064 = nil
		v1065 = nil
	end
	local v1068, v1069
	if v1066 then
		local v1070 = v1066.Position
		local v1071 = workspace.CurrentCamera:WorldToViewportPoint(v1070)
		v1068 = Vector2.new(v1071.X, v1071.Y) - v_u_9:GetGuiInset()
		v1069 = v1071.Z > 0
	else
		v1069 = false
		v1068 = nil
	end
	if v1066 and v1069 then
		v_u_856.Visible = true
		local v1072 = {
			-v1066.RightVector,
			v1066.UpVector,
			v1066.RightVector,
			-v1066.UpVector
		}
		local v1073 = {
			v1064 / 2,
			v1065 / 2,
			v1064 / 2,
			v1065 / 2
		}
		for v1074 = 1, 4 do
			local v1075 = v1066.Position + v1072[v1074] * v1073[v1074]
			local v1076 = workspace.CurrentCamera:WorldToViewportPoint(v1075)
			local v1077 = Vector2.new(v1076.X, v1076.Y) - v_u_9:GetGuiInset()
			local _ = v1076.Z > 0
			local v1078 = v1077 - v1068
			local v1079
			if v1078.Magnitude > 0.001 then
				v1079 = v1078.Unit
			else
				local v1080 = Vector2.new
				local v1081 = v1074 * 3.141592653589793 / 2
				local v1082 = math.cos(v1081)
				local v1083 = v1074 * 3.141592653589793 / 2
				v1079 = v1080(v1082, (math.sin(v1083)))
			end
			local v1084 = v_u_876[v1074]
			v1084.button.Visible = v_u_347 == "move"
			local v1085 = v1084.button
			local v1086 = v1077 + v1079 * 26
			local v1087 = UDim2.fromOffset
			local v1088 = v1086.X + 0.5
			local v1089 = math.floor(v1088)
			local v1090 = v1086.Y + 0.5
			v1085.Position = v1087(v1089, (math.floor(v1090)))
			local v1091 = v1084.icon
			local v1092 = v1079.Y
			local v1093 = v1079.X
			local v1094 = math.atan2(v1092, v1093)
			v1091.Rotation = math.deg(v1094)
			local v1095 = v1066.Position + v1072[(v1074 == 1 or v1074 == 4) and 1 or 3] * (v1064 / 2) + v1072[v1074 <= 2 and 2 or 4] * (v1065 / 2)
			local v1096 = workspace.CurrentCamera:WorldToViewportPoint(v1095)
			local v1097 = Vector2.new(v1096.X, v1096.Y) - v_u_9:GetGuiInset()
			local _ = v1096.Z > 0
			v_u_877[v1074].Visible = v_u_347 == "scale"
			local v1098 = v_u_877[v1074]
			local v1099 = UDim2.fromOffset
			local v1100 = v1097.X + 0.5
			local v1101 = math.floor(v1100)
			local v1102 = v1097.Y + 0.5
			v1098.Position = v1099(v1101, (math.floor(v1102)))
		end
		local v1103 = v1066.Position + v1072[2] * (v1065 / 2)
		local v1104 = workspace.CurrentCamera:WorldToViewportPoint(v1103)
		local v1105 = Vector2.new(v1104.X, v1104.Y) - v_u_9:GetGuiInset()
		local _ = v1104.Z > 0
		local v1106 = v1105 - v1068
		local v1107
		if v1106.Magnitude > 0.001 then
			v1107 = v1106.Unit
		else
			v1107 = Vector2.new(0, -1)
		end
		local v1108 = v1105 + v1107 * 38
		v_u_882.Visible = v_u_347 == "rotate"
		local v1109 = v_u_882
		local v1110 = UDim2.fromOffset
		local v1111 = v1108.X + 0.5
		local v1112 = math.floor(v1111)
		local v1113 = v1108.Y + 0.5
		v1109.Position = v1110(v1112, (math.floor(v1113)))
		v_u_884.Visible = v_u_347 == "rotate"
		local v1114 = v_u_884
		local v1115 = (v1105 + v1108) / 2
		local v1116 = UDim2.fromOffset
		local v1117 = v1115.X + 0.5
		local v1118 = math.floor(v1117)
		local v1119 = v1115.Y + 0.5
		v1114.Position = v1116(v1118, (math.floor(v1119)))
		v_u_884.Size = UDim2.fromOffset(2, 38)
		local v1120 = v_u_884
		local v1121 = v1107.Y
		local v1122 = v1107.X
		local v1123 = math.atan2(v1121, v1122)
		v1120.Rotation = math.deg(v1123) + 90
		local v1124 = v_u_347 == "depth"
		local v1125 = v_u_890
		local v1126 = v_u_891
		v_u_885.Visible = v1124
		v1125.Visible = v1124
		v1126.Visible = v1124
		if v1124 then
			local v1127 = v1068.X
			local v1128 = v1068.X
			for v1129 = 1, 4 do
				local v1130 = v1066.Position + v1072[(v1129 == 1 or v1129 == 4) and 1 or 3] * (v1064 / 2) + v1072[v1129 <= 2 and 2 or 4] * (v1065 / 2)
				local v1131 = workspace.CurrentCamera:WorldToViewportPoint(v1130)
				local v1132 = Vector2.new(v1131.X, v1131.Y) - v_u_9:GetGuiInset()
				local _ = v1131.Z > 0
				local v1133 = v1132.X
				v1127 = math.min(v1127, v1133)
				local v1134 = v1132.X
				v1128 = math.max(v1128, v1134)
			end
			local v1135 = workspace.CurrentCamera.ViewportSize
			local v1136 = v1128 + 40
			local v1137
			if v1136 + 140 > v1135.X then
				v1136 = v1127 - 40
				v1137 = false
			else
				v1137 = true
			end
			local v1138 = Vector2.new(v1136, v1068.Y)
			local v1139 = v_u_885
			local v1140 = UDim2.fromOffset
			local v1141 = v1138.X + 0.5
			local v1142 = math.floor(v1141)
			local v1143 = v1138.Y + 0.5
			v1139.Position = v1140(v1142, (math.floor(v1143)))
			local v1144 = v_u_890
			local v1145 = v1138 + Vector2.new(0, -46)
			local v1146 = UDim2.fromOffset
			local v1147 = v1145.X + 0.5
			local v1148 = math.floor(v1147)
			local v1149 = v1145.Y + 0.5
			v1144.Position = v1146(v1148, (math.floor(v1149)))
			local v1150 = v_u_891
			local v1151 = v1138 + Vector2.new(0, 46)
			local v1152 = UDim2.fromOffset
			local v1153 = v1151.X + 0.5
			local v1154 = math.floor(v1153)
			local v1155 = v1151.Y + 0.5
			v1150.Position = v1152(v1154, (math.floor(v1155)))
			local v1156 = v_u_889
			local v1157
			if v1137 then
				v1157 = Vector2.new(0, 0.5)
			else
				v1157 = Vector2.new(1, 0.5)
			end
			v1156.AnchorPoint = v1157
			local v1158 = v_u_889
			local v1159
			if v1137 then
				v1159 = UDim2.new(1, 8, 0.5, 0)
			else
				v1159 = UDim2.new(0, -8, 0.5, 0)
			end
			v1158.Position = v1159
			local v1160 = v1062.d or 0
			local v1161 = v_u_889
			local v1162
			if v1160 < 0 then
				v1162 = ("\224\184\148\224\184\177\224\184\153\224\185\128\224\184\130\224\185\137\224\184\178 \226\136\146%.2f"):format(-v1160)
			else
				v1162 = v1160 <= 0 and "\224\184\149\224\184\180\224\184\148\224\184\156\224\184\180\224\184\167 0.00" or ("\224\184\148\224\184\182\224\184\135\224\184\173\224\184\173\224\184\129 +%.2f"):format(v1160)
			end
			v1161.Text = v1162
			local v1163 = v_u_889
			local v1164
			if v1160 < 0 then
				v1164 = Color3.fromRGB(120, 200, 255)
			elseif v1160 > 0 then
				v1164 = v_u_21.pink
			else
				v1164 = v_u_21.text
			end
			v1163.TextColor3 = v1164
		end
		local v1165 = v_u_347 == "tilt"
		local v1166 = v_u_900
		local v1167 = v_u_901
		v_u_895.Visible = v1165
		v1166.Visible = v1165
		v1167.Visible = v1165
		for _, v1168 in v_u_896 do
			v1168.button.Visible = v1165
		end
		if v1165 then
			local v1169 = v1068.X
			local v1170 = v1068.X
			for v1171 = 1, 4 do
				local v1172 = v1066.Position + v1072[(v1171 == 1 or v1171 == 4) and 1 or 3] * (v1064 / 2) + v1072[v1171 <= 2 and 2 or 4] * (v1065 / 2)
				local v1173 = workspace.CurrentCamera:WorldToViewportPoint(v1172)
				local v1174 = Vector2.new(v1173.X, v1173.Y) - v_u_9:GetGuiInset()
				local _ = v1173.Z > 0
				local v1175 = v1174.X
				v1169 = math.min(v1169, v1175)
				local v1176 = v1174.X
				v1170 = math.max(v1170, v1176)
			end
			local v1177 = workspace.CurrentCamera.ViewportSize
			local v1178 = v1170 + 70
			if v1178 + 100 > v1177.X then
				v1178 = v1169 - 70
			end
			local v1179 = Vector2.new(v1178, v1068.Y)
			local v1180 = v_u_895
			local v1181 = UDim2.fromOffset
			local v1182 = v1179.X + 0.5
			local v1183 = math.floor(v1182)
			local v1184 = v1179.Y + 0.5
			v1180.Position = v1181(v1183, (math.floor(v1184)))
			for _, v1185 in v_u_896 do
				local v1186 = v1185.button
				local v1187 = v1179 + v1185.off
				local v1188 = UDim2.fromOffset
				local v1189 = v1187.X + 0.5
				local v1190 = math.floor(v1189)
				local v1191 = v1187.Y + 0.5
				v1186.Position = v1188(v1190, (math.floor(v1191)))
			end
			local v1192 = v_u_901
			local v1193 = v1179 + Vector2.new(44, -44)
			local v1194 = UDim2.fromOffset
			local v1195 = v1193.X + 0.5
			local v1196 = math.floor(v1195)
			local v1197 = v1193.Y + 0.5
			v1192.Position = v1194(v1196, (math.floor(v1197)))
			local v1198 = v_u_900
			local v1199 = v1179 + Vector2.new(0, 64)
			local v1200 = UDim2.fromOffset
			local v1201 = v1199.X + 0.5
			local v1202 = math.floor(v1201)
			local v1203 = v1199.Y + 0.5
			v1198.Position = v1200(v1202, (math.floor(v1203)))
			local v1204 = v1062.a or 0
			local v1205 = v1062.b or 0
			v_u_900.Text = ("\224\184\139\224\185\137\224\184\178\224\184\162-\224\184\130\224\184\167\224\184\178 %d\194\176 \194\183 \224\184\154\224\184\153-\224\184\165\224\185\136\224\184\178\224\184\135 %d\194\176"):format(math.round(v1204), (math.round(v1205)))
			local v1206 = v_u_900
			local v1207
			if v1204 == 0 and v1205 == 0 then
				v1207 = v_u_21.text
			else
				v1207 = v_u_894
			end
			v1206.TextColor3 = v1207
		end
	else
		v_u_856.Visible = false
	end
end)
v_u_794("select")
local function v_u_1236(p1208, p1209) -- name: stickerAt
	-- upvalues: (copy) v_u_405, (ref) v_u_343, (copy) v_u_11
	local v1210 = v_u_405(p1208, p1209)
	local v1211 = workspace.CurrentCamera:ViewportPointToRay(p1208, p1209)
	local v1212
	if v1210 then
		v1212 = (v1210.Position - v1211.Origin):Dot(v1211.Direction)
	else
		v1212 = v1210
	end
	local v1213 = nil
	for v1214, v1215 in not v_u_343 and {} or v_u_11.read(v_u_343.model) do
		local v1216 = v_u_343.panels[v1215.p]
		if not v1216 then
			continue
		end
		if v1215.d and v1215.d ~= 0 or (v1215.a or v1215.b) then
			local v1217, v1218, v1219 = v_u_11.frame(v1215, v1216)
			if v1215.d and v1215.d ~= 0 then
				v1217 = v1217 + v1217.LookVector * v1215.d
			end
			local v1220 = v_u_11.tiltFrame(v1217, v1218, v1219, v1215)
			local v1221 = v1220.LookVector
			local v1222 = v1211.Direction:Dot(v1221)
			if v1222 >= -0.001 then
				continue
			end
			local v1223 = (v1220.Position - v1211.Origin):Dot(v1221) / v1222
			if v1223 <= 0 then
				continue
			end
			if v1212 then
				local v1224 = v1212 + 0.1
				local v1225 = -v1215.d
				if v1223 > v1224 + math.max(0, v1225) then
					continue
				end
			end
			local v1226 = v1220:PointToObjectSpace(v1211.Origin + v1211.Direction * v1223)
			local v1227 = v1226.X
			if math.abs(v1227) > v1218 * 0.55 then
				continue
			end
			local v1228 = v1226.Y
			if math.abs(v1228) > v1219 * 0.55 then
				continue
			end
			v1213 = v1214
		else
			if not v1210 then
				continue
			end
			local v1229, v1230, v1231 = v_u_11.frame(v1215, v1216)
			local v1232 = v1229:PointToObjectSpace(v1210.Position)
			local v1233 = v1232.X
			if math.abs(v1233) > v1230 * 0.55 then
				continue
			end
			local v1234 = v1232.Y
			if math.abs(v1234) > v1231 * 0.55 then
				continue
			end
			local v1235 = v1232.Z
			if math.abs(v1235) >= 1 then
				continue
			end
			v1213 = v1214
		end
	end
	return v1213
end
local function v_u_1242(p1237) -- name: overEditorUi
	-- upvalues: (copy) v_u_9, (copy) v_u_174, (copy) v_u_261, (copy) v_u_328, (copy) v_u_159, (ref) v_u_787
	local v1238 = Vector2.new(p1237.X, p1237.Y) - v_u_9:GetGuiInset()
	for _, v1239 in {
		v_u_174,
		v_u_261,
		v_u_328,
		v_u_159,
		v_u_787
	} do
		if not v1239.Visible then
			continue
		end
		local v1240 = v1239.AbsolutePosition
		local v1241 = v1239.AbsoluteSize
		if v1238.X < v1240.X or (v1238.Y < v1240.Y or (v1238.X > v1240.X + v1241.X or v1238.Y > v1240.Y + v1241.Y)) then
			continue
		end
		return true
	end
	return false
end
local function v_u_1267() -- name: updateGhost
	-- upvalues: (ref) v_u_343, (copy) v_u_360, (copy) v_u_7, (ref) v_u_348, (copy) v_u_405, (copy) v_u_11, (ref) v_u_358, (copy) v_u_460, (copy) v_u_415, (ref) v_u_349, (ref) v_u_353, (ref) v_u_342, (copy) v_u_312, (copy) v_u_592, (copy) v_u_21, (copy) v_u_1242, (copy) v_u_341, (copy) v_u_359, (ref) v_u_357
	if v_u_343 and not v_u_360 then
		local v1243 = v_u_7:GetMouseLocation()
		if v_u_348 then
			local v1244 = v_u_405(v1243.X, v1243.Y)
			local v1245
			if v1244 == nil then
				v1245 = false
			else
				local v1246 = v1244.Instance
				if type(v1246:GetAttribute("Panel")) == "string" then
					v1245 = v_u_343.panels[v1244.Instance:GetAttribute("Panel")] == v1244.Instance
				else
					v1245 = false
				end
			end
			if v1245 then
				local v1247 = (not v_u_343 and {} or v_u_11.read(v_u_343.model))[v_u_348.index]
				if v1247 then
					local v1248 = ("move|%s|%.2f|%.2f|%.2f"):format(v1244.Instance:GetFullName(), v1244.Position.X, v1244.Position.Y, v1244.Position.Z)
					if v1248 ~= v_u_358 then
						v_u_358 = v1248
						v_u_460(v_u_415(v1244, v1247.s, v1247.w, v1247.c, v_u_348.rot, v1247.d, v1247.a, v1247.b), v_u_348.index, v_u_348.index)
					end
				end
			else
				return
			end
		elseif v_u_349 then
			local v1249 = v_u_405(v1243.X, v1243.Y)
			local v1250
			if v1249 == nil then
				v1250 = false
			else
				local v1251 = v1249.Instance
				if type(v1251:GetAttribute("Panel")) == "string" then
					v1250 = v_u_343.panels[v1249.Instance:GetAttribute("Panel")] == v1249.Instance
				else
					v1250 = false
				end
			end
			if v1250 then
				v_u_353 = v1249
				if v_u_342 ~= false then
					v_u_342 = false
					v_u_312.Text = v_u_592()
					local v1252 = v_u_312
					local v1253
					if v_u_349 and v_u_342 then
						v1253 = v_u_21.warn
					else
						v1253 = v_u_21.text
					end
					v1252.TextColor3 = v1253
				end
			else
				if not v_u_1242(v1243) then
					v_u_353 = nil
					if v_u_358 or #v_u_341:GetChildren() > 0 then
						v_u_341:ClearAllChildren()
						table.clear(v_u_359)
						v_u_357 = nil
						v_u_358 = nil
					end
					local v1254 = v1249 ~= nil and true or v_u_405(v1243.X, v1243.Y, v_u_343.rough) ~= nil
					if v1254 ~= v_u_342 then
						v_u_342 = v1254
						v_u_312.Text = v_u_592()
						local v1255 = v_u_312
						local v1256
						if v_u_349 and v_u_342 then
							v1256 = v_u_21.warn
						else
							v1256 = v_u_21.text
						end
						v1255.TextColor3 = v1256
					end
					return
				end
				if not v_u_353 then
					if v_u_358 then
						v_u_341:ClearAllChildren()
						table.clear(v_u_359)
						v_u_357 = nil
						v_u_358 = nil
					end
					return
				end
			end
			local v1257
			if v1249 == nil then
				v1257 = false
			else
				local v1258 = v1249.Instance
				if type(v1258:GetAttribute("Panel")) == "string" then
					v1257 = v_u_343.panels[v1249.Instance:GetAttribute("Panel")] == v1249.Instance
				else
					v1257 = false
				end
			end
			if not v1257 then
				v1249 = v_u_353
			end
			if v1249.Instance.Parent and v1249.Instance:IsDescendantOf(v_u_343.model) then
				local v1259 = v1249.Instance:GetFullName()
				local v1260 = v1249.Position.X
				local v1261 = v1249.Position.Y
				local v1262 = v1249.Position.Z
				local v1263 = v_u_349.w
				local v1264 = v_u_349.rot
				local v1265 = v_u_349.c
				local v1266 = ("%s|%.2f|%.2f|%.2f|%.2f|%.1f|%s"):format(v1259, v1260, v1261, v1262, v1263, v1264, (tostring(v1265)))
				if v1266 ~= v_u_358 then
					v_u_358 = v1266
					v_u_460(v_u_415(v1249, v_u_349.s, v_u_349.w, v_u_349.c, v_u_349.rot, v_u_349.d, v_u_349.a, v_u_349.b), #(not v_u_343 and {} or v_u_11.read(v_u_343.model)) + 1, v_u_349.moving)
				end
			else
				v_u_353 = nil
				return
			end
		else
			return
		end
	else
		return
	end
end
local v_u_1268 = nil
local function v_u_1272(p1269) -- name: hideRider
	-- upvalues: (copy) v_u_17
	local v1270 = v_u_17.Character
	if v1270 then
		for _, v1271 in v1270:GetDescendants() do
			if not (v1271:IsA("BasePart") or v1271:IsA("Decal")) then
				continue
			end
			v1271.LocalTransparencyModifier = p1269 and 1 or 0
		end
	end
end
local function v_u_1308(p1273) -- name: camStart
	-- upvalues: (ref) v_u_1268, (copy) v_u_17, (copy) v_u_341
	local v1274 = workspace.CurrentCamera
	local v1275, v1276 = p1273:GetBoundingBox()
	local v1277 = p1273:FindFirstChild("Chassis", true) or (p1273.PrimaryPart or p1273:FindFirstChildWhichIsA("BasePart", true))
	local v1278 = v1274.CFrame.Position - v1275.Position
	local v1279 = v1278.X
	local v1280 = v1278.Z
	local v1281 = math.atan2(v1279, v1280)
	local v1282 = (p1273:FindFirstChild("DriverSeat", true) or p1273:FindFirstChild("VehicleSeat", true) or v1277).CFrame.LookVector * Vector3.new(1, 0, 1)
	local v1283 = v1282.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v1282.Unit
	local v1284 = v1283:Cross(Vector3.new(0, 1, 0))
	local v1285 = v1278.X
	local v1286 = v1278.Z
	if Vector3.new(v1285, 0, v1286):Dot(v1284) < 0 then
		v1284 = -v1284
	end
	local v1287 = (v1284 + v1283 * 0.4).Unit
	local v1288 = v1287.X
	local v1289 = v1287.Z
	local v1290 = v1281 + ((math.atan2(v1288, v1289) - v1281 + 3.141592653589793) % 6.283185307179586 - 3.141592653589793)
	local v1291 = v1277.CFrame:VectorToObjectSpace(v1275:VectorToWorldSpace(v1276 / 2))
	local v1292 = {
		["chassis"] = nil,
		["focus"] = nil,
		["half"] = nil,
		["radius"] = nil,
		["yaw"] = nil,
		["pitch"] = 0.3,
		["zoom"] = 1,
		["pan"] = Vector3.new(0, 0, 0),
		["cur"] = nil,
		["saved"] = nil,
		["hidden"] = nil,
		["chassis"] = v1277,
		["focus"] = v1277.CFrame:PointToObjectSpace(v1275.Position)
	}
	local v1293 = v1291.X
	local v1294 = math.abs(v1293)
	local v1295 = v1291.Y
	local v1296 = math.abs(v1295)
	local v1297 = v1291.Z
	local v1298 = math.abs(v1297)
	v1292.half = Vector3.new(v1294, v1296, v1298) * 0.85
	local v1299 = v1276.X
	local v1300 = v1276.Y
	local v1301 = v1276.Z
	v1292.radius = math.max(v1299, v1300, v1301) * 0.62
	v1292.yaw = v1290
	v1292.cur = {
		["yaw"] = nil,
		["pitch"] = 0.3,
		["zoom"] = 1.2,
		["pan"] = Vector3.new(0, 0, 0),
		["yaw"] = v1281
	}
	v1292.saved = {
		["type"] = v1274.CameraType,
		["subject"] = v1274.CameraSubject,
		["fov"] = v1274.FieldOfView
	}
	v1292.hidden = {}
	v_u_1268 = v1292
	local v1302 = { workspace:FindFirstChild("SpawnedVehicles"), v_u_17.Character, v_u_341 }
	v_u_1268.ignore = v1302
	v_u_1268.rayParams = RaycastParams.new()
	v_u_1268.rayParams.FilterType = Enum.RaycastFilterType.Exclude
	v_u_1268.rayParams.FilterDescendantsInstances = v1302
	v_u_1268.corners = {}
	local v1303 = v1276 / 2 * 0.9
	for _, v1304 in {
		Vector3.new(1, 1, 1),
		Vector3.new(-1, 1, 1),
		Vector3.new(1, 1, -1),
		Vector3.new(-1, 1, -1),
		Vector3.new(1, -0.6, 1),
		Vector3.new(-1, -0.6, 1),
		Vector3.new(1, -0.6, -1),
		Vector3.new(-1, -0.6, -1),
		Vector3.new(1, 0, 0),
		Vector3.new(-1, 0, 0),
		Vector3.new(0, 0, 1),
		Vector3.new(0, 0, -1)
	} do
		local v1305 = v_u_1268.corners
		local v1306 = v1277.CFrame
		local v1307 = (v1275 * CFrame.new(v1303 * v1304)).Position
		table.insert(v1305, v1306:PointToObjectSpace(v1307))
	end
end
local function v_u_1320(p1309, p1310) -- name: clearView
	local v1311 = p1309.chassis.CFrame:PointToWorldSpace(p1309.focus + p1309.cur.pan)
	local v1312 = p1310.Position - v1311
	for _ = 1, 6 do
		local v1313 = workspace:Raycast(v1311, v1312, p1309.rayParams)
		if not v1313 then
			break
		end
		local v1314 = v1313.Instance
		p1309.rayParams:AddToFilter(v1314)
		if v1313.Normal.Y >= 0.7 then
			local v1315 = v1313.Distance - 0.6
			p1310 = p1310 - v1312 * (1 - math.max(v1315, 1) / v1312.Magnitude)
			p1309.rayParams.FilterDescendantsInstances = p1309.ignore
			break
		end
		if p1309.hidden[v1314] == nil then
			p1309.hidden[v1314] = v1314.LocalTransparencyModifier
		end
		v1314.LocalTransparencyModifier = 1
	end
	for _, v1316 in p1309.corners do
		local v1317 = p1309.chassis.CFrame:PointToWorldSpace(v1316)
		local v1318 = workspace:Raycast(v1317, p1310.Position - v1317, p1309.rayParams)
		if not v1318 or v1318.Normal.Y >= 0.7 then
			continue
		end
		local v1319 = v1318.Instance
		p1309.rayParams:AddToFilter(v1319)
		if p1309.hidden[v1319] == nil then
			p1309.hidden[v1319] = v1319.LocalTransparencyModifier
		end
		v1319.LocalTransparencyModifier = 1
	end
	return p1310
end
local function v_u_1324() -- name: camStop
	-- upvalues: (ref) v_u_1268, (copy) v_u_1272
	if v_u_1268 then
		local v1321 = workspace.CurrentCamera
		v1321.CameraType = v_u_1268.saved.type
		v1321.CameraSubject = v_u_1268.saved.subject
		v1321.FieldOfView = v_u_1268.saved.fov
		for v1322, v1323 in v_u_1268.hidden do
			if not v1322.Parent then
				continue
			end
			v1322.LocalTransparencyModifier = v1323
		end
		v_u_1268 = nil
		v_u_1272(false)
	end
end
local function v_u_1340(p1325, p1326) -- name: camPose
	-- upvalues: (copy) v_u_174, (copy) v_u_328
	local v1327 = workspace.CurrentCamera
	local v1328 = p1325.chassis.CFrame:PointToWorldSpace(p1325.focus + p1326.pan)
	local v1329 = v1327.ViewportSize
	local v1330 = 0.4663076581549986 * v1329.X / v1329.Y
	local v1331 = not v_u_174.Visible and 0 or v_u_174.AbsolutePosition.X + v_u_174.AbsoluteSize.X + 12
	local v1332 = v1329.X - (v_u_328.Visible and 130 or 12)
	if v1332 - v1331 < 160 then
		v1332 = v1329.X
		v1331 = 0
	end
	local v1333 = (v1332 - v1331) / v1329.X
	local v1334 = math.clamp(v1333, 0.25, 1)
	local v1335 = (v1331 + v1332) / 2 / v1329.X
	local v1336 = p1325.radius / 0.4663076581549986
	local v1337 = p1325.radius / (v1330 * v1334)
	local v1338 = math.max(v1336, v1337) * p1326.zoom
	local v1339 = -(v1335 - 0.5) * 2 * v1338 * v1330
	return CFrame.new(v1328) * CFrame.Angles(0, p1326.yaw, 0) * CFrame.Angles(-p1326.pitch, 0, 0) * CFrame.new(v1339, -0.06 * v1338, v1338)
end
v6:BindToRenderStep("StickerEditorCamera", Enum.RenderPriority.Camera.Value + 1, function(p1341)
	-- upvalues: (ref) v_u_1268, (copy) v_u_1320, (copy) v_u_1340, (copy) v_u_1272
	local v1342 = v_u_1268
	if v1342 and v1342.chassis.Parent then
		local v1343 = workspace.CurrentCamera
		v1343.CameraType = Enum.CameraType.Scriptable
		v1343.FieldOfView = 50
		local v1344 = -math.min(p1341, 0.1) * 11
		local v1345 = 1 - math.exp(v1344)
		local v1346 = v1342.cur
		v1346.yaw = v1346.yaw + (v1342.yaw - v1346.yaw) * v1345
		v1346.pitch = v1346.pitch + (v1342.pitch - v1346.pitch) * v1345
		v1346.zoom = v1346.zoom + (v1342.zoom - v1346.zoom) * v1345
		v1346.pan = v1346.pan:Lerp(v1342.pan, v1345)
		v1343.CFrame = v_u_1320(v1342, (v_u_1340(v1342, v1346)))
		v_u_1272(true)
	end
end)
local function v_u_1368(p1347, p1348) -- name: zoom
	-- upvalues: (ref) v_u_1268, (ref) v_u_347, (ref) v_u_358
	local v1349 = v_u_1268
	if v1349 then
		local v1350 = v1349.zoom * p1347
		local v1351 = math.clamp(v1350, 0.05, 2.2)
		local v1352 = v1351 / v1349.zoom
		if v1351 >= 0.98 and v_u_347 ~= "camera" then
			v1349.pan = Vector3.new(0, 0, 0)
		elseif p1348 then
			local v1353 = v1349.chassis.CFrame
			local v1354 = v1353:PointToObjectSpace(p1348 + (v1353:PointToWorldSpace(v1349.focus + v1349.pan) - p1348) * v1352) - v1349.focus
			local v1355 = v1349.half * 1.3
			local v1356 = v1354.X
			local v1357 = -v1355.X
			local v1358 = v1355.X
			local v1359 = math.clamp(v1356, v1357, v1358)
			local v1360 = v1354.Y
			local v1361 = -v1355.Y
			local v1362 = v1355.Y
			local v1363 = math.clamp(v1360, v1361, v1362)
			local v1364 = v1354.Z
			local v1365 = -v1355.Z
			local v1366 = v1355.Z
			local v1367 = math.clamp(v1364, v1365, v1366)
			v1349.pan = Vector3.new(v1359, v1363, v1367)
		end
		v1349.zoom = v1351
		v_u_358 = nil
	end
end
local function v_u_1393(p1369, p1370) -- name: panPixels
	-- upvalues: (ref) v_u_1268, (ref) v_u_358
	local v1371 = v_u_1268
	if v1371 then
		local v1372 = workspace.CurrentCamera
		local v1373 = v1371.chassis.CFrame:PointToWorldSpace(v1371.focus + v1371.cur.pan)
		local v1374 = 2 * (workspace.CurrentCamera.CFrame.Position - v1373).Magnitude
		local v1375 = v1372.FieldOfView / 2
		local v1376 = math.rad(v1375)
		local v1377 = v1374 * math.tan(v1376) / v1372.ViewportSize.Y
		local v1378 = (-v1372.CFrame.RightVector * p1369 + v1372.CFrame.UpVector * p1370) * v1377
		local v1379 = v1371.pan + v1371.chassis.CFrame:VectorToObjectSpace(v1378)
		local v1380 = v1371.half * 1.3
		local v1381 = v1379.X
		local v1382 = -v1380.X
		local v1383 = v1380.X
		local v1384 = math.clamp(v1381, v1382, v1383)
		local v1385 = v1379.Y
		local v1386 = -v1380.Y
		local v1387 = v1380.Y
		local v1388 = math.clamp(v1385, v1386, v1387)
		local v1389 = v1379.Z
		local v1390 = -v1380.Z
		local v1391 = v1380.Z
		local v1392 = math.clamp(v1389, v1390, v1391)
		v1371.pan = Vector3.new(v1384, v1388, v1392)
		v_u_358 = nil
	end
end
v335.left.Activated:Connect(function()
	-- upvalues: (ref) v_u_1268, (ref) v_u_358
	if v_u_1268 then
		local v1394 = v_u_1268
		v1394.yaw = v1394.yaw + 0.7853981633974483
		local v1395 = v_u_1268
		local v1396 = v_u_1268.pitch + 0
		v1395.pitch = math.clamp(v1396, -0.15, 1.35)
		v_u_358 = nil
	end
end)
v335.right.Activated:Connect(function()
	-- upvalues: (ref) v_u_1268, (ref) v_u_358
	if v_u_1268 then
		local v1397 = v_u_1268
		v1397.yaw = v1397.yaw + -0.7853981633974483
		local v1398 = v_u_1268
		local v1399 = v_u_1268.pitch + 0
		v1398.pitch = math.clamp(v1399, -0.15, 1.35)
		v_u_358 = nil
	end
end)
v335.up.Activated:Connect(function()
	-- upvalues: (ref) v_u_1268, (ref) v_u_358
	if v_u_1268 then
		local v1400 = v_u_1268
		v1400.yaw = v1400.yaw + 0
		local v1401 = v_u_1268
		local v1402 = v_u_1268.pitch + 0.25
		v1401.pitch = math.clamp(v1402, -0.15, 1.35)
		v_u_358 = nil
	end
end)
v335.down.Activated:Connect(function()
	-- upvalues: (ref) v_u_1268, (ref) v_u_358
	if v_u_1268 then
		local v1403 = v_u_1268
		v1403.yaw = v1403.yaw + 0
		local v1404 = v_u_1268
		local v1405 = v_u_1268.pitch + -0.25
		v1404.pitch = math.clamp(v1405, -0.15, 1.35)
		v_u_358 = nil
	end
end)
v335.plus.Activated:Connect(function()
	-- upvalues: (copy) v_u_1368, (ref) v_u_351, (ref) v_u_343, (copy) v_u_11
	local v1406 = v_u_1368
	local v1407 = 0.8
	local v1408 = v_u_351
	if v1408 then
		v1408 = (not v_u_343 and {} or v_u_11.read(v_u_343.model))[v_u_351]
	end
	local v1409 = v1408 and v_u_343
	if v1409 then
		v1409 = v_u_343.panels[v1408.p]
	end
	local v1410
	if v1409 then
		local v1411, v1412, v1413 = v_u_11.frame(v1408, v1409)
		if v1408.d and v1408.d ~= 0 then
			v1411 = v1411 + v1411.LookVector * v1408.d
		end
		v1410 = v_u_11.tiltFrame(v1411, v1412, v1413, v1408).Position
	else
		v1410 = nil
	end
	v1406(v1407, v1410)
end)
v335.minus.Activated:Connect(function()
	-- upvalues: (copy) v_u_1368, (ref) v_u_351, (ref) v_u_343, (copy) v_u_11
	local v1414 = v_u_1368
	local v1415 = 1.25
	local v1416 = v_u_351
	if v1416 then
		v1416 = (not v_u_343 and {} or v_u_11.read(v_u_343.model))[v_u_351]
	end
	local v1417 = v1416 and v_u_343
	if v1417 then
		v1417 = v_u_343.panels[v1416.p]
	end
	local v1418
	if v1417 then
		local v1419, v1420, v1421 = v_u_11.frame(v1416, v1417)
		if v1416.d and v1416.d ~= 0 then
			v1419 = v1419 + v1419.LookVector * v1416.d
		end
		v1418 = v_u_11.tiltFrame(v1419, v1420, v1421, v1416).Position
	else
		v1418 = nil
	end
	v1414(v1415, v1418)
end)
local v_u_1422 = {
	["StickerEditor"] = true,
	["GameToast"] = true,
	["TouchGui"] = true
}
local v_u_1423 = {}
local function v_u_1425() -- name: hideHud
	-- upvalues: (copy) v_u_17, (copy) v_u_1422, (copy) v_u_1423
	for _, v1424 in v_u_17.PlayerGui:GetChildren() do
		if not v1424:IsA("ScreenGui") or (not v1424.Enabled or v_u_1422[v1424.Name]) then
			continue
		end
		v1424.Enabled = false
		v_u_1423[v1424] = true
	end
end
local function v_u_1432() -- name: finish
	-- upvalues: (copy) v_u_1423, (copy) v_u_341, (copy) v_u_359, (ref) v_u_357, (ref) v_u_358, (ref) v_u_343, (ref) v_u_770, (copy) v_u_1324, (ref) v_u_349, (ref) v_u_351, (ref) v_u_348, (ref) v_u_352, (ref) v_u_353, (ref) v_u_771, (copy) v_u_174, (copy) v_u_261, (copy) v_u_312, (copy) v_u_328, (copy) v_u_171, (copy) v_u_172, (copy) v_u_17
	for v1426 in v_u_1423 do
		if not v1426.Parent then
			continue
		end
		v1426.Enabled = true
	end
	table.clear(v_u_1423)
	v_u_341:ClearAllChildren()
	table.clear(v_u_359)
	v_u_357 = nil
	v_u_358 = nil
	local v1427 = v_u_343
	if v1427 then
		v1427 = v_u_343.model:FindFirstChild("StickerVisuals")
	end
	if v_u_770 and (v1427 and v1427:FindFirstChild("S" .. v_u_770)) then
		for _, v1428 in v1427["S" .. v_u_770]:GetDescendants() do
			if not v1428:IsA("Texture") then
				continue
			end
			v1428.Transparency = 0
		end
	end
	v_u_770 = nil
	v_u_1324()
	if v_u_343 and v_u_343.restoreQuery then
		v_u_343.restoreQuery()
	end
	v_u_343 = nil
	v_u_349 = nil
	v_u_351 = nil
	v_u_348 = nil
	v_u_352 = nil
	v_u_353 = nil
	v_u_771 = nil
	local v1429 = v_u_261
	local v1430 = v_u_312
	local v1431 = v_u_328
	v_u_174.Visible = false
	v1429.Visible = false
	v1430.Visible = false
	v1431.Visible = false
	v_u_171.Text = "\224\184\170\224\184\149\224\184\180\224\185\138\224\184\129\224\185\128\224\184\129\224\184\173\224\184\163\224\185\140"
	v_u_172.Text = "\224\185\129\224\184\155\224\184\176\224\184\165\224\184\178\224\184\162\224\184\154\224\184\153\224\184\163\224\184\150"
	v_u_17:SetAttribute("Tuning", nil)
end
local function v_u_1449() -- name: openEditor
	-- upvalues: (ref) v_u_346, (ref) v_u_343, (copy) v_u_367, (copy) v_u_13, (copy) v_u_16, (copy) v_u_17, (copy) v_u_11, (copy) v_u_373, (copy) v_u_20, (copy) v_u_10, (copy) v_u_185, (copy) v_u_174, (copy) v_u_312, (copy) v_u_328, (copy) v_u_1425, (copy) v_u_171, (copy) v_u_172, (copy) v_u_1308, (copy) v_u_681
	if v_u_346 or v_u_343 then
		return
	else
		local v1433 = v_u_367()
		if v1433 then
			if v_u_16.vehicleIn(v1433) then
				if v_u_17:GetAttribute("Tuning") then
					return
				else
					local v1434, v1435 = v_u_11.panels(v1433)
					if #v1435 == 0 then
						v_u_13.show("\224\184\163\224\184\150\224\184\132\224\184\177\224\184\153\224\184\153\224\184\181\224\185\137\224\184\162\224\184\177\224\184\135\224\185\132\224\184\161\224\185\136\224\184\161\224\184\181\224\184\138\224\184\180\224\185\137\224\184\153\224\184\151\224\184\181\224\185\136\224\185\129\224\184\155\224\184\176\224\185\132\224\184\148\224\185\137 (\224\184\163\224\184\177\224\184\153 StickerRig)", "error")
						return
					else
						v_u_346 = true
						local v1436, v1437 = v_u_373(v_u_20, "Open")
						v_u_346 = false
						if v1436 then
							local v1438 = {}
							local v1439 = {}
							local v1440 = {}
							for _, v1441 in v1433:GetDescendants() do
								if not v1441:IsA("BasePart") or (v1441.Transparency >= 0.5 or v1441:FindFirstAncestor("StickerVisuals")) then
									continue
								end
								local v1442 = v1441:IsA("MeshPart")
								if v1442 then
									if type(v1441:GetAttribute("Panel")) == "string" then
										v1442 = false
									else
										v1442 = v1441.CollisionFidelity == Enum.CollisionFidelity.Box and true or v1441.CollisionFidelity == Enum.CollisionFidelity.Hull
									end
								end
								local v1443
								if v1442 then
									v1443 = v1438
								else
									v1443 = v1440
								end
								table.insert(v1443, v1441)
								table.insert(v1439, v1441)
							end
							v_u_343 = {
								["model"] = v1433,
								["seat"] = v1433:FindFirstChild("DriverSeat", true) or v1433:FindFirstChild("VehicleSeat", true),
								["panels"] = v1434,
								["include"] = v1435,
								["blockers"] = v1440,
								["rough"] = v1438,
								["restoreQuery"] = v_u_11.queryOn(v1439)
							}
							v_u_17:SetAttribute("Tuning", true)
							local v1444 = v_u_10.vehicle(v1433:GetAttribute("VehicleId"))
							local v1445 = v_u_185
							local v1446
							if v1444 then
								v1446 = v1444.th
							else
								v1446 = v1433.Name
							end
							v1445.Text = v1446
							local v1447 = v_u_312
							local v1448 = v_u_328
							v_u_174.Visible = true
							v1447.Visible = true
							v1448.Visible = true
							v_u_1425()
							v_u_171.Text = "\224\184\155\224\184\180\224\184\148\224\184\170\224\184\149\224\184\180\224\185\138\224\184\129\224\185\128\224\184\129\224\184\173\224\184\163\224\185\140"
							v_u_172.Text = "\224\184\129\224\184\148\224\185\128\224\184\158\224\184\183\224\185\136\224\184\173\224\184\154\224\184\177\224\184\153\224\184\151\224\184\182\224\184\129\224\185\129\224\184\165\224\184\176\224\184\155\224\184\180\224\184\148"
							v_u_1308(v1433)
							v_u_681()
						else
							v_u_13.show(v1437 or "\224\185\128\224\184\155\224\184\180\224\184\148\224\185\132\224\184\161\224\185\136\224\185\132\224\184\148\224\185\137", "error")
						end
					end
				end
			else
				v_u_13.show("\224\184\130\224\184\177\224\184\154\224\184\163\224\184\150\224\185\128\224\184\130\224\185\137\224\184\178\224\185\132\224\184\155\224\184\136\224\184\173\224\184\148\224\185\131\224\184\153\224\184\163\224\185\137\224\184\178\224\184\153\224\184\170\224\184\149\224\184\180\224\185\138\224\184\129\224\185\128\224\184\129\224\184\173\224\184\163\224\185\140\224\184\129\224\185\136\224\184\173\224\184\153", "info")
				return
			end
		else
			v_u_13.show("\224\184\130\224\184\182\224\185\137\224\184\153\224\184\153\224\184\177\224\185\136\224\184\135\224\184\151\224\184\181\224\185\136\224\184\132\224\184\153\224\184\130\224\184\177\224\184\154\224\184\129\224\185\136\224\184\173\224\184\153 \224\185\129\224\184\165\224\185\137\224\184\167\224\184\132\224\185\136\224\184\173\224\184\162\224\184\129\224\184\148\224\184\170\224\184\149\224\184\180\224\185\138\224\184\129\224\185\128\224\184\129\224\184\173\224\184\163\224\185\140", "info")
			return
		end
	end
end
local function v_u_1453(p1450) -- name: closeEditor
	-- upvalues: (ref) v_u_346, (ref) v_u_343, (copy) v_u_373, (copy) v_u_20, (copy) v_u_13, (copy) v_u_1432
	if not v_u_346 and v_u_343 then
		v_u_346 = true
		if p1450 then
			local v1451, v1452 = v_u_373(v_u_20, "Confirm")
			if not v1451 then
				v_u_346 = false
				if v1452 then
					v_u_13.show(v1452, "error")
				end
				return
			end
			v_u_13.show(v1452 or "\224\184\154\224\184\177\224\184\153\224\184\151\224\184\182\224\184\129\224\185\129\224\184\165\224\185\137\224\184\167", "info")
		elseif not p1450 then
			v_u_373(v_u_20, "Cancel")
		end
		v_u_373(v_u_20, "Close")
		v_u_346 = false
		v_u_1432()
	end
end
v_u_159.Activated:Connect(function()
	-- upvalues: (ref) v_u_343, (copy) v_u_1453, (copy) v_u_1449
	if v_u_343 then
		v_u_1453(true)
	else
		v_u_1449()
	end
end)
v_u_259.Activated:Connect(function()
	-- upvalues: (copy) v_u_1453
	v_u_1453(true)
end)
v258.Activated:Connect(function()
	-- upvalues: (ref) v_u_346, (ref) v_u_343, (copy) v_u_373, (copy) v_u_20, (copy) v_u_1432
	if not v_u_346 then
		if not v_u_343 then
			return
		end
		v_u_346 = true
		v_u_373(v_u_20, "Cancel")
		v_u_373(v_u_20, "Close")
		v_u_346 = false
		v_u_1432()
	end
end)
local v_u_1454 = 0
v_u_232.Activated:Connect(function()
	-- upvalues: (ref) v_u_343, (copy) v_u_11, (ref) v_u_1454, (copy) v_u_232, (copy) v_u_21, (ref) v_u_346, (copy) v_u_373, (copy) v_u_19, (copy) v_u_13, (ref) v_u_351, (ref) v_u_771, (copy) v_u_681
	if v_u_343 and #(not v_u_343 and {} or v_u_11.read(v_u_343.model)) ~= 0 then
		if os.clock() - v_u_1454 < 2.5 then
			v_u_1454 = 0
			v_u_232.Text = "\224\184\165\224\184\154\224\184\151\224\184\177\224\185\137\224\184\135\224\184\171\224\184\161\224\184\148"
			v_u_232.TextColor3 = v_u_21.dim
			local v1455
			if v_u_346 then
				v1455 = false
			else
				v_u_346 = true
				local v1456
				v1455, v1456 = v_u_373(v_u_19, "clear", nil, nil)
				v_u_346 = false
				if not v1455 and v1456 then
					v_u_13.show(v1456, "error")
				end
			end
			if v1455 then
				v_u_351 = nil
			end
			v_u_771 = nil
			v_u_681()
		else
			v_u_1454 = os.clock()
			v_u_232.Text = "\224\184\129\224\184\148\224\184\173\224\184\181\224\184\129\224\184\132\224\184\163\224\184\177\224\185\137\224\184\135\224\185\128\224\184\158\224\184\183\224\185\136\224\184\173\224\184\162\224\184\183\224\184\153\224\184\162\224\184\177\224\184\153"
			v_u_232.TextColor3 = v_u_21.danger
			task.delay(2.5, function()
				-- upvalues: (ref) v_u_1454, (ref) v_u_232, (ref) v_u_21
				if os.clock() - v_u_1454 >= 2.4 then
					v_u_232.Text = "\224\184\165\224\184\154\224\184\151\224\184\177\224\185\137\224\184\135\224\184\171\224\184\161\224\184\148"
					v_u_232.TextColor3 = v_u_21.dim
				end
			end)
		end
	else
		return
	end
end)
local function v_u_1458(...) -- name: adminInvoke
	-- upvalues: (copy) v_u_18, (copy) v_u_373
	local v1457 = v_u_18:FindFirstChild("StickerAdmin")
	if v1457 then
		return v_u_373(v1457, ...)
	else
		return false, "\224\184\163\224\184\176\224\184\154\224\184\154\224\184\171\224\184\165\224\184\177\224\184\135\224\184\154\224\185\137\224\184\178\224\184\153\224\184\162\224\184\177\224\184\135\224\185\132\224\184\161\224\185\136\224\184\158\224\184\163\224\185\137\224\184\173\224\184\161"
	end
end
local function v_u_1463() -- name: openAdmin
	-- upvalues: (ref) v_u_768, (copy) v_u_12, (copy) v_u_17, (copy) v_u_174, (copy) v_u_21, (copy) v_u_22, (copy) v_u_23, (copy) v_u_140, (copy) v_u_147, (copy) v_u_155, (copy) v_u_56, (copy) v_u_72, (copy) v_u_13, (copy) v_u_1458, (copy) v_u_10
	if v_u_768 or not v_u_12.isAdmin(v_u_17) then
		return
	else
		local v1459 = script:WaitForChild("AdminView", 5)
		local v1460 = require
		local v1461, v1462 = pcall(v1460, v1459)
		if v1461 and v1459 then
			v_u_768 = v1462.new({
				["parent"] = v_u_174,
				["position"] = UDim2.fromOffset(12, 104),
				["size"] = UDim2.fromOffset(316, 402),
				["C"] = v_u_21,
				["BOLD"] = v_u_22,
				["MED"] = v_u_23,
				["new"] = v_u_140,
				["corner"] = v_u_147,
				["stroke"] = v_u_155,
				["label"] = v_u_56,
				["button"] = v_u_72,
				["Catalog"] = v_u_12,
				["Toast"] = v_u_13,
				["invoke"] = v_u_1458,
				["priceText"] = v_u_10.priceText
			})
		else
			warn("StickerEditorClient: AdminView:", v1462)
		end
	end
end
v_u_464 = function(p1464)
	-- upvalues: (ref) v_u_345, (copy) v_u_1463, (copy) v_u_681
	v_u_345 = p1464
	if p1464 == "\0admin" then
		v_u_1463()
	end
	v_u_681()
end
v_u_465 = function(p1465)
	-- upvalues: (ref) v_u_343, (ref) v_u_349, (copy) v_u_341, (copy) v_u_359, (ref) v_u_357, (ref) v_u_358, (copy) v_u_12, (copy) v_u_11, (ref) v_u_351, (copy) v_u_681
	if v_u_343 then
		if v_u_349 and (v_u_349.s == p1465 and not v_u_349.moving) then
			v_u_349 = nil
			v_u_341:ClearAllChildren()
			table.clear(v_u_359)
			v_u_357 = nil
			v_u_358 = nil
		else
			local v1466 = v_u_12.get(p1465)
			if not v1466 then
				return
			end
			local v1467 = not v_u_349 and 1.2 or v_u_349.w
			local v1468 = v_u_12.get(p1465)
			local v1469 = v_u_11.MAX_W
			local v1470 = v1468 and v1468.maxSize or v_u_11.MAX_W
			local v1471 = math.min(v1469, v1470)
			local v1472 = math.min(v1467, v1471)
			local v1473 = not v_u_349 and 0 or v_u_349.rot
			local v1474
			if v1466.tint then
				v1474 = not (v_u_349 and v_u_349.c) and "ffffff" or v_u_349.c
			else
				v1474 = nil
			end
			v_u_349 = {
				["s"] = p1465,
				["w"] = v1472,
				["rot"] = v1473,
				["c"] = v1474
			}
			v_u_351 = nil
			v_u_358 = nil
		end
		v_u_681()
	end
end
v_u_547()
v_u_12.changed:Connect(function()
	-- upvalues: (copy) v_u_547, (ref) v_u_768, (ref) v_u_771, (copy) v_u_681
	v_u_547()
	if v_u_768 then
		v_u_768.refresh()
	end
	v_u_771 = nil
	v_u_681()
end)
v_u_17:GetAttributeChangedSignal("StickerAdmin"):Connect(function()
	-- upvalues: (copy) v_u_12, (copy) v_u_17, (ref) v_u_768, (copy) v_u_547, (copy) v_u_681
	if not v_u_12.isAdmin(v_u_17) and v_u_768 then
		v_u_768.frame:Destroy()
		v_u_768 = nil
	end
	v_u_547()
	v_u_681()
end)
v_u_310.Activated:Connect(function()
	-- upvalues: (ref) v_u_349, (copy) v_u_341, (copy) v_u_359, (ref) v_u_357, (ref) v_u_358, (ref) v_u_343, (ref) v_u_770, (copy) v_u_681
	v_u_349 = nil
	v_u_341:ClearAllChildren()
	table.clear(v_u_359)
	v_u_357 = nil
	v_u_358 = nil
	local v1475 = v_u_343
	if v1475 then
		v1475 = v_u_343.model:FindFirstChild("StickerVisuals")
	end
	if v_u_770 and (v1475 and v1475:FindFirstChild("S" .. v_u_770)) then
		for _, v1476 in v1475["S" .. v_u_770]:GetDescendants() do
			if not v1476:IsA("Texture") then
				continue
			end
			v1476.Transparency = 0
		end
	end
	v_u_770 = nil
	v_u_681()
end)
v_u_308.Activated:Connect(function()
	-- upvalues: (ref) v_u_351, (ref) v_u_343, (copy) v_u_11, (ref) v_u_349, (copy) v_u_393, (copy) v_u_429, (ref) v_u_358, (copy) v_u_681
	local v1477 = v_u_351
	if v1477 then
		v1477 = (not v_u_343 and {} or v_u_11.read(v_u_343.model))[v_u_351]
	end
	if v1477 then
		v_u_349 = {
			["s"] = v1477.s,
			["w"] = v1477.w,
			["rot"] = v_u_393(v1477),
			["c"] = v1477.c,
			["d"] = v1477.d,
			["a"] = v1477.a,
			["b"] = v1477.b,
			["moving"] = v_u_351
		}
		v_u_429(v_u_351)
		v_u_358 = nil
		v_u_681()
	end
end)
v_u_307.Activated:Connect(function()
	-- upvalues: (ref) v_u_351, (ref) v_u_343, (copy) v_u_11, (copy) v_u_13, (copy) v_u_423, (copy) v_u_375, (ref) v_u_346, (copy) v_u_373, (copy) v_u_19, (copy) v_u_681
	local v1478 = v_u_351
	if v1478 then
		v1478 = (not v_u_343 and {} or v_u_11.read(v_u_343.model))[v_u_351]
	end
	if v1478 then
		local v1479 = v_u_11.mirror(v_u_343.model, v1478, v_u_343.panels, v_u_343.include)
		if v1479 then
			local v1480, v1481 = v_u_423(v1479, nil)
			if v1480 then
				local v1482 = v_u_375(v1479)
				local v1483, v1484
				if v_u_346 then
					v1483 = false
					v1484 = nil
				else
					v_u_346 = true
					v1483, v1484 = v_u_373(v_u_19, "place", v1482, nil)
					v_u_346 = false
					if not v1483 and v1484 then
						v_u_13.show(v1484, "error")
					end
				end
				if v1483 then
					v_u_351 = v1484
					v_u_13.show("\224\184\167\224\184\178\224\184\135\224\184\173\224\184\181\224\184\129\224\184\157\224\184\177\224\185\136\224\184\135\224\185\129\224\184\165\224\185\137\224\184\167", "info")
				end
				v_u_681()
			else
				v_u_13.show(v1481, "error")
			end
		else
			v_u_13.show("\224\185\132\224\184\161\224\185\136\224\185\128\224\184\136\224\184\173\224\184\138\224\184\180\224\185\137\224\184\153\224\184\151\224\184\181\224\185\136\224\185\129\224\184\155\224\184\176\224\185\132\224\184\148\224\185\137\224\184\149\224\184\163\224\184\135\224\184\173\224\184\181\224\184\129\224\184\157\224\184\177\224\185\136\224\184\135", "error")
			return
		end
	else
		return
	end
end)
v_u_309.Activated:Connect(function()
	-- upvalues: (ref) v_u_351, (ref) v_u_769
	if v_u_351 then
		v_u_769(v_u_351)
	end
end)
local v_u_1485 = nil
local v_u_1486 = false
local v_u_1487 = nil
local v_u_1488 = 0
local function v_u_1496(p1489, p1490, p1491) -- name: tapAt
	-- upvalues: (ref) v_u_346, (ref) v_u_1488, (ref) v_u_349, (copy) v_u_405, (ref) v_u_343, (ref) v_u_357, (ref) v_u_353, (copy) v_u_415, (copy) v_u_701, (ref) v_u_351, (copy) v_u_1236, (ref) v_u_771, (copy) v_u_681
	if v_u_346 or os.clock() - v_u_1488 < 0.25 then
		return
	else
		v_u_1488 = os.clock()
		if v_u_349 then
			local v1492 = v_u_405(p1489, p1490)
			local v1493
			if v1492 == nil then
				v1493 = false
			else
				local v1494 = v1492.Instance
				if type(v1494:GetAttribute("Panel")) == "string" then
					v1493 = v_u_343.panels[v1492.Instance:GetAttribute("Panel")] == v1492.Instance
				else
					v1493 = false
				end
			end
			if v1493 then
				local v1495
				if p1491 or (not v_u_357 or (not v_u_353 or (v_u_353.Instance ~= v1492.Instance or (v_u_353.Position - v1492.Position).Magnitude >= 0.08))) then
					v1495 = nil
				else
					v1495 = v_u_357
				end
				v_u_701(v1495 or v_u_415(v1492, v_u_349.s, v_u_349.w, v_u_349.c, v_u_349.rot, v_u_349.d, v_u_349.a, v_u_349.b))
			end
		else
			v_u_351 = v_u_1236(p1489, p1490)
			v_u_771 = nil
			v_u_681()
			return
		end
	end
end
v_u_7.InputBegan:Connect(function(p1497, p1498)
	-- upvalues: (ref) v_u_343, (ref) v_u_1487, (ref) v_u_1485, (ref) v_u_1486, (ref) v_u_978, (ref) v_u_347, (ref) v_u_349, (ref) v_u_354, (copy) v_u_7, (ref) v_u_351, (copy) v_u_1236, (copy) v_u_11, (ref) v_u_348, (copy) v_u_393, (copy) v_u_429, (ref) v_u_358, (copy) v_u_1496, (copy) v_u_341, (copy) v_u_359, (ref) v_u_357, (ref) v_u_770, (ref) v_u_771, (copy) v_u_681, (copy) v_u_703, (copy) v_u_399, (ref) v_u_352, (copy) v_u_423, (copy) v_u_13, (copy) v_u_375, (ref) v_u_346, (copy) v_u_373, (copy) v_u_19, (copy) v_u_767, (ref) v_u_769, (copy) v_u_784, (copy) v_u_794, (copy) v_u_1060
	if v_u_343 and not p1498 then
		local v1499 = p1497.UserInputType
		if v1499 == Enum.UserInputType.MouseButton2 then
			v_u_1487 = Vector2.new(p1497.Position.X, p1497.Position.Y)
			return
		elseif v1499 == Enum.UserInputType.Touch then
			v_u_1485 = Vector2.new(p1497.Position.X, p1497.Position.Y)
			v_u_1486 = false
			return
		elseif v1499 == Enum.UserInputType.MouseButton1 then
			if v_u_978 then
				return
			elseif v_u_347 == "camera" and not v_u_349 then
				v_u_354 = Vector2.new(p1497.Position.X, p1497.Position.Y)
				return
			else
				local v1500 = v_u_7:GetMouseLocation()
				if v_u_349 or (not v_u_351 or v_u_1236(v1500.X, v1500.Y) ~= v_u_351) then
					v_u_1496(v1500.X, v1500.Y, false)
				else
					local v1501 = (not v_u_343 and {} or v_u_11.read(v_u_343.model))[v_u_351]
					v_u_348 = {
						["index"] = nil,
						["from"] = nil,
						["rot"] = nil,
						["moved"] = false,
						["index"] = v_u_351,
						["from"] = Vector2.new(v1500.X, v1500.Y),
						["rot"] = v_u_393(v1501)
					}
					v_u_429(v_u_351)
					v_u_358 = nil
				end
			end
		elseif p1497.KeyCode == Enum.KeyCode.Escape then
			if v_u_348 then
				v_u_348 = nil
				v_u_341:ClearAllChildren()
				table.clear(v_u_359)
				v_u_357 = nil
				v_u_358 = nil
				local v1502 = v_u_343
				if v1502 then
					v1502 = v_u_343.model:FindFirstChild("StickerVisuals")
				end
				if v_u_770 and (v1502 and v1502:FindFirstChild("S" .. v_u_770)) then
					for _, v1503 in v1502["S" .. v_u_770]:GetDescendants() do
						if not v1503:IsA("Texture") then
							continue
						end
						v1503.Transparency = 0
					end
				end
				v_u_770 = nil
			elseif v_u_349 then
				v_u_349 = nil
				v_u_341:ClearAllChildren()
				table.clear(v_u_359)
				v_u_357 = nil
				v_u_358 = nil
				local v1504 = v_u_343
				if v1504 then
					v1504 = v_u_343.model:FindFirstChild("StickerVisuals")
				end
				if v_u_770 and (v1504 and v1504:FindFirstChild("S" .. v_u_770)) then
					for _, v1505 in v1504["S" .. v_u_770]:GetDescendants() do
						if not v1505:IsA("Texture") then
							continue
						end
						v1505.Transparency = 0
					end
				end
				v_u_770 = nil
			else
				v_u_351 = nil
				v_u_771 = nil
			end
			v_u_681()
			return
		elseif p1497.KeyCode == Enum.KeyCode.Comma then
			if v_u_349 then
				v_u_349.rot = (v_u_349.rot + -15 + 180) % 360 - 180
				v_u_358 = nil
			elseif v_u_703() then
				v_u_399(v_u_352.entry, v_u_393(v_u_352.entry) + -15)
				if v_u_352 then
					local v1506 = v_u_352
					v_u_352 = nil
					local v1507 = v1506.index
					local v1508 = v1506.entry
					local v1509, v1510 = v_u_423(v1508, v1507)
					if v1509 then
						local v1511 = v_u_375(v1508)
						local v1512, v1513
						if v_u_346 then
							v1512 = false
							v1513 = nil
						else
							v_u_346 = true
							v1512, v1513 = v_u_373(v_u_19, "edit", v1507, v1511)
							v_u_346 = false
							if not v1512 and v1513 then
								v_u_13.show(v1513, "error")
							end
						end
						if v1512 then
							v_u_351 = v1513
						end
					else
						v_u_13.show(v1510, "error")
					end
					v_u_341:ClearAllChildren()
					table.clear(v_u_359)
					v_u_357 = nil
					v_u_358 = nil
					local v1514 = v_u_343
					if v1514 then
						v1514 = v_u_343.model:FindFirstChild("StickerVisuals")
					end
					if v_u_770 and (v1514 and v1514:FindFirstChild("S" .. v_u_770)) then
						for _, v1515 in v1514["S" .. v_u_770]:GetDescendants() do
							if not v1515:IsA("Texture") then
								continue
							end
							v1515.Transparency = 0
						end
					end
					v_u_770 = nil
					v_u_771 = nil
					v_u_681()
				end
			end
			v_u_681()
			return
		elseif p1497.KeyCode == Enum.KeyCode.Period then
			if v_u_349 then
				v_u_349.rot = (v_u_349.rot + 15 + 180) % 360 - 180
				v_u_358 = nil
			elseif v_u_703() then
				v_u_399(v_u_352.entry, v_u_393(v_u_352.entry) + 15)
				if v_u_352 then
					local v1516 = v_u_352
					v_u_352 = nil
					local v1517 = v1516.index
					local v1518 = v1516.entry
					local v1519, v1520 = v_u_423(v1518, v1517)
					if v1519 then
						local v1521 = v_u_375(v1518)
						local v1522, v1523
						if v_u_346 then
							v1522 = false
							v1523 = nil
						else
							v_u_346 = true
							v1522, v1523 = v_u_373(v_u_19, "edit", v1517, v1521)
							v_u_346 = false
							if not v1522 and v1523 then
								v_u_13.show(v1523, "error")
							end
						end
						if v1522 then
							v_u_351 = v1523
						end
					else
						v_u_13.show(v1520, "error")
					end
					v_u_341:ClearAllChildren()
					table.clear(v_u_359)
					v_u_357 = nil
					v_u_358 = nil
					local v1524 = v_u_343
					if v1524 then
						v1524 = v_u_343.model:FindFirstChild("StickerVisuals")
					end
					if v_u_770 and (v1524 and v1524:FindFirstChild("S" .. v_u_770)) then
						for _, v1525 in v1524["S" .. v_u_770]:GetDescendants() do
							if not v1525:IsA("Texture") then
								continue
							end
							v1525.Transparency = 0
						end
					end
					v_u_770 = nil
					v_u_771 = nil
					v_u_681()
				end
			end
			v_u_681()
			return
		elseif p1497.KeyCode == Enum.KeyCode.Minus then
			v_u_767(0.8695652173913044)
			return
		elseif p1497.KeyCode == Enum.KeyCode.Equals then
			v_u_767(1.15)
			return
		elseif (p1497.KeyCode == Enum.KeyCode.Backspace or p1497.KeyCode == Enum.KeyCode.Delete) and (v_u_351 and not v_u_349) then
			v_u_769(v_u_351)
		else
			for _, v1526 in v_u_784 do
				if p1497.KeyCode ~= v1526.keyCode then
					continue
				end
				v_u_794(v1526.key)
				return
			end
			local v1527 = (v_u_7:IsKeyDown(Enum.KeyCode.LeftShift) or v_u_7:IsKeyDown(Enum.KeyCode.RightShift)) and 0.25 or 0.05
			local v1528 = v1527 > 0.1 and 15 or 5
			if v_u_347 == "tilt" and (v_u_351 and (not v_u_349 and (p1497.KeyCode == Enum.KeyCode.Left or (p1497.KeyCode == Enum.KeyCode.Right or (p1497.KeyCode == Enum.KeyCode.Up or p1497.KeyCode == Enum.KeyCode.Down))))) then
				local v1529 = p1497.KeyCode
				local v1530
				if v1529 == Enum.KeyCode.Left then
					v1530 = -v1528
				else
					v1530 = v1529 ~= Enum.KeyCode.Right and 0 or v1528
				end
				if v1529 ~= Enum.KeyCode.Up then
					v1528 = v1529 ~= Enum.KeyCode.Down and 0 or -v1528
				end
				if not v_u_349 and (v_u_351 and not v_u_352) then
					if not v_u_343 then
						return
					end
					if v_u_703() then
						local v1531 = v_u_352.entry
						v1531.a = v_u_11.tilt((v1531.a or 0) + v1530)
						v1531.b = v_u_11.tilt((v1531.b or 0) + v1528)
						if v_u_352 then
							local v1532 = v_u_352
							v_u_352 = nil
							local v1533 = v1532.index
							local v1534 = v1532.entry
							local v1535, v1536 = v_u_423(v1534, v1533)
							if v1535 then
								local v1537 = v_u_375(v1534)
								local v1538, v1539
								if v_u_346 then
									v1538 = false
									v1539 = nil
								else
									v_u_346 = true
									v1538, v1539 = v_u_373(v_u_19, "edit", v1533, v1537)
									v_u_346 = false
									if not v1538 and v1539 then
										v_u_13.show(v1539, "error")
									end
								end
								if v1538 then
									v_u_351 = v1539
								end
							else
								v_u_13.show(v1536, "error")
							end
							v_u_341:ClearAllChildren()
							table.clear(v_u_359)
							v_u_357 = nil
							v_u_358 = nil
							local v1540 = v_u_343
							if v1540 then
								v1540 = v_u_343.model:FindFirstChild("StickerVisuals")
							end
							if v_u_770 and (v1540 and v1540:FindFirstChild("S" .. v_u_770)) then
								for _, v1541 in v1540["S" .. v_u_770]:GetDescendants() do
									if not v1541:IsA("Texture") then
										continue
									end
									v1541.Transparency = 0
								end
							end
							v_u_770 = nil
							v_u_771 = nil
							v_u_681()
							return
						end
					end
				end
			elseif p1497.KeyCode == Enum.KeyCode.PageUp then
				local v1542 = v1527 / 2
				if not v_u_349 and (v_u_351 and not v_u_352) then
					if not v_u_343 then
						return
					end
					if v_u_703() then
						v_u_352.entry.d = v_u_11.out((v_u_352.entry.d or 0) + v1542)
						if v_u_352 then
							local v1543 = v_u_352
							v_u_352 = nil
							local v1544 = v1543.index
							local v1545 = v1543.entry
							local v1546, v1547 = v_u_423(v1545, v1544)
							if v1546 then
								local v1548 = v_u_375(v1545)
								local v1549, v1550
								if v_u_346 then
									v1549 = false
									v1550 = nil
								else
									v_u_346 = true
									v1549, v1550 = v_u_373(v_u_19, "edit", v1544, v1548)
									v_u_346 = false
									if not v1549 and v1550 then
										v_u_13.show(v1550, "error")
									end
								end
								if v1549 then
									v_u_351 = v1550
								end
							else
								v_u_13.show(v1547, "error")
							end
							v_u_341:ClearAllChildren()
							table.clear(v_u_359)
							v_u_357 = nil
							v_u_358 = nil
							local v1551 = v_u_343
							if v1551 then
								v1551 = v_u_343.model:FindFirstChild("StickerVisuals")
							end
							if v_u_770 and (v1551 and v1551:FindFirstChild("S" .. v_u_770)) then
								for _, v1552 in v1551["S" .. v_u_770]:GetDescendants() do
									if not v1552:IsA("Texture") then
										continue
									end
									v1552.Transparency = 0
								end
							end
							v_u_770 = nil
							v_u_771 = nil
							v_u_681()
							return
						end
					end
				end
			elseif p1497.KeyCode == Enum.KeyCode.PageDown then
				local v1553 = -v1527 / 2
				if not v_u_349 and (v_u_351 and not v_u_352) then
					if not v_u_343 then
						return
					end
					if v_u_703() then
						v_u_352.entry.d = v_u_11.out((v_u_352.entry.d or 0) + v1553)
						if v_u_352 then
							local v1554 = v_u_352
							v_u_352 = nil
							local v1555 = v1554.index
							local v1556 = v1554.entry
							local v1557, v1558 = v_u_423(v1556, v1555)
							if v1557 then
								local v1559 = v_u_375(v1556)
								local v1560, v1561
								if v_u_346 then
									v1560 = false
									v1561 = nil
								else
									v_u_346 = true
									v1560, v1561 = v_u_373(v_u_19, "edit", v1555, v1559)
									v_u_346 = false
									if not v1560 and v1561 then
										v_u_13.show(v1561, "error")
									end
								end
								if v1560 then
									v_u_351 = v1561
								end
							else
								v_u_13.show(v1558, "error")
							end
							v_u_341:ClearAllChildren()
							table.clear(v_u_359)
							v_u_357 = nil
							v_u_358 = nil
							local v1562 = v_u_343
							if v1562 then
								v1562 = v_u_343.model:FindFirstChild("StickerVisuals")
							end
							if v_u_770 and (v1562 and v1562:FindFirstChild("S" .. v_u_770)) then
								for _, v1563 in v1562["S" .. v_u_770]:GetDescendants() do
									if not v1563:IsA("Texture") then
										continue
									end
									v1563.Transparency = 0
								end
							end
							v_u_770 = nil
							v_u_771 = nil
							v_u_681()
							return
						end
					end
				end
			else
				if p1497.KeyCode == Enum.KeyCode.Left then
					v_u_1060(-1, 0, v1527)
					return
				end
				if p1497.KeyCode == Enum.KeyCode.Right then
					v_u_1060(1, 0, v1527)
					return
				end
				if p1497.KeyCode == Enum.KeyCode.Up then
					v_u_1060(0, 1, v1527)
					return
				end
				if p1497.KeyCode == Enum.KeyCode.Down then
					v_u_1060(0, -1, v1527)
				end
			end
		end
	else
		return
	end
end)
v_u_7.InputChanged:Connect(function(p1564, p1565)
	-- upvalues: (copy) v_u_40, (ref) v_u_343, (ref) v_u_978, (ref) v_u_977, (ref) v_u_1487, (ref) v_u_1268, (ref) v_u_358, (ref) v_u_354, (copy) v_u_1393, (ref) v_u_348, (copy) v_u_7, (ref) v_u_1485, (ref) v_u_1486, (ref) v_u_347, (ref) v_u_349, (copy) v_u_1368, (copy) v_u_405
	for _, v1566 in v_u_40 do
		if not v1566.dragging or p1564.UserInputType ~= Enum.UserInputType.MouseMovement and p1564.UserInputType ~= Enum.UserInputType.Touch then
			continue
		end
		v1566.move(p1564)
		return
	end
	if v_u_343 then
		local v1567 = p1564.UserInputType
		if v_u_978 and (v1567 == Enum.UserInputType.MouseMovement or v1567 == Enum.UserInputType.Touch) then
			v_u_977(false)
		elseif v1567 == Enum.UserInputType.MouseMovement then
			local v1568 = Vector2.new(p1564.Position.X, p1564.Position.Y)
			if v_u_1487 then
				local v1569 = v1568 - v_u_1487
				v_u_1487 = v1568
				local v1570 = -v1569.X * 0.008
				local v1571 = v1569.Y * 0.006
				if v_u_1268 then
					local v1572 = v_u_1268
					v1572.yaw = v1572.yaw + v1570
					local v1573 = v_u_1268
					local v1574 = v_u_1268.pitch + v1571
					v1573.pitch = math.clamp(v1574, -0.15, 1.35)
					v_u_358 = nil
				end
			end
			if v_u_354 then
				local v1575 = v1568 - v_u_354
				v_u_354 = v1568
				v_u_1393(v1575.X, v1575.Y)
			end
			if v_u_348 then
				local v1576 = v_u_7:GetMouseLocation()
				if (Vector2.new(v1576.X, v1576.Y) - v_u_348.from).Magnitude > 6 then
					v_u_348.moved = true
					return
				end
			end
		elseif v1567 == Enum.UserInputType.Touch and v_u_1485 then
			local v1577 = Vector2.new(p1564.Position.X, p1564.Position.Y)
			local v1578 = v1577 - v_u_1485
			if v_u_1486 or v1578.Magnitude > 12 then
				v_u_1486 = true
				v_u_1485 = v1577
				if v_u_347 == "camera" and not v_u_349 then
					v_u_1393(v1578.X, v1578.Y)
					return
				end
				local v1579 = -v1578.X * 0.008
				local v1580 = v1578.Y * 0.006
				if v_u_1268 then
					local v1581 = v_u_1268
					v1581.yaw = v1581.yaw + v1579
					local v1582 = v_u_1268
					local v1583 = v_u_1268.pitch + v1580
					v1582.pitch = math.clamp(v1583, -0.15, 1.35)
					v_u_358 = nil
					return
				end
			end
		elseif v1567 == Enum.UserInputType.MouseWheel and not p1565 then
			local v1584 = v_u_1368
			local v1585 = p1564.Position.Z > 0 and 0.8695652173913044 or 1.15
			local v1586
			if v_u_343 then
				local v1587 = v_u_7:GetMouseLocation()
				v1586 = v_u_405(v1587.X, v1587.Y)
				if v1586 then
					v1586 = v1586.Position
				end
			else
				v1586 = nil
			end
			v1584(v1585, v1586)
		end
	else
		return
	end
end)
v_u_7.InputEnded:Connect(function(p1588, p1589)
	-- upvalues: (ref) v_u_978, (ref) v_u_977, (ref) v_u_352, (copy) v_u_423, (copy) v_u_13, (copy) v_u_375, (ref) v_u_346, (copy) v_u_373, (copy) v_u_19, (ref) v_u_351, (copy) v_u_341, (copy) v_u_359, (ref) v_u_357, (ref) v_u_358, (ref) v_u_343, (ref) v_u_770, (ref) v_u_771, (copy) v_u_681, (copy) v_u_40, (ref) v_u_1487, (ref) v_u_354, (ref) v_u_348, (ref) v_u_1485, (ref) v_u_1486, (copy) v_u_9, (copy) v_u_1496
	local v1590 = p1588.UserInputType
	if (v1590 == Enum.UserInputType.MouseButton1 or v1590 == Enum.UserInputType.Touch) and v_u_978 then
		v_u_977(true)
		if v_u_978 then
			v_u_978 = nil
			if v_u_352 then
				local v1591 = v_u_352
				v_u_352 = nil
				local v1592 = v1591.index
				local v1593 = v1591.entry
				local v1594, v1595 = v_u_423(v1593, v1592)
				if v1594 then
					local v1596 = v_u_375(v1593)
					local v1597, v1598
					if v_u_346 then
						v1597 = false
						v1598 = nil
					else
						v_u_346 = true
						v1597, v1598 = v_u_373(v_u_19, "edit", v1592, v1596)
						v_u_346 = false
						if not v1597 and v1598 then
							v_u_13.show(v1598, "error")
						end
					end
					if v1597 then
						v_u_351 = v1598
					end
				else
					v_u_13.show(v1595, "error")
				end
				v_u_341:ClearAllChildren()
				table.clear(v_u_359)
				v_u_357 = nil
				v_u_358 = nil
				local v1599 = v_u_343
				if v1599 then
					v1599 = v_u_343.model:FindFirstChild("StickerVisuals")
				end
				if v_u_770 and (v1599 and v1599:FindFirstChild("S" .. v_u_770)) then
					for _, v1600 in v1599["S" .. v_u_770]:GetDescendants() do
						if not v1600:IsA("Texture") then
							continue
						end
						v1600.Transparency = 0
					end
				end
				v_u_770 = nil
				v_u_771 = nil
				v_u_681()
			end
		end
		return
	else
		for _, v1601 in v_u_40 do
			if not v1601.dragging or v1590 ~= Enum.UserInputType.MouseButton1 and v1590 ~= Enum.UserInputType.Touch then
				continue
			end
			v1601.stop()
			return
		end
		if v1590 == Enum.UserInputType.MouseButton2 then
			v_u_1487 = nil
			return
		elseif v1590 == Enum.UserInputType.MouseButton1 and v_u_354 then
			v_u_354 = nil
			return
		elseif v1590 == Enum.UserInputType.MouseButton1 and v_u_348 then
			local v1602 = v_u_348
			v_u_348 = nil
			if v1602.moved and v_u_357 then
				local v1603 = v1602.index
				local v1604 = v_u_357
				local v1605, v1606 = v_u_423(v1604, v1603)
				if v1605 then
					local v1607 = v_u_375(v1604)
					local v1608, v1609
					if v_u_346 then
						v1608 = false
						v1609 = nil
					else
						v_u_346 = true
						v1608, v1609 = v_u_373(v_u_19, "edit", v1603, v1607)
						v_u_346 = false
						if not v1608 and v1609 then
							v_u_13.show(v1609, "error")
						end
					end
					if v1608 then
						v_u_351 = v1609
					end
				else
					v_u_13.show(v1606, "error")
				end
			end
			v_u_341:ClearAllChildren()
			table.clear(v_u_359)
			v_u_357 = nil
			v_u_358 = nil
			local v1610 = v_u_343
			if v1610 then
				v1610 = v_u_343.model:FindFirstChild("StickerVisuals")
			end
			if v_u_770 and (v1610 and v1610:FindFirstChild("S" .. v_u_770)) then
				for _, v1611 in v1610["S" .. v_u_770]:GetDescendants() do
					if not v1611:IsA("Texture") then
						continue
					end
					v1611.Transparency = 0
				end
			end
			v_u_770 = nil
			v_u_771 = nil
			v_u_681()
		elseif v1590 == Enum.UserInputType.Touch and v_u_1485 then
			local v1612 = not v_u_1486
			if v1612 then
				v1612 = not p1589
			end
			v_u_1485 = nil
			v_u_1486 = false
			if v_u_343 and v1612 then
				local v1613 = v_u_9:GetGuiInset()
				v_u_1496(p1588.Position.X, p1588.Position.Y + v1613.Y, true)
			end
		end
	end
end)
v6.RenderStepped:Connect(function(p1614)
	-- upvalues: (ref) v_u_1268, (ref) v_u_343, (ref) v_u_347, (ref) v_u_349, (copy) v_u_7, (ref) v_u_358
	local v1615 = v_u_1268
	if v1615 and (v_u_343 and (v_u_347 == "camera" and not (v_u_349 or v_u_7:GetFocusedTextBox()))) then
		local v1616 = math.min(p1614, 0.1)
		local v1617 = (v_u_7:IsKeyDown(Enum.KeyCode.LeftShift) or v_u_7:IsKeyDown(Enum.KeyCode.RightShift)) and 2.5 or 1
		local v1618 = workspace.CurrentCamera
		local v1619 = Vector3.new(0, 0, 0)
		if v_u_7:IsKeyDown(Enum.KeyCode.A) then
			v1619 = v1619 - v1618.CFrame.RightVector
		end
		if v_u_7:IsKeyDown(Enum.KeyCode.D) then
			v1619 = v1619 + v1618.CFrame.RightVector
		end
		if v_u_7:IsKeyDown(Enum.KeyCode.E) then
			v1619 = v1619 + Vector3.new(0, 1, 0)
		end
		if v_u_7:IsKeyDown(Enum.KeyCode.Q) then
			v1619 = v1619 - Vector3.new(0, 1, 0)
		end
		if v1619.Magnitude > 0.001 then
			local v1620 = v1619.Unit
			local v1621 = v1615.chassis.CFrame:PointToWorldSpace(v1615.focus + v1615.cur.pan)
			local v1622 = (workspace.CurrentCamera.CFrame.Position - v1621).Magnitude
			local v1623 = v1620 * math.max(v1622, 2) * 0.9 * v1616 * v1617
			local v1624 = v1615.pan + v1615.chassis.CFrame:VectorToObjectSpace(v1623)
			local v1625 = v1615.half * 1.3
			local v1626 = v1624.X
			local v1627 = -v1625.X
			local v1628 = v1625.X
			local v1629 = math.clamp(v1626, v1627, v1628)
			local v1630 = v1624.Y
			local v1631 = -v1625.Y
			local v1632 = v1625.Y
			local v1633 = math.clamp(v1630, v1631, v1632)
			local v1634 = v1624.Z
			local v1635 = -v1625.Z
			local v1636 = v1625.Z
			local v1637 = math.clamp(v1634, v1635, v1636)
			v1615.pan = Vector3.new(v1629, v1633, v1637)
			v_u_358 = nil
		end
		local v1638 = (v_u_7:IsKeyDown(Enum.KeyCode.S) and 1 or 0) - (v_u_7:IsKeyDown(Enum.KeyCode.W) and 1 or 0)
		if v1638 ~= 0 then
			local v1639 = 1 + v1638 * 1.3 * v1616 * v1617
			local v1640 = v_u_1268
			if not v1640 then
				return
			end
			local v1641 = v1640.zoom * v1639
			local v1642 = math.clamp(v1641, 0.05, 2.2)
			local _ = v1642 / v1640.zoom
			if v1642 >= 0.98 and v_u_347 ~= "camera" then
				v1640.pan = Vector3.new(0, 0, 0)
			end
			v1640.zoom = v1642
			v_u_358 = nil
		end
	end
end)
local v_u_1643 = 0
v6.RenderStepped:Connect(function()
	-- upvalues: (ref) v_u_343, (ref) v_u_349, (ref) v_u_348, (ref) v_u_1643, (copy) v_u_1267
	if v_u_343 and (v_u_349 or v_u_348) and os.clock() - v_u_1643 > 0.05 then
		v_u_1643 = os.clock()
		v_u_1267()
	end
end)
v_u_17.CharacterRemoving:Connect(function()
	-- upvalues: (ref) v_u_343, (copy) v_u_1432
	if v_u_343 then
		v_u_1432()
	end
end)
local v_u_1644 = false
task.spawn(function()
	-- upvalues: (copy) v_u_367, (copy) v_u_16, (copy) v_u_159, (ref) v_u_343, (copy) v_u_14, (ref) v_u_1644, (copy) v_u_13, (copy) v_u_171, (ref) v_u_346, (copy) v_u_1432, (ref) v_u_352, (ref) v_u_348, (copy) v_u_681
	while true do
		task.wait(0.3)
		local v1645 = v_u_367()
		local v1646
		if v1645 == nil then
			v1646 = false
		else
			v1646 = v_u_16.vehicleIn(v1645)
		end
		local v1647 = v_u_159
		local v1648
		if v1646 or v_u_343 ~= nil then
			local v1649 = v_u_343
			if v1649 then
				v1649 = v_u_14.isPhone()
			end
			v1648 = not v1649
		else
			v1648 = false
		end
		v1647.Visible = v1648
		if v1646 and not (v_u_1644 or v_u_343) then
			v_u_13.show("\224\185\128\224\184\130\224\185\137\224\184\178\224\184\163\224\185\137\224\184\178\224\184\153\224\184\170\224\184\149\224\184\180\224\185\138\224\184\129\224\185\128\224\184\129\224\184\173\224\184\163\224\185\140\224\185\129\224\184\165\224\185\137\224\184\167 \224\184\129\224\184\148\224\184\155\224\184\184\224\185\136\224\184\161 \"\224\184\170\224\184\149\224\184\180\224\185\138\224\184\129\224\185\128\224\184\129\224\184\173\224\184\163\224\185\140\" \224\184\151\224\184\178\224\184\135\224\184\139\224\185\137\224\184\178\224\184\162\224\185\128\224\184\158\224\184\183\224\185\136\224\184\173\224\185\129\224\184\149\224\185\136\224\184\135\224\184\165\224\184\178\224\184\162\224\184\163\224\184\150", "info")
		end
		v_u_1644 = v1646
		v_u_159.BackgroundTransparency = (v1645 or v_u_343) and 0.1 or 0.45
		v_u_171.TextTransparency = (v1645 or v_u_343) and 0 or 0.35
		if not v_u_343 or v_u_346 then
			continue
		end
		if v1645 == v_u_343.model then
			if v_u_352 or v_u_348 then
				continue
			end
			v_u_681()
		else
			v_u_1432()
		end
	end
end)