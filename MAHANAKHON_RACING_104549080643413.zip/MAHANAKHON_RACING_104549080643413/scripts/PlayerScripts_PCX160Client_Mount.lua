-- Path: Players/ygggggg55551/PlayerScripts/PCX160Client/Mount
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = require(game:GetService("ReplicatedStorage"):WaitForChild("NetSeal"))
local v_u_2 = game:GetService("CollectionService")
local v3 = game:GetService("Players")
local v_u_4 = game:GetService("ProximityPromptService")
local v_u_5 = game:GetService("ReplicatedStorage")
local v_u_6 = game:GetService("RunService")
local v_u_7 = require(v_u_5:WaitForChild("PCX160Shared"))
local v_u_8 = Enum.KeyCode.E
local v_u_9 = v3.LocalPlayer
local v10 = {}
local v_u_11 = {}
local v_u_12 = require(v_u_5:WaitForChild("DriveAccess"))
local function v_u_18(p13, p14) -- name: ridePrompt
	-- upvalues: (copy) v_u_11, (copy) v_u_8
	local v15 = v_u_11[p13]
	if v15 and v15.Parent then
		return v15
	end
	local v16 = p13:FindFirstChild("Chassis")
	if v16 then
		v16 = v16:FindFirstChild("PassengerSeatPoint") or v16:FindFirstChild("MountPoint")
	end
	if not v16 then
		return nil
	end
	local v17 = p14:Clone()
	v17.Name = "RidePrompt"
	v17.ActionText = "Ride"
	v17.KeyboardKeyCode = v_u_8
	v17.Parent = v16
	v_u_11[p13] = v17
	return v17
end
function v10.start() -- name: start
	-- upvalues: (copy) v_u_4, (copy) v_u_7, (copy) v_u_12, (copy) v_u_9, (copy) v_u_5, (copy) v_u_1, (copy) v_u_6, (copy) v_u_2, (copy) v_u_18, (copy) v_u_8, (copy) v_u_11
	v_u_4.PromptTriggered:Connect(function(p19)
		-- upvalues: (ref) v_u_7, (ref) v_u_12, (ref) v_u_9, (ref) v_u_5, (ref) v_u_1
		if p19.Name == "MountPrompt" or p19.Name == "RidePrompt" then
			local v20 = p19:FindFirstAncestorWhichIsA("Model")
			if v20 and v20:HasTag(v_u_7.TAG) then
				if p19.Name == "MountPrompt" then
					local v21 = v20:FindFirstChild("VehicleSeat")
					local v22
					if v21 == nil or v21.Occupant ~= nil then
						v22 = false
					else
						local v23 = v21:IsA("Seat")
						if v23 then
							v23 = v21.Disabled
						end
						v22 = not v23
					end
					local v24 = v22 and (v_u_12.mayDriveNow(v_u_9, v20) and v_u_5:FindFirstChild(v_u_7.REMOTE_NAME))
					if v24 then
						v_u_1.fire(v24, "Mount", v20, "Drive")
						return
					end
				else
					local v25 = v20:FindFirstChild("PassengerSeat")
					local v26
					if v25 == nil or v25.Occupant ~= nil then
						v26 = false
					else
						local v27 = v25:IsA("Seat")
						if v27 then
							v27 = v25.Disabled
						end
						v26 = not v27
					end
					local v28 = v26 and v_u_5:FindFirstChild(v_u_7.REMOTE_NAME)
					if v28 then
						v_u_1.fire(v28, "Mount", v20, "Ride")
					end
				end
			end
		else
			return
		end
	end)
	local v_u_29 = 0
	local v_u_30 = 0
	v_u_6.Heartbeat:Connect(function()
		-- upvalues: (ref) v_u_9, (ref) v_u_30, (ref) v_u_29, (ref) v_u_2, (ref) v_u_7, (ref) v_u_12, (ref) v_u_18, (ref) v_u_8, (ref) v_u_11
		local v31 = v_u_9.Character
		if v31 then
			v31 = v31:FindFirstChildOfClass("Humanoid")
		end
		local v32
		if v31 == nil then
			v32 = false
		else
			v32 = v31.SeatPart ~= nil
		end
		local v33
		if v31 then
			v33 = v31.RootPart
		else
			v33 = v31
		end
		local v34 = os.clock()
		if v34 >= v_u_30 then
			v_u_30 = v34 + 0.05
			local v35 = v_u_29 <= v34
			if v35 then
				v_u_29 = v34 + 0.25
			end
			for _, v36 in v_u_2:GetTagged(v_u_7.TAG) do
				local v37 = v36:FindFirstChild("Chassis")
				if v37 and (v33 and (not v35 and (v37.Position - v33.Position).Magnitude > 40)) then
					continue
				end
				if v37 then
					v37 = v37:FindFirstChild("MountPoint")
				end
				local v38
				if v37 then
					v38 = v37:FindFirstChild("MountPrompt")
				else
					v38 = v37
				end
				if not v38 then
					continue
				end
				local v39 = v36:GetAttribute("MountOpen") ~= false and v36:GetAttribute("CarWashBusy") ~= true and not v32
				if v39 then
					local v40
					if v31 then
						v40 = v31.SeatPart
					else
						v40 = v31
					end
					local v41
					if v40 == nil then
						v41 = false
					else
						v41 = v40.Parent == v36
					end
					v39 = not v41
				end
				local v42 = v36:GetAttribute("OwnerName")
				local v43 = (v36:GetAttribute("DisplayName") or "Scooter") .. (not v42 and "" or "  \194\183  " .. v42)
				if v38.ObjectText ~= v43 then
					v38.ObjectText = v43
				end
				if v38.ActionText ~= "Drive" then
					v38.ActionText = "Drive"
				end
				local v44
				if v39 then
					local v45 = v36:FindFirstChild("VehicleSeat")
					if v45 == nil or v45.Occupant ~= nil then
						v44 = false
					else
						local v46 = v45:IsA("Seat")
						if v46 then
							v46 = v45.Disabled
						end
						v44 = not v46
					end
					if v44 then
						v44 = v_u_12.mayDriveNow(v_u_9, v36)
					end
				else
					v44 = v39
				end
				local v47 = v_u_18(v36, v38)
				if v47 == nil then
					v39 = false
				elseif v39 then
					local v48 = v36:FindFirstChild("PassengerSeat")
					if v48 == nil or v48.Occupant ~= nil then
						v39 = false
					else
						local v49 = v48:IsA("Seat")
						if v49 then
							v49 = v48.Disabled
						end
						v39 = not v49
					end
				end
				if v44 and (v39 and v33) then
					local v50 = (v33.Position - v37.WorldPosition).Magnitude
					local v51 = (v33.Position - v47.Parent.WorldPosition).Magnitude
					v44 = v50 <= v51
					if v51 < v50 then
						v39 = true
					else
						v39 = false
					end
				end
				local v52 = v_u_9:FindFirstChild("HoverBike")
				local v53
				if v52 == nil then
					v53 = false
				else
					v53 = v52.Value == v36
				end
				if v53 then
					v44 = false
					v39 = false
				end
				if v38.Enabled ~= v44 then
					v38.Enabled = v44
				end
				if not v47 then
					continue
				end
				if v47.ObjectText ~= v43 then
					v47.ObjectText = v43
				end
				local v54 = v_u_8
				if v47.KeyboardKeyCode ~= v54 then
					v47.KeyboardKeyCode = v54
				end
				if v47.Enabled == v39 then
					continue
				end
				v47.Enabled = v39
			end
			for v55, v56 in v_u_11 do
				if v55.Parent then
					continue
				end
				v56:Destroy()
				v_u_11[v55] = nil
			end
		end
	end)
end
return v10