-- Path: ReplicatedStorage/ClanShared
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = {
	["REMOTE"] = "Clan",
	["CREATE_COST"] = 30000,
	["MAX_MEMBERS"] = 25,
	["MAX_CO"] = 2,
	["MAX_REQUESTS"] = 30,
	["NAME_MIN"] = 3,
	["NAME_MAX"] = 20,
	["TAG_MIN"] = 2,
	["TAG_MAX"] = 4
}
local v2 = {
	["Leader"] = {
		["label"] = "Leader",
		["level"] = 3,
		["color"] = nil,
		["color"] = Color3.fromRGB(255, 196, 46)
	},
	["Co"] = {
		["label"] = "Co-leader",
		["level"] = 2,
		["color"] = nil,
		["color"] = Color3.fromRGB(96, 200, 255)
	},
	["Member"] = {
		["label"] = "Member",
		["level"] = 1,
		["color"] = nil,
		["color"] = Color3.fromRGB(190, 196, 210)
	}
}
v_u_1.ROLES = v2
v_u_1.TAG_COLORS = {
	Color3.fromRGB(255, 255, 255),
	Color3.fromRGB(255, 196, 46),
	Color3.fromRGB(255, 128, 32),
	Color3.fromRGB(255, 64, 64),
	Color3.fromRGB(255, 90, 190),
	Color3.fromRGB(170, 90, 255),
	Color3.fromRGB(80, 120, 255),
	Color3.fromRGB(70, 210, 255),
	Color3.fromRGB(48, 220, 170),
	Color3.fromRGB(110, 230, 80),
	Color3.fromRGB(230, 230, 60),
	Color3.fromRGB(160, 160, 170)
}
function v_u_1.cleanTag(p3) -- name: cleanTag
	-- upvalues: (copy) v_u_1
	if type(p3) == "string" then
		local v4 = p3:upper():gsub("[^A-Z0-9]", "")
		if #v4 < v_u_1.TAG_MIN or #v4 > v_u_1.TAG_MAX then
			return nil
		else
			return v4
		end
	else
		return nil
	end
end
function v_u_1.cleanName(p5) -- name: cleanName
	-- upvalues: (copy) v_u_1
	if type(p5) == "string" then
		local v6 = p5:gsub("%s+", " "):gsub("^ ", ""):gsub(" $", "")
		local v7 = utf8.len(v6)
		if v7 and (v7 >= v_u_1.NAME_MIN and (v_u_1.NAME_MAX >= v7 and not v6:find("[<>&\"]"))) then
			return v6
		else
			return nil
		end
	else
		return nil
	end
end
function v_u_1.assetId(p8) -- name: assetId
	if type(p8) == "number" then
		if p8 > 0 and p8 % 1 == 0 then
			return p8
		else
			return nil
		end
	else
		if type(p8) ~= "string" then
			return nil
		end
		local v9 = p8:match("(%d%d%d%d+)")
		return v9 and tonumber(v9) or nil
	end
end
function v_u_1.logoImage(p10) -- name: logoImage
	return (type(p10) ~= "number" or p10 <= 0) and "" or ("rbxthumb://type=Asset&id=%d&w=150&h=150"):format(p10)
end
return v_u_1