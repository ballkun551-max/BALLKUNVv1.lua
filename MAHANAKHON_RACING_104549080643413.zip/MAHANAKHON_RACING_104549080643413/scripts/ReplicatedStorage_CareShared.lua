-- Path: ReplicatedStorage/CareShared
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_14 = {
	["REMOTE"] = "Care",
	["FUEL_PRICE"] = 5,
	["REPAIR_PRICE"] = 20,
	["PUMP_TAG"] = "FuelPump",
	["PUMP_REACH"] = 18,
	["PLAYER_REACH"] = 14,
	["LOW_FUEL"] = 15,
	["HALF_POWER_BELOW"] = 50,
	["SMOKE_BELOW"] = 35,
	["fuel"] = function(p1) -- name: fuel
		if p1 then
			p1 = p1:GetAttribute("Fuel")
		end
		return typeof(p1) ~= "number" and 100 or math.clamp(p1, 0, 100)
	end,
	["health"] = function(p2) -- name: health
		if p2 then
			p2 = p2:GetAttribute("EngineHealth")
		end
		return typeof(p2) ~= "number" and 100 or math.clamp(p2, 0, 100)
	end,
	["CRASH_BIKE"] = 6,
	["CRASH_CAR"] = 5,
	["CRASH_FULL_KMH"] = 100,
	["damage"] = function(p3, p4) -- name: damage
		-- upvalues: (copy) v_u_14
		if p3 and p4 > 0 then
			local v5 = v_u_14.health(p3) - p4
			p3:SetAttribute("EngineHealth", (math.max(0, v5)))
		end
	end,
	["healthPower"] = function(p6) -- name: healthPower
		-- upvalues: (copy) v_u_14
		local v7 = v_u_14.health(p6)
		return v_u_14.HALF_POWER_BELOW <= v7 and 1 or 0.5 + 0.5 * v7 / v_u_14.HALF_POWER_BELOW
	end,
	["FULL_SPEED_ABOVE"] = 80,
	["healthTop"] = function(p8) -- name: healthTop
		-- upvalues: (copy) v_u_14
		local v9 = v_u_14.health(p8)
		return v_u_14.FULL_SPEED_ABOVE <= v9 and 1 or 0.5 + 0.5 * v9 / v_u_14.FULL_SPEED_ABOVE
	end,
	["fuelCost"] = function(p10) -- name: fuelCost
		-- upvalues: (copy) v_u_14
		local v11 = math.max(0, p10) * v_u_14.FUEL_PRICE
		return math.ceil(v11)
	end,
	["repairCost"] = function(p12) -- name: repairCost
		-- upvalues: (copy) v_u_14
		local v13 = (100 - v_u_14.health(p12)) * v_u_14.REPAIR_PRICE
		return math.ceil(v13)
	end
}
return v_u_14