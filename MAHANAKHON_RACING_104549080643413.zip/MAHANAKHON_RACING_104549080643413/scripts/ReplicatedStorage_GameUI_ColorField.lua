-- Path: ReplicatedStorage/GameUI/ColorField
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = require(game:GetService("ReplicatedStorage"):WaitForChild("UiOwn")).Instance
local v_u_2 = game:GetService("Players")
local v_u_3 = game:GetService("UserInputService")
local v_u_4 = {}
v_u_4.__index = v_u_4
function v_u_4.new(p5, p_u_6) -- name: new
	-- upvalues: (copy) v_u_4, (copy) v_u_1, (copy) v_u_3, (copy) v_u_2
	local v7 = v_u_4
	local v_u_8 = setmetatable({
		["h"] = 0,
		["s"] = 1,
		["v"] = 1,
		["mode"] = nil,
		["opts"] = nil,
		["opts"] = p_u_6
	}, v7)
	local v9 = {
		["Name"] = "ColorField",
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["Position"] = p_u_6.position,
		["Size"] = p_u_6.size
	}
	local v10 = v_u_1.new("Frame")
	v10.BorderSizePixel = 0
	for v11, v12 in v9 do
		v10[v11] = v12
	end
	v10.Parent = p5
	v_u_8.root = v10
	local v_u_13 = v_u_1.new("TextButton")
	v_u_13.Name = "Square"
	v_u_13.Text = ""
	v_u_13.AutoButtonColor = false
	v_u_13.BorderSizePixel = 0
	v_u_13:SetAttribute("SkinSkip", true)
	v_u_13.Parent = v10
	v_u_13.Size = UDim2.new(1, 0, 1, -34)
	v_u_13.BackgroundColor3 = Color3.fromHSV(0, 1, 1)
	local v14 = v_u_1.new("UICorner")
	v14.CornerRadius = UDim.new(0, 10)
	v14.Parent = v_u_13
	local v15 = {
		["Name"] = "White",
		["BackgroundColor3"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = Color3.new(1, 1, 1),
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v16 = v_u_1.new("Frame")
	v16.BorderSizePixel = 0
	for v17, v18 in v15 do
		v16[v17] = v18
	end
	v16.Parent = v_u_13
	local v19 = v_u_1.new("UICorner")
	v19.CornerRadius = UDim.new(0, 10)
	v19.Parent = v16
	local v20 = v_u_1.new("UIGradient")
	v20.Transparency = NumberSequence.new(0, 1)
	v20.Parent = v16
	local v21 = {
		["Name"] = "Black",
		["BackgroundColor3"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = Color3.new(0, 0, 0),
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v22 = v_u_1.new("Frame")
	v22.BorderSizePixel = 0
	for v23, v24 in v21 do
		v22[v23] = v24
	end
	v22.Parent = v_u_13
	local v25 = v_u_1.new("UICorner")
	v25.CornerRadius = UDim.new(0, 10)
	v25.Parent = v22
	local v26 = v_u_1.new("UIGradient")
	v26.Rotation = 90
	v26.Transparency = NumberSequence.new(1, 0)
	v26.Parent = v22
	local v27 = {
		["Name"] = "Dot",
		["AnchorPoint"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Size"] = UDim2.fromOffset(22, 22),
		["BackgroundColor3"] = Color3.new(1, 0, 0)
	}
	local v28 = v_u_1.new("Frame")
	v28.BorderSizePixel = 0
	for v29, v30 in v27 do
		v28[v29] = v30
	end
	v28.Parent = v_u_13
	local v31 = v_u_1.new("UICorner")
	v31.CornerRadius = UDim.new(0, 11)
	v31.Parent = v28
	local v32 = v_u_1.new("UIStroke")
	v32.Color = Color3.new(1, 1, 1)
	v32.Thickness = 3
	v32.Parent = v28
	local v_u_33 = v_u_1.new("TextButton")
	v_u_33.Name = "Hue"
	v_u_33.Text = ""
	v_u_33.AutoButtonColor = false
	v_u_33.BorderSizePixel = 0
	v_u_33:SetAttribute("SkinSkip", true)
	v_u_33.Parent = v10
	v_u_33.AnchorPoint = Vector2.new(0, 1)
	v_u_33.Position = UDim2.fromScale(0, 1)
	v_u_33.Size = UDim2.new(1, 0, 0, 22)
	v_u_33.BackgroundColor3 = Color3.new(1, 1, 1)
	local v34 = v_u_1.new("UICorner")
	v34.CornerRadius = UDim.new(0, 11)
	v34.Parent = v_u_33
	local v35 = {}
	for v36 = 0, 6 do
		local v37 = ColorSequenceKeypoint.new
		local v38 = v36 / 6
		local v39 = Color3.fromHSV
		local v40 = v36 / 6 % 1
		table.insert(v35, v37(v38, v39(v40, 1, 1)))
	end
	local v41 = v_u_1.new("UIGradient")
	v41.Color = ColorSequence.new(v35)
	v41.Parent = v_u_33
	local v42 = {
		["Name"] = "Dot",
		["AnchorPoint"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Size"] = UDim2.fromOffset(28, 28),
		["BackgroundColor3"] = Color3.new(1, 0, 0)
	}
	local v43 = v_u_1.new("Frame")
	v43.BorderSizePixel = 0
	for v44, v45 in v42 do
		v43[v44] = v45
	end
	v43.Parent = v_u_33
	local v46 = v_u_1.new("UICorner")
	v46.CornerRadius = UDim.new(0, 14)
	v46.Parent = v43
	local v47 = v_u_1.new("UIStroke")
	v47.Color = Color3.new(1, 1, 1)
	v47.Thickness = 3
	v47.Parent = v43
	v_u_8.square = v_u_13
	v_u_8.dot = v28
	v_u_8.hue = v_u_33
	v_u_8.hueDot = v43
	local function v_u_60(p48) -- name: track
		-- upvalues: (copy) v_u_8, (copy) v_u_13, (copy) v_u_33, (copy) p_u_6
		local v49 = Vector2.new(p48.X, p48.Y)
		if v_u_8.mode == "square" then
			local v50 = v_u_13.AbsolutePosition
			local v51 = v_u_13.AbsoluteSize
			local v52 = v_u_8
			local v53 = (v49.X - v50.X) / v51.X
			v52.s = math.clamp(v53, 0, 1)
			local v54 = v_u_8
			local v55 = (v49.Y - v50.Y) / v51.Y
			v54.v = 1 - math.clamp(v55, 0, 1)
		elseif v_u_8.mode == "hue" then
			local v56 = v_u_33.AbsolutePosition
			local v57 = v_u_33.AbsoluteSize
			local v58 = v_u_8
			local v59 = (v49.X - v56.X) / v57.X
			v58.h = math.clamp(v59, 0, 0.999)
		end
		v_u_8:set(v_u_8.h, v_u_8.s, v_u_8.v)
		if p_u_6.onChange then
			p_u_6.onChange(v_u_8.h, v_u_8.s, v_u_8.v)
		end
	end
	local v_u_61 = "square"
	v_u_13.InputBegan:Connect(function(p62)
		-- upvalues: (copy) v_u_8, (copy) v_u_61, (copy) v_u_60
		if p62.UserInputType == Enum.UserInputType.MouseButton1 or p62.UserInputType == Enum.UserInputType.Touch then
			v_u_8.mode = v_u_61
			v_u_60(p62.Position)
		end
	end)
	local v_u_63 = "hue"
	v_u_33.InputBegan:Connect(function(p64)
		-- upvalues: (copy) v_u_8, (copy) v_u_63, (copy) v_u_60
		if p64.UserInputType == Enum.UserInputType.MouseButton1 or p64.UserInputType == Enum.UserInputType.Touch then
			v_u_8.mode = v_u_63
			v_u_60(p64.Position)
		end
	end)
	v_u_3.InputChanged:Connect(function(p65)
		-- upvalues: (copy) v_u_8, (copy) v_u_60
		if v_u_8.mode and (p65.UserInputType == Enum.UserInputType.MouseMovement or p65.UserInputType == Enum.UserInputType.Touch) then
			v_u_60(p65.Position)
		end
	end)
	v_u_3.InputEnded:Connect(function(p66)
		-- upvalues: (copy) v_u_8, (copy) p_u_6
		if v_u_8.mode and (p66.UserInputType == Enum.UserInputType.MouseButton1 or p66.UserInputType == Enum.UserInputType.Touch) then
			v_u_8.mode = nil
			if p_u_6.onRelease then
				p_u_6.onRelease(v_u_8.h, v_u_8.s, v_u_8.v)
			end
		end
	end)
	return v_u_8
end
function v_u_4.set(p67, p68, p69, p70) -- name: set
	p67.h = p68
	p67.s = p69
	p67.v = p70
	p67.square.BackgroundColor3 = Color3.fromHSV(p68, 1, 1)
	p67.dot.Position = UDim2.fromScale(p69, 1 - p70)
	p67.dot.BackgroundColor3 = Color3.fromHSV(p68, p69, p70)
	p67.hueDot.Position = UDim2.fromScale(p68, 0.5)
	p67.hueDot.BackgroundColor3 = Color3.fromHSV(p68, 1, 1)
end
return v_u_4