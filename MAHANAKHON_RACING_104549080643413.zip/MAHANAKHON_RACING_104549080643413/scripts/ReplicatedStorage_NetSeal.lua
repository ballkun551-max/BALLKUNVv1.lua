-- Path: ReplicatedStorage/NetSeal
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v1 = game:GetService("Players")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("RunService")
local v_u_4 = require(v_u_2:WaitForChild("GameShared"))
local v5 = {}
local function v_u_16(p6) -- name: nameHash
	local v7 = 2166136261
	for v8 = 1, #p6 do
		local v9 = string.byte
		local v10 = bit32.bxor(v7, v9(p6, v8))
		local v11 = bit32.band(v10, 65535)
		local v12 = bit32.rshift(v10, 16)
		local v13 = v11 * 16777619
		local v14 = v12 * 16777619
		local v15 = bit32.band(v14, 65535)
		v7 = (v13 + bit32.lshift(v15, 16)) % 4294967296
	end
	return v7
end
local function v_u_57(p17, p18, p19, p20) -- name: scramble
	local v21 = p18[1]
	local v22 = bit32.band(p20, 65535)
	local v23 = bit32.rshift(p20, 16)
	local v24 = v22 * 2654435761
	local v25 = v23 * 2654435761
	local v26 = bit32.band(v25, 65535)
	local v27 = (v24 + bit32.lshift(v26, 16)) % 4294967296
	local v28 = bit32.bxor(v21, p19, v27)
	local v29 = bit32.rshift(v28, 16)
	local v30 = bit32.bxor(v28, v29)
	local v31 = bit32.band(v30, 65535)
	local v32 = bit32.rshift(v30, 16)
	local v33 = v31 * 2246822507
	local v34 = v32 * 2246822507
	local v35 = bit32.band(v34, 65535)
	local v36 = (v33 + bit32.lshift(v35, 16)) % 4294967296
	local v37 = bit32.rshift(v36, 13)
	local v38 = bit32.bxor(v36, v37)
	local v39 = bit32.band(v38, 65535)
	local v40 = bit32.rshift(v38, 16)
	local v41 = v39 * 3266489909
	local v42 = v40 * 3266489909
	local v43 = bit32.band(v42, 65535)
	local v44 = (v41 + bit32.lshift(v43, 16)) % 4294967296
	local v45 = bit32.rshift(v44, 16)
	local v46 = bit32.bxor(v44, v45)
	local v47 = v46 == 0 and 1831565813 or v46
	for v48 = 0, buffer.len(p17) - 1 do
		local v49 = bit32.lshift(v47, 13)
		local v50 = bit32.bxor(v47, v49)
		local v51 = bit32.rshift(v50, 17)
		local v52 = bit32.bxor(v50, v51)
		local v53 = bit32.lshift(v52, 5)
		v47 = bit32.bxor(v52, v53)
		local v54 = buffer.readu8(p17, v48)
		local v55 = bit32.band(v47, 255)
		local v56 = bit32.bxor(v54, v55)
		buffer.writeu8(p17, v48, v56)
	end
end
local function v_u_118(p58, p59, p60, p61) -- name: sign
	local v62 = p59[2]
	local v63 = bit32.bxor(v62, p60)
	local v64 = bit32.bxor(v63, p61)
	local v65 = bit32.rshift(v64, 16)
	local v66 = bit32.bxor(v64, v65)
	local v67 = bit32.band(v66, 65535)
	local v68 = bit32.rshift(v66, 16)
	local v69 = v67 * 2246822507
	local v70 = v68 * 2246822507
	local v71 = bit32.band(v70, 65535)
	local v72 = (v69 + bit32.lshift(v71, 16)) % 4294967296
	local v73 = bit32.rshift(v72, 13)
	local v74 = bit32.bxor(v72, v73)
	local v75 = bit32.band(v74, 65535)
	local v76 = bit32.rshift(v74, 16)
	local v77 = v75 * 3266489909
	local v78 = v76 * 3266489909
	local v79 = bit32.band(v78, 65535)
	local v80 = (v77 + bit32.lshift(v79, 16)) % 4294967296
	local v81 = bit32.rshift(v80, 16)
	local v82 = bit32.bxor(v80, v81)
	for v83 = 0, buffer.len(p58) - 1 do
		local v84 = buffer.readu8(p58, v83)
		local v85 = bit32.bxor(v82, v84)
		local v86 = bit32.band(v85, 65535)
		local v87 = bit32.rshift(v85, 16)
		local v88 = v86 * 16777619
		local v89 = v87 * 16777619
		local v90 = bit32.band(v89, 65535)
		v82 = (v88 + bit32.lshift(v90, 16)) % 4294967296
	end
	local v91 = p59[3]
	local v92 = buffer.len(p58)
	local v93 = p59[4]
	local v94 = bit32.band(v92, 65535)
	local v95 = bit32.rshift(v92, 16)
	local v96 = v94 * v93
	local v97 = v95 * v93
	local v98 = bit32.band(v97, 65535)
	local v99 = (v96 + bit32.lshift(v98, 16)) % 4294967296
	local v100 = bit32.bxor(v82, v91, v99)
	local v101 = bit32.rshift(v100, 16)
	local v102 = bit32.bxor(v100, v101)
	local v103 = bit32.band(v102, 65535)
	local v104 = bit32.rshift(v102, 16)
	local v105 = v103 * 2246822507
	local v106 = v104 * 2246822507
	local v107 = bit32.band(v106, 65535)
	local v108 = (v105 + bit32.lshift(v107, 16)) % 4294967296
	local v109 = bit32.rshift(v108, 13)
	local v110 = bit32.bxor(v108, v109)
	local v111 = bit32.band(v110, 65535)
	local v112 = bit32.rshift(v110, 16)
	local v113 = v111 * 3266489909
	local v114 = v112 * 3266489909
	local v115 = bit32.band(v114, 65535)
	local v116 = (v113 + bit32.lshift(v115, 16)) % 4294967296
	local v117 = bit32.rshift(v116, 16)
	return bit32.bxor(v116, v117)
end
local v_u_119 = {}
v_u_119.__index = v_u_119
local function v_u_122() -- name: newWriter
	-- upvalues: (copy) v_u_119
	local v120 = {
		["b"] = nil,
		["at"] = 0,
		["items"] = 0,
		["instances"] = nil,
		["b"] = buffer.create(64),
		["instances"] = {}
	}
	local v121 = v_u_119
	return setmetatable(v120, v121)
end
function v_u_119.room(p123, p124) -- name: room
	local v125 = buffer.len(p123.b)
	if v125 < p123.at + p124 then
		repeat
			v125 = v125 * 2
		until p123.at + p124 <= v125
		local v126 = buffer.create(v125)
		buffer.copy(v126, 0, p123.b, 0, p123.at)
		p123.b = v126
	end
end
function v_u_119.u8(p127, p128) -- name: u8
	p127:room(1)
	local v129 = p127.b
	local v130 = p127.at
	buffer.writeu8(v129, v130, p128)
	p127.at = p127.at + 1
end
function v_u_119.u16(p131, p132) -- name: u16
	p131:room(2)
	local v133 = p131.b
	local v134 = p131.at
	buffer.writeu16(v133, v134, p132)
	p131.at = p131.at + 2
end
function v_u_119.i32(p135, p136) -- name: i32
	p135:room(4)
	local v137 = p135.b
	local v138 = p135.at
	buffer.writei32(v137, v138, p136)
	p135.at = p135.at + 4
end
function v_u_119.f32(p139, p140) -- name: f32
	p139:room(4)
	local v141 = p139.b
	local v142 = p139.at
	buffer.writef32(v141, v142, p140)
	p139.at = p139.at + 4
end
function v_u_119.f64(p143, p144) -- name: f64
	p143:room(8)
	local v145 = p143.b
	local v146 = p143.at
	buffer.writef64(v145, v146, p144)
	p143.at = p143.at + 8
end
function v_u_119.str(p147, p148) -- name: str
	local v149 = #p148 <= 65535
	assert(v149, "NetSeal: string too long")
	p147:u16(#p148)
	p147:room(#p148)
	buffer.writestring(p147.b, p147.at, p148)
	p147.at = p147.at + #p148
end
local function v_u_168(p150, p151, p152) -- name: writeValue
	-- upvalues: (copy) v_u_168
	p150.items = p150.items + 1
	local v153 = p150.items <= 4096
	assert(v153, "NetSeal: too many values")
	local v154 = typeof(p151)
	if p151 == nil then
		p150:u8(0)
		return
	elseif v154 == "boolean" then
		p150:u8(p151 and 2 or 1)
		return
	elseif v154 == "number" then
		p150:u8(3)
		p150:f64(p151)
		return
	elseif v154 == "string" then
		p150:u8(4)
		p150:str(p151)
		return
	elseif v154 == "Vector3" then
		p150:u8(5)
		p150:f32(p151.X)
		p150:f32(p151.Y)
		p150:f32(p151.Z)
		return
	elseif v154 == "Vector2" then
		p150:u8(6)
		p150:f32(p151.X)
		p150:f32(p151.Y)
		return
	elseif v154 == "CFrame" then
		p150:u8(7)
		for _, v155 in { p151:GetComponents() } do
			p150:f32(v155)
		end
		return
	elseif v154 == "Color3" then
		p150:u8(8)
		p150:f32(p151.R)
		p150:f32(p151.G)
		p150:f32(p151.B)
		return
	elseif v154 == "UDim2" then
		p150:u8(9)
		p150:f32(p151.X.Scale)
		p150:i32(p151.X.Offset)
		p150:f32(p151.Y.Scale)
		p150:i32(p151.Y.Offset)
		return
	elseif v154 == "BrickColor" then
		p150:u8(10)
		p150:u16(p151.Number)
		return
	elseif v154 == "EnumItem" then
		p150:u8(11)
		local v156 = p151.EnumType
		p150:str(tostring(v156) .. "." .. p151.Name)
		return
	elseif v154 == "Instance" then
		local v157 = table.find(p150.instances, p151)
		if not v157 then
			local v158 = p150.instances
			table.insert(v158, p151)
			v157 = #p150.instances
			local v159 = v157 <= 64
			assert(v159, "NetSeal: too many instances")
		end
		p150:u8(13)
		p150:u8(v157)
		return
	elseif v154 == "table" then
		local v160 = p152 < 8
		assert(v160, "NetSeal: tables nested too deep")
		local v161 = 0
		for _ in p151 do
			v161 = v161 + 1
		end
		local v162 = v161 <= 65535
		assert(v162, "NetSeal: table too big")
		p150:u8(12)
		p150:u16(v161)
		for v163, v164 in p151 do
			local v165 = type(v163)
			local v166 = (v165 == "string" or v165 == "number") and true or v165 == "boolean"
			local v167 = "NetSeal: can\'t send a " .. v165 .. " key"
			assert(v166, v167)
			v_u_168(p150, v163, p152 + 1)
			v_u_168(p150, v164, p152 + 1)
		end
	else
		error("NetSeal: can\'t send a " .. v154)
	end
end
local function v_u_176(...) -- name: encode
	-- upvalues: (copy) v_u_122, (copy) v_u_168
	local v169 = select("#", ...)
	local v170 = v169 <= 32
	assert(v170, "NetSeal: too many values")
	local v171 = v_u_122()
	v171:u8(0)
	v171:u8(v169)
	for v172 = 1, v169 do
		v_u_168(v171, select(v172, ...), 0)
	end
	local v173 = v171.b
	local v174 = #v171.instances
	buffer.writeu8(v173, 0, v174)
	local v175 = buffer.create(v171.at)
	buffer.copy(v175, 0, v171.b, 0, v171.at)
	return v175, v171.instances
end
local function v_u_232(p177, p178) -- name: readValue
	-- upvalues: (copy) v_u_232
	p177.items = p177.items + 1
	if p177.items > 4096 then
		error("items")
	end
	local v179 = p177.b
	local v180 = p177.at
	local v181 = buffer.readu8(v179, v180)
	p177.at = p177.at + 1
	if v181 == 0 then
		return nil
	end
	if v181 == 1 then
		return false
	end
	if v181 == 2 then
		return true
	end
	if v181 == 3 then
		local v182 = p177.at
		local v183 = buffer.readf64(v179, v182)
		p177.at = p177.at + 8
		if v183 ~= v183 then
			error("nan")
		end
		return v183
	end
	if v181 == 4 or v181 == 11 then
		local v184 = p177.at
		local v185 = buffer.readu16(v179, v184)
		local v186 = buffer.readstring(v179, p177.at + 2, v185)
		p177.at = p177.at + (v185 + 2)
		if v181 == 4 then
			return v186
		end
		local v_u_187, v_u_188 = v186:match("^([%w_]+)%.([%w_]+)$")
		local v189, v190 = pcall(function()
			-- upvalues: (copy) v_u_187, (copy) v_u_188
			return Enum[v_u_187][v_u_188]
		end)
		if not v189 or typeof(v190) ~= "EnumItem" then
			error("enum")
		end
		return v190
	end
	if v181 == 5 then
		local v191 = p177.at
		local v192 = buffer.readf32(v179, v191)
		local v193 = p177.at + 4
		local v194 = buffer.readf32(v179, v193)
		local v195 = p177.at + 8
		local v196 = buffer.readf32(v179, v195)
		local v197 = Vector3.new(v192, v194, v196)
		p177.at = p177.at + 12
		return v197
	end
	if v181 == 6 then
		local v198 = Vector2.new
		local v199 = p177.at
		local v200 = buffer.readf32(v179, v199)
		local v201 = p177.at + 4
		local v202 = v198(v200, (buffer.readf32(v179, v201)))
		p177.at = p177.at + 8
		return v202
	end
	if v181 == 7 then
		local v203 = table.create(12)
		for v204 = 1, 12 do
			local v205 = p177.at + (v204 - 1) * 4
			v203[v204] = buffer.readf32(v179, v205)
		end
		p177.at = p177.at + 48
		return CFrame.new(table.unpack(v203))
	end
	if v181 == 8 then
		local v206 = Color3.new
		local v207 = p177.at
		local v208 = buffer.readf32(v179, v207)
		local v209 = p177.at + 4
		local v210 = buffer.readf32(v179, v209)
		local v211 = p177.at + 8
		local v212 = v206(v208, v210, (buffer.readf32(v179, v211)))
		p177.at = p177.at + 12
		return v212
	end
	if v181 == 9 then
		local v213 = UDim2.new
		local v214 = p177.at
		local v215 = buffer.readf32(v179, v214)
		local v216 = p177.at + 4
		local v217 = buffer.readi32(v179, v216)
		local v218 = p177.at + 8
		local v219 = buffer.readf32(v179, v218)
		local v220 = p177.at + 12
		local v221 = v213(v215, v217, v219, (buffer.readi32(v179, v220)))
		p177.at = p177.at + 16
		return v221
	end
	if v181 == 10 then
		local v222 = BrickColor.new
		local v223 = p177.at
		local v224 = v222((buffer.readu16(v179, v223)))
		p177.at = p177.at + 2
		return v224
	end
	if v181 == 13 then
		local v225 = p177.at
		local v226 = buffer.readu8(v179, v225)
		p177.at = p177.at + 1
		if v226 < 1 or p177.instanceCount < v226 then
			error("instance")
		end
		return p177.instances[v226]
	end
	if v181 == 12 then
		if p178 >= 8 then
			error("depth")
		end
		local v227 = p177.at
		local v228 = buffer.readu16(v179, v227)
		p177.at = p177.at + 2
		local v229 = {}
		for _ = 1, v228 do
			local v230 = v_u_232(p177, p178 + 1)
			local v231 = type(v230)
			if v231 ~= "string" and (v231 ~= "number" and v231 ~= "boolean") then
				error("key")
			end
			v229[v230] = v_u_232(p177, p178 + 1)
		end
		return v229
	end
	error("type")
end
local function v_u_244(p_u_233, p234) -- name: decode
	-- upvalues: (copy) v_u_232
	local v_u_235 = {
		["b"] = nil,
		["at"] = 2,
		["items"] = 0,
		["instances"] = nil,
		["instanceCount"] = 0,
		["b"] = p_u_233,
		["instances"] = p234
	}
	local function v241()
		-- upvalues: (copy) v_u_235, (copy) p_u_233, (ref) v_u_232
		local v236 = p_u_233
		v_u_235.instanceCount = buffer.readu8(v236, 0)
		local v237 = p_u_233
		local v238 = buffer.readu8(v237, 1)
		if v238 > 32 or v_u_235.instanceCount > 64 then
			error("count")
		end
		local v239 = {
			["n"] = v238
		}
		for v240 = 1, v238 do
			v239[v240] = v_u_232(v_u_235, 0)
		end
		return v239
	end
	local v242, v243 = pcall(v241)
	if v242 and v_u_235.at == buffer.len(p_u_233) then
		return v243
	else
		return nil
	end
end
local function v246(p245) -- name: readKey
	return {
		buffer.readu32(p245, 0),
		buffer.readu32(p245, 4),
		buffer.readu32(p245, 8),
		(buffer.readu32(p245, 12))
	}
end
local function v_u_257(p247, p248, p249, ...) -- name: seal
	-- upvalues: (copy) v_u_16, (copy) v_u_176, (copy) v_u_118, (copy) v_u_57
	local v250 = v_u_16(p248)
	local v251, v252 = v_u_176(...)
	local v253 = buffer.len(v251)
	local v254 = buffer.create(12 + v253)
	buffer.writeu32(v254, 0, p249)
	buffer.writeu32(v254, 4, v253)
	local v255 = 8 + v253
	local v256 = v_u_118(v251, p247, v250, p249)
	buffer.writeu32(v254, v255, v256)
	v_u_57(v251, p247, v250, p249)
	buffer.copy(v254, 8, v251, 0, v253)
	return v254, v252
end
local function v_u_272(p258, p259, p260, p261, p262, p263) -- name: unseal
	-- upvalues: (copy) v_u_16, (copy) v_u_57, (copy) v_u_118, (copy) v_u_244
	if typeof(p260) == "buffer" then
		local v264 = buffer.len(p260)
		if v264 < 14 or v264 > 262144 then
			return nil, "size " .. v264
		else
			local v265 = buffer.readu32(p260, 0)
			local v266 = buffer.readu32(p260, 4)
			if v266 + 12 == v264 then
				if v265 == p261 and p262 ~= nil then
					if buffer.tostring(p260) ~= p262 then
						return nil, ("number %d again"):format(v265)
					end
				elseif v265 <= p261 or p261 + 100000 < v265 then
					return nil, ("number %d after %d"):format(v265, p261)
				end
				local v267 = v_u_16(p259)
				local v268 = buffer.create(v266)
				buffer.copy(v268, 0, p260, 8, v266)
				v_u_57(v268, p258, v267, v265)
				local v269 = v_u_118(v268, p258, v267, v265)
				local v270 = v266 + 8
				if v269 == buffer.readu32(p260, v270) then
					local v271 = v_u_244(v268, p263)
					if v271 then
						return v271, v265
					else
						return nil, "body"
					end
				else
					return nil, "signature"
				end
			else
				return nil, "length"
			end
		end
	else
		return nil, "plain " .. typeof(p260)
	end
end
if v_u_3:IsServer() then
	local v273 = game:GetService("ServerStorage")
	local v_u_274 = require(v273:WaitForChild("AntiCheat"))
	local v_u_275 = require(v273:WaitForChild("SealDesk"))
	v_u_275.init({
		["unseal"] = v_u_272,
		["readKey"] = v246
	})
	local v_u_276 = Random.new()
	local v_u_277 = {}
	local function v_u_284(p278) -- name: session
		-- upvalues: (copy) v_u_277, (copy) v_u_276
		local v279 = v_u_277[p278]
		if not v279 and p278.Parent then
			local v280 = buffer.create(16)
			for v281 = 0, 3 do
				local v282 = v281 * 4
				local v283 = v_u_276:NextInteger(0, 4294967295)
				buffer.writeu32(v280, v282, v283)
			end
			v279 = {
				["key"] = {
					buffer.readu32(v280, 0),
					buffer.readu32(v280, 4),
					buffer.readu32(v280, 8),
					(buffer.readu32(v280, 12))
				},
				["keyBuffer"] = v280,
				["last"] = {},
				["lastBytes"] = {},
				["bad"] = {}
			}
			v_u_277[p278] = v279
		end
		return v279
	end
	local function v_u_292(p285, p286, p287, p288) -- name: bad
		-- upvalues: (copy) v_u_274
		local v289 = os.clock()
		local v290 = {}
		for _, v291 in p286.bad do
			if v289 - v291 >= 60 then
				continue
			end
			table.insert(v290, v291)
		end
		table.insert(v290, v289)
		p286.bad = v290
		warn(("NetSeal: %s sent %s a call that doesn\'t open (%s); %d in %ds"):format(p285.Name, p287.Name, p288, #v290, 60))
		if #v290 >= 5 and not p286.kicked then
			p286.kicked = true
			v_u_274.caught(p285, "remote")
			p285:Kick("\224\184\163\224\184\176\224\184\154\224\184\154\224\184\149\224\184\163\224\184\167\224\184\136\224\184\158\224\184\154\224\184\129\224\184\178\224\184\163\224\185\128\224\184\163\224\184\181\224\184\162\224\184\129\224\184\163\224\184\176\224\184\154\224\184\154\224\184\130\224\184\173\224\184\135\224\185\128\224\184\129\224\184\161\224\184\151\224\184\181\224\185\136\224\185\132\224\184\161\224\185\136\224\185\132\224\184\148\224\185\137\224\184\161\224\184\178\224\184\136\224\184\178\224\184\129\224\184\149\224\184\177\224\184\167\224\185\128\224\184\129\224\184\161 (\224\185\130\224\184\155\224\184\163\224\184\162\224\184\180\224\184\135 remote)\nCalls to the game that didn\'t come from the game itself were detected.")
		end
	end
	local function v_u_300(p293, p294, p295, ...) -- name: openValues
		-- upvalues: (copy) v_u_284, (copy) v_u_272, (copy) v_u_275, (copy) v_u_292
		if typeof(p293) ~= "Instance" or not p293:IsA("Player") then
			return nil
		end
		local v296 = v_u_284(p293)
		if not v296 then
			return nil
		end
		local v297 = p294.Name
		local v298, v299 = v_u_272(v296.key, v297, p295, v296.last[v297] or 0, v296.lastBytes[v297], { ... })
		if v298 then
			if v299 ~= v296.last[v297] then
				v296.last[v297] = v299
				v296.lastBytes[v297] = buffer.tostring(p295)
			end
			return v298
		end
		if v_u_275.failed(p293, v296, p294, p295, { ... }) then
			return nil
		end
		v_u_292(p293, v296, p294, v299)
		return nil
	end
	function v5.open(p301, p302, p303, ...) -- name: open
		-- upvalues: (copy) v_u_300
		local v304 = v_u_300(p301, p302, p303, ...)
		if not v304 then
			return false
		end
		local v305 = v304.n
		return true, table.unpack(v304, 1, v305)
	end
	function v5.server(p_u_306) -- name: server
		-- upvalues: (copy) v_u_300
		local v313 = {
			["OnServerEvent"] = {
				["Connect"] = function(_, p_u_307) -- name: Connect
					-- upvalues: (copy) p_u_306, (ref) v_u_300
					return p_u_306.OnServerEvent:Connect(function(p308, p309, ...)
						-- upvalues: (ref) v_u_300, (ref) p_u_306, (copy) p_u_307
						local v310 = v_u_300(p308, p_u_306, p309, ...)
						if v310 then
							local v311 = p_u_307
							local v312 = v310.n
							v311(p308, table.unpack(v310, 1, v312))
						end
					end)
				end
			}
		}
		local v322 = {
			["__newindex"] = function(_, p314, p_u_315) -- name: __newindex
				-- upvalues: (copy) p_u_306, (ref) v_u_300
				local v316 = p314 == "OnServerInvoke"
				assert(v316, "NetSeal.server: only OnServerInvoke can be set")
				function p_u_306.OnServerInvoke(p317, p318, ...)
					-- upvalues: (ref) v_u_300, (ref) p_u_306, (copy) p_u_315
					local v319 = v_u_300(p317, p_u_306, p318, ...)
					if not v319 then
						return false
					end
					local v320 = p_u_315
					local v321 = v319.n
					return v320(p317, table.unpack(v319, 1, v321))
				end
			end
		}
		return setmetatable(v313, v322)
	end
	task.spawn(function()
		-- upvalues: (copy) v_u_2, (copy) v_u_4, (copy) v_u_284, (copy) v_u_275
		local v323 = v_u_2:WaitForChild(v_u_4.REMOTES)
		local v324 = v323:FindFirstChild("Session") or Instance.new("RemoteFunction")
		v324.Name = "Session"
		function v324.OnServerInvoke(p325)
			-- upvalues: (ref) v_u_284, (ref) v_u_275
			local v326 = v_u_284(p325)
			if v326 then
				v326 = v_u_275.hand(p325, v326)
			end
			return v326
		end
		v324.Parent = v323
	end)
	v1.PlayerRemoving:Connect(function(p327)
		-- upvalues: (copy) v_u_277
		v_u_277[p327] = nil
	end)
	return v5
end
local v_u_328 = nil
local v_u_329 = false
local v_u_330 = {}
local function v_u_335() -- name: clientKey
	-- upvalues: (ref) v_u_328, (ref) v_u_329, (copy) v_u_2, (copy) v_u_4
	while not v_u_328 do
		if v_u_329 then
			task.wait()
		else
			v_u_329 = true
			local v331 = v_u_2:WaitForChild(v_u_4.REMOTES):WaitForChild("Session")
			local v332 = v331.InvokeServer
			local v333, v334 = pcall(v332, v331)
			if v333 and (typeof(v334) == "buffer" and buffer.len(v334) == 16) then
				v_u_328 = {
					buffer.readu32(v334, 0),
					buffer.readu32(v334, 4),
					buffer.readu32(v334, 8),
					(buffer.readu32(v334, 12))
				}
			end
			v_u_329 = false
			if v_u_328 then
				continue
			end
			task.wait(1)
		end
	end
	return v_u_328
end
task.spawn(v_u_335)
local function v_u_339(p336, ...) -- name: sealFor
	-- upvalues: (copy) v_u_335, (copy) v_u_330, (copy) v_u_257
	local v337 = v_u_335()
	local v338 = (v_u_330[p336.Name] or 0) + 1
	v_u_330[p336.Name] = v338
	return v_u_257(v337, p336.Name, v338, ...)
end
local v_u_340 = false
local v_u_341 = 0
local v_u_342 = {}
local v_u_343 = {}
local v_u_344 = {}
local v_u_345 = false
local v_u_346 = debug.info(1, "s")
local v_u_347 = false
local function v_u_350() -- name: rootless
	-- upvalues: (copy) v_u_346
	for v348 = 2, 64 do
		local v349 = debug.info(v348, "s")
		if v349 == nil then
			return true
		end
		if v349 == "[C]" or v349 == v_u_346 then
			continue
		end
		return false
	end
	return false
end
local function v_u_360() -- name: outsideCaller
	-- upvalues: (copy) v_u_3, (copy) v_u_346, (copy) v_u_342, (copy) v_u_2, (copy) v_u_343
	if v_u_3:IsStudio() and workspace:GetAttribute("ZZGuardOn") ~= true then
		return nil
	end
	local v351 = v_u_3:IsStudio() and workspace:GetAttribute("ZZPretendElevated") == true and true or pcall(function()
		return game:GetService("CoreGui"):GetChildren()
	end)
	local v352 = nil
	local v353 = nil
	local v354 = nil
	for v355 = 2, 64 do
		local v356 = debug.info(v355, "s")
		if v356 == nil then
			break
		end
		if v356 ~= "[C]" and v356 ~= v_u_346 then
			v352 = v352 or v356
		end
		if v356 == "[C]" or v_u_342[v356] then
			continue
		end
		local v357 = v353 or require(v_u_2:WaitForChild("UiGuardShared"))
		local v358 = v_u_3:IsStudio()
		if v358 then
			v358 = workspace:GetAttribute("ZZPretendChunk")
		end
		if v357.isChunk(v356) or type(v358) == "string" and (v358 ~= "" and string.find(v356, v358, 1, true)) then
			return v356, true, true
		end
		if not v351 and v_u_343[v356] then
			return nil
		end
		v354 = v354 or require(v_u_2:WaitForChild("UiOwn"))
		v353 = v357 or require(v_u_2:WaitForChild("UiGuardShared"))
		local v359 = v353.isCoreOnly(v356)
		if not v354.gameSource(v356) and (not v353.isCore(v356) or v351 and v359) then
			return v356, v351
		end
		if v359 then
			continue
		end
		v_u_342[v356] = true
	end
	if v351 then
		return v352 or "(no caller)", true, false, "bare"
	elseif v352 then
		return nil
	else
		return "(no caller)", false, false, "root"
	end
end
local function v_u_377(p_u_361, p_u_362, p_u_363, p_u_364, p_u_365) -- name: tellCaller
	-- upvalues: (copy) v_u_2, (copy) v_u_4, (copy) v_u_344
	local function v376()
		-- upvalues: (ref) v_u_2, (ref) v_u_4, (ref) v_u_344, (copy) p_u_361, (copy) p_u_362, (copy) p_u_363, (copy) p_u_364, (copy) p_u_365
		local v366 = require(v_u_2:WaitForChild("UiGuardShared"))
		local v367 = v_u_2:WaitForChild(v_u_4.REMOTES):WaitForChild(v366.REMOTE)
		local v368 = v_u_344.sealFor
		local v369 = "Tool"
		local v370 = {
			["kind"] = "caller",
			["source"] = nil,
			["remote"] = nil,
			["elevated"] = nil,
			["chunk"] = nil,
			["how"] = nil
		}
		local v371 = p_u_361
		v370.source = string.sub(v371, 1, 80)
		local v372 = p_u_362
		if v372 then
			v372 = p_u_362.Name
		end
		local v373 = tostring(v372)
		v370.remote = string.sub(v373, 1, 32)
		v370.elevated = p_u_363
		v370.chunk = p_u_364 == true
		v370.how = p_u_365
		local v374, v375 = v368(v367, v369, v370)
		v367:FireServer(v374, table.unpack(v375))
	end
	pcall(v376)
end
local function v_u_404(p_u_378) -- name: guard
	-- upvalues: (copy) v_u_360, (copy) v_u_344, (ref) v_u_345, (copy) v_u_2, (copy) v_u_4, (copy) v_u_3, (copy) v_u_350, (ref) v_u_347, (copy) v_u_377, (copy) v_u_343, (ref) v_u_341, (ref) v_u_340
	if v_u_360 ~= v_u_344.outsideCaller and not v_u_345 then
		v_u_345 = true
		local v_u_379 = "guard"
		task.spawn(function()
			-- upvalues: (ref) v_u_2, (ref) v_u_4, (ref) v_u_344, (copy) v_u_379
			local function v385()
				-- upvalues: (ref) v_u_2, (ref) v_u_4, (ref) v_u_344, (ref) v_u_379
				local v380 = require(v_u_2:WaitForChild("UiGuardShared"))
				local v381 = v_u_2:WaitForChild(v_u_4.REMOTES):WaitForChild(v380.REMOTE)
				local v382 = {
					["kind"] = "swap",
					["where"] = nil,
					["where"] = v_u_379
				}
				local v383, v384 = v_u_344.sealFor(v381, "Tool", v382)
				v381:FireServer(v383, table.unpack(v384))
			end
			pcall(v385)
		end)
	end
	local v386 = v_u_344.outsideCaller
	local v387, v_u_388, v389, v_u_390, v_u_391 = pcall(v386)
	if v387 and v_u_388 then
		if v_u_391 == "root" then
			if not v_u_347 then
				v_u_347 = true
				task.spawn(v_u_377, v_u_388, p_u_378, false, false, "root")
			end
			error("NetSeal: refused", 3)
		end
		if v389 then
			if not v_u_340 then
				v_u_340 = true
				local v_u_392 = true
				local function v403()
					-- upvalues: (ref) v_u_2, (ref) v_u_4, (ref) v_u_344, (copy) v_u_388, (copy) p_u_378, (copy) v_u_392, (copy) v_u_390, (copy) v_u_391
					local v393 = require(v_u_2:WaitForChild("UiGuardShared"))
					local v394 = v_u_2:WaitForChild(v_u_4.REMOTES):WaitForChild(v393.REMOTE)
					local v395 = v_u_344.sealFor
					local v396 = "Tool"
					local v397 = {
						["kind"] = "caller",
						["source"] = nil,
						["remote"] = nil,
						["elevated"] = nil,
						["chunk"] = nil,
						["how"] = nil
					}
					local v398 = v_u_388
					v397.source = string.sub(v398, 1, 80)
					local v399 = p_u_378
					if v399 then
						v399 = p_u_378.Name
					end
					local v400 = tostring(v399)
					v397.remote = string.sub(v400, 1, 32)
					v397.elevated = v_u_392
					v397.chunk = v_u_390 == true
					v397.how = v_u_391
					local v401, v402 = v395(v394, v396, v397)
					v394:FireServer(v401, table.unpack(v402))
				end
				pcall(v403)
			end
			error("NetSeal: refused", 3)
		else
			v_u_343[v_u_388] = true
			if v_u_341 < 2 then
				v_u_341 = v_u_341 + 1
				task.spawn(v_u_377, v_u_388, p_u_378, false)
			end
		end
	else
		if v387 and (v_u_3:IsStudio() and (workspace:GetAttribute("ZZGuardOn") ~= true and v_u_350())) then
			error("NetSeal: call NetSeal.fire / NetSeal.invoke from inside a function of a script, not as a thread\'s own function (task.spawn(NetSeal.invoke, ...) or task.spawn(pcall, NetSeal.invoke, ...)): in the live game that call is refused. Wrap it: task.spawn(function() NetSeal.invoke(...) end)", 3)
		end
		return
	end
end
v_u_344.guard = v_u_404
v_u_344.sealFor = v_u_339
v_u_344.outsideCaller = v_u_360
table.freeze(v_u_344)
function v5.sealed() -- name: sealed
	-- upvalues: (copy) v_u_344, (copy) v_u_3, (copy) v_u_404, (copy) v_u_339, (copy) v_u_360, (copy) v_u_360
	local v405 = 0
	if not table.isfrozen(v_u_344) or v_u_3:IsStudio() and workspace:GetAttribute("ZZPretendThaw") == true then
		v405 = v405 + 1
	end
	if v_u_344.guard ~= v_u_404 or (v_u_344.sealFor ~= v_u_339 or v_u_344.outsideCaller ~= v_u_360) then
		v405 = v405 + 2
	end
	if v_u_360 ~= v_u_360 then
		v405 = v405 + 4
	end
	return v405
end
function v5.invoke(p406, ...) -- name: invoke
	-- upvalues: (copy) v_u_404, (copy) v_u_344, (copy) v_u_339, (copy) v_u_3, (ref) v_u_345, (copy) v_u_2, (copy) v_u_4
	if v_u_404 == v_u_344.guard and v_u_339 == v_u_344.sealFor then
		local v407 = v_u_3:IsStudio()
		if v407 then
			v407 = workspace:GetAttribute("ZZPretendSwap") == true
		end
		if not v407 then
			v_u_344.guard(p406)
			v415, v416 = v_u_344.sealFor(p406, ...)
			return p406:InvokeServer(v415, table.unpack(v416))
		end
	end
	if not v_u_345 then
		v_u_345 = true
		local v_u_408 = "invoke"
		task.spawn(function()
			-- upvalues: (ref) v_u_2, (ref) v_u_4, (ref) v_u_344, (copy) v_u_408
			local function v414()
				-- upvalues: (ref) v_u_2, (ref) v_u_4, (ref) v_u_344, (ref) v_u_408
				local v409 = require(v_u_2:WaitForChild("UiGuardShared"))
				local v410 = v_u_2:WaitForChild(v_u_4.REMOTES):WaitForChild(v409.REMOTE)
				local v411 = {
					["kind"] = "swap",
					["where"] = nil,
					["where"] = v_u_408
				}
				local v412, v413 = v_u_344.sealFor(v410, "Tool", v411)
				v410:FireServer(v412, table.unpack(v413))
			end
			pcall(v414)
		end)
	end
	v_u_344.guard(p406)
	local v415, v416 = v_u_344.sealFor(p406, ...)
	return p406:InvokeServer(v415, table.unpack(v416))
end
function v5.fire(p417, ...) -- name: fire
	-- upvalues: (copy) v_u_404, (copy) v_u_344, (copy) v_u_339, (copy) v_u_3, (ref) v_u_345, (copy) v_u_2, (copy) v_u_4
	if v_u_404 == v_u_344.guard and v_u_339 == v_u_344.sealFor then
		local v418 = v_u_3:IsStudio()
		if v418 then
			v418 = workspace:GetAttribute("ZZPretendSwap") == true
		end
		if not v418 then
			v_u_344.guard(p417)
			v426, v427 = v_u_344.sealFor(p417, ...)
			p417:FireServer(v426, table.unpack(v427))
			return
		end
	end
	if not v_u_345 then
		v_u_345 = true
		local v_u_419 = "fire"
		task.spawn(function()
			-- upvalues: (ref) v_u_2, (ref) v_u_4, (ref) v_u_344, (copy) v_u_419
			local function v425()
				-- upvalues: (ref) v_u_2, (ref) v_u_4, (ref) v_u_344, (ref) v_u_419
				local v420 = require(v_u_2:WaitForChild("UiGuardShared"))
				local v421 = v_u_2:WaitForChild(v_u_4.REMOTES):WaitForChild(v420.REMOTE)
				local v422 = {
					["kind"] = "swap",
					["where"] = nil,
					["where"] = v_u_419
				}
				local v423, v424 = v_u_344.sealFor(v421, "Tool", v422)
				v421:FireServer(v423, table.unpack(v424))
			end
			pcall(v425)
		end)
	end
	v_u_344.guard(p417)
	local v426, v427 = v_u_344.sealFor(p417, ...)
	p417:FireServer(v426, table.unpack(v427))
end
return v5