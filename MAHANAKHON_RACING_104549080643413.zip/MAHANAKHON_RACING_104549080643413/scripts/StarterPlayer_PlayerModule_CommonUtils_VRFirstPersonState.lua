-- Path: StarterPlayer/PlayerModule/CommonUtils/VRFirstPersonState
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

return {
	["inFirstPerson"] = false
}