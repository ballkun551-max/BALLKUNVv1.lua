-- Path: Players/ygggggg55551/PlayerScripts/AdminGift
-- Class: LocalScript  true/Enum.RunContext.Legacy
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = require(game:GetService("ReplicatedStorage"):WaitForChild("NetSeal"))
local v_u_2 = game:GetService("Players")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("TextChatService")
local v_u_5 = require(v3:WaitForChild("GameShared"))
local v_u_6 = require(v3:WaitForChild("RankShared"))
local v7 = v3:WaitForChild("GameUI")
local v_u_8 = require(v7:WaitForChild("Theme"))
local v_u_9 = require(v7:WaitForChild("Toast"))
local v_u_10 = require(v7:WaitForChild("StoreConfig"))
local v_u_11 = v_u_2.LocalPlayer
local v_u_12 = v3:WaitForChild(v_u_5.REMOTES)
local function v_u_19(p13, ...) -- name: call
	-- upvalues: (copy) v_u_12, (copy) v_u_1
	local v14 = v_u_12:FindFirstChild("Admin")
	if v14 then
		local v15 = v_u_1.invoke
		local v16, v17, v18 = pcall(v15, v14, p13, ...)
		if v16 then
			return v17, v18
		else
			return false, "Couldn\'t reach the server"
		end
	else
		return false, "The admin system isn\'t ready yet"
	end
end
local v_u_20 = {}
local function v_u_33(p21, p22) -- name: picture
	-- upvalues: (copy) v_u_8
	local v23 = v_u_8.new("Frame", {
		["Name"] = "Picture",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["ClipsDescendants"] = true,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = Color3.fromRGB(30, 33, 46),
		["Size"] = UDim2.new(1, 0, 0, 118),
		["Parent"] = p21
	})
	v_u_8.corner(v23, 10)
	if p22.thumb then
		local v24 = v_u_8.new("ImageLabel", {
			["Image"] = nil,
			["BackgroundTransparency"] = 1,
			["ScaleType"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["Image"] = p22.thumb,
			["ScaleType"] = Enum.ScaleType.Crop,
			["Size"] = UDim2.fromScale(1, 1),
			["Parent"] = v23
		})
		v_u_8.corner(v24, 10)
		return v23
	end
	local v25 = game:GetService("Players").LocalPlayer:FindFirstChildOfClass("PlayerGui")
	if v25 then
		v25 = v25:FindFirstChild("PreviewCache")
	end
	if v25 then
		v25 = v25:FindFirstChild(p22.id)
	end
	if not v25 then
		local v26 = v_u_8.badge(v23, p22.category == "Car" and "car" or "scooter", "teal", 64)
		v26.AnchorPoint = Vector2.new(0.5, 0.5)
		v26.Position = UDim2.fromScale(0.5, 0.5)
		return v23
	end
	local v27 = v_u_8.new("ViewportFrame", {
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Ambient"] = nil,
		["LightColor"] = nil,
		["LightDirection"] = Vector3.new(-0.6, -1, -0.4),
		["Parent"] = nil,
		["Size"] = UDim2.fromScale(1, 1),
		["Ambient"] = Color3.fromRGB(150, 150, 150),
		["LightColor"] = Color3.fromRGB(255, 250, 240),
		["Parent"] = v23
	})
	local v28 = v25:Clone()
	v28.Parent = v27
	local v29, v30 = v28:GetBoundingBox()
	local v31 = Instance.new("Camera")
	v31.FieldOfView = 30
	local v32 = (Vector3.new(0.85, 0.42, -1)).Unit
	v31.CFrame = CFrame.lookAt(v29.Position + v32 * v30.Magnitude * 1.12, v29.Position)
	v31.Parent = v27
	v27.CurrentCamera = v31
	return v23
end
local function v_u_245() -- name: build
	-- upvalues: (copy) v_u_8, (copy) v_u_11, (copy) v_u_10, (copy) v_u_2, (copy) v_u_5, (copy) v_u_33, (copy) v_u_20, (copy) v_u_6, (copy) v_u_19, (copy) v_u_9
	local v34 = v_u_8.screen("AdminGift", 70, v_u_11:WaitForChild("PlayerGui"))
	local v_u_35 = v_u_8.window({
		["name"] = "AdminGiftPanel",
		["gui"] = nil,
		["icon"] = "gift",
		["grad"] = "pink",
		["title"] = "Staff Gifts",
		["sub"] = "Staff only: game passes and vehicles for any player",
		["size"] = nil,
		["max"] = nil,
		["gui"] = v34,
		["size"] = Vector2.new(0.66, 0.88),
		["max"] = Vector2.new(860, 760)
	})
	local v_u_36 = {}
	local _, v40 = v_u_8.tabs(v_u_35.body, {
		{
			["id"] = "Pass",
			["label"] = "Game Pass",
			["icon"] = "gift",
			["grad"] = "pink"
		},
		{
			["id"] = "Vehicles",
			["label"] = "Vehicles",
			["icon"] = "key",
			["grad"] = "teal"
		}
	}, function(p37)
		-- upvalues: (copy) v_u_36
		for v38, v39 in v_u_36 do
			v39.Visible = v38 == p37
		end
	end, 44)
	v40("Pass")
	local v41 = v_u_8.new("ScrollingFrame", {
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["CanvasSize"] = nil,
		["AutomaticCanvasSize"] = nil,
		["ScrollingDirection"] = nil,
		["ScrollBarThickness"] = 5,
		["ScrollBarImageColor3"] = nil,
		["Parent"] = nil,
		["Position"] = UDim2.fromOffset(0, 54),
		["Size"] = UDim2.new(1, 0, 1, -54),
		["CanvasSize"] = UDim2.new(),
		["AutomaticCanvasSize"] = Enum.AutomaticSize.Y,
		["ScrollingDirection"] = Enum.ScrollingDirection.Y,
		["ScrollBarImageColor3"] = v_u_8.TEXT_DIM,
		["Parent"] = v_u_35.body
	})
	v_u_8.new("UIPadding", {
		["PaddingTop"] = UDim.new(0, 2),
		["PaddingLeft"] = UDim.new(0, 2),
		["PaddingRight"] = UDim.new(0, 10),
		["PaddingBottom"] = UDim.new(0, 10),
		["Parent"] = v41
	})
	v_u_8.new("UIListLayout", {
		["Padding"] = UDim.new(0, 10),
		["SortOrder"] = Enum.SortOrder.LayoutOrder,
		["Parent"] = v41
	})
	local function v45(p42, p43) -- name: stack
		-- upvalues: (ref) v_u_8
		local v44 = v_u_8.new("Frame", {
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["LayoutOrder"] = nil,
			["Parent"] = nil,
			["Size"] = UDim2.fromScale(1, 0),
			["AutomaticSize"] = Enum.AutomaticSize.Y,
			["LayoutOrder"] = p42,
			["Parent"] = p43
		})
		v_u_8.new("UIListLayout", {
			["Padding"] = UDim.new(0, 10),
			["SortOrder"] = Enum.SortOrder.LayoutOrder,
			["Parent"] = v44
		})
		return v44
	end
	local function v50(p46, p47, p48) -- name: card
		-- upvalues: (ref) v_u_8
		local v49 = v_u_8.new("Frame", {
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.08,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["LayoutOrder"] = nil,
			["Parent"] = nil,
			["BackgroundColor3"] = v_u_8.CARD,
			["Size"] = UDim2.new(1, 0, 0, p48),
			["LayoutOrder"] = p47,
			["Parent"] = p46
		})
		v_u_8.corner(v49, 14)
		v_u_8.border(v49, Color3.new(1, 1, 1), 0.88, 1)
		return v49
	end
	local function v58(p51, p52, p53, p54, p55) -- name: section
		-- upvalues: (ref) v_u_8
		local v56 = v_u_8.new("Frame", {
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["LayoutOrder"] = nil,
			["Parent"] = nil,
			["Size"] = UDim2.new(1, 0, 0, 28),
			["LayoutOrder"] = p52,
			["Parent"] = p51
		})
		local v57 = v_u_8.new("Frame", {
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["BackgroundColor3"] = Color3.new(1, 1, 1),
			["AnchorPoint"] = Vector2.new(0, 0.5),
			["Position"] = UDim2.fromScale(0, 0.5),
			["Size"] = UDim2.fromOffset(26, 26),
			["Parent"] = v56
		})
		v_u_8.corner(v57, 13)
		v_u_8.gradient(v57, p55 or "pink")
		v_u_8.text({
			["Text"] = nil,
			["TextSize"] = 15,
			["FontFace"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["Text"] = tostring(p53),
			["FontFace"] = v_u_8.FONT_HEAVY,
			["Size"] = UDim2.fromScale(1, 1),
			["Parent"] = v57
		})
		v_u_8.text({
			["Text"] = nil,
			["TextSize"] = 19,
			["FontFace"] = nil,
			["TextXAlignment"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["Text"] = p54,
			["FontFace"] = v_u_8.FONT_HEAVY,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["Position"] = UDim2.fromOffset(36, 0),
			["Size"] = UDim2.new(1, -36, 1, 0),
			["Parent"] = v56
		})
	end
	local function v62(p59, p60, p61) -- name: note
		-- upvalues: (ref) v_u_8
		return v_u_8.text({
			["Text"] = nil,
			["TextSize"] = 13,
			["TextColor3"] = nil,
			["TextWrapped"] = true,
			["TextXAlignment"] = nil,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["LayoutOrder"] = nil,
			["Parent"] = nil,
			["Text"] = p61,
			["TextColor3"] = v_u_8.TEXT_DIM,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["Size"] = UDim2.new(1, 0, 0, 0),
			["AutomaticSize"] = Enum.AutomaticSize.Y,
			["LayoutOrder"] = p60,
			["Parent"] = p59
		})
	end
	v58(v41, 1, 1, "Choose a player")
	local v63 = v50(v41, 2, 54)
	v_u_8.padding(v63, 6)
	local v_u_64 = v_u_8.new("TextBox", {
		["Name"] = "Who",
		["Text"] = "",
		["PlaceholderText"] = "Username or user ID",
		["ClearTextOnFocus"] = false,
		["FontFace"] = nil,
		["TextSize"] = 17,
		["TextColor3"] = nil,
		["PlaceholderColor3"] = nil,
		["TextXAlignment"] = nil,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.2,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["Parent"] = nil,
		["FontFace"] = v_u_8.FONT_BOLD,
		["TextColor3"] = v_u_8.TEXT,
		["PlaceholderColor3"] = v_u_8.TEXT_DIM,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["BackgroundColor3"] = v_u_8.CARD_DARK,
		["Size"] = UDim2.new(1, -128, 1, 0),
		["Parent"] = v63
	})
	v_u_8.corner(v_u_64, 10)
	v_u_8.new("UIPadding", {
		["PaddingLeft"] = UDim.new(0, 12),
		["PaddingRight"] = UDim.new(0, 12),
		["Parent"] = v_u_64
	})
	local v65 = v_u_8.button({
		["name"] = "Find",
		["text"] = "Find",
		["icon"] = "person",
		["grad"] = "blue",
		["textSize"] = 16,
		["anchor"] = nil,
		["position"] = nil,
		["size"] = nil,
		["parent"] = nil,
		["anchor"] = Vector2.new(1, 0),
		["position"] = UDim2.fromScale(1, 0),
		["size"] = UDim2.new(0, 118, 1, 0),
		["parent"] = v63
	})
	local v_u_66 = v_u_8.new("ScrollingFrame", {
		["Name"] = "HereNow",
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["CanvasSize"] = nil,
		["AutomaticCanvasSize"] = nil,
		["ScrollingDirection"] = nil,
		["ScrollBarThickness"] = 4,
		["LayoutOrder"] = 3,
		["Parent"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 108),
		["CanvasSize"] = UDim2.new(),
		["AutomaticCanvasSize"] = Enum.AutomaticSize.X,
		["ScrollingDirection"] = Enum.ScrollingDirection.X,
		["Parent"] = v41
	})
	v_u_8.new("UIListLayout", {
		["FillDirection"] = Enum.FillDirection.Horizontal,
		["Padding"] = UDim.new(0, 10),
		["SortOrder"] = Enum.SortOrder.LayoutOrder,
		["Parent"] = v_u_66
	})
	v_u_8.new("UIPadding", {
		["PaddingLeft"] = UDim.new(0, 2),
		["PaddingTop"] = UDim.new(0, 3),
		["Parent"] = v_u_66
	})
	local v67 = v50(v41, 4, 92)
	v_u_8.padding(v67, 12)
	local v_u_68 = v_u_8.new("ImageLabel", {
		["BackgroundColor3"] = Color3.fromRGB(30, 32, 44),
		["Size"] = UDim2.fromOffset(66, 66),
		["AnchorPoint"] = Vector2.new(0, 0.5),
		["Position"] = UDim2.fromScale(0, 0.5),
		["Parent"] = v67
	})
	v_u_8.corner(v_u_68, 33)
	local v_u_69 = v_u_8.text({
		["Text"] = "",
		["TextSize"] = 20,
		["FontFace"] = nil,
		["TextXAlignment"] = nil,
		["TextTruncate"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["FontFace"] = v_u_8.FONT_HEAVY,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["TextTruncate"] = Enum.TextTruncate.AtEnd,
		["Position"] = UDim2.fromOffset(80, 0),
		["Size"] = UDim2.new(1, -80, 0, 24),
		["Parent"] = v67
	})
	local v_u_70 = v_u_8.text({
		["Text"] = "",
		["TextSize"] = 14,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["TextTruncate"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["TextColor3"] = v_u_8.TEXT_DIM,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["TextTruncate"] = Enum.TextTruncate.AtEnd,
		["Position"] = UDim2.fromOffset(80, 25),
		["Size"] = UDim2.new(1, -80, 0, 18),
		["Parent"] = v67
	})
	local v_u_71 = v_u_8.text({
		["Text"] = "",
		["TextSize"] = 14,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["TextTruncate"] = nil,
		["FontFace"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["TextColor3"] = v_u_8.GREEN_TEXT,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["TextTruncate"] = Enum.TextTruncate.AtEnd,
		["FontFace"] = v_u_8.FONT_BOLD,
		["Position"] = UDim2.fromOffset(80, 46),
		["Size"] = UDim2.new(1, -80, 0, 18),
		["Parent"] = v67
	})
	local v72 = v45(10, v41)
	v_u_36.Pass = v72
	v58(v72, 1, 2, "Choose a game pass")
	local v_u_73 = {}
	for v74, v75 in v_u_10.GAMEPASSES do
		local v76 = v50(v72, 1 + v74, 74)
		v_u_8.padding(v76, 12)
		local v77 = v_u_8.badge(v76, v75.icon or "gift", v75.grad or "gold", 48)
		v77.AnchorPoint = Vector2.new(0, 0.5)
		v77.Position = UDim2.fromScale(0, 0.5)
		v_u_8.text({
			["Text"] = nil,
			["TextSize"] = 18,
			["FontFace"] = nil,
			["TextXAlignment"] = nil,
			["TextTruncate"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["Text"] = v75.name,
			["FontFace"] = v_u_8.FONT_HEAVY,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["TextTruncate"] = Enum.TextTruncate.AtEnd,
			["Position"] = UDim2.fromOffset(62, 3),
			["Size"] = UDim2.new(1, -212, 0, 22),
			["Parent"] = v76
		})
		v_u_8.text({
			["Text"] = nil,
			["TextSize"] = 14,
			["TextColor3"] = nil,
			["TextXAlignment"] = nil,
			["TextTruncate"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["Text"] = v75.description or "",
			["TextColor3"] = v_u_8.TEXT_DIM,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["TextTruncate"] = Enum.TextTruncate.AtEnd,
			["Position"] = UDim2.fromOffset(62, 27),
			["Size"] = UDim2.new(1, -212, 0, 18),
			["Parent"] = v76
		})
		v_u_73[v74] = {
			["pass"] = v75,
			["button"] = v_u_8.button({
				["name"] = "Give",
				["text"] = "Give",
				["icon"] = "gift",
				["grad"] = "pink",
				["textSize"] = 16,
				["anchor"] = nil,
				["position"] = nil,
				["size"] = nil,
				["parent"] = nil,
				["anchor"] = Vector2.new(1, 0.5),
				["position"] = UDim2.fromScale(1, 0.5),
				["size"] = UDim2.fromOffset(136, 42),
				["parent"] = v76
			})
		}
	end
	v62(v72, 100, "A pass given here is kept in their save like a gift; Take back takes back only what their save holds (not one bought on Roblox). Every one is in the admin log.")
	local v_u_78 = v45(10, v41)
	v_u_78.Visible = false
	v_u_36.Vehicles = v_u_78
	v58(v_u_78, 1, 2, "Give a vehicle", "teal")
	v62(v_u_78, 2, "Private vehicles (not in the public garage), and any you took the keys of: give it back here.")
	local function v81(p79) -- name: grid
		-- upvalues: (ref) v_u_8, (copy) v_u_78
		local v80 = v_u_8.new("Frame", {
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["LayoutOrder"] = nil,
			["Parent"] = nil,
			["Size"] = UDim2.fromScale(1, 0),
			["AutomaticSize"] = Enum.AutomaticSize.Y,
			["LayoutOrder"] = p79,
			["Parent"] = v_u_78
		})
		v_u_8.new("UIGridLayout", {
			["CellSize"] = UDim2.new(0.3333333333333333, -7, 0, 214),
			["CellPadding"] = UDim2.fromOffset(10, 10),
			["SortOrder"] = Enum.SortOrder.LayoutOrder,
			["Parent"] = v80
		})
		return v80
	end
	local v_u_82 = v81(3)
	v58(v_u_78, 4, 3, "Their vehicles \194\183 take the keys", "red")
	local v_u_83 = v62(v_u_78, 5, "")
	local v_u_84 = v81(6)
	v62(v_u_78, 100, "Take keys puts it away if it\'s out and takes it out of their garage (a starter one too: it stays gone until given back). Pass vehicles come with their pass. Every one is in the admin log.")
	local v_u_85 = nil
	local v_u_86 = false
	local v_u_87 = false
	local v_u_88 = {}
	local v_u_89 = 0
	local v_u_90 = {}
	local v_u_91 = {}
	local v_u_92 = false
	local function v_u_101(p93, p94, p95, p96, p97, p98, p99) -- name: vehicleCard
		-- upvalues: (ref) v_u_8, (ref) v_u_33
		local v100 = v_u_8.new("Frame", {
			["Name"] = nil,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.08,
			["BorderSizePixel"] = 0,
			["LayoutOrder"] = nil,
			["Parent"] = nil,
			["Name"] = p95.id,
			["BackgroundColor3"] = v_u_8.CARD,
			["LayoutOrder"] = p94,
			["Parent"] = p93
		})
		v_u_8.corner(v100, 14)
		v_u_8.border(v100, Color3.new(1, 1, 1), 0.88, 1)
		v_u_8.padding(v100, 8)
		v_u_33(v100, p95)
		v_u_8.text({
			["Text"] = nil,
			["TextSize"] = 16,
			["FontFace"] = nil,
			["TextXAlignment"] = nil,
			["TextTruncate"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["Text"] = p95.th or (p95.en or p95.id),
			["FontFace"] = v_u_8.FONT_HEAVY,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["TextTruncate"] = Enum.TextTruncate.AtEnd,
			["Position"] = UDim2.fromOffset(2, 122),
			["Size"] = UDim2.new(1, -4, 0, 20),
			["Parent"] = v100
		})
		v_u_8.text({
			["Text"] = nil,
			["TextSize"] = 13,
			["TextColor3"] = nil,
			["TextXAlignment"] = nil,
			["TextTruncate"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["Text"] = p96,
			["TextColor3"] = p97 or v_u_8.TEXT_DIM,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["TextTruncate"] = Enum.TextTruncate.AtEnd,
			["Position"] = UDim2.fromOffset(2, 142),
			["Size"] = UDim2.new(1, -4, 0, 16),
			["Parent"] = v100
		})
		return v_u_8.button({
			["name"] = "Act",
			["text"] = "...",
			["icon"] = nil,
			["grad"] = nil,
			["textSize"] = 15,
			["anchor"] = nil,
			["position"] = nil,
			["size"] = nil,
			["parent"] = nil,
			["icon"] = p98,
			["grad"] = p99,
			["anchor"] = Vector2.new(0, 1),
			["position"] = UDim2.fromScale(0, 1),
			["size"] = UDim2.new(1, 0, 0, 36),
			["parent"] = v100
		})
	end
	local v_u_102 = nil
	local v_u_103 = nil
	local function v_u_106(p104) -- name: clear
		for _, v105 in p104:GetChildren() do
			if not v105:IsA("GuiObject") then
				continue
			end
			v105:Destroy()
		end
	end
	local function v_u_123() -- name: rebuildVehicles
		-- upvalues: (ref) v_u_85, (ref) v_u_92, (copy) v_u_106, (copy) v_u_82, (copy) v_u_84, (ref) v_u_90, (ref) v_u_91, (ref) v_u_5, (copy) v_u_101, (ref) v_u_8, (ref) v_u_102, (copy) v_u_83, (ref) v_u_103
		local v107
		if v_u_85 then
			if v_u_85.vehicles then
				v107 = v_u_85.vehicles
			else
				v107 = "checking:" .. v_u_85.id
			end
		else
			v107 = "none"
		end
		if v_u_92 == v107 then
			return
		else
			v_u_92 = v107
			v_u_106(v_u_82)
			v_u_106(v_u_84)
			v_u_90 = {}
			v_u_91 = {}
			local v108 = 0
			for _, v_u_109 in v_u_5.VEHICLES do
				local v110
				if v_u_85 == nil or v_u_85.seized == nil then
					v110 = false
				else
					v110 = v_u_85.seized[v_u_109.id] == true
				end
				if not (v_u_109.private or (v_u_109.forSale or v110)) then
					continue
				end
				v108 = v108 + 1
				local v111 = v_u_109.category == "Car" and "Car" or "Motorcycle"
				local v112
				if v110 then
					v112 = "Keys taken \194\183 give it back"
				elseif v_u_109.forSale then
					v112 = ("%s \194\183 for sale %s"):format(v111, v_u_5.formatCash(v_u_109.price or 0))
				else
					v112 = v111 .. " \194\183 private"
				end
				local v113 = v_u_101
				local v114 = v_u_82
				local v115
				if v110 then
					v115 = v_u_8.ORANGE
				else
					v115 = nil
				end
				local v116 = v113(v114, v108, v_u_109, v112, v115, "key", "teal")
				v_u_90[v_u_109.id] = {
					["info"] = v_u_109,
					["button"] = v116
				}
				v116.Activated:Connect(function()
					-- upvalues: (ref) v_u_102, (copy) v_u_109
					v_u_102(v_u_109)
				end)
			end
			if v108 == 0 then
				v_u_8.text({
					["Text"] = "No private or for-sale vehicles right now (GameShared.VEHICLES: private / forSale)",
					["TextSize"] = 14,
					["TextColor3"] = nil,
					["TextXAlignment"] = nil,
					["Parent"] = nil,
					["TextColor3"] = v_u_8.TEXT_DIM,
					["TextXAlignment"] = Enum.TextXAlignment.Left,
					["Parent"] = v_u_82
				}).Size = UDim2.new(1, 0, 0, 24)
			end
			if v_u_85 then
				if v_u_85.vehicles then
					local v117 = 0
					for v118, v_u_119 in v_u_5.VEHICLES do
						local v120 = v_u_85.vehicles[v_u_119.id]
						if not v120 then
							continue
						end
						v117 = v117 + 1
						local v121
						if v_u_119.pass then
							v121 = ("Comes with %s"):format(v_u_5.passName(v_u_119.pass))
						else
							v121 = ("%s km%s"):format(v_u_5.formatNumber(v120), v_u_119.private and " \194\183 private" or "")
						end
						local v122 = v_u_101(v_u_84, v118, v_u_119, v121, nil, "key", "red")
						v_u_91[v_u_119.id] = {
							["info"] = v_u_119,
							["button"] = v122
						}
						v122.Activated:Connect(function()
							-- upvalues: (ref) v_u_103, (copy) v_u_119
							v_u_103(v_u_119)
						end)
					end
					v_u_83.Text = v117 <= 0 and "Nothing in their garage." or ("%d in their garage."):format(v117)
				else
					v_u_83.Text = "Checking their garage..."
				end
			else
				v_u_83.Text = "Pick a player to see their garage."
				return
			end
		end
	end
	local function v_u_158() -- name: render
		-- upvalues: (ref) v_u_85, (copy) v_u_68, (copy) v_u_69, (ref) v_u_86, (copy) v_u_70, (copy) v_u_71, (ref) v_u_20, (ref) v_u_2, (ref) v_u_6, (ref) v_u_8, (copy) v_u_73, (ref) v_u_5, (ref) v_u_87, (ref) v_u_88, (copy) v_u_123, (ref) v_u_90, (ref) v_u_91
		if v_u_85 then
			local v_u_124 = v_u_85.id
			local function v_u_126(p125)
				-- upvalues: (ref) v_u_85, (copy) v_u_124, (ref) v_u_68
				if v_u_85 and v_u_85.id == v_u_124 then
					v_u_68.Image = p125
				end
			end
			if v_u_20[v_u_124] then
				local v127 = v_u_20[v_u_124]
				if v_u_85 and v_u_85.id == v_u_124 then
					v_u_68.Image = v127
				end
			else
				task.spawn(function()
					-- upvalues: (ref) v_u_2, (copy) v_u_124, (ref) v_u_20, (copy) v_u_126
					local v128 = v_u_2.GetUserThumbnailAsync
					local v129 = v_u_2
					local v130 = v_u_124
					local v131 = Enum.ThumbnailType.HeadShot
					local v132 = Enum.ThumbnailSize.Size150x150
					local v133, v134 = pcall(v128, v129, v130, v131, v132)
					if v133 then
						v_u_20[v_u_124] = v134
						v_u_126(v134)
					end
				end)
			end
			v_u_69.Text = (v_u_85.display or (v_u_85.name or "?")) .. "  @" .. (v_u_85.name or "?")
			local v135 = v_u_2:GetPlayerByUserId(v_u_124) and "In this server" or (v_u_85.online and "Playing in another server" or (v_u_85.passes and "Not in the game now (they get it next time they join)" or "..."))
			v_u_70.Text = v_u_6.label(v_u_85.rank or "Member") .. "  \194\183  " .. v135 .. "  \194\183  ID " .. v_u_124
			if v_u_85.passes then
				local v136 = {}
				for v137, v138 in v_u_85.passes do
					table.insert(v136, ("%s (%s)"):format(v137, v138))
				end
				table.sort(v136)
				v_u_71.Text = #v136 <= 0 and "Has no game passes yet" or "Has: " .. table.concat(v136, "  \194\183  ")
				local v139 = v_u_71
				local v140
				if #v136 > 0 then
					v140 = v_u_8.GREEN_TEXT
				else
					v140 = v_u_8.TEXT_DIM
				end
				v139.TextColor3 = v140
			else
				v_u_71.Text = "Checking their passes..."
				v_u_71.TextColor3 = v_u_8.TEXT_DIM
			end
		else
			v_u_68.Image = ""
			v_u_69.Text = v_u_86 and "Looking for them..." or "Nobody picked yet"
			v_u_70.Text = "Pick someone below, or type a username / user ID"
			v_u_71.Text = ""
		end
		for _, v141 in v_u_73 do
			if v_u_85 then
				local v142 = v141.pass
				local v143
				if v_u_85 then
					local v144 = v_u_2:GetPlayerByUserId(v_u_85.id)
					if v144 and v_u_5.hasPass(v144, v142.key) then
						v143 = true
					elseif v_u_85.passes == nil then
						v143 = false
					else
						v143 = v_u_85.passes[v142.name] ~= nil
					end
				else
					v143 = false
				end
				if v143 then
					local v145 = v_u_85.passes
					if v145 then
						v145 = v_u_85.passes[v141.pass.name]
					end
					if v145 == "gift" then
						if v_u_87 then
							v_u_8.setButton(v141.button, "grey", "...", v_u_8.TEXT_DIM)
						else
							local v146 = "takepass:" .. v141.pass.key
							local v147
							if v_u_88[v146] == nil then
								v147 = false
							else
								v147 = os.clock() - v_u_88[v146] <= 3
							end
							if v147 then
								v_u_8.setButton(v141.button, "gold", "Sure? Take back", v_u_8.DARK_TEXT)
							else
								v_u_8.setButton(v141.button, "red", "Take back", Color3.new(1, 1, 1))
							end
						end
					elseif v145 == "bought" then
						v_u_8.setButton(v141.button, "dark", "Bought", v_u_8.TEXT_DIM)
					else
						v_u_8.setButton(v141.button, "dark", "Has it", v_u_8.GREEN_TEXT)
					end
				elseif v_u_87 then
					v_u_8.setButton(v141.button, "grey", "...", v_u_8.TEXT_DIM)
				else
					local v148 = "pass:" .. v141.pass.key
					local v149
					if v_u_88[v148] == nil then
						v149 = false
					else
						v149 = os.clock() - v_u_88[v148] <= 3
					end
					if v149 then
						v_u_8.setButton(v141.button, "gold", "Sure?", v_u_8.DARK_TEXT)
					else
						v_u_8.setButton(v141.button, "pink", "Give", Color3.new(1, 1, 1))
					end
				end
			else
				v_u_8.setButton(v141.button, "grey", "Pick a player", v_u_8.TEXT_DIM)
			end
		end
		v_u_123()
		for v150, v151 in v_u_90 do
			if v_u_85 then
				if v_u_85.vehicles and v_u_85.vehicles[v150] then
					v_u_8.setButton(v151.button, "dark", "Has it", v_u_8.GREEN_TEXT)
				elseif v_u_87 or not v_u_85.vehicles then
					v_u_8.setButton(v151.button, "grey", "...", v_u_8.TEXT_DIM)
				else
					local v152 = "give:" .. v150
					local v153
					if v_u_88[v152] == nil then
						v153 = false
					else
						v153 = os.clock() - v_u_88[v152] <= 3
					end
					if v153 then
						v_u_8.setButton(v151.button, "gold", "Sure?", v_u_8.DARK_TEXT)
					else
						v_u_8.setButton(v151.button, "teal", v_u_85.seized and v_u_85.seized[v150] and "Give back" or "Give", Color3.new(1, 1, 1))
					end
				end
			else
				v_u_8.setButton(v151.button, "grey", "Pick a player", v_u_8.TEXT_DIM)
			end
		end
		for v154, v155 in v_u_91 do
			if v155.info.pass then
				v_u_8.setButton(v155.button, "dark", "Pass vehicle", v_u_8.TEXT_DIM)
			elseif v_u_87 then
				v_u_8.setButton(v155.button, "grey", "...", v_u_8.TEXT_DIM)
			else
				local v156 = "take:" .. v154
				local v157
				if v_u_88[v156] == nil then
					v157 = false
				else
					v157 = os.clock() - v_u_88[v156] <= 3
				end
				if v157 then
					v_u_8.setButton(v155.button, "gold", "Sure? Take keys", v_u_8.DARK_TEXT)
				else
					v_u_8.setButton(v155.button, "red", "Take keys", Color3.new(1, 1, 1))
				end
			end
		end
	end
	local function v_u_178(p_u_159, p160) -- name: lookup
		-- upvalues: (ref) v_u_89, (ref) v_u_88, (ref) v_u_85, (ref) v_u_86, (copy) v_u_158, (ref) v_u_19, (ref) v_u_9
		v_u_89 = v_u_89 + 1
		local v_u_161 = v_u_89
		v_u_88 = {}
		if p160 then
			v_u_85 = p160
		elseif not v_u_85 or v_u_85.id ~= p_u_159 then
			v_u_85 = nil
		end
		v_u_86 = true
		v_u_158()
		task.spawn(function()
			-- upvalues: (ref) v_u_19, (copy) p_u_159, (copy) v_u_161, (ref) v_u_89, (ref) v_u_86, (ref) v_u_9, (ref) v_u_85, (ref) v_u_158
			local v162, v163 = v_u_19("Lookup", p_u_159)
			if v_u_161 == v_u_89 then
				v_u_86 = false
				if v162 and type(v163) == "table" then
					local v164 = v163.passes
					local v165 = {}
					for _, v166 in type(v164) ~= "table" and {} or v163.passes do
						if type(v166) ~= "table" then
							continue
						end
						local v167 = v166.name
						if type(v167) ~= "string" then
							continue
						end
						v165[v166.name] = v166.how or "has it"
					end
					local v168 = v163.vehicles
					local v169 = {}
					local v170 = {}
					for _, v171 in type(v168) ~= "table" and {} or v163.vehicles do
						if type(v171) ~= "table" then
							continue
						end
						local v172 = v171.id
						if type(v172) ~= "string" then
							continue
						end
						local v173 = v171.id
						local v174 = v171.km
						v169[v173] = tonumber(v174) or 0
					end
					local v175 = v163.seized
					for _, v176 in type(v175) ~= "table" and {} or v163.seized do
						if type(v176) ~= "string" then
							continue
						end
						v170[v176] = true
					end
					v_u_85 = {
						["id"] = v163.id,
						["name"] = v163.name,
						["display"] = v163.display,
						["rank"] = v163.rank,
						["here"] = v163.here,
						["online"] = v163.online,
						["passes"] = v165,
						["vehicles"] = v169,
						["seized"] = v170
					}
					v_u_158()
				else
					v_u_9.show(tostring(v163 or "Couldn\'t find them"), "error")
					if v_u_85 and not v_u_85.passes then
						v_u_85.passes = {}
					end
					if v_u_85 and not v_u_85.vehicles then
						local v177 = v_u_85
						v_u_85.vehicles = {}
						v177.seized = {}
					end
					v_u_158()
				end
			else
				return
			end
		end)
	end
	local function v_u_180() -- name: findTyped
		-- upvalues: (copy) v_u_64, (ref) v_u_9, (copy) v_u_178
		local v179 = v_u_64.Text:gsub("^%s+", ""):gsub("%s+$", ""):gsub("^@", "")
		if v179 == "" then
			v_u_9.show("Type a username or user ID", "info")
		else
			v_u_178(v179)
		end
	end
	v65.Activated:Connect(v_u_180)
	v_u_64.FocusLost:Connect(function(p181)
		-- upvalues: (copy) v_u_180
		if p181 then
			v_u_180()
		end
	end)
	local function v_u_207() -- name: refreshStrip
		-- upvalues: (copy) v_u_66, (ref) v_u_2, (ref) v_u_85, (ref) v_u_8, (ref) v_u_20, (ref) v_u_11, (copy) v_u_64, (copy) v_u_178, (copy) v_u_207
		for _, v182 in v_u_66:GetChildren() do
			if not v182:IsA("GuiObject") then
				continue
			end
			v182:Destroy()
		end
		local v183 = v_u_2:GetPlayers()
		table.sort(v183, function(p184, p185)
			return p184.DisplayName:lower() < p185.DisplayName:lower()
		end)
		for v186, v_u_187 in v183 do
			local v188
			if v_u_85 == nil then
				v188 = false
			else
				v188 = v_u_85.id == v_u_187.UserId
			end
			local v189 = v_u_8.new
			local v190 = "TextButton"
			local v191 = {
				["Name"] = nil,
				["Text"] = "",
				["AutoButtonColor"] = false,
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.1,
				["Size"] = nil,
				["LayoutOrder"] = nil,
				["Parent"] = nil,
				["Name"] = "P" .. v_u_187.UserId
			}
			local v192
			if v188 then
				v192 = Color3.fromRGB(80, 40, 70)
			else
				v192 = v_u_8.CARD
			end
			v191.BackgroundColor3 = v192
			v191.Size = UDim2.fromOffset(96, 100)
			v191.LayoutOrder = v186
			v191.Parent = v_u_66
			local v193 = v189(v190, v191)
			v_u_8.corner(v193, 14)
			local v194 = v_u_8.border
			local v195
			if v188 then
				v195 = Color3.fromRGB(255, 120, 200)
			else
				v195 = Color3.new(1, 1, 1)
			end
			v194(v193, v195, v188 and 0 or 0.88, v188 and 2.5 or 1)
			local v_u_196 = v_u_8.new("ImageLabel", {
				["BackgroundColor3"] = Color3.fromRGB(30, 32, 44),
				["Size"] = UDim2.fromOffset(60, 60),
				["AnchorPoint"] = Vector2.new(0.5, 0),
				["Position"] = UDim2.new(0.5, 0, 0, 8),
				["Parent"] = v193
			})
			v_u_8.corner(v_u_196, 30)
			local v_u_197 = v_u_187.UserId
			local function v_u_199(p198)
				-- upvalues: (copy) v_u_196
				v_u_196.Image = p198
			end
			if v_u_20[v_u_197] then
				v_u_196.Image = v_u_20[v_u_197]
			else
				task.spawn(function()
					-- upvalues: (ref) v_u_2, (copy) v_u_197, (ref) v_u_20, (copy) v_u_199
					local v200 = v_u_2.GetUserThumbnailAsync
					local v201 = v_u_2
					local v202 = v_u_197
					local v203 = Enum.ThumbnailType.HeadShot
					local v204 = Enum.ThumbnailSize.Size150x150
					local v205, v206 = pcall(v200, v201, v202, v203, v204)
					if v205 then
						v_u_20[v_u_197] = v206
						v_u_199(v206)
					end
				end)
			end
			v_u_8.text({
				["Text"] = nil,
				["TextSize"] = 13,
				["FontFace"] = nil,
				["TextTruncate"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["Text"] = v_u_187 == v_u_11 and "You" or v_u_187.DisplayName,
				["FontFace"] = v_u_8.FONT_BOLD,
				["TextTruncate"] = Enum.TextTruncate.AtEnd,
				["Position"] = UDim2.fromOffset(4, 72),
				["Size"] = UDim2.new(1, -8, 0, 18),
				["Parent"] = v193
			})
			v193.Activated:Connect(function()
				-- upvalues: (ref) v_u_64, (copy) v_u_187, (ref) v_u_178, (ref) v_u_207
				v_u_64.Text = v_u_187.Name
				v_u_178(v_u_187.UserId, {
					["id"] = nil,
					["name"] = nil,
					["display"] = nil,
					["rank"] = nil,
					["here"] = true,
					["online"] = true,
					["id"] = v_u_187.UserId,
					["name"] = v_u_187.Name,
					["display"] = v_u_187.DisplayName,
					["rank"] = v_u_187:GetAttribute("Rank")
				})
				v_u_207()
			end)
		end
	end
	local function v_u_210(p208) -- name: confirm
		-- upvalues: (ref) v_u_88, (copy) v_u_158
		local v209
		if v_u_88[p208] == nil then
			v209 = false
		else
			v209 = os.clock() - v_u_88[p208] <= 3
		end
		if v209 then
			v_u_88 = {}
			return true
		end
		v_u_88 = {
			[p208] = os.clock()
		}
		v_u_158()
		task.delay(3.05, v_u_158)
		return false
	end
	local function v_u_217(p211) -- name: give
		-- upvalues: (ref) v_u_87, (ref) v_u_85, (ref) v_u_2, (ref) v_u_5, (copy) v_u_210, (copy) v_u_158, (ref) v_u_19, (ref) v_u_9, (copy) v_u_35, (copy) v_u_178
		if not v_u_87 and v_u_85 then
			local v212
			if v_u_85 then
				local v213 = v_u_2:GetPlayerByUserId(v_u_85.id)
				if v213 and v_u_5.hasPass(v213, p211.key) then
					v212 = true
				elseif v_u_85.passes == nil then
					v212 = false
				else
					v212 = v_u_85.passes[p211.name] ~= nil
				end
			else
				v212 = false
			end
			if not v212 and v_u_210("pass:" .. p211.key) then
				v_u_87 = true
				v_u_158()
				local v_u_214 = v_u_85.id
				local v215, v216 = v_u_19("GivePass", v_u_214, p211.key)
				v_u_87 = false
				v_u_9.show(tostring(v216 or (v215 and "Done" or "Couldn\'t give it")), v215 and "ok" or "error")
				if v215 and (v_u_85 and (v_u_85.id == v_u_214 and v_u_85.passes)) then
					v_u_85.passes[p211.name] = "gift"
				end
				v_u_158()
				if v215 then
					task.delay(0.6, function()
						-- upvalues: (ref) v_u_85, (copy) v_u_214, (ref) v_u_35, (ref) v_u_178
						if v_u_85 and (v_u_85.id == v_u_214 and v_u_35.isOpen()) then
							v_u_178(v_u_214)
						end
					end)
				end
				return
			end
		end
	end
	local function v_u_223(p218) -- name: takePass
		-- upvalues: (ref) v_u_87, (ref) v_u_85, (copy) v_u_210, (copy) v_u_158, (ref) v_u_19, (ref) v_u_9, (copy) v_u_35, (copy) v_u_178
		if not v_u_87 and (v_u_85 and (v_u_85.passes and (v_u_85.passes[p218.name] == "gift" and v_u_210("takepass:" .. p218.key)))) then
			v_u_87 = true
			v_u_158()
			local v_u_219 = v_u_85.id
			local v220, v221 = v_u_19("TakePass", v_u_219, p218.key)
			v_u_87 = false
			v_u_9.show(tostring(v221 or (v220 and "Done" or "Couldn\'t take it back")), v220 and "ok" or "error")
			if v220 and (v_u_85 and (v_u_85.id == v_u_219 and v_u_85.passes)) then
				local v222 = table.clone(v_u_85.passes)
				v222[p218.name] = nil
				v_u_85.passes = v222
			end
			v_u_158()
			if v220 then
				task.delay(0.6, function()
					-- upvalues: (ref) v_u_85, (copy) v_u_219, (ref) v_u_35, (ref) v_u_178
					if v_u_85 and (v_u_85.id == v_u_219 and v_u_35.isOpen()) then
						v_u_178(v_u_219)
					end
				end)
			end
		end
	end
	local v_u_224 = v_u_87
	local v_u_225 = v_u_85
	for _, v_u_226 in v_u_73 do
		v_u_226.button.Activated:Connect(function()
			-- upvalues: (copy) v_u_226, (ref) v_u_225, (ref) v_u_2, (ref) v_u_5, (copy) v_u_223, (copy) v_u_217
			local v227 = v_u_226.pass
			local v228
			if v_u_225 then
				local v229 = v_u_2:GetPlayerByUserId(v_u_225.id)
				if v229 and v_u_5.hasPass(v229, v227.key) then
					v228 = true
				elseif v_u_225.passes == nil then
					v228 = false
				else
					v228 = v_u_225.passes[v227.name] ~= nil
				end
			else
				v228 = false
			end
			if v228 then
				v_u_223(v_u_226.pass)
			else
				v_u_217(v_u_226.pass)
			end
		end)
	end
	v_u_102 = function(p230) -- name: giveVehicle
		-- upvalues: (ref) v_u_224, (ref) v_u_225, (copy) v_u_210, (copy) v_u_158, (ref) v_u_19, (ref) v_u_9, (copy) v_u_35, (copy) v_u_178
		if not v_u_224 and (v_u_225 and (v_u_225.vehicles and (not v_u_225.vehicles[p230.id] and v_u_210("give:" .. p230.id)))) then
			v_u_224 = true
			v_u_158()
			local v_u_231 = v_u_225.id
			local v232, v233 = v_u_19("GiveVehicle", v_u_231, p230.id)
			v_u_224 = false
			v_u_9.show(tostring(v233 or (v232 and "Done" or "Couldn\'t give it")), v232 and "ok" or "error")
			if v232 and (v_u_225 and (v_u_225.id == v_u_231 and v_u_225.vehicles)) then
				local v234 = table.clone(v_u_225.vehicles)
				v234[p230.id] = 0
				v_u_225.vehicles = v234
				v_u_225.seized[p230.id] = nil
			end
			v_u_158()
			if v232 then
				task.delay(0.6, function()
					-- upvalues: (ref) v_u_225, (copy) v_u_231, (ref) v_u_35, (ref) v_u_178
					if v_u_225 and (v_u_225.id == v_u_231 and v_u_35.isOpen()) then
						v_u_178(v_u_231)
					end
				end)
			end
		end
	end
	v_u_103 = function(p235) -- name: takeVehicle
		-- upvalues: (ref) v_u_224, (ref) v_u_225, (copy) v_u_210, (copy) v_u_158, (ref) v_u_19, (ref) v_u_9, (copy) v_u_35, (copy) v_u_178
		if not v_u_224 and (v_u_225 and (not p235.pass and (v_u_225.vehicles and (v_u_225.vehicles[p235.id] and v_u_210("take:" .. p235.id))))) then
			v_u_224 = true
			v_u_158()
			local v_u_236 = v_u_225.id
			local v237, v238 = v_u_19("TakeVehicle", v_u_236, p235.id)
			v_u_224 = false
			v_u_9.show(tostring(v238 or (v237 and "Done" or "Couldn\'t take it")), v237 and "ok" or "error")
			if v237 and (v_u_225 and (v_u_225.id == v_u_236 and v_u_225.vehicles)) then
				local v239 = table.clone(v_u_225.vehicles)
				v239[p235.id] = nil
				v_u_225.vehicles = v239
				v_u_225.seized[p235.id] = true
			end
			v_u_158()
			if v237 then
				task.delay(0.6, function()
					-- upvalues: (ref) v_u_225, (copy) v_u_236, (ref) v_u_35, (ref) v_u_178
					if v_u_225 and (v_u_225.id == v_u_236 and v_u_35.isOpen()) then
						v_u_178(v_u_236)
					end
				end)
			end
		end
	end
	local function v_u_242(p_u_240) -- name: watch
		-- upvalues: (ref) v_u_10, (ref) v_u_225, (copy) v_u_158
		for _, v241 in v_u_10.GAMEPASSES do
			p_u_240:GetAttributeChangedSignal("Pass_" .. v241.key):Connect(function()
				-- upvalues: (ref) v_u_225, (copy) p_u_240, (ref) v_u_158
				if v_u_225 and v_u_225.id == p_u_240.UserId then
					v_u_158()
				end
			end)
		end
	end
	for _, v243 in v_u_2:GetPlayers() do
		v_u_242(v243)
	end
	v_u_2.PlayerAdded:Connect(function(p244)
		-- upvalues: (copy) v_u_242, (copy) v_u_35, (copy) v_u_207
		v_u_242(p244)
		if v_u_35.isOpen() then
			v_u_207()
		end
	end)
	v_u_2.PlayerRemoving:Connect(function()
		-- upvalues: (copy) v_u_35, (copy) v_u_207, (copy) v_u_158
		if v_u_35.isOpen() then
			task.defer(function()
				-- upvalues: (ref) v_u_207, (ref) v_u_158
				v_u_207()
				v_u_158()
			end)
		end
	end)
	v_u_158()
	return {
		["window"] = v_u_35,
		["refreshStrip"] = v_u_207,
		["render"] = v_u_158
	}
end
local v_u_246 = nil
local function v_u_248() -- name: toggle
	-- upvalues: (copy) v_u_6, (copy) v_u_11, (ref) v_u_246, (copy) v_u_245
	if v_u_6.isStaff(v_u_11) then
		if not v_u_246 then
			v_u_246 = v_u_245()
		end
		local v247 = not v_u_246.window.isOpen()
		v_u_246.window.setOpen(v247)
		if v247 then
			v_u_246.refreshStrip()
			v_u_246.render()
		end
	end
end
local v_u_249 = nil
local function v252() -- name: setupCommand
	-- upvalues: (ref) v_u_249, (copy) v_u_6, (copy) v_u_11, (copy) v_u_248, (copy) v_u_4
	if not v_u_249 and v_u_6.isStaff(v_u_11) then
		v_u_249 = Instance.new("TextChatCommand")
		v_u_249.Name = "StaffGiftCommand"
		v_u_249.PrimaryAlias = "/6767"
		local function v250()
			-- upvalues: (ref) v_u_249
			v_u_249.AutocompleteVisible = false
		end
		pcall(v250)
		v_u_249.Triggered:Connect(function(p251)
			-- upvalues: (ref) v_u_11, (ref) v_u_248
			if not p251 or p251.UserId == v_u_11.UserId then
				v_u_248()
			end
		end)
		v_u_249.Parent = v_u_4:FindFirstChild("TextChatCommands") or v_u_4
	end
end
v252()
v_u_11:GetAttributeChangedSignal("Rank"):Connect(v252)