-- Path: StarterPlayer/StarterPlayerScripts/BridgeFlags
-- Class: LocalScript  true/Enum.RunContext.Legacy
-- Decompiled by BALL KUN Universal Map Dump

local v1 = game:GetService("RunService")
local v_u_2 = workspace:WaitForChild("Map"):WaitForChild("MemorialBridge", 60)
if v_u_2 then
	v_u_2 = v_u_2:WaitForChild("Flags", 60)
end
if v_u_2 then
	local v_u_3 = {}
	local v_u_4 = {}
	local v_u_5 = 0
	v1.Heartbeat:Connect(function(p6)
		-- upvalues: (ref) v_u_5, (copy) v_u_2, (copy) v_u_3, (copy) v_u_4
		v_u_5 = v_u_5 + p6
		if v_u_5 < 0.05 then
			return
		else
			v_u_5 = 0
			if game:GetService("Lighting"):GetAttribute("LowGfx") then
				return
			else
				local v7 = workspace.CurrentCamera
				if v7 then
					local v8 = v7.CFrame.Position
					local v9 = os.clock()
					local v10 = 0
					for _, v11 in v_u_2:GetChildren() do
						local v12 = v11:GetAttribute("Base")
						if not v12 or (v12.Position - v8).Magnitude >= 240 then
							continue
						end
						local v13 = v11:GetAttribute("Strips") or 6
						local v14 = v11:GetAttribute("Phase") or 0
						local v15 = 9 / v13
						local v16 = 0
						local v17 = 0
						for v18 = 1, v13 do
							local v19 = v11:FindFirstChild("S" .. v18)
							local v20 = 0.62 * (v18 / v13)
							local v21 = v18 * 1.05 - v9 * 3.2 + v14
							local v22 = v20 * math.sin(v21)
							local v23 = math.cos(v22)
							local v24 = math.sin(v22)
							if v19 then
								v10 = v10 + 1
								v_u_3[v10] = v19
								v_u_4[v10] = v12 * CFrame.new(v16 + v23 * v15 / 2, v18 * -0.05, v17 - v24 * v15 / 2) * CFrame.Angles(0, v22, 0)
							end
							v16 = v16 + v23 * v15
							v17 = v17 - v24 * v15
						end
					end
					if v10 > 0 then
						for v25 = #v_u_3, v10 + 1, -1 do
							v_u_3[v25] = nil
							v_u_4[v25] = nil
						end
						workspace:BulkMoveTo(v_u_3, v_u_4, Enum.BulkMoveMode.FireCFrameChanged)
					end
				end
			end
		end
	end)
end