-- Path: Players/ygggggg55551/PlayerScripts/CarClient/TuneMenu
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = require(game:GetService("ReplicatedStorage"):WaitForChild("UiOwn")).Instance
local v2 = game:GetService("Players")
local v3 = game:GetService("ReplicatedStorage")
game:GetService("UserInputService")
local v_u_4 = require(v3:WaitForChild("CarShared"))
local v_u_5 = require(v3:WaitForChild("GameUI"):WaitForChild("Skin"))
local v_u_6 = require(v3:WaitForChild("GameUI"):WaitForChild("Theme"))
local v_u_7 = v2.LocalPlayer
local v_u_8 = require(v3:WaitForChild("GameShared"))
local v9 = v3:WaitForChild("GameUI")
local v_u_10 = require(v9:WaitForChild("Icons"))
local v_u_11 = require(v9:WaitForChild("Toast"))
local v_u_12 = require(v9:WaitForChild("Store"))
local v_u_13 = require(v9:WaitForChild("ModePanel"))
local function v_u_17(p14, p15) -- name: lockMark
	-- upvalues: (copy) v_u_10
	if p14 then
		local v16 = p14:FindFirstChild("LockMark")
		if p15 and not v16 then
			v16 = v_u_10.make("lock", Color3.new(1, 1, 1), 16)
			v16.Name = "LockMark"
			v16.AnchorPoint = Vector2.new(1, 0.5)
			v16.Position = UDim2.new(1, -6, 0.5, 0)
			v16.Parent = p14
		end
		if v16 then
			v16.Visible = p15
		end
	end
end
local v_u_18 = {
	{
		["id"] = "Paint",
		["label"] = "Paint",
		["group"] = "Paint"
	},
	{
		["id"] = "Wheels",
		["label"] = "Wheels",
		["group"] = "Paint"
	},
	{
		["id"] = "Lights",
		["label"] = "RGB Lights",
		["group"] = "Other"
	},
	{
		["id"] = "Carbon",
		["label"] = "Carbon",
		["group"] = "Other"
	},
	{
		["id"] = "Exhaust",
		["label"] = "Exhaust",
		["group"] = "Other"
	},
	{
		["id"] = "Tint",
		["label"] = "Window Tint",
		["group"] = "Other"
	},
	{
		["id"] = "Lower",
		["label"] = "Lowering",
		["group"] = "Other"
	}
}
local v_u_19 = Vector2.new(540, 452)
local v_u_20 = {
	{
		["id"] = "Rim",
		["label"] = "Rims"
	},
	{
		["id"] = "Caliper",
		["label"] = "Brake calipers"
	}
}
local v_u_21 = {
	{
		["id"] = "Body",
		["label"] = "Main color"
	},
	{
		["id"] = "Accent",
		["label"] = "Second color"
	}
}
local v_u_22 = Vector2.new(264, 266)
local v_u_23 = {
	{
		["id"] = "Gloss",
		["label"] = "Gloss"
	},
	{
		["id"] = "Matte",
		["label"] = "Matte"
	},
	{
		["id"] = "Chrome",
		["label"] = "Chrome"
	}
}
local v_u_24 = {
	Color3.fromRGB(240, 240, 240),
	Color3.fromRGB(20, 20, 22),
	Color3.fromRGB(110, 112, 118),
	Color3.fromRGB(190, 192, 198),
	Color3.fromRGB(200, 20, 30),
	Color3.fromRGB(110, 10, 20),
	Color3.fromRGB(255, 120, 0),
	Color3.fromRGB(255, 210, 0),
	Color3.fromRGB(200, 160, 60),
	Color3.fromRGB(20, 150, 60),
	Color3.fromRGB(150, 230, 40),
	Color3.fromRGB(0, 190, 200),
	Color3.fromRGB(20, 90, 220),
	Color3.fromRGB(15, 30, 90),
	Color3.fromRGB(130, 50, 200),
	Color3.fromRGB(255, 110, 180),
	Color3.fromRGB(110, 70, 40),
	Color3.fromRGB(90, 100, 60)
}
local v_u_25 = {
	["Bonnet"] = "Hood",
	["Boot"] = "Trunk",
	["Wing"] = "Rear spoiler",
	["Aero"] = "Front lip / side skirts",
	["Doors"] = "Door panels (4)",
	["Mirrors"] = "Mirror caps",
	["Fenders"] = "Front fenders (2)",
	["Pillars"] = "Pillars / door sills",
	["Lip"] = "Front lip",
	["Skirts"] = "Side skirts",
	["Diffuser"] = "Rear diffuser"
}
local v_u_26 = {
	{
		["id"] = "Stock",
		["label"] = "Stock"
	},
	{
		["id"] = "Sport",
		["label"] = "Sport"
	},
	{
		["id"] = "Carbon",
		["label"] = "Carbon"
	},
	{
		["id"] = "Racing",
		["label"] = "Racing"
	}
}
local v_u_27 = {
	{
		["id"] = "Off",
		["label"] = "Off"
	},
	{
		["id"] = "Rainbow",
		["label"] = "Rainbow"
	},
	{
		["id"] = "Solid",
		["label"] = "Solid"
	},
	{
		["id"] = "Gradient",
		["label"] = "Gradient"
	},
	{
		["id"] = "Mode",
		["label"] = "Modes"
	}
}
local v_u_28 = {
	Color3.fromRGB(255, 255, 255),
	Color3.fromRGB(70, 140, 255),
	Color3.fromRGB(0, 230, 255),
	Color3.fromRGB(40, 255, 120),
	Color3.fromRGB(255, 230, 0),
	Color3.fromRGB(255, 120, 0),
	Color3.fromRGB(255, 30, 40),
	Color3.fromRGB(255, 60, 200),
	Color3.fromRGB(150, 60, 255)
}
local v_u_29 = {
	"Clear",
	"40% tint",
	"60% tint",
	"80% tint"
}
local v_u_30 = {
	"Stock",
	"Low 1",
	"Low 2",
	"Low 3",
	"Slammed"
}
local v_u_31 = v_u_5.PANEL
local v_u_32 = v_u_5.IDLE
local v_u_33 = v_u_5.SELECTED
local v_u_34 = v_u_5.DISABLED
local v_u_35 = v_u_8.TUNE_PRICES
local v_u_36 = {}
local v_u_37 = nil
local v_u_38 = nil
local v_u_39 = nil
local v_u_40 = nil
local v_u_41 = nil
local v_u_42 = {}
local v_u_43 = {}
local v_u_44 = {}
local v_u_45 = {}
local v_u_46 = {}
local v_u_47 = {}
local v_u_48 = {
	{
		["id"] = "Front",
		["label"] = "Front"
	},
	{
		["id"] = "Rear",
		["label"] = "Rear"
	}
}
local v_u_49 = {
	["Front"] = {},
	["Rear"] = {}
}
local v_u_50 = nil
local v_u_51 = nil
local v_u_52 = {}
local v_u_53 = {}
local v_u_54 = {}
local v_u_55 = nil
local v_u_56 = nil
local v_u_57 = {}
local v_u_58 = {}
local v_u_59 = nil
local v_u_60 = nil
local v_u_61 = nil
local v_u_62 = nil
local v_u_63 = {
	["model"] = nil,
	["fire"] = nil,
	["onToggle"] = nil,
	["tab"] = "Paint",
	["finish"] = "Gloss",
	["h"] = 0,
	["s"] = 0,
	["v"] = 1,
	["slot"] = 1,
	["group"] = nil,
	["wheelTarget"] = "Rim",
	["wheelFinish"] = "Gloss",
	["bodyTarget"] = "Body"
}
local function v_u_70() -- name: wheelTargets
	-- upvalues: (copy) v_u_63, (copy) v_u_20
	local v64 = {}
	if v_u_63.model then
		for _, v65 in v_u_63.model:GetDescendants() do
			if not v65:IsA("BasePart") then
				continue
			end
			local v66 = v65:GetAttribute("PaintGroup")
			if not v66 then
				continue
			end
			v64[v66] = true
		end
	end
	local v67 = {}
	for _, v68 in v_u_20 do
		if not v64[v68.id] then
			continue
		end
		local v69 = v68.id
		table.insert(v67, v69)
	end
	return v67
end
local function v_u_73(p71) -- name: hasPaintGroup
	-- upvalues: (copy) v_u_63
	if v_u_63.model then
		for _, v72 in v_u_63.model:GetDescendants() do
			if not v72:IsA("BasePart") or v72:GetAttribute("PaintGroup") ~= p71 then
				continue
			end
			return true
		end
	end
	return false
end
local function v_u_81(p74, p75, p76, p77, p78) -- name: textButton
	-- upvalues: (copy) v_u_1, (copy) v_u_32
	local v79 = v_u_1.new("TextButton")
	v79.Name = p74
	v79.Text = p75
	v79.Position = p76
	v79.Size = p77
	v79.BackgroundColor3 = v_u_32
	v79.TextColor3 = Color3.new(1, 1, 1)
	v79.Font = Enum.Font.GothamBold
	v79.TextSize = 18
	v79.TextWrapped = true
	v79.Parent = p78
	local v80 = v_u_1.new("UICorner")
	v80.CornerRadius = UDim.new(0, 10)
	v80.Parent = v79
	return v79
end
local function v_u_86(p82, ...) -- name: fire
	-- upvalues: (copy) v_u_63, (copy) v_u_8, (copy) v_u_7, (copy) v_u_11, (copy) v_u_12
	if v_u_63.fire and v_u_63.model then
		local v83, _, v84 = ...
		local v85
		if p82 == "Paint" and v84 == "Chrome" or p82 == "DRL" and (v83 == "Gradient" or v84 ~= nil) then
			v85 = true
		elseif p82 == "Underglow" then
			v85 = v83 == true
		else
			v85 = false
		end
		if v85 and v_u_8.passLocked(v_u_7, "Custom") then
			v_u_11.show("That\'s in the Custom pass", "info")
			v_u_12.open("Passes")
		else
			v_u_63.fire(p82, ...)
		end
	else
		return
	end
end
local function v_u_90() -- name: carbonParts
	-- upvalues: (copy) v_u_63, (copy) v_u_4
	local v87 = {}
	if v_u_63.model then
		for _, v88 in v_u_63.model:GetDescendants() do
			if not v88:IsA("BasePart") then
				continue
			end
			local v89 = v_u_4.carbonKeyOf(v88)
			if not v89 then
				continue
			end
			v87[v89] = (v87[v89] or 0) + 1
		end
	end
	return v87
end
local function v_u_188() -- name: refresh
	-- upvalues: (ref) v_u_37, (copy) v_u_63, (copy) v_u_18, (copy) v_u_42, (copy) v_u_33, (copy) v_u_32, (copy) v_u_70, (copy) v_u_19, (ref) v_u_38, (ref) v_u_39, (ref) v_u_41, (ref) v_u_60, (ref) v_u_61, (ref) v_u_62, (copy) v_u_57, (copy) v_u_58, (copy) v_u_4, (copy) v_u_8, (ref) v_u_59, (copy) v_u_35, (copy) v_u_23, (copy) v_u_43, (copy) v_u_73, (copy) v_u_54, (ref) v_u_55, (ref) v_u_56, (copy) v_u_27, (copy) v_u_26, (copy) v_u_45, (copy) v_u_46, (copy) v_u_29, (copy) v_u_20, (copy) v_u_52, (copy) v_u_53, (copy) v_u_7, (copy) v_u_17, (copy) v_u_90, (copy) v_u_44, (copy) v_u_47, (copy) v_u_30, (ref) v_u_50, (ref) v_u_51, (copy) v_u_48, (copy) v_u_49
	if v_u_37 then
		local v91 = v_u_63.model
		local v92 = {}
		for _, v93 in v_u_18 do
			local v94 = v_u_42[v93.id]
			local v95
			if v93.id == v_u_63.tab then
				v95 = v_u_33
			else
				v95 = v_u_32
			end
			v94.BackgroundColor3 = v95
			local v96
			if v_u_63.group == nil or v93.group == v_u_63.group then
				local v97 = v93.id
				if v97 == "Wheels" then
					v96 = #v_u_70() > 0
				elseif v97 == "Exhaust" then
					local v98 = v_u_63.model
					if v98 then
						v98 = v_u_63.model:GetAttribute("FixedExhaust") ~= nil
					end
					v96 = not v98
				else
					v96 = true
				end
			else
				v96 = false
			end
			v94.Visible = v96
			if not v94.Visible then
				continue
			end
			table.insert(v92, v94)
		end
		local v99 = v_u_19.X - 32 - (#v92 - 1) * 4
		local v100 = #v92
		local v101 = v99 / math.max(v100, 1)
		local v102 = math.floor(v101)
		local v103 = math.min(100, v102)
		for v104, v105 in v92 do
			v105.Position = UDim2.fromOffset(16 + (v104 - 1) * (v103 + 4), 56)
			v105.Size = UDim2.fromOffset(v103, 44)
		end
		local v106 = (v_u_63.tab == "Paint" or v_u_63.tab == "Wheels") and true or v_u_63.tab == "Lights"
		local v107
		if v_u_63.pickerFolded == true then
			if v_u_63.pickerShown == true then
				v107 = v106
			else
				v107 = false
			end
		else
			v107 = false
		end
		for v108, v109 in v_u_38 do
			local v110
			if v108 == v_u_63.tab then
				v110 = not v107
			else
				v110 = false
			end
			v109.Visible = v110
		end
		local v111 = v_u_39
		local v112
		if v106 then
			v112 = not v_u_63.pickerFolded or v_u_63.pickerShown == true
		else
			v112 = v106
		end
		v111.Visible = v112
		local v113 = v_u_41
		if v_u_63.pickerFolded ~= true then
			v106 = false
		end
		v113.Visible = v106
		local v114 = v_u_41
		local v115
		if v_u_63.pickerShown then
			v115 = v_u_33
		else
			v115 = v_u_32
		end
		v114.BackgroundColor3 = v115
		local v116
		if v91 then
			v116 = v91:GetAttribute("RainbowOn") == true
		else
			v116 = v91
		end
		local v117 = v91 and (v91:GetAttribute("DRLStyle") or "Rainbow") or "Rainbow"
		local v118
		if v116 then
			v118 = v117 == "Mode"
		else
			v118 = v116
		end
		v_u_60:setVisible(v118)
		v_u_60:refresh(v91)
		v_u_61.Visible = not v118
		v_u_62.Visible = not v118
		for v119, v120 in v_u_57 do
			local v121
			if v119 == "Off" then
				v121 = not v116
			elseif v116 then
				v121 = v119 == v117
			else
				v121 = v116
			end
			local v122
			if v121 then
				v122 = v_u_33
			else
				v122 = v_u_32
			end
			v120.BackgroundColor3 = v122
		end
		for v123, v124 in v_u_58 do
			v124.Visible = not v118
			local v125 = v91 and v91:GetAttribute("DRLColor") or v_u_4.DRL_DEFAULT_COLOR
			if v123 == 2 and v91 then
				v125 = v91:GetAttribute("DRLColor2") or v125
			end
			v124.BackgroundColor3 = v125
			local _, _, v126 = v125:ToHSV()
			local v127
			if v126 > 0.6 then
				v127 = Color3.new(0, 0, 0)
			else
				v127 = Color3.new(1, 1, 1)
			end
			v124.TextColor3 = v127
			v124.UIStroke.Transparency = v123 == v_u_63.slot and 0 or 0.8
		end
		local v128 = v_u_8.tuneOwned(v91)
		if v_u_59 then
			local v129
			if v91 then
				v129 = v91:GetAttribute("Underglow") == true
			else
				v129 = v91
			end
			local v130 = v_u_59
			local v131
			if v129 then
				v131 = v_u_33
			else
				v131 = v_u_32
			end
			v130.BackgroundColor3 = v131
			v_u_59.Text = "Underglow" .. (v129 and "  \226\156\147" or "  " .. v_u_8.tunePriceText(v91, "Underglow", v_u_35.Underglow))
		end
		for _, v132 in v_u_23 do
			local v133 = (v128["Paint_" .. v_u_63.bodyTarget] and 0 or v_u_35.Paint) + v_u_8.tuneCost(v128, "Finish_" .. v132.id, v_u_35.Finish[v132.id] or 0)
			v_u_43[v132.id].Text = v132.label .. "  " .. (v133 <= 0 and "Owned" or v_u_8.priceText(v133))
		end
		local v134 = v_u_73("Accent")
		if not v134 then
			v_u_63.bodyTarget = "Body"
		end
		for v135, v136 in v_u_54 do
			v136.Visible = v134
			local v137
			if v135 == v_u_63.bodyTarget then
				v137 = v_u_33
			else
				v137 = v_u_32
			end
			v136.BackgroundColor3 = v137
		end
		if v_u_55 then
			v_u_55.Position = UDim2.fromOffset(16, v134 and 162 or 112)
			v_u_55.Size = UDim2.new(1, -32, 0, v134 and 148 or 156)
		end
		for v138, v139 in v_u_23 do
			v_u_43[v139.id].Position = UDim2.fromOffset(16 + (v138 - 1) * 140, v134 and 318 or 280)
		end
		if v_u_56 then
			v_u_56.Position = UDim2.fromOffset(16, v134 and 372 or 340)
		end
		for _, v140 in v_u_27 do
			if v140.id == "Off" then
				continue
			end
			v_u_57[v140.id].Text = v140.label .. "  " .. v_u_8.tunePriceText(v91, "Light_" .. v140.id, v_u_35.Light[v140.id])
		end
		for _, v141 in v_u_26 do
			v_u_45[v141.id].Text = v141.label .. "\n" .. v_u_8.tunePriceText(v91, "Exhaust_" .. v141.id, v_u_35.Exhaust[v141.id])
		end
		for v142, v143 in v_u_46 do
			local v144 = v_u_8.tuneCost(v128, "Tint", v_u_35.Tint * v142, v142)
			v143.Text = (v_u_29[v142] or tostring(v142)) .. "\n" .. (v142 == 0 and "Free" or (v144 <= 0 and "Owned" or v_u_8.priceText(v144)))
		end
		for v145, v146 in v_u_43 do
			local v147
			if v145 == v_u_63.finish then
				v147 = v_u_33
			else
				v147 = v_u_32
			end
			v146.BackgroundColor3 = v147
		end
		local v148 = v_u_70()
		local v149 = 16
		for _, v150 in v_u_20 do
			local v151 = v_u_52[v150.id]
			v151.Visible = table.find(v148, v150.id) ~= nil
			local v152
			if v150.id == v_u_63.wheelTarget then
				v152 = v_u_33
			else
				v152 = v_u_32
			end
			v151.BackgroundColor3 = v152
			if not v151.Visible then
				continue
			end
			v151.Position = UDim2.fromOffset(v149, 112)
			v149 = v149 + 172
		end
		for _, v153 in v_u_23 do
			local v154 = (v128["Paint_" .. v_u_63.wheelTarget] and 0 or v_u_35.Paint) + v_u_8.tuneCost(v128, "Finish_" .. v153.id, v_u_35.Finish[v153.id] or 0)
			local v155 = v_u_53[v153.id]
			v155.Text = v153.label .. "  " .. (v154 <= 0 and "Owned" or v_u_8.priceText(v154))
			local v156
			if v153.id == v_u_63.wheelFinish then
				v156 = v_u_33
			else
				v156 = v_u_32
			end
			v155.BackgroundColor3 = v156
		end
		local v157 = v_u_8.passLocked(v_u_7, "Custom")
		v_u_17(v_u_43.Chrome, v157)
		v_u_17(v_u_53.Chrome, v157)
		v_u_17(v_u_57.Gradient, v157)
		v_u_17(v_u_58[2], v157)
		v_u_17(v_u_59, v157)
		local v158 = v_u_17
		local v159 = v_u_39
		if v159 then
			v159 = v_u_39:FindFirstChild("Apply")
		end
		v158(v159, v157)
		local v160 = v_u_90()
		for v161, v162 in v_u_44 do
			local v163
			if v91 then
				v163 = v91:GetAttribute("Carbon_" .. v161) == true
			else
				v163 = v91
			end
			v162.frame.Visible = (v160[v161] or 0) > 0
			local v164
			if v91 then
				v164 = v91:GetAttribute("CarbonPrice_" .. v161)
			else
				v164 = v91
			end
			if typeof(v164) ~= "number" then
				v164 = v_u_35.Carbon
			end
			v162.on.Text = "Carbon  " .. v_u_8.tunePriceText(v91, "Carbon_" .. v161, v164)
			local v165 = v162.on
			local v166
			if v163 then
				v166 = v_u_33
			else
				v166 = v_u_32
			end
			v165.BackgroundColor3 = v166
			local v167 = v162.off
			local v168
			if v163 then
				v168 = v_u_32
			else
				v168 = v_u_33
			end
			v167.BackgroundColor3 = v168
		end
		local v169 = v91 and (v91:GetAttribute("Exhaust") or "Stock") or "Stock"
		for v170, v171 in v_u_45 do
			local v172
			if v170 == v169 then
				v172 = v_u_33
			else
				v172 = v_u_32
			end
			v171.BackgroundColor3 = v172
		end
		local v173 = v91 and (v91:GetAttribute("Tint") or 0) or 0
		for v174, v175 in v_u_46 do
			local v176
			if v174 == v173 then
				v176 = v_u_33
			else
				v176 = v_u_32
			end
			v175.BackgroundColor3 = v176
		end
		local v177 = v91 and (v91:GetAttribute("LowerLevel") or 0) or 0
		local v178
		if v91 == nil then
			v178 = false
		else
			v178 = v91:GetAttribute("LowerSplit") == true
		end
		for v179, v180 in v_u_47 do
			v180.Visible = not v178
			local v181
			if v179 == v177 then
				v181 = v_u_33
			else
				v181 = v_u_32
			end
			v180.BackgroundColor3 = v181
			v180.Text = v_u_30[v179] .. "\n" .. (v179 == 0 and "Free" or v_u_8.tunePriceText(v91, "Lower", v_u_35.Lower))
		end
		if v_u_50 then
			v_u_50.Visible = v178
			v_u_51.Position = UDim2.fromOffset(16, v178 and 268 or 184)
			for _, v182 in v_u_48 do
				local v183 = v91 and (v91:GetAttribute("Lower" .. v182.id) or (v177 or 0)) or 0
				for v184, v185 in v_u_49[v182.id] do
					local v186 = v184 - v183
					local v187
					if math.abs(v186) < 0.01 then
						v187 = v_u_33
					else
						v187 = v_u_32
					end
					v185.BackgroundColor3 = v187
					v185.Text = v_u_30[v184] .. "\n" .. (v184 == 0 and "Free" or v_u_8.tunePriceText(v91, "Lower", v_u_35.Lower))
				end
			end
		end
	end
end
local function v_u_194(p189) -- name: paint
	-- upvalues: (copy) v_u_86, (copy) v_u_63, (copy) v_u_188
	local v190 = v_u_86
	local v191 = "Paint"
	local v192
	if v_u_63.tab == "Wheels" then
		v192 = v_u_63.wheelTarget
	else
		v192 = v_u_63.bodyTarget
	end
	local v193
	if v_u_63.tab == "Wheels" then
		v193 = v_u_63.wheelFinish
	else
		v193 = v_u_63.finish
	end
	v190(v191, v192, p189, v193)
	task.delay(0.25, v_u_188)
end
local function v_u_198(p195) -- name: pickLightColor
	-- upvalues: (copy) v_u_63, (copy) v_u_86, (copy) v_u_188
	local v196 = v_u_63.model and v_u_63.model:GetAttribute("DRLStyle") or "Rainbow"
	local v197 = (not v_u_63.model or (not v_u_63.model:GetAttribute("RainbowOn") or v196 == "Rainbow")) and "Solid" or v196
	if v_u_63.slot == 2 then
		v_u_86("DRL", "Gradient", nil, p195)
	else
		v_u_86("DRL", v197, p195, nil)
	end
	task.delay(0.25, v_u_188)
end
local v_u_199 = require(game:GetService("ReplicatedStorage"):WaitForChild("GameUI"):WaitForChild("ColorField"))
local v_u_200 = nil
local v_u_201 = nil
local function v_u_202() -- name: updatePicker
	-- upvalues: (ref) v_u_200, (copy) v_u_63, (ref) v_u_40, (ref) v_u_201
	if v_u_200 then
		v_u_200:set(v_u_63.h, v_u_63.s, v_u_63.v)
		v_u_40.BackgroundColor3 = Color3.fromHSV(v_u_63.h, v_u_63.s, v_u_63.v)
		if not v_u_201:IsFocused() then
			v_u_201.Text = "#" .. Color3.fromHSV(v_u_63.h, v_u_63.s, v_u_63.v):ToHex():upper()
		end
	end
end
local function v_u_213() -- name: loadPicker
	-- upvalues: (copy) v_u_63, (copy) v_u_4, (copy) v_u_202
	local v203 = v_u_63.model
	if v203 then
		local v204 = v_u_63.model
		local v205 = "Paint"
		local v206
		if v_u_63.tab == "Wheels" then
			v206 = v_u_63.wheelTarget
		else
			v206 = v_u_63.bodyTarget
		end
		v203 = v204:GetAttribute(v205 .. v206)
	end
	if v_u_63.tab == "Lights" and v_u_63.model then
		v203 = v_u_63.model:GetAttribute(v_u_63.slot == 2 and "DRLColor2" or "DRLColor") or v_u_4.DRL_DEFAULT_COLOR
	end
	if typeof(v203) == "Color3" then
		local v207 = v_u_63
		local v208 = v_u_63
		local v209 = v_u_63
		local v210, v211, v212 = v203:ToHSV()
		v207.h = v210
		v208.s = v211
		v209.v = v212
	end
	v_u_202()
end
local function v_u_217(p214) -- name: selectTab
	-- upvalues: (copy) v_u_63, (copy) v_u_73, (copy) v_u_70, (copy) v_u_213, (copy) v_u_188
	v_u_63.tab = p214
	v_u_63.pickerShown = false
	if not v_u_73("Accent") then
		v_u_63.bodyTarget = "Body"
	end
	local v215 = v_u_63.model
	if v215 then
		v215 = v_u_63.model:GetAttribute("Finish" .. v_u_63.bodyTarget)
	end
	if v215 then
		v_u_63.finish = v215
	end
	if p214 == "Wheels" then
		local v216 = v_u_70()
		if #v216 > 0 and not table.find(v216, v_u_63.wheelTarget) then
			v_u_63.wheelTarget = v216[1]
		end
		v_u_63.wheelFinish = v_u_63.model and v_u_63.model:GetAttribute("Finish" .. v_u_63.wheelTarget) or "Gloss"
	end
	v_u_213()
	v_u_188()
end
local function v_u_237(p218, p219, p220, p221, p_u_222) -- name: swatchGrid
	-- upvalues: (copy) v_u_1, (copy) v_u_63, (copy) v_u_202
	local v223 = v_u_1.new("Frame")
	v223.Name = "Swatches"
	v223.BackgroundTransparency = 1
	v223.Position = p219
	v223.Size = p220
	v223.Parent = p221
	local v224 = v_u_1.new("UIGridLayout")
	v224.CellSize = UDim2.fromOffset(44, 44)
	v224.CellPadding = UDim2.fromOffset(12, 12)
	v224.SortOrder = Enum.SortOrder.LayoutOrder
	v224.Parent = v223
	for v225, v_u_226 in p218 do
		local v227 = v_u_1.new("TextButton")
		v227.Name = "Swatch" .. v225
		v227.LayoutOrder = v225
		v227.Text = ""
		v227.AutoButtonColor = false
		v227.BackgroundColor3 = v_u_226
		v227.Parent = v223
		local v228 = v_u_1.new("UICorner")
		v228.CornerRadius = UDim.new(0, 22)
		v228.Parent = v227
		local v229 = v_u_1.new("UIGradient")
		v229.Rotation = 90
		v229.Color = ColorSequence.new(Color3.new(1, 1, 1), Color3.fromRGB(150, 150, 150))
		v229.Parent = v227
		local v230 = v_u_1.new("UIStroke")
		v230.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
		v230.Color = Color3.fromRGB(255, 255, 255)
		v230.Transparency = 0.8
		v230.Parent = v227
		v227.Activated:Connect(function()
			-- upvalues: (ref) v_u_63, (copy) v_u_226, (ref) v_u_202, (copy) p_u_222
			local v231 = v_u_63
			local v232 = v_u_63
			local v233 = v_u_63
			local v234, v235, v236 = v_u_226:ToHSV()
			v231.h = v234
			v232.s = v235
			v233.v = v236
			v_u_202()
			p_u_222(v_u_226)
		end)
	end
	return v223
end
local function v_u_420() -- name: build
	-- upvalues: (ref) v_u_37, (copy) v_u_1, (copy) v_u_7, (copy) v_u_5, (copy) v_u_19, (copy) v_u_31, (copy) v_u_6, (copy) v_u_81, (copy) v_u_36, (ref) v_u_41, (copy) v_u_63, (copy) v_u_188, (copy) v_u_18, (copy) v_u_217, (copy) v_u_42, (ref) v_u_38, (copy) v_u_21, (copy) v_u_213, (copy) v_u_54, (ref) v_u_55, (copy) v_u_237, (copy) v_u_24, (copy) v_u_194, (copy) v_u_23, (copy) v_u_8, (copy) v_u_35, (copy) v_u_11, (copy) v_u_12, (copy) v_u_86, (copy) v_u_43, (ref) v_u_56, (copy) v_u_34, (copy) v_u_20, (copy) v_u_52, (copy) v_u_53, (copy) v_u_27, (ref) v_u_60, (copy) v_u_57, (copy) v_u_58, (ref) v_u_62, (ref) v_u_61, (copy) v_u_28, (copy) v_u_198, (copy) v_u_13, (ref) v_u_59, (copy) v_u_4, (copy) v_u_25, (copy) v_u_44, (copy) v_u_26, (copy) v_u_45, (copy) v_u_29, (copy) v_u_46, (copy) v_u_30, (copy) v_u_47, (ref) v_u_51, (ref) v_u_50, (copy) v_u_48, (copy) v_u_49, (ref) v_u_39, (ref) v_u_40, (ref) v_u_201, (copy) v_u_202, (ref) v_u_200, (copy) v_u_199, (copy) v_u_33
	v_u_37 = v_u_1.new("ScreenGui")
	v_u_37.Name = "CarTune"
	v_u_37.ResetOnSpawn = false
	v_u_37.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
	v_u_37.DisplayOrder = 5
	v_u_37.Enabled = false
	v_u_37.Parent = v_u_7:WaitForChild("PlayerGui")
	v_u_5.apply(v_u_37)
	local v238 = v_u_1.new("Frame")
	v238.Name = "Panel"
	v238.AnchorPoint = Vector2.new(0.5, 0.5)
	v238.Position = UDim2.fromScale(0.5, 0.5)
	v238.Size = UDim2.fromOffset(v_u_19.X, v_u_19.Y)
	v238.BackgroundColor3 = v_u_31
	v238.BackgroundTransparency = 0.1
	v238.Parent = v_u_37
	local v239 = v_u_1.new("UICorner")
	v239.CornerRadius = UDim.new(0, 16)
	v239.Parent = v238
	local v240 = UDim2.fromOffset(20, 10)
	local v241 = UDim2.fromOffset(200, 12)
	local v242 = v_u_1.new("TextLabel")
	v242.BackgroundTransparency = 1
	v242.Position = v240
	v242.Size = v241
	v242.Font = Enum.Font.GothamBold
	v242.TextSize = 16
	v242.TextWrapped = true
	v242.TextColor3 = Color3.fromRGB(200, 200, 200)
	v242.Text = "C\226\128\137U\226\128\137S\226\128\137T\226\128\137O\226\128\137M\226\128\137I\226\128\137Z\226\128\137E"
	v242.Parent = v238
	v242.Name = "Kicker"
	v242.TextSize = 11
	v242.TextColor3 = v_u_6.ACCENT_LIGHT
	v242.TextXAlignment = Enum.TextXAlignment.Left
	local v243 = UDim2.fromOffset(20, 18)
	local v244 = UDim2.new(1, -250, 0, 28)
	local v245 = v_u_1.new("TextLabel")
	v245.BackgroundTransparency = 1
	v245.Position = v243
	v245.Size = v244
	v245.Font = Enum.Font.GothamBold
	v245.TextSize = 16
	v245.TextWrapped = true
	v245.TextColor3 = Color3.fromRGB(200, 200, 200)
	v245.Text = "Car Tuning"
	v245.Parent = v238
	v245.Font = Enum.Font.GothamBlack
	v245.TextSize = 21
	v245.TextColor3 = Color3.new(1, 1, 1)
	v245.TextXAlignment = Enum.TextXAlignment.Left
	local v246 = v_u_1.new("Frame")
	v246.Name = "TitleBar"
	v246.BorderSizePixel = 0
	v246.BackgroundColor3 = v_u_6.ACCENT
	v246.Position = UDim2.fromOffset(20, 46)
	v246.Size = UDim2.fromOffset(34, 3)
	v246.Parent = v238
	local v247 = v_u_1.new("UICorner")
	v247.CornerRadius = UDim.new(0, 2)
	v247.Parent = v246
	local v248 = v_u_1.new("Frame")
	v248.Name = "TabsLine"
	v248.BorderSizePixel = 0
	v248.BackgroundColor3 = Color3.new(1, 1, 1)
	v248.BackgroundTransparency = 0.92
	v248.Position = UDim2.fromOffset(16, 101)
	v248.Size = UDim2.new(1, -32, 0, 1)
	v248.Parent = v238
	v_u_81("Close", "Close", UDim2.new(1, -72, 0, 8), UDim2.fromOffset(60, 44), v238).Activated:Connect(function()
		-- upvalues: (ref) v_u_36
		v_u_36.close()
	end)
	v_u_41 = v_u_81("PickerToggle", "Custom color", UDim2.new(1, -184, 0, 8), UDim2.fromOffset(104, 44), v238)
	v_u_41.TextSize = 16
	v_u_41.Visible = false
	v_u_41.Activated:Connect(function()
		-- upvalues: (ref) v_u_63, (ref) v_u_188
		v_u_63.pickerShown = not v_u_63.pickerShown
		v_u_188()
	end)
	for v249, v_u_250 in v_u_18 do
		local v251 = v_u_81("Tab" .. v_u_250.id, v_u_250.label, UDim2.fromOffset(16 + (v249 - 1) * 104, 56), UDim2.fromOffset(100, 44), v238)
		v251.Activated:Connect(function()
			-- upvalues: (ref) v_u_217, (copy) v_u_250
			v_u_217(v_u_250.id)
		end)
		v_u_42[v_u_250.id] = v251
	end
	v_u_38 = {}
	local v252 = v_u_38
	local v253 = v_u_1.new("Frame")
	v253.Name = "PaintPage"
	v253.BackgroundTransparency = 1
	v253.Size = UDim2.fromScale(1, 1)
	v253.Visible = false
	v253.Parent = v_u_37.Panel
	v252.Paint = v253
	for v254, v_u_255 in v_u_21 do
		local v256 = v_u_81("Target" .. v_u_255.id, v_u_255.label, UDim2.fromOffset(16 + (v254 - 1) * 172, 112), UDim2.fromOffset(164, 40), v_u_38.Paint)
		v256.TextSize = 16
		v256.Visible = false
		v256.Activated:Connect(function()
			-- upvalues: (ref) v_u_63, (copy) v_u_255, (ref) v_u_213, (ref) v_u_188
			v_u_63.bodyTarget = v_u_255.id
			v_u_63.finish = v_u_63.model and v_u_63.model:GetAttribute("Finish" .. v_u_255.id) or "Gloss"
			v_u_213()
			v_u_188()
		end)
		v_u_54[v_u_255.id] = v256
	end
	v_u_55 = v_u_237(v_u_24, UDim2.fromOffset(16, 112), UDim2.new(1, -32, 0, 156), v_u_38.Paint, v_u_194)
	for v257, v_u_258 in v_u_23 do
		local v259 = v_u_81("Finish" .. v_u_258.id, v_u_258.label .. "  " .. v_u_8.priceText(v_u_35.Paint + (v_u_35.Finish[v_u_258.id] or 0)), UDim2.fromOffset(16 + (v257 - 1) * 140, 280), UDim2.fromOffset(128, 44), v_u_38.Paint)
		v259.TextSize = 15
		v259.Activated:Connect(function()
			-- upvalues: (copy) v_u_258, (ref) v_u_8, (ref) v_u_7, (ref) v_u_11, (ref) v_u_12, (ref) v_u_63, (ref) v_u_188, (ref) v_u_86
			if v_u_258.id == "Chrome" and v_u_8.passLocked(v_u_7, "Custom") then
				v_u_11.show("That\'s in the Custom pass", "info")
				v_u_12.open("Passes")
			else
				v_u_63.finish = v_u_258.id
				v_u_188()
				local v260 = v_u_63.model
				if v260 then
					v260 = v_u_63.model:GetAttribute("Paint" .. v_u_63.bodyTarget)
				end
				if v260 then
					local v261 = v_u_86
					local v262 = "Paint"
					local v263
					if v_u_63.tab == "Wheels" then
						v263 = v_u_63.wheelTarget
					else
						v263 = v_u_63.bodyTarget
					end
					local v264
					if v_u_63.tab == "Wheels" then
						v264 = v_u_63.wheelFinish
					else
						v264 = v_u_63.finish
					end
					v261(v262, v263, v260, v264)
					task.delay(0.25, v_u_188)
				end
			end
		end)
		v_u_43[v_u_258.id] = v259
	end
	local v265 = v_u_81("Reset", "Original color  (free)", UDim2.fromOffset(16, 340), UDim2.new(1, -32, 0, 44), v_u_38.Paint)
	v_u_56 = v265
	v265.BackgroundColor3 = v_u_34
	v265.Activated:Connect(function()
		-- upvalues: (ref) v_u_86, (ref) v_u_63, (ref) v_u_188
		local v266 = v_u_86
		local v267 = "Paint"
		local v268
		if v_u_63.tab == "Wheels" then
			v268 = v_u_63.wheelTarget
		else
			v268 = v_u_63.bodyTarget
		end
		local v269 = false
		local v270
		if v_u_63.tab == "Wheels" then
			v270 = v_u_63.wheelFinish
		else
			v270 = v_u_63.finish
		end
		v266(v267, v268, v269, v270)
		task.delay(0.25, v_u_188)
	end)
	local v271 = v_u_38
	local v272 = v_u_1.new("Frame")
	v272.Name = "WheelsPage"
	v272.BackgroundTransparency = 1
	v272.Size = UDim2.fromScale(1, 1)
	v272.Visible = false
	v272.Parent = v_u_37.Panel
	v271.Wheels = v272
	for v273, v_u_274 in v_u_20 do
		local v275 = v_u_81("Target" .. v_u_274.id, v_u_274.label, UDim2.fromOffset(16 + (v273 - 1) * 172, 112), UDim2.fromOffset(164, 40), v_u_38.Wheels)
		v275.TextSize = 16
		v275.Activated:Connect(function()
			-- upvalues: (ref) v_u_63, (copy) v_u_274, (ref) v_u_213, (ref) v_u_188
			v_u_63.wheelTarget = v_u_274.id
			v_u_63.wheelFinish = v_u_63.model and v_u_63.model:GetAttribute("Finish" .. v_u_274.id) or "Gloss"
			v_u_213()
			v_u_188()
		end)
		v_u_52[v_u_274.id] = v275
	end
	v_u_237(v_u_24, UDim2.fromOffset(16, 162), UDim2.new(1, -32, 0, 148), v_u_38.Wheels, v_u_194)
	for v276, v_u_277 in v_u_23 do
		local v278 = v_u_81("Finish" .. v_u_277.id, v_u_277.label .. "  " .. v_u_8.priceText(v_u_35.Paint + (v_u_35.Finish[v_u_277.id] or 0)), UDim2.fromOffset(16 + (v276 - 1) * 140, 318), UDim2.fromOffset(128, 44), v_u_38.Wheels)
		v278.TextSize = 15
		v278.Activated:Connect(function()
			-- upvalues: (copy) v_u_277, (ref) v_u_8, (ref) v_u_7, (ref) v_u_11, (ref) v_u_12, (ref) v_u_63, (ref) v_u_188, (ref) v_u_86
			if v_u_277.id == "Chrome" and v_u_8.passLocked(v_u_7, "Custom") then
				v_u_11.show("That\'s in the Custom pass", "info")
				v_u_12.open("Passes")
			else
				v_u_63.wheelFinish = v_u_277.id
				v_u_188()
				local v279 = v_u_63.model
				if v279 then
					v279 = v_u_63.model:GetAttribute("Paint" .. v_u_63.wheelTarget)
				end
				if v279 then
					local v280 = v_u_86
					local v281 = "Paint"
					local v282
					if v_u_63.tab == "Wheels" then
						v282 = v_u_63.wheelTarget
					else
						v282 = v_u_63.bodyTarget
					end
					local v283
					if v_u_63.tab == "Wheels" then
						v283 = v_u_63.wheelFinish
					else
						v283 = v_u_63.finish
					end
					v280(v281, v282, v279, v283)
					task.delay(0.25, v_u_188)
				end
			end
		end)
		v_u_53[v_u_277.id] = v278
	end
	local v284 = v_u_81("Reset", "Original color  (free)", UDim2.fromOffset(16, 372), UDim2.new(1, -32, 0, 44), v_u_38.Wheels)
	v284.BackgroundColor3 = v_u_34
	v284.Activated:Connect(function()
		-- upvalues: (ref) v_u_86, (ref) v_u_63, (ref) v_u_188
		local v285 = v_u_86
		local v286 = "Paint"
		local v287
		if v_u_63.tab == "Wheels" then
			v287 = v_u_63.wheelTarget
		else
			v287 = v_u_63.bodyTarget
		end
		local v288 = false
		local v289
		if v_u_63.tab == "Wheels" then
			v289 = v_u_63.wheelFinish
		else
			v289 = v_u_63.finish
		end
		v285(v286, v287, v288, v289)
		task.delay(0.25, v_u_188)
	end)
	local v290 = v_u_38
	local v291 = v_u_1.new("Frame")
	v291.Name = "LightsPage"
	v291.BackgroundTransparency = 1
	v291.Size = UDim2.fromScale(1, 1)
	v291.Visible = false
	v291.Parent = v_u_37.Panel
	v290.Lights = v291
	for v292, v_u_293 in v_u_27 do
		local v294 = v_u_81
		local v295 = "Light" .. v_u_293.id
		local v296
		if v_u_293.id == "Off" then
			v296 = v_u_293.label
		else
			v296 = v_u_293.label .. "  " .. v_u_8.priceText(v_u_35.Light[v_u_293.id])
		end
		local v297 = v294(v295, v296, UDim2.fromOffset(16 + (v292 - 1) * 102, 112), UDim2.fromOffset(96, 44), v_u_38.Lights)
		v297.TextSize = 13
		v297.Activated:Connect(function()
			-- upvalues: (copy) v_u_293, (ref) v_u_60, (ref) v_u_63, (ref) v_u_86, (ref) v_u_188
			if v_u_293.id == "Mode" then
				v_u_60:refresh(v_u_63.model)
				local v298 = v_u_86
				local v299 = "DRLMode"
				local v300 = v_u_60.mode
				local v301 = v_u_60.speed
				local v302 = v_u_60.split
				local v303
				if v_u_60.split then
					v303 = v_u_60.modeRight
				else
					v303 = nil
				end
				v298(v299, v300, v301, v302, v303, v_u_60.modeRear)
			else
				v_u_86("DRL", v_u_293.id)
			end
			task.delay(0.25, v_u_188)
		end)
		v_u_57[v_u_293.id] = v297
	end
	for v_u_304 = 1, 2 do
		local v305 = v_u_81("Slot" .. v_u_304, "Color " .. v_u_304, UDim2.fromOffset((v_u_304 - 1) * 128 + 16, 166), UDim2.fromOffset(120, 40), v_u_38.Lights)
		local v306 = v_u_1.new("UIStroke")
		v306.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
		v306.Thickness = 3
		v306.Color = v_u_6.ACCENT
		v306.Parent = v305
		v305.Activated:Connect(function()
			-- upvalues: (ref) v_u_63, (copy) v_u_304, (ref) v_u_213, (ref) v_u_188
			v_u_63.slot = v_u_304
			v_u_213()
			v_u_188()
		end)
		v_u_58[v_u_304] = v305
	end
	local v307 = UDim2.fromOffset(272, 166)
	local v308 = UDim2.fromOffset(252, 40)
	local v309 = v_u_38.Lights
	local v310 = v_u_1.new("TextLabel")
	v310.BackgroundTransparency = 1
	v310.Position = v307
	v310.Size = v308
	v310.Font = Enum.Font.GothamBold
	v310.TextSize = 16
	v310.TextWrapped = true
	v310.TextColor3 = Color3.fromRGB(200, 200, 200)
	v310.Text = "Headlights change color with the engine on. Pick a slot, then a color or drag the bars"
	v310.Parent = v309
	v_u_62 = v310
	v_u_62.TextSize = 13
	v_u_62.TextXAlignment = Enum.TextXAlignment.Left
	v_u_61 = v_u_237(v_u_28, UDim2.fromOffset(16, 218), UDim2.new(1, -32, 0, 100), v_u_38.Lights, v_u_198)
	v_u_60 = v_u_13.new(v_u_38.Lights, UDim2.fromOffset(16, 166), v_u_19.X - 32, function(p311, p312, p313, p314, p315)
		-- upvalues: (ref) v_u_86
		v_u_86("DRLMode", p311, p312, p313, p314, p315)
	end)
	v_u_60:setVisible(false)
	v_u_59 = v_u_81("Underglow", "Underglow", UDim2.fromOffset(16, 392), UDim2.new(1, -32, 0, 44), v_u_38.Lights)
	v_u_59.Activated:Connect(function()
		-- upvalues: (ref) v_u_86, (ref) v_u_63, (ref) v_u_188
		v_u_86("Underglow", v_u_63.model:GetAttribute("Underglow") ~= true)
		task.delay(0.25, v_u_188)
	end)
	local v316 = v_u_38
	local v317 = v_u_1.new("Frame")
	v317.Name = "CarbonPage"
	v317.BackgroundTransparency = 1
	v317.Size = UDim2.fromScale(1, 1)
	v317.Visible = false
	v317.Parent = v_u_37.Panel
	v316.Carbon = v317
	local v318 = v_u_1.new("ScrollingFrame")
	v318.Name = "Rows"
	v318.BackgroundTransparency = 1
	v318.BorderSizePixel = 0
	v318.Position = UDim2.fromOffset(16, 110)
	v318.Size = UDim2.new(1, -32, 0, 262)
	v318.CanvasSize = UDim2.new()
	v318.AutomaticCanvasSize = Enum.AutomaticSize.Y
	v318.ScrollBarThickness = 5
	v318.Parent = v_u_38.Carbon
	local v319 = v_u_1.new("UIListLayout")
	v319.Padding = UDim.new(0, 6)
	v319.SortOrder = Enum.SortOrder.LayoutOrder
	v319.Parent = v318
	for v320, v_u_321 in v_u_4.CARBON_KEYS do
		local v322 = v_u_1.new("Frame")
		v322.Name = "Row" .. v_u_321
		v322.BackgroundTransparency = 1
		v322.LayoutOrder = v320
		v322.Size = UDim2.new(1, -8, 0, 48)
		v322.Parent = v318
		local v323 = v_u_25[v_u_321] or v_u_321
		local v324 = UDim2.fromOffset(0, 0)
		local v325 = UDim2.new(1, -262, 1, 0)
		local v326 = v_u_1.new("TextLabel")
		v326.BackgroundTransparency = 1
		v326.Position = v324
		v326.Size = v325
		v326.Font = Enum.Font.GothamBold
		v326.TextSize = 16
		v326.TextWrapped = true
		v326.TextColor3 = Color3.fromRGB(200, 200, 200)
		v326.Text = v323
		v326.Parent = v322
		v326.TextXAlignment = Enum.TextXAlignment.Left
		v326.TextColor3 = Color3.new(1, 1, 1)
		v326.TextSize = 15
		local v327 = v_u_81("On", "Carbon", UDim2.new(1, -256, 0, 2), UDim2.fromOffset(150, 44), v322)
		v327.TextSize = 15
		local v328 = v_u_81("Off", "Stock", UDim2.new(1, -98, 0, 2), UDim2.fromOffset(92, 44), v322)
		v328.TextSize = 15
		v327.Activated:Connect(function()
			-- upvalues: (ref) v_u_86, (copy) v_u_321, (ref) v_u_188
			v_u_86("Carbon", v_u_321, true)
			task.delay(0.25, v_u_188)
		end)
		v328.Activated:Connect(function()
			-- upvalues: (ref) v_u_86, (copy) v_u_321, (ref) v_u_188
			v_u_86("Carbon", v_u_321, false)
			task.delay(0.25, v_u_188)
		end)
		v_u_44[v_u_321] = {
			["frame"] = v322,
			["on"] = v327,
			["off"] = v328
		}
	end
	local v329 = UDim2.fromOffset(16, 378)
	local v330 = UDim2.new(1, -32, 0, 48)
	local v331 = v_u_38.Carbon
	local v332 = v_u_1.new("TextLabel")
	v332.BackgroundTransparency = 1
	v332.Position = v329
	v332.Size = v330
	v332.Font = Enum.Font.GothamBold
	v332.TextSize = 16
	v332.TextWrapped = true
	v332.TextColor3 = Color3.fromRGB(200, 200, 200)
	v332.Text = "Tap to fit / remove carbon parts"
	v332.Parent = v331
	v332.TextSize = 14
	local v333 = v_u_38
	local v334 = v_u_1.new("Frame")
	v334.Name = "ExhaustPage"
	v334.BackgroundTransparency = 1
	v334.Size = UDim2.fromScale(1, 1)
	v334.Visible = false
	v334.Parent = v_u_37.Panel
	v333.Exhaust = v334
	for v335, v_u_336 in v_u_26 do
		local v337 = v_u_81("Exhaust" .. v_u_336.id, v_u_336.label .. "\n" .. v_u_8.priceText(v_u_35.Exhaust[v_u_336.id]), UDim2.fromOffset(16 + (v335 - 1) * 128, 112), UDim2.fromOffset(120, 62), v_u_38.Exhaust)
		v337.TextSize = 16
		local v338 = v_u_1.new("Frame")
		v338.Name = "Loudness"
		v338.BackgroundTransparency = 1
		v338.AnchorPoint = Vector2.new(1, 0)
		v338.Position = UDim2.new(1, -8, 0, 8)
		v338.Size = UDim2.fromOffset(30, 16)
		v338.Parent = v337
		for v339 = 1, #v_u_26 do
			local v340 = v_u_1.new("Frame")
			v340.BorderSizePixel = 0
			v340.AnchorPoint = Vector2.new(0, 1)
			v340.Position = UDim2.new(0, (v339 - 1) * 8, 1, 0)
			v340.Size = UDim2.fromOffset(5, v339 * 3 + 4)
			v340.BackgroundColor3 = Color3.new(1, 1, 1)
			v340.BackgroundTransparency = v339 <= v335 and 0.1 or 0.75
			v340.Parent = v338
			local v341 = v_u_1.new("UICorner")
			v341.CornerRadius = UDim.new(0, 2)
			v341.Parent = v340
		end
		v337.Activated:Connect(function()
			-- upvalues: (ref) v_u_86, (copy) v_u_336, (ref) v_u_188
			v_u_86("Exhaust", v_u_336.id)
			task.delay(0.25, v_u_188)
		end)
		v_u_45[v_u_336.id] = v337
	end
	local v342 = UDim2.fromOffset(16, 184)
	local v343 = UDim2.new(1, -32, 0, 110)
	local v344 = v_u_38.Exhaust
	local v345 = v_u_1.new("TextLabel")
	v345.BackgroundTransparency = 1
	v345.Position = v342
	v345.Size = v343
	v345.Font = Enum.Font.GothamBold
	v345.TextSize = 16
	v345.TextWrapped = true
	v345.TextColor3 = Color3.fromRGB(200, 200, 200)
	v345.Text = "The louder the exhaust, the more it costs.\nSport: deeper and louder, pops when you lift off at high revs\nCarbon: raspy and aggressive, pops often\nRacing: loudest, rapid pops and flames from the tip"
	v345.Parent = v344
	v345.TextXAlignment = Enum.TextXAlignment.Left
	v345.TextYAlignment = Enum.TextYAlignment.Top
	local v346 = v_u_38
	local v347 = v_u_1.new("Frame")
	v347.Name = "TintPage"
	v347.BackgroundTransparency = 1
	v347.Size = UDim2.fromScale(1, 1)
	v347.Visible = false
	v347.Parent = v_u_37.Panel
	v346.Tint = v347
	for v_u_348 = 0, #v_u_4.TINTS do
		local v349 = v_u_81("Tint" .. v_u_348, (v_u_29[v_u_348] or tostring(v_u_348)) .. "\n" .. v_u_8.priceText(v_u_35.Tint * v_u_348), UDim2.fromOffset(v_u_348 * 128 + 16, 112), UDim2.fromOffset(120, 62), v_u_38.Tint)
		v349.TextSize = 16
		v349.Activated:Connect(function()
			-- upvalues: (ref) v_u_86, (copy) v_u_348, (ref) v_u_188
			v_u_86("Tint", v_u_348)
			task.delay(0.25, v_u_188)
		end)
		v_u_46[v_u_348] = v349
	end
	local v350 = UDim2.fromOffset(16, 184)
	local v351 = UDim2.new(1, -32, 0, 60)
	local v352 = v_u_38.Tint
	local v353 = v_u_1.new("TextLabel")
	v353.BackgroundTransparency = 1
	v353.Position = v350
	v353.Size = v351
	v353.Font = Enum.Font.GothamBold
	v353.TextSize = 16
	v353.TextWrapped = true
	v353.TextColor3 = Color3.fromRGB(200, 200, 200)
	v353.Text = "Higher numbers are darker: less of the inside shows"
	v353.Parent = v352
	local v354 = v_u_38
	local v355 = v_u_1.new("Frame")
	v355.Name = "LowerPage"
	v355.BackgroundTransparency = 1
	v355.Size = UDim2.fromScale(1, 1)
	v355.Visible = false
	v355.Parent = v_u_37.Panel
	v354.Lower = v355
	for v_u_356 = 0, v_u_4.LOWER_LEVELS do
		local v357 = v_u_81("Lower" .. v_u_356, v_u_30[v_u_356], UDim2.fromOffset(v_u_356 * 104 + 16, 112), UDim2.fromOffset(98, 62), v_u_38.Lower)
		v357.TextSize = 15
		v357.Activated:Connect(function()
			-- upvalues: (ref) v_u_86, (copy) v_u_356, (ref) v_u_188
			v_u_86("Lower", v_u_356)
			task.delay(0.25, v_u_188)
		end)
		v_u_47[v_u_356] = v357
	end
	local v358 = UDim2.fromOffset(16, 184)
	local v359 = UDim2.new(1, -32, 0, 60)
	local v360 = v_u_38.Lower
	local v361 = v_u_1.new("TextLabel")
	v361.BackgroundTransparency = 1
	v361.Position = v358
	v361.Size = v359
	v361.Font = Enum.Font.GothamBold
	v361.TextSize = 16
	v361.TextWrapped = true
	v361.TextColor3 = Color3.fromRGB(200, 200, 200)
	v361.Text = "The body sits lower on its wheels. The lowering kit is bought once for this car: then any height is free"
	v361.Parent = v360
	v_u_51 = v361
	v_u_50 = v_u_1.new("Frame")
	v_u_50.Name = "LowerEnds"
	v_u_50.BackgroundTransparency = 1
	v_u_50.Size = UDim2.fromScale(1, 1)
	v_u_50.Visible = false
	v_u_50.Parent = v_u_38.Lower
	for v362, v_u_363 in v_u_48 do
		local v364 = 96 + (v362 - 1) * 86
		local v365 = v_u_363.label
		local v366 = UDim2.fromOffset(16, v364)
		local v367 = UDim2.fromOffset(200, 22)
		local v368 = v_u_50
		local v369 = v_u_1.new("TextLabel")
		v369.BackgroundTransparency = 1
		v369.Position = v366
		v369.Size = v367
		v369.Font = Enum.Font.GothamBold
		v369.TextSize = 16
		v369.TextWrapped = true
		v369.TextColor3 = Color3.fromRGB(200, 200, 200)
		v369.Text = v365
		v369.Parent = v368
		v369.TextXAlignment = Enum.TextXAlignment.Left
		v369.TextColor3 = Color3.new(1, 1, 1)
		for v_u_370 = 0, v_u_4.LOWER_LEVELS do
			local v371 = v_u_81("Lower" .. v_u_363.id .. v_u_370, v_u_30[v_u_370], UDim2.fromOffset(v_u_370 * 104 + 16, v364 + 26), UDim2.fromOffset(98, 54), v_u_50)
			v371.TextSize = 15
			v371.Activated:Connect(function()
				-- upvalues: (ref) v_u_86, (copy) v_u_370, (copy) v_u_363, (ref) v_u_188
				v_u_86("Lower", v_u_370, v_u_363.id)
				task.delay(0.25, v_u_188)
			end)
			v_u_49[v_u_363.id][v_u_370] = v371
		end
	end
	v_u_39 = v_u_1.new("Frame")
	v_u_39.Name = "Picker"
	v_u_39.AnchorPoint = Vector2.new(0, 0.5)
	v_u_39.Position = UDim2.new(0.5, 282, 0.5, 0)
	v_u_39.Size = UDim2.fromOffset(264, 266)
	v_u_39.BackgroundColor3 = v_u_31
	v_u_39.BackgroundTransparency = 0.1
	v_u_39.ZIndex = 2
	v_u_39.Parent = v_u_37
	local v372 = v_u_39
	local v373 = v_u_1.new("UICorner")
	v373.CornerRadius = UDim.new(0, 16)
	v373.Parent = v372
	local v374 = UDim2.fromOffset(14, 8)
	local v375 = UDim2.new(1, -28, 0, 30)
	local v376 = v_u_39
	local v377 = v_u_1.new("TextLabel")
	v377.BackgroundTransparency = 1
	v377.Position = v374
	v377.Size = v375
	v377.Font = Enum.Font.GothamBold
	v377.TextSize = 16
	v377.TextWrapped = true
	v377.TextColor3 = Color3.fromRGB(200, 200, 200)
	v377.Text = "Custom color (drag)"
	v377.Parent = v376
	v377.TextColor3 = Color3.new(1, 1, 1)
	v377.TextXAlignment = Enum.TextXAlignment.Left
	v_u_40 = v_u_1.new("Frame")
	v_u_40.Name = "Preview"
	v_u_40.Position = UDim2.fromOffset(14, 178)
	v_u_40.Size = UDim2.fromOffset(30, 30)
	v_u_40.Parent = v_u_39
	local v378 = v_u_40
	local v379 = v_u_1.new("UICorner")
	v379.CornerRadius = UDim.new(0, 15)
	v379.Parent = v378
	local v380 = v_u_1.new("UIStroke")
	v380.Color = Color3.new(1, 1, 1)
	v380.Transparency = 0.6
	v380.Thickness = 2
	v380.Parent = v_u_40
	v_u_201 = v_u_1.new("TextBox")
	v_u_201.Name = "Hex"
	v_u_201.Text = ""
	v_u_201.PlaceholderText = "#RRGGBB"
	v_u_201.ClearTextOnFocus = true
	v_u_201.FontFace = v_u_6.FONT_DISPLAY
	v_u_201.TextSize = 16
	v_u_201.TextColor3 = Color3.new(1, 1, 1)
	v_u_201.PlaceholderColor3 = Color3.fromRGB(120, 123, 136)
	v_u_201.TextXAlignment = Enum.TextXAlignment.Left
	v_u_201.BackgroundColor3 = Color3.fromRGB(8, 9, 12)
	v_u_201.BackgroundTransparency = 0.2
	v_u_201.Position = UDim2.fromOffset(54, 178)
	v_u_201.Size = UDim2.fromOffset(150, 30)
	v_u_201.Parent = v_u_39
	local v381 = v_u_201
	local v382 = v_u_1.new("UICorner")
	v382.CornerRadius = UDim.new(0, 8)
	v382.Parent = v381
	local v383 = v_u_1.new("UIPadding")
	v383.PaddingLeft = UDim.new(0, 10)
	v383.Parent = v_u_201
	local v_u_384 = v_u_1.new("UIStroke")
	v_u_384.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v_u_384.Color = Color3.new(1, 1, 1)
	v_u_384.Transparency = 0.85
	v_u_384.Parent = v_u_201
	v_u_201.Focused:Connect(function()
		-- upvalues: (copy) v_u_384, (ref) v_u_6
		v_u_384.Color = v_u_6.ACCENT
		v_u_384.Transparency = 0.2
	end)
	v_u_201.FocusLost:Connect(function(_)
		-- upvalues: (copy) v_u_384, (ref) v_u_201, (ref) v_u_63, (ref) v_u_202, (ref) v_u_8, (ref) v_u_7, (ref) v_u_11, (ref) v_u_12, (ref) v_u_198, (ref) v_u_86, (ref) v_u_188
		v_u_384.Color = Color3.new(1, 1, 1)
		v_u_384.Transparency = 0.85
		local v385 = v_u_201.Text:gsub("%s", ""):gsub("^#", ""):match("(%x%x%x%x%x%x)$")
		local v386, v387
		if v385 then
			local v388 = Color3.fromHex
			v386, v387 = pcall(v388, v385)
		else
			v386 = false
			v387 = nil
		end
		if v386 and typeof(v387) == "Color3" then
			local v389 = v_u_63
			local v390 = v_u_63
			local v391 = v_u_63
			local v392, v393, v394 = v387:ToHSV()
			v389.h = v392
			v390.s = v393
			v391.v = v394
			v_u_202()
			local v395 = Color3.fromHSV(v_u_63.h, v_u_63.s, v_u_63.v)
			if v_u_8.passLocked(v_u_7, "Custom") then
				v_u_11.show("That\'s in the Custom pass", "info")
				v_u_12.open("Passes")
				return
			elseif v_u_63.tab == "Lights" then
				v_u_198(v395)
			else
				local v396 = v_u_86
				local v397 = "Paint"
				local v398
				if v_u_63.tab == "Wheels" then
					v398 = v_u_63.wheelTarget
				else
					v398 = v_u_63.bodyTarget
				end
				local v399
				if v_u_63.tab == "Wheels" then
					v399 = v_u_63.wheelFinish
				else
					v399 = v_u_63.finish
				end
				v396(v397, v398, v395, v399)
				task.delay(0.25, v_u_188)
			end
		else
			v_u_202()
			return
		end
	end)
	local v400 = UDim2.fromOffset(214, 178)
	local v401 = UDim2.fromOffset(120, 30)
	local v402 = v_u_39
	local v403 = v_u_1.new("TextLabel")
	v403.BackgroundTransparency = 1
	v403.Position = v400
	v403.Size = v401
	v403.Font = Enum.Font.GothamBold
	v403.TextSize = 16
	v403.TextWrapped = true
	v403.TextColor3 = Color3.fromRGB(200, 200, 200)
	v403.Text = "\224\184\129\224\184\148 Enter"
	v403.Parent = v402
	v403.Name = "HexHint"
	v403.TextSize = 12
	v403.TextColor3 = Color3.fromRGB(120, 123, 136)
	v403.TextXAlignment = Enum.TextXAlignment.Left
	v_u_200 = v_u_199.new(v_u_39, {
		["position"] = UDim2.fromOffset(14, 40),
		["size"] = UDim2.new(1, -28, 0, 128),
		["onChange"] = function(p404, p405, p406) -- name: onChange
			-- upvalues: (ref) v_u_63, (ref) v_u_202
			local v407 = v_u_63
			local v408 = v_u_63
			v_u_63.h = p404
			v407.s = p405
			v408.v = p406
			v_u_202()
		end,
		["onRelease"] = function() -- name: onRelease
			-- upvalues: (ref) v_u_63, (ref) v_u_8, (ref) v_u_7, (ref) v_u_11, (ref) v_u_12, (ref) v_u_198, (ref) v_u_86, (ref) v_u_188
			local v409 = Color3.fromHSV(v_u_63.h, v_u_63.s, v_u_63.v)
			if v_u_8.passLocked(v_u_7, "Custom") then
				v_u_11.show("That\'s in the Custom pass", "info")
				v_u_12.open("Passes")
				return
			elseif v_u_63.tab == "Lights" then
				v_u_198(v409)
			else
				local v410 = v_u_86
				local v411 = "Paint"
				local v412
				if v_u_63.tab == "Wheels" then
					v412 = v_u_63.wheelTarget
				else
					v412 = v_u_63.bodyTarget
				end
				local v413
				if v_u_63.tab == "Wheels" then
					v413 = v_u_63.wheelFinish
				else
					v413 = v_u_63.finish
				end
				v410(v411, v412, v409, v413)
				task.delay(0.25, v_u_188)
			end
		end
	})
	local v414 = v_u_81("Apply", "Use this color", UDim2.fromOffset(14, 220), UDim2.new(1, -28, 0, 34), v_u_39)
	v414.BackgroundColor3 = v_u_33
	v414.Activated:Connect(function()
		-- upvalues: (ref) v_u_63, (ref) v_u_8, (ref) v_u_7, (ref) v_u_11, (ref) v_u_12, (ref) v_u_198, (ref) v_u_86, (ref) v_u_188
		local v415 = Color3.fromHSV(v_u_63.h, v_u_63.s, v_u_63.v)
		if v_u_8.passLocked(v_u_7, "Custom") then
			v_u_11.show("That\'s in the Custom pass", "info")
			v_u_12.open("Passes")
			return
		elseif v_u_63.tab == "Lights" then
			v_u_198(v415)
		else
			local v416 = v_u_86
			local v417 = "Paint"
			local v418
			if v_u_63.tab == "Wheels" then
				v418 = v_u_63.wheelTarget
			else
				v418 = v_u_63.bodyTarget
			end
			local v419
			if v_u_63.tab == "Wheels" then
				v419 = v_u_63.wheelFinish
			else
				v419 = v_u_63.finish
			end
			v416(v417, v418, v415, v419)
			task.delay(0.25, v_u_188)
		end
	end)
	v_u_202()
end
local function v_u_452(p421) -- name: dock
	-- upvalues: (ref) v_u_37, (copy) v_u_19, (copy) v_u_63, (ref) v_u_39, (copy) v_u_22, (copy) v_u_1
	local v422 = v_u_37.Panel
	local v423 = require(game:GetService("ReplicatedStorage"):WaitForChild("GameUI"):WaitForChild("TuneDock"))
	if p421 and v423.set then
		if v423.insets then
			v_u_37.ScreenInsets = v423.insets
		end
		local v424 = v423.size or v_u_37.AbsoluteSize
		local v425 = v424.Y - v423.top - v423.bottom
		local v426 = v424.X - v423.left - v423.right
		local v427 = v423.max or 1
		local v428 = v425 / v_u_19.Y
		local v429 = v426 / v_u_19.X
		local v430 = math.min(v428, v429, v427)
		local v431 = math.max(v427, 0.45)
		local v432 = math.clamp(v430, 0.45, v431)
		v_u_63.pickerFolded = true
		v_u_63.pickerShown = false
		v_u_39.Parent = v422
		v_u_39.Size = UDim2.fromOffset(v_u_19.X - 32, v_u_22.Y)
		for _, v433 in { v422, v_u_39 } do
			local v434 = v433:FindFirstChild("DockScale") or v_u_1.new("UIScale")
			v434.Name = "DockScale"
			v434.Scale = v433 == v_u_39 and 1 or v432
			v434.Parent = v433
		end
		if v423.anchor == "left" then
			v422.AnchorPoint = Vector2.new(0, 0)
			v422.Position = UDim2.new(0, v423.left, 0, v423.top)
		else
			v422.AnchorPoint = Vector2.new(1, 0)
			v422.Position = UDim2.new(1, -v423.right, 0, v423.top)
		end
		v_u_39.AnchorPoint = Vector2.new(0.5, 0)
		v_u_39.Position = UDim2.new(0.5, 0, 0, 108)
		return
	else
		v_u_37.ScreenInsets = Enum.ScreenInsets.CoreUISafeInsets
		v_u_39.Size = UDim2.fromOffset(v_u_22.X, v_u_22.Y)
		local v435
		if v_u_37.AbsoluteSize.Y > 0 then
			v435 = v_u_37.AbsoluteSize
		else
			v435 = workspace.CurrentCamera.ViewportSize
		end
		local v436 = v_u_19.Y + 12 + v_u_22.Y
		local v437, v438
		if p421 then
			local v439 = (v435.Y - 24) / v436
			local v440 = (v435.X - 230) / (v_u_19.X + 24)
			local v441 = math.min(v439, v440, 1)
			local v442 = (v435.Y - 24) / v_u_19.Y
			local v443 = (v435.X - 150) / (v_u_19.X + v_u_22.X + 36)
			local v444 = math.min(v442, v443, 1)
			v437 = v444 - 0.05 <= v441
			if not v437 then
				v441 = v444
			end
			v438 = math.max(v441, 0.45)
		else
			v437 = true
			v438 = 1
		end
		local v445 = v_u_63
		local v446
		if p421 then
			v446 = not v437
		else
			v446 = p421
		end
		v445.pickerFolded = v446
		v_u_63.pickerShown = false
		local v447 = v_u_39
		local v448
		if v_u_63.pickerFolded then
			v448 = v422
		else
			v448 = v_u_37
		end
		v447.Parent = v448
		for _, v449 in { v422, v_u_39 } do
			local v450 = v449:FindFirstChild("DockScale") or v_u_1.new("UIScale")
			v450.Name = "DockScale"
			v450.Scale = v449 == v_u_39 and v_u_63.pickerFolded and 1 or v438
			v450.Parent = v449
		end
		if p421 and v437 then
			local v451 = -v436 * v438 / 2
			v422.AnchorPoint = Vector2.new(1, 0)
			v422.Position = UDim2.new(1, -12, 0.5, v451)
			v_u_39.AnchorPoint = Vector2.new(1, 0)
			v_u_39.Position = UDim2.new(1, -12, 0.5, v451 + (v_u_19.Y + 12) * v438)
			return
		elseif p421 then
			v422.AnchorPoint = Vector2.new(1, 0.5)
			v422.Position = UDim2.new(1, -12, 0.5, 0)
			v_u_39.AnchorPoint = Vector2.new(0.5, 0)
			v_u_39.Position = UDim2.new(0.5, 0, 0, 108)
		else
			v422.AnchorPoint = Vector2.new(0.5, 0.5)
			v422.Position = UDim2.fromScale(0.5, 0.5)
			v_u_39.AnchorPoint = Vector2.new(0, 0.5)
			v_u_39.Position = UDim2.new(0.5, 282, 0.5, 0)
		end
	end
end
function v_u_36.open(p453, p454, p455, p456) -- name: open
	-- upvalues: (ref) v_u_37, (copy) v_u_420, (copy) v_u_63, (copy) v_u_8, (copy) v_u_188, (copy) v_u_18, (copy) v_u_70, (copy) v_u_452, (copy) v_u_217
	if not (v_u_37 and v_u_37.Parent) then
		v_u_420()
	end
	local v457 = p456 or {}
	v_u_63.model = p453
	v_u_63.fire = p454
	v_u_63.onToggle = p455
	v_u_63.group = v457.group
	if v_u_63.ownedWatch then
		v_u_63.ownedWatch:Disconnect()
	end
	v_u_63.ownedWatch = p453.AttributeChanged:Connect(function(p458)
		-- upvalues: (ref) v_u_8, (ref) v_u_188
		if p458 == "TuneOwned" or v_u_8.isTuneAttribute(p458) then
			v_u_188()
		end
	end)
	local v459 = false
	for _, v460 in v_u_18 do
		if v459 then
			continue
		end
		if v460.id == v_u_63.tab and (v_u_63.group == nil or v460.group == v_u_63.group) then
			local v461 = v460.id
			if v461 == "Wheels" then
				v459 = #v_u_70() > 0
			elseif v461 == "Exhaust" then
				local v462 = v_u_63.model
				if v462 then
					v462 = v_u_63.model:GetAttribute("FixedExhaust") ~= nil
				end
				v459 = not v462
			else
				v459 = true
			end
		else
			v459 = false
		end
	end
	if not v459 then
		for _, v463 in v_u_18 do
			if v_u_63.group ~= nil and v463.group ~= v_u_63.group then
				continue
			end
			local v464 = v463.id
			local v465
			if v464 == "Wheels" then
				v465 = #v_u_70() > 0
			elseif v464 == "Exhaust" then
				local v466 = v_u_63.model
				if v466 then
					v466 = v_u_63.model:GetAttribute("FixedExhaust") ~= nil
				end
				v465 = not v466
			else
				v465 = true
			end
			if not v465 then
				continue
			end
			v_u_63.tab = v463.id
		end
	end
	v_u_452(v457.dock == true)
	v_u_217(v_u_63.tab)
	v_u_37.Enabled = true
	if p455 then
		p455(true)
	end
end
function v_u_36.close() -- name: close
	-- upvalues: (ref) v_u_37, (copy) v_u_63
	if v_u_37 then
		v_u_37.Enabled = false
	end
	if v_u_63.onToggle then
		v_u_63.onToggle(false)
	end
	if v_u_63.ownedWatch then
		v_u_63.ownedWatch:Disconnect()
		v_u_63.ownedWatch = nil
	end
	local v467 = v_u_63
	local v468 = v_u_63
	v_u_63.model = nil
	v467.fire = nil
	v468.onToggle = nil
end
function v_u_36.toggle(p469, p470, p471) -- name: toggle
	-- upvalues: (copy) v_u_36
	if v_u_36.isOpen() then
		v_u_36.close()
	else
		v_u_36.open(p469, p470, p471)
	end
end
function v_u_36.isOpen() -- name: isOpen
	-- upvalues: (ref) v_u_37
	local v472
	if v_u_37 == nil then
		v472 = false
	else
		v472 = v_u_37.Enabled
	end
	return v472
end
return v_u_36