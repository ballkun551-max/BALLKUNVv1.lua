-- Path: ReplicatedStorage/GameUI/JobPicker
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = game:GetService("Lighting")
local v_u_2 = game:GetService("Players")
local v_u_3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("RunService")
local v_u_5 = game:GetService("UserInputService")
local v_u_6 = require(v_u_3:WaitForChild("GameShared"))
local v_u_7 = require(v_u_3:WaitForChild("JobShared"))
local v_u_8 = require(v_u_3:WaitForChild("NetSeal"))
local v_u_9 = require(script.Parent:WaitForChild("Theme"))
local v_u_10 = require(script.Parent:WaitForChild("Icons"))
local v_u_11 = require(script.Parent:WaitForChild("Poses"))
local v_u_12 = {
	["isOpen"] = false
}
local v_u_13 = {
	["Delivery"] = "bagSide",
	["Courier"] = "carryParcel",
	["Mechanic"] = "wrenchShoulder",
	["Builder"] = "bagShoulder",
	["Citizen"] = "phone"
}
local v_u_14 = {
	["Delivery"] = "showBag",
	["Courier"] = "offerParcel",
	["Mechanic"] = "wrenchReady",
	["Builder"] = "bagThumbsUp",
	["Citizen"] = "selfie"
}
local v_u_15 = {
	["ClockTime"] = 0.3,
	["Brightness"] = 1.2,
	["ExposureCompensation"] = -0.3,
	["Ambient"] = nil,
	["OutdoorAmbient"] = nil,
	["Ambient"] = Color3.fromRGB(40, 44, 66),
	["OutdoorAmbient"] = Color3.fromRGB(46, 52, 80)
}
local v_u_16 = Color3.fromRGB(8, 8, 10)
local v_u_17 = Color3.new(1, 1, 1)
local v_u_18 = Color3.fromRGB(176, 180, 190)
local v_u_19 = Color3.fromRGB(226, 40, 46)
local v_u_20 = Color3.fromRGB(14, 16, 22)
local v_u_21 = Color3.new(0, 0, 0)
local v_u_22 = Vector2.new(128, 58)
local v_u_23 = Color3.fromRGB(30, 32, 42)
local v_u_24 = Color3.fromRGB(11, 12, 17)
local v_u_25 = v_u_2.LocalPlayer
local function v_u_28(p26, p27) -- name: new
	-- upvalues: (copy) v_u_9
	return v_u_9.new(p26, p27)
end
local function v_u_41(p29, p30, p31, p32, p33, p34) -- name: text
	-- upvalues: (copy) v_u_9, (copy) v_u_17
	local v35 = v_u_9.text
	local v36 = {
		["Text"] = p30,
		["TextSize"] = p31,
		["TextColor3"] = p32 or v_u_17
	}
	local v37
	if p33 then
		v37 = v_u_9.FONT_BOLD
	else
		v37 = v_u_9.FONT
	end
	v36.FontFace = v37
	v36.Parent = p29
	local v38 = v35(v36)
	for v39, v40 in p34 or {} do
		v38[v39] = v40
	end
	return v38
end
local function v_u_45(p42) -- name: countOf
	-- upvalues: (copy) v_u_2, (copy) v_u_7
	local v43 = 0
	for _, v44 in v_u_2:GetPlayers() do
		if (v44:GetAttribute("Job") or v_u_7.DEFAULT) ~= p42 then
			continue
		end
		v43 = v43 + 1
	end
	return v43
end
local function v_u_51(p46, p47, p48, p49) -- name: glass
	-- upvalues: (copy) v_u_17, (copy) v_u_9, (copy) v_u_23, (copy) v_u_24
	p46.BackgroundColor3 = v_u_17
	v_u_9.corner(p46, p47)
	local v50 = {
		["Rotation"] = 90,
		["Color"] = nil,
		["Parent"] = nil,
		["Color"] = ColorSequence.new(p48 or v_u_23, p49 or v_u_24),
		["Parent"] = p46
	}
	v_u_9.new("UIGradient", v50)
end
local function v_u_56(p52, p53) -- name: shadow
	-- upvalues: (copy) v_u_21, (copy) v_u_9
	local v54 = {
		["Name"] = "Shadow",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.55,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_21,
		["AnchorPoint"] = p52.AnchorPoint,
		["Position"] = p52.Position + UDim2.fromOffset(0, 5),
		["Size"] = p52.Size + UDim2.fromOffset(6, 4),
		["ZIndex"] = p52.ZIndex - 1,
		["Parent"] = p52.Parent
	}
	local v55 = v_u_9.new("Frame", v54)
	v_u_9.corner(v55, p53 + 3)
	return v55
end
function v_u_12.open(p_u_57) -- name: open
	-- upvalues: (copy) v_u_12, (copy) v_u_3, (copy) v_u_15, (copy) v_u_1, (copy) v_u_25, (copy) v_u_7, (copy) v_u_9, (copy) v_u_19, (copy) v_u_41, (copy) v_u_17, (copy) v_u_5, (copy) v_u_18, (copy) v_u_20, (copy) v_u_56, (copy) v_u_28, (copy) v_u_51, (copy) v_u_21, (copy) v_u_10, (copy) v_u_45, (copy) v_u_16, (copy) v_u_22, (copy) v_u_13, (copy) v_u_14, (copy) v_u_4, (copy) v_u_11, (copy) v_u_6, (copy) v_u_8
	if not v_u_12.isOpen then
		v_u_12.isOpen = true
		local v58 = v_u_3:WaitForChild("JobStage")
		local v59 = os.clock()
		while not v58:GetAttribute("Dressed") and os.clock() - v59 < 6 do
			task.wait(0.1)
		end
		local v_u_60 = v58:Clone()
		v_u_60:PivotTo(v_u_60:GetPivot() + Vector3.new(0, 2600, 0))
		v_u_60.Parent = workspace
		local v_u_61 = workspace.CurrentCamera
		local v_u_62 = v_u_61.FieldOfView
		v_u_61.CameraType = Enum.CameraType.Scriptable
		local v_u_63 = {}
		for v64, v65 in v_u_15 do
			v_u_63[v64] = v_u_1[v64]
			v_u_1[v64] = v65
		end
		local v_u_66 = v_u_25.PlayerGui:FindFirstChild("TopBar")
		local v_u_67
		if v_u_66 then
			v_u_67 = v_u_66.Enabled
		else
			v_u_67 = v_u_66
		end
		if v_u_66 then
			v_u_66.Enabled = false
		end
		local v_u_68 = {}
		local v_u_69 = {}
		local v_u_70 = nil
		local v_u_71 = nil
		local v_u_72 = nil
		local v_u_73 = 0
		local v_u_74 = 0
		local v_u_75 = 0
		local v_u_76 = 0
		local v_u_77 = v_u_25:GetAttribute("Job") or v_u_7.DEFAULT
		local v_u_78 = v_u_9.new("Part", {
			["Name"] = "KeyLight",
			["Anchored"] = true,
			["CanCollide"] = false,
			["CanQuery"] = false,
			["CanTouch"] = false,
			["Transparency"] = 1,
			["Size"] = Vector3.new(0.2, 0.2, 0.2),
			["Parent"] = nil,
			["Parent"] = v_u_60
		})
		local v79 = {
			["Brightness"] = 0,
			["Range"] = 9,
			["Color"] = nil,
			["Shadows"] = false,
			["Parent"] = nil,
			["Color"] = Color3.fromRGB(255, 236, 214),
			["Parent"] = v_u_78
		}
		local v_u_80 = v_u_9.new("PointLight", v79)
		local function v_u_103() -- name: frame
			-- upvalues: (copy) v_u_61, (ref) v_u_73, (ref) v_u_70, (copy) v_u_80, (copy) v_u_78
			local v81 = CFrame.lookAt(Vector3.new(0, 2604.8, 25), Vector3.new(0, 2604.6, -2))
			local v82 = (Vector3.new(0, 0.20000029, 27)).Magnitude
			local v83 = v_u_61.ViewportSize
			local v84 = v83.X
			local v85 = v83.Y
			local v86 = 22 / (v82 * (v84 / math.max(v85, 1)))
			local v87 = math.atan(v86) * 2
			local v88 = math.deg(v87)
			local v89 = math.clamp(v88, 34, 70)
			local v90 = 1 - (1 - v_u_73) ^ 3
			local v91 = v_u_70
			if v90 <= 0 or not v91 then
				v_u_61.CFrame = v81
				v_u_61.FieldOfView = v89
				v_u_80.Brightness = 0
			else
				local v92 = v91.head.Position - Vector3.new(0, 1.7, 0)
				local v93 = (v81.Position - v92) * Vector3.new(1, 0, 1)
				local v94 = v92 + v93.Unit * 11 + Vector3.new(0, 0.6, 0)
				local v95 = CFrame.lookAt(v94, v92)
				v_u_78.Position = v92 + v93.Unit * 5 + Vector3.new(0, 2.5, 0)
				v_u_80.Brightness = 0.8 * v90
				v_u_61.CFrame = v81:Lerp(v95, v90)
				local v96 = v_u_61
				local v97 = v_u_61.ViewportSize
				local v98 = v97.X
				local v99 = v97.Y
				local v100 = 6 / (11 * (v98 / math.max(v99, 1)))
				local v101 = math.atan(v100) * 2
				local v102 = math.deg(v101)
				v96.FieldOfView = v89 + (math.clamp(v102, 30, 64) - v89) * v90
			end
		end
		v_u_103()
		local v104 = {
			["Name"] = "JobPicker",
			["ResetOnSpawn"] = false,
			["IgnoreGuiInset"] = true,
			["ZIndexBehavior"] = nil,
			["DisplayOrder"] = 60,
			["Parent"] = nil,
			["ZIndexBehavior"] = Enum.ZIndexBehavior.Sibling,
			["Parent"] = v_u_25.PlayerGui
		}
		local v_u_105 = v_u_9.new("ScreenGui", v104)
		local v106 = {
			["Name"] = "JobPickerTitle",
			["ResetOnSpawn"] = false,
			["ScreenInsets"] = nil,
			["DisplayOrder"] = 61,
			["Parent"] = nil,
			["ScreenInsets"] = Enum.ScreenInsets.TopbarSafeInsets,
			["Parent"] = v_u_25.PlayerGui
		}
		local v_u_107 = v_u_9.new("ScreenGui", v106)
		local v108 = {
			["BackgroundTransparency"] = 1,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["Position"] = UDim2.fromOffset(12, 0),
			["Size"] = UDim2.new(0, 360, 1, 0),
			["Parent"] = v_u_107
		}
		local v109 = v_u_9.new("Frame", v108)
		local v110 = {
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["BackgroundColor3"] = v_u_19,
			["AnchorPoint"] = Vector2.new(0, 0.5),
			["Position"] = UDim2.fromScale(0, 0.5),
			["Size"] = UDim2.new(0, 3, 1, -8),
			["Parent"] = v109
		}
		v_u_9.new("Frame", v110)
		v_u_41(v109, "Choose a Job", 24, v_u_17, true, {
			["Position"] = UDim2.new(0, 14, 0, 2),
			["Size"] = UDim2.new(1, -14, 0.62, 0),
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["TextYAlignment"] = Enum.TextYAlignment.Bottom
		})
		v_u_41(v109, v_u_5.TouchEnabled and not v_u_5.MouseEnabled and "Tap a character to choose a job" or "Click a character to choose a job", 12, v_u_18, false, {
			["Position"] = UDim2.new(0, 14, 0.62, 2),
			["Size"] = UDim2.new(1, -14, 0.38, -4),
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["TextYAlignment"] = Enum.TextYAlignment.Top
		})
		local v111 = {
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["Parent"] = nil,
			["Size"] = UDim2.fromScale(1, 1),
			["Parent"] = v_u_105
		}
		local v_u_112 = v_u_9.new("Frame", v111)
		local v_u_113 = v_u_9.new("UIScale", {
			["Parent"] = v_u_112
		})
		local v114 = {
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.06,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = 2,
			["Parent"] = nil,
			["BackgroundColor3"] = v_u_20,
			["AnchorPoint"] = Vector2.new(0.5, 1),
			["Position"] = UDim2.new(0.5, 0, 1, -22),
			["Size"] = UDim2.fromOffset(720, 92),
			["Parent"] = v_u_112
		}
		local v_u_115 = v_u_9.new("Frame", v114)
		local v_u_116 = { v_u_28("UIScale", {
				["Parent"] = v_u_56(v_u_115, 14)
			}) }
		local v117 = {
			["Text"] = "",
			["AutoButtonColor"] = true,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.06,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["BackgroundColor3"] = v_u_20,
			["AnchorPoint"] = Vector2.new(0, 1),
			["Position"] = UDim2.new(0, 22, 1, -22),
			["Size"] = UDim2.fromOffset(120, 48),
			["Parent"] = v_u_112
		}
		local v_u_118 = v_u_9.new("TextButton", v117)
		v_u_51(v_u_118, 12)
		local v119 = {
			["ApplyStrokeMode"] = nil,
			["Color"] = nil,
			["Transparency"] = 0.82,
			["Thickness"] = 1,
			["Parent"] = nil,
			["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
			["Color"] = v_u_17,
			["Parent"] = v_u_118
		}
		v_u_9.new("UIStroke", v119)
		local v120 = v_u_28
		table.insert(v_u_116, v120("UIScale", {
			["Parent"] = v_u_118
		}))
		v_u_41(v_u_118, "\226\128\185  Back", 18, v_u_17, true, {
			["Size"] = UDim2.fromScale(1, 1)
		})
		local v_u_121 = nil
		local v_u_122 = nil
		local v_u_123 = nil
		local function v_u_139() -- name: drawPanel
			-- upvalues: (copy) v_u_115, (ref) v_u_51, (copy) v_u_116, (ref) v_u_9, (ref) v_u_70, (ref) v_u_17, (ref) v_u_19, (copy) v_u_118, (ref) v_u_41, (ref) v_u_5, (ref) v_u_18, (ref) v_u_122, (ref) v_u_21, (ref) v_u_10, (ref) v_u_45, (copy) v_u_77, (ref) v_u_25, (ref) v_u_123
			v_u_115:ClearAllChildren()
			v_u_51(v_u_115, 14)
			local v124 = v_u_116
			local v125 = {
				["Scale"] = v_u_116[1].Scale,
				["Parent"] = v_u_115
			}
			v124[3] = v_u_9.new("UIScale", v125)
			local v126 = {
				["ApplyStrokeMode"] = nil,
				["Color"] = nil,
				["Transparency"] = nil,
				["Thickness"] = 1,
				["Parent"] = nil,
				["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border
			}
			local v127
			if v_u_70 then
				v127 = v_u_70.job.color
			else
				v127 = v_u_17
			end
			v126.Color = v127
			v126.Transparency = v_u_70 and 0.35 or 0.84
			v126.Parent = v_u_115
			v_u_9.new("UIStroke", v126)
			local v128 = {
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil
			}
			local v129
			if v_u_70 then
				v129 = v_u_70.job.color
			else
				v129 = v_u_19
			end
			v128.BackgroundColor3 = v129
			v128.AnchorPoint = Vector2.new(0.5, 0.5)
			v128.Position = UDim2.fromScale(0.5, 0)
			v128.Size = UDim2.new(0.34, 0, 0, 3)
			v128.Parent = v_u_115
			local v130 = v_u_9.new("Frame", v128)
			v_u_9.corner(v130, 2)
			local v131 = {
				["Transparency"] = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(0.5, 0), NumberSequenceKeypoint.new(1, 1) }),
				["Parent"] = v130
			}
			v_u_9.new("UIGradient", v131)
			v_u_118.Visible = v_u_70 == nil
			if v_u_70 then
				local v132 = v_u_70.job
				v_u_9.button({
					["text"] = "\226\128\185  Back",
					["grad"] = "dark",
					["textSize"] = 17,
					["anchor"] = nil,
					["position"] = nil,
					["size"] = nil,
					["radius"] = 14,
					["parent"] = nil,
					["anchor"] = Vector2.new(0, 0.5),
					["position"] = UDim2.new(0, 14, 0.5, 0),
					["size"] = UDim2.fromOffset(118, 56),
					["parent"] = v_u_115
				}).Activated:Connect(function()
					-- upvalues: (ref) v_u_122
					v_u_122()
				end)
				local v133 = {
					["BackgroundColor3"] = nil,
					["BorderSizePixel"] = 0,
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["Parent"] = nil,
					["BackgroundColor3"] = v_u_17,
					["AnchorPoint"] = Vector2.new(0, 0.5),
					["Position"] = UDim2.new(0, 148, 0.5, 0),
					["Size"] = UDim2.fromOffset(56, 56),
					["Parent"] = v_u_115
				}
				local v134 = v_u_9.new("Frame", v133)
				v_u_9.corner(v134, 16)
				local v135 = {
					["Rotation"] = 90,
					["Color"] = nil,
					["Parent"] = nil,
					["Color"] = ColorSequence.new(v132.color:Lerp(v_u_17, 0.25), v132.color:Lerp(v_u_21, 0.35)),
					["Parent"] = v134
				}
				v_u_9.new("UIGradient", v135)
				v_u_9.gloss(v134, 16, 0.25)
				local v136 = v_u_10.make(v132.icon, v_u_17, 32)
				v136.AnchorPoint = Vector2.new(0.5, 0.5)
				v136.Position = UDim2.fromScale(0.5, 0.5)
				v136.Parent = v134
				v_u_41(v_u_115, v132.th, 24, v_u_17, true, {
					["FontFace"] = v_u_9.FONT_DISPLAY,
					["Position"] = UDim2.new(0, 216, 0, 12),
					["Size"] = UDim2.new(1, -410, 0, 28),
					["TextXAlignment"] = Enum.TextXAlignment.Left
				})
				local v137 = ("%d playing"):format((v_u_45(v132.id))) .. (v132.id == v_u_77 and v_u_25:GetAttribute("JobChosen") and "  \194\183  your job" or "")
				v_u_41(v_u_115, v132.detail .. "  \194\183  " .. v137, 13, v_u_18, false, {
					["Position"] = nil,
					["Size"] = nil,
					["TextWrapped"] = true,
					["TextXAlignment"] = nil,
					["TextYAlignment"] = nil,
					["Position"] = UDim2.new(0, 216, 0, 42),
					["Size"] = UDim2.new(1, -410, 0, 34),
					["TextXAlignment"] = Enum.TextXAlignment.Left,
					["TextYAlignment"] = Enum.TextYAlignment.Top
				})
				v_u_9.button({
					["text"] = "PLAY",
					["icon"] = "play",
					["grad"] = "red",
					["textSize"] = 22,
					["anchor"] = nil,
					["position"] = nil,
					["size"] = nil,
					["radius"] = 14,
					["parent"] = nil,
					["anchor"] = Vector2.new(1, 0.5),
					["position"] = UDim2.new(1, -14, 0.5, 0),
					["size"] = UDim2.fromOffset(160, 60),
					["parent"] = v_u_115
				}).Activated:Connect(function()
					-- upvalues: (ref) v_u_123
					v_u_123()
				end)
			else
				v_u_41(v_u_115, "Choose your job", 20, v_u_17, true, {
					["Position"] = UDim2.fromOffset(0, 15),
					["Size"] = UDim2.new(1, 0, 0, 26)
				})
				local v138 = {
					["BackgroundColor3"] = nil,
					["BorderSizePixel"] = 0,
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["Parent"] = nil,
					["BackgroundColor3"] = v_u_19,
					["AnchorPoint"] = Vector2.new(0.5, 0),
					["Position"] = UDim2.new(0.5, 0, 0, 45),
					["Size"] = UDim2.fromOffset(36, 2),
					["Parent"] = v_u_115
				}
				v_u_9.new("Frame", v138)
				v_u_41(v_u_115, v_u_5.TouchEnabled and not v_u_5.MouseEnabled and "Tap a character to choose a job" or "Click a character to choose a job", 13, v_u_18, false, {
					["Position"] = UDim2.fromOffset(0, 53),
					["Size"] = UDim2.new(1, 0, 0, 18)
				})
			end
		end
		local v_u_140 = v_u_123
		for _, v141 in v_u_60:WaitForChild("People"):GetChildren() do
			local v142 = v_u_7.job(v141:GetAttribute("JobId") or v141.Name)
			if not v142 then
				continue
			end
			for _, v143 in v141:GetDescendants() do
				if not v143:IsA("Animator") then
					continue
				end
				v143:Destroy()
			end
			local v144 = {
				["FillTransparency"] = 1,
				["OutlineColor"] = nil,
				["OutlineTransparency"] = 0,
				["DepthMode"] = nil,
				["Parent"] = nil,
				["OutlineColor"] = v_u_16,
				["DepthMode"] = Enum.HighlightDepthMode.Occluded,
				["Parent"] = v141
			}
			local v145 = v_u_9.new("Highlight", v144)
			local v146 = {
				["Text"] = "",
				["AutoButtonColor"] = false,
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.12,
				["BorderSizePixel"] = 0,
				["AnchorPoint"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["BackgroundColor3"] = v_u_17,
				["AnchorPoint"] = Vector2.new(0.5, 1),
				["Size"] = UDim2.fromOffset(v_u_22.X, v_u_22.Y),
				["Parent"] = v_u_112
			}
			local v147 = v_u_9.new("TextButton", v146)
			v_u_9.corner(v147, 12)
			local v148 = {
				["Rotation"] = 90,
				["Color"] = nil,
				["Parent"] = nil,
				["Color"] = ColorSequence.new(v142.color:Lerp(v_u_21, 0.6), v142.color:Lerp(v_u_21, 0.84)),
				["Parent"] = v147
			}
			v_u_9.new("UIGradient", v148)
			local v149 = {
				["ApplyStrokeMode"] = nil,
				["Color"] = nil,
				["Transparency"] = 0.35,
				["Thickness"] = 1.5,
				["Parent"] = nil,
				["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
				["Color"] = v142.color,
				["Parent"] = v147
			}
			local v150 = v_u_9.new("UIStroke", v149)
			v_u_41(v147, v142.th, 17, v_u_17, true, {
				["Position"] = UDim2.fromOffset(6, 7),
				["Size"] = UDim2.new(1, -12, 0, 21)
			})
			local v151 = {
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["BackgroundColor3"] = v142.color,
				["AnchorPoint"] = Vector2.new(0.5, 0),
				["Position"] = UDim2.new(0.5, 0, 0, 31),
				["Size"] = UDim2.fromOffset(30, 2),
				["Parent"] = v147
			}
			v_u_9.new("Frame", v151)
			local v152 = {
				["BackgroundTransparency"] = 1,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["AnchorPoint"] = Vector2.new(0.5, 0),
				["Position"] = UDim2.new(0.5, 0, 0, 36),
				["Size"] = UDim2.fromOffset(84, 16),
				["Parent"] = v147
			}
			local v153 = v_u_9.new("Frame", v152)
			local v154 = v_u_10.make("people", v_u_18, 15)
			v154.Position = UDim2.fromOffset(10, 0)
			v154.Parent = v153
			local v155 = v_u_41(v153, "", 12, v_u_18, false, {
				["Position"] = UDim2.fromOffset(29, 0),
				["Size"] = UDim2.fromOffset(56, 16),
				["TextXAlignment"] = Enum.TextXAlignment.Left
			})
			local v156 = {
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.3,
				["BorderSizePixel"] = 0,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["BackgroundColor3"] = v142.color,
				["AnchorPoint"] = Vector2.new(0.5, 0),
				["Position"] = UDim2.new(0.5, 0, 1, 1),
				["Size"] = UDim2.fromOffset(2, 12),
				["Parent"] = v147
			}
			v_u_9.new("Frame", v156)
			local v157 = v_u_9.new("UIScale", {
				["Parent"] = v147
			})
			local v158 = v141:FindFirstChild("HumanoidRootPart")
			local v159 = v_u_13[v142.id] or "crossArms"
			local v_u_160 = {
				["model"] = nil,
				["head"] = nil,
				["root"] = nil,
				["rest"] = nil,
				["job"] = nil,
				["idle"] = nil,
				["hero"] = nil,
				["from"] = nil,
				["to"] = nil,
				["blendStart"] = 0,
				["phase"] = nil,
				["highlight"] = nil,
				["tag"] = nil,
				["stroke"] = nil,
				["count"] = nil,
				["tagScale"] = nil,
				["grow"] = 1,
				["model"] = v141,
				["head"] = v141:FindFirstChild("Head"),
				["root"] = v158,
				["rest"] = v158.CFrame,
				["job"] = v142,
				["idle"] = v159,
				["hero"] = v_u_14[v142.id] or v159,
				["from"] = v159,
				["to"] = v159,
				["phase"] = math.random() * 5,
				["highlight"] = v145,
				["tag"] = v147,
				["stroke"] = v150,
				["count"] = v155,
				["tagScale"] = v157
			}
			v_u_69[v141] = v_u_160
			v147.Activated:Connect(function()
				-- upvalues: (ref) v_u_12, (copy) v_u_160
				v_u_12._pick(v_u_160)
			end)
			v147.MouseEnter:Connect(function()
				-- upvalues: (ref) v_u_72, (copy) v_u_160
				v_u_72 = v_u_160
			end)
			v147.MouseLeave:Connect(function()
				-- upvalues: (ref) v_u_72, (copy) v_u_160
				if v_u_72 == v_u_160 then
					v_u_72 = nil
				end
			end)
		end
		local function v_u_168() -- name: paint
			-- upvalues: (copy) v_u_69, (ref) v_u_70, (ref) v_u_71, (ref) v_u_17, (ref) v_u_16, (copy) v_u_113
			for _, v161 in v_u_69 do
				local v162 = v161 == v_u_70
				local v163 = v162 or v161 == v_u_71
				local v164 = v161.highlight
				local v165
				if v162 then
					v165 = v_u_17
				elseif v163 then
					v165 = v_u_17
				else
					v165 = v_u_16
				end
				v164.OutlineColor = v165
				v161.tag.BackgroundTransparency = v162 and 0.02 or 0.12
				v161.stroke.Transparency = v163 and 0 or 0.35
				v161.stroke.Thickness = v162 and 2.5 or 1.5
				v161.grow = v161.grow + ((v162 and 1.08 or (v163 and 1.06 or 1)) - v161.grow) * 0.3
				local v166 = v161.tagScale
				local v167 = 0.72 / v_u_113.Scale
				v166.Scale = math.max(1, v167) * v161.grow
			end
		end
		function v_u_12._pick(p169) -- name: _pick
			-- upvalues: (ref) v_u_70, (ref) v_u_75, (ref) v_u_140, (ref) v_u_74, (ref) v_u_76, (ref) v_u_73, (copy) v_u_168, (copy) v_u_139
			if v_u_70 == p169 and v_u_75 == 1 then
				v_u_140()
			else
				if v_u_70 and v_u_70 ~= p169 then
					local v170 = v_u_70
					local v171 = v_u_70.idle
					if v170.to ~= v171 then
						local v172 = v170.to
						local v173 = os.clock()
						v170.from = v172
						v170.to = v171
						v170.blendStart = v173
					end
				end
				v_u_70 = p169
				local v174 = p169.hero
				if p169.to ~= v174 then
					local v175 = p169.to
					local v176 = os.clock()
					p169.from = v175
					p169.to = v174
					p169.blendStart = v176
				end
				local v177 = v_u_73
				local v178 = os.clock()
				v_u_74 = v177
				v_u_75 = 1
				v_u_76 = v178
				v_u_168()
				v_u_139()
			end
		end
		v_u_122 = function() -- name: unpick
			-- upvalues: (ref) v_u_70, (ref) v_u_74, (ref) v_u_75, (ref) v_u_76, (ref) v_u_73, (copy) v_u_168, (copy) v_u_139, (copy) v_u_118
			if v_u_70 then
				local v179 = v_u_70
				local v180 = v_u_70.idle
				if v179.to ~= v180 then
					local v181 = v179.to
					local v182 = os.clock()
					v179.from = v181
					v179.to = v180
					v179.blendStart = v182
				end
			end
			local v183 = v_u_73
			local v184 = os.clock()
			v_u_74 = v183
			v_u_75 = 0
			v_u_76 = v184
			task.delay(0.55, function()
				-- upvalues: (ref) v_u_75, (ref) v_u_70, (ref) v_u_168
				if v_u_75 == 0 then
					v_u_70 = nil
					v_u_168()
				end
			end)
			local v185 = v_u_70
			v_u_70 = nil
			v_u_139()
			v_u_70 = v185
			v_u_118.Visible = true
		end
		local function v_u_191(p186, p187) -- name: personAt
			-- upvalues: (copy) v_u_61, (copy) v_u_60, (copy) v_u_69
			local v188
			if p187 then
				v188 = v_u_61:ViewportPointToRay(p186.X, p186.Y)
			else
				v188 = v_u_61:ScreenPointToRay(p186.X, p186.Y)
			end
			local v189 = RaycastParams.new()
			v189.FilterType = Enum.RaycastFilterType.Include
			v189.FilterDescendantsInstances = { v_u_60:FindFirstChild("People") }
			local v190 = workspace:Raycast(v188.Origin, v188.Direction * 200, v189)
			if v190 then
				v190 = v190.Instance:FindFirstAncestorOfClass("Model")
			end
			while v190 and not v_u_69[v190] do
				v190 = v190:FindFirstAncestorOfClass("Model")
			end
			if v190 then
				v190 = v_u_69[v190]
			end
			return v190
		end
		local v192 = v_u_5.InputBegan
		local function v196(p193, p194)
			-- upvalues: (copy) v_u_191, (ref) v_u_75, (ref) v_u_70, (ref) v_u_12, (ref) v_u_122, (ref) v_u_121
			if not p194 then
				if p193.UserInputType == Enum.UserInputType.MouseButton1 or p193.UserInputType == Enum.UserInputType.Touch then
					local v195 = v_u_191(p193.Position)
					if v195 and v_u_75 == 0 or v195 == v_u_70 and v195 then
						v_u_12._pick(v195)
						return
					end
				elseif p193.KeyCode == Enum.KeyCode.Escape or p193.KeyCode == Enum.KeyCode.ButtonB then
					if v_u_75 == 1 then
						v_u_122()
						return
					end
					v_u_121(false)
				end
			end
		end
		table.insert(v_u_68, v192:Connect(v196))
		local v_u_197 = 0
		local v198 = v_u_4.RenderStepped
		local function v214()
			-- upvalues: (ref) v_u_73, (ref) v_u_74, (ref) v_u_75, (ref) v_u_76, (ref) v_u_1, (ref) v_u_15, (copy) v_u_61, (copy) v_u_103, (copy) v_u_113, (copy) v_u_112, (copy) v_u_116, (ref) v_u_5, (ref) v_u_71, (copy) v_u_191, (ref) v_u_72, (copy) v_u_168, (copy) v_u_69, (ref) v_u_197, (ref) v_u_45
			local v199 = v_u_74
			local v200 = v_u_75 - v_u_74
			local v201 = (os.clock() - v_u_76) / 0.55
			v_u_73 = v199 + v200 * math.clamp(v201, 0, 1)
			if v_u_1.ClockTime ~= v_u_15.ClockTime then
				v_u_1.ClockTime = v_u_15.ClockTime
			end
			v_u_61.CameraType = Enum.CameraType.Scriptable
			v_u_103()
			local v202 = v_u_61.ViewportSize
			local v203 = v_u_113
			local v204 = v202.X / 1280
			local v205 = v202.Y / 720
			local v206 = math.min(v204, v205)
			v203.Scale = math.clamp(v206, 0.55, 1.4)
			v_u_112.Size = UDim2.new(1 / v_u_113.Scale, 0, 1 / v_u_113.Scale, 0)
			for _, v207 in v_u_116 do
				local v208 = 0.72 / v_u_113.Scale
				v207.Scale = math.max(1, v208)
			end
			if v_u_5.MouseEnabled and v_u_75 == 0 then
				v_u_71 = v_u_191(v_u_5:GetMouseLocation(), true) or v_u_72
			else
				v_u_71 = nil
			end
			v_u_168()
			for _, v209 in v_u_69 do
				local v210, v211 = v_u_61:WorldToViewportPoint(v209.head.Position + Vector3.new(0, 1.5, 0))
				local v212 = v209.tag
				if v211 then
					if v_u_73 < 0.05 then
						v211 = v_u_75 == 0
					else
						v211 = false
					end
				end
				v212.Visible = v211
				v209.tag.Position = UDim2.fromOffset(v210.X / v_u_113.Scale, v210.Y / v_u_113.Scale)
			end
			if os.clock() - v_u_197 > 1 then
				v_u_197 = os.clock()
				for _, v213 in v_u_69 do
					v213.count.Text = ("%d players"):format((v_u_45(v213.job.id)))
				end
			end
		end
		table.insert(v_u_68, v198:Connect(v214))
		local v215 = v_u_4.Stepped
		local function v220()
			-- upvalues: (copy) v_u_69, (ref) v_u_11
			local v216 = os.clock()
			for _, v217 in v_u_69 do
				local v218 = (v216 - v217.blendStart) / 0.35
				local v219 = math.clamp(v218, 0, 1)
				if v219 < 1 then
					v_u_11.applyBlend(v217.model, v217.from, v217.to, 1 - (1 - v219) ^ 3, v216 + v217.phase)
				else
					v_u_11.apply(v217.model, v217.to, v216 + v217.phase)
				end
			end
		end
		table.insert(v_u_68, v215:Connect(v220))
		v_u_118.Activated:Connect(function()
			-- upvalues: (ref) v_u_121
			v_u_121(false)
		end)
		local v_u_221 = false
		v_u_123 = function() -- name: start
			-- upvalues: (ref) v_u_221, (ref) v_u_70, (ref) v_u_121
			if not v_u_221 and v_u_70 then
				v_u_121(true)
			end
		end
		local function _(p222) -- name: finish
			-- upvalues: (ref) v_u_221, (ref) v_u_70, (ref) v_u_3, (ref) v_u_6, (ref) v_u_7, (ref) v_u_8, (copy) v_u_68, (copy) v_u_105, (copy) v_u_107, (copy) v_u_60, (copy) v_u_63, (ref) v_u_1, (copy) v_u_61, (copy) v_u_62, (copy) v_u_66, (copy) v_u_67, (ref) v_u_12, (copy) p_u_57
			if not v_u_221 then
				if p222 and v_u_70 then
					local v223 = v_u_3:FindFirstChild(v_u_6.REMOTES)
					if v223 then
						v223 = v223:FindFirstChild(v_u_7.REMOTE)
					end
					if v223 then
						local v224 = v_u_8.invoke
						local v225 = v_u_70.job.id
						local v226, _, v227 = pcall(v224, v223, "Set", v225)
						if v226 and type(v227) == "string" then
							require(script.Parent:WaitForChild("Toast")).show(v227, "info")
						end
					end
				end
				v_u_221 = true
				for _, v228 in v_u_68 do
					v228:Disconnect()
				end
				v_u_105:Destroy()
				v_u_107:Destroy()
				v_u_60:Destroy()
				for v229, v230 in v_u_63 do
					v_u_1[v229] = v230
				end
				v_u_61.FieldOfView = v_u_62
				v_u_61.CameraType = Enum.CameraType.Custom
				if v_u_66 then
					v_u_66.Enabled = v_u_67
				end
				v_u_12.isOpen = false
				local v231 = p_u_57
				if p222 then
					p222 = v_u_70 ~= nil
				end
				v231(p222)
			end
		end
		v_u_168()
		v_u_139()
	end
end
return v_u_12