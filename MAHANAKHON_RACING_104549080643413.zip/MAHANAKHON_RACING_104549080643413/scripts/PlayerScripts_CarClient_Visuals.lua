-- Path: Players/ygggggg55551/PlayerScripts/CarClient/Visuals
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = game:GetService("CollectionService")
local v_u_2 = game:GetService("Debris")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("RunService")
local v_u_5 = require(v3:WaitForChild("CarShared"))
local v_u_6 = require(v3:WaitForChild("GearShared"))
local v_u_7 = require(v3:WaitForChild("EcuShared"))
local v_u_8 = require(game:GetService("ReplicatedStorage"):WaitForChild("LightModes"))
local v_u_9 = {
	"DoorFrontLeft",
	"DoorFrontRight",
	"DoorRearLeft",
	"DoorRearRight"
}
local v_u_10 = { 0.05, 0.15 }
local v_u_11 = Color3.fromRGB(255, 236, 214)
local v_u_12 = Color3.fromRGB(190, 215, 255)
local v_u_13 = {
	["Head"] = Color3.fromRGB(255, 250, 238),
	["DRL"] = Color3.fromRGB(255, 255, 255),
	["Brake"] = Color3.fromRGB(255, 25, 25),
	["Tail"] = Color3.fromRGB(190, 0, 0),
	["Reverse"] = Color3.fromRGB(255, 244, 228),
	["Indicator"] = Color3.fromRGB(255, 150, 20),
	["Fog"] = Color3.fromRGB(255, 245, 225)
}
local v14 = {}
local v_u_15 = {}
local v_u_16 = nil
local function v_u_157(p17) -- name: setup
	-- upvalues: (copy) v_u_15, (copy) v_u_6, (copy) v_u_9, (copy) v_u_5, (copy) v_u_12
	if v_u_15[p17] then
		return
	else
		local v_u_18 = p17:WaitForChild("Chassis", 10)
		if v_u_18 then
			local v19 = {
				["model"] = nil,
				["chassis"] = nil,
				["wheels"] = nil,
				["doors"] = nil,
				["lamps"] = nil,
				["beams"] = nil,
				["steer"] = 0,
				["lastSpeed"] = 0,
				["throttleGuess"] = 0,
				["blinkWasOn"] = false,
				["startedAt"] = nil,
				["model"] = p17,
				["chassis"] = v_u_18,
				["wheels"] = {},
				["doors"] = {},
				["lamps"] = {},
				["beams"] = {
					["Head"] = {},
					["Brake"] = {},
					["Reverse"] = {},
					["Indicator"] = {}
				},
				["startedAt"] = p17:GetAttribute("EngineStartedAt") or 0
			}
			for _, v20 in p17:GetChildren() do
				local v21 = v20.Name:match("^Knuckle(.+)$")
				if not v21 then
					continue
				end
				local v22 = v_u_18:FindFirstChild("SteerMotor" .. v21)
				local v23 = v20:FindFirstChild("SpinMotor" .. v21)
				local v24 = v19.wheels
				local v25 = {
					["steer"] = nil,
					["spin"] = nil,
					["radius"] = nil,
					["angle"] = 0,
					["factor"] = nil,
					["hub"] = nil,
					["comp"] = 0,
					["steer"] = v22 and ({
						["motor"] = v22,
						["base"] = v22:GetAttribute("BaseC0") or v22.C0
					} or nil) or nil,
					["spin"] = v23 and ({
						["motor"] = v23,
						["base"] = v23:GetAttribute("BaseC0") or v23.C0
					} or nil) or nil,
					["radius"] = v23 and v23:GetAttribute("Radius") or (p17:GetAttribute("WheelRadius") or 1.3),
					["factor"] = v22 and v22:GetAttribute("SteerFactor") or (v21:sub(1, 5) == "Front" and 1 or 0)
				}
				if v22 then
					v22 = (v22:GetAttribute("BaseC0") or v22.C0).Position
				end
				v25.hub = v22
				v24[v21] = v25
			end
			local v26 = v_u_18:FindFirstChild("SteeringWheelMotor")
			v19.steeringWheel = v26 and ({
				["motor"] = v26,
				["base"] = v26:GetAttribute("BaseC0") or v26.C0
			} or nil) or nil
			local v27 = v_u_18:FindFirstChild("ShifterMotor")
			if v27 then
				local v28 = p17:GetAttribute("ShifterGears") or 6
				local v29 = {
					["motor"] = nil,
					["base"] = nil,
					["gears"] = nil,
					["h"] = nil,
					["v"] = nil,
					["side"] = 0,
					["fore"] = 0,
					["gear"] = 0,
					["motor"] = v27,
					["base"] = v27:GetAttribute("BaseC0") or v27.C0,
					["gears"] = not v_u_6.SHARES[v28] and 6 or v28
				}
				local v30 = p17:GetAttribute("ShifterH") or 10
				v29.h = math.rad(v30)
				local v31 = p17:GetAttribute("ShifterV") or 8.5
				v29.v = math.rad(v31)
				v19.shifter = v29
			end
			local v32 = v_u_18:FindFirstChild("HandbrakeMotor")
			if v32 then
				local v33 = {
					["motor"] = nil,
					["base"] = nil,
					["angle"] = nil,
					["seat"] = nil,
					["k"] = 0,
					["shown"] = -1,
					["motor"] = v32,
					["base"] = v32:GetAttribute("BaseC0") or v32.C0
				}
				local v34 = p17:GetAttribute("HandbrakeAngle") or 12.5
				v33.angle = math.rad(v34)
				v33.seat = p17:FindFirstChild("DriverSeat")
				v19.handbrakeLever = v33
			end
			for _, v35 in v_u_9 do
				local v36 = v_u_18:FindFirstChild(v35 .. "Motor")
				if not v36 then
					continue
				end
				v19.doors[v35] = {
					["motor"] = nil,
					["base"] = nil,
					["sign"] = nil,
					["open"] = 0,
					["motor"] = v36,
					["base"] = v36:GetAttribute("BaseC0") or v36.C0,
					["sign"] = v36:GetAttribute("OpenSign") or 1
				}
			end
			local v37 = {}
			for _, v38 in p17:GetDescendants() do
				if not (v38:IsA("BasePart") and v38:GetAttribute("HasGlow")) then
					continue
				end
				v37[v38.Name] = v38
			end
			for _, v39 in p17:GetDescendants() do
				if not v39:IsA("BasePart") or (not v39:GetAttribute("Lamp") or v39:GetAttribute("KitLamp")) then
					continue
				end
				local v40 = v19.lamps
				local v41 = {
					["part"] = nil,
					["kind"] = nil,
					["side"] = nil,
					["ending"] = nil,
					["twin"] = nil,
					["covers"] = nil,
					["baseColor"] = nil,
					["baseMaterial"] = nil,
					["state"] = nil,
					["part"] = v39,
					["kind"] = v39:GetAttribute("Lamp"),
					["side"] = v39:GetAttribute("LampSide"),
					["ending"] = v39:GetAttribute("LampEnd"),
					["twin"] = v39:GetAttribute("Twin") == true,
					["covers"] = v37[v39:GetAttribute("TwinOf") or ""],
					["baseColor"] = v39:GetAttribute("BaseColor") or v39.Color,
					["baseMaterial"] = Enum.Material[v39:GetAttribute("BaseMaterial") or "SmoothPlastic"]
				}
				table.insert(v40, v41)
			end
			v19.tailReach = 0.1
			for _, v42 in v19.lamps do
				if v42.kind ~= "Brake" and v42.kind ~= "Tail" then
					continue
				end
				local v43 = v19.tailReach
				local v44 = v_u_18.CFrame:PointToObjectSpace(v42.part.Position).X
				local v45 = math.abs(v44)
				v19.tailReach = math.max(v43, v45)
			end
			for _, v46 in v_u_18:GetChildren() do
				if not v46:IsA("Attachment") then
					continue
				end
				for _, v47 in v46:GetChildren() do
					if v47.Name == "HeadBeam" then
						local v48 = v19.beams.Head
						table.insert(v48, v47)
					elseif v47.Name == "BrakeGlow" then
						if v47:GetAttribute("GlowBase") == nil then
							v47:SetAttribute("GlowBase", v47.Color)
						end
						local v49 = v19.beams.Brake
						table.insert(v49, v47)
					elseif v47.Name == "ReverseBeam" then
						local v50 = v19.beams.Reverse
						table.insert(v50, v47)
					else
						if v47.Name ~= "IndicatorGlow" then
							continue
						end
						local v51 = v19.beams.Indicator
						local v52 = {
							["light"] = v47,
							["side"] = v46:GetAttribute("IndicatorSide")
						}
						table.insert(v51, v52)
					end
				end
			end
			local v53 = Instance.new("Attachment")
			v53.Name = "CarClientFx"
			v53.Parent = v_u_18
			v19.fx = v53
			local v54 = Instance.new("Attachment")
			v54.Name = "CarClientExhaustFx"
			for _, v55 in v_u_18:GetChildren() do
				if not (v55:IsA("Attachment") and v55.Name:match("^Exhaust%d+$")) then
					continue
				end
				v54.Position = v55.Position
			end
			v54.Parent = v_u_18
			v19.exhaustFx = v54
			local v56 = p17:GetAttribute("SoundEngine")
			local v57 = Instance.new("Sound")
			v57.Name = "Engine"
			if type(v56) == "string" and v56 ~= "" then
				if not v56:find("://") then
					v56 = "rbxassetid://" .. v56
				end
			else
				v56 = ""
			end
			v57.SoundId = v56
			v57.Looped = true
			v57.Volume = 0.5
			v57.RollOffMode = Enum.RollOffMode.InverseTapered
			v57.RollOffMinDistance = 8
			v57.RollOffMaxDistance = 160
			v57.Parent = v54
			v19.engine = v57
			local v58 = p17:GetAttribute("SoundStart")
			local v59 = Instance.new("Sound")
			v59.Name = "Start"
			if type(v58) == "string" and v58 ~= "" then
				if not v58:find("://") then
					v58 = "rbxassetid://" .. v58
				end
			else
				v58 = ""
			end
			v59.SoundId = v58
			v59.Looped = false
			v59.Volume = 0.8
			v59.RollOffMode = Enum.RollOffMode.InverseTapered
			v59.RollOffMinDistance = 8
			v59.RollOffMaxDistance = 160
			v59.Parent = v53
			v19.start = v59
			local v60 = p17:GetAttribute("SoundHorn")
			local v61 = Instance.new("Sound")
			v61.Name = "Horn"
			if type(v60) == "string" and v60 ~= "" then
				if not v60:find("://") then
					v60 = "rbxassetid://" .. v60
				end
			else
				v60 = ""
			end
			v61.SoundId = v60
			v61.Looped = true
			v61.Volume = 1
			v61.RollOffMode = Enum.RollOffMode.InverseTapered
			v61.RollOffMinDistance = 8
			v61.RollOffMaxDistance = 220
			v61.Parent = v53
			v19.horn = v61
			local v62 = p17:GetAttribute("SoundBlinker")
			local v63 = Instance.new("Sound")
			v63.Name = "Blinker"
			if type(v62) == "string" and v62 ~= "" then
				if not v62:find("://") then
					v62 = "rbxassetid://" .. v62
				end
			else
				v62 = ""
			end
			v63.SoundId = v62
			v63.Looped = false
			v63.Volume = 0.9
			v63.RollOffMode = Enum.RollOffMode.InverseTapered
			v63.RollOffMinDistance = 8
			v63.RollOffMaxDistance = 30
			v63.Parent = v53
			v19.blinker = v63
			local v64 = v_u_5.engineSet(p17)
			if v64 then
				local v65 = Instance.new("SoundGroup")
				v65.Name = "CarEngine"
				v65.Parent = v54
				v19.groupEq = Instance.new("EqualizerSoundEffect")
				v19.groupEq.Parent = v65
				v19.groupDistortion = Instance.new("DistortionSoundEffect")
				v19.groupDistortion.Enabled = false
				v19.groupDistortion.Parent = v65
				v19.setVolume = v64.volume or 1
				v19.points = {}
				for _, v66 in v64.points do
					local v67 = {
						["rpm"] = v66.rpm,
						["onGain"] = v66.onGain or 1,
						["offGain"] = v66.offGain or (v66.onGain or 1)
					}
					for _, v68 in { "on", "off" } do
						if not v66[v68] then
							continue
						end
						local v69 = "Engine_" .. v68 .. v66.rpm
						local v70 = v66[v68]
						local v71 = v_u_5.ENGINE_MAX_DISTANCE
						local v72 = Instance.new("Sound")
						v72.Name = v69
						if type(v70) == "string" and v70 ~= "" then
							if not v70:find("://") then
								v70 = "rbxassetid://" .. v70
							end
						else
							v70 = ""
						end
						v72.SoundId = v70
						v72.Looped = true
						v72.Volume = 0
						v72.RollOffMode = Enum.RollOffMode.InverseTapered
						v72.RollOffMinDistance = 8
						v72.RollOffMaxDistance = v71 or 160
						v72.Parent = v54
						v72.SoundGroup = v65
						v67[v68] = v72
					end
					local v73 = v19.points
					table.insert(v73, v67)
				end
				table.sort(v19.points, function(p74, p75)
					return p74.rpm < p75.rpm
				end)
				if v64.idle then
					local v76 = v64.idle.id
					local v77 = v_u_5.ENGINE_MAX_DISTANCE
					local v78 = Instance.new("Sound")
					v78.Name = "Engine_idle"
					if type(v76) == "string" and v76 ~= "" then
						if not v76:find("://") then
							v76 = "rbxassetid://" .. v76
						end
					else
						v76 = ""
					end
					v78.SoundId = v76
					v78.Looped = true
					v78.Volume = 0
					v78.RollOffMode = Enum.RollOffMode.InverseTapered
					v78.RollOffMinDistance = 8
					v78.RollOffMaxDistance = v77 or 160
					v78.Parent = v54
					v19.idleSound = v78
					v19.idleSound.SoundGroup = v65
					v19.idleRpm = v64.idle.rpm
					v19.idleGain = v64.idle.gain or 1
				end
				v19.load = 0
			end
			if p17:GetAttribute("KitSound") == true then
				v19.kit = {
					["ts"] = 0
				}
				for _, v79 in {
					{ "Rev", 1.5 },
					{ "Acc", 3.5 },
					{ "Dec", 2.5 }
				} do
					local v80 = v79[1]
					local v81 = "Kit" .. v80
					local v82 = p17:GetAttribute("KitSound" .. v80)
					local v83 = v_u_5.ENGINE_MAX_DISTANCE
					local v84 = Instance.new("Sound")
					v84.Name = v81
					if type(v82) == "string" and v82 ~= "" then
						if not v82:find("://") then
							v82 = "rbxassetid://" .. v82
						end
					else
						v82 = ""
					end
					v84.SoundId = v82
					v84.Looped = true
					v84.Volume = 0
					v84.RollOffMode = Enum.RollOffMode.InverseTapered
					v84.RollOffMinDistance = 8
					v84.RollOffMaxDistance = v83 or 160
					v84.Parent = v54
					if p17:GetAttribute("KitMix") ~= "AC6" then
						local v85 = Instance.new("EqualizerSoundEffect")
						v85.LowGain = 8
						v85.MidGain = 1
						v85.HighGain = -18
						v85.Priority = 1
						v85.Parent = v84
						local v86 = Instance.new("CompressorSoundEffect")
						v86.Threshold = -18
						v86.Ratio = 4
						v86.Attack = 0.005
						v86.Release = 0.1
						v86.GainMakeup = 4
						v86.Priority = 0
						v86.Parent = v84
					end
					v19.kit[v80] = {
						["sound"] = v84,
						["volume"] = p17:GetAttribute("KitSound" .. v80 .. "Volume") or v79[2]
					}
				end
				v19.kit.boost = 0
				v19.kit.mix = p17:GetAttribute("KitMix")
				v19.kit.redline = p17:GetAttribute("KitRedline") or 9000
				v19.kit.idleRpm = p17:GetAttribute("KitIdleRpm") or 800
				if p17:GetAttribute("KitTurbo") then
					local v87 = v19.kit
					local v88 = p17:GetAttribute("KitTurbo")
					local v89 = v_u_5.ENGINE_MAX_DISTANCE
					local v90 = Instance.new("Sound")
					v90.Name = "KitTurbo"
					if type(v88) == "string" and v88 ~= "" then
						if not v88:find("://") then
							v88 = "rbxassetid://" .. v88
						end
					else
						v88 = ""
					end
					v90.SoundId = v88
					v90.Looped = true
					v90.Volume = 0
					v90.RollOffMode = Enum.RollOffMode.InverseTapered
					v90.RollOffMinDistance = 8
					v90.RollOffMaxDistance = v89 or 160
					v90.Parent = v54
					v87.turbo = v90
					v19.kit.turboVolume = p17:GetAttribute("KitTurboVolume") or 0.6
				end
				if p17:GetAttribute("KitBov") then
					local v91 = v19.kit
					local v92 = p17:GetAttribute("KitBov")
					local v93 = v_u_5.ENGINE_MAX_DISTANCE
					local v94 = Instance.new("Sound")
					v94.Name = "KitBov"
					if type(v92) == "string" and v92 ~= "" then
						if not v92:find("://") then
							v92 = "rbxassetid://" .. v92
						end
					else
						v92 = ""
					end
					v94.SoundId = v92
					v94.Looped = false
					v94.Volume = 0
					v94.RollOffMode = Enum.RollOffMode.InverseTapered
					v94.RollOffMinDistance = 8
					v94.RollOffMaxDistance = v93 or 160
					v94.Parent = v54
					v91.bov = v94
					v19.kit.bovVolume = p17:GetAttribute("KitBovVolume") or 3
				end
			end
			v19.engineDistortion = Instance.new("DistortionSoundEffect")
			v19.engineDistortion.Enabled = false
			v19.engineDistortion.Parent = v19.engine
			v19.engineEq = Instance.new("EqualizerSoundEffect")
			v19.engineEq.Enabled = false
			v19.engineEq.Parent = v19.engine
			local v95 = p17:GetAttribute("SoundEngine")
			local v96 = Instance.new("Sound")
			v96.Name = "Rumble"
			if type(v95) == "string" and v95 ~= "" then
				if not v95:find("://") then
					v95 = "rbxassetid://" .. v95
				end
			else
				v95 = ""
			end
			v96.SoundId = v95
			v96.Looped = true
			v96.Volume = 0
			v96.RollOffMode = Enum.RollOffMode.InverseTapered
			v96.RollOffMinDistance = 8
			v96.RollOffMaxDistance = 160
			v96.Parent = v54
			v19.rumble = v96
			local v97 = Instance.new("EqualizerSoundEffect")
			v97.LowGain = 8
			v97.MidGain = -2
			v97.HighGain = -24
			v97.Parent = v19.rumble
			v19.rumbleDistortion = Instance.new("DistortionSoundEffect")
			v19.rumbleDistortion.Parent = v19.rumble
			local v98 = v_u_5.SOUND_EXHAUST_POP
			local v99 = Instance.new("Sound")
			v99.Name = "Pop"
			if type(v98) == "string" and v98 ~= "" then
				if not v98:find("://") then
					v98 = "rbxassetid://" .. v98
				end
			else
				v98 = ""
			end
			v99.SoundId = v98
			v99.Looped = false
			v99.Volume = 1
			v99.RollOffMode = Enum.RollOffMode.InverseTapered
			v99.RollOffMinDistance = 8
			v99.RollOffMaxDistance = 220
			v99.Parent = v54
			v19.pop = v99
			v19.pops = {}
			v19.highAt = -100
			v19.poppedAt = -100
			v19.flames = {}
			v19.smoke = {}
			for _, v100 in v_u_18:GetChildren() do
				if not (v100:IsA("Attachment") and v100.Name:match("^Exhaust%d+$")) then
					continue
				end
				local v101 = Instance.new("ParticleEmitter")
				v101.Name = "CarExhaust"
				v101.Texture = "rbxasset://textures/particles/smoke_main.dds"
				v101.Color = ColorSequence.new(Color3.fromRGB(200, 200, 200))
				v101.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.82), NumberSequenceKeypoint.new(1, 1) })
				v101.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.25), NumberSequenceKeypoint.new(1, 1.6) })
				v101.Lifetime = NumberRange.new(0.8, 1.4)
				v101.Speed = NumberRange.new(2, 4)
				v101.SpreadAngle = Vector2.new(12, 12)
				v101.EmissionDirection = Enum.NormalId.Back
				v101.Rate = 0
				v101.LightInfluence = 1
				v101.Enabled = false
				v101.Parent = v100
				local v102 = v19.smoke
				table.insert(v102, v101)
				local v103 = Instance.new("ParticleEmitter")
				v103.Name = "CarFlame"
				v103.Texture = "rbxasset://textures/particles/fire_main.dds"
				v103.Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(120, 170, 255)), ColorSequenceKeypoint.new(0.3, Color3.fromRGB(255, 170, 60)), ColorSequenceKeypoint.new(1, Color3.fromRGB(255, 70, 20)) })
				v103.LightEmission = 1
				v103.LightInfluence = 0
				v103.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.45), NumberSequenceKeypoint.new(1, 0.08) })
				v103.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.05), NumberSequenceKeypoint.new(1, 1) })
				v103.Lifetime = NumberRange.new(0.06, 0.14)
				v103.Speed = NumberRange.new(10, 16)
				v103.SpreadAngle = Vector2.new(7, 7)
				v103.EmissionDirection = Enum.NormalId.Back
				v103.LockedToPart = true
				v103.Rate = 0
				v103.Enabled = false
				v103.Parent = v100
				local v104 = Instance.new("PointLight")
				v104.Name = "CarFlameLight"
				v104.Color = Color3.fromRGB(255, 140, 50)
				v104.Range = 7
				v104.Brightness = 3
				v104.Enabled = false
				v104.Parent = v100
				local v105 = v19.flames
				table.insert(v105, {
					["emitter"] = nil,
					["light"] = nil,
					["offAt"] = 0,
					["emitter"] = v103,
					["light"] = v104
				})
			end
			if p17:GetAttribute("KitSmoke") == "Black" then
				local v106 = Instance.new("ParticleEmitter")
				v106.Name = "KitBlackSmoke"
				v106.Texture = "rbxassetid://688705835"
				v106.Color = ColorSequence.new(Color3.fromRGB(20, 20, 20))
				v106.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.25), NumberSequenceKeypoint.new(0.8, 7.57), NumberSequenceKeypoint.new(1, 0) })
				v106.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.7, 0.87), NumberSequenceKeypoint.new(1, 1) })
				v106.Lifetime = NumberRange.new(2.5, 10)
				v106.Speed = NumberRange.new(15)
				v106.SpreadAngle = Vector2.new(5, 10)
				v106.Acceleration = Vector3.new(-1, 0, -1)
				v106.Rotation = NumberRange.new(1)
				v106.RotSpeed = NumberRange.new(20, 50)
				v106.LightEmission = 0
				v106.LightInfluence = 1
				v106.EmissionDirection = Enum.NormalId.Back
				v106.Rate = 0
				v106.Enabled = false
				v106.Parent = v54
				v19.kitSmoke = v106
				v19.kitSmokeRate = p17:GetAttribute("KitSmokeRate") or 60
			end
			v19.rayParams = RaycastParams.new()
			v19.rayParams.FilterType = Enum.RaycastFilterType.Exclude
			v19.rayParams.FilterDescendantsInstances = { p17 }
			v19.rayParams.IgnoreWater = true
			v19.engineWas = p17:GetAttribute("EngineOn") == true
			v19.guide = {}
			for _, v107 in p17:GetDescendants() do
				if not v107:IsA("BasePart") or v107.Name ~= "DRLGuidePiece" then
					continue
				end
				v107.Transparency = 1
				local v108 = v19.guide
				local v109 = {
					["part"] = v107,
					["t"] = v107:GetAttribute("T") or 0,
					["top"] = v107:GetAttribute("Top") == true,
					["side"] = v107:GetAttribute("Side") or ""
				}
				table.insert(v108, v109)
			end
			local v110 = #v19.guide > 0 and 8 or 0
			local v111 = {}
			for _, v112 in v19.lamps do
				local v113 = v112.part:GetAttribute("DRLBand")
				if (v112.kind == "DRL" or v112.part:GetAttribute("DRLMirror")) and v113 then
					v112.band = v113
					v112.row = v112.part:GetAttribute("DRLRow") or 1
					v110 = math.max(v110, v113)
				else
					if v112.kind ~= "DRL" then
						continue
					end
					table.insert(v111, v112)
				end
			end
			if v110 > 0 then
				v19.bandCount = v110
			else
				if #v111 == 0 and p17:GetAttribute("HeadlampsNoRGB") ~= true then
					for _, v114 in v19.lamps do
						if v114.kind ~= "Head" then
							continue
						end
						table.insert(v111, v114)
					end
				end
				table.sort(v111, function(p115, p116)
					-- upvalues: (copy) v_u_18
					return v_u_18.CFrame:PointToObjectSpace(p115.part.Position).X < v_u_18.CFrame:PointToObjectSpace(p116.part.Position).X
				end)
				for v117, v118 in v111 do
					v118.band = v117
				end
				v19.bandCount = #v111
			end
			v19.drlGlows = {}
			local v119 = v19.bandCount / 2
			local v120 = math.ceil(v119)
			local v121 = {}
			local v122 = {}
			for _, v123 in v19.guide do
				local v124 = v121[v123.side]
				if not v123.top then
					continue
				end
				if v124 then
					local v125 = v123.t - 0.5
					local v126 = math.abs(v125)
					local v127 = v124.t - 0.5
					if v126 >= math.abs(v127) then
						continue
					end
				end
				v121[v123.side] = v123
			end
			for _, v128 in v121 do
				local v129 = v128.part.Position
				table.insert(v122, v129)
			end
			local v130 = {}
			for _, v131 in v19.lamps do
				local v132 = v131.side or v131.part
				if v131.band ~= v120 or (v131.kind ~= "DRL" or ((v131.row or 1) ~= 1 or v130[v132])) then
					continue
				end
				v130[v132] = true
				local v133 = v131.part.Position
				table.insert(v122, v133)
			end
			for _, v134 in v122 do
				local v135 = Instance.new("Attachment")
				v135.Name = "CarDRLGlow"
				v135.Parent = v_u_18
				v135.WorldPosition = v134 + v_u_18.CFrame.LookVector * 1
				local v136 = Instance.new("PointLight")
				v136.Range = 2.5
				v136.Brightness = 0.5
				v136.Shadows = false
				v136.Enabled = false
				v136.Parent = v135
				local v137 = v19.drlGlows
				table.insert(v137, v136)
			end
			local v138 = Vector3.new(0, 0, 0)
			local v139 = 0
			for _, v140 in p17:GetChildren() do
				if not (v140:IsA("Seat") or v140:IsA("VehicleSeat")) or (v140:GetAttribute("SeatKey") or ""):sub(1, 5) ~= "Front" then
					continue
				end
				v138 = v138 + v_u_18.CFrame:PointToObjectSpace(v140.Position)
				v139 = v139 + 1
			end
			if v139 > 0 then
				local v141 = Instance.new("Attachment")
				v141.Name = "CarCabinLight"
				v141.Position = v138 / v139 + Vector3.new(0, 2.6, -0.5)
				v141.Parent = v_u_18
				v19.cabinLight = Instance.new("PointLight")
				v19.cabinLight.Range = 5
				v19.cabinLight.Brightness = 0.25
				v19.cabinLight.Shadows = false
				v19.cabinLight.Enabled = false
				v19.cabinLight.Parent = v141
				v19.cabinAttachment = v141
			end
			local v142 = p17:FindFirstChild("SteeringWheelRoot")
			if v142 then
				v19.dashGlow = Instance.new("PointLight")
				v19.dashGlow.Name = "CarDashGlow"
				v19.dashGlow.Range = 3
				v19.dashGlow.Brightness = 0.6
				v19.dashGlow.Color = v_u_12
				v19.dashGlow.Shadows = false
				v19.dashGlow.Enabled = false
				v19.dashGlow.Parent = v142
			end
			local v143 = nil
			local v144 = 6
			for _, v145 in v19.wheels do
				if not v145.hub then
					continue
				end
				local v146 = v145.hub.Y - v145.radius
				v143 = math.min(v143 or (1 / 0), v146)
				local v147 = v145.hub.Z
				local v148 = math.abs(v147)
				v144 = math.max(v144, v148)
			end
			v19.underglow = {}
			for v149, v150 in { -0.7, 0, 0.7 } do
				local v151 = Instance.new("Attachment")
				v151.Name = "CarUnderglow" .. v149
				local v152 = (v143 or -1) + 0.5
				local v153 = v150 * v144
				v151.Position = Vector3.new(0, v152, v153)
				v151.Parent = v_u_18
				local v154 = Instance.new("PointLight")
				local v155 = v144 * 1.3
				v154.Range = math.max(10, v155)
				v154.Brightness = 4
				v154.Shadows = true
				v154.Enabled = false
				v154.Parent = v151
				local v156 = v19.underglow
				table.insert(v156, v154)
			end
			v_u_15[p17] = v19
		end
	end
end
local function v_u_171(p158, p159) -- name: wheelCompression
	-- upvalues: (copy) v_u_5
	local v160 = p158.chassis.CFrame:PointToWorldSpace(p159.hub)
	local v161 = p159.radius + v_u_5.SUSP_EXTEND + 1.5
	local v162 = workspace
	local v163 = v160 + Vector3.new(0, 1, 0)
	local v164 = -v161
	local v165 = v162:Raycast(v163, Vector3.new(0, v164, 0), p158.rayParams)
	if not v165 then
		return -v_u_5.SUSP_EXTEND
	end
	local v166 = p158.chassis.Parent
	if not v166 then
		v167 = v166 and v166:GetAttribute("LowerDrop") or 0
		v168 = p159.radius - (v160.Y - v165.Position.Y)
		v169 = -v_u_5.SUSP_EXTEND
		v170 = v_u_5.SUSP_TRAVEL + v167
		return math.clamp(v168, v169, v170)
	end
	if p159.hub.Z < 0 then
		v167 = v166:GetAttribute("LowerDropFront")
	else
		v167 = v166:GetAttribute("LowerDropRear")
	end
	if v167 then
		v168 = p159.radius - (v160.Y - v165.Position.Y)
		v169 = -v_u_5.SUSP_EXTEND
		v170 = v_u_5.SUSP_TRAVEL + v167
		return math.clamp(v168, v169, v170)
	end
	local v167 = v166 and v166:GetAttribute("LowerDrop") or 0
	local v168 = p159.radius - (v160.Y - v165.Position.Y)
	local v169 = -v_u_5.SUSP_EXTEND
	local v170 = v_u_5.SUSP_TRAVEL + v167
	return math.clamp(v168, v169, v170)
end
local function v_u_178(p172) -- name: teardown
	-- upvalues: (copy) v_u_15
	local v173 = v_u_15[p172]
	if v173 then
		if v173.fx then
			v173.fx:Destroy()
		end
		if v173.exhaustFx then
			v173.exhaustFx:Destroy()
		end
		for _, v174 in v173.smoke do
			v174:Destroy()
		end
		for _, v175 in v173.flames or {} do
			v175.emitter:Destroy()
			v175.light:Destroy()
		end
		for _, v176 in v173.underglow or {} do
			if not v176.Parent then
				continue
			end
			v176.Parent:Destroy()
		end
		for _, v177 in v173.drlGlows or {} do
			if not v177.Parent then
				continue
			end
			v177.Parent:Destroy()
		end
		if v173.cabinAttachment then
			v173.cabinAttachment:Destroy()
		end
		if v173.dashGlow then
			v173.dashGlow:Destroy()
		end
		v_u_15[p172] = nil
	end
end
local function v_u_184(p179, p180, p181) -- name: setLamp
	local v182 = p180 .. tostring(p181)
	if p179.state ~= v182 then
		p179.state = v182
		local v183 = p179.part
		if p179.twin then
			v183.Color = p181
			v183.Transparency = p180 == "on" and 0 or (p180 == "dim" and 0.45 or 1)
			if p179.covers then
				p179.covers.LocalTransparencyModifier = p180 == "on" and 1 or 0
				return
			end
		else
			if p180 == "off" then
				v183.Color = p179.baseColor
				v183.Material = p179.baseMaterial
				return
			end
			if p180 == "dim" then
				p181 = p181:Lerp(Color3.new(0, 0, 0), 0.4)
			end
			v183.Color = p181
			v183.Material = Enum.Material.Neon
		end
	end
end
local v_u_185 = {
	["idle"] = { Color3.fromRGB(120, 132, 150), 0.6 },
	["on"] = { Color3.fromRGB(150, 160, 178), 0.5 }
}
local function v_u_194(p186, p187, p188, p189) -- name: frontColorAt
	-- upvalues: (copy) v_u_5
	local v190 = p186.model
	local v191 = p186.chassis.CFrame:PointToObjectSpace(p187).X
	local v192 = math.abs(v191) / p186.tailReach
	local v193 = math.clamp(v192, 0, 1)
	if v190:GetAttribute("DRLStyle") == "Mode" then
		return v_u_5.modeColor(v190, v193, v191 < 0 and "Left" or "Right", p189, true)
	else
		return v_u_5.lightColor(v190, v193 + 1, 2, p188)
	end
end
local function v_u_200(p195, p196) -- name: firePop
	-- upvalues: (copy) v_u_2
	local v197 = p195.pop:Clone()
	v197.PlaybackSpeed = 0.85 + math.random() * 0.4
	v197.Volume = (0.6 + math.random() * 0.5) * p196.pops
	v197.Parent = p195.exhaustFx
	v197:Play()
	v_u_2:AddItem(v197, 2)
	if p196.flames then
		local v198 = os.clock()
		for _, v199 in p195.flames do
			v199.emitter:Emit(math.random(3, 5))
			v199.light.Enabled = true
			v199.offAt = v198 + 0.07
		end
	end
end
local function v_u_211(p201, p202, p203, p204) -- name: stepExhaust
	-- upvalues: (copy) v_u_10, (copy) v_u_200
	local v205 = os.clock()
	if p203 > 0.5 then
		p201.highAt = v205
	elseif p202.pops > 0 and (p203 < 0.12 and (p204 > 0.3 and (v205 - p201.highAt < 0.6 and (p201.poppedAt < p201.highAt and v205 - p201.poppedAt > 0.9)))) then
		p201.poppedAt = v205
		local v206 = math.random
		local v207 = p202.pops * 4
		local v208 = v205
		for _ = 1, v206(2, math.round(v207) + 2) do
			v208 = v208 + (v_u_10[1] + math.random() * (v_u_10[2] - v_u_10[1]))
			local v209 = p201.pops
			table.insert(v209, v208)
		end
	end
	while p201.pops[1] and p201.pops[1] <= v205 do
		table.remove(p201.pops, 1)
		v_u_200(p201, p202)
	end
	for _, v210 in p201.flames do
		if not v210.light.Enabled or v210.offAt > v205 then
			continue
		end
		v210.light.Enabled = false
	end
end
local function v_u_248(p212, p213, p214, p215) -- name: stepEngineLayers
	local v216 = p212.points
	local v217 = v216[1]
	local v218 = v216[#v216]
	for v219 = 1, #v216 - 1 do
		if p213 > v216[v219 + 1].rpm then
			continue
		end
		v217 = v216[v219]
		v218 = v216[v219 + 1]
	end
	local v220 = p213 - v217.rpm
	local v221 = v218.rpm - v217.rpm
	local v222 = v220 / math.max(v221, 1)
	local v223 = math.clamp(v222, 0, 1)
	local v224
	if p212.idleSound then
		local v225 = (p212.idleRpm + 500 - p213) / 500
		v224 = math.clamp(v225, 0, 1)
		local v226 = p212.idleSound
		local v227 = p215 * math.sqrt(v224) * p212.idleGain
		local v228 = p213 / p212.idleRpm
		local v229 = math.clamp(v228, 0.6, 1.8)
		if v227 > 0.01 then
			v226.Volume = math.min(v227, 10)
			v226.PlaybackSpeed = v229
			if not v226.IsPlaying then
				v226:Play()
			end
		elseif v226.IsPlaying then
			v226:Stop()
		end
	else
		v224 = 0
	end
	local v230 = 1 - v224
	local v231 = p215 * math.sqrt(v230)
	local v232 = math.sqrt(p214)
	local v233 = 1 - p214
	local v234 = math.sqrt(v233)
	for _, v235 in v216 do
		local v236
		if v235 == v217 then
			local v237 = v223 * 3.141592653589793 / 2
			v236 = math.cos(v237)
		elseif v235 == v218 then
			local v238 = v223 * 3.141592653589793 / 2
			v236 = math.sin(v238)
		else
			v236 = 0
		end
		local v239 = p213 / v235.rpm
		local v240 = math.clamp(v239, 0.5, 2)
		local v241 = v235.on or v235.off
		local v242 = v235.off or v235.on
		if v241 == v242 then
			local v243 = v236 * v231
			local v244
			if v235.on then
				v244 = v235.onGain
			else
				v244 = v235.offGain
			end
			local v245 = v243 * v244
			if v245 > 0.01 then
				v241.Volume = math.min(v245, 10)
				v241.PlaybackSpeed = v240
				if v241.IsPlaying then
					continue
				end
				v241:Play()
			else
				if not v241.IsPlaying then
					continue
				end
				v241:Stop()
			end
		else
			local v246 = v236 * v231 * v232 * v235.onGain
			if v246 > 0.01 then
				v241.Volume = math.min(v246, 10)
				v241.PlaybackSpeed = v240
				if not v241.IsPlaying then
					v241:Play()
				end
			elseif v241.IsPlaying then
				v241:Stop()
			end
			local v247 = v236 * v231 * v234 * v235.offGain
			if v247 > 0.01 then
				v242.Volume = math.min(v247, 10)
				v242.PlaybackSpeed = v240
				if v242.IsPlaying then
					continue
				end
				v242:Play()
			else
				if not v242.IsPlaying then
					continue
				end
				v242:Stop()
			end
		end
	end
end
local function v_u_293(p249, p250, p251, p252, p253) -- name: stepKitEngine
	-- upvalues: (copy) v_u_5
	local v254 = p249.kit
	v254.ts = v254.ts + (math.clamp(p251, 0, 1) - v254.ts) * v_u_5.alpha(8, p253)
	local v255 = (p250 - 1300) / 1600
	local v256 = math.clamp(v255, 0, 1)
	local v257 = v256 * v256 * (3 - v256 * 2)
	local v258 = 0.05 + p250 / 7000
	local v259 = math.min(v258, 0.85)
	local v260 = p250 / 7000
	local v261 = math.clamp(v260, 0.45, 0.95)
	if v254.mix == "AC6" then
		local v262 = (p250 - v_u_5.IDLE_RPM) / (v_u_5.REDLINE_RPM - v_u_5.IDLE_RPM)
		local v263 = math.clamp(v262, 0, 1)
		local v264 = (v254.idleRpm + v263 * (v254.redline - v254.idleRpm)) / v254.redline
		local v265 = 11.25 * v264 - 5
		local v266 = math.clamp(v265, 0, 1)
		local v267 = (0.2 + 1.7 * v264) * (1 - v266) + (0.1 + 1.1 * v264) * v266
		local v268 = 2 - 8 * v264
		local v269 = math.clamp(v268, 0, 1)
		local v270 = v254.Rev.sound
		local v271 = v254.Rev.volume * v269 * p252
		local v272 = 1 + 1.6 * v264
		if v271 > 0.01 then
			v270.Volume = math.min(v271, 10)
			v270.PlaybackSpeed = v272
			if not v270.IsPlaying then
				v270:Play()
			end
		elseif v270.IsPlaying then
			v270:Stop()
		end
		local v273 = v254.Acc.sound
		local v274 = v254.Acc.volume * v254.ts * p252
		if v274 > 0.01 then
			v273.Volume = math.min(v274, 10)
			v273.PlaybackSpeed = v267
			if not v273.IsPlaying then
				v273:Play()
			end
		elseif v273.IsPlaying then
			v273:Stop()
		end
		local v275 = v254.Dec.sound
		local v276 = v254.Dec.volume * (1 - v254.ts) * (1 - v269 * 0.5) * p252
		if v276 > 0.01 then
			v275.Volume = math.min(v276, 10)
			v275.PlaybackSpeed = v267
			if not v275.IsPlaying then
				v275:Play()
			end
		elseif v275.IsPlaying then
			v275:Stop()
		end
	else
		local v277 = v254.Rev.sound
		local v278 = v254.Rev.volume * (1 - 0.8 * v257) * p252
		if v278 > 0.01 then
			v277.Volume = math.min(v278, 10)
			v277.PlaybackSpeed = v259
			if not v277.IsPlaying then
				v277:Play()
			end
		elseif v277.IsPlaying then
			v277:Stop()
		end
		local v279 = v254.Acc.sound
		local v280 = v254.Acc.volume * v257 * (0.35 + 0.65 * v254.ts) * p252
		if v280 > 0.01 then
			v279.Volume = math.min(v280, 10)
			v279.PlaybackSpeed = v261
			if not v279.IsPlaying then
				v279:Play()
			end
		elseif v279.IsPlaying then
			v279:Stop()
		end
		local v281 = v254.Dec.sound
		local v282 = v254.Dec.volume * v257 * (1 - v254.ts) * p252
		if v282 > 0.01 then
			v281.Volume = math.min(v282, 10)
			v281.PlaybackSpeed = v261
			if not v281.IsPlaying then
				v281:Play()
			end
		elseif v281.IsPlaying then
			v281:Stop()
		end
	end
	if v254.turbo or v254.bov then
		local v283 = math.clamp(p251, 0, 1)
		local v284 = (p250 - 2000) / 3500
		local v285 = math.clamp(v284, 0, 1)
		local v286 = v283 * (v285 * v285 * (3 - v285 * 2))
		v254.boost = v254.boost + (v286 - v254.boost) * v_u_5.alpha(v254.boost < v286 and 1.2 or 5, p253)
		if v254.turbo then
			local v287 = v254.turbo
			local v288 = v254.turboVolume * v254.boost * p252
			local v289 = 1 + 1.75 * v254.boost
			local v290 = math.min(v289, 2)
			if v288 > 0.01 then
				v287.Volume = math.min(v288, 10)
				v287.PlaybackSpeed = v290
				if not v287.IsPlaying then
					v287:Play()
				end
			elseif v287.IsPlaying then
				v287:Stop()
			end
		end
		if v254.bov then
			if v254.lastPedal and (v254.lastPedal - v283 > 0.3 and v254.boost > 0.35) then
				local v291 = v254.bov
				local v292 = v254.bovVolume * v254.boost * p252
				v291.Volume = math.min(v292, 10)
				v254.bov.PlaybackSpeed = 0.3 + 1.75 * v254.boost
				v254.bov.TimePosition = 0
				v254.bov:Play()
				v254.boost = v254.boost * 0.3
			end
			v254.lastPedal = v283
		end
	end
end
local function v_u_298(p294) -- name: stopEngineLayers
	if p294.kit then
		for _, v295 in { "Rev", "Acc", "Dec" } do
			if not p294.kit[v295].sound.IsPlaying then
				continue
			end
			p294.kit[v295].sound:Stop()
		end
		if p294.kit.turbo and p294.kit.turbo.IsPlaying then
			p294.kit.turbo:Stop()
		end
		p294.kit.boost = 0
	end
	for _, v296 in p294.points or {} do
		for _, v297 in { v296.on, v296.off } do
			if not (v297 and v297.IsPlaying) then
				continue
			end
			v297:Stop()
		end
	end
	if p294.idleSound and p294.idleSound.IsPlaying then
		p294.idleSound:Stop()
	end
end
local function v_u_486(p299, p300, p301) -- name: stepCar
	-- upvalues: (copy) v_u_5, (ref) v_u_16, (copy) v_u_171, (copy) v_u_6, (copy) v_u_184, (copy) v_u_13, (copy) v_u_185, (copy) v_u_194, (copy) v_u_8, (copy) v_u_11, (copy) v_u_7, (copy) v_u_293, (copy) v_u_248, (copy) v_u_211, (copy) v_u_298
	local v302 = p299.model
	local v303 = p299.chassis
	if v303.Parent then
		local v304 = (v303.Position - p301).Magnitude < 450
		local v305 = v_u_5.flatRotation(v303.CFrame)
		local v306 = v303.AssemblyLinearVelocity:Dot(v305.LookVector)
		local v307 = v303.Anchored and 0 or v306
		local v308 = v_u_16
		if v308 then
			v308 = v_u_16.model == v302
		end
		local v309
		if v308 then
			v309 = v_u_16.steer
		else
			v309 = v302:GetAttribute("Steer") or 0
		end
		p299.steer = p299.steer + (v309 - p299.steer) * v_u_5.alpha(10, p300)
		local v310
		if v308 then
			v310 = v_u_16.throttle
		else
			local v311 = (v307 - p299.lastSpeed) / math.max(p300, 0.001) / 6
			v310 = math.clamp(v311, -1, 1)
		end
		p299.throttleGuess = p299.throttleGuess + (v310 - p299.throttleGuess) * v_u_5.alpha(4, p300)
		p299.lastSpeed = v307
		if v304 then
			local v312 = v302:GetAttribute("MaxSteer") or v_u_5.MAX_STEER
			local v313 = p299.steer
			local v314 = v_u_5.maxSteer(v307) * v312 / v_u_5.MAX_STEER
			local v315 = v313 * math.min(v312, v314)
			local v316
			if (v303.Position - p301).Magnitude < 250 then
				v316 = v303.CFrame.UpVector.Y > 0.5
			else
				v316 = false
			end
			local v317 = v_u_5.alpha(30, p300)
			for _, v318 in p299.wheels do
				if v318.spin then
					v318.angle = (v318.angle - v307 / v318.radius * p300) % 6.283185307179586
					v318.spin.motor.C0 = v318.spin.base * CFrame.Angles(v318.angle, 0, 0)
				end
				if not v318.steer then
					continue
				end
				local v319 = not (v316 and v318.hub) and 0 or v_u_171(p299, v318)
				v318.comp = v318.comp + (v319 - v318.comp) * v317
				local v320 = CFrame.new(0, v318.comp, 0)
				if v318.factor == 0 then
					v318.steer.motor.C0 = v320 * v318.steer.base
				else
					v318.steer.motor.C0 = v320 * v318.steer.base * CFrame.Angles(0, -v315 * v318.factor, 0)
				end
			end
			if p299.steeringWheel then
				p299.steeringWheel.motor.C0 = p299.steeringWheel.base * CFrame.Angles(0, 0, -p299.steer * v_u_5.STEERING_WHEEL_TURN)
			end
			local v321 = workspace:GetServerTimeNow()
			for v322, v323 in p299.doors do
				local v324 = v321 - (v302:GetAttribute("DoorOpenAt_" .. v322) or -100)
				local v325 = v324 >= 0 and v324 < v_u_5.DOOR_TIME and 1 or (v302:GetAttribute("DoorHeld_" .. v322) == true and 1 or 0)
				local v326 = v323.open < v325 and 5 or 3.5
				local v327 = v323.open
				local v328 = v325 - v323.open
				local v329 = v327 + math.sign(v328) * v326 * p300
				v323.open = math.clamp(v329, 0, 1)
				local v330 = v323.open * v323.open * (3 - 2 * v323.open)
				v323.motor.C0 = v323.base * CFrame.Angles(0, v323.sign * v_u_5.DOOR_OPEN * v330, 0)
			end
			if p299.shifter or p299.handbrakeLever then
				local v331 = v302:GetAttribute("EngineOn") == true
				if p299.shifter then
					local v332 = p299.shifter
					local v333 = v332.gears
					local v334
					if v331 then
						local v335
						if v308 then
							v335 = v302:GetAttribute("LocalReversing") == true
						else
							v335 = v302:GetAttribute("Reversing") == true
						end
						if v335 or v307 < -0.5 then
							v334 = -1
						else
							local v336 = v_u_6.gear(v302)
							if not v336 then
								local v337 = v_u_6.SHARES[v333]
								local v338 = v302:GetAttribute("MaxSpeed") or v_u_5.DEFAULT_MAX_SPEED
								local v339 = v332.gear
								v336 = math.clamp(v339, 1, v333)
								if v336 < v333 and v337[v336] * v338 < v307 then
									v336 = v336 + 1
								elseif v336 > 1 and v307 < v337[v336 - 1] * v338 * 0.8 then
									v336 = v336 - 1
								end
							end
							v334 = math.clamp(v336, 1, v333)
						end
					else
						v334 = 0
					end
					v332.gear = v334
					local v340 = 0
					local v341 = 0
					if v334 == -1 then
						local v342 = (v333 + 1) / 4
						v340 = math.floor(v342) * 2 * v332.h
						if v333 % 2 == 0 then
							v341 = v332.v
						else
							v341 = -v332.v
						end
					elseif v334 > 0 then
						local v343 = (v334 - 1) / 2
						local v344 = math.floor(v343)
						local v345 = (v333 + 1) / 4
						v340 = (v344 - math.floor(v345)) * v332.h
						if v334 % 2 == 1 then
							v341 = v332.v
						else
							v341 = -v332.v
						end
					end
					local v346 = p300 / 0.15
					local v347 = v332.side - v340
					if math.abs(v347) > 0.001 then
						local v348 = v332.fore
						if math.abs(v348) > 0.001 then
							local v349 = v332.fore
							local v350 = v332.fore
							local v351 = math.sign(v350)
							local v352 = v332.fore
							local v353 = math.abs(v352)
							local v354 = v332.v * v346
							v332.fore = v349 - v351 * math.min(v353, v354)
						else
							local v355 = v332.side
							local v356 = v340 - v332.side
							local v357 = math.sign(v356)
							local v358 = v340 - v332.side
							local v359 = math.abs(v358)
							local v360 = v332.h * v346
							v332.side = v355 + v357 * math.min(v359, v360)
						end
					else
						local v361 = v332.fore - v341
						if math.abs(v361) > 0.001 then
							local v362 = v332.fore
							local v363 = v341 - v332.fore
							local v364 = math.sign(v363)
							local v365 = v341 - v332.fore
							local v366 = math.abs(v365)
							local v367 = v332.v * v346
							v332.fore = v362 + v364 * math.min(v366, v367)
						end
					end
					v332.motor.C0 = v332.base * CFrame.Angles(-v332.fore, 0, -v332.side)
				end
				if p299.handbrakeLever then
					local v368 = p299.handbrakeLever
					local v369 = not v331
					if not v369 then
						if v368.seat == nil or v368.seat.Occupant ~= nil then
							if v308 then
								v369 = v302:GetAttribute("LocalHandbrake") == true
							else
								v369 = v302:GetAttribute("Handbrake") == true
							end
						else
							v369 = true
						end
					end
					local v370 = v368.k
					local v371 = (v369 and 1 or 0) - v368.k
					local v372 = v370 + math.sign(v371) * p300 / 0.2
					v368.k = math.clamp(v372, 0, 1)
					if v368.k ~= v368.shown then
						v368.shown = v368.k
						v368.motor.C0 = v368.base * CFrame.Angles(v368.angle * v368.k, 0, 0)
					end
				end
			end
		end
		local v373 = v302:GetAttribute("HeadlightsOn") == true
		local v374 = v302:GetAttribute("Braking") == true
		local v375 = v302:GetAttribute("Reversing") == true
		if v308 and v302:GetAttribute("LocalBraking") ~= nil then
			v374 = v302:GetAttribute("LocalBraking") == true
			if v302:GetAttribute("LocalReversing") == true then
				v375 = true
			else
				v375 = false
			end
		end
		local v376 = v302:GetAttribute("EngineOn") == true
		local v377 = v302:GetAttribute("Indicator") or "Off"
		local v378 = workspace:GetServerTimeNow() % v_u_5.BLINK_PERIOD < v_u_5.BLINK_ON_TIME
		local v379 = {}
		local v380
		if v378 then
			v380 = v377 == "Left" and true or v377 == "Hazard"
		else
			v380 = v378
		end
		v379.Left = v380
		local v381
		if v378 then
			v381 = v377 == "Right" and true or v377 == "Hazard"
		else
			v381 = v378
		end
		v379.Right = v381
		local v382 = v302:GetAttribute("RearIndicatorsInLamps") == true
		local v383
		if v376 then
			if v302:GetAttribute("RainbowOn") == true then
				v383 = v302:GetAttribute("KitRung") ~= true
			else
				v383 = false
			end
		else
			v383 = v376
		end
		local v384 = os.clock()
		for _, v385 in p299.lamps do
			local v386 = v385.kind
			if v383 and (v385.band and (v385.part:GetAttribute("DRLMirror") and v302:GetAttribute("DRLStyle") == "Mode")) then
				local v387 = p299.bandCount <= 1 and 0 or 1 - (v385.band - 1) / (p299.bandCount - 1)
				local v388 = v_u_5.modeColor(v302, v387, v385.side or "Left")
				v_u_184(v385, v388 and "on" or "off", v388 or v_u_13.DRL)
			elseif v383 and v385.band then
				local v389 = v_u_5.lightColor(v302, v385.band, p299.bandCount, v384)
				local v390 = "on" .. tostring(v389)
				if v385.state == v390 then
					continue
				end
				v385.state = v390
				local v391 = v385.part
				if v385.twin then
					v391.Color = v389
					v391.Transparency = 0
					if not v385.covers then
						continue
					end
					v385.covers.LocalTransparencyModifier = 1
				else
					v391.Color = v389
					v391.Material = Enum.Material.Neon
				end
			elseif v386 == "Head" and v385.part:GetAttribute("SoftGlow") then
				local v392 = v373 and "on" or (v376 and v385.part:GetAttribute("LitWithEngine") and "idle" or "off")
				local v393 = "soft" .. v392
				if v385.state == v393 then
					continue
				end
				v385.state = v393
				local v394 = v_u_185[v392]
				if v394 then
					v385.part.Color = v394[1]
					v385.part.Transparency = v394[2]
				else
					v385.part.Transparency = 1
				end
			elseif v386 == "Head" and (v376 and v385.part:GetAttribute("LitWithEngine")) then
				local v395 = v_u_13.Head
				local v396 = "on" .. tostring(v395)
				if v385.state == v396 then
					continue
				end
				v385.state = v396
				local v397 = v385.part
				if v385.twin then
					v397.Color = v395
					v397.Transparency = 0
					if not v385.covers then
						continue
					end
					v385.covers.LocalTransparencyModifier = 1
				else
					v397.Color = v395
					v397.Material = Enum.Material.Neon
				end
			elseif v386 == "Head" then
				v_u_184(v385, v373 and "on" or "off", v_u_13.Head)
			elseif v386 == "DRL" then
				v_u_184(v385, (v376 or v373) and (v385.row or 1) <= 1 and "on" or "off", v_u_13.DRL)
			elseif v386 == "Brake" or v386 == "Tail" then
				if v382 and (v377 ~= "Off" and (v377 == "Hazard" or v377 == v385.side)) and v379[v385.side] then
					local v398 = v_u_13.Indicator
					local v399 = "on" .. tostring(v398)
					if v385.state == v399 then
						continue
					end
					v385.state = v399
					local v400 = v385.part
					if v385.twin then
						v400.Color = v398
						v400.Transparency = 0
						if not v385.covers then
							continue
						end
						v385.covers.LocalTransparencyModifier = 1
					else
						v400.Color = v398
						v400.Material = Enum.Material.Neon
					end
				elseif v383 then
					local v401 = v385.part
					local v402 = workspace:GetServerTimeNow()
					local v403 = v_u_194(p299, v401.Position, v384, v402)
					v_u_184(v385, v403 and "on" or "off", v403 or v_u_13.Brake)
				elseif v374 then
					local v404 = v_u_13.Brake
					local v405 = "on" .. tostring(v404)
					if v385.state == v405 then
						continue
					end
					v385.state = v405
					local v406 = v385.part
					if v385.twin then
						v406.Color = v404
						v406.Transparency = 0
						if not v385.covers then
							continue
						end
						v385.covers.LocalTransparencyModifier = 1
					else
						v406.Color = v404
						v406.Material = Enum.Material.Neon
					end
				elseif v375 then
					local v407 = v_u_13.Brake
					local v408 = "on" .. tostring(v407)
					if v385.state == v408 then
						continue
					end
					v385.state = v408
					local v409 = v385.part
					if v385.twin then
						v409.Color = v407
						v409.Transparency = 0
						if not v385.covers then
							continue
						end
						v385.covers.LocalTransparencyModifier = 1
					else
						v409.Color = v407
						v409.Material = Enum.Material.Neon
					end
				else
					v_u_184(v385, v373 and "dim" or "off", v_u_13.Brake)
				end
			elseif v386 == "Reverse" then
				v_u_184(v385, v375 and "dim" or "off", v_u_13.Reverse)
			elseif v386 == "Indicator" then
				v_u_184(v385, v379[v385.side] and "on" or "off", v_u_13.Indicator)
			else
				if v386 ~= "Fog" then
					continue
				end
				local v410 = v_u_13.Fog
				local v411 = "off" .. tostring(v410)
				if v385.state == v411 then
					continue
				end
				v385.state = v411
				local v412 = v385.part
				if v385.twin then
					v412.Color = v410
					v412.Transparency = 1
					if not v385.covers then
						continue
					end
					v385.covers.LocalTransparencyModifier = 0
				else
					v412.Color = v385.baseColor
					v412.Material = v385.baseMaterial
				end
			end
		end
		for _, v413 in p299.beams.Head do
			v413.Enabled = v373
		end
		local v414 = workspace:GetServerTimeNow()
		for _, v415 in p299.beams.Brake do
			local v416
			if v383 and v415.Parent:IsA("Attachment") then
				v416 = v_u_194(p299, v415.Parent.WorldPosition, v384, v414)
			else
				v416 = nil
			end
			local v417
			if v383 then
				v417 = v416 ~= nil
			else
				v417 = v374 or (v375 or v373)
			end
			v415.Enabled = v417
			v415.Brightness = (v374 or v375) and 2 or 0.6
			v415.Color = v416 or (v415:GetAttribute("GlowBase") or v415.Color)
		end
		for _, v418 in p299.beams.Reverse do
			v418.Enabled = v375
		end
		for _, v419 in p299.beams.Indicator do
			v419.light.Enabled = v379[v419.side] == true
		end
		local v420 = workspace:GetServerTimeNow() % v_u_5.BLINK_PERIOD / (v_u_5.BLINK_ON_TIME * 0.55)
		local v421 = math.clamp(v420, 0, 1)
		if v376 and p299.engineWas == false then
			p299.welcomeAt = os.clock()
		end
		p299.engineWas = v376
		local v422 = p299.welcomeAt
		if v422 then
			v422 = os.clock() - p299.welcomeAt
		end
		if v422 and v_u_8.WELCOME_TIME < v422 then
			p299.welcomeAt = nil
			v422 = nil
		end
		local v423
		if v383 then
			v423 = v302:GetAttribute("DRLStyle") == "Mode"
		else
			v423 = v383
		end
		local v424 = workspace:GetServerTimeNow()
		for _, v425 in p299.guide do
			local v426
			if v377 == "Hazard" then
				v426 = true
			elseif v377 == "Off" then
				v426 = false
			else
				v426 = v377 == v425.side
			end
			local v427 = nil
			if v426 then
				if v378 and v425.t <= v421 then
					v427 = v_u_13.Indicator
				else
					v427 = nil
				end
			elseif v422 then
				v427 = v_u_8.welcome(v425.t, v422)
			elseif v423 then
				v427 = v_u_5.modeColor(v302, v425.t, v425.side, v424)
			elseif v383 then
				v427 = v_u_5.lightColor(v302, 1 + v425.t, 2, v384)
			elseif (v376 or v373) and v425.top then
				v427 = v_u_13.DRL
			end
			local v428
			if v304 then
				v428 = v427 ~= nil
			else
				v428 = v304
			end
			v425.part.Transparency = v428 and 0 or 1
			if not v428 then
				continue
			end
			v425.part.Color = v427
		end
		local v429 = v376 or v373
		local v430
		if v383 then
			local v431 = v_u_5.lightColor
			local v432 = p299.bandCount / 2
			v430 = v431(v302, math.ceil(v432), p299.bandCount, v384)
		else
			v430 = v_u_13.DRL
		end
		for _, v433 in p299.drlGlows do
			v433.Enabled = v304 and v429
			v433.Color = v430
		end
		if p299.cabinLight then
			p299.cabinLight.Enabled = v304 and v376
			p299.cabinLight.Color = v_u_11
		end
		if p299.dashGlow then
			p299.dashGlow.Enabled = v304 and v376
		end
		if v304 then
			if v376 or v373 then
				v373 = v302:GetAttribute("Underglow") == true
			end
		else
			v373 = v304
		end
		for v434, v435 in p299.underglow do
			v435.Enabled = v373
			if not v373 then
				continue
			end
			local v436
			if v383 then
				v436 = v_u_5.lightColor(v302, v434, #p299.underglow, v384)
			else
				v436 = v302:GetAttribute("DRLColor") or v_u_5.DRL_DEFAULT_COLOR
			end
			v435.Color = v436
		end
		local v437 = v379.Left or v379.Right
		if v377 ~= "Off" and (v437 ~= p299.blinkWasOn and v304) then
			p299.blinker.PlaybackSpeed = v437 and 1 or 0.85
			p299.blinker:Play()
		end
		p299.blinkWasOn = v437
		local v438 = v_u_5.EXHAUSTS[v302:GetAttribute("Exhaust") or "Stock"] or v_u_5.EXHAUSTS.Stock
		if v376 and v304 then
			local v439 = v302:GetAttribute("MaxSpeed") or v_u_5.DEFAULT_MAX_SPEED
			local v440
			if v308 then
				v440 = v310
			else
				v440 = p299.throttleGuess <= 0.15 and 0 or p299.throttleGuess
			end
			local v441 = v_u_5.rpm(v307, v439, v440)
			local v442
			if v307 > -0.3 then
				v442 = v_u_6.gear(v302)
			else
				v442 = false
			end
			local v443 = 0
			if v442 then
				if os.clock() - (p299.gearTopAt or 0) > 0.5 then
					p299.gearTopAt = os.clock()
					p299.gearTop = v_u_6.topSpeed(v302, 1)
				end
				local v444 = v_u_6.revs(v307, p299.gearTop, v_u_6.gears(v302), v442)
				v441 = v_u_5.IDLE_RPM + (v_u_5.REDLINE_RPM - v_u_5.IDLE_RPM) * v444
				if v442 == 1 and v440 > 0 then
					v441 = math.max(v441, 2200)
				end
				if v444 > 0.995 and v440 > 0 then
					local v445 = os.clock() * 45
					v443 = (math.sin(v445) * 0.5 + 0.5) * 450
				end
			end
			local v446 = v_u_7.soundSetting(v302, "Rev")
			if v440 > 0 and v446 ~= 1 then
				local v447 = v_u_5.REDLINE_RPM - v_u_5.IDLE_RPM
				local v448 = (v441 - v_u_5.IDLE_RPM) / v447
				local v449 = math.clamp(v448, 0, 1)
				v441 = v_u_5.IDLE_RPM + v447 * v449 ^ v446 ^ (-0.8)
			end
			p299.revRpm = p299.revRpm or v441
			local v450 = p299.revRpm < v441
			p299.revRpm = p299.revRpm + (v441 - p299.revRpm) * v_u_5.alpha(not v450 and 8 or 12 * v446, p300)
			local v451 = p299.revRpm - v443
			local v452 = v_u_7.idleSpeed(v302)
			if v452 ~= 1 then
				local v453 = v_u_5.IDLE_RPM * (v452 - 1)
				local v454 = 1 - (v451 - v_u_5.IDLE_RPM) / 1500
				v451 = v451 + v453 * math.clamp(v454, 0, 1)
			end
			local v455 = (v451 - v_u_5.IDLE_RPM) / (v_u_5.REDLINE_RPM - v_u_5.IDLE_RPM)
			local v456 = table.clone(v438)
			local v457 = v456.pitch
			local v458 = v302:GetAttribute("EnginePitch")
			v456.pitch = v457 * (typeof(v458) ~= "number" and 1 or v458)
			local v459 = v456.volume
			local v460 = v302:GetAttribute("ExhaustVolume")
			v456.volume = v459 * (typeof(v460) ~= "number" and 1 or v460)
			local v461 = v456.distortion
			local v462 = v302:GetAttribute("ExhaustRasp")
			local v463 = v461 + (typeof(v462) ~= "number" and 0 or v462)
			v456.distortion = math.clamp(v463, 0, 1)
			local v464 = v456.low or 0
			local v465 = v302:GetAttribute("ExhaustBass")
			v456.low = v464 + (typeof(v465) ~= "number" and 0 or v465)
			local v466 = v456.rumble
			local v467 = v302:GetAttribute("ExhaustBass")
			local v468 = v466 + (typeof(v467) ~= "number" and 0 or v467) / 12
			v456.rumble = math.clamp(v468, 0, 1)
			local v469 = (0.8 + 1.1 * v455) * v456.pitch
			local v470 = p299.throttleGuess
			local v471 = math.max(v470, 0)
			if p299.kit then
				v_u_293(p299, v451, v440, v456.volume, p300)
				if p299.engine.IsPlaying then
					p299.engine:Stop()
				end
			elseif p299.points then
				local v472 = math.clamp(v440, 0, 1)
				p299.load = p299.load + (v472 - p299.load) * v_u_5.alpha(8, p300)
				p299.groupEq.LowGain = v456.low or 0
				p299.groupEq.HighGain = v456.high or 0
				p299.groupDistortion.Enabled = v456.distortion > 0
				p299.groupDistortion.Level = v456.distortion
				v_u_248(p299, v451, p299.load, p299.setVolume * v456.volume * (0.8 + 0.2 * p299.load))
				if p299.engine.IsPlaying then
					p299.engine:Stop()
				end
				if p299.rumble.IsPlaying then
					p299.rumble:Stop()
				end
			else
				p299.engine.PlaybackSpeed = v469
				p299.engine.Volume = (v471 * 0.35 + 0.35 + 0.15 * v455) * v456.volume
				p299.engineDistortion.Enabled = v456.distortion > 0
				p299.engineDistortion.Level = v456.distortion
				p299.engineEq.Enabled = v456.rumble > 0
				p299.engineEq.LowGain = 6 * v456.rumble
				if not p299.engine.IsPlaying then
					p299.engine:Play()
				end
			end
			if p299.points or (p299.kit or v456.rumble <= 0) then
				if p299.rumble.IsPlaying then
					p299.rumble:Stop()
				end
			else
				p299.rumble.PlaybackSpeed = v469 * 0.5
				p299.rumble.Volume = v456.rumble * (v471 * 0.65 + 0.35) * (0.6 + 0.4 * v455)
				local v473 = p299.rumbleDistortion
				local v474 = v456.distortion + 0.25
				v473.Level = math.min(v474, 0.8)
				if not p299.rumble.IsPlaying then
					p299.rumble:Play()
				end
			end
			local v475 = v_u_211
			if not v308 then
				v310 = p299.throttleGuess
			end
			v475(p299, v456, v310, v455)
			for _, v476 in p299.smoke do
				v476.Enabled = true
				local v477 = p299.throttleGuess
				v476.Rate = math.max(v477, 0) * 14 + 4
			end
			if p299.kitSmoke then
				local v478 = math.clamp(v455, 0, 1) * 8200 + 800
				local v479 = math.clamp(v440, 0, 1)
				p299.kitSmoke.Rate = p299.kitSmokeRate * v479
				local v480 = p299.kitSmoke
				local v481
				if v479 > 0.05 then
					v481 = v478 > 3600
				else
					v481 = false
				end
				v480.Enabled = v481
			end
		else
			if p299.engine.IsPlaying then
				p299.engine:Stop()
			end
			if p299.rumble.IsPlaying then
				p299.rumble:Stop()
			end
			v_u_298(p299)
			table.clear(p299.pops)
			for _, v482 in p299.flames do
				v482.light.Enabled = false
			end
			for _, v483 in p299.smoke do
				v483.Enabled = false
			end
			if p299.kitSmoke then
				p299.kitSmoke.Enabled = false
			end
		end
		local v484 = v302:GetAttribute("EngineStartedAt") or 0
		if v484 ~= p299.startedAt then
			p299.startedAt = v484
			if v376 and (v304 and workspace:GetServerTimeNow() - v484 < 2) then
				p299.start:Play()
			end
		end
		local v485 = v302:GetAttribute("HornOn") == true
		if v485 and not p299.horn.IsPlaying then
			p299.horn:Play()
		elseif not v485 and p299.horn.IsPlaying then
			p299.horn:Stop()
		end
	else
		return
	end
end
function v14.setLocalDriver(p487, p488, p489) -- name: setLocalDriver
	-- upvalues: (ref) v_u_16
	if p487 then
		v_u_16 = {
			["model"] = p487,
			["steer"] = p488,
			["throttle"] = p489
		}
	else
		v_u_16 = nil
	end
end
function v14.start() -- name: start
	-- upvalues: (copy) v_u_1, (copy) v_u_5, (copy) v_u_157, (copy) v_u_178, (copy) v_u_4, (copy) v_u_15, (copy) v_u_486
	v_u_1:GetInstanceAddedSignal(v_u_5.TAG):Connect(function(p490)
		-- upvalues: (ref) v_u_157
		task.spawn(v_u_157, p490)
	end)
	v_u_1:GetInstanceRemovedSignal(v_u_5.TAG):Connect(v_u_178)
	for _, v491 in v_u_1:GetTagged(v_u_5.TAG) do
		task.spawn(v_u_157, v491)
	end
	v_u_4:BindToRenderStep("CarVisuals", Enum.RenderPriority.Camera.Value - 1, function(p492)
		-- upvalues: (ref) v_u_15, (ref) v_u_486
		local v493 = workspace.CurrentCamera.CFrame.Position
		for _, v494 in v_u_15 do
			local v495 = v_u_486
			local v496, v497 = pcall(v495, v494, p492, v493)
			if v496 then
				continue
			end
			warn("Car visuals:", v497)
			v_u_15[v494.model] = nil
		end
	end)
end
return v14