-- Path: Players/ygggggg55551/PlayerScripts/MinimapClient
-- Class: LocalScript  true/Enum.RunContext.Legacy
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = require(game:GetService("ReplicatedStorage"):WaitForChild("UiOwn")).Instance
local v2 = game:GetService("Players")
local v3 = game:GetService("ReplicatedStorage")
local v4 = game:GetService("RunService")
local v_u_5 = require(v3:WaitForChild("MapRoads"))
local v_u_6 = require(v3:WaitForChild("RoadGraph"))
local v_u_7 = require(v3:WaitForChild("DeliveryShared"))
local v8 = v3:WaitForChild("GameUI")
local v_u_9 = require(v8:WaitForChild("Theme"))
local v_u_10 = require(v8:WaitForChild("Icons"))
local v_u_11 = require(v8:WaitForChild("Phone"))
local v_u_12 = v2.LocalPlayer
local v_u_13 = v_u_9.isTouch()
local v_u_14 = v_u_13 and 176 or 264
local v_u_15 = v_u_13 and 340 or 560
local v_u_16 = v_u_14
local v17 = Color3.fromRGB(44, 52, 44)
local v18 = Color3.fromRGB(42, 88, 134)
local v19 = Color3.fromRGB(86, 90, 96)
local v20 = {
	["main"] = Color3.fromRGB(138, 142, 150),
	["ring"] = Color3.fromRGB(138, 142, 150),
	["bridge"] = Color3.fromRGB(138, 142, 150),
	["cross"] = Color3.fromRGB(124, 128, 136),
	["side"] = Color3.fromRGB(124, 128, 136),
	["soi"] = Color3.fromRGB(116, 120, 128),
	["hill"] = Color3.fromRGB(128, 122, 112),
	["village"] = Color3.fromRGB(116, 120, 128),
	["alley"] = Color3.fromRGB(100, 104, 110),
	["link"] = Color3.fromRGB(116, 120, 128)
}
local v_u_21 = {
	["ToShop"] = v_u_9.ORANGE,
	["ToHome"] = v_u_9.GREEN_TEXT
}
local v_u_22 = {
	["ToShop"] = "bag",
	["ToHome"] = "pin"
}
local v_u_23 = {
	["ToShop"] = "person",
	["ToHome"] = "pin"
}
local v24 = v_u_9.screen("Minimap", 3, v_u_12:WaitForChild("PlayerGui"))
v24.Enabled = false
local v25 = v_u_9.new
local v26 = "Frame"
local v27 = {
	["Name"] = "Minimap",
	["BackgroundTransparency"] = 1,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil
}
local v28
if v_u_13 then
	v28 = Vector2.new(0, 0)
else
	v28 = Vector2.new(1, 0)
end
v27.AnchorPoint = v28
local v29
if v_u_13 then
	v29 = UDim2.fromOffset(12, 72)
else
	v29 = UDim2.new(1, -v_u_9.EDGE, 0, v_u_9.EDGE)
end
v27.Position = v29
v27.Size = UDim2.fromOffset(v_u_14, v_u_14)
v27.Parent = v24
local v_u_30 = v25(v26, v27)
v_u_9.autoScale(v_u_30)
local v_u_31 = false
v_u_9.new("TextButton", {
	["Name"] = "Tap",
	["Text"] = "",
	["BackgroundTransparency"] = 1,
	["Size"] = nil,
	["ZIndex"] = 8,
	["Parent"] = nil,
	["Size"] = UDim2.fromScale(1, 1),
	["Parent"] = v_u_30
}).Activated:Connect(function()
	-- upvalues: (ref) v_u_31, (ref) v_u_16, (copy) v_u_15, (copy) v_u_14, (copy) v_u_30, (copy) v_u_13, (copy) v_u_9
	v_u_31 = not v_u_31
	local v32
	if v_u_31 then
		v32 = v_u_15
	else
		v32 = v_u_14
	end
	v_u_16 = v32
	v_u_30.Size = UDim2.fromOffset(v_u_16, v_u_16)
	if v_u_31 then
		v_u_30.AnchorPoint = Vector2.new(0.5, 0.5)
		v_u_30.Position = UDim2.fromScale(0.5, 0.5)
	else
		local v33 = v_u_30
		local v34
		if v_u_13 then
			v34 = Vector2.new(0, 0)
		else
			v34 = Vector2.new(1, 0)
		end
		v33.AnchorPoint = v34
		local v35 = v_u_30
		local v36
		if v_u_13 then
			v36 = UDim2.fromOffset(12, 72)
		else
			v36 = UDim2.new(1, -v_u_9.EDGE, 0, v_u_9.EDGE)
		end
		v35.Position = v36
	end
end)
local v37 = v_u_9.new("CanvasGroup", {
	["Name"] = "Map",
	["Size"] = nil,
	["BackgroundColor3"] = nil,
	["BorderSizePixel"] = 0,
	["Parent"] = nil,
	["Size"] = UDim2.fromScale(1, 1),
	["BackgroundColor3"] = v17,
	["Parent"] = v_u_30
})
v_u_9.corner(v37, 12)
local v38 = v_u_9.new("Frame", {
	["Name"] = "Border",
	["BackgroundTransparency"] = 1,
	["Size"] = nil,
	["ZIndex"] = 5,
	["Parent"] = nil,
	["Size"] = UDim2.fromScale(1, 1),
	["Parent"] = v_u_30
})
v_u_9.corner(v38, 12)
v_u_9.border(v38, v_u_9.BORDER, 0.55, 1.5)
local v_u_39 = v_u_9.new("Frame", {
	["Name"] = "Rotator",
	["BackgroundTransparency"] = 1,
	["Size"] = nil,
	["Position"] = nil,
	["Parent"] = nil,
	["Size"] = UDim2.new(),
	["Position"] = UDim2.fromScale(0.5, 0.5),
	["Parent"] = v37
})
local v_u_40 = v_u_9.new("UIScale", {
	["Scale"] = 0.62,
	["Parent"] = nil,
	["Parent"] = v_u_39
})
local v_u_41 = v_u_9.new("Frame", {
	["Name"] = "Mover",
	["BackgroundTransparency"] = 1,
	["Size"] = nil,
	["Parent"] = nil,
	["Size"] = UDim2.new(),
	["Parent"] = v_u_39
})
local v42 = v_u_9.new("Frame", {
	["Name"] = "Water",
	["BackgroundTransparency"] = 1,
	["Size"] = nil,
	["ZIndex"] = 1,
	["Parent"] = nil,
	["Size"] = UDim2.new(),
	["Parent"] = v_u_41
})
local v43 = v_u_9.new("Frame", {
	["Name"] = "Buildings",
	["BackgroundTransparency"] = 1,
	["Size"] = nil,
	["ZIndex"] = 2,
	["Parent"] = nil,
	["Size"] = UDim2.new(),
	["Parent"] = v_u_41
})
local v44 = v_u_9.new("Frame", {
	["Name"] = "Roads",
	["BackgroundTransparency"] = 1,
	["Size"] = nil,
	["ZIndex"] = 3,
	["Parent"] = nil,
	["Size"] = UDim2.new(),
	["Parent"] = v_u_41
})
local v_u_45 = v_u_9.new("Frame", {
	["Name"] = "Route",
	["BackgroundTransparency"] = 1,
	["Size"] = nil,
	["ZIndex"] = 4,
	["Parent"] = nil,
	["Size"] = UDim2.new(),
	["Parent"] = v_u_41
})
local v_u_46 = {}
local v_u_47 = v_u_31
local function v_u_62(p48, p49, p50, p51, p52, p53, p54, p55, p56) -- name: shape
	-- upvalues: (copy) v_u_1, (copy) v_u_46
	local v57 = v_u_1.new("Frame")
	v57.AnchorPoint = Vector2.new(0.5, 0.5)
	v57.Position = UDim2.fromOffset(p49, p50)
	v57.Size = UDim2.fromOffset(p51, p52)
	v57.Rotation = p53
	v57.BackgroundColor3 = p54
	v57.BorderSizePixel = 0
	v57.Visible = false
	if p55 then
		local v58 = v_u_1.new("UICorner")
		v58.CornerRadius = UDim.new(0, p55)
		v58.Parent = v57
	end
	v57.Parent = p48
	if not p56 then
		local v59 = v_u_46
		local v60 = {
			["frame"] = v57,
			["x"] = p49,
			["z"] = p50
		}
		local v61 = p51 * p51 + p52 * p52
		v60.r = math.sqrt(v61) / 2
		table.insert(v59, v60)
	end
	return v57
end
for _, v63 in v_u_5.WATER do
	v_u_62(v42, (v63[1] + v63[3]) / 2, (v63[2] + v63[4]) / 2, v63[3] - v63[1], v63[4] - v63[2], 0, v18)
end
local v64 = v_u_5.BUILDINGS
for v65 = 1, #v64, 5 do
	v_u_62(v43, v64[v65], v64[v65 + 1], v64[v65 + 2], v64[v65 + 3], -v64[v65 + 4], v19, 3)
end
local v66 = v_u_5.NODES
local v_u_67 = v_u_5.EDGES
local v68 = {}
for v69 = 1, #v_u_67, 3 do
	table.insert(v68, v69)
end
table.sort(v68, function(p70, p71)
	-- upvalues: (copy) v_u_5, (copy) v_u_67
	return v_u_5.KINDS[v_u_67[p70 + 2]].half < v_u_5.KINDS[v_u_67[p71 + 2]].half
end)
for _, v72 in v68 do
	local v73 = v_u_5.KINDS[v_u_67[v72 + 2]]
	local v74 = v_u_67[v72]
	local v75 = Vector2.new(v66[v74 * 2 - 1], v66[v74 * 2])
	local v76 = v_u_67[v72 + 1]
	local v77 = Vector2.new(v66[v76 * 2 - 1], v66[v76 * 2])
	local v78 = v73.half
	local v79 = v20[v73.id] or v20.soi
	local v80 = v77 - v75
	local v81 = (v75 + v77) / 2
	local v82 = v81.X
	local v83 = v81.Y
	local v84 = v80.Magnitude + v78 * 2
	local v85 = v78 * 2
	local v86 = v80.Y
	local v87 = v80.X
	local v88 = math.atan2(v86, v87)
	v_u_62(v44, v82, v83, v84, v85, math.deg(v88), v79, v78, nil)
end
local v89 = v_u_9.new("Frame", {
	["Name"] = "Overlay",
	["BackgroundTransparency"] = 1,
	["Size"] = nil,
	["ZIndex"] = 10,
	["Parent"] = nil,
	["Size"] = UDim2.fromScale(1, 1),
	["Parent"] = v37
})
local v_u_90 = v_u_9.new("Frame", {
	["Name"] = "You",
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["BackgroundTransparency"] = 1,
	["ZIndex"] = 12,
	["Parent"] = nil,
	["AnchorPoint"] = Vector2.new(0.5, 0.5),
	["Position"] = UDim2.fromScale(0.5, 0.5),
	["Size"] = UDim2.fromOffset(22, 22),
	["Parent"] = v89
})
for _, v91 in { -1, 1 } do
	local v92 = v_u_9.new("Frame", {
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Rotation"] = nil,
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["ZIndex"] = 12,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0),
		["Position"] = UDim2.fromOffset(11 + v91 * 4, 1),
		["Size"] = UDim2.fromOffset(5, 19),
		["Rotation"] = v91 * -28,
		["BackgroundColor3"] = Color3.new(1, 1, 1),
		["Parent"] = v_u_90
	})
	v_u_9.corner(v92, 2)
	v_u_9.new("UIStroke", {
		["Color"] = nil,
		["Thickness"] = 1.5,
		["Parent"] = nil,
		["Color"] = Color3.fromRGB(20, 20, 22),
		["Parent"] = v92
	})
end
local v_u_93 = v_u_9.text({
	["Name"] = "North",
	["Text"] = "N",
	["FontFace"] = nil,
	["TextSize"] = 13,
	["AnchorPoint"] = nil,
	["Size"] = nil,
	["BackgroundColor3"] = nil,
	["BackgroundTransparency"] = 0.15,
	["ZIndex"] = 11,
	["Parent"] = nil,
	["FontFace"] = v_u_9.FONT_BOLD,
	["AnchorPoint"] = Vector2.new(0.5, 0.5),
	["Size"] = UDim2.fromOffset(18, 18),
	["BackgroundColor3"] = Color3.fromRGB(24, 26, 28),
	["Parent"] = v89
})
v_u_9.corner(v_u_93, 9)
local v_u_94 = v_u_9.new("Frame", {
	["Name"] = "Pin",
	["AnchorPoint"] = nil,
	["Size"] = nil,
	["Visible"] = false,
	["ZIndex"] = 13,
	["Parent"] = nil,
	["AnchorPoint"] = Vector2.new(0.5, 0.5),
	["Size"] = UDim2.fromOffset(26, 26),
	["Parent"] = v89
})
v_u_9.corner(v_u_94, 13)
v_u_9.new("UIStroke", {
	["Color"] = nil,
	["Thickness"] = 2,
	["Parent"] = nil,
	["Color"] = Color3.new(1, 1, 1),
	["Parent"] = v_u_94
})
local v_u_95 = nil
local v_u_96 = v_u_9.text({
	["Name"] = "Distance",
	["Text"] = "",
	["FontFace"] = nil,
	["TextSize"] = 14,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["AutomaticSize"] = nil,
	["BackgroundColor3"] = nil,
	["BackgroundTransparency"] = 0.15,
	["Visible"] = false,
	["ZIndex"] = 13,
	["Parent"] = nil,
	["FontFace"] = v_u_9.FONT_BOLD,
	["AnchorPoint"] = Vector2.new(0.5, 1),
	["Position"] = UDim2.new(0.5, 0, 1, -6),
	["Size"] = UDim2.fromOffset(0, 22),
	["AutomaticSize"] = Enum.AutomaticSize.X,
	["BackgroundColor3"] = Color3.fromRGB(24, 26, 28),
	["Parent"] = v89
})
v_u_9.corner(v_u_96, 6)
v_u_9.padding(v_u_96, 8, 0)
local v_u_97 = nil
local v_u_98 = "Off"
local v_u_99 = nil
local v_u_100 = nil
local v_u_101 = {}
local v_u_102 = nil
local v_u_103 = 0
local v_u_104 = nil
local v_u_105 = (-1 / 0)
local v_u_106 = v_u_1.new("Folder")
v_u_106.Name = "DeliveryMarker"
local v_u_107 = v_u_1.new("Part")
v_u_107.Name = "Column"
v_u_107.Shape = Enum.PartType.Cylinder
v_u_107.Size = Vector3.new(90, 3, 3)
v_u_107.Material = Enum.Material.Neon
v_u_107.Transparency = 0.5
v_u_107.Anchored = true
v_u_107.CanCollide = false
v_u_107.CanQuery = false
v_u_107.CanTouch = false
v_u_107.CastShadow = false
v_u_107.Parent = v_u_106
local v_u_108 = v_u_107:Clone()
v_u_108.Name = "Ring"
local v109 = v_u_7.ARRIVE_RADIUS * 2
local v110 = v_u_7.ARRIVE_RADIUS * 2
v_u_108.Size = Vector3.new(0.2, v109, v110)
v_u_108.Transparency = 0.85
v_u_108.Parent = v_u_106
local v111 = v_u_1.new("BillboardGui")
v111.Name = "Label"
v111.AlwaysOnTop = true
v111.Size = UDim2.fromOffset(240, 54)
v111.StudsOffsetWorldSpace = Vector3.new(0, -31, 0)
v111.LightInfluence = 0
v111.Parent = v_u_107
local v_u_112 = v_u_9.text({
	["FontFace"] = nil,
	["TextSize"] = 20,
	["Size"] = nil,
	["TextStrokeTransparency"] = 0.4,
	["Parent"] = nil,
	["FontFace"] = v_u_9.FONT_BOLD,
	["Size"] = UDim2.new(1, 0, 0, 28),
	["Parent"] = v111
})
local v_u_113 = v_u_9.text({
	["FontFace"] = nil,
	["TextSize"] = 16,
	["Position"] = nil,
	["Size"] = nil,
	["TextStrokeTransparency"] = 0.4,
	["Parent"] = nil,
	["FontFace"] = v_u_9.FONT_BOLD,
	["Position"] = UDim2.fromOffset(0, 28),
	["Size"] = UDim2.new(1, 0, 0, 22),
	["Parent"] = v111
})
local function v_u_134() -- name: drawRoute
	-- upvalues: (copy) v_u_101, (ref) v_u_102, (ref) v_u_104, (copy) v_u_40, (copy) v_u_21, (ref) v_u_98, (copy) v_u_9, (copy) v_u_45, (copy) v_u_62
	for _, v114 in v_u_101 do
		v114:Destroy()
	end
	table.clear(v_u_101)
	if v_u_102 then
		v_u_104 = v_u_40.Scale
		local v115 = 5 / v_u_104 / 2
		local v116 = math.max(1, v115)
		local v117 = v_u_21[v_u_98] or v_u_9.YELLOW
		for v118 = 1, #v_u_102 - 1 do
			local v119 = v_u_45
			local v120 = v_u_102[v118]
			local v121 = v_u_102[v118 + 1]
			local v122 = v121 - v120
			local v123 = (v120 + v121) / 2
			local v124 = v_u_62
			local v125 = v123.X
			local v126 = v123.Y
			local v127 = v122.Magnitude + v116 * 2
			local v128 = v116 * 2
			local v129 = v122.Y
			local v130 = v122.X
			local v131 = math.atan2(v129, v130)
			local v132 = v124(v119, v125, v126, v127, v128, math.deg(v131), v117, v116, true)
			v132.Visible = true
			local v133 = v_u_101
			table.insert(v133, v132)
		end
	end
end
local function v_u_137() -- name: setPinIcon
	-- upvalues: (ref) v_u_95, (ref) v_u_97, (copy) v_u_23, (copy) v_u_22, (copy) v_u_10, (ref) v_u_98, (copy) v_u_94
	if v_u_95 then
		v_u_95:Destroy()
	end
	local v135
	if v_u_97 and v_u_97.kind == "ride" then
		v135 = v_u_23
	else
		v135 = v_u_22
	end
	v_u_95 = v_u_10.make(v135[v_u_98] or "pin", Color3.new(1, 1, 1), 18)
	v_u_95.AnchorPoint = Vector2.new(0.5, 0.5)
	v_u_95.Position = UDim2.fromScale(0.5, 0.5)
	v_u_95.ZIndex = 14
	for _, v136 in v_u_95:GetDescendants() do
		if not v136:IsA("GuiObject") then
			continue
		end
		v136.ZIndex = 14
	end
	v_u_95.Parent = v_u_94
end
local function v146() -- name: readJob
	-- upvalues: (ref) v_u_98, (copy) v_u_12, (ref) v_u_97, (copy) v_u_7, (ref) v_u_99, (ref) v_u_100, (ref) v_u_102, (copy) v_u_11, (ref) v_u_105, (copy) v_u_101, (copy) v_u_21, (copy) v_u_9, (copy) v_u_94, (copy) v_u_137, (copy) v_u_107, (copy) v_u_108, (copy) v_u_112, (copy) v_u_106, (copy) v_u_96
	v_u_98 = v_u_12:GetAttribute("DeliveryState") or "Off"
	v_u_97 = v_u_7.decode(v_u_12:GetAttribute("DeliveryJob"))
	local v138, v139 = v_u_7.target(v_u_98, v_u_97)
	v_u_99 = v138
	v_u_100 = v139
	v_u_102 = nil
	v_u_11.routeLength = nil
	v_u_105 = (-1 / 0)
	for _, v140 in v_u_101 do
		v140:Destroy()
	end
	table.clear(v_u_101)
	if v_u_99 then
		local v141 = v_u_21[v_u_98] or v_u_9.YELLOW
		v_u_94.BackgroundColor3 = v141
		v_u_137()
		v_u_107.Color = v141
		v_u_108.Color = v141
		v_u_107.CFrame = CFrame.new(v_u_99 + Vector3.new(0, 57, 0)) * CFrame.Angles(0, 0, 1.5707963267948966)
		v_u_108.CFrame = CFrame.new(v_u_99 + Vector3.new(0, 0.15, 0)) * CFrame.Angles(0, 0, 1.5707963267948966)
		if v_u_97.kind == "ride" then
			local v142 = v_u_112
			local v143
			if v_u_98 == "ToShop" then
				v143 = ("Pick up %s"):format(v_u_97.customer or "")
			else
				v143 = ("Deliver %s"):format(v_u_100.name or "")
			end
			v142.Text = v143
		else
			local v144 = v_u_112
			local v145
			if v_u_98 == "ToShop" then
				v145 = ("Pick up food: %s"):format(v_u_100.name or "")
			else
				v145 = ("Drop off: %s"):format(v_u_97.customer or "")
			end
			v144.Text = v145
		end
		v_u_112.TextColor3 = v141
		v_u_106.Parent = workspace
	else
		v_u_106.Parent = nil
	end
	v_u_94.Visible = v_u_99 ~= nil
	v_u_96.Visible = v_u_99 ~= nil
end
v_u_12:GetAttributeChangedSignal("DeliveryState"):Connect(v146)
v_u_12:GetAttributeChangedSignal("DeliveryJob"):Connect(v146)
v146()
local v_u_147 = (-1 / 0)
local v_u_148 = 0.62
local v_u_149 = nil
local v_u_150 = nil
local function v_u_158() -- name: fullView
	-- upvalues: (ref) v_u_149, (copy) v_u_46, (ref) v_u_150, (ref) v_u_16
	if not v_u_149 then
		local v151 = Vector2.new((1 / 0), (1 / 0))
		local v152 = Vector2.new((-1 / 0), (-1 / 0))
		for _, v153 in v_u_46 do
			v151 = v151:Min(Vector2.new(v153.x - v153.r, v153.z - v153.r))
			v152 = v152:Max(Vector2.new(v153.x + v153.r, v153.z + v153.r))
		end
		if v151.X > v152.X then
			v151 = Vector2.new(-1000, -1000)
			v152 = Vector2.new(1000, 1000)
		end
		local v154 = (v151.X + v152.X) / 2
		local v155 = (v151.Y + v152.Y) / 2
		v_u_149 = Vector3.new(v154, 0, v155)
		local v156 = v152.X - v151.X
		local v157 = v152.Y - v151.Y
		v_u_150 = math.max(v156, v157)
	end
	return v_u_149, (v_u_16 - 16) / v_u_150
end
v4.RenderStepped:Connect(function(p159)
	-- upvalues: (copy) v_u_12, (ref) v_u_47, (ref) v_u_148, (copy) v_u_158, (copy) v_u_40, (copy) v_u_39, (copy) v_u_41, (copy) v_u_90, (ref) v_u_16, (copy) v_u_93, (ref) v_u_147, (copy) v_u_46, (ref) v_u_99, (ref) v_u_105, (ref) v_u_102, (ref) v_u_103, (copy) v_u_6, (copy) v_u_11, (copy) v_u_134, (ref) v_u_104, (copy) v_u_94, (copy) v_u_7, (copy) v_u_96, (copy) v_u_113
	local v160 = workspace.CurrentCamera
	local v161 = v_u_12.Character
	if v161 then
		v161 = v161:FindFirstChild("HumanoidRootPart")
	end
	if v160 and v161 then
		local v162 = v161.Position
		local v163
		if v_u_47 then
			local v164
			v163, v164 = v_u_158()
			v_u_148 = v164
		else
			local v165 = v161.AssemblyLinearVelocity.X
			local v166 = v161.AssemblyLinearVelocity.Z
			local v167 = Vector3.new(v165, 0, v166).Magnitude / 120
			local v168 = v_u_148
			local v169 = math.clamp(v167, 0, 1) * -0.32 + 0.62 - v_u_148
			local v170 = 1.5 * p159
			v_u_148 = v168 + v169 * math.min(1, v170)
			v163 = v162
		end
		v_u_40.Scale = v_u_148
		local v171 = v160.CFrame.LookVector
		local v172 = Vector2.new(v171.X, v171.Z)
		if v172.Magnitude < 0.001 then
			v172 = Vector2.new(v160.CFrame.UpVector.X, v160.CFrame.UpVector.Z)
		end
		local v173
		if v_u_47 then
			v173 = 3.141592653589793
		else
			local v174 = v172.Y
			local v175 = v172.X
			v173 = -1.5707963267948966 - math.atan2(v174, v175)
		end
		v_u_39.Rotation = math.deg(v173)
		v_u_41.Position = UDim2.fromOffset(-v163.X, -v163.Z)
		local v176 = v161.CFrame.LookVector
		local v177 = v_u_90
		local v178 = v176.Z
		local v179 = v176.X
		local v180 = math.atan2(v178, v179) + v173
		v177.Rotation = math.deg(v180) + 90
		local v181 = Vector2.new(v162.X - v163.X, v162.Z - v163.Z) * v_u_148
		local v182 = math.cos(v173)
		local v183 = math.sin(v173)
		local v184 = Vector2.new(v181.X * v182 - v181.Y * v183, v181.X * v183 + v181.Y * v182)
		v_u_90.Position = UDim2.new(0.5, v184.X, 0.5, v184.Y)
		local v185 = v_u_16 / 2
		local v186 = Vector2.new(0, 1)
		local v187 = math.cos(v173)
		local v188 = math.sin(v173)
		local v189 = Vector2.new(v186.X * v187 - v186.Y * v188, v186.X * v188 + v186.Y * v187) * (v185 - 12)
		v_u_93.Position = UDim2.new(0.5, v189.X, 0.5, v189.Y)
		local v190 = os.clock()
		if v190 - v_u_147 > 0.25 then
			v_u_147 = v190
			local v191 = v185 * 1.45 / v_u_148 + 40
			for _, v192 in v_u_46 do
				local v193 = v192.x - v163.X
				local v194 = v192.z - v163.Z
				local v195 = v193 * v193 + v194 * v194 < (v191 + v192.r) ^ 2
				if v192.frame.Visible == v195 then
					continue
				end
				v192.frame.Visible = v195
			end
		end
		if v_u_99 then
			if v190 - v_u_105 > 1 then
				v_u_105 = v190
				local v196, v197 = v_u_6.route(v162, v_u_99)
				v_u_102 = v196
				v_u_103 = v197
				v_u_11.routeLength = v_u_103
				v_u_134()
			elseif v_u_104 then
				local v198 = v_u_148 / v_u_104 - 1
				if math.abs(v198) > 0.2 then
					v_u_134()
				end
			end
			local v199 = Vector2.new(v_u_99.X - v163.X, v_u_99.Z - v163.Z) * v_u_148
			local v200 = math.cos(v173)
			local v201 = math.sin(v173)
			local v202 = Vector2.new(v199.X * v200 - v199.Y * v201, v199.X * v201 + v199.Y * v200)
			local v203 = v185 - 16
			local v204 = v202.X
			local v205 = math.abs(v204)
			local v206 = v202.Y
			local v207 = math.abs(v206)
			local v208 = math.max(v205, v207)
			if v203 < v208 then
				v202 = v202 * (v203 / v208)
			end
			v_u_94.Position = UDim2.new(0.5, v202.X, 0.5, v202.Y)
			local v209 = v_u_7.distanceText(v_u_103)
			v_u_96.Text = v209
			v_u_113.Text = v209
		end
	end
end)