-- Path: Players/ygggggg55551/PlayerScripts/RaceClient
-- Class: LocalScript  true/Enum.RunContext.Legacy
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = require(game:GetService("ReplicatedStorage"):WaitForChild("NetSeal"))
local v_u_2 = game:GetService("Players")
local v3 = game:GetService("ReplicatedStorage")
local v4 = game:GetService("RunService")
local v_u_5 = game:GetService("TweenService")
local v_u_6 = require(v3:WaitForChild("GameShared"))
local v_u_7 = require(v3:WaitForChild("GameUI"):WaitForChild("Theme"))
local v_u_8 = v_u_2.LocalPlayer
local v_u_9 = v3:WaitForChild(v_u_6.REMOTES):WaitForChild("Duel")
local v10 = {
	{ 1000, "+1K" },
	{ 5000, "+5K" },
	{ 10000, "+10K" },
	{ 2000, "+2K" },
	{ -1000, "-1K" },
	{ -5000, "-5K" },
	{ "max", "MAX" },
	{ 0, "NO BET" }
}
local v_u_11 = Color3.fromRGB(255, 166, 26)
local v_u_12 = Color3.fromRGB(60, 255, 90)
local v_u_13 = Color3.fromRGB(48, 48, 54)
local v14 = v_u_7.screen("DuelRace", 45, v_u_8:WaitForChild("PlayerGui"))
local v_u_15 = v_u_7.new("Frame", {
	["Name"] = "Shade",
	["BackgroundColor3"] = nil,
	["BackgroundTransparency"] = 0.5,
	["BorderSizePixel"] = 0,
	["Size"] = nil,
	["Visible"] = false,
	["Parent"] = nil,
	["BackgroundColor3"] = Color3.fromRGB(4, 6, 12),
	["Size"] = UDim2.fromScale(1, 1),
	["Parent"] = v14
})
local v_u_16 = v_u_7.panel({
	["Name"] = "Panel",
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Visible"] = false,
	["Parent"] = nil,
	["AnchorPoint"] = Vector2.new(0.5, 0.5),
	["Position"] = UDim2.fromScale(0.5, 0.5),
	["Size"] = UDim2.fromOffset(620, 430),
	["Parent"] = v14
})
v_u_16.UICorner.CornerRadius = UDim.new(0, 18)
local v_u_17 = v_u_7.new("UIScale", {
	["Parent"] = v_u_16
})
local v_u_18 = v_u_7.text({
	["Text"] = "1v1 DRAG RACE",
	["FontFace"] = nil,
	["TextSize"] = 24,
	["TextColor3"] = nil,
	["TextXAlignment"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["FontFace"] = v_u_7.FONT_DISPLAY,
	["TextColor3"] = v_u_7.YELLOW,
	["TextXAlignment"] = Enum.TextXAlignment.Left,
	["Position"] = UDim2.fromOffset(18, 10),
	["Size"] = UDim2.fromOffset(330, 28),
	["Parent"] = v_u_16
})
local v_u_19 = v_u_7.text({
	["Text"] = "",
	["FontFace"] = nil,
	["TextSize"] = 15,
	["TextColor3"] = nil,
	["TextXAlignment"] = nil,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["FontFace"] = v_u_7.FONT_BOLD,
	["TextColor3"] = v_u_7.TEXT_DIM,
	["TextXAlignment"] = Enum.TextXAlignment.Right,
	["AnchorPoint"] = Vector2.new(1, 0),
	["Position"] = UDim2.new(1, -92, 0, 15),
	["Size"] = UDim2.fromOffset(240, 20),
	["Parent"] = v_u_16
})
local v_u_20 = v_u_7.text({
	["Text"] = "",
	["FontFace"] = nil,
	["TextSize"] = 20,
	["TextXAlignment"] = nil,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["FontFace"] = v_u_7.FONT_DIGITS,
	["TextXAlignment"] = Enum.TextXAlignment.Right,
	["AnchorPoint"] = Vector2.new(1, 0),
	["Position"] = UDim2.new(1, -18, 0, 12),
	["Size"] = UDim2.fromOffset(70, 26),
	["Parent"] = v_u_16
})
local v_u_21 = v_u_7.new("Frame", {
	["BackgroundColor3"] = nil,
	["BorderSizePixel"] = 0,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["BackgroundColor3"] = Color3.fromRGB(40, 44, 56),
	["Position"] = UDim2.fromOffset(18, 46),
	["Size"] = UDim2.new(1, -36, 0, 4),
	["Parent"] = v_u_16
})
v_u_7.corner(v_u_21, 2)
local v_u_22 = v_u_7.new("Frame", {
	["BackgroundColor3"] = nil,
	["BorderSizePixel"] = 0,
	["Size"] = nil,
	["Parent"] = nil,
	["BackgroundColor3"] = v_u_7.YELLOW,
	["Size"] = UDim2.fromScale(1, 1),
	["Parent"] = v_u_21
})
v_u_7.corner(v_u_22, 2)
local function v27(p23) -- name: card
	-- upvalues: (copy) v_u_7, (copy) v_u_16
	local v24 = v_u_7.new("Frame", {
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.1,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_7.CARD,
		["Position"] = UDim2.fromOffset(p23, 60),
		["Size"] = UDim2.fromOffset(278, 96),
		["Parent"] = v_u_16
	})
	v_u_7.corner(v24, 12)
	local v25 = v_u_7.border(v24, Color3.new(1, 1, 1), 0.85, 1)
	local v26 = v_u_7.new("ImageLabel", {
		["BackgroundColor3"] = Color3.fromRGB(30, 32, 40),
		["Position"] = UDim2.fromOffset(10, 10),
		["Size"] = UDim2.fromOffset(76, 76),
		["Parent"] = v24
	})
	v_u_7.corner(v26, 38)
	return {
		["pic"] = nil,
		["name"] = nil,
		["cash"] = nil,
		["status"] = nil,
		["edge"] = nil,
		["userId"] = nil,
		["pic"] = v26,
		["name"] = v_u_7.text({
			["FontFace"] = nil,
			["TextSize"] = 18,
			["TextXAlignment"] = nil,
			["TextTruncate"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["FontFace"] = v_u_7.FONT_HEAVY,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["TextTruncate"] = Enum.TextTruncate.AtEnd,
			["Position"] = UDim2.fromOffset(96, 10),
			["Size"] = UDim2.fromOffset(174, 22),
			["Parent"] = v24
		}),
		["cash"] = v_u_7.text({
			["FontFace"] = nil,
			["TextSize"] = 14,
			["TextColor3"] = nil,
			["TextXAlignment"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["FontFace"] = v_u_7.FONT_BOLD,
			["TextColor3"] = v_u_7.TEXT_DIM,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["Position"] = UDim2.fromOffset(96, 34),
			["Size"] = UDim2.fromOffset(174, 18),
			["Parent"] = v24
		}),
		["status"] = v_u_7.text({
			["FontFace"] = nil,
			["TextSize"] = 16,
			["TextXAlignment"] = nil,
			["TextTruncate"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["FontFace"] = v_u_7.FONT_HEAVY,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["TextTruncate"] = Enum.TextTruncate.AtEnd,
			["Position"] = UDim2.fromOffset(96, 58),
			["Size"] = UDim2.fromOffset(174, 26),
			["Parent"] = v24
		}),
		["edge"] = v25
	}
end
local v_u_28 = { v27(18), (v27(324)) }
v_u_7.text({
	["Text"] = "VS",
	["FontFace"] = nil,
	["TextSize"] = 22,
	["TextColor3"] = nil,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["FontFace"] = v_u_7.FONT_DISPLAY,
	["TextColor3"] = v_u_7.YELLOW,
	["AnchorPoint"] = Vector2.new(0.5, 0.5),
	["Position"] = UDim2.fromOffset(310, 108),
	["Size"] = UDim2.fromOffset(30, 30),
	["Parent"] = v_u_16
})
local function v29() -- name: body
	-- upvalues: (copy) v_u_7, (copy) v_u_16
	return v_u_7.new("Frame", {
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["Visible"] = false,
		["Parent"] = nil,
		["Position"] = UDim2.fromOffset(0, 166),
		["Size"] = UDim2.new(1, 0, 0, 252),
		["Parent"] = v_u_16
	})
end
local v_u_30 = v29()
v_u_7.text({
	["Text"] = "YOUR BET",
	["FontFace"] = nil,
	["TextSize"] = 14,
	["TextColor3"] = nil,
	["TextXAlignment"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["FontFace"] = v_u_7.FONT_BOLD,
	["TextColor3"] = v_u_7.TEXT_DIM,
	["TextXAlignment"] = Enum.TextXAlignment.Left,
	["Position"] = UDim2.fromOffset(18, 0),
	["Size"] = UDim2.fromOffset(200, 18),
	["Parent"] = v_u_30
})
local v_u_31 = v_u_7.text({
	["Text"] = "",
	["FontFace"] = nil,
	["TextSize"] = 16,
	["TextColor3"] = nil,
	["TextXAlignment"] = nil,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["FontFace"] = v_u_7.FONT_HEAVY,
	["TextColor3"] = v_u_7.YELLOW,
	["TextXAlignment"] = Enum.TextXAlignment.Right,
	["AnchorPoint"] = Vector2.new(1, 0),
	["Position"] = UDim2.new(1, -18, 0, -1),
	["Size"] = UDim2.fromOffset(330, 20),
	["Parent"] = v_u_30
})
local v_u_32 = v_u_7.new("TextBox", {
	["Text"] = "",
	["PlaceholderText"] = "0",
	["ClearTextOnFocus"] = false,
	["FontFace"] = nil,
	["TextSize"] = 26,
	["TextColor3"] = nil,
	["BackgroundColor3"] = nil,
	["BackgroundTransparency"] = 0.1,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["FontFace"] = v_u_7.FONT_DIGITS,
	["TextColor3"] = v_u_7.YELLOW,
	["BackgroundColor3"] = Color3.fromRGB(12, 14, 20),
	["Position"] = UDim2.fromOffset(18, 22),
	["Size"] = UDim2.fromOffset(250, 52),
	["Parent"] = v_u_30
})
v_u_7.corner(v_u_32, 10)
v_u_7.border(v_u_32, v_u_7.YELLOW, 0.6, 1)
local v33 = {}
local v_u_34 = {
	["bet"] = "1 \194\183 BET",
	["pick"] = "2 \194\183 PICK A RIDE",
	["stage"] = "3 \194\183 RACE",
	["race"] = "3 \194\183 RACE",
	["result"] = "RESULT"
}
for v35, v36 in v10 do
	local v37 = (v35 - 1) % 4
	local v38 = (v35 - 1) / 4
	local v39 = math.floor(v38)
	v33[v35] = v_u_7.button({
		["name"] = nil,
		["text"] = nil,
		["grad"] = nil,
		["textSize"] = 15,
		["size"] = nil,
		["position"] = nil,
		["parent"] = nil,
		["name"] = "Chip" .. v35,
		["text"] = v36[2],
		["grad"] = v36[1] == 0 and "green" or "dark",
		["size"] = UDim2.fromOffset(76, 24),
		["position"] = UDim2.fromOffset(284 + v37 * 80, v39 * 28 + 22),
		["parent"] = v_u_30
	})
end
local v_u_40 = v_u_7.text({
	["Text"] = "",
	["FontFace"] = nil,
	["TextSize"] = 17,
	["TextXAlignment"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["FontFace"] = v_u_7.FONT_BOLD,
	["TextXAlignment"] = Enum.TextXAlignment.Left,
	["Position"] = UDim2.fromOffset(18, 90),
	["Size"] = UDim2.fromOffset(300, 30),
	["Parent"] = v_u_30
})
local v_u_41 = v_u_7.button({
	["name"] = "Match",
	["text"] = "Match it",
	["grad"] = "blue",
	["textSize"] = 16,
	["size"] = nil,
	["anchor"] = nil,
	["position"] = nil,
	["parent"] = nil,
	["size"] = UDim2.fromOffset(150, 36),
	["anchor"] = Vector2.new(1, 0),
	["position"] = UDim2.new(1, -18, 0, 87),
	["parent"] = v_u_30
})
local v_u_42 = v_u_7.text({
	["Text"] = "",
	["FontFace"] = nil,
	["TextSize"] = 15,
	["TextColor3"] = nil,
	["TextWrapped"] = true,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["FontFace"] = v_u_7.FONT_BOLD,
	["TextColor3"] = v_u_7.TEXT_DIM,
	["Position"] = UDim2.fromOffset(18, 132),
	["Size"] = UDim2.new(1, -36, 0, 40),
	["Parent"] = v_u_30
})
local v43 = v_u_7.button({
	["name"] = "Cancel",
	["text"] = "Call off",
	["grad"] = "red",
	["textSize"] = 17,
	["size"] = nil,
	["position"] = nil,
	["parent"] = nil,
	["size"] = UDim2.fromOffset(150, 52),
	["position"] = UDim2.fromOffset(18, 190),
	["parent"] = v_u_30
})
local v_u_44 = v_u_7.button({
	["name"] = "Ready",
	["text"] = "READY",
	["grad"] = "gold",
	["textSize"] = 20,
	["size"] = nil,
	["anchor"] = nil,
	["position"] = nil,
	["parent"] = nil,
	["size"] = UDim2.fromOffset(250, 52),
	["anchor"] = Vector2.new(1, 0),
	["position"] = UDim2.new(1, -18, 0, 190),
	["parent"] = v_u_30
})
local v_u_45 = v29()
v_u_7.text({
	["Text"] = "PICK YOUR RIDE",
	["FontFace"] = nil,
	["TextSize"] = 14,
	["TextColor3"] = nil,
	["TextXAlignment"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["FontFace"] = v_u_7.FONT_BOLD,
	["TextColor3"] = v_u_7.TEXT_DIM,
	["TextXAlignment"] = Enum.TextXAlignment.Left,
	["Position"] = UDim2.fromOffset(18, 0),
	["Size"] = UDim2.fromOffset(300, 18),
	["Parent"] = v_u_45
})
local v_u_46 = v_u_7.new("ScrollingFrame", {
	["BackgroundTransparency"] = 1,
	["BorderSizePixel"] = 0,
	["Position"] = nil,
	["Size"] = nil,
	["CanvasSize"] = nil,
	["AutomaticCanvasSize"] = nil,
	["ScrollBarThickness"] = 6,
	["ScrollingDirection"] = nil,
	["Parent"] = nil,
	["Position"] = UDim2.fromOffset(18, 22),
	["Size"] = UDim2.new(1, -36, 0, 186),
	["CanvasSize"] = UDim2.new(),
	["AutomaticCanvasSize"] = Enum.AutomaticSize.Y,
	["ScrollingDirection"] = Enum.ScrollingDirection.Y,
	["Parent"] = v_u_45
})
v_u_7.new("UIGridLayout", {
	["CellSize"] = UDim2.fromOffset(136, 112),
	["CellPadding"] = UDim2.fromOffset(8, 8),
	["SortOrder"] = Enum.SortOrder.LayoutOrder,
	["Parent"] = v_u_46
})
local v_u_47 = v_u_7.text({
	["Text"] = "",
	["FontFace"] = nil,
	["TextSize"] = 15,
	["TextColor3"] = nil,
	["TextXAlignment"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["FontFace"] = v_u_7.FONT_BOLD,
	["TextColor3"] = v_u_7.TEXT_DIM,
	["TextXAlignment"] = Enum.TextXAlignment.Left,
	["Position"] = UDim2.fromOffset(18, 218),
	["Size"] = UDim2.new(1, -36, 0, 24),
	["Parent"] = v_u_45
})
local v_u_48 = Color3.fromRGB(255, 200, 60)
local v_u_49 = Color3.fromRGB(255, 96, 96)
local v_u_50 = Color3.fromRGB(110, 240, 140)
local v_u_51 = v_u_7.new("Frame", {
	["Name"] = "Result",
	["BackgroundTransparency"] = 1,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Visible"] = false,
	["Parent"] = nil,
	["AnchorPoint"] = Vector2.new(0.5, 0.5),
	["Position"] = UDim2.fromScale(0.5, 0.5),
	["Size"] = UDim2.fromOffset(640, 410),
	["Parent"] = v14
})
local v_u_52 = v_u_7.new("UIScale", {
	["Parent"] = v_u_51
})
local v_u_53 = v_u_7.text({
	["Text"] = "",
	["FontFace"] = nil,
	["TextSize"] = 66,
	["TextColor3"] = nil,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["FontFace"] = v_u_7.FONT_DISPLAY,
	["TextColor3"] = Color3.new(1, 1, 1),
	["AnchorPoint"] = Vector2.new(0.5, 0),
	["Position"] = UDim2.new(0.5, 0, 0, 0),
	["Size"] = UDim2.new(1, 0, 0, 78),
	["Parent"] = v_u_51
})
local v_u_54 = v_u_7.new("UIGradient", {
	["Rotation"] = 90,
	["Parent"] = nil,
	["Parent"] = v_u_53
})
v_u_7.new("UIStroke", {
	["Thickness"] = 3,
	["Color"] = nil,
	["Parent"] = nil,
	["Color"] = Color3.fromRGB(16, 10, 4),
	["Parent"] = v_u_53
})
local v_u_55 = v_u_7.new("UIScale", {
	["Parent"] = v_u_53
})
local v_u_56 = v_u_7.text({
	["Text"] = "",
	["FontFace"] = nil,
	["TextSize"] = 16,
	["TextColor3"] = nil,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["FontFace"] = v_u_7.FONT_BOLD,
	["TextColor3"] = v_u_7.TEXT_DIM,
	["AnchorPoint"] = Vector2.new(0.5, 0),
	["Position"] = UDim2.new(0.5, 0, 0, 80),
	["Size"] = UDim2.new(1, 0, 0, 22),
	["Parent"] = v_u_51
})
local function v63(p57) -- name: resultCard
	-- upvalues: (copy) v_u_7, (copy) v_u_51, (copy) v_u_48
	local v58 = v_u_7.new("Frame", {
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.05,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_7.PANEL,
		["Position"] = UDim2.fromOffset(p57, 114),
		["Size"] = UDim2.fromOffset(300, 196),
		["Parent"] = v_u_51
	})
	v_u_7.corner(v58, 18)
	local v59 = v_u_7.border(v58, Color3.new(1, 1, 1), 0.85, 2)
	local v60 = v_u_7.new("ImageLabel", {
		["BackgroundColor3"] = Color3.fromRGB(30, 32, 40),
		["Position"] = UDim2.fromOffset(16, 16),
		["Size"] = UDim2.fromOffset(84, 84),
		["Parent"] = v58
	})
	v_u_7.corner(v60, 42)
	local v61 = v_u_7.text({
		["FontFace"] = nil,
		["TextSize"] = 20,
		["TextXAlignment"] = nil,
		["TextTruncate"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["FontFace"] = v_u_7.FONT_HEAVY,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["TextTruncate"] = Enum.TextTruncate.AtEnd,
		["Position"] = UDim2.fromOffset(112, 20),
		["Size"] = UDim2.fromOffset(176, 26),
		["Parent"] = v58
	})
	local v62 = v_u_7.new("Frame", {
		["BackgroundColor3"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Visible"] = false,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_48,
		["Position"] = UDim2.fromOffset(112, 54),
		["Size"] = UDim2.fromOffset(96, 26),
		["Parent"] = v58
	})
	v_u_7.corner(v62, 13)
	v_u_7.text({
		["Text"] = "\240\159\143\134 WINNER",
		["FontFace"] = nil,
		["TextSize"] = 14,
		["TextColor3"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["FontFace"] = v_u_7.FONT_HEAVY,
		["TextColor3"] = v_u_7.DARK_TEXT,
		["Size"] = UDim2.fromScale(1, 1),
		["Parent"] = v62
	})
	return {
		["frame"] = nil,
		["edge"] = nil,
		["pic"] = nil,
		["name"] = nil,
		["pill"] = nil,
		["lane"] = nil,
		["et"] = nil,
		["kmh"] = nil,
		["userId"] = nil,
		["frame"] = v58,
		["edge"] = v59,
		["pic"] = v60,
		["name"] = v61,
		["pill"] = v62,
		["lane"] = v_u_7.text({
			["FontFace"] = nil,
			["TextSize"] = 14,
			["TextColor3"] = nil,
			["TextXAlignment"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["FontFace"] = v_u_7.FONT_BOLD,
			["TextColor3"] = v_u_7.TEXT_DIM,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["Position"] = UDim2.fromOffset(112, 84),
			["Size"] = UDim2.fromOffset(176, 18),
			["Parent"] = v58
		}),
		["et"] = v_u_7.text({
			["FontFace"] = nil,
			["TextSize"] = 40,
			["TextXAlignment"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["FontFace"] = v_u_7.FONT_DIGITS,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["Position"] = UDim2.fromOffset(18, 114),
			["Size"] = UDim2.fromOffset(264, 46),
			["Parent"] = v58
		}),
		["kmh"] = v_u_7.text({
			["FontFace"] = nil,
			["TextSize"] = 16,
			["TextColor3"] = nil,
			["TextXAlignment"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["FontFace"] = v_u_7.FONT_BOLD,
			["TextColor3"] = v_u_7.TEXT_DIM,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["Position"] = UDim2.fromOffset(18, 162),
			["Size"] = UDim2.fromOffset(264, 22),
			["Parent"] = v58
		})
	}
end
local v_u_64 = { v63(12), (v63(328)) }
local v_u_65 = v_u_7.text({
	["Text"] = "",
	["FontFace"] = nil,
	["TextSize"] = 42,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["FontFace"] = v_u_7.FONT_DISPLAY,
	["AnchorPoint"] = Vector2.new(0.5, 0),
	["Position"] = UDim2.new(0.5, 0, 0, 320),
	["Size"] = UDim2.new(1, 0, 0, 50),
	["Parent"] = v_u_51
})
v_u_7.new("UIStroke", {
	["Thickness"] = 2,
	["Color"] = nil,
	["Transparency"] = 0.3,
	["Parent"] = nil,
	["Color"] = Color3.fromRGB(10, 10, 14),
	["Parent"] = v_u_65
})
local v_u_66 = v_u_7.text({
	["Text"] = "",
	["FontFace"] = nil,
	["TextSize"] = 15,
	["TextColor3"] = nil,
	["TextWrapped"] = true,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["FontFace"] = v_u_7.FONT_BOLD,
	["TextColor3"] = v_u_7.TEXT_DIM,
	["AnchorPoint"] = Vector2.new(0.5, 0),
	["Position"] = UDim2.new(0.5, 0, 0, 374),
	["Size"] = UDim2.new(1, -40, 0, 34),
	["Parent"] = v_u_51
})
local v_u_67 = v_u_7.new("Frame", {
	["Name"] = "Hud",
	["BackgroundTransparency"] = 1,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Visible"] = false,
	["Parent"] = nil,
	["AnchorPoint"] = Vector2.new(0.5, 0),
	["Position"] = UDim2.new(0.5, 0, 0, 64),
	["Size"] = UDim2.fromOffset(300, 132),
	["Parent"] = v14
})
local v_u_68 = v_u_7.new("UIScale", {
	["Parent"] = v_u_67
})
local v69 = v_u_7.new("Frame", {
	["BackgroundColor3"] = nil,
	["BackgroundTransparency"] = 0.15,
	["Size"] = nil,
	["Parent"] = nil,
	["BackgroundColor3"] = Color3.fromRGB(12, 12, 16),
	["Size"] = UDim2.fromOffset(300, 66),
	["Parent"] = v_u_67
})
v_u_7.corner(v69, 16)
v_u_7.border(v69, Color3.new(1, 1, 1), 0.82, 1)
local v_u_70 = {}
for v71 = 1, 4 do
	local v72 = v_u_7.new("Frame", {
		["BackgroundColor3"] = v_u_13,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromOffset((v71 - 1) * 70 + 45, 33),
		["Size"] = UDim2.fromOffset(46, 46),
		["Parent"] = v69
	})
	v_u_7.corner(v72, 23)
	v_u_70[v71] = v72
end
local v_u_73 = v_u_7.text({
	["Text"] = "",
	["FontFace"] = nil,
	["TextSize"] = 34,
	["TextStrokeTransparency"] = 0.4,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["FontFace"] = v_u_7.FONT_DISPLAY,
	["Position"] = UDim2.fromOffset(0, 70),
	["Size"] = UDim2.fromOffset(300, 40),
	["Parent"] = v_u_67
})
local v_u_74 = v_u_7.text({
	["Text"] = "",
	["FontFace"] = nil,
	["TextSize"] = 15,
	["TextStrokeTransparency"] = 0.5,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["FontFace"] = v_u_7.FONT_BOLD,
	["Position"] = UDim2.fromOffset(0, 110),
	["Size"] = UDim2.fromOffset(300, 20),
	["Parent"] = v_u_67
})
local function v86() -- name: fit
	-- upvalues: (copy) v_u_17, (copy) v_u_68, (copy) v_u_52
	local v75 = workspace.CurrentCamera and workspace.CurrentCamera.ViewportSize or Vector2.new(1280, 720)
	local v76 = v_u_17
	local v77 = (v75.Y - 80) / 430
	local v78 = (v75.X - 24) / 620
	local v79 = math.min(v77, v78)
	v76.Scale = math.clamp(v79, 0.45, 1.15)
	local v80 = v_u_68
	local v81 = v75.Y / 720
	v80.Scale = math.clamp(v81, 0.6, 1.1)
	local v82 = v_u_52
	local v83 = (v75.Y - 40) / 410
	local v84 = (v75.X - 24) / 640
	local v85 = math.min(v83, v84)
	v82.Scale = math.clamp(v85, 0.45, 1.15)
end
v86()
workspace:GetPropertyChangedSignal("CurrentCamera"):Connect(v86)
if workspace.CurrentCamera then
	workspace.CurrentCamera:GetPropertyChangedSignal("ViewportSize"):Connect(v86)
end
local v_u_87 = nil
local v_u_88 = 0
local v_u_89 = 1
local v_u_90 = nil
local v_u_91 = {}
local function v_u_93(p92) -- name: money
	-- upvalues: (copy) v_u_6
	return v_u_6.formatCash(p92 or 0)
end
local function v_u_121() -- name: drawCards
	-- upvalues: (ref) v_u_87, (copy) v_u_28, (copy) v_u_6, (copy) v_u_91, (copy) v_u_2, (copy) v_u_7
	for v94, v95 in { v_u_87.racers[v_u_87.me], v_u_87.racers[3 - v_u_87.me] } do
		local v96 = v_u_28[v94]
		local v97 = v96.name
		local v98
		if v94 == 1 then
			v98 = v95.name .. " (you)"
		else
			v98 = v95.name
		end
		v97.Text = v98
		local v99 = v96.cash
		local v100
		if v95.bot then
			v100 = "practice"
		else
			local v101 = v95.cash
			v100 = v_u_6.formatCash(v101 or 0)
		end
		v99.Text = v100
		if v96.userId ~= v95.userId then
			v96.userId = v95.userId
			local v_u_102 = v95.userId
			local v_u_103 = v96.pic
			if v_u_102 and v_u_102 > 0 then
				if v_u_91[v_u_102] then
					v_u_103.Image = v_u_91[v_u_102]
				else
					task.spawn(function()
						-- upvalues: (ref) v_u_2, (copy) v_u_102, (ref) v_u_91, (copy) v_u_103
						local v104 = v_u_2.GetUserThumbnailAsync
						local v105 = v_u_2
						local v106 = v_u_102
						local v107 = Enum.ThumbnailType.HeadShot
						local v108 = Enum.ThumbnailSize.Size150x150
						local v109, v110 = pcall(v104, v105, v106, v107, v108)
						if v109 then
							v_u_91[v_u_102] = v110
							v_u_103.Image = v110
						end
					end)
				end
			else
				v_u_103.Image = ""
			end
		end
		local v111 = v_u_87.state
		if v111 == "bet" then
			local v112 = v96.status
			local v113 = v95.ready and "\226\156\147 " or ""
			local v114 = v95.offer
			v112.Text = v113 .. "Offers " .. v_u_6.formatCash(v114 or 0)
			local v115 = v96.status
			local v116
			if v95.ready then
				v116 = v_u_7.GREEN_TEXT or Color3.fromRGB(110, 240, 140)
			else
				v116 = v_u_7.TEXT
			end
			v115.TextColor3 = v116
		elseif v111 == "pick" then
			v96.status.Text = not v95.picked and "Picking\226\128\166" or "\226\156\147 " .. (v95.car or "Picked")
			local v117 = v96.status
			local v118
			if v95.picked then
				v118 = Color3.fromRGB(110, 240, 140)
			else
				v118 = v_u_7.TEXT_DIM
			end
			v117.TextColor3 = v118
		else
			v96.status.Text = v95.car or ""
			v96.status.TextColor3 = v_u_7.TEXT
		end
		local v119 = v96.edge
		local v120
		if v111 == "bet" and v95.ready or v111 == "pick" and v95.picked then
			v120 = Color3.fromRGB(110, 240, 140)
		else
			v120 = Color3.new(1, 1, 1)
		end
		v119.Color = v120
		v96.edge.Transparency = (v111 == "bet" and v95.ready or v111 == "pick" and v95.picked) and 0.2 or 0.85
	end
end
local function v_u_149() -- name: drawBet
	-- upvalues: (ref) v_u_87, (copy) v_u_32, (copy) v_u_6, (copy) v_u_31, (copy) v_u_40, (copy) v_u_93, (copy) v_u_41, (copy) v_u_7, (copy) v_u_44, (copy) v_u_42
	local v122 = v_u_87.racers[v_u_87.me]
	local v123 = v_u_87.racers[3 - v_u_87.me]
	if not v_u_32:IsFocused() then
		local v124 = v_u_32
		local v125 = v122.offer
		v124.Text = v_u_6.formatCash(v125 or 0)
	end
	local v126 = v_u_87.cap
	if not v126 then
		local v127 = v122.cash
		local v128 = v123.cash
		v126 = math.min(v127, v128)
	end
	v_u_31.Text = "MAX STAKE  " .. v_u_6.formatCash(v126 or 0)
	local v129 = v_u_40
	local v130 = "%s has %s  \194\183  offers %s"
	local v131 = v123.name
	local v132
	if v123.bot then
		v132 = "practice money"
	else
		local v133 = v123.cash
		v132 = v_u_6.formatCash(v133 or 0)
	end
	v129.Text = v130:format(v131, v132, v_u_93(v123.offer))
	v_u_41.Visible = v123.offer ~= v122.offer
	local v134 = v_u_7.setButton
	local v135 = v_u_44
	local v136 = v122.ready and "green" or "gold"
	local v137 = v122.ready and "\226\156\147 READY" or "READY"
	local v138
	if v122.ready then
		v138 = Color3.new(1, 1, 1)
	else
		v138 = v_u_7.DARK_TEXT
	end
	v134(v135, v136, v137, v138)
	if v_u_87.note then
		v_u_42.Text = v_u_87.note
	elseif v122.offer == v123.offer then
		if v122.ready and not v123.ready then
			v_u_42.Text = "Waiting for " .. v123.name .. " to press Ready\226\128\166"
		elseif v126 <= 0 then
			v_u_42.Text = "One of you has no money: a race for fun - press Ready."
		elseif v122.offer == 0 then
			v_u_42.Text = ("A race for nothing - press Ready. Or bet up to %s: the lower balance of you two, at most %s."):format(v_u_6.formatCash(v126 or 0), v_u_93(v_u_87.betMax or 10000))
		else
			local v139 = v_u_42
			local v140 = v122.offer
			v139.Text = ("Both bet %s: the winner takes %s. Leaving the game after this loses your bet."):format(v_u_6.formatCash(v140 or 0), v_u_93(v122.offer * 2))
		end
	else
		v_u_42.Text = "The two offers have to match: change yours or press Match it."
	end
	local v141
	if v_u_87 and v_u_87.cooldownEnds then
		local v142 = v_u_87.cooldownEnds - workspace:GetServerTimeNow()
		v141 = math.max(0, v142)
	else
		v141 = 0
	end
	if v141 > 0 and not v_u_87.note then
		local v143 = v_u_31
		local v144 = v141 // 60
		local v145 = v141 % 60
		v143.Text = ("BET COOLDOWN  %d:%02d"):format(v144, (math.floor(v145)))
		local v146 = v_u_42
		local v147 = v141 // 60
		local v148 = v141 % 60
		v146.Text = ("One money race every 3 minutes (against money pumping): bets open again in %d:%02d. Race for nothing now - or race the bot, no wait."):format(v147, (math.floor(v148)))
	end
end
local function v_u_168() -- name: drawPick
	-- upvalues: (ref) v_u_87, (ref) v_u_90, (copy) v_u_46, (copy) v_u_7, (copy) v_u_6, (copy) v_u_1, (copy) v_u_9, (copy) v_u_47, (copy) v_u_93
	if v_u_87.vehicles and v_u_90 ~= v_u_87.vehicles then
		v_u_90 = v_u_87.vehicles
		for _, v150 in v_u_46:GetChildren() do
			if not v150:IsA("GuiButton") then
				continue
			end
			v150:Destroy()
		end
		for v151, v_u_152 in v_u_87.vehicles do
			local v153 = v_u_7.new("TextButton", {
				["Name"] = nil,
				["Text"] = "",
				["AutoButtonColor"] = false,
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.05,
				["LayoutOrder"] = nil,
				["Parent"] = nil,
				["Name"] = v_u_152.id,
				["BackgroundColor3"] = v_u_7.CARD,
				["LayoutOrder"] = v151,
				["Parent"] = v_u_46
			})
			v_u_7.corner(v153, 10)
			v_u_7.border(v153, Color3.new(1, 1, 1), 0.85, 1).Name = "Edge"
			v_u_7.text({
				["Text"] = nil,
				["FontFace"] = nil,
				["TextSize"] = 14,
				["TextWrapped"] = true,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["Text"] = v_u_152.name,
				["FontFace"] = v_u_7.FONT_HEAVY,
				["AnchorPoint"] = Vector2.new(0, 1),
				["Position"] = UDim2.new(0, 6, 1, -2),
				["Size"] = UDim2.new(1, -12, 0, 34),
				["Parent"] = v153
			})
			local v154 = v_u_6.vehicle(v_u_152.id)
			local v155 = v_u_7.new("ImageLabel", {
				["Name"] = "Picture",
				["BackgroundColor3"] = nil,
				["Image"] = nil,
				["ScaleType"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["BackgroundColor3"] = Color3.fromRGB(40, 44, 56),
				["Image"] = v154 and v154.thumb or "",
				["ScaleType"] = Enum.ScaleType.Fit,
				["Position"] = UDim2.fromOffset(4, 4),
				["Size"] = UDim2.new(1, -8, 0, 70),
				["Parent"] = v153
			})
			v_u_7.corner(v155, 8)
			if v_u_152.fav then
				v_u_7.text({
					["Text"] = "\226\152\133",
					["FontFace"] = nil,
					["TextSize"] = 16,
					["TextColor3"] = nil,
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["Parent"] = nil,
					["FontFace"] = v_u_7.FONT_HEAVY,
					["TextColor3"] = v_u_7.YELLOW,
					["AnchorPoint"] = Vector2.new(1, 0),
					["Position"] = UDim2.new(1, -4, 0, 0),
					["Size"] = UDim2.fromOffset(18, 18),
					["Parent"] = v153
				})
			end
			v153.Activated:Connect(function()
				-- upvalues: (copy) v_u_152, (ref) v_u_1, (ref) v_u_9
				local v156 = v_u_152.id
				v_u_1.fire(v_u_9, "Pick", v156)
			end)
		end
	end
	local v157 = v_u_87.racers[v_u_87.me]
	local v158 = v_u_87.racers[3 - v_u_87.me]
	for _, v159 in v_u_46:GetChildren() do
		if not v159:IsA("GuiButton") then
			continue
		end
		local v160 = v157.picked
		if v160 then
			if v157.car == nil then
				v160 = false
			else
				v160 = v159:FindFirstChildWhichIsA("TextLabel").Text == v157.car
			end
		end
		local v161
		if v160 then
			v161 = Color3.fromRGB(70, 56, 12)
		else
			v161 = v_u_7.CARD
		end
		v159.BackgroundColor3 = v161
		local v162 = v159.Edge
		local v163
		if v160 then
			v163 = v_u_7.YELLOW
		else
			v163 = Color3.new(1, 1, 1)
		end
		v162.Color = v163
		v159.Edge.Transparency = v160 and 0 or 0.85
	end
	local v164 = v_u_87.bet or 0
	local v165 = v_u_47
	local v166 = v164 <= 0 and "" or ("Bets taken: %s each, %s to the winner. "):format(v_u_6.formatCash(v164 or 0), v_u_93(v164 * 2))
	local v167
	if v158.picked then
		v167 = v158.name .. " has picked."
	else
		v167 = v158.name .. " is picking\226\128\166"
	end
	v165.Text = v166 .. v167
end
local v_u_169 = nil
local function v_u_223() -- name: drawResult
	-- upvalues: (ref) v_u_87, (copy) v_u_53, (copy) v_u_54, (copy) v_u_56, (copy) v_u_64, (copy) v_u_91, (copy) v_u_2, (copy) v_u_48, (copy) v_u_7, (copy) v_u_50, (copy) v_u_49, (copy) v_u_65, (copy) v_u_66, (copy) v_u_6, (copy) v_u_93, (ref) v_u_169, (copy) v_u_55, (copy) v_u_5
	local v170 = v_u_87.result or {}
	local v171 = v_u_87.racers[v_u_87.me]
	local v172 = v_u_87.racers[3 - v_u_87.me]
	local v173 = v_u_87.bet or 0
	local v174 = v170.winner == v_u_87.me
	local v175 = v170.winner == 3 - v_u_87.me
	local v176 = v170.winner
	if v176 then
		if v170.winner >= 0 then
			v176 = v_u_87.tree ~= nil
		else
			v176 = false
		end
	end
	if v_u_87.solo and v174 then
		v_u_53.Text = "SOLO RUN"
		v_u_54.Color = ColorSequence.new(Color3.fromRGB(150, 230, 255), Color3.fromRGB(40, 140, 255))
	elseif v174 then
		v_u_53.Text = "VICTORY"
		v_u_54.Color = ColorSequence.new(Color3.fromRGB(255, 244, 140), Color3.fromRGB(255, 150, 20))
	elseif v175 then
		v_u_53.Text = "DEFEAT"
		v_u_54.Color = ColorSequence.new(Color3.fromRGB(255, 150, 150), Color3.fromRGB(214, 36, 48))
	elseif v170.winner == 0 and v170.reason ~= "void" then
		v_u_53.Text = "DRAW"
		v_u_54.Color = ColorSequence.new(Color3.fromRGB(255, 255, 255), Color3.fromRGB(170, 176, 190))
	else
		v_u_53.Text = "CALLED OFF"
		v_u_54.Color = ColorSequence.new(Color3.fromRGB(220, 224, 232), Color3.fromRGB(130, 136, 150))
	end
	local v177 = v_u_87.note or (v170.reason == "finish" and "first past the line at 402 m" or (v170.reason == "solo" and "your time and speed, alone" or (v170.reason ~= "quit" and "" or v172.name .. " left the game")))
	v_u_56.Text = ("ARENA %d  \194\183  402 m%s"):format(v_u_87.track or 1, v177 == "" and "" or "  \194\183  " .. v177)
	for v178, v179 in { v171, v172 } do
		local v180 = v_u_64[v178]
		local v181
		if v178 == 1 then
			v181 = v_u_87.me
		else
			v181 = 3 - v_u_87.me
		end
		local v182 = v170.winner == v181
		local v183 = v180.name
		local v184
		if v178 == 1 then
			v184 = v179.name .. " (you)"
		else
			v184 = v179.name
		end
		v183.Text = v184
		if v180.userId ~= v179.userId then
			v180.userId = v179.userId
			local v_u_185 = v179.userId
			local v_u_186 = v180.pic
			if v_u_185 and v_u_185 > 0 then
				if v_u_91[v_u_185] then
					v_u_186.Image = v_u_91[v_u_185]
				else
					task.spawn(function()
						-- upvalues: (ref) v_u_2, (copy) v_u_185, (ref) v_u_91, (copy) v_u_186
						local v187 = v_u_2.GetUserThumbnailAsync
						local v188 = v_u_2
						local v189 = v_u_185
						local v190 = Enum.ThumbnailType.HeadShot
						local v191 = Enum.ThumbnailSize.Size150x150
						local v192, v193 = pcall(v187, v188, v189, v190, v191)
						if v192 then
							v_u_91[v_u_185] = v193
							v_u_186.Image = v193
						end
					end)
				end
			else
				v_u_186.Image = ""
			end
		end
		v180.lane.Text = ("Lane %d%s"):format(v181, not v179.car and "" or "  \194\183  " .. v179.car)
		local v194 = v180.et
		local v195
		if v179.et then
			v195 = ("%.3f s"):format(v179.et)
		else
			v195 = v176 and v170.reason ~= "void" and "DNF" or "\226\128\148"
		end
		v194.Text = v195
		local v196 = v180.et
		local v197
		if v182 then
			v197 = v_u_48
		else
			v197 = v_u_7.TEXT
		end
		v196.TextColor3 = v197
		local v198 = v180.kmh
		local v199
		if v179.kmh then
			local v200 = v179.kmh + 0.5
			v199 = ("%d km/h at the line"):format((math.floor(v200)))
		else
			v199 = ""
		end
		v198.Text = v199
		v180.pill.Visible = v182
		local v201 = v180.edge
		local v202
		if v182 then
			v202 = v_u_48
		else
			v202 = Color3.new(1, 1, 1)
		end
		v201.Color = v202
		v180.edge.Transparency = v182 and 0 or 0.85
		local v203 = v180.frame
		local v204
		if v182 then
			v204 = Color3.fromRGB(62, 50, 18)
		else
			v204 = v_u_7.PANEL
		end
		v203.BackgroundColor3 = v204
		v180.frame.BackgroundTransparency = v170.winner and (v170.winner > 0 and not v182) and 0.3 or 0.05
	end
	local v205 = 0
	local v_u_206 = ""
	local v207 = v_u_7.TEXT
	if v174 and (v170.amount or 0) > 0 then
		v205 = v170.amount
		v207 = v_u_50
		v_u_206 = "+"
	elseif v175 and v173 > 0 then
		v207 = v_u_49
		v205 = v173
		v_u_206 = "-"
	end
	v_u_65.TextColor3 = v207
	local v208 = v_u_66
	local v209
	if v174 and v173 > 0 then
		local v210 = v_u_6.formatCash(v173 or 0)
		local v211 = (v170.amount or 0) - v173
		local v212 = math.max(0, v211)
		v209 = ("your %s back + %s from %s"):format(v210, v_u_6.formatCash(v212 or 0), v172.name)
	elseif v175 and v173 > 0 then
		v209 = ("%s takes both bets"):format(v172.name)
	else
		v209 = (v170.reason ~= "void" or v173 <= 0) and "" or ("your %s bet is back"):format(v_u_93(v173))
	end
	v208.Text = v209
	if v_u_169 ~= v_u_87.id then
		v_u_169 = v_u_87.id
		v_u_55.Scale = 0.55
		v_u_5:Create(v_u_55, TweenInfo.new(0.45, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
			["Scale"] = 1
		}):Play()
		for v213, v214 in v_u_64 do
			local v215 = v213 == 1 and 12 or 328
			v214.frame.Position = UDim2.fromOffset(v215 + (v213 == 1 and -40 or 40), 114)
			v_u_5:Create(v214.frame, TweenInfo.new(0.35, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
				["Position"] = UDim2.fromOffset(v215, 114)
			}):Play()
		end
		if v205 > 0 then
			local v_u_216 = Instance.new("NumberValue")
			v_u_216.Changed:Connect(function(p217)
				-- upvalues: (ref) v_u_65, (ref) v_u_206, (ref) v_u_6
				local v218 = v_u_65
				local v219 = v_u_206
				local v220 = p217 + 0.5
				local v221 = math.floor(v220)
				v218.Text = v219 .. v_u_6.formatCash(v221 or 0)
			end)
			v_u_65.Text = v_u_206 .. v_u_6.formatCash(0)
			local v222 = v_u_5:Create(v_u_216, TweenInfo.new(1.2, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
				["Value"] = v205
			})
			v222.Completed:Connect(function()
				-- upvalues: (copy) v_u_216
				v_u_216:Destroy()
			end)
			v222:Play()
		end
	end
	if v205 <= 0 then
		v_u_65.Text = v170.winner == 0 and v173 > 0 and "BETS BACK" or (v170.winner == -2 and "YOUR BET BACK" or (v170.winner == -1 and "NOTHING WAS TAKEN" or (v_u_87.solo and "TEST RUN" or (v173 <= 0 and "FOR FUN" or ""))))
		v_u_65.TextColor3 = v_u_7.TEXT_DIM
	end
end
local function v_u_234() -- name: draw
	-- upvalues: (ref) v_u_87, (copy) v_u_15, (copy) v_u_16, (copy) v_u_67, (copy) v_u_51, (copy) v_u_30, (copy) v_u_45, (copy) v_u_19, (copy) v_u_34, (copy) v_u_18, (copy) v_u_21, (copy) v_u_121, (copy) v_u_149, (copy) v_u_168, (copy) v_u_223
	if v_u_87 then
		local v224 = v_u_87.state
		local v225 = v224 == "stage" and true or v224 == "race"
		local v226 = v224 == "result"
		local v227 = v_u_16
		local v228 = not v225
		if v228 then
			v228 = not v226
		end
		v227.Visible = v228
		v_u_15.Visible = v224 == "bet" and true or (v224 == "pick" and true or v226)
		v_u_51.Visible = v226
		v_u_67.Visible = v225
		v_u_30.Visible = v224 == "bet"
		v_u_45.Visible = v224 == "pick"
		v_u_19.Text = v_u_34[v224] or ""
		v_u_18.Text = not v_u_87.track and "1v1 DRAG RACE" or ("ARENA %d \194\183 1v1 DRAG"):format(v_u_87.track)
		local v229 = v_u_21
		local v230
		if v_u_87.deadline == nil then
			v230 = false
		else
			v230 = v224 ~= "result"
		end
		v229.Visible = v230
		v_u_121()
		if v224 == "bet" then
			v_u_149()
			return
		elseif v224 == "pick" then
			v_u_168()
		elseif v224 == "result" then
			v_u_223()
		end
	else
		local v231 = v_u_16
		local v232 = v_u_67
		local v233 = v_u_51
		v_u_15.Visible = false
		v231.Visible = false
		v232.Visible = false
		v233.Visible = false
		return
	end
end
v_u_9.OnClientEvent:Connect(function(p235, p236)
	-- upvalues: (copy) v_u_8, (ref) v_u_87, (ref) v_u_90, (copy) v_u_234, (ref) v_u_88, (ref) v_u_89
	if p235 == "Return" then
		local v237 = v_u_8.Character
		local v238
		if v237 then
			v238 = v237:FindFirstChildOfClass("Humanoid")
		else
			v238 = v237
		end
		if typeof(p236) == "CFrame" and (v238 and not v238.SeatPart) then
			if v238:GetState() == Enum.HumanoidStateType.Physics or v238:GetState() == Enum.HumanoidStateType.Ragdoll then
				v238:ChangeState(Enum.HumanoidStateType.GettingUp)
			end
			v237:PivotTo(p236)
			local v239 = v237:FindFirstChild("HumanoidRootPart")
			if v239 then
				v239.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
			end
		end
		return
	elseif p235 == "Clear" then
		v_u_87 = nil
		v_u_90 = nil
		v_u_234()
		return
	elseif p235 == "State" and type(p236) == "table" then
		if not v_u_87 or (v_u_87.state ~= p236.state or v_u_87.deadline ~= p236.deadline) then
			v_u_88 = workspace:GetServerTimeNow()
			local v240
			if p236.deadline then
				local v241 = p236.deadline - v_u_88
				v240 = math.max(1, v241)
			else
				v240 = 1
			end
			v_u_89 = v240
		end
		v_u_87 = p236
		v_u_234()
	end
end)
local v_u_242 = v_u_89
local v_u_243 = v_u_87
for v244, v_u_245 in v10 do
	v33[v244].Activated:Connect(function()
		-- upvalues: (ref) v_u_243, (copy) v_u_245, (copy) v_u_1, (copy) v_u_9
		if v_u_243 and v_u_243.state == "bet" then
			local v246 = v_u_243.racers[v_u_243.me]
			local v247 = v_u_243.racers[3 - v_u_243.me]
			local v248 = v_u_243.cap
			if not v248 then
				local v249 = v246.cash
				local v250 = v247.cash
				v248 = math.min(v249, v250)
			end
			local v251 = v_u_245[1]
			if v251 == "max" then
				v_u_1.fire(v_u_9, "Offer", v248)
				return
			elseif v251 == 0 then
				v_u_1.fire(v_u_9, "Offer", 0)
			else
				local v252 = v246.offer + v251
				local v253 = math.clamp(v252, 0, v248)
				v_u_1.fire(v_u_9, "Offer", v253)
			end
		else
			return
		end
	end)
end
v_u_32.Focused:Connect(function()
	-- upvalues: (ref) v_u_243, (copy) v_u_32
	if v_u_243 and v_u_243.state == "bet" then
		local v254 = v_u_32
		local v255
		if v_u_243.racers[v_u_243.me].offer > 0 then
			local v256 = v_u_243.racers[v_u_243.me].offer
			v255 = tostring(v256)
		else
			v255 = ""
		end
		v254.Text = v255
	end
end)
v_u_32.FocusLost:Connect(function()
	-- upvalues: (ref) v_u_243, (copy) v_u_32, (copy) v_u_1, (copy) v_u_9, (copy) v_u_6
	if v_u_243 and v_u_243.state == "bet" then
		local v257 = v_u_32.Text:gsub("[^%d]", "")
		local v258 = tonumber(v257) or 0
		local v259 = v_u_243.cap or (1 / 0)
		local v260 = math.min(v258, v259)
		v_u_1.fire(v_u_9, "Offer", v260)
		v_u_32.Text = v_u_6.formatCash(v260 or 0)
	end
end)
v_u_41.Activated:Connect(function()
	-- upvalues: (ref) v_u_243, (copy) v_u_1, (copy) v_u_9
	if v_u_243 and v_u_243.state == "bet" then
		local v261 = v_u_243.racers[3 - v_u_243.me].offer
		v_u_1.fire(v_u_9, "Offer", v261)
	end
end)
v_u_44.Activated:Connect(function()
	-- upvalues: (ref) v_u_243, (copy) v_u_1, (copy) v_u_9
	if v_u_243 and v_u_243.state == "bet" then
		local v262 = not v_u_243.racers[v_u_243.me].ready
		v_u_1.fire(v_u_9, "Ready", v262)
	end
end)
v43.Activated:Connect(function()
	-- upvalues: (ref) v_u_243, (copy) v_u_1, (copy) v_u_9
	if v_u_243 and v_u_243.state == "bet" then
		v_u_1.fire(v_u_9, "Cancel", nil)
	end
end)
v4.RenderStepped:Connect(function()
	-- upvalues: (ref) v_u_243, (copy) v_u_31, (copy) v_u_42, (copy) v_u_6, (copy) v_u_1, (copy) v_u_9, (copy) v_u_20, (copy) v_u_22, (ref) v_u_242, (copy) v_u_7, (copy) v_u_67, (copy) v_u_74, (copy) v_u_73, (copy) v_u_70, (copy) v_u_13, (copy) v_u_11, (copy) v_u_12
	if v_u_243 then
		local v263 = workspace:GetServerTimeNow()
		if v_u_243.state == "bet" and (v_u_243.cooldownEnds and not v_u_243.note) then
			local v264
			if v_u_243 and v_u_243.cooldownEnds then
				local v265 = v_u_243.cooldownEnds - workspace:GetServerTimeNow()
				v264 = math.max(0, v265)
			else
				v264 = 0
			end
			if v264 > 0 then
				local v266 = v_u_31
				local v267 = v264 // 60
				local v268 = v264 % 60
				v266.Text = ("BET COOLDOWN  %d:%02d"):format(v267, (math.floor(v268)))
				local v269 = v_u_42
				local v270 = v264 // 60
				local v271 = v264 % 60
				v269.Text = ("One money race every 3 minutes (against money pumping): bets open again in %d:%02d. Race for nothing now - or race the bot, no wait."):format(v270, (math.floor(v271)))
			elseif v_u_31.Text:find("COOLDOWN") then
				v_u_31.Text = "BETS OPEN AGAIN"
				local v272 = v_u_42
				local v273 = v_u_243.betMax or 10000
				v272.Text = "The wait is over: offer a bet (up to " .. v_u_6.formatCash(v273 or 0) .. ") or race for nothing."
				local v274 = v_u_243.racers[v_u_243.me].offer
				v_u_1.fire(v_u_9, "Offer", v274)
			end
		end
		if v_u_243.deadline then
			local v275 = v_u_243.deadline - v263
			local v276 = math.max(0, v275)
			local v277 = v_u_20
			local v278 = v276 / 60
			local v279 = math.floor(v278)
			local v280 = v276 % 60
			v277.Text = ("%d:%02d"):format(v279, (math.floor(v280)))
			local v281 = v_u_22
			local v282 = UDim2.fromScale
			local v283 = v276 / v_u_242
			v281.Size = v282(math.clamp(v283, 0, 1), 1)
			local v284 = v_u_22
			local v285
			if v276 < 10 then
				v285 = Color3.fromRGB(255, 96, 96)
			else
				v285 = v_u_7.YELLOW
			end
			v284.BackgroundColor3 = v285
		else
			v_u_20.Text = ""
		end
		if v_u_67.Visible then
			local v286 = v_u_243.tree
			local v287 = v_u_243.racers[v_u_243.me]
			v_u_74.Text = ("Arena %d \194\183 Lane %d \194\183 402 m \194\183 vs %s"):format(v_u_243.track or 1, v_u_243.me, v_u_243.racers[3 - v_u_243.me].name)
			if v286 then
				local v288 = v286.green <= v263
				for v289, v290 in { v286.amber1, v286.amber2, v286.amber3 } do
					local v291 = v_u_70[v289]
					local v292
					if v290 <= v263 and not v288 then
						v292 = v_u_11
					else
						v292 = v_u_13
					end
					v291.BackgroundColor3 = v292
				end
				local v293 = v_u_70[4]
				local v294
				if v288 then
					v294 = v_u_12
				else
					v294 = v_u_13
				end
				v293.BackgroundColor3 = v294
				if v287.et then
					v_u_73.Text = ("%.3f s"):format(v287.et)
					v_u_73.TextColor3 = v_u_7.YELLOW
					return
				elseif v288 and v263 - v286.green < 1 then
					v_u_73.Text = "GO!"
					v_u_73.TextColor3 = v_u_12
					return
				elseif v288 then
					v_u_73.Text = ("%.2f"):format(v263 - v286.green)
					v_u_73.TextColor3 = v_u_7.TEXT
				else
					v_u_73.Text = v286.stage <= v263 and "STAGED" or "GET READY"
					v_u_73.TextColor3 = v_u_7.TEXT
				end
			else
				v_u_73.Text = "GET READY"
				v_u_70[1].BackgroundColor3 = v_u_13
				v_u_70[2].BackgroundColor3 = v_u_13
				v_u_70[3].BackgroundColor3 = v_u_13
				v_u_70[4].BackgroundColor3 = v_u_13
				return
			end
		else
			return
		end
	else
		return
	end
end)