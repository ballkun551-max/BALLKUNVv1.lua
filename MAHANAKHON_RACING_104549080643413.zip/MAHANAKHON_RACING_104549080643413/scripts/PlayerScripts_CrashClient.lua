-- Path: Players/ygggggg55551/PlayerScripts/CrashClient
-- Class: LocalScript  true/Enum.RunContext.Legacy
-- Decompiled by BALL KUN Universal Map Dump

local v1 = game:GetService("Players")
local v2 = game:GetService("ReplicatedStorage")
local v3 = game:GetService("RunService")
local v_u_4 = require(v2:WaitForChild("Ragdoll"))
local v_u_5 = require(v2:WaitForChild("VehicleFx"))
local v_u_6 = require(v2:WaitForChild("BumpGuard"))
local v_u_7 = v1.LocalPlayer
local v_u_8 = nil
local function v_u_12(p9) -- name: stopTracks
	local v10 = p9:FindFirstChildOfClass("Animator")
	if v10 then
		for _, v11 in v10:GetPlayingAnimationTracks() do
			v11:Stop(0.1)
		end
	end
end
local function v_u_24(p13) -- name: holdBody
	-- upvalues: (copy) v_u_4
	for _, v14 in p13 do
		if not v14.Parent or v14.Anchored then
			continue
		end
		local v15 = v14.AssemblyLinearVelocity
		local v16 = v15.X
		local v17 = v15.Z
		local v18 = Vector3.new(v16, 0, v17)
		if v18.Magnitude <= v_u_4.LAUNCH_FLAT and v15.Y <= v_u_4.LAUNCH_UP then
			continue
		end
		if v18.Magnitude > v_u_4.LAUNCH_FLAT then
			v18 = v18.Unit * v_u_4.LAUNCH_FLAT
		end
		local v19 = v18.X
		local v20 = v15.Y
		local v21 = v_u_4.LAUNCH_UP
		local v22 = math.min(v20, v21)
		local v23 = v18.Z
		v14.AssemblyLinearVelocity = Vector3.new(v19, v22, v23)
	end
end
local function v_u_40(p_u_25, p_u_26, p27, p28) -- name: setRagdoll
	-- upvalues: (copy) v_u_12, (copy) v_u_4, (copy) v_u_5, (copy) v_u_24
	local v29 = p_u_25:FindFirstChild("HumanoidRootPart")
	v_u_12(p_u_26)
	if p27 then
		p_u_26:SetStateEnabled(Enum.HumanoidStateType.GettingUp, false)
		p_u_26:ChangeState(Enum.HumanoidStateType.Physics)
		for _, v30 in p_u_25:GetDescendants() do
			if not v30:IsA("BasePart") or v30:FindFirstAncestorWhichIsA("Accessory") then
				continue
			end
			if p28[v30] == nil then
				p28[v30] = v30.CanCollide
			end
			v30.CanCollide = v30 ~= v29
		end
		local v31 = v_u_4.capLaunch(p_u_25:GetAttribute(v_u_4.LAUNCH_ATTRIBUTE))
		local v_u_32 = {}
		for _, v33 in p_u_25:GetDescendants() do
			if not v33:IsA("BasePart") then
				continue
			end
			table.insert(v_u_32, v33)
			if v33.Anchored then
				continue
			end
			v33.AssemblyLinearVelocity = v31
		end
		if v29 then
			local v34 = math.random() * 8 - 4
			local v35 = math.random() * 4 - 2
			local v36 = math.random() * 8 - 4
			v29.AssemblyAngularVelocity = Vector3.new(v34, v35, v36)
		end
		v_u_5.shake(1)
		task.spawn(function()
			-- upvalues: (ref) v_u_4, (copy) p_u_25, (copy) p_u_26, (ref) v_u_12, (ref) v_u_24, (copy) v_u_32
			local v37 = os.clock()
			while v_u_4.isRagdolled(p_u_25) and p_u_26.Parent do
				if p_u_26:GetState() ~= Enum.HumanoidStateType.Physics then
					p_u_26:ChangeState(Enum.HumanoidStateType.Physics)
					v_u_12(p_u_26)
				end
				if os.clock() - v37 < v_u_4.KNOCK_HOLD then
					v_u_24(v_u_32)
				end
				task.wait()
			end
		end)
	else
		for v38, v39 in p28 do
			if not v38.Parent then
				continue
			end
			v38.CanCollide = v39
		end
		table.clear(p28)
		p_u_26:SetStateEnabled(Enum.HumanoidStateType.GettingUp, true)
		if v29 then
			v29.AssemblyAngularVelocity = Vector3.new(0, 0, 0)
		end
		p_u_26:ChangeState(Enum.HumanoidStateType.GettingUp)
		task.delay(0.6, function()
			-- upvalues: (copy) p_u_26, (ref) v_u_4, (copy) p_u_25, (ref) v_u_12
			if p_u_26.Parent and not v_u_4.isRagdolled(p_u_25) then
				v_u_12(p_u_26)
				p_u_26:ChangeState(Enum.HumanoidStateType.Running)
			end
		end)
	end
end
local function v48(p_u_41) -- name: onCharacter
	-- upvalues: (ref) v_u_8, (copy) v_u_4, (copy) v_u_40
	if v_u_8 then
		v_u_8:Disconnect()
	end
	local v_u_42 = p_u_41:WaitForChild("Humanoid")
	local v_u_43 = {}
	local v_u_44 = false
	local function v46() -- name: update
		-- upvalues: (ref) v_u_4, (copy) p_u_41, (ref) v_u_44, (ref) v_u_40, (copy) v_u_42, (copy) v_u_43
		local v45 = v_u_4.isRagdolled(p_u_41)
		if v45 ~= v_u_44 then
			v_u_44 = v45
			v_u_40(p_u_41, v_u_42, v45, v_u_43)
		end
	end
	v_u_8 = p_u_41:GetAttributeChangedSignal(v_u_4.ATTRIBUTE):Connect(v46)
	local v47 = v_u_4.isRagdolled(p_u_41)
	if v47 ~= v_u_44 then
		v_u_44 = v47
		v_u_40(p_u_41, v_u_42, v47, v_u_43)
	end
end
if v_u_7.Character then
	task.spawn(v48, v_u_7.Character)
end
v_u_7.CharacterAdded:Connect(v48)
local v_u_49 = nil
local v_u_50 = nil
local v_u_51 = nil
local v_u_52 = RaycastParams.new()
v_u_52.FilterType = Enum.RaycastFilterType.Exclude
local function v_u_56(p53) -- name: onFoot
	local v54 = p53:FindFirstAncestorOfClass("Model")
	while v54 do
		local v55 = v54:FindFirstChildOfClass("Humanoid")
		if v55 then
			return v55.SeatPart == nil
		end
		v54 = v54:FindFirstAncestorOfClass("Model")
	end
	return false
end
v3.Heartbeat:Connect(function(p57)
	-- upvalues: (copy) v_u_7, (copy) v_u_4, (ref) v_u_49, (copy) v_u_6, (ref) v_u_50, (ref) v_u_51, (copy) v_u_24, (copy) v_u_56, (copy) v_u_52, (copy) v_u_12
	local v58 = v_u_7.Character
	local v59
	if v58 then
		v59 = v58:FindFirstChildOfClass("Humanoid")
	else
		v59 = v58
	end
	local v60
	if v58 then
		v60 = v58:FindFirstChild("HumanoidRootPart")
	else
		v60 = v58
	end
	if v59 and (v60 and (v59.Health > 0 and not (v59.SeatPart or v_u_4.isRagdolled(v58)))) then
		if v_u_50 then
			if os.clock() - v_u_50 < 1.2 and (v_u_51[1] and v_u_51[1]:IsDescendantOf(v58)) then
				if v59:GetState() ~= Enum.HumanoidStateType.Physics then
					v59:ChangeState(Enum.HumanoidStateType.Physics)
				end
				v_u_24(v_u_51)
			else
				v_u_50 = nil
				if v_u_49 then
					v_u_6.reset(v_u_49)
				end
				v59:ChangeState(Enum.HumanoidStateType.GettingUp)
			end
		else
			if not v_u_49 or v_u_49.root ~= v60 then
				v_u_49 = v_u_6.new(v60, nil, { v58 })
			end
			local v61
			if v59.UseJumpPower then
				v61 = v59.JumpPower
			else
				local v62 = 2 * workspace.Gravity * v59.JumpHeight
				v61 = math.sqrt(v62)
			end
			v_u_6.step(v_u_49, p57, v59.WalkSpeed + 8, v61 + 10)
			local v63 = v_u_49.hit
			if v63 and (v63.Parent and not v_u_56(v63)) then
				local v64 = v63.AssemblyLinearVelocity
				local v65 = v64 - (v_u_49.v or Vector3.new(0, 0, 0))
				local v66 = v64.X
				local v67 = v64.Z
				if Vector3.new(v66, 0, v67).Magnitude > 22 then
					local v68 = v65.X
					local v69 = v65.Z
					if Vector3.new(v68, 0, v69).Magnitude > 22 then
						v_u_52.FilterDescendantsInstances = { v58 }
						local v70 = workspace:Raycast(v60.Position, Vector3.new(0, -5, 0), v_u_52)
						local v71
						if v70 == nil then
							v71 = false
						else
							v71 = v70.Instance.AssemblyRootPart == v63.AssemblyRootPart
						end
						if not v71 then
							v_u_50 = os.clock()
							v_u_51 = {}
							for _, v72 in v58:GetDescendants() do
								if not v72:IsA("BasePart") then
									continue
								end
								local v73 = v_u_51
								table.insert(v73, v72)
							end
							v_u_12(v59)
							v59:ChangeState(Enum.HumanoidStateType.Physics)
							v_u_24(v_u_51)
						end
					end
				end
			end
			return
		end
	else
		if v_u_49 then
			v_u_6.reset(v_u_49)
		end
		v_u_50 = nil
		return
	end
end)
local v74 = v2:WaitForChild(v_u_5.REMOTE_NAME, 30)
if v74 then
	v74.OnClientEvent:Connect(function(p75, p76, p77, p78)
		-- upvalues: (copy) v_u_5
		if typeof(p76) == "Vector3" then
			if (workspace.CurrentCamera.CFrame.Position - p76).Magnitude > 400 then
				return
			elseif p75 == "Burst" then
				v_u_5.burst(p76, p77, p78)
			elseif p75 == "Thud" then
				v_u_5.thud(p76, p77)
			end
		else
			return
		end
	end)
end