-- Path: ReplicatedStorage/RouteArrows
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = game:GetService("Players")
local v2 = game:GetService("ReplicatedStorage")
local v3 = game:GetService("RunService")
local v4 = require(v2:WaitForChild("MapRoads"))
local v_u_5 = require(v2:WaitForChild("RoadGraph"))
local v_u_6 = require(v2:WaitForChild("DeliveryShared"))
local v_u_7 = {
	["arrived"] = Instance.new("BindableEvent")
}
local v_u_8 = Color3.fromRGB(40, 210, 255)
local v_u_9 = {
	[Enum.Material.Asphalt] = true,
	[Enum.Material.Concrete] = true,
	[Enum.Material.Slate] = true,
	[Enum.Material.Basalt] = true,
	[Enum.Material.Cobblestone] = true
}
local v_u_10 = v_u_1.LocalPlayer
local v11 = v4.NODES
local v12 = v4.EDGES
local v_u_13 = {}
local v_u_14 = nil
local v_u_15 = nil
local v_u_16 = {}
local v_u_17 = 0
local v_u_18 = nil
local v_u_19 = nil
local v_u_20 = {
	6,
	-6,
	12,
	-12,
	18,
	-18,
	26,
	-26,
	34,
	-34,
	44,
	-44
}
local v_u_21 = nil
local v_u_22 = nil
local v_u_23 = nil
local v_u_24 = (-1 / 0)
for v25 = 1, #v12, 3 do
	local v26 = v4.KINDS[v12[v25 + 2]]
	if not v26.gps then
		continue
	end
	local v27 = v12[v25]
	local v28 = v12[v25 + 1]
	local v29 = {
		["a"] = Vector2.new(v11[v27 * 2 - 1], v11[v27 * 2]),
		["b"] = Vector2.new(v11[v28 * 2 - 1], v11[v28 * 2]),
		["half"] = v26.half
	}
	table.insert(v_u_13, v29)
end
local function v_u_41(p30) -- name: laneOffset
	-- upvalues: (copy) v_u_13
	local v31 = (1 / 0)
	local v32 = 0
	for _, v33 in v_u_13 do
		local v34 = v33.b - v33.a
		local v35 = (p30 - v33.a):Dot(v34)
		local v36 = v34:Dot(v34)
		local v37 = v35 / math.max(v36, 1e-6)
		local v38 = math.clamp(v37, 0, 1)
		local v39 = (v33.a + v34 * v38 - p30).Magnitude
		if v39 >= v31 then
			continue
		end
		v32 = v33.half
		v31 = v39
	end
	if v31 > 3 then
		return 0
	end
	local v40 = v32 * 0.45
	return math.min(v40, 30)
end
local function v_u_49(p42, p43, p44) -- name: pointAt
	local v45 = p43[#p43]
	local v46 = math.clamp(p44, 0, v45)
	for v47 = 2, #p42 do
		if v46 > p43[v47] then
			continue
		end
		local v48 = p43[v47] - p43[v47 - 1]
		return p42[v47 - 1]:Lerp(p42[v47], v48 <= 0 and 0 or (v46 - p43[v47 - 1]) / v48)
	end
	return p42[#p42]
end
local v_u_50 = RaycastParams.new()
v_u_50.FilterType = Enum.RaycastFilterType.Exclude
local function v_u_56() -- name: refreshFilter
	-- upvalues: (ref) v_u_22, (copy) v_u_1, (copy) v_u_50
	local v51 = { v_u_22 }
	for _, v52 in v_u_1:GetPlayers() do
		if not v52.Character then
			continue
		end
		local v53 = v52.Character
		table.insert(v51, v53)
	end
	for _, v54 in {
		"SpawnedVehicles",
		"DeliveryMarker",
		"Npcs",
		"NPCs"
	} do
		local v55 = workspace:FindFirstChild(v54)
		if not v55 then
			continue
		end
		table.insert(v51, v55)
	end
	v_u_50.FilterDescendantsInstances = v51
end
local function v_u_62(p57) -- name: arrowAt
	-- upvalues: (copy) v_u_16, (copy) v_u_8
	local v58 = v_u_16[p57]
	if not v58 then
		v58 = {}
		local v59 = Instance.new("Part")
		v59.Name = "Shaft"
		v59.Anchored = true
		v59.CanCollide = false
		v59.CanQuery = false
		v59.CanTouch = false
		v59.CastShadow = false
		v59.Material = Enum.Material.Neon
		v59.Color = v_u_8
		v59.Size = Vector3.new(1.3, 0.14, 14)
		v59.Transparency = 0.3
		v58.shaft = v59
		local v60 = Instance.new("Part")
		v60.Name = "Head"
		v60.Anchored = true
		v60.CanCollide = false
		v60.CanQuery = false
		v60.CanTouch = false
		v60.CastShadow = false
		v60.Material = Enum.Material.Neon
		v60.Color = v_u_8
		v60.Size = Vector3.new(1.3, 0.14, 7)
		v60.Transparency = 0.3
		v58.left = v60
		local v61 = Instance.new("Part")
		v61.Name = "Head"
		v61.Anchored = true
		v61.CanCollide = false
		v61.CanQuery = false
		v61.CanTouch = false
		v61.CastShadow = false
		v61.Material = Enum.Material.Neon
		v61.Color = v_u_8
		v61.Size = Vector3.new(1.3, 0.14, 7)
		v61.Transparency = 0.3
		v58.right = v61
		v_u_16[p57] = v58
	end
	return v58
end
local function v_u_67(p63, p64) -- name: place
	-- upvalues: (ref) v_u_22
	p63.shaft.CFrame = p64
	local v65 = p64 * CFrame.new(0, 0, -7)
	p63.left.CFrame = v65 * CFrame.Angles(0, 0.5585053606381855, 0) * CFrame.new(0, 0, 2.85)
	p63.right.CFrame = v65 * CFrame.Angles(0, -0.5585053606381855, 0) * CFrame.new(0, 0, 2.85)
	if p63.shown ~= true then
		p63.shown = true
		local v66 = v_u_22
		p63.shaft.Parent = v66
		p63.left.Parent = v66
		p63.right.Parent = v66
	end
end
local function v_u_74() -- name: makeColumn
	-- upvalues: (ref) v_u_18, (copy) v_u_8, (ref) v_u_23, (ref) v_u_14
	v_u_18 = Instance.new("Part")
	v_u_18.Name = "Column"
	v_u_18.Shape = Enum.PartType.Cylinder
	v_u_18.Size = Vector3.new(140, 4, 4)
	v_u_18.Material = Enum.Material.Neon
	v_u_18.Color = v_u_8
	v_u_18.Transparency = 0.45
	v_u_18.Anchored = true
	v_u_18.CanCollide = false
	v_u_18.CanQuery = false
	v_u_18.CanTouch = false
	v_u_18.CastShadow = false
	local v_u_68 = Instance.new("BillboardGui")
	v_u_68.Name = "Label"
	v_u_68.AlwaysOnTop = true
	v_u_68.LightInfluence = 0
	v_u_68.Size = UDim2.fromOffset(260, 56)
	v_u_68.StudsOffsetWorldSpace = Vector3.new(0, -54, 0)
	v_u_68.Parent = v_u_18
	local function v73(p69, p70, p71) -- name: text
		-- upvalues: (ref) v_u_8, (copy) v_u_68
		local v72 = Instance.new("TextLabel")
		v72.BackgroundTransparency = 1
		v72.Position = UDim2.fromOffset(0, p69)
		v72.Size = UDim2.new(1, 0, 0, p70)
		v72.FontFace = Font.new("rbxasset://fonts/families/BuilderSans.json", Enum.FontWeight.Bold)
		v72.TextSize = p71
		v72.TextColor3 = v_u_8
		v72.TextStrokeTransparency = 0.4
		v72.Parent = v_u_68
		return v72
	end
	v_u_23 = v73(0, 28, 20)
	v_u_14 = v73(28, 22, 16)
end
local function v_u_119() -- name: lay
	-- upvalues: (copy) v_u_10, (ref) v_u_15, (ref) v_u_21, (copy) v_u_7, (copy) v_u_5, (ref) v_u_19, (copy) v_u_16, (ref) v_u_17, (copy) v_u_56, (copy) v_u_49, (copy) v_u_41, (copy) v_u_50, (copy) v_u_9, (copy) v_u_20, (copy) v_u_67, (copy) v_u_62, (ref) v_u_14, (copy) v_u_6
	local v75 = v_u_10.Character
	if v75 then
		v75 = v75:FindFirstChild("HumanoidRootPart")
	end
	if v75 and v_u_15 then
		local v76 = v75.Position
		if Vector2.new(v76.X - v_u_15.X, v76.Z - v_u_15.Z).Magnitude < 45 then
			local v77 = v_u_21
			v_u_7.set(nil)
			v_u_7.arrived:Fire(v77)
			return
		else
			local v78, v79 = v_u_5.route(v76, v_u_15)
			v_u_19 = v79
			local v80 = {}
			for v81 = 2, #v78 do
				local v82 = v78[v81]
				table.insert(v80, v82)
			end
			if #v80 < 2 then
				for _, v83 in v_u_16 do
					if v83.shown == false then
						continue
					end
					v83.shown = false
					v83.shaft.Parent = nil
					v83.left.Parent = nil
					v83.right.Parent = nil
				end
				v_u_17 = 0
			else
				local v84 = { 0 }
				for v85 = 2, #v80 do
					v84[v85] = v84[v85 - 1] + (v80[v85] - v80[v85 - 1]).Magnitude
				end
				v_u_56()
				local v86 = v76.Y - 2.5
				local v87 = v84[#v80] - 6
				local v88 = math.min(v87, 660)
				local v89 = 18
				local v90 = 0
				while v89 < v88 do
					local v91 = v_u_49(v80, v84, v89)
					local v92 = v_u_49(v80, v84, v89 + 4) - v_u_49(v80, v84, v89 - 4)
					local v93
					if v92.Magnitude > 0.1 then
						v93 = v92.Unit
					else
						v93 = Vector2.new(0, -1)
					end
					local v94 = Vector2.new(v93.Y, -v93.X)
					local v95 = v91 + v94 * v_u_41(v_u_49(v80, v84, v89))
					local v96 = v95.X
					local v97 = v95.Y
					local v98 = workspace
					local v99 = v86 + 30
					local v100 = v98:Raycast(Vector3.new(v96, v99, v97), Vector3.new(0, -110, 0), v_u_50)
					if not v100 or v100.Normal.Y <= 0.6 then
						v100 = nil
					end
					if not (v100 and v_u_9[v100.Material]) then
						v100 = nil
						for _, v101 in v_u_20 do
							local v102 = v95 + v94 * v101
							local v103 = v102.X
							local v104 = v102.Y
							local v105 = workspace
							local v106 = v86 + 30
							local v107 = v105:Raycast(Vector3.new(v103, v106, v104), Vector3.new(0, -110, 0), v_u_50)
							if not v107 or v107.Normal.Y <= 0.6 then
								v107 = nil
							end
							if not (v107 and v_u_9[v107.Material]) then
								continue
							end
							v95 = v102
							v100 = v107
						end
					end
					if v100 then
						v90 = v90 + 1
						v86 = v100.Position.Y
						local v108 = v100.Normal
						local v109 = v95.X
						local v110 = v100.Position.Y + 0.1
						local v111 = v95.Y
						local v112 = Vector3.new(v109, v110, v111)
						local v113 = v93.X
						local v114 = v93.Y
						local v115 = Vector3.new(v113, 0, v114)
						local v116 = (v115 - v108 * v115:Dot(v108)).Unit
						v_u_67(v_u_62(v90), CFrame.lookAt(v112, v112 + v116, v108))
					end
					v89 = v89 + 30
				end
				for v117 = v90 + 1, #v_u_16 do
					local v118 = v_u_16[v117]
					if v118.shown == false then
						continue
					end
					v118.shown = false
					v118.shaft.Parent = nil
					v118.left.Parent = nil
					v118.right.Parent = nil
				end
				v_u_17 = v90
				v_u_14.Text = v_u_6.distanceText(v79)
			end
		end
	else
		return
	end
end
function v_u_7.set(p120, p121) -- name: set
	-- upvalues: (ref) v_u_15, (ref) v_u_21, (ref) v_u_19, (ref) v_u_24, (copy) v_u_16, (ref) v_u_17, (ref) v_u_22, (copy) v_u_74, (ref) v_u_18, (copy) v_u_56, (copy) v_u_50, (ref) v_u_23, (ref) v_u_14
	v_u_15 = p120
	v_u_21 = p121
	v_u_19 = nil
	v_u_24 = (-1 / 0)
	if v_u_15 then
		if not v_u_22 then
			v_u_22 = Instance.new("Folder")
			v_u_22.Name = "RouteArrows"
			v_u_74()
			v_u_18.Parent = v_u_22
		end
		v_u_22.Parent = workspace
		v_u_56()
		local v122 = workspace
		local v123 = v_u_15.X
		local v124 = v_u_15.Z
		local v125 = v122:Raycast(Vector3.new(v123, 600, v124), Vector3.new(0, -900, 0), v_u_50)
		local v126
		if v125 then
			v126 = v125.Position.Y
		else
			v126 = v_u_15.Y
		end
		v_u_18.CFrame = CFrame.new(v_u_15.X, v126 + 14 + 70, v_u_15.Z) * CFrame.Angles(0, 0, 1.5707963267948966)
		v_u_23.Text = p121 or ""
		v_u_14.Text = ""
	else
		for _, v127 in v_u_16 do
			if v127.shown == false then
				continue
			end
			v127.shown = false
			v127.shaft.Parent = nil
			v127.left.Parent = nil
			v127.right.Parent = nil
		end
		v_u_17 = 0
		if v_u_22 then
			v_u_22.Parent = nil
		end
	end
end
function v_u_7.target() -- name: target
	-- upvalues: (ref) v_u_15, (ref) v_u_21
	return v_u_15, v_u_21
end
function v_u_7.length() -- name: length
	-- upvalues: (ref) v_u_15, (ref) v_u_19
	if v_u_15 then
		return v_u_19
	else
		return nil
	end
end
v3.Heartbeat:Connect(function()
	-- upvalues: (ref) v_u_15, (ref) v_u_24, (copy) v_u_119
	if v_u_15 and os.clock() - v_u_24 > 0.5 then
		v_u_24 = os.clock()
		local v128 = v_u_119
		local v129, v130 = pcall(v128)
		if not v129 then
			warn("RouteArrows:", v130)
		end
	end
end)
v3.RenderStepped:Connect(function()
	-- upvalues: (ref) v_u_15, (ref) v_u_17, (copy) v_u_16
	if v_u_15 and v_u_17 ~= 0 then
		local v131 = os.clock()
		for v132 = 1, v_u_17 do
			local v133 = v_u_16[v132]
			local v134 = v131 * 5 - v132 * 0.8
			local v135 = 0.55 - (math.sin(v134) * 0.5 + 0.5) * 0.42
			v133.shaft.Transparency = v135
			v133.left.Transparency = v135
			v133.right.Transparency = v135
		end
	end
end)
return v_u_7