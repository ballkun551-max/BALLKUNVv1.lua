-- Path: Players/ygggggg55551/PlayerScripts/PickupCargoClient
-- Class: LocalScript  true/Enum.RunContext.Legacy
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = require(game:GetService("ReplicatedStorage"):WaitForChild("UiOwn")).Instance
local v2 = game:GetService("Players")
local v3 = game:GetService("ReplicatedStorage")
local v4 = game:GetService("RunService")
local v_u_5 = game:GetService("UserInputService")
local v_u_6 = game:GetService("ContextActionService")
local v_u_7 = game:GetService("GuiService")
local v_u_8 = require(v3:WaitForChild("GameShared"))
local v_u_9 = require(v3:WaitForChild("NetSeal"))
local v10 = v3:WaitForChild("GameUI")
local v_u_11 = require(v10:WaitForChild("Theme"))
local v_u_12 = require(v10:WaitForChild("Icons"))
local v_u_13 = require(v10:WaitForChild("Toast"))
local v_u_14 = v2.LocalPlayer
local v_u_15 = v3:WaitForChild(v_u_8.REMOTES):WaitForChild("PickupCargo")
local v_u_16 = {
	["DMAXMUX"] = {
		["promptAt"] = nil,
		["bed"] = Vector3.new(0, 1.6, 7.4),
		["promptAt"] = CFrame.new(0, 1.6, 10.9)
	}
}
local v_u_17 = v_u_11.YELLOW
local v18 = Color3.fromRGB(255, 120, 190)
local v19 = Color3.fromRGB(255, 150, 40)
local v20 = Color3.fromRGB(90, 180, 255)
local v_u_21 = Color3.fromRGB(14, 18, 26)
local v_u_22 = {
	{
		["key"] = "move",
		["label"] = "\224\185\128\224\184\132\224\184\165\224\184\183\224\185\136\224\184\173\224\184\153\224\184\162\224\185\137\224\184\178\224\184\162",
		["keyCode"] = nil,
		["keyCode"] = Enum.KeyCode.One
	},
	{
		["key"] = "height",
		["label"] = "\224\184\130\224\184\182\224\185\137\224\184\153\224\184\165\224\184\135",
		["keyCode"] = nil,
		["keyCode"] = Enum.KeyCode.Two
	},
	{
		["key"] = "rotate",
		["label"] = "\224\184\171\224\184\161\224\184\184\224\184\153",
		["keyCode"] = nil,
		["keyCode"] = Enum.KeyCode.Three
	},
	{
		["key"] = "tilt",
		["label"] = "\224\185\128\224\184\137\224\184\181\224\184\162\224\184\135",
		["keyCode"] = nil,
		["keyCode"] = Enum.KeyCode.Four
	}
}
local function v_u_29(...) -- name: call
	-- upvalues: (copy) v_u_9, (copy) v_u_15
	local v23 = v_u_9.invoke
	local v24 = v_u_15
	local v25, v26, v27, v28 = pcall(v23, v24, ...)
	if v25 then
		return v26, v27, v28
	else
		return false, "\224\184\165\224\184\173\224\184\135\224\184\173\224\184\181\224\184\129\224\184\132\224\184\163\224\184\177\224\185\137\224\184\135"
	end
end
local v_u_30 = nil
local v_u_31 = nil
local v_u_32 = nil
local v_u_33 = nil
local v_u_34 = "move"
local v_u_35 = v_u_11.screen("CargoMenu", 9, v_u_14:WaitForChild("PlayerGui"))
v_u_35.Enabled = false
local function v_u_43(p36, p37, p38, p39, p40, p41, p42) -- name: bar
	-- upvalues: (copy) v_u_11
	return v_u_11.new("Frame", {
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Rotation"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = p40,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.new(0.5, p41 or 0, 0.5, p42 or 0),
		["Size"] = UDim2.fromOffset(p37, p38),
		["Rotation"] = p39 or 0,
		["Parent"] = p36
	})
end
local function v47(p44) -- name: closeButton
	-- upvalues: (copy) v_u_11, (copy) v_u_12
	local v45 = v_u_11.new("TextButton", {
		["Name"] = "Close",
		["Text"] = "",
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(1, 0),
		["Position"] = UDim2.new(1, 4, 0, -2),
		["Size"] = UDim2.fromOffset(36, 36),
		["Parent"] = p44
	})
	local v46 = v_u_12.make("close", v_u_11.TEXT_DIM, 24)
	v46.AnchorPoint = Vector2.new(0.5, 0.5)
	v46.Position = UDim2.fromScale(0.5, 0.5)
	v46.Parent = v45
	return v45
end
local v_u_48 = v_u_11.panel({
	["Name"] = "Picker",
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Visible"] = false,
	["Parent"] = nil,
	["AnchorPoint"] = Vector2.new(0.5, 0.5),
	["Position"] = UDim2.fromScale(0.5, 0.5),
	["Size"] = UDim2.fromOffset(452, 392),
	["Parent"] = v_u_35
})
v_u_11.autoScale(v_u_48)
v_u_11.padding(v_u_48, 14)
v_u_11.text({
	["Text"] = "\224\185\128\224\184\165\224\184\183\224\184\173\224\184\129\224\184\161\224\184\173\224\185\132\224\184\139\224\184\132\224\185\140\224\184\130\224\184\182\224\185\137\224\184\153\224\184\129\224\184\163\224\184\176\224\184\154\224\184\176",
	["FontFace"] = nil,
	["TextSize"] = 21,
	["TextXAlignment"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["FontFace"] = v_u_11.FONT_HEAVY,
	["TextXAlignment"] = Enum.TextXAlignment.Left,
	["Size"] = UDim2.new(1, -44, 0, 26),
	["Parent"] = v_u_48
})
v_u_11.text({
	["Text"] = "\224\185\129\224\184\149\224\184\176\224\184\163\224\184\185\224\184\155\224\185\128\224\184\158\224\184\183\224\185\136\224\184\173\224\184\162\224\184\129\224\184\130\224\184\182\224\185\137\224\184\153\224\184\171\224\184\165\224\184\177\224\184\135\224\184\129\224\184\163\224\184\176\224\184\154\224\184\176 \224\185\129\224\184\165\224\185\137\224\184\167\224\184\165\224\184\178\224\184\129\224\184\136\224\184\177\224\184\148\224\184\149\224\184\179\224\185\129\224\184\171\224\184\153\224\185\136\224\184\135\224\185\132\224\184\148\224\185\137\224\185\128\224\184\171\224\184\161\224\184\183\224\184\173\224\184\153\224\184\170\224\184\149\224\184\180\224\185\138\224\184\129\224\185\128\224\184\129\224\184\173\224\184\163\224\185\140",
	["TextSize"] = 13,
	["TextColor3"] = nil,
	["TextXAlignment"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["TextColor3"] = v_u_11.TEXT_DIM,
	["TextXAlignment"] = Enum.TextXAlignment.Left,
	["Position"] = UDim2.fromOffset(0, 26),
	["Size"] = UDim2.new(1, -44, 0, 18),
	["Parent"] = v_u_48
})
local v49 = v47(v_u_48)
local v_u_50 = v_u_11.new("ScrollingFrame", {
	["Name"] = "Grid",
	["BackgroundTransparency"] = 1,
	["BorderSizePixel"] = 0,
	["Position"] = nil,
	["Size"] = nil,
	["CanvasSize"] = nil,
	["AutomaticCanvasSize"] = nil,
	["ScrollBarThickness"] = 4,
	["ScrollingDirection"] = nil,
	["Parent"] = nil,
	["Position"] = UDim2.fromOffset(0, 54),
	["Size"] = UDim2.new(1, 0, 1, -54),
	["CanvasSize"] = UDim2.new(),
	["AutomaticCanvasSize"] = Enum.AutomaticSize.Y,
	["ScrollingDirection"] = Enum.ScrollingDirection.Y,
	["Parent"] = v_u_48
})
v_u_11.new("UIGridLayout", {
	["CellSize"] = UDim2.fromOffset(128, 114),
	["CellPadding"] = UDim2.fromOffset(8, 8),
	["SortOrder"] = Enum.SortOrder.LayoutOrder,
	["Parent"] = v_u_50
})
v_u_11.new("UIPadding", {
	["PaddingTop"] = UDim.new(0, 2),
	["PaddingLeft"] = UDim.new(0, 2),
	["Parent"] = v_u_50
})
local v_u_51 = v_u_11.panel({
	["Name"] = "ToolBar",
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Visible"] = false,
	["Parent"] = nil,
	["AnchorPoint"] = Vector2.new(0.5, 1),
	["Position"] = UDim2.new(0.5, 0, 1, -14),
	["Size"] = UDim2.fromOffset(#v_u_22 * 70 + (#v_u_22 - 1) * 4 + 12, 66),
	["Parent"] = v_u_35
})
v_u_11.autoScale(v_u_51)
v_u_11.new("UIPadding", {
	["PaddingLeft"] = UDim.new(0, 6),
	["PaddingRight"] = UDim.new(0, 6),
	["PaddingTop"] = UDim.new(0, 6),
	["PaddingBottom"] = UDim.new(0, 6),
	["Parent"] = v_u_51
})
v_u_11.new("UIListLayout", {
	["FillDirection"] = Enum.FillDirection.Horizontal,
	["Padding"] = UDim.new(0, 4),
	["SortOrder"] = Enum.SortOrder.LayoutOrder,
	["Parent"] = v_u_51
})
local v_u_52 = {}
local function v_u_59(p53) -- name: setTool
	-- upvalues: (ref) v_u_34, (copy) v_u_52, (copy) v_u_11
	v_u_34 = p53
	for v54, v55 in v_u_52 do
		local v56 = v54 == p53
		local v57 = v55.button
		local v58
		if v56 then
			v58 = Color3.fromRGB(70, 60, 30)
		else
			v58 = v_u_11.CARD_DARK
		end
		v57.BackgroundColor3 = v58
		v55.edge.Enabled = v56
	end
end
local v_u_60 = v_u_34
local function v67(p61, p62, p63) -- name: toolIcon
	-- upvalues: (copy) v_u_11, (copy) v_u_43
	local v64 = v_u_11.new("Frame", {
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.new(0.5, 0, 0, 18),
		["Size"] = UDim2.fromOffset(22, 22),
		["Parent"] = p62
	})
	if p61 == "move" then
		v_u_43(v64, 18, 2, 0, p63)
		v_u_43(v64, 18, 2, 90, p63)
		for _, v65 in {
			{ 45, 7.25, -1.75 },
			{ -45, 7.25, 1.75 },
			{ -45, -7.25, -1.75 },
			{ 45, -7.25, 1.75 },
			{ -45, -1.75, -7.25 },
			{ 45, 1.75, -7.25 },
			{ 45, -1.75, 7.25 },
			{ -45, 1.75, 7.25 }
		} do
			v_u_43(v64, 5, 2, v65[1], p63, v65[2], v65[3])
		end
		return v64
	elseif p61 == "height" then
		v_u_43(v64, 20, 2, 0, p63, 0, 9)
		v_u_43(v64, 14, 2, 90, p63, 0, -1)
		v_u_43(v64, 5, 2, -45, p63, -1.75, -6.75)
		v_u_43(v64, 5, 2, 45, p63, 1.75, -6.75)
		v_u_43(v64, 5, 2, 45, p63, -1.75, 4.25)
		v_u_43(v64, 5, 2, -45, p63, 1.75, 4.25)
		return v64
	else
		if p61 ~= "rotate" then
			if p61 == "tilt" then
				v_u_43(v64, 16, 2, 0, p63, 2, -6)
				v_u_43(v64, 16, 2, 0, p63, -2, 6)
				v_u_43(v64, 12.6, 2, 108.4, p63, -8, 0)
				v_u_43(v64, 12.6, 2, 108.4, p63, 8, 0)
			end
			return v64
		end
		local v66 = v_u_11.new("Frame", {
			["BackgroundTransparency"] = 1,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5, 0.5),
			["Size"] = UDim2.fromOffset(16, 16),
			["Parent"] = v64
		})
		v_u_11.corner(v66, 8)
		v_u_11.new("UIStroke", {
			["Color"] = nil,
			["Thickness"] = 2,
			["Parent"] = nil,
			["Color"] = p63,
			["Parent"] = v66
		})
		v_u_43(v64, 5, 2, 45, p63, 2.2, -9.6)
		v_u_43(v64, 5, 2, -45, p63, 2.2, -6.4)
		return v64
	end
end
local v_u_68 = false
local v_u_69 = nil
local v_u_70 = false
local v_u_71 = 0
local v_u_72 = 0
for v73, v_u_74 in v_u_22 do
	local v75 = v_u_11.new("TextButton", {
		["Name"] = nil,
		["Text"] = "",
		["AutoButtonColor"] = true,
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["LayoutOrder"] = nil,
		["Parent"] = nil,
		["Name"] = v_u_74.key,
		["BackgroundColor3"] = v_u_11.CARD_DARK,
		["Size"] = UDim2.fromOffset(70, 54),
		["LayoutOrder"] = v73,
		["Parent"] = v_u_51
	})
	v_u_11.corner(v75, 9)
	local v76 = v_u_11.new("UIStroke", {
		["Color"] = nil,
		["Thickness"] = 1.5,
		["ApplyStrokeMode"] = nil,
		["Parent"] = nil,
		["Color"] = v_u_17,
		["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
		["Parent"] = v75
	})
	v67(v_u_74.key, v75, v_u_11.TEXT)
	v_u_11.text({
		["Text"] = nil,
		["TextSize"] = 11,
		["FontFace"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Text"] = v_u_74.label .. "  " .. v73,
		["FontFace"] = v_u_11.FONT_BOLD,
		["Position"] = UDim2.fromOffset(0, 34),
		["Size"] = UDim2.new(1, 0, 0, 16),
		["Parent"] = v75
	})
	v75.Activated:Connect(function()
		-- upvalues: (copy) v_u_59, (copy) v_u_74
		v_u_59(v_u_74.key)
	end)
	v_u_52[v_u_74.key] = {
		["button"] = v75,
		["edge"] = v76
	}
end
v_u_59("move")
local v_u_77 = v_u_11.panel({
	["Name"] = "Card",
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Visible"] = false,
	["Parent"] = nil,
	["AnchorPoint"] = Vector2.new(1, 0.5),
	["Position"] = UDim2.new(1, -16, 0.5, 0),
	["Size"] = UDim2.fromOffset(252, 268),
	["Parent"] = v_u_35
})
v_u_11.autoScale(v_u_77)
v_u_11.padding(v_u_77, 12)
v_u_11.text({
	["Text"] = "\224\184\154\224\184\163\224\184\163\224\184\151\224\184\184\224\184\129\224\184\161\224\184\173\224\185\132\224\184\139\224\184\132\224\185\140",
	["FontFace"] = nil,
	["TextSize"] = 19,
	["TextXAlignment"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["FontFace"] = v_u_11.FONT_HEAVY,
	["TextXAlignment"] = Enum.TextXAlignment.Left,
	["Size"] = UDim2.new(1, -40, 0, 24),
	["Parent"] = v_u_77
})
local v_u_78 = v_u_11.text({
	["Text"] = "",
	["TextSize"] = 13,
	["TextColor3"] = nil,
	["FontFace"] = nil,
	["TextXAlignment"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["TextColor3"] = v_u_17,
	["FontFace"] = v_u_11.FONT_BOLD,
	["TextXAlignment"] = Enum.TextXAlignment.Left,
	["Position"] = UDim2.fromOffset(0, 24),
	["Size"] = UDim2.new(1, -40, 0, 18),
	["Parent"] = v_u_77
})
local v79 = v47(v_u_77)
local v_u_80 = v_u_11.text({
	["Text"] = "",
	["TextSize"] = 12,
	["TextColor3"] = nil,
	["TextWrapped"] = true,
	["TextXAlignment"] = nil,
	["TextYAlignment"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["TextColor3"] = v_u_11.TEXT_DIM,
	["TextXAlignment"] = Enum.TextXAlignment.Left,
	["TextYAlignment"] = Enum.TextYAlignment.Top,
	["Position"] = UDim2.fromOffset(0, 46),
	["Size"] = UDim2.new(1, 0, 0, 44),
	["Parent"] = v_u_77
})
local function v84(p81, p82) -- name: row
	-- upvalues: (copy) v_u_11, (copy) v_u_77
	local v83 = v_u_11.new("Frame", {
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Position"] = UDim2.fromOffset(0, p81),
		["Size"] = UDim2.new(1, 0, 0, p82),
		["Parent"] = v_u_77
	})
	v_u_11.new("UIListLayout", {
		["FillDirection"] = Enum.FillDirection.Horizontal,
		["Padding"] = UDim.new(0, 6),
		["Parent"] = v83
	})
	return v83
end
local v85 = v84(94, 38)
local v86 = v84(138, 42)
local v87 = v_u_11.button({
	["text"] = "\224\185\128\224\184\155\224\184\165\224\184\181\224\185\136\224\184\162\224\184\153\224\184\132\224\184\177\224\184\153",
	["grad"] = "grey",
	["textSize"] = 14,
	["size"] = nil,
	["parent"] = nil,
	["size"] = UDim2.new(0.5, -3, 1, 0),
	["parent"] = v85
})
local v88 = v_u_11.button({
	["text"] = "\224\184\163\224\184\181\224\185\128\224\184\139\224\185\135\224\184\149",
	["grad"] = "grey",
	["textSize"] = 14,
	["size"] = nil,
	["parent"] = nil,
	["size"] = UDim2.new(0.5, -3, 1, 0),
	["parent"] = v85
})
local v89 = v_u_11.button({
	["text"] = "\224\185\128\224\184\173\224\184\178\224\184\165\224\184\135\224\184\130\224\184\181\224\185\136",
	["grad"] = "green",
	["textSize"] = 15,
	["size"] = nil,
	["parent"] = nil,
	["size"] = UDim2.new(0.5, -3, 1, 0),
	["parent"] = v86
})
local v90 = v_u_11.button({
	["text"] = "\224\185\128\224\184\173\224\184\178\224\184\173\224\184\173\224\184\129",
	["grad"] = "red",
	["textSize"] = 15,
	["size"] = nil,
	["parent"] = nil,
	["size"] = UDim2.new(0.5, -3, 1, 0),
	["parent"] = v86
})
local v91 = v_u_11.button({
	["text"] = "\224\185\128\224\184\170\224\184\163\224\185\135\224\184\136",
	["grad"] = "gold",
	["textSize"] = 16,
	["size"] = nil,
	["position"] = nil,
	["parent"] = nil,
	["size"] = UDim2.new(1, 0, 0, 42),
	["position"] = UDim2.fromOffset(0, 186),
	["parent"] = v_u_77
})
v_u_11.text({
	["Text"] = "\224\184\132\224\184\165\224\184\180\224\184\129\224\184\130\224\184\167\224\184\178\224\184\132\224\185\137\224\184\178\224\184\135/\224\184\165\224\184\178\224\184\129\224\184\153\224\184\180\224\185\137\224\184\167 = \224\184\171\224\184\161\224\184\184\224\184\153\224\184\129\224\184\165\224\185\137\224\184\173\224\184\135 \194\183 \224\184\165\224\185\137\224\184\173\224\185\128\224\184\161\224\184\178\224\184\170\224\185\140 = \224\184\139\224\184\185\224\184\161",
	["TextSize"] = 11,
	["TextColor3"] = nil,
	["TextWrapped"] = true,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["TextColor3"] = v_u_11.TEXT_DIM,
	["Position"] = UDim2.fromOffset(0, 230),
	["Size"] = UDim2.new(1, 0, 0, 16),
	["Parent"] = v_u_77
})
local v_u_92 = v_u_11.new("Frame", {
	["Name"] = "Gizmo",
	["BackgroundTransparency"] = 1,
	["Size"] = nil,
	["Visible"] = false,
	["Parent"] = nil,
	["Size"] = UDim2.fromScale(1, 1),
	["Parent"] = v_u_35
})
local function v98(p93, p94, p95, p96) -- name: knob
	-- upvalues: (copy) v_u_11, (copy) v_u_92
	local v97 = v_u_11.new("TextButton", {
		["Name"] = nil,
		["Text"] = "",
		["AutoButtonColor"] = false,
		["AnchorPoint"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["ZIndex"] = 6,
		["Visible"] = false,
		["Parent"] = nil,
		["Name"] = p93,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Size"] = UDim2.fromOffset(p95, p96 or p95),
		["BackgroundColor3"] = p94,
		["Parent"] = v_u_92
	})
	v_u_11.corner(v97, math.min(p95, p96 or p95) / 2)
	v_u_11.new("UIStroke", {
		["Color"] = nil,
		["Thickness"] = 2,
		["Parent"] = nil,
		["Color"] = Color3.new(1, 1, 1),
		["Parent"] = v97
	})
	return v97
end
local function v105(p99, p100, p101) -- name: chevron
	-- upvalues: (copy) v_u_11, (copy) v_u_43, (copy) v_u_21
	local v102 = v_u_11.new("Frame", {
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Rotation"] = nil,
		["ZIndex"] = 7,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.new(0.5, 0, 0.5, p101 or 0),
		["Size"] = UDim2.fromOffset(16, 16),
		["Rotation"] = p100,
		["Parent"] = p99
	})
	local v103 = v_u_43(v102, 8, 3, 45, v_u_21, 1, -2.6)
	local v104 = v_u_43(v102, 8, 3, -45, v_u_21, 1, 2.6)
	v103.ZIndex = 7
	v104.ZIndex = 7
	return v102
end
local v_u_106 = {}
local function v109(p107) -- name: tag
	-- upvalues: (copy) v_u_11, (copy) v_u_92
	local v108 = v_u_11.text({
		["Text"] = nil,
		["TextSize"] = 12,
		["FontFace"] = nil,
		["AnchorPoint"] = nil,
		["Size"] = nil,
		["BackgroundTransparency"] = 0.2,
		["BackgroundColor3"] = nil,
		["ZIndex"] = 7,
		["Visible"] = false,
		["Parent"] = nil,
		["Text"] = p107,
		["FontFace"] = v_u_11.FONT_BOLD,
		["AnchorPoint"] = Vector2.new(0.5, 0),
		["Size"] = UDim2.fromOffset(150, 22),
		["BackgroundColor3"] = v_u_11.PANEL,
		["Parent"] = v_u_92
	})
	v_u_11.corner(v108, 6)
	return v108
end
local v_u_110 = {
	Vector3.new(1, 0, 0),
	Vector3.new(-1, 0, 0),
	Vector3.new(0, 0, -1),
	Vector3.new(0, 0, 1)
}
for v111 = 1, 4 do
	local v112 = v98("Move" .. v111, v_u_17, 30)
	v_u_106[v111] = {
		["button"] = v112,
		["arrow"] = v105(v112, 0)
	}
end
local v_u_113 = v98("Height", v18, 30, 50)
v105(v_u_113, -90, -11)
v105(v_u_113, 90, 11)
local v_u_114 = v98("HeightPlus", v18, 26)
local v_u_115 = v98("HeightMinus", v18, 26)
v_u_43(v_u_114, 12, 3, 0, v_u_21).ZIndex = 7
v_u_43(v_u_114, 12, 3, 90, v_u_21).ZIndex = 7
v_u_43(v_u_115, 12, 3, 0, v_u_21).ZIndex = 7
local v_u_116 = v109("")
local v_u_117 = v98("Rotate", v19, 30)
local v118 = v_u_11.new("Frame", {
	["BackgroundTransparency"] = 1,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["ZIndex"] = 7,
	["Parent"] = nil,
	["AnchorPoint"] = Vector2.new(0.5, 0.5),
	["Position"] = UDim2.fromScale(0.5, 0.5),
	["Size"] = UDim2.fromOffset(12, 12),
	["Parent"] = v_u_117
})
v_u_11.corner(v118, 6)
v_u_11.new("UIStroke", {
	["Color"] = nil,
	["Thickness"] = 2,
	["Parent"] = nil,
	["Color"] = v_u_21,
	["Parent"] = v118
})
local v_u_119 = v98("RotateLeft", v19, 26)
local v_u_120 = v98("RotateRight", v19, 26)
v105(v_u_119, 180)
v105(v_u_120, 0)
local v_u_121 = v109("")
local v_u_122 = v98("Tilt", v20, 34)
local v123 = v_u_11.new("Frame", {
	["BackgroundColor3"] = nil,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["BorderSizePixel"] = 0,
	["ZIndex"] = 7,
	["Parent"] = nil,
	["BackgroundColor3"] = v_u_21,
	["AnchorPoint"] = Vector2.new(0.5, 0.5),
	["Position"] = UDim2.fromScale(0.5, 0.5),
	["Size"] = UDim2.fromOffset(8, 8),
	["Parent"] = v_u_122
})
v_u_11.corner(v123, 4)
local v_u_124 = {}
for _, v125 in {
	{
		"left",
		180,
		-44,
		0
	},
	{
		"right",
		0,
		44,
		0
	},
	{
		"up",
		-90,
		0,
		-44
	},
	{
		"down",
		90,
		0,
		44
	}
} do
	local v126 = v98("Tilt" .. v125[1], v20, 26)
	v105(v126, v125[2])
	v_u_124[v125[1]] = {
		["button"] = v126,
		["off"] = Vector2.new(v125[3], v125[4])
	}
end
local v_u_127 = v_u_11.new("TextButton", {
	["Name"] = "TiltZero",
	["Text"] = "0",
	["FontFace"] = nil,
	["TextSize"] = 13,
	["TextColor3"] = nil,
	["AutoButtonColor"] = true,
	["AnchorPoint"] = nil,
	["Size"] = nil,
	["BackgroundColor3"] = nil,
	["BorderSizePixel"] = 0,
	["ZIndex"] = 6,
	["Visible"] = false,
	["Parent"] = nil,
	["FontFace"] = v_u_11.FONT_BOLD,
	["TextColor3"] = v_u_21,
	["AnchorPoint"] = Vector2.new(0.5, 0.5),
	["Size"] = UDim2.fromOffset(26, 26),
	["BackgroundColor3"] = Color3.fromRGB(230, 236, 245),
	["Parent"] = v_u_92
})
v_u_11.corner(v_u_127, 13)
local v_u_128 = v109("")
local function v_u_133() -- name: cargoWeld
	-- upvalues: (ref) v_u_30
	local v129 = v_u_30
	if v129 then
		v129 = v_u_30:FindFirstChild("Chassis")
	end
	local v130 = workspace:FindFirstChild("VehicleCargo")
	if not (v129 and v130) then
		return nil
	end
	for _, v131 in v130:GetChildren() do
		local v132 = v131:FindFirstChild("CargoRoot")
		if v132 then
			v132 = v132:FindFirstChild("CargoWeld")
		end
		if not v132 or v132.Part0 ~= v129 then
			continue
		end
		return v132
	end
	return nil
end
local function v_u_151(p134) -- name: clamp
	-- upvalues: (ref) v_u_31
	local v135 = v_u_31
	if v135 then
		v135 = v_u_31.limits
	end
	if not v135 then
		return p134
	end
	local v136 = p134.x
	local v137 = v135.x[1]
	local v138 = v135.x[2]
	p134.x = math.clamp(v136, v137, v138)
	local v139 = p134.y
	local v140 = v135.y[1]
	local v141 = v135.y[2]
	p134.y = math.clamp(v139, v140, v141)
	local v142 = p134.z
	local v143 = v135.z[1]
	local v144 = v135.z[2]
	p134.z = math.clamp(v142, v143, v144)
	p134.yaw = (p134.yaw + 180) % 360 - 180
	local v145 = p134.pitch
	local v146 = v135.pitch[1]
	local v147 = v135.pitch[2]
	p134.pitch = math.clamp(v145, v146, v147)
	local v148 = p134.roll
	local v149 = v135.roll[1]
	local v150 = v135.roll[2]
	p134.roll = math.clamp(v148, v149, v150)
	return p134
end
local function v_u_161(p152) -- name: bedFrame
	-- upvalues: (ref) v_u_31
	local v153 = CFrame.new(p152.x, v_u_31.floor + p152.y, p152.z)
	local v154 = CFrame.Angles
	local v155 = p152.yaw
	local v156 = v153 * v154(0, math.rad(v155), 0)
	local v157 = CFrame.Angles
	local v158 = p152.pitch
	local v159 = math.rad(v158)
	local v160 = p152.roll
	return v156 * v157(v159, 0, (math.rad(v160)))
end
local v_u_162 = nil
local v163 = false
local function v_u_176() -- name: camStart
	-- upvalues: (ref) v_u_30, (copy) v_u_16, (ref) v_u_162
	local v164 = v_u_30
	if v164 then
		v164 = v_u_30:FindFirstChild("Chassis")
	end
	local v165 = v_u_30
	if v165 then
		v165 = v_u_16[v_u_30:GetAttribute("VehicleId")]
	end
	local v166
	if v164 and v165 then
		v166 = v164.CFrame:PointToWorldSpace(v165.bed)
	else
		v166 = nil
		v164 = nil
	end
	local v167 = workspace.CurrentCamera
	if v166 and v167 then
		local v168 = v167.CFrame.Position - v166
		if v168.Magnitude < 6 then
			v168 = v164.CFrame:VectorToWorldSpace(Vector3.new(9, 8, 15))
		end
		local v169 = {}
		local v170 = v168.Magnitude
		v169.dist = math.clamp(v170, 10, 22)
		local v171 = v168.X
		local v172 = v168.Z
		v169.yaw = math.atan2(v171, v172)
		local v173 = v168.Unit.Y
		local v174 = math.clamp(v173, -1, 1)
		local v175 = math.asin(v174)
		v169.pitch = math.clamp(v175, 0.20943951023931956, 1.2217304763960306)
		v_u_162 = v169
		v167.CameraType = Enum.CameraType.Scriptable
	end
end
v4:BindToRenderStep("CargoCamera", Enum.RenderPriority.Camera.Value + 1, function()
	-- upvalues: (ref) v_u_162, (ref) v_u_30, (copy) v_u_16
	if v_u_162 then
		local v177 = v_u_30
		if v177 then
			v177 = v_u_30:FindFirstChild("Chassis")
		end
		local v178 = v_u_30
		if v178 then
			v178 = v_u_16[v_u_30:GetAttribute("VehicleId")]
		end
		local v179
		if v177 and v178 then
			v179 = v177.CFrame:PointToWorldSpace(v178.bed)
		else
			v179 = nil
		end
		local v180 = workspace.CurrentCamera
		if v179 and v180 then
			local v181 = v_u_162.yaw
			local v182 = math.sin(v181)
			local v183 = v_u_162.pitch
			local v184 = v182 * math.cos(v183)
			local v185 = v_u_162.pitch
			local v186 = math.sin(v185)
			local v187 = v_u_162.yaw
			local v188 = math.cos(v187)
			local v189 = v_u_162.pitch
			local v190 = v188 * math.cos(v189)
			local v191 = Vector3.new(v184, v186, v190)
			v180.CFrame = CFrame.lookAt(v179 + v191 * v_u_162.dist, v179)
		end
	end
end)
local function v_u_241() -- name: refreshGizmo
	-- upvalues: (ref) v_u_33, (ref) v_u_162, (copy) v_u_92, (copy) v_u_133, (ref) v_u_69, (ref) v_u_30, (copy) v_u_16, (copy) v_u_7, (copy) v_u_106, (copy) v_u_110, (ref) v_u_60, (copy) v_u_113, (copy) v_u_114, (copy) v_u_115, (copy) v_u_116, (ref) v_u_32, (copy) v_u_117, (copy) v_u_119, (copy) v_u_120, (copy) v_u_121, (copy) v_u_122, (copy) v_u_127, (copy) v_u_128, (copy) v_u_124
	local v192
	if v_u_33 == "place" then
		v192 = v_u_162 ~= nil
	else
		v192 = false
	end
	v_u_92.Visible = v192
	if v192 then
		local v193 = v_u_133()
		if v193 then
			v193 = v193.Part1
		end
		local v194, v195
		if v193 then
			if not v_u_69 then
				local _, v196 = v193.Parent:GetBoundingBox()
				v_u_69 = v196
			end
			v194 = v193.CFrame
			v195 = v_u_69
		else
			v194 = nil
			v195 = nil
		end
		local v197 = v_u_30
		if v197 then
			v197 = v_u_30:FindFirstChild("Chassis")
		end
		local v198 = v_u_30
		if v198 then
			v198 = v_u_16[v_u_30:GetAttribute("VehicleId")]
		end
		if v197 and v198 then
			v197.CFrame:PointToWorldSpace(v198.bed)
		else
			v197 = nil
		end
		if v194 and v197 then
			local v199 = v195.Y
			local v200 = v194.Position + v197.CFrame.UpVector * (v199 / 2)
			local v201, v202 = workspace.CurrentCamera:WorldToViewportPoint(v200)
			local v203 = Vector2.new(v201.X, v201.Y) - v_u_7:GetGuiInset()
			if v202 then
				local v204 = v195.X
				local v205 = v195.Z
				local v206 = math.max(v204, v205) / 2 + 1.1
				for v207, v208 in v_u_106 do
					local v209 = v200 + v197.CFrame:VectorToWorldSpace(v_u_110[v207]) * v206
					local v210, _ = workspace.CurrentCamera:WorldToViewportPoint(v209)
					local v211 = Vector2.new(v210.X, v210.Y) - v_u_7:GetGuiInset()
					local v212 = v211 - v203
					v208.button.Visible = v_u_60 == "move"
					v208.button.Position = UDim2.fromOffset(v211.X, v211.Y)
					local v213 = v208.arrow
					local v214 = v212.Y
					local v215 = v212.X
					local v216 = math.atan2(v214, v215)
					v213.Rotation = math.deg(v216)
				end
				local v217 = v200 + v197.CFrame.RightVector * v206
				local v218, _ = workspace.CurrentCamera:WorldToViewportPoint(v217)
				local v219 = Vector2.new(v218.X, v218.Y) - v_u_7:GetGuiInset()
				local v220 = v200 + v197.CFrame.UpVector * (v199 / 2 + 1.4)
				local v221, _ = workspace.CurrentCamera:WorldToViewportPoint(v220)
				local v222 = Vector2.new(v221.X, v221.Y) - v_u_7:GetGuiInset()
				local v223 = v_u_60 == "height"
				local v224 = v_u_114
				local v225 = v_u_115
				local v226 = v_u_116
				v_u_113.Visible = v223
				v224.Visible = v223
				v225.Visible = v223
				v226.Visible = v223
				v_u_113.Position = UDim2.fromOffset(v219.X, v219.Y)
				v_u_114.Position = UDim2.fromOffset(v219.X, v219.Y - 46)
				v_u_115.Position = UDim2.fromOffset(v219.X, v219.Y + 46)
				v_u_116.Position = UDim2.fromOffset(v219.X, v219.Y + 64)
				v_u_116.Text = ("\224\184\170\224\184\185\224\184\135 %.2f"):format(v_u_32 and v_u_32.y or 0)
				local v227 = v_u_60 == "rotate"
				local v228 = v_u_119
				local v229 = v_u_120
				local v230 = v_u_121
				v_u_117.Visible = v227
				v228.Visible = v227
				v229.Visible = v227
				v230.Visible = v227
				v_u_117.Position = UDim2.fromOffset(v222.X, v222.Y)
				v_u_119.Position = UDim2.fromOffset(v222.X - 44, v222.Y)
				v_u_120.Position = UDim2.fromOffset(v222.X + 44, v222.Y)
				v_u_121.Position = UDim2.fromOffset(v222.X, v222.Y + 20)
				local v231 = v_u_121
				local v232 = v_u_32 and v_u_32.yaw or 0
				v231.Text = ("\224\184\171\224\184\161\224\184\184\224\184\153 %d\194\176 \194\183 \224\184\165\224\184\178\224\184\129\224\184\139\224\185\137\224\184\178\224\184\162\224\184\130\224\184\167\224\184\178"):format((math.round(v232)))
				local v233 = v_u_60 == "tilt"
				local v234 = v_u_127
				local v235 = v_u_128
				v_u_122.Visible = v233
				v234.Visible = v233
				v235.Visible = v233
				v_u_122.Position = UDim2.fromOffset(v222.X, v222.Y)
				for _, v236 in v_u_124 do
					v236.button.Visible = v233
					v236.button.Position = UDim2.fromOffset(v222.X + v236.off.X, v222.Y + v236.off.Y)
				end
				v_u_127.Position = UDim2.fromOffset(v222.X + 44, v222.Y + 44)
				v_u_128.Position = UDim2.fromOffset(v222.X, v222.Y + 62)
				local v237 = v_u_128
				local v238 = v_u_32 and -v_u_32.roll or 0
				local v239 = math.round(v238)
				local v240 = v_u_32 and v_u_32.pitch or 0
				v237.Text = ("\224\185\128\224\184\173\224\184\181\224\184\162\224\184\135 %d\194\176 \194\183 \224\185\128\224\184\135\224\184\162 %d\194\176"):format(v239, (math.round(v240)))
			else
				v_u_92.Visible = false
			end
		else
			v_u_92.Visible = false
			return
		end
	else
		return
	end
end
local v_u_242 = v_u_162
local v_u_243 = v163
local v_u_244 = nil
local function v_u_247(p245) -- name: pointer
	-- upvalues: (copy) v_u_5, (copy) v_u_7
	if p245 and p245.UserInputType == Enum.UserInputType.Touch then
		return Vector2.new(p245.Position.X, p245.Position.Y)
	end
	local v246 = v_u_5:GetMouseLocation()
	return Vector2.new(v246.X, v246.Y) - v_u_7:GetGuiInset()
end
for v_u_248, v249 in v_u_106 do
	local function v_u_266(p250)
		-- upvalues: (copy) v_u_133, (ref) v_u_69, (ref) v_u_30, (copy) v_u_16, (ref) v_u_32, (copy) v_u_7, (copy) v_u_110, (copy) v_u_248, (ref) v_u_244, (copy) v_u_247
		local v251 = v_u_133()
		if v251 then
			v251 = v251.Part1
		end
		local v252, v253
		if v251 then
			if not v_u_69 then
				local _, v254 = v251.Parent:GetBoundingBox()
				v_u_69 = v254
			end
			v252 = v251.CFrame
			v253 = v_u_69
		else
			v252 = nil
			v253 = nil
		end
		local v255 = v_u_30
		if v255 then
			v255 = v_u_30:FindFirstChild("Chassis")
		end
		local v256 = v_u_30
		if v256 then
			v256 = v_u_16[v_u_30:GetAttribute("VehicleId")]
		end
		if v255 and v256 then
			v255.CFrame:PointToWorldSpace(v256.bed)
		else
			v255 = nil
		end
		if v252 and (v255 and v_u_32) then
			local v257 = v252.Position + v255.CFrame.UpVector * (v253.Y / 2)
			local v258, _ = workspace.CurrentCamera:WorldToViewportPoint(v257)
			local v259 = Vector2.new(v258.X, v258.Y) - v_u_7:GetGuiInset()
			local v260 = v257 + v255.CFrame:VectorToWorldSpace(v_u_110[v_u_248])
			local v261, _ = workspace.CurrentCamera:WorldToViewportPoint(v260)
			local v262 = Vector2.new(v261.X, v261.Y) - v_u_7:GetGuiInset() - v259
			local v263 = {
				["kind"] = "move",
				["input"] = nil,
				["from"] = nil,
				["o0"] = nil,
				["dir"] = nil,
				["sdir"] = nil,
				["pps"] = nil,
				["input"] = p250,
				["from"] = v_u_247(p250),
				["o0"] = table.clone(v_u_32),
				["dir"] = v_u_110[v_u_248]
			}
			local v264
			if v262.Magnitude > 0.001 then
				v264 = v262.Unit
			else
				v264 = Vector2.xAxis
			end
			v263.sdir = v264
			local v265 = v262.Magnitude
			v263.pps = math.max(v265, 4)
			v_u_244 = v263
		end
	end
	v249.button.InputBegan:Connect(function(p267)
		-- upvalues: (ref) v_u_33, (copy) v_u_266
		if v_u_33 == "place" and (p267.UserInputType == Enum.UserInputType.MouseButton1 or p267.UserInputType == Enum.UserInputType.Touch) then
			v_u_266(p267)
		end
	end)
end
local function v_u_269(p268)
	-- upvalues: (ref) v_u_32, (ref) v_u_244, (copy) v_u_247
	if v_u_32 then
		v_u_244 = {
			["kind"] = "height",
			["input"] = nil,
			["from"] = nil,
			["o0"] = nil,
			["input"] = p268,
			["from"] = v_u_247(p268),
			["o0"] = table.clone(v_u_32)
		}
	end
end
v_u_113.InputBegan:Connect(function(p270)
	-- upvalues: (ref) v_u_33, (copy) v_u_269
	if v_u_33 == "place" and (p270.UserInputType == Enum.UserInputType.MouseButton1 or p270.UserInputType == Enum.UserInputType.Touch) then
		v_u_269(p270)
	end
end)
local function v_u_272(p271)
	-- upvalues: (ref) v_u_32, (ref) v_u_244, (copy) v_u_247
	if v_u_32 then
		v_u_244 = {
			["kind"] = "rotate",
			["input"] = nil,
			["from"] = nil,
			["o0"] = nil,
			["input"] = p271,
			["from"] = v_u_247(p271),
			["o0"] = table.clone(v_u_32)
		}
	end
end
v_u_117.InputBegan:Connect(function(p273)
	-- upvalues: (ref) v_u_33, (copy) v_u_272
	if v_u_33 == "place" and (p273.UserInputType == Enum.UserInputType.MouseButton1 or p273.UserInputType == Enum.UserInputType.Touch) then
		v_u_272(p273)
	end
end)
local function v_u_275(p274)
	-- upvalues: (ref) v_u_32, (ref) v_u_244, (copy) v_u_247
	if v_u_32 then
		v_u_244 = {
			["kind"] = "tilt",
			["input"] = nil,
			["from"] = nil,
			["o0"] = nil,
			["input"] = p274,
			["from"] = v_u_247(p274),
			["o0"] = table.clone(v_u_32)
		}
	end
end
v_u_122.InputBegan:Connect(function(p276)
	-- upvalues: (ref) v_u_33, (copy) v_u_275
	if v_u_33 == "place" and (p276.UserInputType == Enum.UserInputType.MouseButton1 or p276.UserInputType == Enum.UserInputType.Touch) then
		v_u_275(p276)
	end
end)
v_u_114.Activated:Connect(function()
	-- upvalues: (ref) v_u_32, (copy) v_u_151, (copy) v_u_133, (ref) v_u_31, (copy) v_u_161, (copy) v_u_80, (ref) v_u_68
	if v_u_32 then
		local v277 = v_u_32
		v277.y = v277.y + 0.1
		v_u_151(v_u_32)
		local v278 = v_u_133()
		if v278 and v_u_31 then
			v278.C0 = v_u_161(v_u_32)
		end
		if v_u_32 then
			local v279 = v_u_80
			local v280 = v_u_32.x
			local v281 = v_u_32.z
			local v282 = v_u_32.y
			local v283 = v_u_32.yaw
			local v284 = math.round(v283)
			local v285 = -v_u_32.roll
			local v286 = math.round(v285)
			local v287 = v_u_32.pitch
			v279.Text = ("\224\184\139\224\185\137\224\184\178\224\184\162/\224\184\130\224\184\167\224\184\178 %.1f \194\183 \224\184\171\224\184\153\224\185\137\224\184\178/\224\184\171\224\184\165\224\184\177\224\184\135 %.1f \194\183 \224\184\170\224\184\185\224\184\135 %.1f\n\224\184\171\224\184\161\224\184\184\224\184\153 %d\194\176 \194\183 \224\185\128\224\184\173\224\184\181\224\184\162\224\184\135 %d\194\176 \194\183 \224\185\128\224\184\135\224\184\162 %d\194\176"):format(v280, v281, v282, v284, v286, (math.round(v287)))
		end
		v_u_68 = true
	end
end)
v_u_115.Activated:Connect(function()
	-- upvalues: (ref) v_u_32, (copy) v_u_151, (copy) v_u_133, (ref) v_u_31, (copy) v_u_161, (copy) v_u_80, (ref) v_u_68
	if v_u_32 then
		local v288 = v_u_32
		v288.y = v288.y + -0.1
		v_u_151(v_u_32)
		local v289 = v_u_133()
		if v289 and v_u_31 then
			v289.C0 = v_u_161(v_u_32)
		end
		if v_u_32 then
			local v290 = v_u_80
			local v291 = v_u_32.x
			local v292 = v_u_32.z
			local v293 = v_u_32.y
			local v294 = v_u_32.yaw
			local v295 = math.round(v294)
			local v296 = -v_u_32.roll
			local v297 = math.round(v296)
			local v298 = v_u_32.pitch
			v290.Text = ("\224\184\139\224\185\137\224\184\178\224\184\162/\224\184\130\224\184\167\224\184\178 %.1f \194\183 \224\184\171\224\184\153\224\185\137\224\184\178/\224\184\171\224\184\165\224\184\177\224\184\135 %.1f \194\183 \224\184\170\224\184\185\224\184\135 %.1f\n\224\184\171\224\184\161\224\184\184\224\184\153 %d\194\176 \194\183 \224\185\128\224\184\173\224\184\181\224\184\162\224\184\135 %d\194\176 \194\183 \224\185\128\224\184\135\224\184\162 %d\194\176"):format(v291, v292, v293, v295, v297, (math.round(v298)))
		end
		v_u_68 = true
	end
end)
v_u_119.Activated:Connect(function()
	-- upvalues: (ref) v_u_32, (copy) v_u_151, (copy) v_u_133, (ref) v_u_31, (copy) v_u_161, (copy) v_u_80, (ref) v_u_68
	if v_u_32 then
		local v299 = v_u_32
		v299.yaw = v299.yaw + 5
		v_u_151(v_u_32)
		local v300 = v_u_133()
		if v300 and v_u_31 then
			v300.C0 = v_u_161(v_u_32)
		end
		if v_u_32 then
			local v301 = v_u_80
			local v302 = v_u_32.x
			local v303 = v_u_32.z
			local v304 = v_u_32.y
			local v305 = v_u_32.yaw
			local v306 = math.round(v305)
			local v307 = -v_u_32.roll
			local v308 = math.round(v307)
			local v309 = v_u_32.pitch
			v301.Text = ("\224\184\139\224\185\137\224\184\178\224\184\162/\224\184\130\224\184\167\224\184\178 %.1f \194\183 \224\184\171\224\184\153\224\185\137\224\184\178/\224\184\171\224\184\165\224\184\177\224\184\135 %.1f \194\183 \224\184\170\224\184\185\224\184\135 %.1f\n\224\184\171\224\184\161\224\184\184\224\184\153 %d\194\176 \194\183 \224\185\128\224\184\173\224\184\181\224\184\162\224\184\135 %d\194\176 \194\183 \224\185\128\224\184\135\224\184\162 %d\194\176"):format(v302, v303, v304, v306, v308, (math.round(v309)))
		end
		v_u_68 = true
	end
end)
v_u_120.Activated:Connect(function()
	-- upvalues: (ref) v_u_32, (copy) v_u_151, (copy) v_u_133, (ref) v_u_31, (copy) v_u_161, (copy) v_u_80, (ref) v_u_68
	if v_u_32 then
		local v310 = v_u_32
		v310.yaw = v310.yaw + -5
		v_u_151(v_u_32)
		local v311 = v_u_133()
		if v311 and v_u_31 then
			v311.C0 = v_u_161(v_u_32)
		end
		if v_u_32 then
			local v312 = v_u_80
			local v313 = v_u_32.x
			local v314 = v_u_32.z
			local v315 = v_u_32.y
			local v316 = v_u_32.yaw
			local v317 = math.round(v316)
			local v318 = -v_u_32.roll
			local v319 = math.round(v318)
			local v320 = v_u_32.pitch
			v312.Text = ("\224\184\139\224\185\137\224\184\178\224\184\162/\224\184\130\224\184\167\224\184\178 %.1f \194\183 \224\184\171\224\184\153\224\185\137\224\184\178/\224\184\171\224\184\165\224\184\177\224\184\135 %.1f \194\183 \224\184\170\224\184\185\224\184\135 %.1f\n\224\184\171\224\184\161\224\184\184\224\184\153 %d\194\176 \194\183 \224\185\128\224\184\173\224\184\181\224\184\162\224\184\135 %d\194\176 \194\183 \224\185\128\224\184\135\224\184\162 %d\194\176"):format(v313, v314, v315, v317, v319, (math.round(v320)))
		end
		v_u_68 = true
	end
end)
v_u_124.left.button.Activated:Connect(function()
	-- upvalues: (ref) v_u_32, (copy) v_u_151, (copy) v_u_133, (ref) v_u_31, (copy) v_u_161, (copy) v_u_80, (ref) v_u_68
	if v_u_32 then
		local v321 = v_u_32
		v321.roll = v321.roll + 2
		v_u_151(v_u_32)
		local v322 = v_u_133()
		if v322 and v_u_31 then
			v322.C0 = v_u_161(v_u_32)
		end
		if v_u_32 then
			local v323 = v_u_80
			local v324 = v_u_32.x
			local v325 = v_u_32.z
			local v326 = v_u_32.y
			local v327 = v_u_32.yaw
			local v328 = math.round(v327)
			local v329 = -v_u_32.roll
			local v330 = math.round(v329)
			local v331 = v_u_32.pitch
			v323.Text = ("\224\184\139\224\185\137\224\184\178\224\184\162/\224\184\130\224\184\167\224\184\178 %.1f \194\183 \224\184\171\224\184\153\224\185\137\224\184\178/\224\184\171\224\184\165\224\184\177\224\184\135 %.1f \194\183 \224\184\170\224\184\185\224\184\135 %.1f\n\224\184\171\224\184\161\224\184\184\224\184\153 %d\194\176 \194\183 \224\185\128\224\184\173\224\184\181\224\184\162\224\184\135 %d\194\176 \194\183 \224\185\128\224\184\135\224\184\162 %d\194\176"):format(v324, v325, v326, v328, v330, (math.round(v331)))
		end
		v_u_68 = true
	end
end)
v_u_124.right.button.Activated:Connect(function()
	-- upvalues: (ref) v_u_32, (copy) v_u_151, (copy) v_u_133, (ref) v_u_31, (copy) v_u_161, (copy) v_u_80, (ref) v_u_68
	if v_u_32 then
		local v332 = v_u_32
		v332.roll = v332.roll + -2
		v_u_151(v_u_32)
		local v333 = v_u_133()
		if v333 and v_u_31 then
			v333.C0 = v_u_161(v_u_32)
		end
		if v_u_32 then
			local v334 = v_u_80
			local v335 = v_u_32.x
			local v336 = v_u_32.z
			local v337 = v_u_32.y
			local v338 = v_u_32.yaw
			local v339 = math.round(v338)
			local v340 = -v_u_32.roll
			local v341 = math.round(v340)
			local v342 = v_u_32.pitch
			v334.Text = ("\224\184\139\224\185\137\224\184\178\224\184\162/\224\184\130\224\184\167\224\184\178 %.1f \194\183 \224\184\171\224\184\153\224\185\137\224\184\178/\224\184\171\224\184\165\224\184\177\224\184\135 %.1f \194\183 \224\184\170\224\184\185\224\184\135 %.1f\n\224\184\171\224\184\161\224\184\184\224\184\153 %d\194\176 \194\183 \224\185\128\224\184\173\224\184\181\224\184\162\224\184\135 %d\194\176 \194\183 \224\185\128\224\184\135\224\184\162 %d\194\176"):format(v335, v336, v337, v339, v341, (math.round(v342)))
		end
		v_u_68 = true
	end
end)
v_u_124.up.button.Activated:Connect(function()
	-- upvalues: (ref) v_u_32, (copy) v_u_151, (copy) v_u_133, (ref) v_u_31, (copy) v_u_161, (copy) v_u_80, (ref) v_u_68
	if v_u_32 then
		local v343 = v_u_32
		v343.pitch = v343.pitch + 2
		v_u_151(v_u_32)
		local v344 = v_u_133()
		if v344 and v_u_31 then
			v344.C0 = v_u_161(v_u_32)
		end
		if v_u_32 then
			local v345 = v_u_80
			local v346 = v_u_32.x
			local v347 = v_u_32.z
			local v348 = v_u_32.y
			local v349 = v_u_32.yaw
			local v350 = math.round(v349)
			local v351 = -v_u_32.roll
			local v352 = math.round(v351)
			local v353 = v_u_32.pitch
			v345.Text = ("\224\184\139\224\185\137\224\184\178\224\184\162/\224\184\130\224\184\167\224\184\178 %.1f \194\183 \224\184\171\224\184\153\224\185\137\224\184\178/\224\184\171\224\184\165\224\184\177\224\184\135 %.1f \194\183 \224\184\170\224\184\185\224\184\135 %.1f\n\224\184\171\224\184\161\224\184\184\224\184\153 %d\194\176 \194\183 \224\185\128\224\184\173\224\184\181\224\184\162\224\184\135 %d\194\176 \194\183 \224\185\128\224\184\135\224\184\162 %d\194\176"):format(v346, v347, v348, v350, v352, (math.round(v353)))
		end
		v_u_68 = true
	end
end)
v_u_124.down.button.Activated:Connect(function()
	-- upvalues: (ref) v_u_32, (copy) v_u_151, (copy) v_u_133, (ref) v_u_31, (copy) v_u_161, (copy) v_u_80, (ref) v_u_68
	if v_u_32 then
		local v354 = v_u_32
		v354.pitch = v354.pitch + -2
		v_u_151(v_u_32)
		local v355 = v_u_133()
		if v355 and v_u_31 then
			v355.C0 = v_u_161(v_u_32)
		end
		if v_u_32 then
			local v356 = v_u_80
			local v357 = v_u_32.x
			local v358 = v_u_32.z
			local v359 = v_u_32.y
			local v360 = v_u_32.yaw
			local v361 = math.round(v360)
			local v362 = -v_u_32.roll
			local v363 = math.round(v362)
			local v364 = v_u_32.pitch
			v356.Text = ("\224\184\139\224\185\137\224\184\178\224\184\162/\224\184\130\224\184\167\224\184\178 %.1f \194\183 \224\184\171\224\184\153\224\185\137\224\184\178/\224\184\171\224\184\165\224\184\177\224\184\135 %.1f \194\183 \224\184\170\224\184\185\224\184\135 %.1f\n\224\184\171\224\184\161\224\184\184\224\184\153 %d\194\176 \194\183 \224\185\128\224\184\173\224\184\181\224\184\162\224\184\135 %d\194\176 \194\183 \224\185\128\224\184\135\224\184\162 %d\194\176"):format(v357, v358, v359, v361, v363, (math.round(v364)))
		end
		v_u_68 = true
	end
end)
v_u_127.Activated:Connect(function()
	-- upvalues: (ref) v_u_32, (copy) v_u_151, (copy) v_u_133, (ref) v_u_31, (copy) v_u_161, (copy) v_u_80, (ref) v_u_68
	if v_u_32 then
		local v365 = v_u_32
		v_u_32.roll = 0
		v365.pitch = 0
		v_u_151(v_u_32)
		local v366 = v_u_133()
		if v366 and v_u_31 then
			v366.C0 = v_u_161(v_u_32)
		end
		if v_u_32 then
			local v367 = v_u_80
			local v368 = v_u_32.x
			local v369 = v_u_32.z
			local v370 = v_u_32.y
			local v371 = v_u_32.yaw
			local v372 = math.round(v371)
			local v373 = -v_u_32.roll
			local v374 = math.round(v373)
			local v375 = v_u_32.pitch
			v367.Text = ("\224\184\139\224\185\137\224\184\178\224\184\162/\224\184\130\224\184\167\224\184\178 %.1f \194\183 \224\184\171\224\184\153\224\185\137\224\184\178/\224\184\171\224\184\165\224\184\177\224\184\135 %.1f \194\183 \224\184\170\224\184\185\224\184\135 %.1f\n\224\184\171\224\184\161\224\184\184\224\184\153 %d\194\176 \194\183 \224\185\128\224\184\173\224\184\181\224\184\162\224\184\135 %d\194\176 \194\183 \224\185\128\224\184\135\224\184\162 %d\194\176"):format(v368, v369, v370, v372, v374, (math.round(v375)))
		end
		v_u_68 = true
	end
end)
local function v_u_396(p376) -- name: updateDrag
	-- upvalues: (ref) v_u_244, (ref) v_u_32, (copy) v_u_247, (copy) v_u_151, (copy) v_u_133, (ref) v_u_31, (copy) v_u_161, (copy) v_u_80, (ref) v_u_68
	local v377 = v_u_244
	if v377 and v_u_32 then
		local v378 = v_u_247(p376)
		local v379 = table.clone(v377.o0)
		if v377.kind == "move" then
			local v380 = (v378 - v377.from):Dot(v377.sdir) / v377.pps / 0.05
			local v381 = math.round(v380) * 0.05
			v379.x = v377.o0.x + v377.dir.X * v381
			v379.z = v377.o0.z + v377.dir.Z * v381
		elseif v377.kind == "height" then
			local v382 = (v377.o0.y + (v377.from.Y - v378.Y) / 60) / 0.02
			v379.y = math.round(v382) * 0.02
		elseif v377.kind == "rotate" then
			local v383 = (v377.o0.yaw - (v378.X - v377.from.X) * 0.5) / 1
			v379.yaw = math.round(v383) * 1
		elseif v377.kind == "tilt" then
			local v384 = (v377.o0.roll - (v378.X - v377.from.X) / 3) / 1
			v379.roll = math.round(v384) * 1
			local v385 = (v377.o0.pitch + (v377.from.Y - v378.Y) / 3) / 1
			v379.pitch = math.round(v385) * 1
		end
		v_u_32 = v379
		v_u_151(v_u_32)
		local v386 = v_u_133()
		if v386 and v_u_31 then
			v386.C0 = v_u_161(v_u_32)
		end
		if v_u_32 then
			local v387 = v_u_80
			local v388 = v_u_32.x
			local v389 = v_u_32.z
			local v390 = v_u_32.y
			local v391 = v_u_32.yaw
			local v392 = math.round(v391)
			local v393 = -v_u_32.roll
			local v394 = math.round(v393)
			local v395 = v_u_32.pitch
			v387.Text = ("\224\184\139\224\185\137\224\184\178\224\184\162/\224\184\130\224\184\167\224\184\178 %.1f \194\183 \224\184\171\224\184\153\224\185\137\224\184\178/\224\184\171\224\184\165\224\184\177\224\184\135 %.1f \194\183 \224\184\170\224\184\185\224\184\135 %.1f\n\224\184\171\224\184\161\224\184\184\224\184\153 %d\194\176 \194\183 \224\185\128\224\184\173\224\184\181\224\184\162\224\184\135 %d\194\176 \194\183 \224\185\128\224\184\135\224\184\162 %d\194\176"):format(v388, v389, v390, v392, v394, (math.round(v395)))
		end
		v_u_68 = true
	end
end
v_u_5.InputBegan:Connect(function(p397, p398)
	-- upvalues: (ref) v_u_33, (ref) v_u_242, (ref) v_u_243, (copy) v_u_5, (ref) v_u_244
	if v_u_33 == "place" and v_u_242 then
		if p397.UserInputType == Enum.UserInputType.MouseButton2 and not p398 then
			v_u_243 = true
			v_u_5.MouseBehavior = Enum.MouseBehavior.LockCurrentPosition
		elseif p397.UserInputType == Enum.UserInputType.Touch and not (p398 or v_u_244) then
			v_u_243 = p397
		end
	else
		return
	end
end)
v_u_5.InputChanged:Connect(function(p399, p400)
	-- upvalues: (ref) v_u_244, (copy) v_u_396, (ref) v_u_242, (ref) v_u_243
	if v_u_244 and (p399.UserInputType == Enum.UserInputType.MouseMovement or p399 == v_u_244.input) then
		v_u_396(p399)
		return
	elseif v_u_242 then
		if p399.UserInputType == Enum.UserInputType.MouseWheel and not p400 then
			local v401 = v_u_242
			local v402 = v_u_242.dist * 0.88 ^ p399.Position.Z
			v401.dist = math.clamp(v402, 7, 28)
		elseif v_u_243 and (p399.UserInputType == Enum.UserInputType.MouseMovement and v_u_243 == true or p399 == v_u_243) then
			local v403 = v_u_242
			v403.yaw = v403.yaw - p399.Delta.X * 0.008
			local v404 = v_u_242
			local v405 = v_u_242.pitch + p399.Delta.Y * 0.006
			v404.pitch = math.clamp(v405, 0.13962634015954636, 1.3089969389957472)
		end
	else
		return
	end
end)
v_u_5.InputEnded:Connect(function(p406)
	-- upvalues: (ref) v_u_244, (ref) v_u_243, (copy) v_u_5
	if v_u_244 and (p406.UserInputType == Enum.UserInputType.MouseButton1 or p406 == v_u_244.input) then
		v_u_244 = nil
	end
	if p406.UserInputType == Enum.UserInputType.MouseButton2 and v_u_243 == true then
		v_u_243 = false
		v_u_5.MouseBehavior = Enum.MouseBehavior.Default
	elseif v_u_243 and p406 == v_u_243 then
		v_u_243 = false
	end
end)
v_u_5.TouchPinch:Connect(function(_, p407, _, p408, p409)
	-- upvalues: (ref) v_u_242
	if v_u_242 and (not p409 and (p408 == Enum.UserInputState.Change and p407 > 0)) then
		local v410 = v_u_242
		local v411 = v_u_242.dist / math.clamp(p407, 0.97, 1.03)
		v410.dist = math.clamp(v411, 7, 28)
	end
end)
local v_u_412 = {
	Enum.KeyCode.One,
	Enum.KeyCode.Two,
	Enum.KeyCode.Three,
	Enum.KeyCode.Four,
	Enum.KeyCode.Left,
	Enum.KeyCode.Right,
	Enum.KeyCode.Up,
	Enum.KeyCode.Down,
	Enum.KeyCode.Comma,
	Enum.KeyCode.Period,
	Enum.KeyCode.PageUp,
	Enum.KeyCode.PageDown
}
local function v_u_541(_, p413, p414) -- name: onKey
	-- upvalues: (ref) v_u_33, (copy) v_u_5, (copy) v_u_22, (copy) v_u_59, (ref) v_u_32, (copy) v_u_151, (copy) v_u_133, (ref) v_u_31, (copy) v_u_161, (copy) v_u_80, (ref) v_u_68, (ref) v_u_60
	if p413 ~= Enum.UserInputState.Begin or v_u_33 ~= "place" then
		return Enum.ContextActionResult.Sink
	end
	local v415 = v_u_5:IsKeyDown(Enum.KeyCode.LeftShift) or v_u_5:IsKeyDown(Enum.KeyCode.RightShift)
	local v416 = p414.KeyCode
	for _, v417 in v_u_22 do
		if v417.keyCode ~= v416 then
			continue
		end
		v_u_59(v417.key)
		return Enum.ContextActionResult.Sink
	end
	local v418 = v415 and 0.5 or 0.1
	local v419 = v415 and 15 or 2
	local v420 = v416 == Enum.KeyCode.Left and -1 or (v416 == Enum.KeyCode.Right and 1 or 0)
	local v421 = v416 == Enum.KeyCode.Up and 1 or (v416 == Enum.KeyCode.Down and -1 or 0)
	if v416 == Enum.KeyCode.Comma then
		local v422 = v415 and 15 or 5
		if v_u_32 then
			local v423 = v_u_32
			v423.yaw = v423.yaw + v422
			v_u_151(v_u_32)
			local v424 = v_u_133()
			if v424 and v_u_31 then
				v424.C0 = v_u_161(v_u_32)
			end
			if v_u_32 then
				local v425 = v_u_80
				local v426 = v_u_32.x
				local v427 = v_u_32.z
				local v428 = v_u_32.y
				local v429 = v_u_32.yaw
				local v430 = math.round(v429)
				local v431 = -v_u_32.roll
				local v432 = math.round(v431)
				local v433 = v_u_32.pitch
				v425.Text = ("\224\184\139\224\185\137\224\184\178\224\184\162/\224\184\130\224\184\167\224\184\178 %.1f \194\183 \224\184\171\224\184\153\224\185\137\224\184\178/\224\184\171\224\184\165\224\184\177\224\184\135 %.1f \194\183 \224\184\170\224\184\185\224\184\135 %.1f\n\224\184\171\224\184\161\224\184\184\224\184\153 %d\194\176 \194\183 \224\185\128\224\184\173\224\184\181\224\184\162\224\184\135 %d\194\176 \194\183 \224\185\128\224\184\135\224\184\162 %d\194\176"):format(v426, v427, v428, v430, v432, (math.round(v433)))
			end
			v_u_68 = true
		end
	elseif v416 == Enum.KeyCode.Period then
		local v434 = v415 and -15 or -5
		if v_u_32 then
			local v435 = v_u_32
			v435.yaw = v435.yaw + v434
			v_u_151(v_u_32)
			local v436 = v_u_133()
			if v436 and v_u_31 then
				v436.C0 = v_u_161(v_u_32)
			end
			if v_u_32 then
				local v437 = v_u_80
				local v438 = v_u_32.x
				local v439 = v_u_32.z
				local v440 = v_u_32.y
				local v441 = v_u_32.yaw
				local v442 = math.round(v441)
				local v443 = -v_u_32.roll
				local v444 = math.round(v443)
				local v445 = v_u_32.pitch
				v437.Text = ("\224\184\139\224\185\137\224\184\178\224\184\162/\224\184\130\224\184\167\224\184\178 %.1f \194\183 \224\184\171\224\184\153\224\185\137\224\184\178/\224\184\171\224\184\165\224\184\177\224\184\135 %.1f \194\183 \224\184\170\224\184\185\224\184\135 %.1f\n\224\184\171\224\184\161\224\184\184\224\184\153 %d\194\176 \194\183 \224\185\128\224\184\173\224\184\181\224\184\162\224\184\135 %d\194\176 \194\183 \224\185\128\224\184\135\224\184\162 %d\194\176"):format(v438, v439, v440, v442, v444, (math.round(v445)))
			end
			v_u_68 = true
		end
	elseif v416 == Enum.KeyCode.PageUp then
		if v_u_32 then
			local v446 = v_u_32
			v446.y = v446.y + v418
			v_u_151(v_u_32)
			local v447 = v_u_133()
			if v447 and v_u_31 then
				v447.C0 = v_u_161(v_u_32)
			end
			if v_u_32 then
				local v448 = v_u_80
				local v449 = v_u_32.x
				local v450 = v_u_32.z
				local v451 = v_u_32.y
				local v452 = v_u_32.yaw
				local v453 = math.round(v452)
				local v454 = -v_u_32.roll
				local v455 = math.round(v454)
				local v456 = v_u_32.pitch
				v448.Text = ("\224\184\139\224\185\137\224\184\178\224\184\162/\224\184\130\224\184\167\224\184\178 %.1f \194\183 \224\184\171\224\184\153\224\185\137\224\184\178/\224\184\171\224\184\165\224\184\177\224\184\135 %.1f \194\183 \224\184\170\224\184\185\224\184\135 %.1f\n\224\184\171\224\184\161\224\184\184\224\184\153 %d\194\176 \194\183 \224\185\128\224\184\173\224\184\181\224\184\162\224\184\135 %d\194\176 \194\183 \224\185\128\224\184\135\224\184\162 %d\194\176"):format(v449, v450, v451, v453, v455, (math.round(v456)))
			end
			v_u_68 = true
		end
	elseif v416 == Enum.KeyCode.PageDown then
		local v457 = -v418
		if v_u_32 then
			local v458 = v_u_32
			v458.y = v458.y + v457
			v_u_151(v_u_32)
			local v459 = v_u_133()
			if v459 and v_u_31 then
				v459.C0 = v_u_161(v_u_32)
			end
			if v_u_32 then
				local v460 = v_u_80
				local v461 = v_u_32.x
				local v462 = v_u_32.z
				local v463 = v_u_32.y
				local v464 = v_u_32.yaw
				local v465 = math.round(v464)
				local v466 = -v_u_32.roll
				local v467 = math.round(v466)
				local v468 = v_u_32.pitch
				v460.Text = ("\224\184\139\224\185\137\224\184\178\224\184\162/\224\184\130\224\184\167\224\184\178 %.1f \194\183 \224\184\171\224\184\153\224\185\137\224\184\178/\224\184\171\224\184\165\224\184\177\224\184\135 %.1f \194\183 \224\184\170\224\184\185\224\184\135 %.1f\n\224\184\171\224\184\161\224\184\184\224\184\153 %d\194\176 \194\183 \224\185\128\224\184\173\224\184\181\224\184\162\224\184\135 %d\194\176 \194\183 \224\185\128\224\184\135\224\184\162 %d\194\176"):format(v461, v462, v463, v465, v467, (math.round(v468)))
			end
			v_u_68 = true
		end
	elseif v_u_60 == "move" then
		if v420 ~= 0 then
			local v469 = v420 * v418
			if v_u_32 then
				local v470 = v_u_32
				v470.x = v470.x + v469
				v_u_151(v_u_32)
				local v471 = v_u_133()
				if v471 and v_u_31 then
					v471.C0 = v_u_161(v_u_32)
				end
				if v_u_32 then
					local v472 = v_u_80
					local v473 = v_u_32.x
					local v474 = v_u_32.z
					local v475 = v_u_32.y
					local v476 = v_u_32.yaw
					local v477 = math.round(v476)
					local v478 = -v_u_32.roll
					local v479 = math.round(v478)
					local v480 = v_u_32.pitch
					v472.Text = ("\224\184\139\224\185\137\224\184\178\224\184\162/\224\184\130\224\184\167\224\184\178 %.1f \194\183 \224\184\171\224\184\153\224\185\137\224\184\178/\224\184\171\224\184\165\224\184\177\224\184\135 %.1f \194\183 \224\184\170\224\184\185\224\184\135 %.1f\n\224\184\171\224\184\161\224\184\184\224\184\153 %d\194\176 \194\183 \224\185\128\224\184\173\224\184\181\224\184\162\224\184\135 %d\194\176 \194\183 \224\185\128\224\184\135\224\184\162 %d\194\176"):format(v473, v474, v475, v477, v479, (math.round(v480)))
				end
				v_u_68 = true
			end
		end
		if v421 ~= 0 then
			local v481 = -v421 * v418
			if v_u_32 then
				local v482 = v_u_32
				v482.z = v482.z + v481
				v_u_151(v_u_32)
				local v483 = v_u_133()
				if v483 and v_u_31 then
					v483.C0 = v_u_161(v_u_32)
				end
				if v_u_32 then
					local v484 = v_u_80
					local v485 = v_u_32.x
					local v486 = v_u_32.z
					local v487 = v_u_32.y
					local v488 = v_u_32.yaw
					local v489 = math.round(v488)
					local v490 = -v_u_32.roll
					local v491 = math.round(v490)
					local v492 = v_u_32.pitch
					v484.Text = ("\224\184\139\224\185\137\224\184\178\224\184\162/\224\184\130\224\184\167\224\184\178 %.1f \194\183 \224\184\171\224\184\153\224\185\137\224\184\178/\224\184\171\224\184\165\224\184\177\224\184\135 %.1f \194\183 \224\184\170\224\184\185\224\184\135 %.1f\n\224\184\171\224\184\161\224\184\184\224\184\153 %d\194\176 \194\183 \224\185\128\224\184\173\224\184\181\224\184\162\224\184\135 %d\194\176 \194\183 \224\185\128\224\184\135\224\184\162 %d\194\176"):format(v485, v486, v487, v489, v491, (math.round(v492)))
				end
				v_u_68 = true
			end
		end
	elseif v_u_60 == "height" then
		if v421 ~= 0 then
			local v493 = v421 * v418
			if v_u_32 then
				local v494 = v_u_32
				v494.y = v494.y + v493
				v_u_151(v_u_32)
				local v495 = v_u_133()
				if v495 and v_u_31 then
					v495.C0 = v_u_161(v_u_32)
				end
				if v_u_32 then
					local v496 = v_u_80
					local v497 = v_u_32.x
					local v498 = v_u_32.z
					local v499 = v_u_32.y
					local v500 = v_u_32.yaw
					local v501 = math.round(v500)
					local v502 = -v_u_32.roll
					local v503 = math.round(v502)
					local v504 = v_u_32.pitch
					v496.Text = ("\224\184\139\224\185\137\224\184\178\224\184\162/\224\184\130\224\184\167\224\184\178 %.1f \194\183 \224\184\171\224\184\153\224\185\137\224\184\178/\224\184\171\224\184\165\224\184\177\224\184\135 %.1f \194\183 \224\184\170\224\184\185\224\184\135 %.1f\n\224\184\171\224\184\161\224\184\184\224\184\153 %d\194\176 \194\183 \224\185\128\224\184\173\224\184\181\224\184\162\224\184\135 %d\194\176 \194\183 \224\185\128\224\184\135\224\184\162 %d\194\176"):format(v497, v498, v499, v501, v503, (math.round(v504)))
				end
				v_u_68 = true
			end
		end
	elseif v_u_60 == "rotate" then
		if v420 ~= 0 then
			local v505 = -v420 * (v415 and 15 or 5)
			if v_u_32 then
				local v506 = v_u_32
				v506.yaw = v506.yaw + v505
				v_u_151(v_u_32)
				local v507 = v_u_133()
				if v507 and v_u_31 then
					v507.C0 = v_u_161(v_u_32)
				end
				if v_u_32 then
					local v508 = v_u_80
					local v509 = v_u_32.x
					local v510 = v_u_32.z
					local v511 = v_u_32.y
					local v512 = v_u_32.yaw
					local v513 = math.round(v512)
					local v514 = -v_u_32.roll
					local v515 = math.round(v514)
					local v516 = v_u_32.pitch
					v508.Text = ("\224\184\139\224\185\137\224\184\178\224\184\162/\224\184\130\224\184\167\224\184\178 %.1f \194\183 \224\184\171\224\184\153\224\185\137\224\184\178/\224\184\171\224\184\165\224\184\177\224\184\135 %.1f \194\183 \224\184\170\224\184\185\224\184\135 %.1f\n\224\184\171\224\184\161\224\184\184\224\184\153 %d\194\176 \194\183 \224\185\128\224\184\173\224\184\181\224\184\162\224\184\135 %d\194\176 \194\183 \224\185\128\224\184\135\224\184\162 %d\194\176"):format(v509, v510, v511, v513, v515, (math.round(v516)))
				end
				v_u_68 = true
			end
		end
	elseif v_u_60 == "tilt" then
		if v420 ~= 0 then
			local v517 = -v420 * v419
			if v_u_32 then
				local v518 = v_u_32
				v518.roll = v518.roll + v517
				v_u_151(v_u_32)
				local v519 = v_u_133()
				if v519 and v_u_31 then
					v519.C0 = v_u_161(v_u_32)
				end
				if v_u_32 then
					local v520 = v_u_80
					local v521 = v_u_32.x
					local v522 = v_u_32.z
					local v523 = v_u_32.y
					local v524 = v_u_32.yaw
					local v525 = math.round(v524)
					local v526 = -v_u_32.roll
					local v527 = math.round(v526)
					local v528 = v_u_32.pitch
					v520.Text = ("\224\184\139\224\185\137\224\184\178\224\184\162/\224\184\130\224\184\167\224\184\178 %.1f \194\183 \224\184\171\224\184\153\224\185\137\224\184\178/\224\184\171\224\184\165\224\184\177\224\184\135 %.1f \194\183 \224\184\170\224\184\185\224\184\135 %.1f\n\224\184\171\224\184\161\224\184\184\224\184\153 %d\194\176 \194\183 \224\185\128\224\184\173\224\184\181\224\184\162\224\184\135 %d\194\176 \194\183 \224\185\128\224\184\135\224\184\162 %d\194\176"):format(v521, v522, v523, v525, v527, (math.round(v528)))
				end
				v_u_68 = true
			end
		end
		if v421 ~= 0 then
			local v529 = v421 * v419
			if v_u_32 then
				local v530 = v_u_32
				v530.pitch = v530.pitch + v529
				v_u_151(v_u_32)
				local v531 = v_u_133()
				if v531 and v_u_31 then
					v531.C0 = v_u_161(v_u_32)
				end
				if v_u_32 then
					local v532 = v_u_80
					local v533 = v_u_32.x
					local v534 = v_u_32.z
					local v535 = v_u_32.y
					local v536 = v_u_32.yaw
					local v537 = math.round(v536)
					local v538 = -v_u_32.roll
					local v539 = math.round(v538)
					local v540 = v_u_32.pitch
					v532.Text = ("\224\184\139\224\185\137\224\184\178\224\184\162/\224\184\130\224\184\167\224\184\178 %.1f \194\183 \224\184\171\224\184\153\224\185\137\224\184\178/\224\184\171\224\184\165\224\184\177\224\184\135 %.1f \194\183 \224\184\170\224\184\185\224\184\135 %.1f\n\224\184\171\224\184\161\224\184\184\224\184\153 %d\194\176 \194\183 \224\185\128\224\184\173\224\184\181\224\184\162\224\184\135 %d\194\176 \194\183 \224\185\128\224\184\135\224\184\162 %d\194\176"):format(v533, v534, v535, v537, v539, (math.round(v540)))
				end
				v_u_68 = true
			end
		end
	end
	return Enum.ContextActionResult.Sink
end
local function v_u_542() -- name: holdWalk
	return Enum.ContextActionResult.Sink
end
local function v_u_545(p543) -- name: bindKeys
	-- upvalues: (copy) v_u_6, (copy) v_u_541, (copy) v_u_412, (copy) v_u_542
	if p543 then
		local v544 = v_u_412
		v_u_6:BindActionAtPriority("CargoKeys", v_u_541, false, Enum.ContextActionPriority.High.Value + 50, table.unpack(v544))
		v_u_6:BindActionAtPriority("CargoHoldWalk", v_u_542, false, Enum.ContextActionPriority.High.Value + 50, Enum.PlayerActions.CharacterForward, Enum.PlayerActions.CharacterBackward, Enum.PlayerActions.CharacterLeft, Enum.PlayerActions.CharacterRight, Enum.PlayerActions.CharacterJump)
	else
		v_u_6:UnbindAction("CargoKeys")
		v_u_6:UnbindAction("CargoHoldWalk")
	end
end
local v_u_546 = {}
local function v553() -- name: closeAll
	-- upvalues: (ref) v_u_68, (ref) v_u_30, (ref) v_u_32, (ref) v_u_71, (copy) v_u_29, (ref) v_u_244, (ref) v_u_33, (copy) v_u_6, (ref) v_u_242, (ref) v_u_243, (copy) v_u_5, (copy) v_u_14, (copy) v_u_546, (copy) v_u_35, (copy) v_u_48, (copy) v_u_51, (copy) v_u_77, (copy) v_u_92, (ref) v_u_69
	if v_u_68 and (v_u_30 and v_u_32) then
		v_u_68 = false
		v_u_71 = os.clock()
		task.spawn(v_u_29, "Set", v_u_30, table.clone(v_u_32))
	end
	v_u_244 = nil
	if v_u_33 == "place" then
		v_u_6:UnbindAction("CargoKeys")
		v_u_6:UnbindAction("CargoHoldWalk")
	end
	if v_u_242 then
		v_u_242 = nil
		v_u_243 = false
		v_u_5.MouseBehavior = Enum.MouseBehavior.Default
		local v547 = workspace.CurrentCamera
		local v548 = v_u_14.Character
		if v548 then
			v548 = v_u_14.Character:FindFirstChildOfClass("Humanoid")
		end
		if v547 then
			v547.CameraType = Enum.CameraType.Custom
			if v548 then
				v547.CameraSubject = v548
			end
		end
	end
	local v549 = v_u_30
	if v549 then
		v549 = v_u_546[v_u_30]
	end
	if v549 then
		v549 = v549:FindFirstChild("CargoPrompt")
	end
	if v549 then
		v549.Enabled = true
	end
	v_u_33 = nil
	v_u_35.Enabled = false
	local v550 = v_u_51
	local v551 = v_u_77
	local v552 = v_u_92
	v_u_48.Visible = false
	v550.Visible = false
	v551.Visible = false
	v552.Visible = false
	v_u_30 = nil
	v_u_69 = nil
end
local v_u_554 = nil
local function v_u_559(p555) -- name: loadBike
	-- upvalues: (ref) v_u_70, (ref) v_u_30, (copy) v_u_29, (ref) v_u_31, (ref) v_u_32, (ref) v_u_69, (copy) v_u_13, (ref) v_u_554
	if v_u_70 or not v_u_30 then
		return
	else
		v_u_70 = true
		local v556, v557, v558 = v_u_29("Load", v_u_30, p555)
		v_u_70 = false
		if v556 then
			v_u_31.cargo = p555
			v_u_32 = v558
			v_u_69 = nil
			v_u_13.show(v557, "ok")
			v_u_554()
		else
			v_u_13.show(v557 or "\224\184\130\224\184\182\224\185\137\224\184\153\224\184\129\224\184\163\224\184\176\224\184\154\224\184\176\224\185\132\224\184\161\224\185\136\224\185\132\224\184\148\224\185\137", "error")
		end
	end
end
local function v_u_570() -- name: fillPicker
	-- upvalues: (copy) v_u_50, (ref) v_u_31, (copy) v_u_11, (copy) v_u_17, (copy) v_u_8, (copy) v_u_12, (copy) v_u_559
	for _, v560 in v_u_50:GetChildren() do
		if not v560:IsA("GuiButton") then
			continue
		end
		v560:Destroy()
	end
	v_u_50.CanvasPosition = Vector2.zero
	for v561, v_u_562 in v_u_31 and v_u_31.bikes or {} do
		local v563 = v_u_31.cargo == v_u_562.id
		local v564 = v_u_11.new("TextButton", {
			["Name"] = nil,
			["Text"] = "",
			["AutoButtonColor"] = true,
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["LayoutOrder"] = nil,
			["Parent"] = nil,
			["Name"] = v_u_562.id,
			["BackgroundColor3"] = v_u_11.CARD_DARK,
			["LayoutOrder"] = v563 and 0 or v561,
			["Parent"] = v_u_50
		})
		v_u_11.corner(v564, 12)
		v_u_11.new("UIStroke", {
			["Color"] = nil,
			["Thickness"] = 2,
			["Enabled"] = nil,
			["ApplyStrokeMode"] = nil,
			["Parent"] = nil,
			["Color"] = v_u_17,
			["Enabled"] = v563,
			["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
			["Parent"] = v564
		})
		local v565 = v_u_11.new("Frame", {
			["Name"] = "Picture",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Position"] = nil,
			["Size"] = nil,
			["ClipsDescendants"] = true,
			["Parent"] = nil,
			["BackgroundColor3"] = Color3.fromRGB(28, 30, 40),
			["Position"] = UDim2.fromOffset(4, 4),
			["Size"] = UDim2.new(1, -8, 0, 76),
			["Parent"] = v564
		})
		v_u_11.corner(v565, 9)
		v_u_11.new("UIGradient", {
			["Rotation"] = 90,
			["Color"] = nil,
			["Parent"] = nil,
			["Color"] = ColorSequence.new(Color3.fromRGB(96, 102, 128), Color3.fromRGB(26, 28, 38)),
			["Parent"] = v565
		})
		local v566 = v_u_8.vehicle(v_u_562.id)
		if v566 and v566.thumb then
			local v567 = v_u_11.new("ImageLabel", {
				["Image"] = nil,
				["ScaleType"] = nil,
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["Parent"] = nil,
				["Image"] = v566.thumb,
				["ScaleType"] = Enum.ScaleType.Crop,
				["Size"] = UDim2.fromScale(1, 1),
				["Parent"] = v565
			})
			v_u_11.corner(v567, 9)
		else
			local v568 = v_u_12.make("scooter", v_u_11.TEXT_DIM, 44)
			v568.AnchorPoint = Vector2.new(0.5, 0.5)
			v568.Position = UDim2.fromScale(0.5, 0.5)
			v568.Parent = v565
		end
		if v563 then
			local v569 = v_u_11.text({
				["Text"] = "\224\184\154\224\184\153\224\184\129\224\184\163\224\184\176\224\184\154\224\184\176",
				["TextSize"] = 11,
				["FontFace"] = nil,
				["TextColor3"] = nil,
				["BackgroundTransparency"] = 0,
				["BackgroundColor3"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["FontFace"] = v_u_11.FONT_BOLD,
				["TextColor3"] = v_u_11.DARK_TEXT,
				["BackgroundColor3"] = v_u_17,
				["Position"] = UDim2.fromOffset(4, 4),
				["Size"] = UDim2.fromOffset(56, 18),
				["Parent"] = v565
			})
			v_u_11.corner(v569, 6)
		end
		v_u_11.text({
			["Text"] = nil,
			["TextSize"] = 13,
			["FontFace"] = nil,
			["TextWrapped"] = true,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["Text"] = v_u_562.name,
			["FontFace"] = v_u_11.FONT_BOLD,
			["Position"] = UDim2.fromOffset(4, 82),
			["Size"] = UDim2.new(1, -8, 0, 28),
			["Parent"] = v564
		})
		v564.Activated:Connect(function()
			-- upvalues: (ref) v_u_559, (copy) v_u_562
			v_u_559(v_u_562.id)
		end)
	end
end
local function v_u_575() -- name: showPicker
	-- upvalues: (ref) v_u_33, (ref) v_u_68, (ref) v_u_30, (ref) v_u_32, (ref) v_u_71, (copy) v_u_29, (copy) v_u_6, (ref) v_u_242, (ref) v_u_243, (copy) v_u_5, (copy) v_u_14, (ref) v_u_244, (copy) v_u_35, (copy) v_u_51, (copy) v_u_77, (copy) v_u_92, (copy) v_u_48, (copy) v_u_570, (ref) v_u_31, (copy) v_u_13
	if v_u_33 == "place" then
		if v_u_68 and (v_u_30 and v_u_32) then
			v_u_68 = false
			v_u_71 = os.clock()
			task.spawn(v_u_29, "Set", v_u_30, table.clone(v_u_32))
		end
		v_u_6:UnbindAction("CargoKeys")
		v_u_6:UnbindAction("CargoHoldWalk")
		if v_u_242 then
			v_u_242 = nil
			v_u_243 = false
			v_u_5.MouseBehavior = Enum.MouseBehavior.Default
			local v571 = workspace.CurrentCamera
			local v572 = v_u_14.Character
			if v572 then
				v572 = v_u_14.Character:FindFirstChildOfClass("Humanoid")
			end
			if v571 then
				v571.CameraType = Enum.CameraType.Custom
				if v572 then
					v571.CameraSubject = v572
				end
			end
		end
	end
	v_u_33 = "pick"
	v_u_244 = nil
	v_u_35.Enabled = true
	local v573 = v_u_77
	local v574 = v_u_92
	v_u_51.Visible = false
	v573.Visible = false
	v574.Visible = false
	v_u_48.Visible = true
	v_u_570()
	if v_u_31 and #v_u_31.bikes == 0 then
		v_u_13.show("\224\184\132\224\184\184\224\184\147\224\184\162\224\184\177\224\184\135\224\185\132\224\184\161\224\185\136\224\184\161\224\184\181\224\184\161\224\184\173\224\185\132\224\184\139\224\184\132\224\185\140", "info")
	end
end
v_u_554 = function() -- name: startPlace
	-- upvalues: (ref) v_u_30, (ref) v_u_32, (copy) v_u_575, (ref) v_u_33, (ref) v_u_72, (ref) v_u_244, (copy) v_u_35, (copy) v_u_48, (copy) v_u_51, (copy) v_u_77, (copy) v_u_8, (ref) v_u_31, (copy) v_u_78, (copy) v_u_80, (copy) v_u_546, (ref) v_u_242, (copy) v_u_176, (copy) v_u_545
	if not (v_u_30 and v_u_32) then
		return v_u_575()
	end
	v_u_33 = "place"
	v_u_72 = os.clock()
	v_u_244 = nil
	v_u_35.Enabled = true
	v_u_48.Visible = false
	local v576 = v_u_77
	v_u_51.Visible = true
	v576.Visible = true
	local v577 = v_u_8.vehicle(v_u_31.cargo or "")
	v_u_78.Text = not v577 and "" or v577.th
	if v_u_32 then
		local v578 = v_u_80
		local v579 = v_u_32.x
		local v580 = v_u_32.z
		local v581 = v_u_32.y
		local v582 = v_u_32.yaw
		local v583 = math.round(v582)
		local v584 = -v_u_32.roll
		local v585 = math.round(v584)
		local v586 = v_u_32.pitch
		v578.Text = ("\224\184\139\224\185\137\224\184\178\224\184\162/\224\184\130\224\184\167\224\184\178 %.1f \194\183 \224\184\171\224\184\153\224\185\137\224\184\178/\224\184\171\224\184\165\224\184\177\224\184\135 %.1f \194\183 \224\184\170\224\184\185\224\184\135 %.1f\n\224\184\171\224\184\161\224\184\184\224\184\153 %d\194\176 \194\183 \224\185\128\224\184\173\224\184\181\224\184\162\224\184\135 %d\194\176 \194\183 \224\185\128\224\184\135\224\184\162 %d\194\176"):format(v579, v580, v581, v583, v585, (math.round(v586)))
	end
	local v587 = v_u_30
	if v587 then
		v587 = v_u_546[v_u_30]
	end
	if v587 then
		v587 = v587:FindFirstChild("CargoPrompt")
	end
	if v587 then
		v587.Enabled = false
	end
	if not v_u_242 then
		v_u_176()
	end
	v_u_545(true)
end
local function v_u_591(p588) -- name: openMenu
	-- upvalues: (ref) v_u_33, (copy) v_u_29, (copy) v_u_13, (ref) v_u_30, (ref) v_u_31, (ref) v_u_32, (ref) v_u_69, (ref) v_u_554, (copy) v_u_575
	if v_u_33 then
		return
	else
		local v589 = v_u_29("Bikes", p588)
		if type(v589) == "table" then
			v_u_30 = p588
			v_u_31 = v589
			local v590
			if v589.offset then
				v590 = table.clone(v589.offset) or nil
			else
				v590 = nil
			end
			v_u_32 = v590
			v_u_69 = nil
			if v589.cargo and v_u_32 then
				v_u_554()
			else
				v_u_575()
			end
		else
			v_u_13.show("\224\185\132\224\184\155\224\184\162\224\184\183\224\184\153\224\184\151\224\184\181\224\185\136\224\184\151\224\185\137\224\184\178\224\184\162\224\184\129\224\184\163\224\184\176\224\184\154\224\184\176\224\184\130\224\184\173\224\184\135\224\184\132\224\184\184\224\184\147\224\184\129\224\185\136\224\184\173\224\184\153", "error")
			return
		end
	end
end
v49.Activated:Connect(function()
	-- upvalues: (ref) v_u_31, (ref) v_u_32, (ref) v_u_554, (ref) v_u_68, (ref) v_u_30, (ref) v_u_71, (copy) v_u_29, (ref) v_u_244, (ref) v_u_33, (copy) v_u_6, (ref) v_u_242, (ref) v_u_243, (copy) v_u_5, (copy) v_u_14, (copy) v_u_546, (copy) v_u_35, (copy) v_u_48, (copy) v_u_51, (copy) v_u_77, (copy) v_u_92, (ref) v_u_69
	if v_u_31 and (v_u_31.cargo and v_u_32) then
		v_u_554()
	else
		if v_u_68 and (v_u_30 and v_u_32) then
			v_u_68 = false
			v_u_71 = os.clock()
			task.spawn(v_u_29, "Set", v_u_30, table.clone(v_u_32))
		end
		v_u_244 = nil
		if v_u_33 == "place" then
			v_u_6:UnbindAction("CargoKeys")
			v_u_6:UnbindAction("CargoHoldWalk")
		end
		if v_u_242 then
			v_u_242 = nil
			v_u_243 = false
			v_u_5.MouseBehavior = Enum.MouseBehavior.Default
			local v592 = workspace.CurrentCamera
			local v593 = v_u_14.Character
			if v593 then
				v593 = v_u_14.Character:FindFirstChildOfClass("Humanoid")
			end
			if v592 then
				v592.CameraType = Enum.CameraType.Custom
				if v593 then
					v592.CameraSubject = v593
				end
			end
		end
		local v594 = v_u_30
		if v594 then
			v594 = v_u_546[v_u_30]
		end
		if v594 then
			v594 = v594:FindFirstChild("CargoPrompt")
		end
		if v594 then
			v594.Enabled = true
		end
		v_u_33 = nil
		v_u_35.Enabled = false
		local v595 = v_u_51
		local v596 = v_u_77
		local v597 = v_u_92
		v_u_48.Visible = false
		v595.Visible = false
		v596.Visible = false
		v597.Visible = false
		v_u_30 = nil
		v_u_69 = nil
	end
end)
v79.Activated:Connect(v553)
v91.Activated:Connect(v553)
v87.Activated:Connect(v_u_575)
v88.Activated:Connect(function()
	-- upvalues: (ref) v_u_31, (ref) v_u_32, (copy) v_u_151, (copy) v_u_133, (copy) v_u_161, (copy) v_u_80, (ref) v_u_68
	if v_u_31 and v_u_31.default then
		v_u_32 = table.clone(v_u_31.default)
		v_u_151(v_u_32)
		local v598 = v_u_133()
		if v598 and v_u_31 then
			v598.C0 = v_u_161(v_u_32)
		end
		if v_u_32 then
			local v599 = v_u_80
			local v600 = v_u_32.x
			local v601 = v_u_32.z
			local v602 = v_u_32.y
			local v603 = v_u_32.yaw
			local v604 = math.round(v603)
			local v605 = -v_u_32.roll
			local v606 = math.round(v605)
			local v607 = v_u_32.pitch
			v599.Text = ("\224\184\139\224\185\137\224\184\178\224\184\162/\224\184\130\224\184\167\224\184\178 %.1f \194\183 \224\184\171\224\184\153\224\185\137\224\184\178/\224\184\171\224\184\165\224\184\177\224\184\135 %.1f \194\183 \224\184\170\224\184\185\224\184\135 %.1f\n\224\184\171\224\184\161\224\184\184\224\184\153 %d\194\176 \194\183 \224\185\128\224\184\173\224\184\181\224\184\162\224\184\135 %d\194\176 \194\183 \224\185\128\224\184\135\224\184\162 %d\194\176"):format(v600, v601, v602, v604, v606, (math.round(v607)))
		end
		v_u_68 = true
	end
end)
v89.Activated:Connect(function()
	-- upvalues: (ref) v_u_70, (ref) v_u_30, (ref) v_u_68, (ref) v_u_32, (ref) v_u_71, (copy) v_u_29, (copy) v_u_13, (ref) v_u_244, (ref) v_u_33, (copy) v_u_6, (ref) v_u_242, (ref) v_u_243, (copy) v_u_5, (copy) v_u_14, (copy) v_u_546, (copy) v_u_35, (copy) v_u_48, (copy) v_u_51, (copy) v_u_77, (copy) v_u_92, (ref) v_u_69
	if not v_u_70 and v_u_30 then
		if v_u_68 and (v_u_30 and v_u_32) then
			v_u_68 = false
			v_u_71 = os.clock()
			task.spawn(v_u_29, "Set", v_u_30, table.clone(v_u_32))
		end
		v_u_70 = true
		local v608, v609 = v_u_29("Unload", v_u_30)
		v_u_70 = false
		v_u_13.show(v609 or (v608 and "\224\185\128\224\184\163\224\184\181\224\184\162\224\184\154\224\184\163\224\185\137\224\184\173\224\184\162" or "\224\185\128\224\184\173\224\184\178\224\184\165\224\184\135\224\185\132\224\184\161\224\185\136\224\185\132\224\184\148\224\185\137"), v608 and "ok" or "error")
		if v608 then
			if v_u_68 and (v_u_30 and v_u_32) then
				v_u_68 = false
				v_u_71 = os.clock()
				task.spawn(v_u_29, "Set", v_u_30, table.clone(v_u_32))
			end
			v_u_244 = nil
			if v_u_33 == "place" then
				v_u_6:UnbindAction("CargoKeys")
				v_u_6:UnbindAction("CargoHoldWalk")
			end
			if v_u_242 then
				v_u_242 = nil
				v_u_243 = false
				v_u_5.MouseBehavior = Enum.MouseBehavior.Default
				local v610 = workspace.CurrentCamera
				local v611 = v_u_14.Character
				if v611 then
					v611 = v_u_14.Character:FindFirstChildOfClass("Humanoid")
				end
				if v610 then
					v610.CameraType = Enum.CameraType.Custom
					if v611 then
						v610.CameraSubject = v611
					end
				end
			end
			local v612 = v_u_30
			if v612 then
				v612 = v_u_546[v_u_30]
			end
			if v612 then
				v612 = v612:FindFirstChild("CargoPrompt")
			end
			if v612 then
				v612.Enabled = true
			end
			v_u_33 = nil
			v_u_35.Enabled = false
			local v613 = v_u_51
			local v614 = v_u_77
			local v615 = v_u_92
			v_u_48.Visible = false
			v613.Visible = false
			v614.Visible = false
			v615.Visible = false
			v_u_30 = nil
			v_u_69 = nil
		end
	end
end)
v90.Activated:Connect(function()
	-- upvalues: (ref) v_u_70, (ref) v_u_30, (copy) v_u_29, (copy) v_u_13, (ref) v_u_31, (ref) v_u_32, (copy) v_u_575
	if not v_u_70 and v_u_30 then
		v_u_70 = true
		local v616, v617 = v_u_29("Remove", v_u_30)
		v_u_70 = false
		v_u_13.show(v617 or "", v616 and "info" or "error")
		if v616 then
			v_u_31.cargo = nil
			v_u_32 = nil
			v_u_575()
		end
	end
end)
v4.Heartbeat:Connect(function()
	-- upvalues: (ref) v_u_33, (ref) v_u_68, (ref) v_u_30, (ref) v_u_32, (ref) v_u_71, (ref) v_u_70, (copy) v_u_29, (ref) v_u_244, (copy) v_u_80, (copy) v_u_14, (copy) v_u_6, (ref) v_u_242, (ref) v_u_243, (copy) v_u_5, (copy) v_u_546, (copy) v_u_35, (copy) v_u_48, (copy) v_u_51, (copy) v_u_77, (copy) v_u_92, (ref) v_u_69, (copy) v_u_133, (ref) v_u_72, (ref) v_u_31, (copy) v_u_575
	if v_u_33 then
		local v618 = os.clock()
		if v_u_68 and (v_u_30 and (v_u_32 and (v618 - v_u_71 >= 0.12 and not v_u_70))) then
			v_u_68 = false
			v_u_71 = v618
			local v_u_619 = table.clone(v_u_32)
			task.spawn(function()
				-- upvalues: (ref) v_u_29, (ref) v_u_30, (copy) v_u_619, (ref) v_u_68, (ref) v_u_244, (ref) v_u_33, (ref) v_u_32, (ref) v_u_80
				local v620, v621 = v_u_29("Set", v_u_30, v_u_619)
				v_u_32 = v620 and (type(v621) == "table" and not v_u_68) and (not v_u_244 and (v_u_33 == "place" and v621))
				if v_u_32 then
					local v622 = v_u_80
					local v623 = v_u_32.x
					local v624 = v_u_32.z
					local v625 = v_u_32.y
					local v626 = v_u_32.yaw
					local v627 = math.round(v626)
					local v628 = -v_u_32.roll
					local v629 = math.round(v628)
					local v630 = v_u_32.pitch
					v622.Text = ("\224\184\139\224\185\137\224\184\178\224\184\162/\224\184\130\224\184\167\224\184\178 %.1f \194\183 \224\184\171\224\184\153\224\185\137\224\184\178/\224\184\171\224\184\165\224\184\177\224\184\135 %.1f \194\183 \224\184\170\224\184\185\224\184\135 %.1f\n\224\184\171\224\184\161\224\184\184\224\184\153 %d\194\176 \194\183 \224\185\128\224\184\173\224\184\181\224\184\162\224\184\135 %d\194\176 \194\183 \224\185\128\224\184\135\224\184\162 %d\194\176"):format(v623, v624, v625, v627, v629, (math.round(v630)))
				end
			end)
		end
		local v631 = v_u_14.Character
		local v632
		if v631 then
			v632 = v631:FindFirstChild("HumanoidRootPart")
		else
			v632 = v631
		end
		if v631 then
			v631 = v631:FindFirstChildOfClass("Humanoid")
		end
		local v633 = v_u_30
		if v633 then
			v633 = v_u_30:FindFirstChild("Chassis")
		end
		if v_u_30 and (v_u_30.Parent and (v632 and (v633 and ((v632.Position - v633.Position).Magnitude <= 26 and (not v631 or not v631.SeatPart and v631.Health > 0))))) then
			if v_u_33 == "place" and (not v_u_133() and (not v_u_70 and v618 - v_u_72 > 3)) then
				v_u_31.cargo = nil
				v_u_32 = nil
				v_u_575()
			end
		else
			if v_u_68 and (v_u_30 and v_u_32) then
				v_u_68 = false
				v_u_71 = os.clock()
				task.spawn(v_u_29, "Set", v_u_30, table.clone(v_u_32))
			end
			v_u_244 = nil
			if v_u_33 == "place" then
				v_u_6:UnbindAction("CargoKeys")
				v_u_6:UnbindAction("CargoHoldWalk")
			end
			if v_u_242 then
				v_u_242 = nil
				v_u_243 = false
				v_u_5.MouseBehavior = Enum.MouseBehavior.Default
				local v634 = workspace.CurrentCamera
				local v635 = v_u_14.Character
				if v635 then
					v635 = v_u_14.Character:FindFirstChildOfClass("Humanoid")
				end
				if v634 then
					v634.CameraType = Enum.CameraType.Custom
					if v635 then
						v634.CameraSubject = v635
					end
				end
			end
			local v636 = v_u_30
			if v636 then
				v636 = v_u_546[v_u_30]
			end
			if v636 then
				v636 = v636:FindFirstChild("CargoPrompt")
			end
			if v636 then
				v636.Enabled = true
			end
			v_u_33 = nil
			v_u_35.Enabled = false
			local v637 = v_u_51
			local v638 = v_u_77
			local v639 = v_u_92
			v_u_48.Visible = false
			v637.Visible = false
			v638.Visible = false
			v639.Visible = false
			v_u_30 = nil
			v_u_69 = nil
		end
	else
		return
	end
end)
v4:BindToRenderStep("CargoGizmo", Enum.RenderPriority.Camera.Value + 2, function()
	-- upvalues: (ref) v_u_33, (ref) v_u_241
	if v_u_33 == "place" then
		v_u_241()
	end
end)
local function v_u_645(p_u_640) -- name: watchPickup
	-- upvalues: (copy) v_u_546, (copy) v_u_16, (copy) v_u_14, (copy) v_u_1, (copy) v_u_591
	if v_u_546[p_u_640] or not p_u_640:IsA("Model") then
		return
	else
		local v641 = v_u_16[p_u_640:GetAttribute("VehicleId")]
		if v641 and p_u_640:GetAttribute("OwnerUserId") == v_u_14.UserId then
			local v642 = p_u_640:WaitForChild("Chassis", 10)
			if v642 and not v_u_546[p_u_640] then
				local v643 = v_u_1.new("Attachment")
				v643.Name = "CargoPromptAt"
				v643.CFrame = v641.promptAt
				v643.Parent = v642
				local v644 = v_u_1.new("ProximityPrompt")
				v644.Name = "CargoPrompt"
				v644.ActionText = "\224\184\154\224\184\163\224\184\163\224\184\151\224\184\184\224\184\129\224\184\161\224\184\173\224\185\132\224\184\139\224\184\132\224\185\140"
				v644.ObjectText = "\224\184\129\224\184\163\224\184\176\224\184\154\224\184\176"
				v644.KeyboardKeyCode = Enum.KeyCode.E
				v644.HoldDuration = 0.2
				v644.MaxActivationDistance = 10
				v644.RequiresLineOfSight = false
				v644.Parent = v643
				v644.Triggered:Connect(function()
					-- upvalues: (ref) v_u_591, (copy) p_u_640
					v_u_591(p_u_640)
				end)
				v_u_546[p_u_640] = v643
				p_u_640.AncestryChanged:Connect(function()
					-- upvalues: (copy) p_u_640, (ref) v_u_546
					if not p_u_640:IsDescendantOf(workspace) then
						v_u_546[p_u_640] = nil
					end
				end)
			end
		else
			return
		end
	end
end
local v646 = workspace:WaitForChild("SpawnedVehicles")
v646.ChildAdded:Connect(function(p647)
	-- upvalues: (copy) v_u_645
	task.defer(v_u_645, p647)
end)
for _, v648 in v646:GetChildren() do
	task.spawn(v_u_645, v648)
end