-- Path: ReplicatedStorage/GroupRewardShared
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

return {
	["REMOTE"] = "GroupReward",
	["EVENT"] = "GroupRewardOpen",
	["REWARD"] = 10000,
	["GROUP_ID"] = game.CreatorType ~= Enum.CreatorType.Group and 762937383 or game.CreatorId
}