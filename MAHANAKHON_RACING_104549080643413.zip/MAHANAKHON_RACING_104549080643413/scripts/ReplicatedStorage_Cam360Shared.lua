-- Path: ReplicatedStorage/Cam360Shared
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_12 = {
	["ATTRIBUTE"] = "Cam360",
	["PROP"] = "Cam360",
	["LENS"] = "Insta360_Lens",
	["ORDER"] = { "Bar", "Tail" },
	["NAMES"] = {
		["Bar"] = "\224\184\129\224\184\165\224\185\137\224\184\173\224\184\135 360 \224\184\149\224\184\180\224\184\148\224\185\129\224\184\174\224\184\153\224\184\148\224\185\140",
		["Tail"] = "\224\184\129\224\184\165\224\185\137\224\184\173\224\184\135 360 \224\184\149\224\184\180\224\184\148\224\184\151\224\185\137\224\184\178\224\184\162\224\184\163\224\184\150"
	},
	["SPOTS"] = {
		["Bar"] = {
			["on"] = "SteerRoot",
			["from"] = "GripRight",
			["dir"] = Vector3.new(0.3, 1, -0.55),
			["length"] = 1.9
		},
		["Tail"] = {
			["on"] = "Chassis",
			["from"] = "Taillight",
			["dir"] = Vector3.new(0, 1, 0.6),
			["length"] = 1.5
		}
	},
	["HEAD_SCALE"] = 2,
	["HEAD"] = {
		"Insta360_Body",
		"Insta360_Screen",
		"Insta360_Lens",
		"Insta360_Glass"
	},
	["CLAMP"] = {
		"Mount",
		"Rubber_Feet",
		"Screws",
		"Knuckle",
		"Knuckle_1",
		"Knuckle_2",
		"bolt001"
	},
	["FOV"] = {
		["Bar"] = 95,
		["Tail"] = 100
	},
	["LOOK_DOWN"] = {
		["Bar"] = 0.6,
		["Tail"] = 0.4
	},
	["LENS_REACH"] = 0.25,
	["lensLocal"] = function(p1, p2) -- name: lensLocal
		-- upvalues: (copy) v_u_12
		local v3 = v_u_12.SPOTS[p2]
		local v4 = p1:FindFirstChild("Chassis")
		local v5
		if v3 then
			v5 = p1:FindFirstChild(v3.on)
		else
			v5 = v3
		end
		local v6 = not v3 or (not v4 or v4:FindFirstChild(v3.from))
		if v6 then
			v5 = v6
		elseif v5 then
			v5 = v5:FindFirstChild(v3.from)
		end
		if not (v5 and v5:IsA("Attachment")) then
			return nil
		end
		local v7 = v4.CFrame:VectorToWorldSpace(v3.dir).Unit
		return v4.CFrame:PointToObjectSpace(v5.WorldPosition + v7 * (v3.length + v_u_12.LENS_REACH))
	end,
	["valid"] = function(p8) -- name: valid
		-- upvalues: (copy) v_u_12
		return v_u_12.SPOTS[p8] ~= nil
	end,
	["next"] = function(p9) -- name: next
		-- upvalues: (copy) v_u_12
		for v10, v11 in v_u_12.ORDER do
			if v11 ~= p9 then
				continue
			end
			return v_u_12.ORDER[v10 + 1]
		end
		return v_u_12.ORDER[1]
	end
}
return v_u_12