-- Path: Players/ygggggg55551/PlayerScripts/CarClient/Hands
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = {}
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = false
local v_u_4 = {
	75,
	135,
	195,
	245
}
local v_u_5 = { 1, 0.3, 0.5 }
local v_u_6 = Color3.fromRGB(226, 178, 140)
local v_u_7 = Color3.fromRGB(38, 40, 46)
local v_u_8 = nil
local v_u_9 = {}
local v_u_10 = {}
local v_u_11 = nil
local v_u_12 = nil
local function v_u_18(p13, p14, p15, p16) -- name: piece
	-- upvalues: (ref) v_u_8
	local v17 = Instance.new("Part")
	v17.Name = p13
	v17.Size = p14
	v17.Color = p15
	v17.Material = Enum.Material.SmoothPlastic
	v17.Shape = p16 or Enum.PartType.Block
	v17.Anchored = true
	v17.CanCollide = false
	v17.CanQuery = false
	v17.CanTouch = false
	v17.CastShadow = false
	v17.TopSurface = Enum.SurfaceType.Smooth
	v17.BottomSurface = Enum.SurfaceType.Smooth
	v17.Parent = v_u_8
	return v17
end
local function v_u_123(p19, p20, p21, p22, p23) -- name: buildHand
	-- upvalues: (copy) v_u_9, (copy) v_u_18, (ref) v_u_3, (copy) v_u_4, (copy) v_u_5, (copy) v_u_10, (copy) v_u_7, (ref) v_u_11
	local v24 = p22 * 1
	local v25 = 0.095 * v24
	local v26 = v25 / 2 + 0.01 * v24
	local v27 = 0.26 * v24
	local v28 = v27 * 0.4
	local v29 = p21 * 0.374606593415912 * (0.09 * v24 + v28)
	local v30 = 0.9271838545667874 * (0.14 * v24 + v28)
	local v31 = Vector3.new(v29, 0, v30)
	local v32 = 0.36 * v24 / 2
	if not v_u_3 then
		local v33 = v31 - Vector3.new(0, v32, 0)
		local v34 = v31 + Vector3.new(0, v32, 0)
		local v35 = v_u_18
		local v36 = (v34 - v33).Magnitude
		local v37 = v35("BackOfHand", Vector3.new(v36, v27, v27), p23, Enum.PartType.Cylinder)
		local v38 = CFrame.lookAt((v33 + v34) / 2, v34) * CFrame.Angles(0, 1.5707963267948966, 0)
		local v39 = v_u_9
		local v40 = {
			["part"] = v37,
			["offset"] = p19.CFrame * v38
		}
		table.insert(v39, v40)
		local v41 = v31 + Vector3.new(0, v32, 0)
		local v42 = v_u_18("HandTop", Vector3.new(1, 1, 1) * v27, p23, Enum.PartType.Ball)
		local v43 = CFrame.new(v41)
		local v44 = v_u_9
		local v45 = {
			["part"] = v42,
			["offset"] = p19.CFrame * v43
		}
		table.insert(v44, v45)
		local v46 = v31 - Vector3.new(0, v32, 0)
		local v47 = v_u_18("HandBottom", Vector3.new(1, 1, 1) * v27, p23, Enum.PartType.Ball)
		local v48 = CFrame.new(v46)
		local v49 = v_u_9
		local v50 = {
			["part"] = v47,
			["offset"] = p19.CFrame * v48
		}
		table.insert(v49, v50)
		for v51 = 1, 4 do
			local v52 = (v51 - 2.5) * 0.098 * v24
			local v53 = {}
			for v54, v55 in v_u_4 do
				local v56 = v52 - (v54 - 1) * 0.008 * v24
				local v57 = math.rad(v55)
				local v58 = p21 * math.sin(v57) * (0.09 * v24 + v26)
				local v59 = math.cos(v57) * (0.14 * v24 + v26)
				v53[v54] = Vector3.new(v58, v56, v59)
			end
			for v60 = 1, #v53 do
				local v61 = "Joint" .. v51 .. "_" .. v60
				local v62 = v53[v60]
				local v63 = v_u_18(v61, Vector3.new(1, 1, 1) * (v25 * (v60 == 1 and 1.1 or 1)), p23, Enum.PartType.Ball)
				local v64 = CFrame.new(v62)
				local v65 = v_u_9
				local v66 = {
					["part"] = v63,
					["offset"] = p19.CFrame * v64
				}
				table.insert(v65, v66)
				if v60 <= 1 then
					continue
				end
				local v67 = "Finger" .. v51 .. "_" .. v60
				local v68 = v53[v60 - 1]
				local v69 = v53[v60]
				local v70 = v_u_18
				local v71 = (v69 - v68).Magnitude
				local v72 = v70(v67, Vector3.new(v71, v25, v25), p23, Enum.PartType.Cylinder)
				local v73 = CFrame.lookAt((v68 + v69) / 2, v69) * CFrame.Angles(0, 1.5707963267948966, 0)
				local v74 = v_u_9
				local v75 = {
					["part"] = v72,
					["offset"] = p19.CFrame * v73
				}
				table.insert(v74, v75)
			end
		end
		local v76 = -0.04 * v24
		local v77 = v26 + 0.02 * v24
		local v78 = p21 * -0.3420201433256686 * (0.09 * v24 + v77)
		local v79 = 0.9396926207859084 * (0.14 * v24 + v77)
		local v80 = Vector3.new(v78, v76, v79)
		local v81 = 0.18 * v24
		local v82 = p21 * -0.9063077870366499 * (0.09 * v24 + v26)
		local v83 = 0.4226182617406996 * (0.14 * v24 + v26)
		local v84 = Vector3.new(v82, v81, v83)
		local v85 = v_u_18("ThumbBase", Vector3.new(1, 1, 1) * (v25 * 1.15), p23, Enum.PartType.Ball)
		local v86 = CFrame.new(v80)
		local v87 = v_u_9
		local v88 = {
			["part"] = v85,
			["offset"] = p19.CFrame * v86
		}
		table.insert(v87, v88)
		local v89 = v25 * 1.05
		local v90 = v_u_18
		local v91 = (v84 - v80).Magnitude
		local v92 = v90("Thumb", Vector3.new(v91, v89, v89), p23, Enum.PartType.Cylinder)
		local v93 = CFrame.lookAt((v80 + v84) / 2, v84) * CFrame.Angles(0, 1.5707963267948966, 0)
		local v94 = v_u_9
		local v95 = {
			["part"] = v92,
			["offset"] = p19.CFrame * v93
		}
		table.insert(v94, v95)
		local v96 = v_u_18("ThumbTip", Vector3.new(1, 1, 1) * (v25 * 1.05), p23, Enum.PartType.Ball)
		local v97 = CFrame.new(v84)
		local v98 = v_u_9
		local v99 = {
			["part"] = v96,
			["offset"] = p19.CFrame * v97
		}
		table.insert(v98, v99)
	end
	local v100 = p21 * 0.05
	local v101 = v31 + Vector3.new(v100, -0.24, 0.1) * v24
	if not v_u_3 then
		local v102 = v_u_18("Wrist", Vector3.new(1, 1, 1) * (0.2 * v24), p23, Enum.PartType.Ball)
		local v103 = CFrame.new(v101)
		local v104 = v_u_9
		local v105 = {
			["part"] = v102,
			["offset"] = p19.CFrame * v103
		}
		table.insert(v104, v105)
	end
	local v106 = p21 * 0.4
	local v107 = Vector3.new(v106, -0.55, 1).Unit
	local v108 = v101 + v107 * 1.5 * v24
	local v109 = p20 * p19.CFrame * v108
	local v110 = p21 * v_u_5[1]
	local v111 = v_u_5[2]
	local v112 = v_u_5[3]
	local v113 = Vector3.new(v110, v111, v112).Unit
	local v114 = p20 * p19.CFrame * (v108 + v113 * 1.4 * v24)
	local v115 = v_u_10
	local v116 = {}
	local v117 = v_u_18
	local v118 = 0.36 * v24
	local v119 = 0.36 * v24
	v116.rod = v117("Forearm", Vector3.new(1, v118, v119), v_u_7, Enum.PartType.Cylinder)
	v116.cap = v_u_18("Elbow", Vector3.new(0.44, 0.44, 0.44) * v24, v_u_7, Enum.PartType.Ball)
	local v120 = v_u_18
	local v121 = 0.44 * v24
	local v122 = 0.44 * v24
	v116.upper = v120("UpperArm", Vector3.new(1, v121, v122), v_u_7, Enum.PartType.Cylinder)
	v116.shoulderCap = v_u_18("Shoulder", Vector3.new(0.506, 0.506, 0.506) * v24, v_u_7, Enum.PartType.Ball)
	v116.cuff = p19.CFrame * (v101 + v107 * 0.1 * v24)
	v116.elbow = v_u_11.CFrame:PointToObjectSpace(v109)
	v116.shoulder = v_u_11.CFrame:PointToObjectSpace(v114)
	table.insert(v115, v116)
end
local function v_u_146(p124, p125, p126, p127) -- name: placeGloves
	-- upvalues: (ref) v_u_8, (copy) v_u_9
	local v128 = p125.CFrame.Position
	local v129 = p126.CFrame.Position
	local v130 = (v129 - v128).Unit
	local v131 = (p125.CFrame.ZVector + p126.CFrame.ZVector).Unit:Cross(v130).Unit
	local v132 = v130:Cross(v131).Unit
	local v133 = CFrame.fromMatrix((v128 + v129) / 2, v130, v131, v132)
	local v134 = (v129 - v128).Magnitude / 2
	for _, v135 in { "Left", "Right" } do
		local v136 = p124:FindFirstChild(v135)
		local v137 = v136:GetAttribute("WheelOffset")
		local v138 = v136:GetAttribute("UnitSize")
		local v139 = v136:Clone()
		v139.Size = v138 * v134 * 0.85
		v139.TextureID = ""
		v139.Color = p127
		v139.Material = Enum.Material.SmoothPlastic
		v139.Anchored = true
		v139.CanCollide = false
		v139.CanQuery = false
		v139.CanTouch = false
		v139.CastShadow = false
		v139.Parent = v_u_8
		local v140 = v137.Position.X * 1.12
		local v141 = v137.Position.Y + 0.4
		local v142 = v137.Position.Z
		local v143 = Vector3.new(v140, v141, v142) * v134
		local v144 = v_u_9
		local v145 = {
			["part"] = v139,
			["offset"] = v133 * CFrame.new(v143) * v137.Rotation
		}
		table.insert(v144, v145)
	end
end
function v_u_1.start(p147, p148) -- name: start
	-- upvalues: (copy) v_u_1, (ref) v_u_11, (copy) v_u_6, (ref) v_u_12, (ref) v_u_8, (copy) v_u_2, (ref) v_u_3, (copy) v_u_123, (copy) v_u_146
	v_u_1.stop()
	v_u_11 = p147:FindFirstChild("Chassis")
	local v149 = p147:FindFirstChild("SteeringWheelRoot")
	local v150
	if v149 then
		v150 = v149:FindFirstChild("GripLeft")
	else
		v150 = v149
	end
	if v149 then
		v149 = v149:FindFirstChild("GripRight")
	end
	local v151 = v_u_11
	if v151 then
		v151 = v_u_11:FindFirstChild("SteeringWheelMotor")
	end
	if v150 and (v149 and v151) then
		local v152 = v151:GetAttribute("BaseC0") or v151.C0
		local v153 = v151.Part0.CFrame * v152 * v151.C1:Inverse()
		local v154 = (v150.Position - v149.Position).Magnitude / 2
		local v155 = math.max(v154, 0.2) / 0.688
		local v156 = p148:FindFirstChild("RightHand") or p148:FindFirstChild("Right Arm")
		local v157
		if v156 then
			local _, v158 = v156.Color:ToHSV()
			if v158 < 0.12 then
				v157 = v_u_6
			else
				v157 = v156.Color
			end
		else
			v157 = v_u_6
		end
		v_u_12 = {
			["motor"] = nil,
			["base"] = nil,
			["raw"] = 0,
			["angle"] = 0,
			["motor"] = v151,
			["base"] = v152
		}
		v_u_8 = Instance.new("Folder")
		v_u_8.Name = "CarFirstPersonHands"
		v_u_8.Parent = workspace.CurrentCamera
		local v159 = v_u_2:FindFirstChild("GameAssets")
		if v159 then
			v159 = v159:FindFirstChild("DriverGloves")
		end
		local v160
		if v159 == nil or v159:FindFirstChild("Left") == nil then
			v160 = false
		else
			v160 = v159:FindFirstChild("Right") ~= nil
		end
		v_u_3 = v160
		v_u_123(v150, v153, -1, v155, v157)
		v_u_123(v149, v153, 1, v155, v157)
		if v_u_3 then
			v_u_146(v159, v150, v149, v157)
		end
		v_u_1.update()
	end
end
function v_u_1.update() -- name: update
	-- upvalues: (ref) v_u_12, (ref) v_u_3, (copy) v_u_9, (copy) v_u_10, (ref) v_u_11
	if v_u_12 then
		local v161 = v_u_12.motor
		local _, _, v162 = (v_u_12.base:Inverse() * v161.C0):ToEulerAnglesXYZ()
		local v163 = v162 - v_u_12.raw
		if v163 > 3.141592653589793 then
			v163 = v163 - 6.283185307179586
		elseif v163 < -3.141592653589793 then
			v163 = v163 + 6.283185307179586
		end
		v_u_12.raw = v162
		local v164 = v_u_12
		v164.angle = v164.angle + v163
		local v165 = v_u_3 and 0.6108652381980153 or 2.0943951023931953
		local v166 = v_u_12.angle
		local v167 = -v165
		local v168 = math.clamp(v166, v167, v165)
		local v169 = v161.Part0.CFrame * v_u_12.base * CFrame.Angles(0, 0, v168) * v161.C1:Inverse()
		for _, v170 in v_u_9 do
			v170.part.CFrame = v169 * v170.offset
		end
		for _, v171 in v_u_10 do
			local v172 = v169 * v171.cuff
			local v173 = v_u_11.CFrame * v171.elbow
			local v174 = v171.rod
			local v175 = (v173 - v172).Magnitude
			local v176 = v171.rod.Size.Y
			local v177 = v171.rod.Size.Z
			v174.Size = Vector3.new(v175, v176, v177)
			v171.rod.CFrame = CFrame.lookAt((v172 + v173) / 2, v173) * CFrame.Angles(0, 1.5707963267948966, 0)
			v171.cap.CFrame = CFrame.new(v173)
			local v178 = v_u_11.CFrame * v171.shoulder
			local v179 = v171.upper
			local v180 = (v178 - v173).Magnitude
			local v181 = v171.upper.Size.Y
			local v182 = v171.upper.Size.Z
			v179.Size = Vector3.new(v180, v181, v182)
			v171.upper.CFrame = CFrame.lookAt((v173 + v178) / 2, v178) * CFrame.Angles(0, 1.5707963267948966, 0)
			v171.shoulderCap.CFrame = CFrame.new(v178)
		end
	end
end
function v_u_1.stop() -- name: stop
	-- upvalues: (ref) v_u_8, (ref) v_u_11, (ref) v_u_12, (copy) v_u_9, (copy) v_u_10
	if v_u_8 then
		v_u_8:Destroy()
	end
	v_u_8 = nil
	v_u_11 = nil
	v_u_12 = nil
	table.clear(v_u_9)
	table.clear(v_u_10)
end
return v_u_1