-- Path: ReplicatedStorage/GameUI/ShopApp
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = require(game:GetService("ReplicatedStorage"):WaitForChild("NetSeal"))
local v2 = game:GetService("Players")
local v_u_3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = require(v_u_3:WaitForChild("GameShared"))
local v_u_6 = require(v_u_3:WaitForChild("ShopShared"))
local v_u_7 = require(v_u_3:WaitForChild("PCX160Shared"))
local v_u_8 = require(v_u_3:WaitForChild("Cam360Shared"))
local v_u_9 = require(script.Parent:WaitForChild("Theme"))
local v_u_10 = require(script.Parent:WaitForChild("Icons"))
local v_u_11 = require(script.Parent:WaitForChild("Toast"))
local v12 = {}
local v_u_13 = Color3.new(1, 1, 1)
local v_u_14 = Color3.fromRGB(28, 30, 36)
local v_u_15 = Color3.fromRGB(112, 116, 128)
local v_u_16 = Color3.fromRGB(243, 244, 247)
local v_u_17 = Color3.fromRGB(255, 170, 40)
local v_u_18 = Color3.fromRGB(60, 30, 10)
local v_u_19 = TweenInfo.new(0.3, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
local v_u_20 = { Color3.fromRGB(92, 214, 122), Color3.fromRGB(26, 150, 72) }
local v_u_21 = { Color3.fromRGB(255, 120, 104), Color3.fromRGB(210, 48, 52) }
local v_u_22 = { Color3.fromRGB(224, 226, 232), Color3.fromRGB(206, 209, 216) }
local v_u_23 = v2.LocalPlayer
local function v_u_41(p24, p25, p26, p27, p28, p29, p30, p31, p32, p33) -- name: label
	-- upvalues: (copy) v_u_9
	local v34 = v_u_9.text
	local v35 = {
		["Text"] = p25
	}
	local v36
	if p32 then
		v36 = v_u_9.FONT_BOLD
	else
		v36 = v_u_9.FONT
	end
	v35.FontFace = v36
	v35.TextSize = p30
	v35.TextColor3 = p31
	v35.TextXAlignment = Enum.TextXAlignment.Left
	v35.TextTruncate = Enum.TextTruncate.AtEnd
	v35.Position = UDim2.new(0, p26, 0, p27)
	local v37
	if p28 then
		v37 = UDim2.fromOffset(p28, p29)
	else
		v37 = UDim2.new(1, -p26 - 8, 0, p29)
	end
	v35.Size = v37
	v35.Parent = p24
	local v38 = v34(v35)
	for v39, v40 in p33 or {} do
		v38[v39] = v40
	end
	return v38
end
local function v_u_55(p42, p43, p44, p45, p46, p47, p48, p49) -- name: pill
	-- upvalues: (copy) v_u_9, (copy) v_u_13, (copy) v_u_41, (copy) v_u_4
	local v50 = v_u_9.new("TextButton", {
		["Text"] = "",
		["AutoButtonColor"] = false,
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_13,
		["Position"] = UDim2.new(p45.X.Scale, p45.X.Offset, 0, p46),
		["Size"] = UDim2.new(p47.X.Scale, p47.X.Offset, 0, p48),
		["Parent"] = p42
	})
	v_u_9.corner(v50, p48 // 2)
	local v51 = v_u_9.new("UIGradient", {
		["Rotation"] = 90,
		["Color"] = nil,
		["Parent"] = nil,
		["Color"] = ColorSequence.new(p44[1], p44[2]),
		["Parent"] = v50
	})
	local v52 = v_u_41(v50, p43, 0, 0, nil, p48, 14, p49 or v_u_13, true, {
		["TextXAlignment"] = Enum.TextXAlignment.Center,
		["Size"] = UDim2.fromScale(1, 1)
	})
	local v_u_53 = v_u_9.new("UIScale", {
		["Parent"] = v50
	})
	v50.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_4, (copy) v_u_53
		v_u_4:Create(v_u_53, TweenInfo.new(0.08), {
			["Scale"] = 0.94
		}):Play()
	end)
	for _, v54 in { v50.MouseButton1Up, v50.MouseLeave } do
		v54:Connect(function()
			-- upvalues: (ref) v_u_4, (copy) v_u_53
			v_u_4:Create(v_u_53, TweenInfo.new(0.08), {
				["Scale"] = 1
			}):Play()
		end)
	end
	return v50, v52, v51
end
local function v_u_59(p56) -- name: toolOf
	-- upvalues: (copy) v_u_23
	for _, v57 in { v_u_23.Character, v_u_23:FindFirstChildOfClass("Backpack") } do
		for _, v58 in not v57 and {} or v57:GetChildren() do
			if not (v58:IsA("Tool") and v58:GetAttribute(p56)) then
				continue
			end
			return v58, v57 == v_u_23.Character
		end
	end
	return nil, false
end
local function v_u_62() -- name: ridingBike
	-- upvalues: (copy) v_u_23, (copy) v_u_7
	local v60 = v_u_23.Character
	if v60 then
		v60 = v_u_23.Character:FindFirstChildOfClass("Humanoid")
	end
	if v60 then
		v60 = v60.SeatPart
	end
	local v61
	if v60 then
		v61 = v_u_7.bikeFromSeat(v60)
	else
		v61 = v60
	end
	if v61 and (v61:GetAttribute("OwnerUserId") == v_u_23.UserId and v60 == v61:FindFirstChild("VehicleSeat")) then
		return v61
	else
		return nil
	end
end
local function v_u_68(p63) -- name: isEquipped
	-- upvalues: (copy) v_u_62, (copy) v_u_8, (copy) v_u_23, (copy) v_u_59
	if p63.id ~= "Cam360" then
		local _, v64 = v_u_59(p63.id)
		return v64
	end
	local v65 = v_u_62()
	if v65 then
		return v65:GetAttribute(v_u_8.ATTRIBUTE) ~= nil
	end
	local v66 = workspace:FindFirstChild("SpawnedVehicles")
	for _, v67 in not v66 and {} or v66:GetChildren() do
		if v67:GetAttribute("OwnerUserId") ~= v_u_23.UserId or not v67:GetAttribute(v_u_8.ATTRIBUTE) then
			continue
		end
		return true
	end
	return false
end
function v12.build(p69, p_u_70, p_u_71) -- name: build
	-- upvalues: (copy) v_u_3, (copy) v_u_5, (copy) v_u_6, (copy) v_u_9, (copy) v_u_16, (copy) v_u_13, (copy) v_u_17, (copy) v_u_18, (copy) v_u_10, (copy) v_u_41, (copy) v_u_14, (copy) v_u_15, (copy) v_u_55, (copy) v_u_20, (copy) v_u_22, (copy) v_u_68, (copy) v_u_62, (copy) v_u_7, (copy) v_u_11, (copy) v_u_1, (copy) v_u_8, (copy) v_u_59, (copy) v_u_23, (copy) v_u_21, (copy) v_u_4, (copy) v_u_19
	local v_u_72 = v_u_3:WaitForChild(v_u_5.REMOTES):WaitForChild(v_u_6.REMOTE)
	local v73 = {}
	local v_u_74 = v_u_9.new("Frame", {
		["Name"] = "ShopApp",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["Visible"] = false,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_16,
		["Size"] = UDim2.fromScale(1, 1),
		["Parent"] = p69
	})
	local v_u_75 = v_u_9.new("UIScale", {
		["Parent"] = v_u_74
	})
	v73.frame = v_u_74
	local v76 = v_u_9.new("Frame", {
		["Name"] = "Header",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_13,
		["Size"] = UDim2.new(1, 0, 0, 92),
		["Parent"] = v_u_74
	})
	v_u_9.new("UIGradient", {
		["Rotation"] = 25,
		["Color"] = nil,
		["Parent"] = nil,
		["Color"] = ColorSequence.new(v_u_17, v_u_18),
		["Parent"] = v76
	})
	local v77 = v_u_9.new("TextButton", {
		["Name"] = "Back",
		["Text"] = "",
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Position"] = UDim2.fromOffset(4, 42),
		["Size"] = UDim2.fromOffset(36, 44),
		["Parent"] = v76
	})
	local v78 = v_u_10.make("arrow", v_u_13, 20)
	v78.AnchorPoint = Vector2.new(0.5, 0.5)
	v78.Position = UDim2.fromScale(0.5, 0.5)
	v78.Parent = v77
	v77.Activated:Connect(function()
		-- upvalues: (copy) p_u_70
		p_u_70()
	end)
	v_u_41(v76, "Shop", 42, 40, nil, 26, 22, v_u_13, true)
	local v_u_79 = v_u_41(v76, "", 42, 66, nil, 16, 12, v_u_13, false, {
		["TextTransparency"] = 0.1
	})
	local v80 = v_u_9.new("ScrollingFrame", {
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["CanvasSize"] = nil,
		["AutomaticCanvasSize"] = nil,
		["ScrollBarThickness"] = 3,
		["Parent"] = nil,
		["Position"] = UDim2.fromOffset(0, 92),
		["Size"] = UDim2.new(1, 0, 1, -92),
		["CanvasSize"] = UDim2.new(),
		["AutomaticCanvasSize"] = Enum.AutomaticSize.Y,
		["Parent"] = v_u_74
	})
	v_u_9.new("UIListLayout", {
		["Padding"] = UDim.new(0, 12),
		["SortOrder"] = Enum.SortOrder.LayoutOrder,
		["Parent"] = v80
	})
	v_u_9.new("UIPadding", {
		["PaddingTop"] = UDim.new(0, 12),
		["PaddingLeft"] = UDim.new(0, 14),
		["PaddingRight"] = UDim.new(0, 14),
		["PaddingBottom"] = UDim.new(0, 30),
		["Parent"] = v80
	})
	local v_u_81 = {}
	local v_u_82 = {}
	local v_u_83 = {}
	for v84, v_u_85 in v_u_6.ITEMS do
		if v_u_85.hidden then
			continue
		end
		local v86 = v_u_9.new("Frame", {
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["LayoutOrder"] = nil,
			["Parent"] = nil,
			["BackgroundColor3"] = v_u_13,
			["Size"] = UDim2.new(1, 0, 0, 150),
			["LayoutOrder"] = v84,
			["Parent"] = v80
		})
		v_u_9.corner(v86, 16)
		local v87 = v_u_9.new("Frame", {
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["BackgroundColor3"] = v_u_13,
			["Position"] = UDim2.fromOffset(12, 14),
			["Size"] = UDim2.fromOffset(52, 52),
			["Parent"] = v86
		})
		v_u_9.corner(v87, 14)
		v_u_9.new("UIGradient", {
			["Rotation"] = 90,
			["Color"] = nil,
			["Parent"] = nil,
			["Color"] = ColorSequence.new(v_u_85.colors[1], v_u_85.colors[2]),
			["Parent"] = v87
		})
		local v88 = v_u_10.make(v_u_85.icon, v_u_13, 30)
		v88.AnchorPoint = Vector2.new(0.5, 0.5)
		v88.Position = UDim2.fromScale(0.5, 0.5)
		v88.Parent = v87
		v_u_41(v86, v_u_85.name, 76, 12, nil, 22, 17, v_u_14, true)
		v_u_41(v86, v_u_85.th, 76, 34, nil, 18, 13, v_u_15, false)
		v_u_41(v86, v_u_85.line, 12, 74, nil, 18, 12, v_u_15, false, {
			["TextWrapped"] = true,
			["Size"] = nil,
			["Size"] = UDim2.new(1, -24, 0, 30)
		})
		v_u_81[v_u_85.id] = v_u_41(v86, "", 76, 52, nil, 16, 12, Color3.fromRGB(30, 150, 80), true)
		local v89, v90 = v_u_55(v86, "Buy  " .. v_u_5.formatCash(v_u_85.price), { Color3.fromRGB(255, 196, 46), Color3.fromRGB(236, 140, 14) }, UDim2.fromOffset(12, 0), 100, UDim2.new(0.5, -18, 0, 0), 40, v_u_14)
		v_u_82[v_u_85.id] = v90
		local v91 = v_u_41
		local v92
		if v_u_85.shop then
			v92 = ("\224\184\139\224\184\183\224\185\137\224\184\173 / \224\184\149\224\184\180\224\184\148 / \224\184\150\224\184\173\224\184\148 \224\184\151\224\184\181\224\185\136\224\184\163\224\185\137\224\184\178\224\184\153 %s \224\184\139\224\184\173\224\184\162 42 (\224\184\136\224\184\173\224\184\148\224\184\163\224\184\150\224\185\131\224\184\153\224\184\138\224\185\136\224\184\173\224\184\135\224\184\149\224\184\180\224\184\148\224\184\149\224\184\177\224\185\137\224\184\135)"):format(v_u_85.shop)
		else
			v92 = v_u_85.once and "On a bike: U (the 360 button)" or "Hold it, then hold-press your vehicle"
		end
		local v93 = v91(v86, v92, 0, 106, nil, 30, 11, v_u_15, false, {
			["Position"] = nil,
			["Size"] = nil,
			["TextWrapped"] = true,
			["TextTruncate"] = nil,
			["Position"] = UDim2.new(0.5, 4, 0, 104),
			["Size"] = UDim2.new(0.5, -16, 0, 34),
			["TextTruncate"] = Enum.TextTruncate.None
		})
		local v94, v95, v96 = v_u_55(v86, "Equip", v_u_20, UDim2.new(0.5, 4, 0, 0), 100, UDim2.new(0.25, -8, 0, 0), 40)
		local v97, v98, v99 = v_u_55(v86, "Unequip", v_u_22, UDim2.new(0.75, 0, 0, 0), 100, UDim2.new(0.25, -12, 0, 0), 40)
		v95.TextSize = 13
		v98.TextSize = 13
		v94.Visible = false
		v97.Visible = false
		v_u_83[v_u_85.id] = {
			["buy"] = v89,
			["hint"] = v93,
			["equip"] = v94,
			["equipText"] = v95,
			["equipGrad"] = v96,
			["unequip"] = v97,
			["unequipText"] = v98,
			["unequipGrad"] = v99
		}
		v94.Activated:Connect(function()
			-- upvalues: (ref) v_u_68, (copy) v_u_85, (ref) v_u_62, (ref) v_u_3, (ref) v_u_7, (ref) v_u_11, (ref) v_u_1, (ref) v_u_8, (ref) v_u_59, (ref) v_u_23, (copy) p_u_71
			if v_u_68(v_u_85) then
				return
			elseif v_u_85.id == "Cam360" then
				local v100 = v_u_62()
				local v101 = v_u_3:FindFirstChild(v_u_7.REMOTE_NAME)
				if v100 and v101 then
					v_u_1.fire(v101, "Cam360", v_u_8.ORDER[1])
					v_u_11.show("360 camera on: on the handlebar (U: tail / off)", "ok")
				else
					v_u_11.show("Get on your own bike first, then Equip (or press U on it)", "info")
				end
			else
				local v102 = v_u_59(v_u_85.id)
				local v103 = v_u_23.Character
				if v103 then
					v103 = v_u_23.Character:FindFirstChildOfClass("Humanoid")
				end
				if v102 and v103 then
					v103:EquipTool(v102)
					v_u_11.show(("Holding the %s: hold-press your vehicle"):format(v_u_85.name:lower()), "ok")
					p_u_71()
				else
					v_u_11.show("Not in your bag yet: try again in a moment", "error")
				end
			end
		end)
		v97.Activated:Connect(function()
			-- upvalues: (ref) v_u_68, (copy) v_u_85, (ref) v_u_62, (ref) v_u_3, (ref) v_u_7, (ref) v_u_11, (ref) v_u_1, (ref) v_u_23
			if v_u_68(v_u_85) then
				if v_u_85.id == "Cam360" then
					local v104 = v_u_62()
					local v105 = v_u_3:FindFirstChild(v_u_7.REMOTE_NAME)
					if v104 and v105 then
						v_u_1.fire(v105, "Cam360", "Off")
						v_u_11.show("360 camera off", "ok")
					else
						v_u_11.show("Get on the bike to take its 360 camera off", "info")
					end
				else
					local v106 = v_u_23.Character
					if v106 then
						v106 = v_u_23.Character:FindFirstChildOfClass("Humanoid")
					end
					if v106 then
						v106:UnequipTools()
					end
					return
				end
			else
				return
			end
		end)
		v89.Activated:Connect(function()
			-- upvalues: (ref) v_u_1, (copy) v_u_72, (copy) v_u_85, (ref) v_u_11
			local v107 = v_u_1.invoke
			local v108 = v_u_72
			local v109 = v_u_85.id
			local v110, v111, v112 = pcall(v107, v108, "Buy", v109)
			v_u_11.show(v110 and v112 and v112 or "Couldn\'t reach the shop", v110 and v111 and "ok" or "error")
		end)
	end
	local function v_u_141() -- name: refresh
		-- upvalues: (copy) v_u_79, (ref) v_u_5, (ref) v_u_23, (ref) v_u_6, (copy) v_u_81, (copy) v_u_82, (ref) v_u_15, (copy) v_u_83, (ref) v_u_68, (ref) v_u_22, (ref) v_u_20, (ref) v_u_21, (ref) v_u_13
		v_u_79.Text = "Your money " .. v_u_5.formatCash(v_u_23:GetAttribute("Cash") or 0)
		for _, v113 in v_u_6.ITEMS do
			if v113.hidden then
				continue
			end
			local v114 = v_u_6.count(v_u_23, v113.id)
			if v113.once then
				v_u_81[v113.id].Text = v114 > 0 and "Yours" or "Not yours yet"
				v_u_82[v113.id].Text = v114 > 0 and "Owned" or "Buy  " .. v_u_5.formatCash(v113.price)
			else
				v_u_81[v113.id].Text = v114 <= 0 and "You have none" or ("You have %d"):format(v114)
			end
			local v115 = v_u_81[v113.id]
			local v116
			if v114 > 0 then
				v116 = Color3.fromRGB(30, 150, 80)
			else
				v116 = v_u_15
			end
			v115.TextColor3 = v116
			if v113.shop then
				local v117 = v_u_83[v113.id]
				local v118 = v117.buy
				local v119 = v117.equip
				local v120 = v117.unequip
				v118.Visible = false
				v119.Visible = false
				v120.Visible = false
				v117.hint.Visible = true
				v117.hint.Position = UDim2.new(0, 12, 0, 104)
				v117.hint.Size = UDim2.new(1, -24, 0, 34)
			else
				local v121 = v_u_83[v113.id]
				local v122 = v114 > 0
				local v123 = v113.once and v122
				v121.buy.Visible = not v123
				v121.hint.Visible = not v122
				local v124 = v121.equip
				local v125 = v121.unequip
				v124.Visible = v122
				v125.Visible = v122
				local v126 = v121.equip
				local v127
				if v123 then
					v127 = UDim2.new(0, 12, 0, 100)
				else
					v127 = UDim2.new(0.5, 4, 0, 100)
				end
				v126.Position = v127
				local v128 = v121.equip
				local v129
				if v123 then
					v129 = UDim2.new(0.5, -18, 0, 40)
				else
					v129 = UDim2.new(0.25, -8, 0, 40)
				end
				v128.Size = v129
				local v130 = v121.unequip
				local v131
				if v123 then
					v131 = UDim2.new(0.5, 4, 0, 100)
				else
					v131 = UDim2.new(0.75, 0, 0, 100)
				end
				v130.Position = v131
				local v132 = v121.unequip
				local v133
				if v123 then
					v133 = UDim2.new(0.5, -16, 0, 40)
				else
					v133 = UDim2.new(0.25, -12, 0, 40)
				end
				v132.Size = v133
				if not v122 then
					continue
				end
				local v134 = v_u_68(v113)
				local v135
				if v134 then
					v135 = v_u_22
				else
					v135 = v_u_20
				end
				local v136
				if v134 then
					v136 = v_u_21
				else
					v136 = v_u_22
				end
				v121.equipGrad.Color = ColorSequence.new(v135[1], v135[2])
				v121.unequipGrad.Color = ColorSequence.new(v136[1], v136[2])
				v121.equipText.Text = v134 and "Equipped" or "Equip"
				local v137 = v121.equipText
				local v138
				if v134 then
					v138 = v_u_15
				else
					v138 = v_u_13
				end
				v137.TextColor3 = v138
				local v139 = v121.unequipText
				local v140
				if v134 then
					v140 = v_u_13
				else
					v140 = v_u_15
				end
				v139.TextColor3 = v140
			end
		end
	end
	v_u_23.AttributeChanged:Connect(function(p142)
		-- upvalues: (copy) v_u_141
		if p142 == "Cash" or p142:sub(1, 5) == "Item_" then
			v_u_141()
		end
	end)
	local v_u_143 = false
	function v73.show() -- name: show
		-- upvalues: (ref) v_u_143, (copy) v_u_74, (copy) v_u_141, (copy) v_u_75, (ref) v_u_4, (ref) v_u_19
		local v144 = not v_u_143
		v_u_143 = true
		v_u_74.Visible = true
		v_u_141()
		if v144 then
			task.spawn(function()
				-- upvalues: (ref) v_u_143, (ref) v_u_141
				while v_u_143 do
					task.wait(0.4)
					if not v_u_143 then
						continue
					end
					v_u_141()
				end
			end)
		end
		v_u_75.Scale = 0.92
		v_u_4:Create(v_u_75, v_u_19, {
			["Scale"] = 1
		}):Play()
	end
	function v73.hide() -- name: hide
		-- upvalues: (ref) v_u_143, (copy) v_u_74
		v_u_143 = false
		v_u_74.Visible = false
	end
	function v73.isShown() -- name: isShown
		-- upvalues: (ref) v_u_143
		return v_u_143
	end
	return v73
end
return v12