-- Path: Workspace/BebeqCat/Config
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

return {
	["DETECT_RADIUS"] = 20,
	["IDLE_DIST"] = 8,
	["RESUME_DIST"] = 10,
	["LOSE_RADIUS"] = 30,
	["MOVE_SPEED"] = 36,
	["RETURN_SPEED"] = 25,
	["CAT_HALF_HEIGHT"] = 0.1,
	["Y_LERP_SPEED"] = 8
}