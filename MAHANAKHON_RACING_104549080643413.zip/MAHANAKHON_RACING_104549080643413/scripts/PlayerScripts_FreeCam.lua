-- Path: Players/ygggggg55551/PlayerScripts/FreeCam
-- Class: LocalScript  true/Enum.RunContext.Legacy
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = require(game:GetService("ReplicatedStorage"):WaitForChild("UiOwn")).Instance
local v_u_2 = game:GetService("ContextActionService")
local v3 = game:GetService("Players")
local v_u_4 = game:GetService("ProximityPromptService")
local v_u_5 = game:GetService("RunService")
local v_u_6 = game:GetService("StarterGui")
local v_u_7 = game:GetService("UserInputService")
local v_u_8 = v3.LocalPlayer
local v_u_9 = workspace.CurrentCamera
local v_u_10 = Enum.KeyCode.Y
local v_u_11 = {
	1,
	2,
	4,
	8,
	16,
	32,
	64
}
local v_u_12 = false
local v_u_13 = 3
local v_u_14 = Vector3.new(0, 0, 0)
local v_u_15 = Vector3.new(0, 0, 0)
local v_u_16 = 0
local v_u_17 = 0
local v_u_18 = 0
local v_u_19 = 0
local v_u_20 = 0
local v_u_21 = 0
local v_u_22 = 70
local v_u_23 = 70
local v_u_24 = {}
local v_u_25 = {
	["move"] = Vector3.new(0, 0, 0),
	["look"] = nil,
	["up"] = 0,
	["down"] = 0,
	["look"] = Vector2.zero
}
local v_u_26 = Vector2.zero
local v_u_27 = 0
local v_u_28 = 0
local v_u_29 = nil
local v_u_30 = v_u_7.TouchEnabled
local v_u_31 = false
local v_u_32 = nil
local v_u_33 = v_u_1.new("ScreenGui")
v_u_33.Name = "FreeCamUI"
v_u_33.ResetOnSpawn = false
v_u_33.IgnoreGuiInset = true
v_u_33.DisplayOrder = 50
v_u_33.Parent = v_u_8:WaitForChild("PlayerGui")
local v_u_34 = v_u_1.new("TextLabel")
v_u_34.Name = "Help"
v_u_34.AnchorPoint = Vector2.new(0.5, 1)
v_u_34.Position = UDim2.new(0.5, 0, 1, -16)
v_u_34.Size = UDim2.fromOffset(640, 54)
v_u_34.BackgroundColor3 = Color3.fromRGB(16, 17, 19)
v_u_34.BackgroundTransparency = 0.25
v_u_34.TextColor3 = Color3.fromRGB(235, 236, 238)
v_u_34.TextSize = 15
v_u_34.Font = Enum.Font.GothamMedium
v_u_34.TextWrapped = true
v_u_34.Visible = false
v_u_34.Text = "Free camera  \194\183  Mouse: look  \194\183  W A S D: move  \194\183  E/Q: up/down  \194\183  Shift: slow  \194\183  Wheel: zoom  \194\183  - / =: speed\nHold R + mouse: tilt  \194\183  H: hide help  \194\183  Y: exit"
v_u_34.Parent = v_u_33
local v_u_35 = v_u_1.new("UICorner")
v_u_35.CornerRadius = UDim.new(0, 8)
v_u_35.Parent = v_u_34
local v_u_36 = require(game:GetService("ReplicatedStorage"):WaitForChild("UiOwn")).clone(v_u_34)
v_u_36.Name = "Speed"
v_u_36.AnchorPoint = Vector2.new(0.5, 0)
v_u_36.Position = UDim2.new(0.5, 0, 0, 16)
v_u_36.Size = UDim2.fromOffset(220, 30)
v_u_36.Parent = v_u_33
local v_u_37 = v_u_1.new("TextButton")
v_u_37.Name = "Toggle"
v_u_37.AnchorPoint = Vector2.new(1, 0)
v_u_37.Position = UDim2.new(1, -12, 0, 60)
v_u_37.Size = UDim2.fromOffset(64, 34)
v_u_37.BackgroundColor3 = Color3.fromRGB(16, 17, 19)
v_u_37.BackgroundTransparency = 0.3
v_u_37.TextColor3 = Color3.new(1, 1, 1)
v_u_37.Font = Enum.Font.GothamBold
v_u_37.TextSize = 14
v_u_37.Text = "Camera"
v_u_37.Visible = false
v_u_37.Parent = v_u_33
local v38 = v_u_1.new("BindableEvent")
v38.Name = "ToggleFreeCam"
v38.Parent = v_u_33
v_u_35:Clone().Parent = v_u_37
if v_u_7.TouchEnabled then
	local v39 = v_u_9.ViewportSize.X
	local v40 = v_u_9.ViewportSize.Y
	if math.min(v39, v40) <= 500 then
		v_u_37.Size = UDim2.fromOffset(54, 28)
		v_u_37.TextSize = 12
	end
end
local v_u_41 = v_u_1.new("Frame")
v_u_41.Name = "TouchPad"
v_u_41.AnchorPoint = Vector2.new(1, 0.5)
v_u_41.Position = UDim2.new(1, -16, 0.5, 20)
v_u_41.Size = UDim2.fromOffset(150, 288)
v_u_41.BackgroundTransparency = 1
v_u_41.Visible = false
v_u_41.Parent = v_u_33
local v_u_42 = v_u_1.new("UIScale")
v_u_42.Parent = v_u_41
local v43 = v_u_9.ViewportSize.Y / 540
v_u_42.Scale = math.clamp(v43, 0.7, 1.2)
v_u_9:GetPropertyChangedSignal("ViewportSize"):Connect(function() -- name: fitPad
	-- upvalues: (copy) v_u_42, (copy) v_u_9
	local v44 = v_u_42
	local v45 = v_u_9.ViewportSize.Y / 540
	v44.Scale = math.clamp(v45, 0.7, 1.2)
end)
local function v53(p46, p47, p48, p49, p50, p51) -- name: padButton
	-- upvalues: (copy) v_u_1, (copy) v_u_41, (copy) v_u_35
	local v52 = v_u_1.new("TextButton")
	v52.Name = p46
	v52.Position = UDim2.fromOffset(p48, p49)
	v52.Size = UDim2.fromOffset(p50, p51)
	v52.BackgroundColor3 = Color3.fromRGB(16, 17, 19)
	v52.BackgroundTransparency = 0.35
	v52.TextColor3 = Color3.new(1, 1, 1)
	v52.Font = Enum.Font.GothamBold
	v52.TextSize = 17
	v52.Text = p47
	v52.AutoButtonColor = true
	v52.Parent = v_u_41
	v_u_35:Clone().Parent = v52
	return v52
end
local function v58(p54, p_u_55) -- name: holdButton
	-- upvalues: (ref) v_u_27
	p54.InputBegan:Connect(function(p56)
		-- upvalues: (ref) v_u_27, (copy) p_u_55
		if p56.UserInputType == Enum.UserInputType.Touch and true or p56.UserInputType == Enum.UserInputType.MouseButton1 then
			v_u_27 = p_u_55
		end
	end)
	p54.InputEnded:Connect(function(p57)
		-- upvalues: (ref) v_u_27, (copy) p_u_55
		if (p57.UserInputType == Enum.UserInputType.Touch and true or p57.UserInputType == Enum.UserInputType.MouseButton1) and v_u_27 == p_u_55 then
			v_u_27 = 0
		end
	end)
end
local function v63(p59, p_u_60) -- name: zoomButton
	-- upvalues: (ref) v_u_28
	p59.InputBegan:Connect(function(p61)
		-- upvalues: (ref) v_u_28, (copy) p_u_60
		if p61.UserInputType == Enum.UserInputType.Touch and true or p61.UserInputType == Enum.UserInputType.MouseButton1 then
			v_u_28 = p_u_60
		end
	end)
	p59.InputEnded:Connect(function(p62)
		-- upvalues: (ref) v_u_28, (copy) p_u_60
		if (p62.UserInputType == Enum.UserInputType.Touch and true or p62.UserInputType == Enum.UserInputType.MouseButton1) and v_u_28 == p_u_60 then
			v_u_28 = 0
		end
	end)
end
v58(v53("Up", "Up", 0, 0, 150, 64), 1)
v58(v53("Down", "Down", 0, 70, 150, 64), -1)
local v64 = v53("Slower", "Slower -", 0, 140, 72, 44)
local v65 = v53("Faster", "Faster +", 78, 140, 72, 44)
v63(v53("ZoomOut", "Zoom -", 0, 192, 72, 44), -1)
v63(v53("ZoomIn", "Zoom +", 78, 192, 72, 44), 1)
local v66 = v53("HideUI", "Hide UI", 0, 244, 150, 44)
v66.TextSize = 15
local v_u_67 = v_u_1.new("TextButton")
v_u_67.Name = "ShowUI"
v_u_67.AnchorPoint = Vector2.new(1, 0)
v_u_67.Position = UDim2.new(1, -8, 0, 8)
v_u_67.Size = UDim2.fromOffset(52, 28)
v_u_67.BackgroundColor3 = Color3.fromRGB(16, 17, 19)
v_u_67.BackgroundTransparency = 0.85
v_u_67.TextColor3 = Color3.new(1, 1, 1)
v_u_67.TextTransparency = 0.6
v_u_67.Font = Enum.Font.GothamBold
v_u_67.TextSize = 12
v_u_67.Text = "Show"
v_u_67.Visible = false
v_u_67.Parent = v_u_33
v_u_35:Clone().Parent = v_u_67
local v_u_68 = v_u_1.new("Frame")
v_u_68.Name = "Stick"
v_u_68.AnchorPoint = Vector2.new(0, 1)
v_u_68.Position = UDim2.new(0, 40, 1, -30)
v_u_68.Size = UDim2.fromOffset(150, 150)
v_u_68.BackgroundColor3 = Color3.fromRGB(16, 17, 19)
v_u_68.BackgroundTransparency = 0.55
v_u_68.Visible = false
v_u_68.Active = true
v_u_68.Parent = v_u_33
local v69 = v_u_1.new("UICorner")
v69.CornerRadius = UDim.new(0.5, 0)
v69.Parent = v_u_68
local v_u_70 = v_u_1.new("UIScale")
v_u_70.Parent = v_u_68
local v_u_71 = v_u_1.new("Frame")
v_u_71.Name = "Knob"
v_u_71.AnchorPoint = Vector2.new(0.5, 0.5)
v_u_71.Position = UDim2.fromScale(0.5, 0.5)
v_u_71.Size = UDim2.fromOffset(62, 62)
v_u_71.BackgroundColor3 = Color3.new(1, 1, 1)
v_u_71.BackgroundTransparency = 0.25
v_u_71.Parent = v_u_68
v69:Clone().Parent = v_u_71
local v_u_72 = nil
local v73 = v_u_9.ViewportSize.Y / 540
v_u_70.Scale = math.clamp(v73, 0.7, 1.2)
v_u_9:GetPropertyChangedSignal("ViewportSize"):Connect(function() -- name: fitStick
	-- upvalues: (copy) v_u_70, (copy) v_u_9
	local v74 = v_u_70
	local v75 = v_u_9.ViewportSize.Y / 540
	v74.Scale = math.clamp(v75, 0.7, 1.2)
end)
local function v_u_81(p76) -- name: moveStick
	-- upvalues: (copy) v_u_68, (copy) v_u_71, (ref) v_u_26
	local v77 = v_u_68.AbsolutePosition + v_u_68.AbsoluteSize / 2
	local v78 = v_u_68.AbsoluteSize.X / 2
	local v79 = Vector2.new(p76.X, p76.Y) - v77
	if v78 < v79.Magnitude then
		v79 = v79.Unit * v78
	end
	local v80 = v79 / v78
	v_u_71.Position = UDim2.fromScale(0.5 + v80.X / 2, 0.5 + v80.Y / 2)
	v_u_26 = v80
end
v_u_68.InputBegan:Connect(function(p82)
	-- upvalues: (ref) v_u_72, (copy) v_u_81
	if p82.UserInputType == Enum.UserInputType.Touch or p82.UserInputType == Enum.UserInputType.MouseButton1 then
		v_u_72 = p82
		v_u_81(p82.Position)
	end
end)
v_u_7.InputChanged:Connect(function(p83)
	-- upvalues: (ref) v_u_72, (copy) v_u_81
	if v_u_72 and (p83 == v_u_72 or p83.UserInputType == Enum.UserInputType.MouseMovement and v_u_72.UserInputType == Enum.UserInputType.MouseButton1) then
		v_u_81(p83.Position)
	end
end)
v_u_7.InputEnded:Connect(function(p84)
	-- upvalues: (ref) v_u_72, (ref) v_u_26, (copy) v_u_71
	if v_u_72 and (p84 == v_u_72 or p84.UserInputType == Enum.UserInputType.MouseButton1) then
		v_u_72 = nil
		v_u_26 = Vector2.zero
		v_u_71.Position = UDim2.fromScale(0.5, 0.5)
	end
end)
local v_u_85 = 0
local function v_u_89() -- name: playerControls
	-- upvalues: (copy) v_u_8
	local v_u_86 = v_u_8:FindFirstChild("PlayerScripts")
	if v_u_86 then
		v_u_86 = v_u_8.PlayerScripts:FindFirstChild("PlayerModule")
	end
	if not v_u_86 then
		return nil
	end
	local v87, v88 = pcall(function()
		-- upvalues: (copy) v_u_86
		return require(v_u_86):GetControls()
	end)
	return v87 and v88 and v88 or nil
end
local v_u_90 = {
	Enum.KeyCode.W,
	Enum.KeyCode.A,
	Enum.KeyCode.S,
	Enum.KeyCode.D,
	Enum.KeyCode.E,
	Enum.KeyCode.Q,
	Enum.KeyCode.Up,
	Enum.KeyCode.Down,
	Enum.KeyCode.Left,
	Enum.KeyCode.Right,
	Enum.KeyCode.LeftShift,
	Enum.KeyCode.RightShift,
	Enum.KeyCode.Space,
	Enum.KeyCode.R,
	Enum.KeyCode.H,
	Enum.KeyCode.Minus,
	Enum.KeyCode.Equals,
	Enum.KeyCode.LeftControl,
	Enum.KeyCode.Thumbstick1,
	Enum.KeyCode.Thumbstick2,
	Enum.KeyCode.ButtonL2,
	Enum.KeyCode.ButtonR2,
	Enum.KeyCode.DPadUp,
	Enum.KeyCode.DPadDown,
	Enum.KeyCode.ButtonA,
	Enum.KeyCode.ButtonB,
	Enum.UserInputType.MouseWheel,
	Enum.UserInputType.MouseMovement
}
local function v_u_126(_, p91, p92) -- name: onInput
	-- upvalues: (ref) v_u_23, (copy) v_u_36, (ref) v_u_13, (copy) v_u_11, (ref) v_u_85, (copy) v_u_24, (ref) v_u_21, (ref) v_u_19, (ref) v_u_20, (ref) v_u_25, (copy) v_u_34
	local v93 = p92.KeyCode
	if p92.UserInputType ~= Enum.UserInputType.MouseWheel then
		if p92.UserInputType ~= Enum.UserInputType.MouseMovement then
			if v93 == Enum.KeyCode.Thumbstick1 then
				local v94 = v_u_25
				local v95 = p92.Position.X
				local v96 = -p92.Position.Y
				v94.move = Vector3.new(v95, 0, v96)
			elseif v93 == Enum.KeyCode.Thumbstick2 then
				v_u_25.look = Vector2.new(p92.Position.X, p92.Position.Y)
			elseif v93 == Enum.KeyCode.ButtonL2 then
				v_u_25.down = p92.Position.Z
			elseif v93 == Enum.KeyCode.ButtonR2 then
				v_u_25.up = p92.Position.Z
			elseif p91 == Enum.UserInputState.Begin then
				v_u_24[v93] = true
				if v93 == Enum.KeyCode.Minus then
					local v97 = v_u_13 - 1
					v_u_13 = math.max(1, v97)
					local v98 = v_u_36
					local v99 = v_u_13
					local v100 = #v_u_11
					local v101 = v_u_23 + 0.5
					v98.Text = ("Speed %d/%d  \194\183  FOV %d\194\176"):format(v99, v100, (math.floor(v101)))
					v_u_36.Visible = true
					v_u_85 = os.clock() + 1.2
				elseif v93 == Enum.KeyCode.Equals then
					local v102 = #v_u_11
					local v103 = v_u_13 + 1
					v_u_13 = math.min(v102, v103)
					local v104 = v_u_36
					local v105 = v_u_13
					local v106 = #v_u_11
					local v107 = v_u_23 + 0.5
					v104.Text = ("Speed %d/%d  \194\183  FOV %d\194\176"):format(v105, v106, (math.floor(v107)))
					v_u_36.Visible = true
					v_u_85 = os.clock() + 1.2
				elseif v93 == Enum.KeyCode.H then
					v_u_34.Visible = not v_u_34.Visible
				elseif v93 == Enum.KeyCode.R then
					v_u_24.rolled = false
				elseif v93 == Enum.KeyCode.DPadUp then
					local v108 = v_u_23 - 8
					v_u_23 = math.clamp(v108, 15, 100)
					local v109 = v_u_36
					local v110 = v_u_13
					local v111 = #v_u_11
					local v112 = v_u_23 + 0.5
					v109.Text = ("Speed %d/%d  \194\183  FOV %d\194\176"):format(v110, v111, (math.floor(v112)))
					v_u_36.Visible = true
					v_u_85 = os.clock() + 1.2
				elseif v93 == Enum.KeyCode.DPadDown then
					local v113 = v_u_23 + 8
					v_u_23 = math.clamp(v113, 15, 100)
					local v114 = v_u_36
					local v115 = v_u_13
					local v116 = #v_u_11
					local v117 = v_u_23 + 0.5
					v114.Text = ("Speed %d/%d  \194\183  FOV %d\194\176"):format(v115, v116, (math.floor(v117)))
					v_u_36.Visible = true
					v_u_85 = os.clock() + 1.2
				end
			elseif p91 == Enum.UserInputState.End then
				if v93 == Enum.KeyCode.R and not v_u_24.rolled then
					v_u_21 = 0
				end
				v_u_24[v93] = nil
			end
			return Enum.ContextActionResult.Sink
		end
		local v118 = p92.Delta
		if v_u_24[Enum.KeyCode.R] then
			v_u_21 = v_u_21 - v118.X * 0.0025
			v_u_24.rolled = true
		else
			local v119 = v_u_23 / 70 * 0.0025
			v_u_19 = v_u_19 - v118.X * v119
			local v120 = v_u_20 - v118.Y * v119
			v_u_20 = math.clamp(v120, -1.5, 1.5)
		end
		return Enum.ContextActionResult.Sink
	end
	local v121 = v_u_23 - p92.Position.Z * 4
	v_u_23 = math.clamp(v121, 15, 100)
	local v122 = v_u_36
	local v123 = v_u_13
	local v124 = #v_u_11
	local v125 = v_u_23 + 0.5
	v122.Text = ("Speed %d/%d  \194\183  FOV %d\194\176"):format(v123, v124, (math.floor(v125)))
	v_u_36.Visible = true
	v_u_85 = os.clock() + 1.2
	return Enum.ContextActionResult.Sink
end
local function v_u_164(p127) -- name: step
	-- upvalues: (copy) v_u_7, (ref) v_u_28, (ref) v_u_23, (ref) v_u_31, (copy) v_u_36, (ref) v_u_13, (copy) v_u_11, (ref) v_u_85, (ref) v_u_19, (ref) v_u_25, (ref) v_u_20, (ref) v_u_16, (ref) v_u_17, (ref) v_u_18, (ref) v_u_21, (ref) v_u_22, (copy) v_u_24, (ref) v_u_26, (ref) v_u_27, (ref) v_u_15, (ref) v_u_14, (copy) v_u_9
	if v_u_7.MouseBehavior ~= Enum.MouseBehavior.LockCenter then
		v_u_7.MouseBehavior = Enum.MouseBehavior.LockCenter
	end
	local v128 = math.min(p127, 0.1)
	if v_u_28 ~= 0 then
		local v129 = v_u_23 - v_u_28 * 35 * v128
		v_u_23 = math.clamp(v129, 15, 100)
		if not v_u_31 then
			local v130 = v_u_36
			local v131 = v_u_13
			local v132 = #v_u_11
			local v133 = v_u_23 + 0.5
			v130.Text = ("Speed %d/%d  \194\183  FOV %d\194\176"):format(v131, v132, (math.floor(v133)))
			v_u_36.Visible = true
			v_u_85 = os.clock() + 1.2
		end
	end
	v_u_19 = v_u_19 - v_u_25.look.X * 2.4 * v128 * (v_u_23 / 70)
	local v134 = v_u_20 + v_u_25.look.Y * 2.4 * v128 * (v_u_23 / 70)
	v_u_20 = math.clamp(v134, -1.5, 1.5)
	local v135 = -5 * v128
	local v136 = 1 - math.exp(v135)
	v_u_16 = v_u_16 + (v_u_19 - v_u_16) * v136
	v_u_17 = v_u_17 + (v_u_20 - v_u_17) * v136
	v_u_18 = v_u_18 + (v_u_21 - v_u_18) * v136
	local v137 = v_u_22
	local v138 = v_u_23 - v_u_22
	local v139 = -3 * v128
	v_u_22 = v137 + v138 * (1 - math.exp(v139))
	local v140 = CFrame.fromEulerAnglesYXZ(v_u_17, v_u_16, 0) * CFrame.Angles(0, 0, v_u_18)
	local v141 = Enum.KeyCode.D
	local v142 = Enum.KeyCode.A
	local v143 = (v_u_24[v141] and 1 or 0) - (v_u_24[v142] and 1 or 0)
	local v144 = Enum.KeyCode.Right
	local v145 = Enum.KeyCode.Left
	local v146 = v143 + ((v_u_24[v144] and 1 or 0) - (v_u_24[v145] and 1 or 0)) + v_u_26.X
	local v147 = Enum.KeyCode.E
	local v148 = Enum.KeyCode.Q
	local v149 = (v_u_24[v147] and 1 or 0) - (v_u_24[v148] and 1 or 0) + v_u_25.up - v_u_25.down + v_u_27
	local v150 = Enum.KeyCode.S
	local v151 = Enum.KeyCode.W
	local v152 = (v_u_24[v150] and 1 or 0) - (v_u_24[v151] and 1 or 0)
	local v153 = Enum.KeyCode.Down
	local v154 = Enum.KeyCode.Up
	local v155 = v152 + ((v_u_24[v153] and 1 or 0) - (v_u_24[v154] and 1 or 0)) + v_u_26.Y
	local v156 = Vector3.new(v146, v149, v155) + v_u_25.move
	if v156.Magnitude > 1 then
		v156 = v156.Unit
	end
	local v157 = v_u_11[v_u_13]
	if v_u_24[Enum.KeyCode.LeftShift] or v_u_24[Enum.KeyCode.RightShift] then
		v157 = v157 * 0.3
	end
	local v158 = CFrame.fromEulerAnglesYXZ(0, v_u_16, 0)
	local v159 = v156.X
	local v160 = v156.Z
	local v161 = v_u_15
	local v162 = v140:VectorToWorldSpace((Vector3.new(v159, 0, v160))) * v157 + v158.UpVector * v156.Y * v157 - v_u_15
	local v163 = -2 * v128
	v_u_15 = v161 + v162 * (1 - math.exp(v163))
	v_u_14 = v_u_14 + v_u_15 * v128
	v_u_9.CameraType = Enum.CameraType.Scriptable
	v_u_9.CFrame = CFrame.new(v_u_14) * v140
	v_u_9.FieldOfView = v_u_22
	if v_u_36.Visible and v_u_85 < os.clock() then
		v_u_36.Visible = false
	end
end
local function v_u_184() -- name: start
	-- upvalues: (ref) v_u_12, (copy) v_u_9, (ref) v_u_14, (ref) v_u_15, (ref) v_u_17, (ref) v_u_16, (ref) v_u_18, (ref) v_u_20, (ref) v_u_19, (ref) v_u_21, (ref) v_u_22, (ref) v_u_23, (copy) v_u_24, (ref) v_u_25, (ref) v_u_32, (copy) v_u_7, (copy) v_u_8, (copy) v_u_33, (copy) v_u_6, (copy) v_u_4, (copy) v_u_89, (copy) v_u_2, (copy) v_u_126, (copy) v_u_90, (copy) v_u_5, (copy) v_u_164, (copy) v_u_34, (copy) v_u_30, (copy) v_u_37, (ref) v_u_31, (ref) v_u_27, (ref) v_u_28, (ref) v_u_29, (copy) v_u_41, (copy) v_u_68, (copy) v_u_67, (copy) v_u_36, (ref) v_u_13, (copy) v_u_11, (ref) v_u_85
	if not v_u_12 then
		v_u_12 = true
		local v165 = v_u_9.CFrame
		v_u_14 = v165.Position
		v_u_15 = Vector3.new(0, 0, 0)
		local v166, v167 = v165:ToEulerAnglesYXZ()
		v_u_17 = v166
		v_u_16 = v167
		v_u_18 = 0
		v_u_20 = v166
		v_u_19 = v167
		v_u_21 = 0
		local v168 = v_u_9.FieldOfView
		local v169 = v_u_9.FieldOfView
		v_u_22 = v168
		v_u_23 = v169
		table.clear(v_u_24)
		v_u_25 = {
			["move"] = Vector3.new(0, 0, 0),
			["look"] = nil,
			["up"] = 0,
			["down"] = 0,
			["look"] = Vector2.zero
		}
		v_u_32 = {
			["cameraType"] = v_u_9.CameraType,
			["subject"] = v_u_9.CameraSubject,
			["fov"] = v_u_9.FieldOfView,
			["mouseBehavior"] = v_u_7.MouseBehavior,
			["mouseIcon"] = v_u_7.MouseIconEnabled,
			["guis"] = {},
			["core"] = {}
		}
		for _, v170 in v_u_8.PlayerGui:GetChildren() do
			if not v170:IsA("ScreenGui") or (v170 == v_u_33 or not v170.Enabled) then
				continue
			end
			v_u_32.guis[v170] = true
			v170.Enabled = false
		end
		for _, v171 in Enum.CoreGuiType:GetEnumItems() do
			if v171 == Enum.CoreGuiType.All then
				continue
			end
			v_u_32.core[v171] = v_u_6:GetCoreGuiEnabled(v171)
		end
		local v172 = v_u_6.SetCoreGuiEnabled
		local v173 = v_u_6
		local v174 = Enum.CoreGuiType.All
		pcall(v172, v173, v174, false)
		local v175 = v_u_6.SetCoreGuiEnabled
		local v176 = v_u_6
		local v177 = Enum.CoreGuiType.Captures
		pcall(v175, v176, v177, true)
		v_u_32.prompts = v_u_4.Enabled
		v_u_4.Enabled = false
		local v178 = v_u_89()
		if v178 then
			v178:Disable()
		end
		local v179 = v_u_90
		v_u_2:BindActionAtPriority("FreeCamInput", v_u_126, false, Enum.ContextActionPriority.High.Value + 100, table.unpack(v179))
		v_u_7.MouseBehavior = Enum.MouseBehavior.LockCenter
		v_u_7.MouseIconEnabled = false
		v_u_5:BindToRenderStep("FreeCam", Enum.RenderPriority.Last.Value + 10, v_u_164)
		v_u_34.Visible = not v_u_30
		v_u_37.Text = "Exit"
		v_u_31 = false
		v_u_27 = 0
		v_u_28 = 0
		v_u_29 = nil
		v_u_41.Visible = v_u_30
		v_u_68.Visible = v_u_30
		v_u_67.Visible = false
		v_u_37.Visible = v_u_30
		task.delay(4, function()
			-- upvalues: (ref) v_u_12, (ref) v_u_34
			if v_u_12 then
				v_u_34.Visible = false
			end
		end)
		local v180 = v_u_36
		local v181 = v_u_13
		local v182 = #v_u_11
		local v183 = v_u_23 + 0.5
		v180.Text = ("Speed %d/%d  \194\183  FOV %d\194\176"):format(v181, v182, (math.floor(v183)))
		v_u_36.Visible = true
		v_u_85 = os.clock() + 1.2
	end
end
local function v_u_194() -- name: stop
	-- upvalues: (ref) v_u_12, (copy) v_u_5, (copy) v_u_2, (copy) v_u_89, (ref) v_u_32, (copy) v_u_6, (copy) v_u_4, (copy) v_u_8, (copy) v_u_7, (copy) v_u_9, (copy) v_u_34, (copy) v_u_36, (copy) v_u_37, (ref) v_u_27, (ref) v_u_28, (ref) v_u_29, (ref) v_u_31, (copy) v_u_41, (copy) v_u_68, (ref) v_u_72, (ref) v_u_26, (copy) v_u_71, (copy) v_u_67
	if v_u_12 then
		v_u_12 = false
		v_u_5:UnbindFromRenderStep("FreeCam")
		v_u_2:UnbindAction("FreeCamInput")
		local v185 = v_u_89()
		if v185 then
			v185:Enable()
		end
		for v186 in v_u_32.guis do
			if not v186.Parent then
				continue
			end
			v186.Enabled = true
		end
		for v187, v188 in v_u_32.core do
			local v189 = v_u_6.SetCoreGuiEnabled
			local v190 = v_u_6
			pcall(v189, v190, v187, v188)
		end
		v_u_4.Enabled = v_u_32.prompts ~= false
		local v191 = v_u_8.Character
		if v191 then
			v191 = v_u_8.Character:FindFirstChildOfClass("Humanoid")
		end
		local v192 = v_u_7
		local v193
		if v191 and v191.SeatPart then
			v193 = v_u_32.mouseBehavior
		else
			v193 = Enum.MouseBehavior.Default
		end
		v192.MouseBehavior = v193
		v_u_7.MouseIconEnabled = v_u_32.mouseIcon
		v_u_9.FieldOfView = v_u_32.fov
		v_u_9.CameraSubject = v_u_32.subject
		v_u_9.CameraType = v_u_32.cameraType
		v_u_34.Visible = false
		v_u_36.Visible = false
		v_u_37.Text = "Camera"
		v_u_27 = 0
		v_u_28 = 0
		v_u_29 = nil
		v_u_31 = false
		v_u_41.Visible = false
		v_u_68.Visible = false
		v_u_72 = nil
		v_u_26 = Vector2.zero
		v_u_71.Position = UDim2.fromScale(0.5, 0.5)
		v_u_67.Visible = false
		v_u_37.Visible = false
	end
end
local function v195() -- name: toggle
	-- upvalues: (ref) v_u_12, (copy) v_u_194, (copy) v_u_184
	if v_u_12 then
		v_u_194()
	else
		v_u_184()
	end
end
v_u_7.InputBegan:Connect(function(p196, p197)
	-- upvalues: (ref) v_u_12, (copy) v_u_10, (copy) v_u_7, (copy) v_u_194, (copy) v_u_184
	if not p197 or v_u_12 then
		if p196.KeyCode == v_u_10 then
			if p196.UserInputType == Enum.UserInputType.Gamepad1 and not v_u_7:IsGamepadButtonDown(Enum.UserInputType.Gamepad1, Enum.KeyCode.ButtonL1) then
				return
			end
			if v_u_12 then
				v_u_194()
				return
			end
			v_u_184()
		end
	end
end)
v_u_37.Activated:Connect(v195)
v38.Event:Connect(v195)
v64.Activated:Connect(function()
	-- upvalues: (ref) v_u_13, (copy) v_u_11, (ref) v_u_31, (copy) v_u_36, (ref) v_u_23, (ref) v_u_85
	local v198 = v_u_13 + -1
	local v199 = #v_u_11
	v_u_13 = math.clamp(v198, 1, v199)
	if not v_u_31 then
		local v200 = v_u_36
		local v201 = v_u_13
		local v202 = #v_u_11
		local v203 = v_u_23 + 0.5
		v200.Text = ("Speed %d/%d  \194\183  FOV %d\194\176"):format(v201, v202, (math.floor(v203)))
		v_u_36.Visible = true
		v_u_85 = os.clock() + 1.2
	end
end)
v65.Activated:Connect(function()
	-- upvalues: (ref) v_u_13, (copy) v_u_11, (ref) v_u_31, (copy) v_u_36, (ref) v_u_23, (ref) v_u_85
	local v204 = v_u_13 + 1
	local v205 = #v_u_11
	v_u_13 = math.clamp(v204, 1, v205)
	if not v_u_31 then
		local v206 = v_u_36
		local v207 = v_u_13
		local v208 = #v_u_11
		local v209 = v_u_23 + 0.5
		v206.Text = ("Speed %d/%d  \194\183  FOV %d\194\176"):format(v207, v208, (math.floor(v209)))
		v_u_36.Visible = true
		v_u_85 = os.clock() + 1.2
	end
end)
v66.Activated:Connect(function()
	-- upvalues: (ref) v_u_31, (ref) v_u_27, (ref) v_u_28, (copy) v_u_41, (ref) v_u_12, (copy) v_u_30, (copy) v_u_68, (copy) v_u_71, (copy) v_u_37, (copy) v_u_67, (copy) v_u_36, (copy) v_u_34
	v_u_31 = true
	v_u_27 = 0
	v_u_28 = 0
	local v210 = v_u_41
	local v211 = v_u_12 and v_u_30
	if v211 then
		v211 = false
	end
	v210.Visible = v211
	local v212 = v_u_68
	local v213 = v_u_12
	if v213 then
		v213 = v_u_30
	end
	v212.Visible = v213
	v_u_68.BackgroundTransparency = 0.97
	v_u_71.BackgroundTransparency = 0.93
	local v214 = v_u_37
	local v215 = v_u_12 and v_u_30
	if v215 then
		v215 = false
	end
	v214.Visible = v215
	v_u_67.Visible = v_u_12 and true
	v_u_36.Visible = false
	v_u_34.Visible = false
end)
v_u_67.Activated:Connect(function()
	-- upvalues: (ref) v_u_31, (ref) v_u_27, (ref) v_u_28, (copy) v_u_41, (ref) v_u_12, (copy) v_u_30, (copy) v_u_68, (copy) v_u_71, (copy) v_u_37, (copy) v_u_67, (copy) v_u_36
	v_u_31 = false
	v_u_27 = 0
	v_u_28 = 0
	local v216 = v_u_12 and v_u_30
	v_u_41.Visible = v216 and true or v216
	local v217 = v_u_68
	local v218 = v_u_12
	if v218 then
		v218 = v_u_30
	end
	v217.Visible = v218
	v_u_68.BackgroundTransparency = 0.55
	v_u_71.BackgroundTransparency = 0.25
	local v219 = v_u_12 and v_u_30
	v_u_37.Visible = v219 and true or v219
	v_u_67.Visible = v_u_12 and false
	v_u_36.Visible = false
end)
local v_u_220 = {}
v_u_7.TouchMoved:Connect(function(p221)
	-- upvalues: (ref) v_u_12, (copy) v_u_220, (ref) v_u_19, (ref) v_u_20
	if v_u_12 and v_u_220[p221] then
		local v222 = 0
		for _ in v_u_220 do
			v222 = v222 + 1
		end
		if v222 < 2 then
			local v223 = p221.Delta
			v_u_19 = v_u_19 - v223.X * 0.0025 * 1.5
			local v224 = v_u_20 - v223.Y * 0.0025 * 1.5
			v_u_20 = math.clamp(v224, -1.5, 1.5)
			return
		end
	end
end)
v_u_7.TouchStarted:Connect(function(p225, p226)
	-- upvalues: (copy) v_u_220
	if not p226 then
		v_u_220[p225] = true
	end
end)
v_u_7.TouchEnded:Connect(function(p227)
	-- upvalues: (copy) v_u_220
	v_u_220[p227] = nil
end)
v_u_7.TouchPinch:Connect(function(_, p228, _, p229, p230)
	-- upvalues: (ref) v_u_12, (ref) v_u_29, (ref) v_u_23, (ref) v_u_31, (copy) v_u_36, (ref) v_u_13, (copy) v_u_11, (ref) v_u_85
	if v_u_12 then
		if p229 == Enum.UserInputState.Begin then
			local v231
			if p230 then
				v231 = nil
			else
				v231 = v_u_23
			end
			v_u_29 = v231
		elseif p229 == Enum.UserInputState.Change and (v_u_29 and p228 > 0) then
			local v232 = v_u_29 / p228
			v_u_23 = math.clamp(v232, 15, 100)
			if not v_u_31 then
				local v233 = v_u_36
				local v234 = v_u_13
				local v235 = #v_u_11
				local v236 = v_u_23 + 0.5
				v233.Text = ("Speed %d/%d  \194\183  FOV %d\194\176"):format(v234, v235, (math.floor(v236)))
				v_u_36.Visible = true
				v_u_85 = os.clock() + 1.2
				return
			end
		else
			v_u_29 = nil
		end
	else
		return
	end
end)
v_u_8.CharacterAdded:Connect(function()
	-- upvalues: (copy) v_u_194
	v_u_194()
end)