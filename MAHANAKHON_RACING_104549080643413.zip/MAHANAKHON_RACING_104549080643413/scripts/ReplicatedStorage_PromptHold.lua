-- Path: ReplicatedStorage/PromptHold
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = game:GetService("Players")
local v_u_6 = {
	["SECONDS"] = 1,
	["exempt"] = function(p2) -- name: exempt
		-- upvalues: (copy) v_u_1
		local v3 = workspace:FindFirstChild("SpawnedVehicles")
		if v3 and p2:IsDescendantOf(v3) then
			return true
		end
		local v4 = p2:FindFirstAncestorOfClass("Model")
		while v4 do
			if v_u_1:GetPlayerFromCharacter(v4) then
				return true
			end
			v4 = v4:FindFirstAncestorOfClass("Model")
		end
		return false
	end,
	["held"] = function(p5) -- name: held
		return p5.Name == "WorkPrompt"
	end
}
local function v_u_8(p7) -- name: set
	-- upvalues: (copy) v_u_6
	if p7.Parent and p7.HoldDuration ~= v_u_6.SECONDS then
		p7.HoldDuration = v_u_6.SECONDS
	end
end
local function v_u_11(p_u_9) -- name: hook
	-- upvalues: (copy) v_u_6, (copy) v_u_8
	if p_u_9:IsA("ProximityPrompt") and v_u_6.held(p_u_9) then
		task.defer(v_u_8, p_u_9)
		p_u_9:GetPropertyChangedSignal("HoldDuration"):Connect(function()
			-- upvalues: (copy) p_u_9, (ref) v_u_6
			local v10 = p_u_9
			if v10.Parent and v10.HoldDuration ~= v_u_6.SECONDS then
				v10.HoldDuration = v_u_6.SECONDS
			end
		end)
	end
end
function v_u_6.watch() -- name: watch
	-- upvalues: (copy) v_u_11
	workspace.DescendantAdded:Connect(v_u_11)
	for _, v12 in workspace:GetDescendants() do
		v_u_11(v12)
	end
end
return v_u_6