-- Path: Players/ygggggg55551/PlayerScripts/PassShowcaseClient
-- Class: LocalScript  true/Enum.RunContext.Legacy
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = require(game:GetService("ReplicatedStorage"):WaitForChild("NetSeal")).invoke
local v2 = game:GetService("CollectionService")
local v_u_3 = game:GetService("MarketplaceService")
local v4 = game:GetService("Players")
local v5 = game:GetService("ProximityPromptService")
local v6 = game:GetService("ReplicatedStorage")
local v7 = game:GetService("RunService")
local v_u_8 = require(v6:WaitForChild("GameShared"))
local v9 = v6:WaitForChild("GameUI")
local v_u_10 = require(v9:WaitForChild("Toast"))
local v_u_11 = require(v9:WaitForChild("StoreConfig"))
local v_u_12 = v4.LocalPlayer
local v_u_13 = v6:WaitForChild(v_u_8.REMOTES)
local v_u_14 = {}
local v_u_15 = {}
local function v_u_30(p16) -- name: track
	-- upvalues: (copy) v_u_14, (copy) v_u_15, (copy) v_u_8, (copy) v_u_12
	if not p16:IsA("Model") or v_u_14[p16] then
		return
	end
	local v17 = p16:WaitForChild("Spin", 15)
	if not (v17 and p16.Parent) then
		return
	end
	local v18 = p16:GetAttribute("SpinParts") or 0
	local v19 = {}
	for _ = 1, 50 do
		v19 = {}
		for _, v20 in v17:GetDescendants() do
			if not v20:IsA("BasePart") then
				continue
			end
			table.insert(v19, v20)
		end
		if v18 <= #v19 then
			break
		end
		task.wait(0.1)
	end
	if p16.Parent and #v19 ~= 0 then
		local v21 = v17:GetPivot()
		local v22 = table.create(#v19)
		for v23, v24 in v19 do
			v22[v23] = v21:ToObjectSpace(v24.CFrame)
		end
		local v25 = v_u_14
		local v26 = {
			["centre"] = v21,
			["parts"] = v19,
			["offsets"] = v22,
			["cframes"] = table.create(#v19)
		}
		local v27 = p16:GetAttribute("SpinSpeed") or 24
		v26.speed = math.rad(v27)
		v25[p16] = v26
		local v_u_28 = p16:FindFirstChild("BuyPrompt", true)
		if v_u_28 and (v_u_28:IsA("ProximityPrompt") and type(v_u_28:GetAttribute("PassShowcase")) == "string") then
			v_u_15[v_u_28] = v_u_28:GetAttribute("PassShowcase")
			local v29 = v_u_15[v_u_28]
			if v29 then
				v_u_28.ActionText = v_u_8.hasPass(v_u_12, v29) and "\224\184\161\224\184\181\224\185\129\224\184\165\224\185\137\224\184\167 \226\156\147" or "\224\184\139\224\184\183\224\185\137\224\184\173\224\184\148\224\185\137\224\184\167\224\184\162 Robux"
			end
			v_u_28.Destroying:Once(function()
				-- upvalues: (ref) v_u_15, (copy) v_u_28
				v_u_15[v_u_28] = nil
			end)
		end
	end
end
v2:GetInstanceAddedSignal("PassShowcase"):Connect(function(p31)
	-- upvalues: (copy) v_u_30
	task.spawn(v_u_30, p31)
end)
v2:GetInstanceRemovedSignal("PassShowcase"):Connect(function(p32) -- name: forget
	-- upvalues: (copy) v_u_14
	v_u_14[p32] = nil
end)
for _, v33 in v2:GetTagged("PassShowcase") do
	task.spawn(v_u_30, v33)
end
v_u_12.AttributeChanged:Connect(function(p34)
	-- upvalues: (copy) v_u_15, (copy) v_u_8, (copy) v_u_12
	if string.sub(p34, 1, 5) == "Pass_" then
		for v35 in v_u_15 do
			local v36 = v_u_15[v35]
			if not v36 then
				continue
			end
			v35.ActionText = v_u_8.hasPass(v_u_12, v36) and "\224\184\161\224\184\181\224\185\129\224\184\165\224\185\137\224\184\167 \226\156\147" or "\224\184\139\224\184\183\224\185\137\224\184\173\224\184\148\224\185\137\224\184\167\224\184\162 Robux"
		end
	end
end);
(v7.PreRender or v7.RenderStepped):Connect(function() end)
local v_u_37 = false
v5.PromptTriggered:Connect(function(p38)
	-- upvalues: (ref) v_u_37, (copy) v_u_11, (copy) v_u_8, (copy) v_u_12, (copy) v_u_10, (copy) v_u_1, (copy) v_u_13, (copy) v_u_3
	local v39 = p38:GetAttribute("PassShowcase")
	if type(v39) == "string" and not v_u_37 then
		for _, v41 in v_u_11.GAMEPASSES do
			if v41.key ~= v39 then
				continue
			end
		end
		local v41 = nil
		if v41 then
			if v_u_8.hasPass(v_u_12, v39) then
				v_u_10.show("You already have " .. v41.name .. ": spawn it from My Vehicles", "info")
			else
				v_u_37 = true
				local v42 = v_u_1
				local v43 = v_u_13:FindFirstChild("Store")
				local v44, v45, v46, v47 = pcall(v42, v43, "BuyStart", v39)
				if v44 and (v45 and v47) then
					v_u_3:PromptProductPurchase(v_u_12, v47)
				else
					v_u_10.show(v44 and v46 and v46 or "Couldn\'t start the purchase", "error")
				end
				task.delay(1, function()
					-- upvalues: (ref) v_u_37
					v_u_37 = false
				end)
			end
		else
			return
		end
	else
		return
	end
end)