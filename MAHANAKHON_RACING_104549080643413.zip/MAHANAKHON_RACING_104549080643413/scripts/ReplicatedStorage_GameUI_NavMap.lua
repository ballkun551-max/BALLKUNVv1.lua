-- Path: ReplicatedStorage/GameUI/NavMap
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = require(game:GetService("ReplicatedStorage"):WaitForChild("UiOwn")).Instance
local v2 = game:GetService("Players")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("RunService")
local v_u_5 = game:GetService("TweenService")
local v_u_6 = require(v3:WaitForChild("MapRoads"))
local v_u_7 = require(v3:WaitForChild("MapPlaces"))
local v_u_8 = require(v3:WaitForChild("RoadGraph"))
local v_u_9 = require(v3:WaitForChild("DeliveryShared"))
local v_u_10 = require(script.Parent:WaitForChild("Theme"))
local v_u_11 = require(script.Parent:WaitForChild("Icons"))
local v_u_12 = require(script.Parent:WaitForChild("Phone"))
local v_u_13 = TweenInfo.new(0.42, Enum.EasingStyle.Quint, Enum.EasingDirection.Out)
local v_u_14 = TweenInfo.new(0.34, Enum.EasingStyle.Quint, Enum.EasingDirection.In)
local v_u_15 = Color3.new(1, 1, 1)
local v_u_16 = {
	["land"] = Color3.fromRGB(238, 240, 243),
	["building"] = Color3.fromRGB(221, 224, 230),
	["water"] = Color3.fromRGB(166, 208, 244),
	["route"] = Color3.fromRGB(30, 132, 255),
	["routeEdge"] = Color3.fromRGB(16, 86, 198),
	["bar"] = Color3.fromRGB(27, 31, 46),
	["barDim"] = Color3.fromRGB(168, 176, 196),
	["button"] = Color3.fromRGB(62, 68, 90),
	["ink"] = Color3.fromRGB(44, 48, 58),
	["dim"] = Color3.fromRGB(112, 118, 130),
	["pick"] = Color3.fromRGB(28, 178, 104),
	["drop"] = Color3.fromRGB(236, 60, 60),
	["food"] = Color3.fromRGB(255, 140, 0)
}
local v_u_17 = {
	["main"] = { Color3.fromRGB(255, 241, 204), Color3.fromRGB(230, 196, 128) },
	["ring"] = { Color3.fromRGB(255, 241, 204), Color3.fromRGB(230, 196, 128) },
	["bridge"] = { Color3.fromRGB(255, 241, 204), Color3.fromRGB(230, 196, 128) },
	["alley"] = { Color3.fromRGB(250, 250, 252), Color3.fromRGB(214, 218, 224) }
}
local v_u_18 = { v_u_15, Color3.fromRGB(202, 207, 216) }
local v_u_19 = v2.LocalPlayer
local function v_u_22(p20) -- name: shopIcon
	local v21 = p20:lower()
	return (v21:find("coffee") or (v21:find("cafe") or (v21:find("tea") or v21:find("bakery")))) and "\226\152\149" or (v21:find("market") and "\240\159\155\146" or (v21:find("minimart") and "\240\159\143\170" or "\240\159\141\156"))
end
local v23 = v_u_6.NODES
local v24 = v_u_6.EDGES
local v_u_25 = {}
local v_u_26 = {
	["left"] = 0,
	["right"] = 180,
	["uturn"] = 270,
	["straight"] = 90,
	["start"] = 90
}
local function v_u_33() -- name: allPlaces
	-- upvalues: (copy) v_u_7, (copy) v_u_6, (copy) v_u_22, (copy) v_u_16
	local v27 = {}
	for _, v28 in v_u_7 do
		local v29 = {
			["th"] = v28.th,
			["icon"] = v28.icon,
			["color"] = v28.color,
			["x"] = v28.x,
			["z"] = v28.z,
			["rank"] = v28.rank or 2
		}
		table.insert(v27, v29)
	end
	for _, v30 in v_u_6.SHOPS do
		local v31 = v30[1]
		if tostring(v31):lower():find("market") then
			continue
		end
		local v32 = {
			["th"] = nil,
			["icon"] = nil,
			["color"] = nil,
			["x"] = nil,
			["z"] = nil,
			["rank"] = 1,
			["th"] = v30[1],
			["icon"] = v_u_22(v30[1]),
			["color"] = v_u_16.food,
			["x"] = v30[2],
			["z"] = v30[4]
		}
		table.insert(v27, v32)
	end
	return v27
end
local v34 = {}
local function v_u_48(p35, p36, p37, p38, p39, p40, p41, p42, p43) -- name: shape
	-- upvalues: (copy) v_u_1
	local v44 = v_u_1.new("Frame")
	v44.AnchorPoint = Vector2.new(0.5, 0.5)
	v44.Position = UDim2.fromOffset(p36, p37)
	v44.Size = UDim2.fromOffset(p38, p39)
	v44.Rotation = p40
	v44.BackgroundColor3 = p41
	v44.BorderSizePixel = 0
	v44.Visible = p43 == nil
	if p42 then
		local v45 = v_u_1.new("UICorner")
		v45.CornerRadius = UDim.new(0, p42)
		v45.Parent = v44
	end
	v44.Parent = p35
	if p43 then
		local v46 = {
			["frame"] = v44,
			["x"] = p36,
			["z"] = p37
		}
		local v47 = p38 * p38 + p39 * p39
		v46.r = math.sqrt(v47) / 2
		table.insert(p43, v46)
	end
	return v44
end
local function v_u_51(p49, p50) -- name: new
	-- upvalues: (copy) v_u_10
	return v_u_10.new(p49, p50)
end
local v_u_52 = {
	["left"] = "\224\185\128\224\184\165\224\184\181\224\185\137\224\184\162\224\184\167\224\184\139\224\185\137\224\184\178\224\184\162",
	["right"] = "\224\185\128\224\184\165\224\184\181\224\185\137\224\184\162\224\184\167\224\184\130\224\184\167\224\184\178",
	["uturn"] = "\224\184\129\224\184\165\224\184\177\224\184\154\224\184\163\224\184\150",
	["arrive"] = "\224\184\150\224\184\182\224\184\135\224\184\136\224\184\184\224\184\148\224\184\171\224\184\161\224\184\178\224\184\162",
	["start"] = "\224\184\130\224\184\182\224\185\137\224\184\153\224\184\150\224\184\153\224\184\153"
}
for v53 = 1, #v24, 3 do
	local v54 = v_u_6.KINDS[v24[v53 + 2]]
	if not v54.gps then
		continue
	end
	local v55 = v24[v53]
	local v56 = v24[v53 + 1]
	local v57 = {
		["a"] = Vector2.new(v23[v55 * 2 - 1], v23[v55 * 2]),
		["b"] = Vector2.new(v23[v56 * 2 - 1], v23[v56 * 2]),
		["half"] = v54.half
	}
	table.insert(v_u_25, v57)
end
local function v_u_65(p58) -- name: onRoad
	-- upvalues: (copy) v_u_25
	for _, v59 in v_u_25 do
		local v60 = v59.b - v59.a
		local v61 = (p58 - v59.a):Dot(v60)
		local v62 = v60:Dot(v60)
		local v63 = v61 / math.max(v62, 1e-6)
		local v64 = math.clamp(v63, 0, 1)
		if (v59.a + v60 * v64 - p58).Magnitude > v59.half + 10 then
			continue
		end
		return true
	end
	return false
end
local function v_u_73(p66, p67, p68) -- name: pointAt
	local v69 = p67[#p67]
	local v70 = math.clamp(p68, 0, v69)
	for v71 = 2, #p66 do
		if v70 > p67[v71] then
			continue
		end
		local v72 = p67[v71] - p67[v71 - 1]
		return p66[v71 - 1]:Lerp(p66[v71], v72 <= 0 and 0 or (v70 - p67[v71 - 1]) / v72)
	end
	return p66[#p66]
end
local function v_u_104(p74, p75, p76) -- name: nextMove
	-- upvalues: (copy) v_u_73
	local v77 = #p74
	if v77 < 3 then
		return 0, "arrive"
	end
	local v78 = {}
	for v79 = p76 and 2 or 1, v77 - 1 do
		local v80 = p74[v79]
		table.insert(v78, v80)
	end
	local v81 = { 0 }
	for v82 = 2, #v78 do
		v81[v82] = v81[v82 - 1] + (v78[v82] - v78[v82 - 1]).Magnitude
	end
	local v83 = v81[#v78]
	if p76 and (p75 and v83 > 4) then
		local v84 = v_u_73(v78, v81, 20) - v78[1]
		if v84.Magnitude > 2 and v84.Unit:Dot(p75) < -0.5 then
			return 0, "uturn"
		end
	end
	local v85 = 0
	for v86 = 2, #v78 - 1 do
		local v87 = v81[v86]
		local v88 = v78[v86]
		local v89 = v_u_73(v78, v81, v87) - v_u_73(v78, v81, v87 - 20)
		local v90 = v_u_73(v78, v81, v87 + 20) - v_u_73(v78, v81, v87)
		local v91 = v88 - p74[1]
		if not p75 or (v91.Magnitude >= 75 or (v90.Magnitude <= 2 or v90.Unit:Dot(p75) <= 0.8)) then
			if v89.Magnitude <= 2 or v90.Magnitude <= 2 then
				continue
			end
			local v92 = v89.Unit
			local v93 = v90.Unit
			local v94 = v92:Dot(v93)
			local v95 = math.clamp(v94, -1, 1)
			local v96 = math.acos(v95)
			local v97 = math.deg(v96)
			if v97 <= 35 then
				continue
			end
			local v98 = v92.X * v93.Y - v92.Y * v93.X
			local v99 = v_u_73(v78, v81, v87 + 70) - v_u_73(v78, v81, v87 + 70 - 20)
			local v100
			if v99.Magnitude > 2 then
				v100 = v92:Dot(v99.Unit) < -0.85
			else
				v100 = false
			end
			local v101 = v87 - v85
			local v102 = math.max(0, v101)
			if v97 > 150 or v100 then
				return v102, "uturn"
			elseif v98 > 0 then
				return v102, "right"
			else
				return v102, "left"
			end
		end
		v85 = v87 - math.max(0, v91:Dot(p75))
	end
	local v103 = v83 - v85
	return math.max(0, v103), "arrive"
end
function v34.new(p105, p106, p_u_107, p108) -- name: new
	-- upvalues: (copy) v_u_1, (copy) v_u_16, (copy) v_u_10, (copy) v_u_15, (copy) v_u_11, (copy) v_u_51, (copy) v_u_6, (copy) v_u_48, (copy) v_u_17, (copy) v_u_18, (copy) v_u_33, (copy) v_u_19, (copy) v_u_8, (copy) v_u_104, (copy) v_u_65, (copy) v_u_52, (copy) v_u_9, (copy) v_u_26, (copy) v_u_12, (copy) v_u_4, (copy) v_u_5, (copy) v_u_13, (copy) v_u_14
	local v_u_109 = p106.X
	local v_u_110 = p106.Y
	local v_u_111 = v_u_109 / 2
	local v_u_112 = 104 + (v_u_110 - 104 - 96) * 0.74
	local v_u_113 = {
		["dismissed"] = v_u_1.new("BindableEvent")
	}
	local v114 = {
		["Name"] = "Nav",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["Visible"] = false,
		["ZIndex"] = 20,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_16.land,
		["Position"] = UDim2.fromScale(0, 1),
		["Size"] = UDim2.fromScale(1, 1),
		["Parent"] = p105
	}
	local v_u_115 = v_u_10.new("CanvasGroup", v114)
	v_u_113.root = v_u_115
	local v116 = {
		["Name"] = "Map",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 1,
		["Parent"] = nil,
		["Size"] = UDim2.fromScale(1, 1),
		["Parent"] = v_u_115
	}
	local v_u_117 = v_u_10.new("Frame", v116)
	local v118 = {
		["Name"] = "Places",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 3,
		["Parent"] = nil,
		["Size"] = UDim2.fromScale(1, 1),
		["Parent"] = v_u_115
	}
	local v_u_119 = v_u_10.new("Frame", v118)
	local v120 = {
		["Name"] = "Pin",
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Size"] = nil,
		["Visible"] = false,
		["ZIndex"] = 4,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 1),
		["Size"] = UDim2.fromOffset(32, 44),
		["Parent"] = v_u_115
	}
	local v_u_121 = v_u_10.new("Frame", v120)
	local v122 = {
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_16.drop,
		["Size"] = UDim2.fromOffset(32, 32),
		["Parent"] = v_u_121
	}
	local v_u_123 = v_u_10.new("Frame", v122)
	v_u_10.corner(v_u_123, 16)
	local v124 = {
		["ApplyStrokeMode"] = nil,
		["Color"] = nil,
		["Thickness"] = 2.5,
		["Parent"] = nil,
		["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
		["Color"] = v_u_15,
		["Parent"] = v_u_123
	}
	v_u_10.new("UIStroke", v124)
	local v125 = {
		["Text"] = "1",
		["FontFace"] = nil,
		["TextSize"] = 17,
		["TextColor3"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["FontFace"] = v_u_10.FONT_HEAVY,
		["TextColor3"] = v_u_15,
		["Size"] = UDim2.fromScale(1, 1),
		["Parent"] = v_u_123
	}
	local v_u_126 = v_u_10.text(v125)
	local v127 = {
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_16.drop,
		["Position"] = UDim2.fromOffset(14.5, 31),
		["Size"] = UDim2.fromOffset(3, 9),
		["Parent"] = v_u_121
	}
	local v_u_128 = v_u_10.new("Frame", v127)
	local v129 = {
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_15,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.new(0.5, 0, 1, -2),
		["Size"] = UDim2.fromOffset(9, 5),
		["Parent"] = v_u_121
	}
	local v130 = v_u_10.new("Frame", v129)
	v_u_10.corner(v130, 3)
	local v131 = {
		["ApplyStrokeMode"] = nil,
		["Color"] = nil,
		["Thickness"] = 1.5,
		["Parent"] = nil,
		["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
		["Color"] = v_u_16.ink,
		["Parent"] = v130
	}
	v_u_10.new("UIStroke", v131)
	local v132 = {
		["Name"] = "You",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 5,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_15,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromOffset(v_u_111, v_u_112),
		["Size"] = UDim2.fromOffset(34, 34),
		["Parent"] = v_u_115
	}
	local v_u_133 = v_u_10.new("Frame", v132)
	v_u_10.corner(v_u_133, 17)
	local v134 = {
		["ApplyStrokeMode"] = nil,
		["Color"] = nil,
		["Transparency"] = 0.8,
		["Thickness"] = 1,
		["Parent"] = nil,
		["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
		["Color"] = Color3.new(0, 0, 0),
		["Parent"] = v_u_133
	}
	v_u_10.new("UIStroke", v134)
	local v135 = {
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_16.route,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.5),
		["Size"] = UDim2.fromOffset(26, 26),
		["Parent"] = v_u_133
	}
	local v136 = v_u_10.new("Frame", v135)
	v_u_10.corner(v136, 13)
	local v_u_137 = p108 or {}
	for _, v138 in { -1, 1 } do
		local v139 = {
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Rotation"] = nil,
			["Parent"] = nil,
			["BackgroundColor3"] = v_u_15,
			["AnchorPoint"] = Vector2.new(0.5, 0),
			["Position"] = UDim2.fromOffset(13 + v138 * 3.4, 5),
			["Size"] = UDim2.fromOffset(4, 15),
			["Rotation"] = v138 * -30,
			["Parent"] = v136
		}
		local v140 = v_u_10.new("Frame", v139)
		v_u_10.corner(v140, 2)
	end
	local v141 = {
		["Name"] = "Speed",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 6,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_15,
		["Position"] = UDim2.fromOffset(12, 116),
		["Size"] = UDim2.fromOffset(54, 54),
		["Parent"] = v_u_115
	}
	local v142 = v_u_10.new("Frame", v141)
	v_u_10.corner(v142, 12)
	local v143 = {
		["ApplyStrokeMode"] = nil,
		["Color"] = nil,
		["Transparency"] = 0.88,
		["Thickness"] = 1,
		["Parent"] = nil,
		["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
		["Color"] = Color3.new(0, 0, 0),
		["Parent"] = v142
	}
	v_u_10.new("UIStroke", v143)
	local v144 = {
		["Text"] = "0",
		["FontFace"] = nil,
		["TextSize"] = 22,
		["TextColor3"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["FontFace"] = v_u_10.FONT_HEAVY,
		["TextColor3"] = v_u_16.ink,
		["Position"] = UDim2.fromOffset(0, 6),
		["Size"] = UDim2.new(1, 0, 0, 24),
		["Parent"] = v142
	}
	local v_u_145 = v_u_10.text(v144)
	local v146 = {
		["Text"] = "km/h",
		["FontFace"] = nil,
		["TextSize"] = 11,
		["TextColor3"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["FontFace"] = v_u_10.FONT_BOLD,
		["TextColor3"] = v_u_16.dim,
		["Position"] = UDim2.fromOffset(0, 32),
		["Size"] = UDim2.new(1, 0, 0, 14),
		["Parent"] = v142
	}
	v_u_10.text(v146)
	local v147 = {
		["Name"] = "Eta",
		["Text"] = "",
		["FontFace"] = nil,
		["TextSize"] = 15,
		["TextColor3"] = nil,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["ZIndex"] = 6,
		["Parent"] = nil,
		["FontFace"] = v_u_10.FONT_BOLD,
		["TextColor3"] = v_u_16.ink,
		["BackgroundColor3"] = v_u_15,
		["AnchorPoint"] = Vector2.new(0.5, 1),
		["Position"] = UDim2.new(0.5, 0, 1, -106),
		["Size"] = UDim2.fromOffset(0, 30),
		["AutomaticSize"] = Enum.AutomaticSize.X,
		["Parent"] = v_u_115
	}
	local v_u_148 = v_u_10.text(v147)
	v_u_10.corner(v_u_148, 15)
	v_u_10.padding(v_u_148, 14, 0)
	local v149 = {
		["ApplyStrokeMode"] = nil,
		["Color"] = nil,
		["Transparency"] = 0.88,
		["Thickness"] = 1,
		["Parent"] = nil,
		["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
		["Color"] = Color3.new(0, 0, 0),
		["Parent"] = v_u_148
	}
	v_u_10.new("UIStroke", v149)
	local v150 = {
		["Name"] = "Top",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["ZIndex"] = 8,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_16.bar,
		["Size"] = UDim2.new(1, 0, 0, 104),
		["Parent"] = v_u_115
	}
	local v151 = v_u_10.new("Frame", v150)
	local v152 = {
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_15,
		["Position"] = UDim2.fromOffset(14, 42),
		["Size"] = UDim2.fromOffset(48, 48),
		["Parent"] = v151
	}
	local v153 = v_u_10.new("Frame", v152)
	v_u_10.corner(v153, 24)
	local v_u_154 = v_u_11.make("arrow", v_u_16.bar, 30)
	v_u_154.AnchorPoint = Vector2.new(0.5, 0.5)
	v_u_154.Position = UDim2.fromScale(0.5, 0.5)
	v_u_154.Parent = v153
	local v155 = {
		["Text"] = "",
		["FontFace"] = nil,
		["TextSize"] = 30,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["FontFace"] = v_u_10.FONT_DISPLAY,
		["TextColor3"] = v_u_15,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["Position"] = UDim2.fromOffset(74, 38),
		["Size"] = UDim2.new(1, -124, 0, 34),
		["Parent"] = v151
	}
	local v_u_156 = v_u_10.text(v155)
	local v157 = {
		["Text"] = "",
		["FontFace"] = nil,
		["TextSize"] = 15,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["TextTruncate"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["FontFace"] = v_u_10.FONT_BOLD,
		["TextColor3"] = v_u_16.barDim,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["TextTruncate"] = Enum.TextTruncate.AtEnd,
		["Position"] = UDim2.fromOffset(74, 72),
		["Size"] = UDim2.new(1, -124, 0, 20),
		["Parent"] = v151
	}
	local v_u_158 = v_u_10.text(v157)
	local v159 = {
		["Name"] = "Close",
		["Text"] = "",
		["AutoButtonColor"] = false,
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_16.button,
		["AnchorPoint"] = Vector2.new(1, 0),
		["Position"] = UDim2.new(1, -12, 0, 50),
		["Size"] = UDim2.fromOffset(34, 34),
		["Parent"] = v151
	}
	local v160 = v_u_10.new("TextButton", v159)
	v_u_10.corner(v160, 17)
	local v161 = v_u_11.make("close", v_u_15, 18)
	v161.AnchorPoint = Vector2.new(0.5, 0.5)
	v161.Position = UDim2.fromScale(0.5, 0.5)
	v161.Parent = v160
	local v162 = {
		["Name"] = "Bottom",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 8,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_16.bar,
		["AnchorPoint"] = Vector2.new(0, 1),
		["Position"] = UDim2.fromScale(0, 1),
		["Size"] = UDim2.new(1, 0, 0, 96),
		["Parent"] = v_u_115
	}
	local v163 = v_u_10.new("Frame", v162)
	v_u_10.corner(v163, 18)
	local v164 = {
		["Text"] = "",
		["RichText"] = true,
		["FontFace"] = nil,
		["TextSize"] = 19,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["TextTruncate"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["FontFace"] = v_u_10.FONT_BOLD,
		["TextColor3"] = v_u_15,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["TextTruncate"] = Enum.TextTruncate.AtEnd,
		["Position"] = UDim2.fromOffset(16, 14),
		["Size"] = UDim2.new(1, -72, 0, 26),
		["Parent"] = v163
	}
	local v_u_165 = v_u_10.text(v164)
	local v166 = {
		["Text"] = "",
		["FontFace"] = nil,
		["TextSize"] = 14,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["TextYAlignment"] = nil,
		["TextWrapped"] = true,
		["TextTruncate"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["FontFace"] = v_u_10.FONT,
		["TextColor3"] = v_u_16.barDim,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["TextYAlignment"] = Enum.TextYAlignment.Top,
		["TextTruncate"] = Enum.TextTruncate.AtEnd,
		["Position"] = UDim2.fromOffset(16, 42),
		["Size"] = UDim2.new(1, -72, 0, 36),
		["Parent"] = v163
	}
	local v_u_167 = v_u_10.text(v166)
	local v168 = {
		["Name"] = "Details",
		["Text"] = "",
		["AutoButtonColor"] = false,
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_16.button,
		["AnchorPoint"] = Vector2.new(1, 0),
		["Position"] = UDim2.new(1, -14, 0, 18),
		["Size"] = UDim2.fromOffset(38, 38),
		["Parent"] = v163
	}
	local v169 = v_u_10.new("TextButton", v168)
	v_u_10.corner(v169, 19)
	local v170 = v_u_11.make("arrow", v_u_15, 20)
	v170.AnchorPoint = Vector2.new(0.5, 0.5)
	v170.Position = UDim2.fromScale(0.5, 0.5)
	v170.Rotation = 90
	v170.Parent = v169
	local v_u_171 = false
	local v_u_172 = false
	local v_u_173 = {}
	local v_u_174 = nil
	local v_u_175 = nil
	local v_u_176 = nil
	local v_u_177 = nil
	local v_u_178 = nil
	local v_u_179 = {}
	local v_u_180 = nil
	local v_u_181 = nil
	local v_u_182 = nil
	local v_u_183 = 0
	local v_u_184 = {}
	local v_u_185 = nil
	local v_u_186 = (-1 / 0)
	local v_u_187 = (-1 / 0)
	local v_u_188 = 0.55
	local v_u_189 = 0
	local v_u_190 = false
	local v_u_191 = nil
	local function v_u_258() -- name: build
		-- upvalues: (ref) v_u_172, (ref) v_u_174, (copy) v_u_111, (copy) v_u_112, (copy) v_u_117, (ref) v_u_10, (ref) v_u_175, (ref) v_u_176, (ref) v_u_51, (ref) v_u_177, (ref) v_u_178, (ref) v_u_6, (ref) v_u_48, (ref) v_u_16, (copy) v_u_173, (ref) v_u_17, (ref) v_u_18, (ref) v_u_33, (copy) v_u_119, (ref) v_u_15, (copy) v_u_179
		if not v_u_172 then
			v_u_172 = true
			local v192 = {
				["Name"] = "Rotator",
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["Position"] = nil,
				["Parent"] = nil,
				["Size"] = UDim2.new(),
				["Position"] = UDim2.fromOffset(v_u_111, v_u_112),
				["Parent"] = v_u_117
			}
			v_u_174 = v_u_10.new("Frame", v192)
			local v193 = {
				["Scale"] = 0.55,
				["Parent"] = nil,
				["Parent"] = v_u_174
			}
			v_u_175 = v_u_10.new("UIScale", v193)
			local v194 = {
				["Name"] = "Mover",
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["Parent"] = nil,
				["Size"] = UDim2.new(),
				["Parent"] = v_u_174
			}
			v_u_176 = v_u_10.new("Frame", v194)
			local v195 = {
				["Name"] = "Water",
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["ZIndex"] = 1,
				["Parent"] = nil,
				["Size"] = UDim2.new(),
				["Parent"] = v_u_176
			}
			local v196 = v_u_10.new("Frame", v195)
			local v197 = {
				["Name"] = "Buildings",
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["ZIndex"] = 2,
				["Parent"] = nil,
				["Size"] = UDim2.new(),
				["Parent"] = v_u_176
			}
			local v198 = v_u_10.new("Frame", v197)
			local v199 = {
				["Name"] = "RoadEdges",
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["ZIndex"] = 3,
				["Parent"] = nil,
				["Size"] = UDim2.new(),
				["Parent"] = v_u_176
			}
			local v200 = v_u_10.new("Frame", v199)
			local v201 = {
				["Name"] = "Roads",
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["ZIndex"] = 4,
				["Parent"] = nil,
				["Size"] = UDim2.new(),
				["Parent"] = v_u_176
			}
			local v202 = v_u_10.new("Frame", v201)
			local v203 = {
				["Name"] = "RouteEdge",
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["ZIndex"] = 5,
				["Parent"] = nil,
				["Size"] = UDim2.new(),
				["Parent"] = v_u_176
			}
			v_u_177 = v_u_10.new("Frame", v203)
			local v204 = {
				["Name"] = "Route",
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["ZIndex"] = 6,
				["Parent"] = nil,
				["Size"] = UDim2.new(),
				["Parent"] = v_u_176
			}
			v_u_178 = v_u_10.new("Frame", v204)
			for _, v205 in v_u_6.WATER do
				v_u_48(v196, (v205[1] + v205[3]) / 2, (v205[2] + v205[4]) / 2, v205[3] - v205[1], v205[4] - v205[2], 0, v_u_16.water, nil, v_u_173)
			end
			local v206 = v_u_6.BUILDINGS
			for v207 = 1, #v206, 5 do
				v_u_48(v198, v206[v207], v206[v207 + 1], v206[v207 + 2], v206[v207 + 3], -v206[v207 + 4], v_u_16.building, 3, v_u_173)
			end
			local v208 = v_u_6.NODES
			local v_u_209 = v_u_6.EDGES
			local v210 = {}
			for v211 = 1, #v_u_209, 3 do
				table.insert(v210, v211)
			end
			table.sort(v210, function(p212, p213)
				-- upvalues: (ref) v_u_6, (copy) v_u_209
				return v_u_6.KINDS[v_u_209[p212 + 2]].half < v_u_6.KINDS[v_u_209[p213 + 2]].half
			end)
			for _, v214 in v210 do
				local v215 = v_u_6.KINDS[v_u_209[v214 + 2]]
				local v216 = v_u_17[v215.id] or v_u_18
				local v217 = v_u_209[v214]
				local v218 = Vector2.new(v208[v217 * 2 - 1], v208[v217 * 2])
				local v219 = v_u_209[v214 + 1]
				local v220 = Vector2.new(v208[v219 * 2 - 1], v208[v219 * 2])
				local v221 = v215.half + 3
				local v222 = v216[2]
				local v223 = v_u_173
				local v224 = v220 - v218
				local v225 = (v218 + v220) / 2
				local v226 = v_u_48
				local v227 = v225.X
				local v228 = v225.Y
				local v229 = v224.Magnitude + v221 * 2
				local v230 = v221 * 2
				local v231 = v224.Y
				local v232 = v224.X
				local v233 = math.atan2(v231, v232)
				v226(v200, v227, v228, v229, v230, math.deg(v233), v222, v221, v223)
				local v234 = v215.half
				local v235 = v216[1]
				local v236 = v_u_173
				local v237 = v220 - v218
				local v238 = (v218 + v220) / 2
				local v239 = v_u_48
				local v240 = v238.X
				local v241 = v238.Y
				local v242 = v237.Magnitude + v234 * 2
				local v243 = v234 * 2
				local v244 = v237.Y
				local v245 = v237.X
				local v246 = math.atan2(v244, v245)
				v239(v202, v240, v241, v242, v243, math.deg(v246), v235, v234, v236)
			end
			for _, v247 in v_u_33() do
				local v248 = {
					["BackgroundTransparency"] = 1,
					["Size"] = nil,
					["Visible"] = false,
					["ZIndex"] = nil,
					["Parent"] = nil,
					["Size"] = UDim2.new(),
					["ZIndex"] = v247.rank >= 2 and 2 or 1,
					["Parent"] = v_u_119
				}
				local v249 = v_u_10.new("Frame", v248)
				local v250 = {
					["BackgroundColor3"] = nil,
					["BorderSizePixel"] = 0,
					["AnchorPoint"] = nil,
					["Size"] = nil,
					["Parent"] = nil,
					["BackgroundColor3"] = v_u_15,
					["AnchorPoint"] = Vector2.new(0.5, 0.5),
					["Size"] = UDim2.fromOffset(22, 22),
					["Parent"] = v249
				}
				local v251 = v_u_10.new("Frame", v250)
				v_u_10.corner(v251, 11)
				local v252 = {
					["ApplyStrokeMode"] = nil,
					["Color"] = nil,
					["Thickness"] = 2,
					["Parent"] = nil,
					["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
					["Color"] = v247.color,
					["Parent"] = v251
				}
				v_u_10.new("UIStroke", v252)
				local v253 = {
					["Text"] = nil,
					["TextSize"] = 13,
					["Size"] = nil,
					["Parent"] = nil,
					["Text"] = v247.icon,
					["Size"] = UDim2.fromScale(1, 1),
					["Parent"] = v251
				}
				v_u_10.text(v253)
				local v254 = {
					["Text"] = nil,
					["FontFace"] = nil,
					["TextSize"] = nil,
					["TextColor3"] = nil,
					["TextStrokeColor3"] = nil,
					["TextStrokeTransparency"] = 0.05,
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["AutomaticSize"] = nil,
					["Parent"] = nil,
					["Text"] = v247.th,
					["FontFace"] = v_u_10.FONT_BOLD,
					["TextSize"] = v247.rank >= 2 and 12 or 11
				}
				local v255
				if v247.rank >= 2 then
					v255 = v_u_16.ink
				else
					v255 = v_u_16.dim
				end
				v254.TextColor3 = v255
				v254.TextStrokeColor3 = v_u_15
				v254.AnchorPoint = Vector2.new(0.5, 0)
				v254.Position = UDim2.fromOffset(0, 12)
				v254.Size = UDim2.fromOffset(0, 15)
				v254.AutomaticSize = Enum.AutomaticSize.X
				v254.Parent = v249
				local v256 = v_u_179
				local v257 = {
					["place"] = nil,
					["holder"] = nil,
					["label"] = nil,
					["near"] = false,
					["place"] = v247,
					["holder"] = v249,
					["label"] = v_u_10.text(v254)
				}
				table.insert(v256, v257)
			end
		end
	end
	local function v_u_296() -- name: drawRoute
		-- upvalues: (copy) v_u_184, (ref) v_u_182, (ref) v_u_185, (ref) v_u_188, (ref) v_u_177, (ref) v_u_16, (ref) v_u_48, (ref) v_u_178
		for _, v259 in v_u_184 do
			v259:Destroy()
		end
		table.clear(v_u_184)
		if v_u_182 then
			v_u_185 = v_u_188
			local v260 = 6 / v_u_185 / 2
			local v261 = math.max(1, v260)
			local v262 = v261 + 1.8 / v_u_185
			for v263 = 1, #v_u_182 - 1 do
				local v264 = v_u_184
				local v265 = v_u_177
				local v266 = v_u_182[v263]
				local v267 = v_u_182[v263 + 1]
				local v268 = v_u_16.routeEdge
				local v269 = v267 - v266
				local v270 = (v266 + v267) / 2
				local v271 = v_u_48
				local v272 = v270.X
				local v273 = v270.Y
				local v274 = v269.Magnitude + v262 * 2
				local v275 = v262 * 2
				local v276 = v269.Y
				local v277 = v269.X
				local v278 = math.atan2(v276, v277)
				local v279 = v271(v265, v272, v273, v274, v275, math.deg(v278), v268, v262, nil)
				table.insert(v264, v279)
				local v280 = v_u_184
				local v281 = v_u_178
				local v282 = v_u_182[v263]
				local v283 = v_u_182[v263 + 1]
				local v284 = v_u_16.route
				local v285 = v283 - v282
				local v286 = (v282 + v283) / 2
				local v287 = v_u_48
				local v288 = v286.X
				local v289 = v286.Y
				local v290 = v285.Magnitude + v261 * 2
				local v291 = v261 * 2
				local v292 = v285.Y
				local v293 = v285.X
				local v294 = math.atan2(v292, v293)
				local v295 = v287(v281, v288, v289, v290, v291, math.deg(v294), v284, v261, nil)
				table.insert(v280, v295)
			end
		end
	end
	local function v_u_403(p297) -- name: step
		-- upvalues: (ref) v_u_19, (ref) v_u_188, (ref) v_u_175, (ref) v_u_190, (ref) v_u_189, (ref) v_u_174, (ref) v_u_176, (copy) v_u_133, (copy) v_u_145, (copy) v_u_111, (copy) v_u_112, (ref) v_u_187, (copy) v_u_109, (copy) v_u_110, (copy) v_u_173, (copy) v_u_179, (ref) v_u_180, (ref) v_u_186, (ref) v_u_182, (ref) v_u_183, (ref) v_u_8, (copy) v_u_296, (ref) v_u_104, (ref) v_u_65, (copy) v_u_158, (ref) v_u_52, (ref) v_u_9, (copy) v_u_154, (ref) v_u_26, (ref) v_u_185, (ref) v_u_137, (ref) v_u_12, (copy) v_u_156, (copy) v_u_148, (copy) v_u_121
		local v298 = v_u_19.Character
		local v299
		if v298 then
			v299 = v298:FindFirstChild("HumanoidRootPart")
		else
			v299 = v298
		end
		local v300, v301, v302
		if v299 then
			local v303 = v298:FindFirstChildOfClass("Humanoid")
			if v303 then
				v303 = v303.SeatPart
			end
			local v304 = v303 or v299
			v300 = v304.Position
			v301 = v304.AssemblyLinearVelocity
			v302 = v304.CFrame.LookVector
		else
			v300 = nil
			v301 = nil
			v302 = nil
		end
		if v300 then
			local v305 = Vector2.new(v301.X, v301.Z)
			local v306 = v305.Magnitude
			local v307 = v306 / 150
			local v308 = v_u_188
			local v309 = math.clamp(v307, 0, 1) * -0.31000000000000005 + 0.55 - v_u_188
			local v310 = 1.5 * p297
			v_u_188 = v308 + v309 * math.min(1, v310)
			v_u_175.Scale = v_u_188
			local v311
			if v306 > 6 then
				v311 = v305.Unit
			else
				v311 = Vector2.new(v302.X, v302.Z)
			end
			if v311.Magnitude > 0.2 then
				local v312 = v311.Y
				local v313 = v311.X
				local v314 = -1.5707963267948966 - math.atan2(v312, v313)
				if not v_u_190 then
					v_u_189 = v314
					v_u_190 = true
				end
				local v315 = (v314 - v_u_189 + 3.141592653589793) % 6.283185307179586 - 3.141592653589793
				local v316 = v_u_189
				local v317 = 4 * p297
				v_u_189 = v316 + v315 * math.min(1, v317)
			end
			local v318 = v_u_189
			v_u_174.Rotation = math.deg(v318)
			v_u_176.Position = UDim2.fromOffset(-v300.X, -v300.Z)
			local v319 = v_u_133
			local v320 = v302.Z
			local v321 = v302.X
			local v322 = math.atan2(v320, v321) + v_u_189
			v319.Rotation = math.deg(v322) + 90
			local v323 = v_u_145
			local v324 = v306 * 1.008 + 0.5
			local v325 = math.floor(v324)
			v323.Text = tostring(v325)
			local v326 = v_u_189
			local v327 = math.cos(v326)
			local v328 = v_u_189
			local v329 = math.sin(v328)
			local v330 = os.clock()
			if v330 - v_u_187 > 0.25 then
				v_u_187 = v330
				local v331 = v_u_111
				local v332 = v_u_109 - v_u_111
				local v333 = math.max(v331, v332)
				local v334 = v_u_112
				local v335 = v_u_110 - v_u_112
				local v336 = math.max(v334, v335)
				local v337 = v333 * v333 + v336 * v336
				local v338 = math.sqrt(v337) / v_u_188 + 30
				for _, v339 in v_u_173 do
					local v340 = v339.x - v300.X
					local v341 = v339.z - v300.Z
					local v342 = v340 * v340 + v341 * v341 < (v338 + v339.r) ^ 2
					if v339.frame.Visible == v342 then
						continue
					end
					v339.frame.Visible = v342
				end
				local v343 = {}
				for _, v344 in v_u_179 do
					local v345 = v344.place.x
					local v346 = v344.place.z
					local v347 = (v345 - v300.X) * v_u_188
					local v348 = (v346 - v300.Z) * v_u_188
					local v349 = v_u_111 + v347 * v327 - v348 * v329
					local v350 = v_u_112 + v347 * v329 + v348 * v327
					local v351
					if v349 > -60 and (v349 < v_u_109 + 60 and v350 > 84) then
						v351 = v350 < v_u_110 - 96 + 20
					else
						v351 = false
					end
					v344.near = v351
					if v344.near then
						v344.sx = v349
						v344.sy = v350
						table.insert(v343, v344)
					else
						v344.holder.Visible = false
					end
				end
				table.sort(v343, function(p352, p353)
					-- upvalues: (ref) v_u_111, (ref) v_u_112
					if p352.place.rank == p353.place.rank then
						return (p352.sx - v_u_111) ^ 2 + (p352.sy - v_u_112) ^ 2 < (p353.sx - v_u_111) ^ 2 + (p353.sy - v_u_112) ^ 2
					else
						return p352.place.rank > p353.place.rank
					end
				end)
				local v_u_354 = {}
				local function v360(p355, p356, p357, p358) -- name: free
					-- upvalues: (copy) v_u_354
					for _, v359 in v_u_354 do
						if p355 >= v359[3] or (v359[1] >= p357 or (p356 >= v359[4] or v359[2] >= p358)) then
							continue
						end
						return false
					end
					return true
				end
				for _, v361 in v343 do
					local v362 = v361.sx
					local v363 = v361.sy
					local v364 = v360(v362 - 13, v363 - 13, v362 + 13, v363 + 13)
					local v365 = v361.label.TextBounds.X
					local v366 = utf8.len(v361.place.th) or 40
					local v367 = math.max(v365, v366)
					local v368 = v362 - v367 / 2 - 2
					local v369 = v363 + 13 - 2
					local v370 = v362 + v367 / 2 + 2
					local v371 = v363 + 13 + 15
					local v372
					if v364 then
						v372 = v360(v368, v369, v370, v371)
					else
						v372 = v364
					end
					v361.holder.Visible = v364
					v361.label.Visible = v372
					if v364 then
						local v373 = {
							v362 - 13,
							v363 - 13,
							v362 + 13,
							v363 + 13
						}
						table.insert(v_u_354, v373)
					end
					if not v372 then
						continue
					end
					table.insert(v_u_354, {
						v368,
						v369,
						v370,
						v371
					})
				end
			end
			for _, v374 in v_u_179 do
				if not (v374.near and v374.holder.Visible) then
					continue
				end
				local v375 = v374.place.x
				local v376 = v374.place.z
				local v377 = (v375 - v300.X) * v_u_188
				local v378 = (v376 - v300.Z) * v_u_188
				local v379 = v_u_111 + v377 * v327 - v378 * v329
				local v380 = v_u_112 + v377 * v329 + v378 * v327
				v374.holder.Position = UDim2.fromOffset(v379, v380)
			end
			if v_u_180 then
				if v330 - v_u_186 > 0.5 then
					v_u_186 = v330
					local v381, v382 = v_u_8.route(v300, v_u_180)
					v_u_182 = v381
					v_u_183 = v382
					v_u_296()
					local v383
					if v311.Magnitude > 0.2 then
						v383 = v311.Unit
					else
						v383 = nil
					end
					local v384, v385 = v_u_104(v_u_182, v383, (v_u_65(Vector2.new(v300.X, v300.Z))))
					if v385 == "arrive" then
						v_u_158.Text = "\224\184\149\224\184\163\224\184\135\224\185\132\224\184\155\224\184\136\224\184\153\224\184\150\224\184\182\224\184\135\224\184\136\224\184\184\224\184\148\224\184\171\224\184\161\224\184\178\224\184\162"
					elseif v384 < 8 then
						v_u_158.Text = v_u_52[v385] .. "\224\184\149\224\184\173\224\184\153\224\184\153\224\184\181\224\185\137"
					else
						v_u_158.Text = ("\224\184\173\224\184\181\224\184\129 %s %s"):format(v_u_9.distanceText(v384), v_u_52[v385])
					end
					v_u_154.Rotation = v385 == "arrive" and 90 or (v_u_26[v385] or 90)
				elseif v_u_185 then
					local v386 = v_u_188 / v_u_185 - 1
					if math.abs(v386) > 0.2 then
						v_u_296()
					end
				end
				local v387
				if v_u_137.length then
					v387 = v_u_137.length()
				else
					v387 = v_u_12.routeLength
				end
				local v388 = v387 or v_u_183
				local v389 = v_u_9.distanceText(v388)
				if v_u_156.Text ~= v389 then
					v_u_156.Text = v389
					local v390 = v_u_148
					local v391 = v388 / 40 / 60
					local v392 = math.ceil(v391)
					v390.Text = ("%s  \226\128\162  %s"):format(("%d \224\184\153\224\184\178\224\184\151\224\184\181"):format((math.max(1, v392))), v389)
				end
				local v393 = v_u_180.X
				local v394 = v_u_180.Z
				local v395 = (v393 - v300.X) * v_u_188
				local v396 = (v394 - v300.Z) * v_u_188
				local v397 = v_u_111 + v395 * v327 - v396 * v329
				local v398 = v_u_112 + v395 * v329 + v396 * v327
				local v399 = v_u_109 - 18
				local v400 = math.clamp(v397, 18, v399)
				local v401 = v_u_110 - 96 - 6
				local v402 = math.clamp(v398, 152, v401)
				v_u_121.Position = UDim2.fromOffset(v400, v402)
			end
		end
	end
	v_u_4.RenderStepped:Connect(function(p404)
		-- upvalues: (ref) v_u_171, (ref) v_u_172, (copy) p_u_107, (copy) v_u_403
		if v_u_171 and (v_u_172 and p_u_107()) then
			v_u_403((math.min(p404, 0.1)))
		end
	end)
	local function v405() -- name: dismiss
		-- upvalues: (copy) v_u_113
		v_u_113.dismissed:Fire()
	end
	v160.Activated:Connect(v405)
	v169.Activated:Connect(v405)
	function v_u_113.setTarget(p406, p407) -- name: setTarget
		-- upvalues: (ref) v_u_180, (ref) v_u_181, (ref) v_u_182, (ref) v_u_183, (ref) v_u_186, (ref) v_u_172, (copy) v_u_184, (copy) v_u_121, (ref) v_u_16, (copy) v_u_123, (copy) v_u_128, (copy) v_u_126, (copy) v_u_165, (copy) v_u_167, (copy) v_u_156, (copy) v_u_158, (copy) v_u_148
		v_u_180 = p406
		v_u_181 = p407
		v_u_182 = nil
		v_u_183 = 0
		v_u_186 = (-1 / 0)
		if v_u_172 then
			for _, v408 in v_u_184 do
				v408:Destroy()
			end
			table.clear(v_u_184)
		end
		v_u_121.Visible = v_u_180 ~= nil
		if v_u_181 then
			local v409 = v_u_181.color
			if not v409 then
				if v_u_181.step == 1 then
					v409 = v_u_16.pick
				else
					v409 = v_u_16.drop
				end
			end
			v_u_123.BackgroundColor3 = v409
			v_u_128.BackgroundColor3 = v409
			local v410 = v_u_126
			local v411 = v_u_181.pinText
			if not v411 then
				local v412 = v_u_181.step or 1
				v411 = tostring(v412)
			end
			v410.Text = v411
			v_u_165.Text = ("<font color=\"#%s\">%s</font>  %s"):format(v409:ToHex(), v_u_181.verb or "", (v_u_181.who or ""):gsub("[<>&]", ""))
			v_u_167.Text = v_u_181.where or ""
		end
		v_u_156.Text = ""
		v_u_158.Text = "\224\184\129\224\184\179\224\184\165\224\184\177\224\184\135\224\184\171\224\184\178\224\185\128\224\184\170\224\185\137\224\184\153\224\184\151\224\184\178\224\184\135..."
		v_u_148.Text = "..."
	end
	function v_u_113.isShown() -- name: isShown
		-- upvalues: (ref) v_u_171
		return v_u_171
	end
	function v_u_113.show(p413) -- name: show
		-- upvalues: (ref) v_u_171, (copy) v_u_258, (ref) v_u_186, (ref) v_u_187, (ref) v_u_190, (copy) v_u_115, (ref) v_u_191, (ref) v_u_5, (ref) v_u_13
		if v_u_171 then
			return
		else
			v_u_171 = true
			v_u_258()
			v_u_186 = (-1 / 0)
			v_u_187 = (-1 / 0)
			v_u_190 = false
			v_u_115.Visible = true
			if v_u_191 then
				v_u_191:Cancel()
			end
			if p413 then
				v_u_115.Position = UDim2.fromScale(0, 1)
				v_u_191 = v_u_5:Create(v_u_115, v_u_13, {
					["Position"] = UDim2.new()
				})
				v_u_191:Play()
			else
				v_u_115.Position = UDim2.new()
			end
		end
	end
	function v_u_113.hide(p414) -- name: hide
		-- upvalues: (ref) v_u_171, (ref) v_u_191, (copy) v_u_115, (ref) v_u_5, (ref) v_u_14
		if v_u_171 then
			v_u_171 = false
			if v_u_191 then
				v_u_191:Cancel()
			end
			if p414 and v_u_115.Visible then
				v_u_191 = v_u_5:Create(v_u_115, v_u_14, {
					["Position"] = UDim2.fromScale(0, 1)
				})
				v_u_191.Completed:Connect(function(p415)
					-- upvalues: (ref) v_u_171, (ref) v_u_115
					if p415 == Enum.PlaybackState.Completed and not v_u_171 then
						v_u_115.Visible = false
					end
				end)
				v_u_191:Play()
			else
				v_u_115.Position = UDim2.fromScale(0, 1)
				v_u_115.Visible = false
			end
		else
			return
		end
	end
	return v_u_113
end
return v34