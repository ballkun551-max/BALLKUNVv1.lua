-- Path: StarterPlayer/PlayerModule/PlayerModuleInternal
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = game:GetService("RunService")
local v2 = require(script.Parent:WaitForChild("CommonUtils"))
require(script.Parent.Types)
local v_u_3 = v2.get("CharacterUtil")
local v_u_4 = v2.get("ConnectionUtil")
local v_u_5 = v2.get("EventBus")
local v_u_6 = v2.get("FlagUtil").getUserFlag("UserPlayerModuleEngineAPI")
local v_u_7 = require(script.Parent)
local v_u_8 = require(script.Parent:WaitForChild("CameraModule"))
local v_u_9 = require(script.Parent:WaitForChild("ControlModule"))
local v_u_10 = require(script.Parent:WaitForChild("EngineInterface"))
local v_u_11 = require(script.Parent:WaitForChild("InputSampler"))
local v_u_12 = require(script.Parent:WaitForChild("ServerAuthority"))
local v_u_13 = {}
v_u_13.__index = v_u_13
function v_u_13.new() -- name: new
	-- upvalues: (copy) v_u_7, (copy) v_u_4, (copy) v_u_5, (copy) v_u_11, (copy) v_u_13
	local v14 = {}
	local v15 = {
		["playerModule"] = nil,
		["controlModule"] = nil,
		["engineInterface"] = nil,
		["connectionUtil"] = nil,
		["eventBus"] = nil,
		["isServerAuthority"] = false,
		["playerModule"] = v_u_7,
		["controlModule"] = {
			["isJumping"] = false,
			["moveVector"] = nil,
			["worldMoveVector"] = nil,
			["actions"] = nil,
			["enabled"] = true,
			["moveVector"] = Vector2.new(),
			["worldMoveVector"] = Vector3.new(),
			["actions"] = {}
		},
		["engineInterface"] = {
			["player"] = nil,
			["character"] = nil,
			["humanoid"] = nil,
			["characterChanged"] = false
		},
		["connectionUtil"] = v_u_4.new(),
		["eventBus"] = v_u_5.new()
	}
	v14.data = v15
	v14.inputSampler = v_u_11.new()
	local v16 = v_u_13
	return setmetatable(v14, v16)
end
function v_u_13.start(p_u_17) -- name: start
	-- upvalues: (copy) v_u_3, (copy) v_u_6, (copy) v_u_10, (copy) v_u_12, (copy) v_u_9, (copy) v_u_1, (copy) v_u_8
	p_u_17.data.connectionUtil:trackConnection("ONLOCALPLAYER", v_u_3.onLocalPlayer(function(p18)
		-- upvalues: (ref) v_u_6, (ref) v_u_10, (copy) p_u_17, (ref) v_u_12, (ref) v_u_9, (ref) v_u_1, (ref) v_u_8, (ref) v_u_3
		if v_u_6 then
			v_u_10.update(p_u_17.data)
			v_u_12.initialize(p_u_17.data)
			v_u_9:initialize(p_u_17.data)
			v_u_1:BindToRenderStep("PLAYERMODULE_RENDERSTEPPED_INPUT", Enum.RenderPriority.Input.Value, function(p19)
				-- upvalues: (ref) v_u_10, (ref) p_u_17, (ref) v_u_9
				v_u_10.update(p_u_17.data)
				v_u_9:Update(p_u_17.data, p19)
			end)
			v_u_1:BindToRenderStep("PLAYERMODULE_RENDERSTEPPED_CAMERA", Enum.RenderPriority.Camera.Value, function(p20)
				-- upvalues: (ref) v_u_8, (ref) p_u_17, (ref) v_u_10
				v_u_8:Update(p_u_17.data, p20)
				p_u_17.inputSampler:Update(p_u_17.data)
				v_u_10.cleanDirty(p_u_17.data)
			end)
		else
			p_u_17.data.engineInterface.player = p18
			v_u_12.initialize(p_u_17.data)
			v_u_9:initialize(p_u_17.data)
			v_u_1:BindToRenderStep("PLAYERMODULE_RENDERSTEPPED_INPUT", Enum.RenderPriority.Input.Value, function(p21)
				-- upvalues: (ref) p_u_17, (ref) v_u_3, (ref) v_u_9
				p_u_17.data.engineInterface.character = v_u_3.getCharacter()
				if p_u_17.data.engineInterface.character then
					v_u_9:Update(p_u_17.data, p21)
				end
			end)
			p_u_17.data.connectionUtil:trackBoundFunction("PLAYERMODULE_RENDERSTEPPED_INPUT", function()
				-- upvalues: (ref) v_u_1
				v_u_1:UnbindFromRenderStep("PLAYERMODULE_RENDERSTEPPED_INPUT")
			end)
			v_u_1:BindToRenderStep("PLAYERMODULE_RENDERSTEPPED_CAMERA", Enum.RenderPriority.Camera.Value, function(p22)
				-- upvalues: (ref) v_u_8, (ref) p_u_17
				v_u_8:Update(p_u_17.data, p22)
				p_u_17.inputSampler:Update(p_u_17.data)
			end)
			p_u_17.data.connectionUtil:trackBoundFunction("PLAYERMODULE_RENDERSTEPPED_CAMERA", function()
				-- upvalues: (ref) v_u_1
				v_u_1:UnbindFromRenderStep("PLAYERMODULE_RENDERSTEPPED_CAMERA")
			end)
		end
	end))
end
if not v_u_6 then
	function v_u_13.stop(p23) -- name: stop
		p23.data.connectionUtil:disconnectAll()
	end
end
return v_u_13