-- Path: ReplicatedStorage/LiveRpm
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

return setmetatable({}, {
	["__mode"] = "k"
})