-- Path: Players/ygggggg55551/PlayerScripts/BonnetClient
-- Class: LocalScript  true/Enum.RunContext.Legacy
-- Decompiled by BALL KUN Universal Map Dump

local v1 = game:GetService("CollectionService")
local v2 = game:GetService("RunService")
local v_u_3 = {}
local function v_u_6(p4) -- name: track
	-- upvalues: (copy) v_u_3
	if v_u_3[p4] or not p4:IsA("Model") or (p4:GetAttribute("KitLights") == true or p4:GetAttribute("KitBackfire") == true) then
		return
	else
		local v5 = p4:FindFirstChild("Chassis")
		if v5 then
			v5 = v5:FindFirstChild("BonnetMotor")
		end
		if v5 and v5:IsA("Motor6D") then
			v_u_3[p4] = {
				["motor"] = nil,
				["base"] = nil,
				["angle"] = nil,
				["sign"] = nil,
				["k"] = 0,
				["motor"] = v5,
				["base"] = v5:GetAttribute("BaseC0") or v5.C0,
				["angle"] = v5:GetAttribute("OpenAngle") or 0.8726646259971648,
				["sign"] = v5:GetAttribute("OpenSign") or 1
			}
		end
	end
end
local function v10(p_u_7) -- name: watch
	-- upvalues: (copy) v_u_6, (copy) v_u_3
	v_u_6(p_u_7)
	if not v_u_3[p_u_7] and p_u_7:IsA("Model") then
		local v_u_8 = nil
		v_u_8 = p_u_7.DescendantAdded:Connect(function(p9)
			-- upvalues: (ref) v_u_6, (copy) p_u_7, (ref) v_u_3, (ref) v_u_8
			if p9.Name == "BonnetMotor" then
				v_u_6(p_u_7)
				if v_u_3[p_u_7] or not p_u_7.Parent then
					v_u_8:Disconnect()
				end
			end
		end)
	end
end
v1:GetInstanceAddedSignal("GTACar"):Connect(v10)
v1:GetInstanceRemovedSignal("GTACar"):Connect(function(p11) -- name: untrack
	-- upvalues: (copy) v_u_3
	v_u_3[p11] = nil
end)
for _, v12 in v1:GetTagged("GTACar") do
	v10(v12)
end
v2.RenderStepped:Connect(function(p13)
	-- upvalues: (copy) v_u_3
	for v14, v15 in v_u_3 do
		if v15.motor.Parent and v14.Parent then
			local v16 = v14:GetAttribute("HoodOpen") == true and 1 or 0
			if v15.k == v16 then
				continue
			end
			local v17 = v14:GetAttribute("HoodOpenTime") or 1.2
			local v18 = 1 / math.max(v17, 0.1)
			local v19 = v15.k
			local v20 = v16 - v15.k
			local v21 = v19 + math.sign(v20) * v18 * p13
			v15.k = math.clamp(v21, 0, 1)
			local v22 = v15.k
			local v23 = v22 * v22 * (3 - 2 * v22)
			v15.motor.C0 = v15.base * CFrame.fromAxisAngle(Vector3.new(1, 0, 0), v15.sign * v15.angle * v23)
		else
			v_u_3[v14] = nil
		end
	end
end)
local v_u_24 = {}
local function v_u_27(p25) -- name: trackBoot
	-- upvalues: (copy) v_u_24
	if v_u_24[p25] or not p25:IsA("Model") then
		return
	else
		local v26 = p25:FindFirstChild("Chassis")
		if v26 then
			v26 = v26:FindFirstChild("BootMotor")
		end
		if v26 and v26:IsA("Motor6D") then
			v_u_24[p25] = {
				["motor"] = nil,
				["base"] = nil,
				["angle"] = nil,
				["sign"] = nil,
				["k"] = 0,
				["motor"] = v26,
				["base"] = v26:GetAttribute("BaseC0") or v26.C0,
				["angle"] = v26:GetAttribute("OpenAngle") or 1.3962634015954636,
				["sign"] = v26:GetAttribute("OpenSign") or 1
			}
		end
	end
end
v1:GetInstanceAddedSignal("GTACar"):Connect(function(p28)
	-- upvalues: (copy) v_u_27
	task.defer(v_u_27, p28)
end)
v1:GetInstanceRemovedSignal("GTACar"):Connect(function(p29)
	-- upvalues: (copy) v_u_24
	v_u_24[p29] = nil
end)
for _, v30 in v1:GetTagged("GTACar") do
	v_u_27(v30)
end
v2.RenderStepped:Connect(function(p31)
	-- upvalues: (copy) v_u_24
	for v32, v33 in v_u_24 do
		if v33.motor.Parent and v32.Parent then
			local v34 = v32:GetAttribute("BootOpen") == true and 1 or 0
			if v33.k == v34 then
				continue
			end
			local v35 = v32:GetAttribute("BootOpenTime") or 0.9
			local v36 = 1 / math.max(v35, 0.1)
			local v37 = v33.k
			local v38 = v34 - v33.k
			local v39 = v37 + math.sign(v38) * v36 * p31
			v33.k = math.clamp(v39, 0, 1)
			local v40 = v33.k
			local v41 = v40 * v40 * (3 - 2 * v40)
			v33.motor.C0 = v33.base * CFrame.fromAxisAngle(Vector3.new(1, 0, 0), v33.sign * v33.angle * v41)
		else
			v_u_24[v32] = nil
		end
	end
end)