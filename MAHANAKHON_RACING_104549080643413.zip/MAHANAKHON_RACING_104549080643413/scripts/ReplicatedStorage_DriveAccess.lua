-- Path: ReplicatedStorage/DriveAccess
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v1 = game:GetService("Players")
local v_u_2 = {}
local v_u_3 = setmetatable({}, {
	["__mode"] = "k"
})
function v_u_2.isOwner(p4, p5) -- name: isOwner
	local v6 = p5:GetAttribute("OwnerUserId")
	return v6 == nil and true or v6 == p4.UserId
end
local function v_u_11(p7, p8) -- name: entry
	-- upvalues: (copy) v_u_3
	local v9 = v_u_3[p7]
	if not v9 then
		v9 = {}
		v_u_3[p7] = v9
	end
	local v10 = v9[p8]
	if v10 and (v10.friends ~= nil and os.clock() - v10.at > 300) then
		v10 = nil
	end
	if not v10 then
		v10 = {
			["at"] = os.clock()
		}
		v9[p8] = v10
	end
	return v10
end
local function v_u_18(p12, p13, p14) -- name: check
	p14.busy = true
	local v15 = p12.IsFriendsWith
	local v16, v17 = pcall(v15, p12, p13)
	if v16 then
		v16 = v17 == true
	end
	p14.friends = v16
	p14.at = os.clock()
	p14.busy = false
end
function v_u_2.mayDrive(p19, p20) -- name: mayDrive
	-- upvalues: (copy) v_u_2, (copy) v_u_11
	if v_u_2.isOwner(p19, p20) then
		return true
	end
	local v21 = p20:GetAttribute("OwnerUserId")
	local v22 = v_u_11(p19, v21)
	if v22.friends == nil then
		if v22.busy then
			local v23 = os.clock()
			while v22.busy and os.clock() - v23 < 10 do
				task.wait(0.1)
			end
		else
			v22.busy = true
			local v24 = p19.IsFriendsWith
			local v25, v26 = pcall(v24, p19, v21)
			if v25 then
				v25 = v26 == true
			end
			v22.friends = v25
			v22.at = os.clock()
			v22.busy = false
		end
	end
	return v22.friends == true
end
function v_u_2.mayDriveNow(p27, p28) -- name: mayDriveNow
	-- upvalues: (copy) v_u_2, (copy) v_u_11, (copy) v_u_18
	if v_u_2.isOwner(p27, p28) then
		return true
	end
	local v29 = p28:GetAttribute("OwnerUserId")
	local v30 = v_u_11(p27, v29)
	if v30.friends == nil and not v30.busy then
		task.spawn(v_u_18, p27, v29, v30)
	end
	return v30.friends == true
end
v1.PlayerRemoving:Connect(function(p31)
	-- upvalues: (copy) v_u_3
	v_u_3[p31] = nil
end)
return v_u_2