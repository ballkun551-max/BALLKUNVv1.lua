-- Path: Players/ygggggg55551/PlayerScripts/PodiumPose
-- Class: LocalScript  true/Enum.RunContext.Legacy
-- Decompiled by BALL KUN Universal Map Dump

local v1 = game:GetService("RunService")
local v_u_2 = {
	"RightShoulder",
	"RightElbow",
	"RightWrist",
	"LeftShoulder",
	"LeftElbow",
	"LeftWrist",
	"Waist",
	"Neck",
	"Root"
}
local v_u_3 = CFrame.Angles
local v_u_4 = {}
local v_u_5 = {}
local function v_u_10(p6) -- name: rig
	-- upvalues: (copy) v_u_5, (copy) v_u_2
	local v7 = v_u_5[p6]
	if v7 and (v7.RightShoulder and v7.RightShoulder.Parent) then
		return v7
	end
	local v8 = {}
	for _, v9 in p6:GetDescendants() do
		if not ((v9:IsA("AnimationConstraint") or v9:IsA("Motor6D")) and table.find(v_u_2, v9.Name)) then
			continue
		end
		v8[v9.Name] = v9
	end
	v_u_5[p6] = v8
	return v8
end
local v_u_98 = { function(p11, p12)
		-- upvalues: (copy) v_u_3
		local v13 = p12 * 4.2
		local v14 = (1 - math.cos(v13)) / 2
		local v15 = 2.961592653589793 - v14 * 0.42
		local v16 = 3.141592653589793 - v15
		local v17 = v_u_3(v15, 0, -0.1)
		local v18 = p11.RightShoulder
		if v18 then
			v18.Transform = v17
		end
		local v19 = v_u_3(v16, 0, 0)
		local v20 = p11.RightElbow
		if v20 then
			v20.Transform = v19
		end
		local v21 = 2.55 - v14 * 0.3
		local v22 = v14 * 0.35 + 0.95
		local v23 = v_u_3(v21, 0, 0.32)
		local v24 = p11.LeftShoulder
		if v24 then
			v24.Transform = v23
		end
		local v25 = v_u_3(v22, 0, 0)
		local v26 = p11.LeftElbow
		if v26 then
			v26.Transform = v25
		end
		local v27 = v_u_3
		local v28 = v14 * 0.04 + 0.07
		local v29 = p12 * 0.7
		local v30 = v27(v28, math.sin(v29) * 0.12, 0)
		local v31 = p11.Waist
		if v31 then
			v31.Transform = v30
		end
		local v32 = v_u_3
		local v33 = p12 * 0.7
		local v34 = v32(0.22, math.sin(v33) * -0.1, 0)
		local v35 = p11.Neck
		if v35 then
			v35.Transform = v34
		end
		local v36 = CFrame.new(0, v14 * 0.1, 0)
		local v37 = p11.Root
		if v37 then
			v37.Transform = v36
		end
	end, function(p38, p39)
		-- upvalues: (copy) v_u_3
		local v40 = p39 * 1.6
		local v41 = math.sin(v40)
		local v42 = p39 % 7
		local v43
		if v42 < 1.8 then
			local v44 = v42 / 1.8 * 2 * 3.141592653589793
			v43 = (1 - math.cos(v44)) / 2
		else
			v43 = 0
		end
		local v45 = 1.25 + 0.75 * v43
		local v46 = 3.141592653589793 - v45
		local v47 = v_u_3(v45, 0, 0.22)
		local v48 = p38.RightShoulder
		if v48 then
			v48.Transform = v47
		end
		local v49 = v_u_3(v46, 0, 0)
		local v50 = p38.RightElbow
		if v50 then
			v50.Transform = v49
		end
		local v51 = 1.05 + 0.75 * v43
		local v52 = 1.55 - 0.15 * v43
		local v53 = v_u_3(v51, 0, -0.5)
		local v54 = p38.LeftShoulder
		if v54 then
			v54.Transform = v53
		end
		local v55 = v_u_3(v52, 0, 0)
		local v56 = p38.LeftElbow
		if v56 then
			v56.Transform = v55
		end
		local v57 = v_u_3
		local v58 = v41 * 0.02
		local v59 = p39 * 0.45
		local v60 = v57(v58, math.sin(v59) * 0.14, 0)
		local v61 = p38.Waist
		if v61 then
			v61.Transform = v60
		end
		local v62 = v_u_3
		local v63 = 0.05 + 0.15 * v43
		local v64 = p39 * 0.45
		local v65 = v62(v63, math.sin(v64) * -0.12, 0)
		local v66 = p38.Neck
		if v66 then
			v66.Transform = v65
		end
		local v67 = CFrame.new(0, v41 * 0.03, 0)
		local v68 = p38.Root
		if v68 then
			v68.Transform = v67
		end
	end, function(p69, p70)
		-- upvalues: (copy) v_u_3
		local v71 = p70 * 1.5 + 1
		local v72 = math.sin(v71)
		local v73 = (p70 + 3) % 8
		local v74
		if v73 < 2 then
			local v75 = v73 / 2 * 2 * 3.141592653589793
			v74 = (1 - math.cos(v75)) / 2
		else
			v74 = 0
		end
		local v76 = 0.5 + 1.6 * v74
		local v77 = 3.141592653589793 - v76
		local v78 = v_u_3(v76, 0, -0.12)
		local v79 = p69.RightShoulder
		if v79 then
			v79.Transform = v78
		end
		local v80 = v_u_3(v77, 0, 0)
		local v81 = p69.RightElbow
		if v81 then
			v81.Transform = v80
		end
		local v82 = v_u_3(v72 * 0.04 + 0.12, 0, 0.16)
		local v83 = p69.LeftShoulder
		if v83 then
			v83.Transform = v82
		end
		local v84 = v_u_3(0.3, 0, 0)
		local v85 = p69.LeftElbow
		if v85 then
			v85.Transform = v84
		end
		local v86 = v_u_3
		local v87 = v72 * 0.02
		local v88 = p70 * 0.5
		local v89 = v86(v87, math.sin(v88) * -0.13, 0)
		local v90 = p69.Waist
		if v90 then
			v90.Transform = v89
		end
		local v91 = v_u_3
		local v92 = 0.04 + 0.12 * v74
		local v93 = p70 * 0.5
		local v94 = v91(v92, math.sin(v93) * 0.1, 0)
		local v95 = p69.Neck
		if v95 then
			v95.Transform = v94
		end
		local v96 = CFrame.new(0, v72 * 0.03, 0)
		local v97 = p69.Root
		if v97 then
			v97.Transform = v96
		end
	end }
local function v_u_101(p99) -- name: add
	-- upvalues: (copy) v_u_98, (copy) v_u_4
	local v100 = p99:IsA("Model")
	if v100 then
		v100 = p99:GetAttribute("PodiumRank")
	end
	if v100 and v_u_98[v100] then
		v_u_4[p99] = v100
	end
end
local function v_u_106(p102) -- name: watch
	-- upvalues: (copy) v_u_98, (copy) v_u_4, (copy) v_u_101, (copy) v_u_5
	for _, v103 in p102:GetChildren() do
		local v104 = v103:IsA("Model")
		if v104 then
			v104 = v103:GetAttribute("PodiumRank")
		end
		if not (v104 and v_u_98[v104]) then
			continue
		end
		v_u_4[v103] = v104
	end
	p102.ChildAdded:Connect(v_u_101)
	p102.ChildRemoved:Connect(function(p105)
		-- upvalues: (ref) v_u_4, (ref) v_u_5
		v_u_4[p105] = nil
		v_u_5[p105] = nil
	end)
end
local v107 = workspace:WaitForChild("Map")
local v108 = v107:FindFirstChild("DragPodium")
if v108 then
	v_u_106(v108)
else
	local v_u_109 = nil
	v_u_109 = v107.ChildAdded:Connect(function(p110)
		-- upvalues: (ref) v_u_109, (copy) v_u_106
		if p110.Name == "DragPodium" then
			v_u_109:Disconnect()
			v_u_106(p110)
		end
	end)
end
v1.Heartbeat:Connect(function()
	-- upvalues: (copy) v_u_4, (copy) v_u_98, (copy) v_u_10
	if next(v_u_4) ~= nil then
		local v111 = workspace.CurrentCamera
		if v111 then
			v111 = v111.CFrame.Position
		end
		local v112 = os.clock()
		for v113, v114 in v_u_4 do
			local v115 = v113.PrimaryPart or v113:FindFirstChild("HumanoidRootPart")
			if not v115 or v111 and (v115.Position - v111).Magnitude >= 260 then
				continue
			end
			v_u_98[v114](v_u_10(v113), v112 + v114 * 1.3)
		end
	end
end)