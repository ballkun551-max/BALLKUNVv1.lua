-- Path: Players/ygggggg55551/PlayerScripts/StaffStayClient
-- Class: LocalScript  true/Enum.RunContext.Legacy
-- Decompiled by BALL KUN Universal Map Dump

local v1 = game:GetService("Players")
local v2 = game:GetService("ReplicatedStorage")
local v3 = game:GetService("UserInputService")
local v4 = game:GetService("RunService")
local v_u_5 = require(v2:WaitForChild("NetSeal"))
local v6 = require(v2:WaitForChild("GameShared"))
local v7 = {
	["Owner"] = true,
	["Developer"] = true,
	["Admin"] = true
}
local v8 = v1.LocalPlayer
local v_u_9 = v2:WaitForChild(v6.REMOTES):WaitForChild("StaffStay")
local v_u_10 = os.clock()
local function v11() -- name: touched
	-- upvalues: (ref) v_u_10
	v_u_10 = os.clock()
end
v3.InputBegan:Connect(v11)
v3.InputChanged:Connect(v11)
v3.InputEnded:Connect(v11)
v8.Idled:Connect(function(p12)
	-- upvalues: (ref) v_u_10
	local v13 = v_u_10
	local v14 = os.clock() - p12
	v_u_10 = math.min(v13, v14)
end)
local v15 = v_u_10
while true do
	repeat
		task.wait(10)
		local v16 = not (v4:IsStudio() and workspace:GetAttribute("ZZStayFast")) and 1020 or workspace:GetAttribute("ZZStayFast")
	until v7[v8:GetAttribute("Rank")] and v16 <= os.clock() - v15
	pcall(function()
		-- upvalues: (copy) v_u_5, (copy) v_u_9
		return v_u_5.invoke(v_u_9, "Stay")
	end)
	v_u_10 = os.clock() - v16 + 60
	v15 = v_u_10
end