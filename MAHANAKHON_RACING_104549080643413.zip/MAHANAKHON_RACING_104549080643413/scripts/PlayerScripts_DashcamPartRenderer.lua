-- Path: Players/ygggggg55551/PlayerScripts/DashcamPartRenderer
-- Class: LocalScript  true/Enum.RunContext.Legacy
-- Decompiled by BALL KUN Universal Map Dump

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = require(v1:WaitForChild("DashcamShared"))
v1:WaitForChild(v_u_2.PARTS_FOLDER)
local v_u_3 = {}
local v_u_4 = {}
local function v_u_15(p5) -- name: draw
	-- upvalues: (copy) v_u_2, (copy) v_u_3
	local v6 = p5:GetAttribute(v_u_2.PARTS_ATTR)
	local v7 = (type(v6) ~= "string" or p5:GetAttribute(v_u_2.EDITING)) and "" or v6
	local v8 = v_u_3[p5]
	if v8 and (v8.text == v7 and (v7 == "" or v8.folder and v8.folder.Parent)) then
		return
	else
		local v9 = v_u_3[p5]
		v_u_3[p5] = nil
		if v9 and v9.folder then
			v9.folder:Destroy()
		end
		if v7 == "" then
			v_u_3[p5] = {
				["text"] = ""
			}
		else
			local v10 = Instance.new("Folder")
			v10.Name = v_u_2.VISUALS
			local v11 = v_u_2.build
			local v12 = v_u_2.decode(v7)
			local v13, v14 = pcall(v11, p5, v12, v10)
			if not v13 then
				warn("DashcamPartRenderer:", v14)
			end
			v10.Parent = p5
			v_u_3[p5] = {
				["folder"] = v10,
				["text"] = v7
			}
		end
	end
end
local function v_u_23(p_u_16) -- name: watch
	-- upvalues: (copy) v_u_4, (copy) v_u_2, (copy) v_u_15, (copy) v_u_3
	if not v_u_4[p_u_16] and p_u_16:IsA("Model") then
		v_u_4[p_u_16] = { p_u_16:GetAttributeChangedSignal(v_u_2.PARTS_ATTR):Connect(function()
				-- upvalues: (copy) p_u_16, (ref) v_u_15, (ref) v_u_3
				local v17 = p_u_16
				local v18 = workspace.CurrentCamera
				if v18 then
					v18 = (v17:GetPivot().Position - v18.CFrame.Position).Magnitude
				end
				if v18 and v18 < 360 then
					v_u_15(v17)
				else
					local v19 = v_u_3[v17]
					v_u_3[v17] = nil
					if v19 and v19.folder then
						v19.folder:Destroy()
					end
				end
			end), p_u_16:GetAttributeChangedSignal(v_u_2.EDITING):Connect(function()
				-- upvalues: (copy) p_u_16, (ref) v_u_15, (ref) v_u_3
				local v20 = p_u_16
				local v21 = workspace.CurrentCamera
				if v21 then
					v21 = (v20:GetPivot().Position - v21.CFrame.Position).Magnitude
				end
				if v21 and v21 < 360 then
					v_u_15(v20)
				else
					local v22 = v_u_3[v20]
					v_u_3[v20] = nil
					if v22 and v22.folder then
						v22.folder:Destroy()
					end
				end
			end) }
	end
end
local v_u_24 = {}
local function v_u_31(p25) -- name: follow
	-- upvalues: (copy) v_u_24, (copy) v_u_23, (copy) v_u_3, (copy) v_u_4
	local v26 = v_u_24
	table.insert(v26, p25)
	p25.ChildAdded:Connect(v_u_23)
	p25.ChildRemoved:Connect(function(p27)
		-- upvalues: (ref) v_u_3, (ref) v_u_4
		local v28 = v_u_3[p27]
		v_u_3[p27] = nil
		if v28 and v28.folder then
			v28.folder:Destroy()
		end
		for _, v29 in v_u_4[p27] or {} do
			v29:Disconnect()
		end
		v_u_4[p27] = nil
	end)
	for _, v30 in p25:GetChildren() do
		v_u_23(v30)
	end
end
v_u_31(workspace:WaitForChild("SpawnedVehicles"))
task.spawn(function()
	-- upvalues: (copy) v_u_31
	v_u_31(workspace:WaitForChild("VehicleCargo"))
end)
while true do
	task.wait(0.5)
	for _, v32 in v_u_24 do
		for _, v33 in v32:GetChildren() do
			if not v33:IsA("Model") then
				continue
			end
			local v34 = workspace.CurrentCamera
			if v34 then
				v34 = (v33:GetPivot().Position - v34.CFrame.Position).Magnitude
			end
			if v34 and v34 < 300 then
				v_u_15(v33)
			else
				if not v34 or (v34 <= 360 or not v_u_3[v33]) then
					continue
				end
				local v35 = v_u_3[v33]
				v_u_3[v33] = nil
				if not (v35 and v35.folder) then
					continue
				end
				v35.folder:Destroy()
			end
		end
	end
end