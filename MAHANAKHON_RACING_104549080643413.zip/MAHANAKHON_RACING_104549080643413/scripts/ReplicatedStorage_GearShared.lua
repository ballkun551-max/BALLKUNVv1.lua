-- Path: ReplicatedStorage/GearShared
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_38 = {
	["BOXES"] = {
		["WAVE_STREET"] = 4,
		["WAVE_BARE"] = 4,
		["WAVE_SILVER"] = 4,
		["WAVE_KAGE"] = 4,
		["WAVE_110I"] = 4,
		["WAVE_WHITE"] = 4,
		["WAVE125S"] = 4,
		["DREAM_RACE"] = 4,
		["DREAM_DRAG"] = 4,
		["SPORT_STEP"] = 4,
		["FLAT150"] = 5,
		["CHER74"] = 5,
		["CHER150"] = 5,
		["CHER72"] = 5,
		["TYPER23"] = 6,
		["FK8"] = 6
	},
	["SHARES"] = {
		[4] = {
			0.36,
			0.58,
			0.8,
			1
		},
		[5] = {
			0.3,
			0.48,
			0.65,
			0.83,
			1
		},
		[6] = {
			0.26,
			0.42,
			0.57,
			0.71,
			0.86,
			1
		}
	},
	["NO_TOP_CUT"] = {
		["CHER74"] = true,
		["CHER150"] = true,
		["CHER72"] = true
	},
	["PULL_FIRST"] = 1.3,
	["PULL_TOP"] = 0.9,
	["LUG_BELOW"] = 0.3,
	["LUG_PULL"] = 0.35,
	["OVER_REV"] = 1.3,
	["STOPPED"] = 1,
	["SEND_INTERVAL"] = 0.2,
	["UP_KEYS"] = {
		[Enum.KeyCode.E] = true,
		[Enum.KeyCode.ButtonR1] = true
	},
	["TOO_FAST"] = "Too fast for a lower gear: slow down first",
	["gears"] = function(p1) -- name: gears
		-- upvalues: (copy) v_u_38
		local v2
		if p1 then
			v2 = v_u_38.BOXES[p1:GetAttribute("VehicleId") or p1.Name] or nil
		else
			v2 = nil
		end
		return v2
	end,
	["gear"] = function(p3) -- name: gear
		-- upvalues: (copy) v_u_38
		local v4 = v_u_38.gears(p3)
		if p3 then
			p3 = p3:GetAttribute("Gear")
		end
		if not v4 or typeof(p3) ~= "number" then
			return nil
		end
		local v5 = math.floor(p3)
		return math.clamp(v5, 1, v4)
	end,
	["noTopCut"] = function(p6, p7) -- name: noTopCut
		-- upvalues: (copy) v_u_38
		local v8 = v_u_38.gears(p6)
		local v9
		if v8 == nil or p7 ~= v8 then
			v9 = false
		else
			v9 = v_u_38.NO_TOP_CUT[p6:GetAttribute("VehicleId") or p6.Name] == true
		end
		return v9
	end,
	["share"] = function(p10, p11) -- name: share
		-- upvalues: (copy) v_u_38
		local v12 = v_u_38.SHARES[p10]
		local v13 = #v12
		return v12[math.clamp(p11, 1, v13)]
	end,
	["revs"] = function(p14, p15, p16, p17) -- name: revs
		-- upvalues: (copy) v_u_38
		local v18 = math.max(p14, 0)
		local v19 = p15 * v_u_38.share(p16, p17)
		local v20 = v18 / math.max(v19, 0.001)
		return math.clamp(v20, 0, 1)
	end,
	["pull"] = function(p21, p22, p23, p24) -- name: pull
		-- upvalues: (copy) v_u_38
		local v25 = v_u_38.PULL_FIRST
		local v26 = (v_u_38.PULL_TOP - v_u_38.PULL_FIRST) * (p24 - 1)
		local v27 = p23 - 1
		local v28 = v25 + v26 / math.max(v27, 1)
		local v29 = math.max(p21, 0)
		local v30 = p22 * v_u_38.share(p23, p24)
		local v31 = v29 / math.max(v30, 0.001)
		if p24 > 1 and v31 < v_u_38.LUG_BELOW then
			v28 = v28 * (v_u_38.LUG_PULL + (1 - v_u_38.LUG_PULL) * v31 / v_u_38.LUG_BELOW)
		end
		return v28
	end,
	["shift"] = function(p32, p33, p34, p35, p36) -- name: shift
		-- upvalues: (copy) v_u_38
		local v37 = p33 + p34
		if v37 < 1 or p32 < v37 then
			return nil, nil
		elseif p34 < 0 and math.max(p35, 0) > p36 * v_u_38.share(p32, v37) * v_u_38.OVER_REV then
			return nil, v_u_38.TOO_FAST
		else
			return v37, nil
		end
	end
}
local v_u_39 = nil
function v_u_38.topSpeed(p40, p41) -- name: topSpeed
	-- upvalues: (ref) v_u_39
	v_u_39 = v_u_39 or require(script.Parent:WaitForChild("GameShared"))
	local _, _, v42 = v_u_39.upgradeScales(p40)
	return v_u_39.driveTop(p40, v42, p41)
end
local v_u_43 = nil
function v_u_38.watchPrompts() -- name: watchPrompts
	-- upvalues: (ref) v_u_43
	if not v_u_43 then
		v_u_43 = {}
		local v44 = game:GetService("ProximityPromptService")
		v44.PromptShown:Connect(function(p45)
			-- upvalues: (ref) v_u_43
			v_u_43[p45] = true
		end)
		v44.PromptHidden:Connect(function(p46)
			-- upvalues: (ref) v_u_43
			v_u_43[p46] = nil
		end)
	end
end
function v_u_38.promptOnKey(p47) -- name: promptOnKey
	-- upvalues: (ref) v_u_43
	for v48 in v_u_43 or {} do
		if not v48.Parent or (not v48.Enabled or v48.KeyboardKeyCode ~= p47) then
			continue
		end
		return true
	end
	return false
end
return v_u_38