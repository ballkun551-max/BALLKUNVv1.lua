-- Path: ReplicatedStorage/DashcamView
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v1 = game:GetService("Players")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("UserInputService")
local v_u_5 = game:GetService("ContextActionService")
local v_u_6 = require(v_u_2:WaitForChild("DashcamShared"))
local v_u_7 = require(v_u_2:WaitForChild("UiOwn")).Instance
local v_u_8 = v1.LocalPlayer
local v_u_9 = {}
local v_u_10 = nil
local function v_u_18(p11, p12) -- name: say
	-- upvalues: (copy) v_u_2, (copy) v_u_4
	local v13 = require
	local v14 = v_u_2:WaitForChild("GameUI")
	local v15, v16 = pcall(v13, v14:WaitForChild("Toast"))
	if v15 then
		local v17 = v_u_4.TouchEnabled and not v_u_4.MouseEnabled and "\224\184\165\224\184\178\224\184\129\224\184\153\224\184\180\224\185\137\224\184\167\224\184\148\224\185\137\224\184\178\224\184\153\224\184\130\224\184\167\224\184\178 = \224\184\171\224\184\161\224\184\184\224\184\153 360" or "\224\184\132\224\184\165\224\184\180\224\184\129\224\184\130\224\184\167\224\184\178\224\184\165\224\184\178\224\184\129 = \224\184\171\224\184\161\224\184\184\224\184\153 360 \194\183 \224\184\165\224\185\137\224\184\173\224\185\128\224\184\161\224\184\178\224\184\170\224\185\140 = \224\184\139\224\184\185\224\184\161"
		v16.show(("\224\184\161\224\184\184\224\184\161\224\184\129\224\184\165\224\185\137\224\184\173\224\184\135: %s \194\183 %s \194\183 U = %s"):format(p11, v17, p12 > 1 and "\224\185\128\224\184\165\224\184\183\224\184\173\224\184\129\224\184\129\224\184\165\224\185\137\224\184\173\224\184\135 / \224\184\129\224\184\165\224\184\177\224\184\154" or "\224\184\129\224\184\165\224\184\177\224\184\154"), "info")
	end
end
local function v_u_23(p19) -- name: current
	-- upvalues: (copy) v_u_6
	local v20 = p19.model:GetAttribute(v_u_6.PARTS_ATTR)
	if v20 ~= p19.text then
		p19.text = v20
		p19.list = v_u_6.decode(v20)
		p19.parts = {}
	end
	local v21 = p19.list[p19.index]
	if not v21 then
		return nil
	end
	local v22 = p19.parts[p19.index]
	if not (v22 and v22.Parent) then
		v22 = v_u_6.find(p19.model, v21.k)
		p19.parts[p19.index] = v22
	end
	if not v22 then
		v21 = nil
	end
	return v21, v22
end
local function v_u_29(p24, p25) -- name: hideOwn
	-- upvalues: (copy) v_u_6
	if p25 then
		p25 = p24.model:FindFirstChild(v_u_6.VISUALS)
	end
	local v26
	if p25 then
		v26 = p25:FindFirstChild("C" .. p24.index) or nil
	else
		v26 = nil
	end
	if p24.hidden and p24.hidden ~= v26 then
		for _, v27 in p24.hidden:GetDescendants() do
			if not v27:IsA("BasePart") then
				continue
			end
			v27.LocalTransparencyModifier = 0
		end
	end
	p24.hidden = v26
	if v26 then
		for _, v28 in v26:GetDescendants() do
			if not v28:IsA("BasePart") then
				continue
			end
			v28.LocalTransparencyModifier = 1
		end
	end
end
local function v_u_35(p30, p31) -- name: sharp
	if p31 then
		p30.dof = {}
		for _, v32 in { game:GetService("Lighting"), workspace.CurrentCamera } do
			for _, v33 in v32:GetDescendants() do
				if not (v33:IsA("DepthOfFieldEffect") and v33.Enabled) then
					continue
				end
				p30.dof[v33] = true
				v33.Enabled = false
			end
		end
	else
		for v34 in p30.dof or {} do
			if not v34.Parent then
				continue
			end
			v34.Enabled = true
		end
		p30.dof = nil
	end
end
local function v_u_67(p36) -- name: render
	-- upvalues: (ref) v_u_10, (copy) v_u_8, (copy) v_u_9, (copy) v_u_23, (copy) v_u_6, (copy) v_u_29
	local v37 = v_u_10
	if v37 then
		if v37.model.Parent then
			local v38 = v37.model
			local v39 = v_u_8.Character
			if v39 then
				v39 = v_u_8.Character:FindFirstChildOfClass("Humanoid")
			end
			if v39 then
				v39 = v39.SeatPart
			end
			local v40
			if v39 == nil then
				v40 = false
			else
				v40 = v39:IsDescendantOf(v38)
			end
			if v40 then
				local v41, v42 = v_u_23(v37)
				if v41 then
					local v43 = math.min(p36, 0.1)
					local v44 = v42.CFrame * v_u_6.offset(v41)
					local v45 = v44.LookVector
					local v46 = v45.X
					local v47 = v45.Z
					local v48 = Vector3.new(v46, 0, v47)
					local v49 = -v43 * 5
					local v50 = 1 - math.exp(v49)
					local v51 = v45.Y
					local v52 = math.clamp(v51, -1, 1)
					local v53 = math.asin(v52)
					if v48.Magnitude > 0.001 then
						local v54 = -v48.X
						local v55 = -v48.Z
						local v56 = math.atan2(v54, v55)
						if v37.yaw then
							v56 = v37.yaw + ((v56 - v37.yaw + 3.141592653589793) % 6.283185307179586 - 3.141592653589793) * v50
						end
						v37.yaw = v56
					end
					v37.yaw = v37.yaw or 0
					if v37.pitch0 then
						v53 = v37.pitch0 + (v53 - v37.pitch0) * v50
					end
					v37.pitch0 = v53
					v37.lookYaw = v37.lookYaw - (v37.delta.X + v37.stick.X * 2.792526803190927 * v43)
					local v57 = v37.lookPitch - v37.delta.Y + v37.stick.Y * 2.792526803190927 * v43
					v37.lookPitch = math.clamp(v57, -1.4835298641951802, 1.4835298641951802)
					v37.delta = Vector2.zero
					local v58 = -v43 * 10
					local v59 = 1 - math.exp(v58)
					v37.curYaw = v37.curYaw + (v37.lookYaw - v37.curYaw) * v59
					v37.curPitch = v37.curPitch + (v37.lookPitch - v37.curPitch) * v59
					local v60 = workspace.CurrentCamera
					local v61 = v60.ViewportSize
					local v62 = v_u_6.viewThrough
					local v63 = v61.X
					local v64 = v61.Y
					local v65, v66 = v62(v41, v44, v63 / math.max(v64, 1), v37.yaw, v37.pitch0, v37.curYaw, v37.curPitch, v37.fovAdd)
					v37.curFov = v37.curFov + (v66 - v37.curFov) * v59
					v60.CameraType = Enum.CameraType.Scriptable
					v60.CFrame = v65
					v60.Focus = CFrame.new(v65.Position)
					v60.FieldOfView = v37.curFov
					v_u_29(v37, true)
				else
					v_u_9.stop()
				end
			end
		end
		v_u_9.stop()
	end
end
local function v_u_106(p68, p69) -- name: start
	-- upvalues: (ref) v_u_10, (copy) v_u_4, (copy) v_u_35, (copy) v_u_3, (copy) v_u_67, (copy) v_u_2
	local v_u_70 = workspace.CurrentCamera
	local v_u_71 = {
		["model"] = nil,
		["index"] = nil,
		["saved"] = nil,
		["lookYaw"] = 0,
		["lookPitch"] = 0,
		["curYaw"] = 0,
		["curPitch"] = 0,
		["fovAdd"] = 0,
		["curFov"] = nil,
		["delta"] = nil,
		["stick"] = nil,
		["touches"] = nil,
		["dragging"] = false,
		["conns"] = nil,
		["model"] = p68,
		["index"] = p69 or 1,
		["saved"] = {
			["subject"] = v_u_70.CameraSubject,
			["fov"] = v_u_70.FieldOfView
		},
		["curFov"] = v_u_70.FieldOfView,
		["delta"] = Vector2.zero,
		["stick"] = Vector2.zero,
		["touches"] = {},
		["conns"] = {}
	}
	v_u_10 = v_u_71
	local v72 = v_u_71.conns
	local v73 = v_u_4.InputBegan
	local function v76(p74, p75)
		-- upvalues: (copy) v_u_71, (ref) v_u_4, (copy) v_u_70
		if p75 then
			return
		elseif p74.UserInputType == Enum.UserInputType.MouseButton2 then
			v_u_71.dragging = true
			v_u_4.MouseBehavior = Enum.MouseBehavior.LockCurrentPosition
		elseif p74.UserInputType == Enum.UserInputType.Touch and p74.Position.X > v_u_70.ViewportSize.X * 0.45 then
			v_u_71.touches[p74] = true
		end
	end
	table.insert(v72, v73:Connect(v76))
	local v77 = v_u_71.conns
	local v78 = v_u_4.InputChanged
	local function v90(p79, p80)
		-- upvalues: (copy) v_u_71, (ref) v_u_4
		local v81 = p79.UserInputType
		if v81 == Enum.UserInputType.MouseMovement then
			local v82 = Vector2.new(p79.Position.X, p79.Position.Y)
			local v83 = Vector2.new(p79.Delta.X, p79.Delta.Y)
			if v83.Magnitude < 0.001 and v_u_71.lastAt then
				v83 = v82 - v_u_71.lastAt
			end
			v_u_71.lastAt = v82
			if (v_u_71.dragging or v_u_4.MouseBehavior == Enum.MouseBehavior.LockCenter) and v83.Magnitude < 250 then
				local v84 = v_u_71
				v84.delta = v84.delta + v83 * 0.004363323129985824
				return
			end
		else
			if v81 == Enum.UserInputType.Touch and v_u_71.touches[p79] then
				local v85 = v_u_71
				v85.delta = v85.delta + Vector2.new(p79.Delta.X, p79.Delta.Y) * 0.005235987755982988
				return
			end
			if p79.KeyCode == Enum.KeyCode.Thumbstick2 then
				local v86 = Vector2.new(p79.Position.X, p79.Position.Y)
				local v87 = v_u_71
				if v86.Magnitude <= 0.15 then
					v86 = Vector2.zero
				end
				v87.stick = v86
				return
			end
			if v81 == Enum.UserInputType.MouseWheel and not p80 then
				local v88 = v_u_71
				local v89 = v_u_71.fovAdd - p79.Position.Z * 6
				v88.fovAdd = math.clamp(v89, -60, 40)
			end
		end
	end
	table.insert(v77, v78:Connect(v90))
	local v91 = v_u_71.conns
	local v92 = v_u_4.InputEnded
	local function v94(p93)
		-- upvalues: (copy) v_u_71, (ref) v_u_4
		if p93.UserInputType == Enum.UserInputType.MouseButton2 and v_u_71.dragging then
			v_u_71.dragging = false
			if v_u_4.MouseBehavior == Enum.MouseBehavior.LockCurrentPosition then
				v_u_4.MouseBehavior = Enum.MouseBehavior.Default
			end
		end
		v_u_71.touches[p93] = nil
	end
	table.insert(v91, v92:Connect(v94))
	local v95 = v_u_71.conns
	local v96 = v_u_4.TouchPinch
	table.insert(v95, v96:Connect(function(_, p97, _, p98, p99)
		-- upvalues: (copy) v_u_71
		if not p99 and (p98 == Enum.UserInputState.Change and p97 > 0) then
			local v100 = v_u_71
			local v101 = v_u_71.fovAdd + (1 - math.clamp(p97, 0.97, 1.03)) * 60
			v100.fovAdd = math.clamp(v101, -60, 40)
		end
	end))
	v_u_35(v_u_71, true)
	v_u_3:BindToRenderStep("DashcamView", Enum.RenderPriority.Camera.Value + 2, v_u_67)
	local v102 = require
	local v103 = v_u_2:WaitForChild("GameUI")
	local v104, v105 = pcall(v102, v103:WaitForChild("HudHide"))
	if v104 then
		v105.set("view", true)
	end
end
function v_u_9.active() -- name: active
	-- upvalues: (ref) v_u_10
	return v_u_10 ~= nil
end
function v_u_9.stop() -- name: stop
	-- upvalues: (ref) v_u_10, (copy) v_u_3, (copy) v_u_2, (copy) v_u_8, (copy) v_u_4
	local v107 = v_u_10
	if v107 then
		v_u_10 = nil
		local v108 = v_u_3.UnbindFromRenderStep
		local v109 = v_u_3
		pcall(v108, v109, "DashcamView")
		for _, v110 in v107.conns do
			v110:Disconnect()
		end
		if v107.hidden and v107.hidden ~= nil then
			for _, v111 in v107.hidden:GetDescendants() do
				if not v111:IsA("BasePart") then
					continue
				end
				v111.LocalTransparencyModifier = 0
			end
		end
		v107.hidden = nil
		for v112 in v107.dof or {} do
			if not v112.Parent then
				continue
			end
			v112.Enabled = true
		end
		v107.dof = nil
		local v113 = require
		local v114 = v_u_2:WaitForChild("GameUI")
		local v115, v116 = pcall(v113, v114:WaitForChild("HudHide"))
		if v115 then
			v116.set("view", false)
		end
		local v117 = workspace.CurrentCamera
		local v118 = v107.model
		local v119 = v_u_8.Character
		if v119 then
			v119 = v_u_8.Character:FindFirstChildOfClass("Humanoid")
		end
		local v120
		if v119 then
			v120 = v119.SeatPart
		else
			v120 = v119
		end
		local v121
		if v120 == nil then
			v121 = false
		else
			v121 = v120:IsDescendantOf(v118)
		end
		v117.CameraType = Enum.CameraType.Custom
		if v121 and (v107.saved.subject and v107.saved.subject.Parent) then
			v119 = v107.saved.subject
		end
		v117.CameraSubject = v119
		v117.FieldOfView = v107.saved.fov
		if v107.dragging and v_u_4.MouseBehavior == Enum.MouseBehavior.LockCurrentPosition then
			v_u_4.MouseBehavior = Enum.MouseBehavior.Default
		end
	end
end
local v_u_122 = nil
local v_u_123 = {
	[Enum.KeyCode.Zero] = 0,
	[Enum.KeyCode.One] = 1,
	[Enum.KeyCode.Two] = 2,
	[Enum.KeyCode.Three] = 3,
	[Enum.KeyCode.Four] = 4,
	[Enum.KeyCode.Five] = 5,
	[Enum.KeyCode.Six] = 6,
	[Enum.KeyCode.Seven] = 7,
	[Enum.KeyCode.Eight] = 8,
	[Enum.KeyCode.Nine] = 9
}
local function v_u_133(p124, p125) -- name: nameOf
	-- upvalues: (copy) v_u_6
	local v126 = p124[p125]
	local v127
	if v126 then
		v127 = v_u_6.part(v126.c)
	else
		v127 = v126
	end
	local v128 = v127 and v127.th or (v126 and (v126.c or "?") or "?")
	local v129 = 0
	local v130 = 0
	for v131, v132 in p124 do
		if not v126 or v132.c ~= v126.c then
			continue
		end
		v129 = v129 + 1
		if v131 ~= p125 then
			continue
		end
		v130 = v129
	end
	if v129 > 1 then
		return ("%s #%d"):format(v128, v130)
	else
		return v128
	end
end
local function v_u_141(p134, p135) -- name: whereOn
	-- upvalues: (copy) v_u_6
	local v136 = v_u_6.find(p134, p135.k)
	local v137 = p134:FindFirstChild("DriverSeat", true) or p134:FindFirstChild("VehicleSeat", true)
	if not (v136 and v137) then
		return ""
	end
	local v138 = v_u_6.part(p135.c)
	local v139 = (v136.CFrame * v_u_6.offset(p135)):PointToWorldSpace((v138 and v138.lens or Vector3.new(0, 0, 0)) * p135.s)
	local v140 = v137.CFrame:PointToObjectSpace(v139)
	return (v140.Z < -0.8 and "\224\184\148\224\185\137\224\184\178\224\184\153\224\184\171\224\184\153\224\185\137\224\184\178" or (v140.Z > 0.8 and "\224\184\148\224\185\137\224\184\178\224\184\153\224\184\171\224\184\165\224\184\177\224\184\135" or "\224\184\149\224\184\163\224\184\135\224\184\129\224\184\165\224\184\178\224\184\135")) .. (v140.X > 0.4 and " \194\183 \224\184\130\224\184\167\224\184\178" or (v140.X < -0.4 and " \194\183 \224\184\139\224\185\137\224\184\178\224\184\162" or ""))
end
local function v_u_143() -- name: closePicker
	-- upvalues: (ref) v_u_122, (copy) v_u_5
	local v142 = v_u_122
	if v142 then
		v_u_122 = nil
		v_u_5:UnbindAction("DashcamViewPick")
		v142.gui:Destroy()
	end
end
local function v_u_152(p144, p145) -- name: choose
	-- upvalues: (ref) v_u_122, (copy) v_u_5, (copy) v_u_6, (copy) v_u_9, (ref) v_u_10, (copy) v_u_106, (copy) v_u_18, (copy) v_u_133
	local v146 = v_u_122
	if v146 then
		v_u_122 = nil
		v_u_5:UnbindAction("DashcamViewPick")
		v146.gui:Destroy()
	end
	local v147 = v_u_6.read(p144)
	if p145 == 0 or not v147[p145] then
		v_u_9.stop()
	else
		if v_u_10 and v_u_10.model == p144 then
			if v_u_10.index ~= p145 then
				v_u_10.index = p145
				local v148 = v_u_10
				v_u_10.yaw = nil
				v148.pitch0 = nil
				local v149 = v_u_10
				local v150 = v_u_10
				local v151 = v_u_10
				v_u_10.lookYaw = 0
				v149.lookPitch = 0
				v150.curYaw = 0
				v151.curPitch = 0
				v_u_10.fovAdd = 0
			end
		else
			v_u_9.stop()
			v_u_106(p144, p145)
		end
		v_u_18(v_u_133(v147, p145), #v147)
	end
end
local function v_u_166(p153, p154) -- name: picture
	-- upvalues: (copy) v_u_7, (copy) v_u_6
	local v155 = v_u_7.new("ViewportFrame")
	v155.BackgroundTransparency = 1
	v155.Size = UDim2.fromScale(1, 1)
	v155.Ambient = Color3.fromRGB(190, 190, 200)
	v155.LightDirection = Vector3.new(-0.6, -1, -0.4)
	v155.Parent = p153
	local v156 = v_u_6.makeModel(p154, 1)
	if v156 then
		v156.Parent = v155
		local v157, v158 = v156:GetBoundingBox()
		local v159 = v_u_7.new("Camera")
		v159.FieldOfView = 30
		v159.Parent = v155
		v155.CurrentCamera = v159
		local v160 = (Vector3.new(-0.57357645, 0.35, -0.81915206)).Unit
		local v161 = CFrame.lookAt
		local v162 = v157.Position
		local v163 = v158.X
		local v164 = v158.Y
		local v165 = v158.Z
		v159.CFrame = v161(v162 + v160 * math.max(v163, v164, v165) * 2.4, v157.Position)
	end
end
local function v_u_215(p_u_167, p_u_168) -- name: openPicker
	-- upvalues: (ref) v_u_122, (copy) v_u_5, (copy) v_u_2, (copy) v_u_8, (ref) v_u_10, (copy) v_u_143, (copy) v_u_166, (copy) v_u_141, (copy) v_u_133, (copy) v_u_152, (copy) v_u_6, (copy) v_u_9, (copy) v_u_123
	local v169 = v_u_122
	if v169 then
		v_u_122 = nil
		v_u_5:UnbindAction("DashcamViewPick")
		v169.gui:Destroy()
	end
	local v170 = v_u_2:WaitForChild("GameUI")
	local v_u_171 = require(v170:WaitForChild("Theme"))
	local v172 = require(v170:WaitForChild("Icons"))
	local v173 = v_u_171.screen("DashcamViewPicker", 30, v_u_8:WaitForChild("PlayerGui"))
	local v174 = #p_u_168 + (v_u_10 and 1 or 0)
	local v_u_175 = v_u_171.panel({
		["Name"] = "Picker",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.5),
		["Size"] = UDim2.fromOffset(340, v174 * 62 + 76),
		["Parent"] = v173
	})
	v_u_171.autoScale(v_u_175)
	v_u_171.padding(v_u_175, 12)
	v_u_171.text({
		["Text"] = "\224\185\131\224\184\138\224\185\137\224\184\161\224\184\184\224\184\161\224\184\129\224\184\165\224\185\137\224\184\173\224\184\135\224\184\149\224\184\177\224\184\167\224\185\132\224\184\171\224\184\153?",
		["FontFace"] = nil,
		["TextSize"] = 19,
		["TextXAlignment"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["FontFace"] = v_u_171.FONT_HEAVY,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["Size"] = UDim2.new(1, -40, 0, 24),
		["Parent"] = v_u_175
	})
	v_u_171.text({
		["Text"] = "\224\184\129\224\184\148\224\185\128\224\184\165\224\184\130 \224\184\171\224\184\163\224\184\183\224\184\173\224\185\129\224\184\149\224\184\176\224\185\128\224\184\165\224\184\183\224\184\173\224\184\129 \194\183 U = \224\184\155\224\184\180\224\184\148",
		["TextSize"] = 12,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["TextColor3"] = v_u_171.TEXT_DIM,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["Position"] = UDim2.fromOffset(0, 24),
		["Size"] = UDim2.new(1, -40, 0, 16),
		["Parent"] = v_u_175
	})
	local v176 = v_u_171.new("TextButton", {
		["Name"] = "Close",
		["Text"] = "",
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Modal"] = true,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(1, 0),
		["Position"] = UDim2.new(1, 4, 0, -2),
		["Size"] = UDim2.fromOffset(36, 36),
		["Parent"] = v_u_175
	})
	local v177 = v172.make("close", v_u_171.TEXT_DIM, 24)
	v177.AnchorPoint = Vector2.new(0.5, 0.5)
	v177.Position = UDim2.fromScale(0.5, 0.5)
	v177.Parent = v176
	v176.Activated:Connect(v_u_143)
	local function v196(p178, p179, p180, p181, p182, p183, p184) -- name: row
		-- upvalues: (copy) v_u_171, (copy) v_u_175, (ref) v_u_166
		local v185 = v_u_171.new
		local v186 = "TextButton"
		local v187 = {
			["Name"] = nil,
			["Text"] = "",
			["AutoButtonColor"] = true,
			["Modal"] = true,
			["BorderSizePixel"] = 0,
			["BackgroundColor3"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["Name"] = "Pick" .. p179
		}
		local v188
		if p182 then
			v188 = Color3.fromRGB(70, 60, 30)
		else
			v188 = v_u_171.CARD_DARK
		end
		v187.BackgroundColor3 = v188
		v187.Position = UDim2.fromOffset(0, p178)
		v187.Size = UDim2.new(1, 0, 0, 56)
		v187.Parent = v_u_175
		local v189 = v185(v186, v187)
		v_u_171.corner(v189, 10)
		v_u_171.new("UIStroke", {
			["Color"] = nil,
			["Thickness"] = 2,
			["Enabled"] = nil,
			["ApplyStrokeMode"] = nil,
			["Parent"] = nil,
			["Color"] = v_u_171.YELLOW,
			["Enabled"] = p182,
			["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
			["Parent"] = v189
		})
		local v190 = v_u_171.text({
			["Text"] = nil,
			["TextSize"] = 14,
			["FontFace"] = nil,
			["TextColor3"] = nil,
			["BackgroundTransparency"] = 0,
			["BackgroundColor3"] = nil,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["Text"] = tostring(p179),
			["FontFace"] = v_u_171.FONT_BOLD,
			["TextColor3"] = v_u_171.DARK_TEXT,
			["BackgroundColor3"] = v_u_171.YELLOW,
			["AnchorPoint"] = Vector2.new(0, 0.5),
			["Position"] = UDim2.new(0, 10, 0.5, 0),
			["Size"] = UDim2.fromOffset(24, 24),
			["Parent"] = v189
		})
		v_u_171.corner(v190, 6)
		local v191
		if p183 then
			local v192 = v_u_171.new("Frame", {
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["ClipsDescendants"] = true,
				["Parent"] = nil,
				["BackgroundColor3"] = Color3.fromRGB(28, 30, 40),
				["AnchorPoint"] = Vector2.new(0, 0.5),
				["Position"] = UDim2.new(0, 42, 0.5, 0),
				["Size"] = UDim2.fromOffset(46, 46),
				["Parent"] = v189
			})
			v_u_171.corner(v192, 8)
			v_u_166(v192, p183)
			v191 = 98
		else
			v191 = 44
		end
		v_u_171.text({
			["Text"] = nil,
			["TextSize"] = 15,
			["FontFace"] = nil,
			["TextXAlignment"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["Text"] = p180,
			["FontFace"] = v_u_171.FONT_BOLD,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["Position"] = UDim2.fromOffset(v191, 8),
			["Size"] = UDim2.new(1, -v191 - 8, 0, 20),
			["Parent"] = v189
		})
		local v193 = v_u_171.text
		local v194 = {
			["Text"] = nil,
			["TextSize"] = 12,
			["TextColor3"] = nil,
			["TextXAlignment"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["Text"] = p181
		}
		local v195
		if p182 then
			v195 = v_u_171.YELLOW
		else
			v195 = v_u_171.TEXT_DIM
		end
		v194.TextColor3 = v195
		v194.TextXAlignment = Enum.TextXAlignment.Left
		v194.Position = UDim2.fromOffset(v191, 29)
		v194.Size = UDim2.new(1, -v191 - 8, 0, 18)
		v194.Parent = v189
		v193(v194)
		v189.Activated:Connect(p184)
	end
	for v_u_197, v198 in p_u_168 do
		local v199
		if v_u_10 == nil or v_u_10.model ~= p_u_167 then
			v199 = false
		else
			v199 = v_u_10.index == v_u_197
		end
		local v200 = v_u_141(p_u_167, v198)
		local v201 = 50 + (v_u_197 - 1) * 62
		local v202 = v_u_133(p_u_168, v_u_197)
		if v199 then
			v200 = "\224\184\129\224\184\179\224\184\165\224\184\177\224\184\135\224\184\148\224\184\185\224\184\173\224\184\162\224\184\185\224\185\136 \194\183 " .. v200
		end
		v196(v201, v_u_197, v202, v200, v199, v198.c, function()
			-- upvalues: (ref) v_u_152, (copy) p_u_167, (copy) v_u_197
			v_u_152(p_u_167, v_u_197)
		end)
	end
	if v_u_10 then
		v196(#p_u_168 * 62 + 50, 0, "\224\184\161\224\184\184\224\184\161\224\184\155\224\184\129\224\184\149\224\184\180", "\224\184\173\224\184\173\224\184\129\224\184\136\224\184\178\224\184\129\224\184\161\224\184\184\224\184\161\224\184\129\224\184\165\224\185\137\224\184\173\224\184\135", false, nil, function()
			-- upvalues: (copy) p_u_167, (ref) v_u_122, (ref) v_u_5, (ref) v_u_6, (ref) v_u_9
			local v203 = p_u_167
			local v204 = v_u_122
			if v204 then
				v_u_122 = nil
				v_u_5:UnbindAction("DashcamViewPick")
				v204.gui:Destroy()
			end
			v_u_6.read(v203)
			v_u_9.stop()
		end)
	end
	local v205 = {}
	for v206 in v_u_123 do
		table.insert(v205, v206)
	end
	v_u_5:BindActionAtPriority("DashcamViewPick", function(_, p207, p208)
		-- upvalues: (ref) v_u_123, (copy) p_u_168, (ref) v_u_10, (ref) v_u_152, (copy) p_u_167
		if p207 ~= Enum.UserInputState.Begin then
			return Enum.ContextActionResult.Sink
		end
		local v209 = v_u_123[p208.KeyCode]
		if v209 and (v209 >= 1 and v209 <= #p_u_168 or v209 == 0 and v_u_10) then
			v_u_152(p_u_167, v209)
		end
		return Enum.ContextActionResult.Sink
	end, false, Enum.ContextActionPriority.High.Value + 60, table.unpack(v205))
	v_u_122 = {
		["gui"] = v173,
		["model"] = p_u_167
	}
	local v_u_210 = v_u_122
	task.spawn(function()
		-- upvalues: (ref) v_u_122, (copy) v_u_210, (copy) p_u_167, (ref) v_u_8, (ref) v_u_5
		while v_u_122 == v_u_210 do
			task.wait(0.3)
			if v_u_122 ~= v_u_210 then
				continue
			end
			if p_u_167.Parent then
				local v211 = p_u_167
				local v212 = v_u_8.Character
				if v212 then
					v212 = v_u_8.Character:FindFirstChildOfClass("Humanoid")
				end
				if v212 then
					v212 = v212.SeatPart
				end
				local v213
				if v212 == nil then
					v213 = false
				else
					v213 = v212:IsDescendantOf(v211)
				end
				if v213 then
					continue
				end
			end
			local v214 = v_u_122
			if not v214 then
				continue
			end
			v_u_122 = nil
			v_u_5:UnbindAction("DashcamViewPick")
			v214.gui:Destroy()
		end
	end)
end
function v_u_9.toggle(p216) -- name: toggle
	-- upvalues: (ref) v_u_122, (copy) v_u_5, (ref) v_u_10, (copy) v_u_9, (copy) v_u_6, (copy) v_u_106, (copy) v_u_18, (copy) v_u_133, (copy) v_u_215
	if v_u_122 then
		local v217 = v_u_122
		if v217 then
			v_u_122 = nil
			v_u_5:UnbindAction("DashcamViewPick")
			v217.gui:Destroy()
		end
		return true
	else
		if v_u_10 and v_u_10.model ~= p216 then
			v_u_9.stop()
		end
		local v218 = not p216 and {} or v_u_6.read(p216)
		if #v218 == 0 then
			if not v_u_10 then
				return false
			end
			v_u_9.stop()
			return true
		elseif #v218 == 1 then
			if v_u_10 then
				v_u_9.stop()
			else
				v_u_106(p216, 1)
				v_u_18(v_u_133(v218, 1), 1)
			end
			return true
		else
			v_u_215(p216, v218)
			return true
		end
	end
end
return v_u_9