-- Path: Players/ygggggg55551/PlayerScripts/GroupRewardClient
-- Class: LocalScript  true/Enum.RunContext.Legacy
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = require(game:GetService("ReplicatedStorage"):WaitForChild("NetSeal"))
local v_u_2 = game:GetService("AvatarEditorService")
local v_u_3 = game:GetService("GroupService")
local v4 = game:GetService("Players")
local v5 = game:GetService("ReplicatedStorage")
local v_u_6 = require(v5:WaitForChild("GameShared"))
local v_u_7 = require(v5:WaitForChild("GroupRewardShared"))
local v8 = v5:WaitForChild("GameUI")
local v_u_9 = require(v8:WaitForChild("Theme"))
local v_u_10 = require(v8:WaitForChild("Toast"))
local v11 = v4.LocalPlayer
local v12 = v5:WaitForChild(v_u_6.REMOTES)
local v_u_13 = v12:WaitForChild(v_u_7.REMOTE)
local v14 = v12:WaitForChild(v_u_7.EVENT)
local v15 = v_u_9.screen("GroupReward", 22, v11:WaitForChild("PlayerGui"))
local v_u_16 = v_u_9.window({
	["name"] = "GroupRewardWindow",
	["gui"] = nil,
	["icon"] = "people",
	["grad"] = "gold",
	["title"] = "Group reward",
	["sub"] = nil,
	["size"] = nil,
	["touchSize"] = nil,
	["max"] = nil,
	["gui"] = v15,
	["sub"] = ("Join the group, get \224\184\191%s"):format(v_u_6.formatNumber(v_u_7.REWARD)),
	["size"] = Vector2.new(0.42, 0.62),
	["touchSize"] = Vector2.new(0.8, 0.9),
	["max"] = Vector2.new(560, 520)
})
local v_u_17 = v_u_9.new("Frame", {
	["BackgroundTransparency"] = 1,
	["Size"] = nil,
	["Parent"] = nil,
	["Size"] = UDim2.fromScale(1, 1),
	["Parent"] = v_u_16.body
})
v_u_9.new("UIListLayout", {
	["Padding"] = UDim.new(0, 10),
	["SortOrder"] = Enum.SortOrder.LayoutOrder,
	["Parent"] = v_u_17
})
local function v20(p18) -- name: card
	-- upvalues: (copy) v_u_9, (copy) v_u_17
	local v19 = v_u_9.new("Frame", {
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_9.CARD,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y,
		["LayoutOrder"] = p18,
		["Parent"] = v_u_17
	})
	v_u_9.corner(v19, 14)
	v_u_9.border(v19, Color3.new(1, 1, 1), 0.88, 1)
	v_u_9.padding(v19, 14, 12)
	v_u_9.new("UIListLayout", {
		["Padding"] = UDim.new(0, 8),
		["SortOrder"] = Enum.SortOrder.LayoutOrder,
		["Parent"] = v19
	})
	return v19
end
local function v26(p21, p22, p23, p24, p25) -- name: text
	-- upvalues: (copy) v_u_9
	return v_u_9.text({
		["Text"] = nil,
		["TextSize"] = nil,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["TextWrapped"] = true,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = nil,
		["Parent"] = nil,
		["Text"] = p22,
		["TextSize"] = p23,
		["TextColor3"] = p24 or v_u_9.TEXT,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y,
		["LayoutOrder"] = p25,
		["Parent"] = p21
	})
end
local v27 = v20(1)
v26(v27, "1.  Join the group", 18, v_u_9.TEXT, 1).FontFace = v_u_9.FONT_HEAVY
local v_u_28 = v26(v27, "", 15, v_u_9.TEXT_DIM, 2)
local v_u_29 = v_u_9.button({
	["text"] = "Join group",
	["grad"] = "blue",
	["icon"] = "people",
	["textSize"] = 16,
	["size"] = nil,
	["parent"] = nil,
	["size"] = UDim2.new(1, 0, 0, 44),
	["parent"] = v27
})
v_u_29.LayoutOrder = 3
local v30 = v20(2)
v26(v30, ("2.  Claim \224\184\191%s"):format(v_u_6.formatNumber(v_u_7.REWARD)), 18, v_u_9.TEXT, 1).FontFace = v_u_9.FONT_HEAVY
local v_u_31 = v_u_9.button({
	["text"] = "Claim",
	["grad"] = "gold",
	["icon"] = "coin",
	["textSize"] = 17,
	["size"] = nil,
	["parent"] = nil,
	["size"] = UDim2.new(1, 0, 0, 48),
	["parent"] = v30
})
v_u_31.LayoutOrder = 2
local v32 = v20(3)
v26(v32, "Like + Favorite the map \240\159\153\143", 18, v_u_9.TEXT, 1).FontFace = v_u_9.FONT_HEAVY
v26(v32, "Tap \240\159\145\141 on the game\'s page and \226\173\144 favorite it - it helps the map grow!", 15, v_u_9.TEXT_DIM, 2)
local v33 = v_u_9.button({
	["text"] = "Favorite \226\173\144",
	["grad"] = "purple",
	["textSize"] = 16,
	["size"] = nil,
	["parent"] = nil,
	["size"] = UDim2.new(1, 0, 0, 44),
	["parent"] = v32
})
v33.LayoutOrder = 3
local v_u_34 = nil
local function v_u_40() -- name: refresh
	-- upvalues: (copy) v_u_1, (copy) v_u_13, (ref) v_u_34, (copy) v_u_28, (copy) v_u_9, (copy) v_u_29, (copy) v_u_31, (copy) v_u_6, (copy) v_u_7
	local v35 = v_u_1.invoke
	local v36 = v_u_13
	local v37, v38, v39 = pcall(v35, v36, "Status")
	if v37 and (v38 and type(v39) == "table") then
		v_u_34 = v39
		if v_u_34.inGroup then
			v_u_28.Text = "\226\156\147  You\'re in the group"
			v_u_28.TextColor3 = v_u_9.GREEN_TEXT
			v_u_29.Visible = false
		else
			v_u_28.Text = "Join MAHANAKHON RACING\'s group on Roblox, then come back here."
			v_u_28.TextColor3 = v_u_9.TEXT_DIM
			v_u_29.Visible = true
		end
		if v_u_34.claimed then
			v_u_9.setButton(v_u_31, "grey", "Claimed \226\156\147", Color3.new(1, 1, 1))
			return
		elseif v_u_34.inGroup then
			v_u_9.setButton(v_u_31, "gold", ("Claim \224\184\191%s"):format(v_u_6.formatNumber(v_u_7.REWARD)), v_u_9.DARK_TEXT)
		else
			v_u_9.setButton(v_u_31, "dark", "Join the group first", v_u_9.TEXT_DIM)
		end
	else
		return
	end
end
v_u_29.Activated:Connect(function()
	-- upvalues: (copy) v_u_3, (copy) v_u_7, (copy) v_u_10, (copy) v_u_40
	local v41 = v_u_3.PromptJoinAsync
	local v42 = v_u_3
	local v43 = v_u_7.GROUP_ID
	if not pcall(v41, v42, v43) then
		v_u_10.show("Open the group from the game\'s page: Community", "info")
	end
	v_u_40()
end)
local v_u_44 = false
v_u_31.Activated:Connect(function()
	-- upvalues: (ref) v_u_44, (ref) v_u_34, (copy) v_u_1, (copy) v_u_13, (copy) v_u_10, (copy) v_u_40
	if not (v_u_44 or v_u_34 and v_u_34.claimed) then
		v_u_44 = true
		local v45 = v_u_1.invoke
		local v46 = v_u_13
		local v47, v48, v49 = pcall(v45, v46, "Claim")
		v_u_44 = false
		if v47 and v49 then
			v_u_10.show(v49, v48 and "ok" or "error")
		end
		v_u_40()
	end
end)
v33.Activated:Connect(function()
	-- upvalues: (copy) v_u_2, (copy) v_u_10
	local v50 = v_u_2.PromptSetFavorite
	local v51 = v_u_2
	local v52 = game.PlaceId
	local v53 = Enum.AvatarItemType.Asset
	if not pcall(v50, v51, v52, v53, true) then
		v_u_10.show("Tap \226\173\144 on the game\'s page to favorite it", "info")
	end
end)
v14.OnClientEvent:Connect(function()
	-- upvalues: (copy) v_u_16, (copy) v_u_40
	v_u_16.setOpen(true)
	task.spawn(v_u_40)
end)