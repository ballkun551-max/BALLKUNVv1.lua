-- Path: Players/ygggggg55551/PlayerScripts/PCX160Client
-- Class: LocalScript  true/Enum.RunContext.Legacy
-- Decompiled by BALL KUN Universal Map Dump

local v1 = game:GetService("CollectionService")
local v2 = game:GetService("Players")
local v3 = game:GetService("ReplicatedStorage")
local v4 = game:GetService("RunService")
local v_u_5 = require(v3:WaitForChild("PCX160Shared"))
local v_u_6 = require(script:WaitForChild("Visuals"))
local v_u_7 = require(script:WaitForChild("Sound"))
local v_u_8 = require(script:WaitForChild("Driver"))
local v9 = require(script:WaitForChild("Mount"))
local v_u_10 = require(script:WaitForChild("Rider"))
local v11 = v2.LocalPlayer
local v_u_12 = {}
local v13 = game:GetService("Lighting")
if not v13:FindFirstChildWhichIsA("BloomEffect") then
	local v14 = Instance.new("BloomEffect")
	v14.Name = "PCX160Bloom"
	v14.Intensity = 0.9
	v14.Size = 18
	v14.Threshold = 1.3
	v14.Parent = v13
end
v9.start()
local function v18(p_u_15) -- name: addBike
	-- upvalues: (copy) v_u_12, (copy) v_u_6, (copy) v_u_7, (copy) v_u_10
	if v_u_12[p_u_15] or not p_u_15:IsA("Model") then
		return
	else
		local v16 = v_u_6.new(p_u_15)
		if v16 then
			if p_u_15:IsDescendantOf(workspace) then
				local v_u_17 = {
					["visuals"] = v16,
					["sound"] = v_u_7.new(p_u_15),
					["rider"] = v_u_10.new(p_u_15)
				}
				v_u_12[p_u_15] = v_u_17
				v_u_17.voiceConn = p_u_15:GetAttributeChangedSignal("VoiceApplied"):Connect(function()
					-- upvalues: (ref) v_u_12, (copy) p_u_15, (copy) v_u_17, (ref) v_u_7
					if v_u_12[p_u_15] == v_u_17 then
						v_u_17.sound:destroy()
						v_u_17.sound = v_u_7.new(p_u_15)
					end
				end)
			else
				v16:destroy()
			end
		else
			return
		end
	end
end
local function v21(p19) -- name: removeBike
	-- upvalues: (copy) v_u_12, (copy) v_u_8
	local v20 = v_u_12[p19]
	if v20 then
		v20.visuals:destroy()
		v20.sound:destroy()
		if v20.voiceConn then
			v20.voiceConn:Disconnect()
		end
		if v20.rider then
			v20.rider:destroy()
		end
		v_u_12[p19] = nil
	end
	if v_u_8.model() == p19 then
		v_u_8.stop()
	end
end
for _, v22 in v1:GetTagged(v_u_5.TAG) do
	task.spawn(v18, v22)
end
v1:GetInstanceAddedSignal(v_u_5.TAG):Connect(v18)
v1:GetInstanceRemovedSignal(v_u_5.TAG):Connect(v21)
v4.Stepped:Connect(function(_, p23)
	-- upvalues: (copy) v_u_12, (copy) v_u_8
	local v24 = workspace.CurrentCamera
	if v24 then
		v24 = v24.CFrame.Position
	end
	for v25, v26 in v_u_12 do
		local v27
		if v_u_8.model() == v25 then
			v27 = nil
		else
			local v28 = v26.visuals
			local v29 = v28.chassis
			if v29 and v24 then
				if (v29.Position - v24).Magnitude >= 120 then
					v27 = 10
				elseif v28.seat and v28.seat.Occupant ~= nil then
					v27 = nil
				else
					v27 = v29.AssemblyLinearVelocity.Magnitude <= 1 and 20 or nil
				end
			else
				v27 = nil
			end
		end
		v26.hz = v27
		v26.jointDt = (v26.jointDt or 0) + p23
		if v27 == nil or v26.jointDt >= 1 / v27 then
			v26.visuals:stepJoints(v26.jointDt)
			v26.jointDt = 0
		end
		if not v26.rider then
			continue
		end
		v26.rider:step(p23)
	end
end)
v4.Heartbeat:Connect(function(p30)
	-- upvalues: (copy) v_u_12
	for _, v31 in v_u_12 do
		v31.updateDt = (v31.updateDt or 0) + p30
		local v32 = v31.hz
		if v32 ~= nil and v31.updateDt < 1 / v32 then
			continue
		end
		v31.visuals:update(v31.updateDt)
		v31.sound:update(v31.updateDt)
		v31.updateDt = 0
	end
end)
local function v_u_35(p33) -- name: rpmOf
	-- upvalues: (copy) v_u_12
	local v34 = v_u_12[p33]
	return v34 and v34.sound.rpm or 0
end
local v_u_36 = nil
local function v42(p37) -- name: onCharacter
	-- upvalues: (ref) v_u_36, (copy) v_u_5, (copy) v_u_8, (copy) v_u_35
	local v_u_38 = p37:WaitForChild("Humanoid")
	if v_u_36 then
		v_u_36:Disconnect()
	end
	local function v40() -- name: onSeat
		-- upvalues: (ref) v_u_5, (copy) v_u_38, (ref) v_u_8, (ref) v_u_35
		local v39 = v_u_5.bikeFromSeat(v_u_38.SeatPart)
		if v39 then
			v_u_8.start(v39, v_u_38, v_u_35)
		else
			v_u_8.stop()
		end
	end
	v_u_36 = v_u_38:GetPropertyChangedSignal("SeatPart"):Connect(v40)
	local v41 = v_u_5.bikeFromSeat(v_u_38.SeatPart)
	if v41 then
		v_u_8.start(v41, v_u_38, v_u_35)
	else
		v_u_8.stop()
	end
end
if v11.Character then
	task.spawn(v42, v11.Character)
end
v11.CharacterAdded:Connect(v42)
v11.CharacterRemoving:Connect(function()
	-- upvalues: (copy) v_u_8
	v_u_8.stop()
end)