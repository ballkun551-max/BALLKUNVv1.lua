-- Path: Players/ygggggg55551/PlayerScripts/DynoScreensClient
-- Class: LocalScript  true/Enum.RunContext.Legacy
-- Decompiled by BALL KUN Universal Map Dump

local v1 = game:GetService("Players")
local v2 = game:GetService("ReplicatedStorage")
local v3 = game:GetService("RunService")
local v4 = game:GetService("CollectionService")
local v_u_5 = game:GetService("HttpService")
local v_u_6 = require(v2:WaitForChild("DynoScreenKit"))
local v_u_7 = require(v2:WaitForChild("GameShared"))
local v_u_8 = require(v2:WaitForChild("LiveRpm"))
local v_u_9 = require(v2:WaitForChild("GameUI"):WaitForChild("Toast"))
local v_u_10 = require(v2:WaitForChild("UiOwn"))
local v_u_11 = v1.LocalPlayer
local v_u_12 = v_u_11:WaitForChild("PlayerGui")
local v_u_13 = v_u_6.C
local function v_u_22(p14, p15) -- name: hpAt
	-- upvalues: (copy) v_u_7
	local v16 = v_u_7.upgradeScales(p14)
	local v17 = (p14:GetAttribute("MaxSpeed") or 100) * 0.12 * v16
	local v18 = p15 / 9000
	local v19 = math.clamp(v18, 0, 1) / 0.86
	local v20
	if v19 <= 1 then
		v20 = v19 ^ 1.5 * (2.5 - v19 * 1.5)
	else
		v20 = 1 - (v19 - 1) * 0.86 * 2.2
	end
	local v21 = v17 * v20
	return math.max(0, v21)
end
local function v_u_28(p23, p24) -- name: downsample
	if #p23 <= p24 then
		return p23
	end
	local v25 = {}
	for v26 = 1, p24 do
		local v27 = 1 + (v26 - 1) * (#p23 - 1) / (p24 - 1) + 0.5
		v25[v26] = p23[math.floor(v27)]
	end
	return v25
end
local v_u_29 = {}
local function v_u_30() -- name: newState
	return {
		["runs"] = nil,
		["runCount"] = 0,
		["sel"] = nil,
		["cursor"] = nil,
		["hold"] = false,
		["auto"] = true,
		["hand"] = false,
		["armed"] = false,
		["rec"] = nil,
		["showHp"] = true,
		["showTq"] = true,
		["ch"] = nil,
		["hist"] = nil,
		["ect"] = 33.2,
		["oil"] = 33.2,
		["egt"] = 33.2,
		["startRpm"] = 2000,
		["stopRpm"] = 9000,
		["mode"] = "DYNO",
		["lastRpm"] = 0,
		["ramp"] = 0,
		["zeroLoad"] = 0,
		["filesDirty"] = true,
		["toldLock"] = nil,
		["runs"] = {},
		["ch"] = {
			["rpm"] = true,
			["thr"] = true,
			["afr"] = true
		},
		["hist"] = {}
	}
end
local function v_u_45(p31, _) -- name: finishRun
	-- upvalues: (copy) v_u_28, (copy) v_u_9
	local v32 = p31.rec
	p31.rec = nil
	if v32 then
		local v33 = v32.pts
		if #v33 >= 6 and v33[#v33].rpm - v33[1].rpm >= 2500 then
			local v34 = {
				["pts"] = nil,
				["vehicle"] = nil,
				["peakHp"] = 0,
				["peakHpRpm"] = 0,
				["peakTq"] = 0,
				["peakTqRpm"] = 0,
				["pts"] = v_u_28(v33, 60),
				["vehicle"] = v32.vehicle
			}
			for _, v35 in v33 do
				if v35.hp > v34.peakHp then
					local v36 = v35.hp
					local v37 = v35.rpm
					v34.peakHp = v36
					v34.peakHpRpm = v37
				end
				if v35.tq <= v34.peakTq then
					continue
				end
				local v38 = v35.tq
				local v39 = v35.rpm
				v34.peakTq = v38
				v34.peakTqRpm = v39
			end
			p31.runCount = p31.runCount + 1
			v34.n = p31.runCount
			local v40 = p31.runs
			table.insert(v40, v34)
			if #p31.runs > 5 then
				table.remove(p31.runs, 1)
			end
			p31.sel = v34
			p31.armed = false
			p31.filesDirty = true
			local v41 = v_u_9.show
			local v42 = v34.n
			local v43 = v34.peakHp
			local v44 = v34.peakHpRpm / 50
			v41(("Run %d: %.1f hp @ %d rpm \194\183 %.1f lb-ft"):format(v42, v43, math.floor(v44) * 50, v34.peakTq), "info")
		end
	else
		return
	end
end
local function v_u_51(p46) -- name: setupLeft
	-- upvalues: (copy) v_u_13, (copy) v_u_6
	local v47 = p46.Root
	local v48 = {
		["gui"] = p46,
		["r"] = v47,
		["charts"] = {}
	}
	for _, v49 in {
		{ "Hp", v_u_13.green },
		{ "Tq", v_u_13.red },
		{ "Speed", v_u_13.yellow }
	} do
		local v50 = v47[v49[1] .. "Chart"]
		v48.charts[v49[1]] = {
			["box"] = v50,
			["pool"] = v_u_6.pool(v50, "Line", 59, v49[2], 2.5, 4),
			["value"] = v47[v49[1] .. "ChartValue"]
		}
	end
	return v48
end
local function v_u_57(p52) -- name: setupRight
	-- upvalues: (copy) v_u_6, (copy) v_u_13
	local v53 = p52.Root
	local v54 = {
		["gui"] = p52,
		["r"] = v53,
		["lines"] = {},
		["files"] = {}
	}
	v54.lines.rpm = v_u_6.pool(v53.Plot, "LineRpm", 59, v_u_13.green, 2.5, 4)
	v54.lines.thr = v_u_6.pool(v53.Plot, "LineThr", 59, Color3.fromRGB(60, 200, 235), 2, 4)
	v54.lines.afr = v_u_6.pool(v53.Plot, "LineAfr", 59, v_u_13.red, 2, 4)
	local v55 = v53.RunFiles.Area
	for v56 = 1, 5 do
		v54.files[v56] = {
			["hp"] = v_u_6.pool(v55, "Hp" .. v56, 59, v_u_6.RUN_COLORS[v56], 2.5, 5),
			["tq"] = v_u_6.pool(v55, "Tq" .. v56, 59, v_u_6.RUN_COLORS[v56], 1.5, 5)
		}
	end
	v54.recHp = v_u_6.pool(v55, "RecHp", 79, v_u_13.red, 3, 6)
	v54.recTq = v_u_6.pool(v55, "RecTq", 79, Color3.fromRGB(255, 140, 120), 2, 6)
	return v54
end
local function v_u_87(p58, p59, p60) -- name: wire
	local v_u_61 = p58.st
	local v_u_62 = p60.Root
	local function v66(p63, p_u_64) -- name: on
		-- upvalues: (copy) v_u_62, (copy) v_u_61
		local v_u_65 = v_u_62:FindFirstChild(p63, true)
		if v_u_65 and v_u_65:IsA("GuiButton") then
			v_u_65.Activated:Connect(function()
				-- upvalues: (copy) p_u_64, (copy) v_u_65, (ref) v_u_61
				p_u_64(v_u_65)
				v_u_61.filesDirty = true
			end)
		end
	end
	if p59 == "Left" then
		v66("ModeDyno", function()
			-- upvalues: (copy) v_u_61
			v_u_61.mode = "DYNO"
		end)
		v66("ModeRoad", function()
			-- upvalues: (copy) v_u_61
			v_u_61.mode = "ROAD"
		end)
		v66("ModeHold", function()
			-- upvalues: (copy) v_u_61
			v_u_61.hold = not v_u_61.hold
		end)
		v66("ModeSet", function()
			-- upvalues: (copy) v_u_61
			v_u_61.zeroLoad = (v_u_61.last and v_u_61.last.load or 0) + v_u_61.zeroLoad
		end)
		v66("AutoStart", function()
			-- upvalues: (copy) v_u_61
			v_u_61.auto = not v_u_61.auto
			v_u_61.hand = false
		end)
		v66("StopUp", function()
			-- upvalues: (copy) v_u_61
			local v67 = v_u_61
			local v68 = v_u_61.stopRpm + 500
			v67.stopRpm = math.min(9000, v68)
		end)
		v66("StopDown", function()
			-- upvalues: (copy) v_u_61
			local v69 = v_u_61
			local v70 = v_u_61.stopRpm - 500
			v69.stopRpm = math.max(5000, v70)
		end)
		for v_u_71 = 1, 4 do
			v66("HexKey" .. v_u_71, function()
				-- upvalues: (copy) v_u_61, (copy) v_u_71
				v_u_61.flash = {
					["key"] = v_u_71,
					["t"] = os.clock()
				}
			end)
		end
	else
		v66("Run", function()
			-- upvalues: (copy) v_u_61
			v_u_61.armed = true
		end)
		v66("Stop", function()
			-- upvalues: (copy) v_u_61
			v_u_61.armed = false
			v_u_61.rec = nil
		end)
		v66("Hold", function()
			-- upvalues: (copy) v_u_61
			v_u_61.hold = not v_u_61.hold
		end)
		v66("Home", function()
			-- upvalues: (copy) v_u_61
			v_u_61.cursor = nil
			v_u_61.hist = {}
		end)
		v66("SetZero", function()
			-- upvalues: (copy) v_u_61
			v_u_61.zeroLoad = (v_u_61.last and v_u_61.last.load or 0) + v_u_61.zeroLoad
		end)
		v66("Hand", function()
			-- upvalues: (copy) v_u_61
			v_u_61.hand = not v_u_61.hand
			if v_u_61.hand then
				v_u_61.auto = false
			end
		end)
		v66("ShowHp", function()
			-- upvalues: (copy) v_u_61
			v_u_61.showHp = not v_u_61.showHp
			if not (v_u_61.showHp or v_u_61.showTq) then
				v_u_61.showTq = true
			end
		end)
		v66("ShowTq", function()
			-- upvalues: (copy) v_u_61
			v_u_61.showTq = not v_u_61.showTq
			if not (v_u_61.showHp or v_u_61.showTq) then
				v_u_61.showHp = true
			end
		end)
		v66("AutoRun", function()
			-- upvalues: (copy) v_u_61
			v_u_61.auto = not v_u_61.auto
			if v_u_61.auto then
				v_u_61.hand = false
			end
		end)
		v66("New", function()
			-- upvalues: (copy) v_u_61
			local v72 = v_u_61
			local v73 = v_u_61
			local v74 = v_u_61
			v_u_61.runs = {}
			v72.sel = nil
			v73.runCount = 0
			v74.cursor = nil
		end)
		v66("RunPlus", function()
			-- upvalues: (copy) v_u_61
			if #v_u_61.runs > 0 then
				local v75 = table.find(v_u_61.runs, v_u_61.sel) or 0
				v_u_61.sel = v_u_61.runs[v75 % #v_u_61.runs + 1]
			end
		end)
		v66("RunMinus", function()
			-- upvalues: (copy) v_u_61
			local v76 = table.find(v_u_61.runs, v_u_61.sel)
			if v76 then
				table.remove(v_u_61.runs, v76)
				local v77 = v_u_61
				local v78 = v_u_61.runs
				local v79 = #v_u_61.runs
				v77.sel = v78[math.min(v76, v79)]
			end
		end)
		for v_u_80 = 1, 5 do
			v66("Run" .. v_u_80, function()
				-- upvalues: (copy) v_u_61, (copy) v_u_80
				v_u_61.sel = v_u_61.runs[v_u_80]
			end)
		end
		for v81 = 0, 14 do
			v66("Step" .. v81, function(p82)
				-- upvalues: (copy) v_u_61
				local v83 = p82:GetAttribute("Rpm")
				local v84 = v_u_61
				if v_u_61.cursor == v83 then
					v83 = nil
				end
				v84.cursor = v83
			end)
		end
		for v_u_85, v86 in {
			["rpm"] = "ChRpm",
			["thr"] = "ChThr",
			["afr"] = "ChAfr"
		} do
			v66(v86, function()
				-- upvalues: (copy) v_u_61, (copy) v_u_85
				v_u_61.ch[v_u_85] = not v_u_61.ch[v_u_85]
			end)
		end
	end
end
local function v_u_98(p88) -- name: attach
	-- upvalues: (copy) v_u_29, (copy) v_u_30, (copy) v_u_10, (copy) v_u_12, (copy) v_u_51, (copy) v_u_57, (copy) v_u_87
	local v89 = p88:GetAttribute("Side")
	local v90 = p88:WaitForChild("DynoScreen", 10)
	local v91 = p88:WaitForChild("Pad", 10)
	if v89 and (v90 and v91) then
		local v92 = v91.Value
		local v93 = os.clock()
		while not v92 and (os.clock() - v93 < 30 and p88.Parent) do
			v91.Changed:Wait()
			v92 = v91.Value
		end
		if v92 and p88.Parent then
			local v94 = v_u_29[v92]
			if not v94 then
				v94 = {
					["pad"] = v92,
					["st"] = v_u_30()
				}
				v_u_29[v92] = v94
			end
			local v95 = v89 == "Left" and "left" or "right"
			if v94[v95] then
				v94[v95].gui:Destroy()
			end
			local v_u_96 = v_u_10.clone(v90)
			v_u_96.Name = "DynoScreen_" .. v89
			v_u_96.Adornee = p88
			v_u_96.ResetOnSpawn = false
			pcall(function()
				-- upvalues: (copy) v_u_96
				v_u_96.Active = true
			end)
			v_u_96.Parent = v_u_12
			v90.Enabled = false
			local v97
			if v89 == "Left" then
				v97 = v_u_51(v_u_96)
			else
				v97 = v_u_57(v_u_96)
			end
			v94[v95] = v97
			v94[v95].part = p88
			v_u_87(v94, v89, v_u_96)
			v94.st.filesDirty = true
		end
	else
		return
	end
end
v4:GetInstanceAddedSignal("DynoScreen"):Connect(function(p99)
	-- upvalues: (copy) v_u_98
	task.spawn(v_u_98, p99)
end)
v4:GetInstanceRemovedSignal("DynoScreen"):Connect(function(p100) -- name: detach
	-- upvalues: (copy) v_u_29
	for _, v101 in v_u_29 do
		for _, v102 in { "left", "right" } do
			if not v101[v102] or v101[v102].part ~= p100 then
				continue
			end
			v101[v102].gui:Destroy()
			v101[v102] = nil
		end
	end
end)
local function v_u_113(p103) -- name: onPad
	local v104 = workspace:FindFirstChild("SpawnedVehicles")
	local v105 = 9
	local v106 = nil
	for _, v107 in not v104 and {} or v104:GetChildren() do
		local v108 = v107:GetPivot().Position - p103.Position
		local v109 = v108.X
		local v110 = v108.Z
		local v111 = Vector3.new(v109, 0, v110).Magnitude
		if v111 >= v105 then
			continue
		end
		local v112 = v108.Y
		if math.abs(v112) >= 8 then
			continue
		end
		v106 = v107
		v105 = v111
	end
	return v106
end
local function v_u_144(p114, p115, p116) -- name: sample
	-- upvalues: (copy) v_u_8, (copy) v_u_22, (copy) v_u_7, (copy) v_u_5
	local v117 = {
		["t"] = os.clock()
	}
	local v118
	if p115 == nil then
		v118 = false
	else
		v118 = p115:GetAttribute("EngineOn") == true
	end
	local v119
	if p115 then
		v119 = p115:FindFirstChild("VehicleSeat", true) or p115:FindFirstChild("DriverSeat", true)
	else
		v119 = p115
	end
	v117.engineOn = v118
	v117.rpm = v118 and (v_u_8[p115] or 1700) or 0
	local v120
	if v119 and v119.Occupant then
		local v121 = v119.ThrottleFloat
		v120 = math.max(0, v121)
	else
		v120 = 0
	end
	v117.throttle = v120
	v117.hp = not v118 and 0 or v_u_22(p115, v117.rpm) * (0.06 + 0.94 * v117.throttle)
	local v122 = v117.hp
	local v123 = v117.rpm
	v117.tq = v123 <= 500 and 0 or v122 * 5252 / v123
	local v124
	if p115 then
		local _, _, v125 = v_u_7.upgradeScales(p115)
		v124 = (p115:GetAttribute("MaxSpeed") or 100) * (v125 or 1) * 1.008
	else
		v124 = 0
	end
	local v126
	if v118 then
		local v127 = v117.rpm - 1700
		v126 = math.max(0, v127) / 7300 * v124
	else
		v126 = 0
	end
	v117.speed = v126
	v117.sensor = v117.speed / 3.6 / 0.9990264638415542 * 60
	local v128 = {}
	local v129
	if p115 then
		v129 = p115:GetAttribute("EcuFeedback")
	else
		v129 = p115
	end
	local v130
	if v129 then
		local v131 = v_u_5.JSONDecode
		local v132 = v_u_5
		local v133
		v133, v130 = pcall(v131, v132, v129)
		if v133 then
			if type(v130) ~= "table" then
				v130 = v128
			end
		else
			v130 = v128
		end
	else
		v130 = v128
	end
	local v134 = (1 - (v130.Afr or 1)) * 1.4
	local v135 = 0.18 + 0.82 * v117.throttle * (0.45 + 0.55 * v117.rpm / 9000)
	local v136 = not p115 and 1 or v_u_7.upgradeScales(p115)
	local v137 = math.min(1, p116)
	if v118 then
		p114.ect = p114.ect + (86 + 8 * v117.rpm / 9000 - p114.ect) * (0.015 + 0.05 * v117.throttle) * v137 * 10
		p114.egt = p114.egt + (240 + 560 * (v117.rpm / 9000) * (0.35 + 0.65 * v117.throttle) - p114.egt) * 0.6 * v137
	else
		p114.ect = p114.ect + (33.2 - p114.ect) * 0.05 * v137
		p114.egt = p114.egt + (33.2 - p114.egt) * 0.3 * v137
	end
	p114.oil = p114.oil + (p114.ect - 6 - p114.oil) * 0.08 * v137
	local v138 = math.noise(v117.t * 0.7, 3.1)
	local v139 = p114.ect
	local v140 = p114.oil
	local v141 = p114.egt
	v117.ect = v139
	v117.oil = v140
	v117.egt = v141
	v117.inj = not v118 and 0 or (1.05 + 7.2 * v135) * (1 + (1 - (v130.Fuel or 1)) * 0.12)
	v117.ign = not v118 and 0 or 10 + 24 * (v117.rpm / 9000) - 7 * v117.throttle * (1 - v117.rpm / 9000) + (1 - (v130.Ign or 1)) * 3
	v117.stft = not v118 and 0 or v138 * 2.4 + (1 - (v130.Afr or 1)) * 6
	v117.afr = not v118 and 0 or 14.7 - 1.9 * v117.throttle + v134 + v138 * 0.15
	v117.flow = not v118 and 0 or 0.0055420999999999995 * v117.rpm / 2 * (0.25 + 0.7 * v117.throttle) * v136
	v117.baro = 1008 + math.noise(v117.t * 0.05, 7.7) * 3
	local v142
	if v118 then
		v142 = 32 + 66 * v117.throttle
	else
		v142 = v117.baro / 10
	end
	v117.map = v142
	v117.humid = 66.36 + math.noise(v117.t * 0.05, 1.3) * 0.4
	v117.temp = 33.2 + math.noise(v117.t * 0.03, 9.1) * 0.3
	v117.load = v117.tq * 1.3558 / 9.81 * 0.1 - p114.zeroLoad
	local v143 = (v117.rpm - p114.lastRpm) / math.max(p116, 0.001)
	p114.ramp = p114.ramp + (v143 - p114.ramp) * 0.4
	p114.lastRpm = v117.rpm
	return v117
end
local function v_u_157(p145, p146, p147) -- name: runStep
	-- upvalues: (copy) v_u_7, (copy) v_u_45
	if p145.rec then
		if p147.engineOn and p147.throttle >= 0.5 then
			if p147.rpm >= p145.startRpm then
				local v148 = p145.rec.pts[#p145.rec.pts]
				if not v148 or p147.rpm > v148.rpm + 40 then
					local v149 = p145.rec.pts
					local v150 = {
						["rpm"] = p147.rpm,
						["hp"] = p147.hp,
						["tq"] = p147.tq
					}
					table.insert(v149, v150)
				end
			end
			local v151 = p147.rpm
			local v152 = p145.stopRpm
			if math.min(v152, 9000) - 150 <= v151 then
				v_u_45(p145, p146)
			end
		else
			v_u_45(p145, p146)
		end
	else
		local v153
		if p145.hand then
			v153 = p145.armed
		else
			v153 = p145.auto and p145.mode == "DYNO" and true or p145.armed
		end
		if v153 and (p147.engineOn and (p147.throttle > 0.9 and p147.rpm <= p145.startRpm + 600)) then
			local v154 = v_u_7.vehicle(p146:GetAttribute("VehicleId"))
			local v155 = {
				["pts"] = {}
			}
			local v156
			if v154 then
				v156 = v154.th
			else
				v156 = p146.Name
			end
			v155.vehicle = v156
			p145.rec = v155
		end
		return
	end
end
local function v_u_164(p158) -- name: topsFor
	-- upvalues: (copy) v_u_22
	local v159 = 0
	local v160 = 0
	for v161 = 1700, 9000, 100 do
		local v162 = v_u_22(p158, v161)
		v159 = math.max(v159, v162)
		local v163 = v161 <= 500 and 0 or v162 * 5252 / v161
		v160 = math.max(v160, v163)
	end
	return v159, v160
end
for _, v165 in v4:GetTagged("DynoScreen") do
	task.spawn(v_u_98, v165)
end
local function v_u_228(p166, p167, p168, p169) -- name: drawLeft
	-- upvalues: (copy) v_u_6, (copy) v_u_13, (copy) v_u_164, (copy) v_u_7
	local v170 = p166.r
	local v171 = v_u_6.setSeg
	local v172 = v170.SensorRpm
	local v173 = p168.sensor + 0.5
	v171(v172, ("%d"):format((math.floor(v173))))
	v_u_6.setSeg(v170.Hp, ("%.1f"):format(p168.hp))
	local v174 = v_u_6.setSeg
	local v175 = v170.Rpm
	local v176 = p168.rpm / 10 + 0.5
	v174(v175, ("%d"):format(math.floor(v176) * 10))
	v_u_6.setSeg(v170.Tq, ("%.1f"):format(p168.tq * 1.3558))
	v_u_6.setSeg(v170.Speed, ("%.1f"):format(p168.speed))
	v170.Ecu.Ect.Text = ("%.2f"):format(p168.ect)
	v170.Ecu.Inj.Text = ("%.2f"):format(p168.inj)
	v170.Ecu.Ign.Text = ("%.2f"):format(p168.ign)
	v170.Ecu.Stft.Text = ("%.2f"):format(p168.stft)
	local v177 = v170.ModeDyno
	local v178 = v_u_13.btnRedOn
	local v179 = v_u_13.btnRed
	local v180 = p167.mode == "DYNO"
	if v177 then
		if v180 then
			v179 = v178
		end
		v177.BackgroundColor3 = v179
	end
	local v181 = v170.ModeRoad
	local v182 = v_u_13.btnRedOn
	local v183 = v_u_13.btnRed
	local v184 = p167.mode == "ROAD"
	if v181 then
		if v184 then
			v183 = v182
		end
		v181.BackgroundColor3 = v183
	end
	local v185 = v170.ModeHold
	local v186 = v_u_13.btnRedOn
	local v187 = v_u_13.btnRed
	local v188 = p167.hold
	if v185 then
		if v188 then
			v187 = v186
		end
		v185.BackgroundColor3 = v187
	end
	local v189 = v170.StartRpm
	local v190 = p167.startRpm
	v189.Text = tostring(v190)
	local v191 = v170.StopRpm
	local v192 = p167.stopRpm
	v191.Text = tostring(v192)
	local v193 = v170.Ramp
	local v194 = p167.ramp + 0.5
	local v195 = math.floor(v194)
	v193.Text = ("%d"):format((math.max(0, v195)))
	v170.HoldTime.Text = p167.hold and "\226\136\158" or "0"
	local v196 = v170.AutoStart
	local v197
	if p167.auto and not p167.hand then
		v197 = Color3.fromRGB(235, 235, 238)
	else
		v197 = Color3.fromRGB(120, 120, 124)
	end
	v196.BackgroundColor3 = v197
	for v198 = 1, 4 do
		local v199 = v170:FindFirstChild("Hex" .. v198)
		local v200 = p167.flash
		if v200 then
			if p167.flash.key == v198 then
				v200 = os.clock() - p167.flash.t < 0.25
			else
				v200 = false
			end
		end
		if not v199 then
			continue
		end
		for _, v201 in v199:GetChildren() do
			local v202
			if v200 then
				v202 = v_u_13.oliveEdge
			else
				v202 = v_u_13.olive
			end
			v201.BackgroundColor3 = v202
		end
	end
	local v203, v204, v205
	if p169 then
		v203, v204 = v_u_164(p169)
		local _, _, v206 = v_u_7.upgradeScales(p169)
		v205 = (p169:GetAttribute("MaxSpeed") or 100) * (v206 or 1) * 1.008
	else
		v203 = 10
		v204 = 10
		v205 = 100
	end
	local v207 = {}
	local v208 = v203 * 1.15 / 5
	local v209 = math.ceil(v208) * 5
	v207.Hp = math.max(5, v209)
	local v210 = v204 * 1.3558 * 1.15 / 5
	local v211 = math.ceil(v210) * 5
	v207.Tq = math.max(5, v211)
	local v212 = v205 * 1.15 / 5
	local v213 = math.ceil(v212) * 5
	v207.Speed = math.max(5, v213)
	local v214 = {
		["Hp"] = "hp",
		["Tq"] = "tqNm",
		["Speed"] = "speed"
	}
	for v215, v216 in p166.charts do
		local v217 = {}
		for v218, v219 in p167.hist do
			local v220
			if v215 == "Tq" then
				v220 = v219.tq * 1.3558
			else
				v220 = v219[v214[v215]]
			end
			local v221 = {}
			local v222 = (v218 - 1) / 59
			local v223 = v220 / v207[v215]
			__set_list(v221, 1, {v222, (math.clamp(v223, 0, 1))})
			v217[v218] = v221
		end
		v_u_6.plot(v216.pool, v217, 542, 194)
		local v224
		if v215 == "Tq" then
			v224 = p168.tq * 1.3558
		else
			v224 = p168[v214[v215]]
		end
		v216.value.Text = ("%.2f"):format(v224)
	end
	local v225 = p169 and (p167.hold and "HOLD" or (p167.rec and "RUN" or (p168.engineOn and (p169:GetAttribute("DynoLocked") and "LOCKED" or "IDLE") or "READY"))) or "STANDBY"
	v170.StatusMode.Text = "Mode:  " .. v225
	local v226 = v170.StatusBaro
	local v227 = p168.baro + 0.5
	v226.Text = ("%d mbar"):format((math.floor(v227)))
	v170.StatusHumid.Text = ("%.2f%%"):format(p168.humid)
	v170.StatusTemp.Text = ("%.2f\194\176C"):format(p168.temp)
	v170.StatusBrake.Text = "Brake 0.00%"
	v170.StatusLoad.Text = ("Abs Load-cell %.2f"):format(p168.load)
end
local function v_u_239(p229, p230, p231) -- name: valueAt
	local v232 = p229.pts
	for v233 = 1, #v232 - 1 do
		local v234 = v232[v233]
		local v235 = v232[v233 + 1]
		if v234.rpm > p230 or p230 > v235.rpm then
			continue
		end
		local v236 = p230 - v234.rpm
		local v237 = v235.rpm - v234.rpm
		local v238 = v236 / math.max(1, v237)
		return v234[p231] + (v235[p231] - v234[p231]) * v238
	end
	return nil
end
local function v_u_295(p240, p241) -- name: drawFiles
	-- upvalues: (copy) v_u_6, (copy) v_u_28, (copy) v_u_239, (copy) v_u_13
	local v242 = p240.r
	local v243 = v242.RunFiles
	local v244 = 5
	for _, v245 in p241.runs do
		if p241.showHp then
			local v246 = v245.peakHp
			v244 = math.max(v244, v246)
		end
		if not p241.showTq then
			continue
		end
		local v247 = v245.peakTq
		v244 = math.max(v244, v247)
	end
	if p241.rec then
		for _, v248 in p241.rec.pts do
			if p241.showHp then
				local v249 = v248.hp
				v244 = math.max(v244, v249)
			end
			if not p241.showTq then
				continue
			end
			local v250 = v248.tq
			v244 = math.max(v244, v250)
		end
	end
	local v251 = v244 * 1.15 / 5
	local v252 = math.ceil(v251) * 5
	local v_u_253 = math.max(5, v252)
	for v254 = 0, 4 do
		local v255 = v243["YTick" .. v254]
		local v256 = v_u_253 * (4 - v254) / 4 + 0.5
		v255.Text = ("%d"):format((math.floor(v256)))
	end
	v243.YTitle.Text = p241.showHp and p241.showTq and "Power (hp) \194\183 Torque (lb-ft)" or (p241.showHp and "Power (hp)" or "Torque (lb-ft)")
	local function v266(p257, p258) -- name: pts
		-- upvalues: (ref) v_u_253
		local v259 = {}
		for v260, v261 in p257 do
			local v262 = {}
			local v263 = (v261.rpm - 2000) / 7000
			local v264 = math.clamp(v263, 0, 1)
			local v265 = v261[p258] / v_u_253
			__set_list(v262, 1, {v264, (math.clamp(v265, 0, 1))})
			v259[v260] = v262
		end
		return v259
	end
	local v267 = {}
	for v268 = 1, 5 do
		local v269 = p241.runs[v268]
		local v270 = p240.files[v268]
		local v271 = v_u_6.RUN_COLORS[v268]
		v_u_6.setColor(v270.hp, v271)
		v_u_6.setColor(v270.tq, v271:Lerp(Color3.new(1, 1, 1), 0.35))
		v_u_6.plot(v270.hp, not (v269 and p241.showHp) and {} or v266(v269.pts, "hp"), 756, 190)
		v_u_6.plot(v270.tq, not (v269 and p241.showTq) and {} or v266(v269.pts, "tq"), 756, 190)
		if not v269 then
			continue
		end
		local v272 = ("#%02x%02x%02x"):format(v271.R * 255, v271.G * 255, v271.B * 255)
		local v273 = v269.n
		local v274 = v269 == p241.sel and "*" or ""
		table.insert(v267, ("<font color=\"%s\">\226\150\160</font> Run %d%s"):format(v272, v273, v274))
	end
	local v275 = not p241.rec and {} or v_u_28(p241.rec.pts, 80)
	v_u_6.plot(p240.recHp, not p241.showHp and {} or v266(v275, "hp"), 756, 190)
	v_u_6.plot(p240.recTq, not p241.showTq and {} or v266(v275, "tq"), 756, 190)
	if p241.rec then
		table.insert(v267, "<font color=\"#eb372d\">\226\150\160</font> live")
	end
	v243.Legend.RichText = true
	v243.Legend.Text = table.concat(v267, "    ")
	local v276 = v243.Area.Cursor
	if p241.cursor then
		v276.Visible = true
		v276.Position = UDim2.fromOffset((p241.cursor - 2000) / 7000 * 756 - 1, 0)
		local v277 = { ("@ %d rpm"):format(p241.cursor) }
		for _, v278 in p241.runs do
			local v279 = v_u_239(v278, p241.cursor, "hp")
			local v280 = v_u_239(v278, p241.cursor, "tq")
			if not v279 then
				continue
			end
			local v281 = v278.n
			table.insert(v277, ("Run %d: %.1f hp \194\183 %.1f lb-ft"):format(v281, v279, v280))
		end
		v243.Readout.Text = table.concat(v277, "\n")
	else
		v276.Visible = false
		local v282 = p241.sel
		local v283 = v243.Readout
		local v284
		if v282 then
			local v285 = v282.n
			local v286 = v282.vehicle or ""
			local v287 = v282.peakHp
			local v288 = v282.peakHpRpm / 50
			local v289 = math.floor(v288) * 50
			local v290 = v282.peakTq
			local v291 = v282.peakTqRpm / 50
			v284 = ("Run %d \194\183 %s\nPeak %.1f hp @ %d rpm\nPeak %.1f lb-ft @ %d rpm"):format(v285, v286, v287, v289, v290, math.floor(v291) * 50)
		else
			v284 = ""
		end
		v283.Text = v284
	end
	for v292 = 0, 14 do
		local v293 = v242["Step" .. v292]
		local v294
		if p241.cursor == v293:GetAttribute("Rpm") then
			v294 = Color3.fromRGB(200, 222, 40)
		else
			v294 = v_u_13.orange
		end
		v293.BackgroundColor3 = v294
	end
end
local function v_u_365(p_u_296, p_u_297, p298, p299) -- name: drawRight
	-- upvalues: (copy) v_u_6, (copy) v_u_13, (copy) v_u_7, (copy) v_u_295
	local v300 = p_u_296.r
	local function v309(p301, p302) -- name: line
		-- upvalues: (copy) p_u_297, (ref) v_u_6, (copy) p_u_296
		local v303 = {}
		if p_u_297.ch[p301] then
			for v304, v305 in p_u_297.hist do
				local v306 = {}
				local v307 = (v304 - 1) / 59
				local v308 = p302(v305)
				__set_list(v306, 1, {v307, (math.clamp(v308, 0, 1))})
				v303[v304] = v306
			end
		end
		v_u_6.plot(p_u_296.lines[p301], v303, 770, 250)
	end
	v309("rpm", function(p310)
		return p310.rpm / 10000
	end)
	v309("thr", function(p311)
		return p311.throttle
	end)
	v309("afr", function(p312)
		return p312.afr <= 0 and 0 or (p312.afr - 10) / 8
	end)
	v300.TileFlow.Value.Text = ("%.2f"):format(p298.flow)
	v300.TileMap.Value.Text = ("%.1f"):format(p298.map)
	v300.TileBaro.Value.Text = ("%.2f"):format(p298.baro)
	v300.TileAfr.Value.Text = p298.afr <= 0 and "--" or ("%.2f"):format(p298.afr)
	local v313 = v300.TileEgt.Value
	local v314 = p298.egt + 0.5
	v313.Text = ("%d"):format((math.floor(v314)))
	v300.TileOil.Value.Text = ("%.1f"):format(p298.oil)
	local v315 = {}
	local v316 = p298.rpm + 0.5
	v315.ChRpm = ("Value: %d rpm"):format((math.floor(v316)))
	local v317 = p298.throttle * 100 + 0.5
	v315.ChThr = ("Value: %d %%"):format((math.floor(v317)))
	v315.ChAfr = p298.afr <= 0 and "Value: --" or ("Value: %.2f :1"):format(p298.afr)
	v315.ChFlow = ("Value: %.2f CFM"):format(p298.flow)
	local v318 = p298.egt + 0.5
	v315.ChEgt = ("Value: %d \194\176C"):format((math.floor(v318)))
	v315.ChOil = ("Value: %.1f \194\176C"):format(p298.oil)
	v315.ChBaro = ("Value: %.2f mBar"):format(p298.baro)
	for v319, v320 in v315 do
		v300[v319].Value.Text = v320
	end
	local v321 = v300.ChRpm.Edge
	local v322
	if p_u_297.ch.rpm then
		v322 = Color3.fromRGB(80, 230, 240)
	else
		v322 = Color3.fromRGB(30, 30, 34)
	end
	v321.Color = v322
	local v323 = v300.ChThr.Edge
	local v324
	if p_u_297.ch.thr then
		v324 = Color3.fromRGB(60, 200, 235)
	else
		v324 = Color3.fromRGB(30, 30, 34)
	end
	v323.Color = v324
	local v325 = v300.ChAfr.Edge
	local v326
	if p_u_297.ch.afr then
		v326 = Color3.fromRGB(240, 70, 70)
	else
		v326 = Color3.fromRGB(30, 30, 34)
	end
	v325.Color = v326
	local v327 = v300.RunList
	v327.Head.Text.Text = not p_u_297.sel and "No runs" or ("Run %d"):format(p_u_297.sel.n)
	for v328 = 1, 5 do
		local v329 = v327["Run" .. v328]
		local v330 = p_u_297.runs[v328]
		v329.Visible = v330 ~= nil
		if not v330 then
			continue
		end
		v329.Text = ("Run %d"):format(v330.n)
		local v331
		if v330 == p_u_297.sel then
			v331 = Color3.fromRGB(150, 80, 22)
		else
			v331 = Color3.fromRGB(26, 26, 30)
		end
		v329.BackgroundColor3 = v331
		v329.TextColor3 = v_u_6.RUN_COLORS[v328]:Lerp(Color3.new(1, 1, 1), 0.4)
	end
	local v332 = v300.Run
	local v333 = Color3.fromRGB(110, 255, 120)
	local v334 = Color3.fromRGB(40, 195, 60)
	local v335 = p_u_297.armed
	if v332 then
		if v335 then
			v334 = v333
		end
		v332.BackgroundColor3 = v334
	end
	local v336 = v300.Hold
	local v337 = Color3.fromRGB(230, 140, 40)
	local v338 = Color3.fromRGB(150, 80, 22)
	local v339 = p_u_297.hold
	if v336 then
		if v339 then
			v338 = v337
		end
		v336.BackgroundColor3 = v338
	end
	local v340 = v300.Hand
	local v341 = Color3.fromRGB(90, 110, 140)
	local v342 = Color3.fromRGB(40, 46, 58)
	local v343 = p_u_297.hand
	if v340 then
		if v343 then
			v342 = v341
		end
		v340.BackgroundColor3 = v342
	end
	local v344 = v300.AutoRun
	local v345 = Color3.fromRGB(230, 140, 40)
	local v346 = Color3.fromRGB(80, 44, 14)
	local v347 = p_u_297.auto
	if v347 then
		v347 = not p_u_297.hand
	end
	if v344 then
		if v347 then
			v346 = v345
		end
		v344.BackgroundColor3 = v346
	end
	local v348 = v300.ShowHp
	local v349 = Color3.fromRGB(40, 195, 60)
	local v350 = v_u_13.bg2
	local v351 = p_u_297.showHp
	if v348 then
		if v351 then
			v350 = v349
		end
		v348.BackgroundColor3 = v350
	end
	local v352 = v300.ShowTq
	local v353 = Color3.fromRGB(40, 195, 60)
	local v354 = v_u_13.bg2
	local v355 = p_u_297.showTq
	if v352 then
		if v355 then
			v354 = v353
		end
		v352.BackgroundColor3 = v354
	end
	local v356 = p_u_297.rec
	if v356 then
		v356 = os.clock() % 0.6 < 0.4
	end
	local v357 = v300.Sampling
	local v358
	if v356 then
		v358 = Color3.fromRGB(255, 220, 60)
	elseif p_u_297.rec then
		v358 = Color3.fromRGB(235, 190, 30)
	else
		v358 = Color3.fromRGB(110, 92, 24)
	end
	v357.BackgroundColor3 = v358
	v300.Sampling.Text = p_u_297.rec and "SAMPLING" or ((p_u_297.armed or p_u_297.auto and (not p_u_297.hand and p_u_297.mode == "DYNO")) and "READY" or "SAMPLING")
	local v359 = not p299 and 1 or v_u_7.upgradeScales(p299)
	v300.Gain.Text = ("x%.2f"):format(v359)
	local v360
	if p299 then
		v360 = v_u_7.vehicle(p299:GetAttribute("VehicleId"))
	else
		v360 = p299
	end
	local v361 = v300.InfoProject
	local v362
	if p299 then
		if v360 then
			v362 = v360.th
		else
			v362 = p299.Name
		end
	else
		v362 = "-"
	end
	v361.Text = v362
	v300.InfoOwner.Text = p299 and (p299:GetAttribute("OwnerName") or "-") or "-"
	v300.InfoEngine.Text = not p299 and "-" or ("Stage %d"):format(p299:GetAttribute("EngineLevel") or 0)
	local v363 = v300.InfoEcu
	local v364
	if p299 and p299:GetAttribute("EcuGain") then
		v364 = ("%.3f"):format(p299:GetAttribute("EcuGain"))
	else
		v364 = p299 and "factory" or "-"
	end
	v363.Text = v364
	v300.InfoStep.Text = "40 rpm"
	v300.InfoTemp.Text = ("%.2f \194\176C"):format(p298.temp)
	if p_u_297.filesDirty or p_u_297.rec then
		p_u_297.filesDirty = false
		v_u_295(p_u_296, p_u_297)
	end
end
local v_u_366 = 0
v3.Heartbeat:Connect(function(p367)
	-- upvalues: (ref) v_u_366, (copy) v_u_11, (copy) v_u_29, (copy) v_u_113, (copy) v_u_144, (copy) v_u_157, (copy) v_u_9, (copy) v_u_228, (copy) v_u_365
	v_u_366 = v_u_366 + p367
	if v_u_366 >= 0.1 then
		local v_u_368 = v_u_366
		v_u_366 = 0
		local v369 = v_u_11.Character
		if v369 then
			v369 = v_u_11.Character:FindFirstChild("HumanoidRootPart")
		end
		for v_u_370, v_u_371 in v_u_29 do
			if not v_u_370.Parent or (not v369 or (v369.Position - v_u_370.Position).Magnitude >= 160) then
				continue
			end
			local function v378()
				-- upvalues: (copy) v_u_371, (ref) v_u_113, (copy) v_u_370, (ref) v_u_144, (copy) v_u_368, (ref) v_u_157, (ref) v_u_11, (ref) v_u_9, (ref) v_u_228, (ref) v_u_365
				local v372 = v_u_371.st
				local v373 = v_u_113(v_u_370)
				if v373 ~= v372.model then
					v372.model = v373
					v372.rec = nil
					v372.hist = {}
					v372.ect = 33.2
					v372.egt = 33.2
				end
				local v374 = v_u_144(v372, v373, v_u_368)
				v372.last = v374
				if v373 then
					v_u_157(v372, v373, v374)
					local v375 = v373:FindFirstChild("VehicleSeat", true)
					local v376 = v375 and v375.Occupant
					if v376 then
						v376 = v375.Occupant.Parent == v_u_11.Character
					end
					if v376 and (v373:GetAttribute("DynoLocked") and v372.toldLock ~= v373) then
						v372.toldLock = v373
						v_u_9.show("\224\184\165\224\185\135\224\184\173\224\184\129\224\184\154\224\184\153\224\185\129\224\184\151\224\185\136\224\184\153\224\185\129\224\184\165\224\185\137\224\184\167: \224\184\154\224\184\180\224\184\148\224\184\132\224\184\177\224\184\153\224\185\128\224\184\163\224\185\136\224\184\135\224\184\170\224\184\184\224\184\148\224\184\132\224\185\137\224\184\178\224\184\135\224\185\132\224\184\167\224\185\137\224\185\128\224\184\158\224\184\183\224\185\136\224\184\173\224\184\167\224\184\180\224\185\136\224\184\135\224\184\163\224\184\177\224\184\153 \194\183 \224\184\129\224\184\148 S \224\185\128\224\184\158\224\184\183\224\185\136\224\184\173\224\184\150\224\184\173\224\184\162\224\184\173\224\184\173\224\184\129", "info")
					elseif not v373:GetAttribute("DynoLocked") and v372.toldLock == v373 then
						v372.toldLock = nil
					end
				end
				if not v372.hold then
					local v377 = v372.hist
					table.insert(v377, v374)
					if #v372.hist > 60 then
						table.remove(v372.hist, 1)
					end
					if v_u_371.left then
						v_u_228(v_u_371.left, v372, v374, v373)
					end
					if v_u_371.right then
						v_u_365(v_u_371.right, v372, v374, v373)
					end
				end
			end
			local v379, v380 = pcall(v378)
			if v379 then
				continue
			end
			warn("DynoScreensClient:", v380)
		end
	end
end)