-- Path: Players/ygggggg55551/PlayerScripts/PlateClient
-- Class: LocalScript  true/Enum.RunContext.Legacy
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = require(game:GetService("ReplicatedStorage"):WaitForChild("UiOwn")).Instance
local v_u_2 = require(game:GetService("ReplicatedStorage"):WaitForChild("NetSeal"))
local v3 = game:GetService("CollectionService")
local v4 = game:GetService("Players")
local v5 = game:GetService("ReplicatedStorage")
local v6 = game:GetService("RunService")
local v_u_7 = game:GetService("UserInputService")
local v8 = require(v5:WaitForChild("GameShared"))
local v_u_9 = require(v5:WaitForChild("PlateShared"))
local v10 = v5:WaitForChild("GameUI")
local v_u_11 = require(v10:WaitForChild("Theme"))
local v_u_12 = require(v10:WaitForChild("Toast"))
local v_u_13 = v4.LocalPlayer
local v_u_14 = v5:WaitForChild(v8.REMOTES):WaitForChild(v_u_9.REMOTE)
local v_u_15 = v_u_11.YELLOW
local v_u_16 = Color3.fromRGB(58, 60, 64)
local v_u_17 = {}
local v_u_18 = {
	["None"] = { Color3.fromRGB(38, 38, 42), Enum.Material.SmoothPlastic },
	["Chrome"] = { Color3.fromRGB(212, 214, 220), Enum.Material.Metal },
	["Black"] = { Color3.fromRGB(16, 16, 18), Enum.Material.SmoothPlastic },
	["Gold"] = { Color3.fromRGB(222, 176, 72), Enum.Material.Metal },
	["Carbon"] = { Color3.fromRGB(34, 35, 38), Enum.Material.Metal }
}
local function v_u_29(p19, p20) -- name: redraw
	-- upvalues: (copy) v_u_9, (copy) v_u_18
	local v21 = v_u_9.design(p19)
	local v22 = p19:GetAttribute("PlateOn") ~= false
	local v23 = v_u_18[v21.frame] or v_u_18.None
	local v24 = v22 and 0 or 1
	for _, v25 in p20.rims do
		v25.Color = v23[1]
		v25.Material = v23[2]
		v25.LocalTransparencyModifier = v24
	end
	for _, v26 in p20.holders do
		v26.LocalTransparencyModifier = v24
	end
	for v27, v28 in p20.plates do
		v27.LocalTransparencyModifier = v24
		v28:ClearAllChildren()
		v28.Enabled = v22
		if not v22 then
			continue
		end
		v_u_9.draw(v28, v21, v27:GetAttribute("PlateKind") or "Car")
	end
end
local function v_u_41(_, p30, p31) -- name: addPart
	-- upvalues: (copy) v_u_9, (copy) v_u_1
	if p31:IsA("BasePart") then
		if p31.Name == v_u_9.PART and not p30.plates[p31] then
			local v32 = p31:GetAttribute("PlateKind") or "Car"
			local v_u_33 = v_u_1.new("SurfaceGui")
			v_u_33.Name = "PlateFace"
			v_u_33.Face = Enum.NormalId.Front
			v_u_33.SizingMode = Enum.SurfaceGuiSizingMode.FixedSize
			local v34 = v_u_9.CANVAS[v32] or v_u_9.CANVAS.Car
			local v35 = Vector2.new
			local v36 = v34.Y * p31.Size.X / p31.Size.Y + 0.5
			v_u_33.CanvasSize = v35(math.floor(v36), v34.Y)
			v_u_33.LightInfluence = 0.8
			pcall(function()
				-- upvalues: (copy) v_u_33
				v_u_33.MaxDistance = 140
			end)
			v_u_33.Parent = p31
			p30.plates[p31] = v_u_33
			p30.dirty = true
			return
		elseif p31.Name == "PlateRim" then
			local v37 = p30.rims
			table.insert(v37, p31)
			p30.dirty = true
			return
		elseif p31.Name == "PlateHolder" then
			local v38 = p30.holders
			table.insert(v38, p31)
			p30.dirty = true
			return
		elseif p31:GetAttribute("Kickstand") or p31:GetAttribute("CenterStand") then
			local v39 = p30.stands
			table.insert(v39, p31)
		elseif p31:GetAttribute("SeatLid") then
			local v40 = p30.lids
			table.insert(v40, p31)
		end
	else
		return
	end
end
local v_u_42 = {}
local v_u_43 = true
local function v_u_55(p_u_44, p45) -- name: track
	-- upvalues: (copy) v_u_17, (copy) v_u_41, (ref) v_u_43, (copy) v_u_9
	if not v_u_17[p_u_44] and p_u_44:IsA("Model") then
		local v_u_46 = {
			["plates"] = {},
			["stands"] = {},
			["lids"] = {},
			["rims"] = {},
			["holders"] = {},
			["connections"] = {},
			["drawOnly"] = p45 == true
		}
		v_u_17[p_u_44] = v_u_46
		for _, v47 in p_u_44:GetDescendants() do
			v_u_41(p_u_44, v_u_46, v47)
		end
		local v48 = v_u_46.connections
		local v49 = p_u_44.DescendantAdded
		local function v51(p50)
			-- upvalues: (ref) v_u_41, (copy) p_u_44, (copy) v_u_46, (ref) v_u_43
			v_u_41(p_u_44, v_u_46, p50)
			v_u_43 = true
		end
		table.insert(v48, v49:Connect(v51))
		for _, v52 in v_u_9.ATTRIBUTES do
			local v53 = v_u_46.connections
			local v54 = p_u_44:GetAttributeChangedSignal(v52)
			table.insert(v53, v54:Connect(function()
				-- upvalues: (copy) v_u_46
				v_u_46.dirty = true
			end))
		end
		v_u_46.dirty = true
		v_u_43 = true
	end
end
local function v_u_60(p56) -- name: untrack
	-- upvalues: (copy) v_u_17, (ref) v_u_43
	local v57 = v_u_17[p56]
	if v57 then
		for _, v58 in v57.connections do
			v58:Disconnect()
		end
		for _, v59 in v57.plates do
			v59:Destroy()
		end
		v_u_17[p56] = nil
		v_u_43 = true
	end
end
local v_u_61 = v_u_43
for _, v62 in { "PCX160", "GTACar" } do
	v3:GetInstanceAddedSignal(v62):Connect(v_u_55)
	v3:GetInstanceRemovedSignal(v62):Connect(v_u_60)
	for _, v63 in v3:GetTagged(v62) do
		v_u_55(v63)
	end
end
task.spawn(function()
	-- upvalues: (copy) v_u_55, (copy) v_u_60
	local v64 = workspace:WaitForChild("VehicleCargo")
	v64.ChildAdded:Connect(function(p65)
		-- upvalues: (ref) v_u_55
		v_u_55(p65, true)
	end)
	v64.ChildRemoved:Connect(v_u_60)
	for _, v66 in v64:GetChildren() do
		v_u_55(v66, true)
	end
end)
local v_u_67 = v_u_11.screen("PlateUI", 14, v_u_13:WaitForChild("PlayerGui"))
local v_u_68 = v_u_11.panel({
	["Name"] = "Hint",
	["Size"] = nil,
	["AutomaticSize"] = nil,
	["Visible"] = false,
	["ZIndex"] = 5,
	["Parent"] = nil,
	["Size"] = UDim2.fromOffset(0, 30),
	["AutomaticSize"] = Enum.AutomaticSize.X,
	["Parent"] = v_u_67
})
v_u_11.padding(v_u_68, 10, 0)
local v_u_69 = v_u_11.text({
	["Size"] = nil,
	["AutomaticSize"] = nil,
	["FontFace"] = nil,
	["TextSize"] = 15,
	["ZIndex"] = 6,
	["Parent"] = nil,
	["Size"] = UDim2.fromScale(0, 1),
	["AutomaticSize"] = Enum.AutomaticSize.X,
	["FontFace"] = v_u_11.FONT_BOLD,
	["Parent"] = v_u_68
})
local v_u_70 = false
local v_u_71 = ""
local v_u_72 = nil
local v_u_73 = false
local v_u_74 = false
local function v_u_82() -- name: rebuildClickables
	-- upvalues: (ref) v_u_61, (copy) v_u_42, (copy) v_u_17
	v_u_61 = false
	table.clear(v_u_42)
	for _, v75 in v_u_17 do
		if v75.drawOnly then
			continue
		end
		for v76 in v75.plates do
			local v77 = v_u_42
			table.insert(v77, v76)
		end
		for _, v78 in v75.stands do
			local v79 = v_u_42
			table.insert(v79, v78)
		end
		for _, v80 in v75.lids do
			local v81 = v_u_42
			table.insert(v81, v80)
		end
	end
end
local function v_u_101(p83) -- name: pick
	-- upvalues: (ref) v_u_61, (copy) v_u_82, (copy) v_u_42, (copy) v_u_17, (copy) v_u_13, (copy) v_u_9
	if v_u_61 then
		v_u_82()
	end
	local v84 = RaycastParams.new()
	v84.FilterType = Enum.RaycastFilterType.Include
	v84.FilterDescendantsInstances = v_u_42
	local v85 = workspace:Raycast(p83.Origin, p83.Direction * 80, v84)
	if not v85 then
		return nil
	end
	local v86 = v85.Instance
	for v88 in v_u_17 do
		if not v86:IsDescendantOf(v88) then
			continue
		end
	end
	local v88 = nil
	if v88 then
		local v89 = v88:GetAttribute("OwnerUserId")
		if v89 == nil and true or v89 == v_u_13.UserId then
			local v90 = v86:GetAttribute("SeatLid") == true
			if v90 then
				local v91 = v_u_13.Character
				if v91 then
					v91 = v_u_13.Character:FindFirstChildOfClass("Humanoid")
				end
				if v91 and (v91.SeatPart and v91.SeatPart:IsDescendantOf(v88)) then
					return nil
				end
			end
			local v92
			if v86.Name == v_u_9.PART then
				v92 = false
			else
				v92 = not v90
			end
			if v92 and v86.Transparency >= 1 then
				return nil
			end
			local v93 = v_u_13.Character
			local v94 = RaycastParams.new()
			v94.FilterType = Enum.RaycastFilterType.Exclude
			v94.FilterDescendantsInstances = v93 and { v93, v88 } or { v88 }
			local v95 = workspace:Raycast(p83.Origin, p83.Direction.Unit * (v85.Distance - 0.1), v94)
			if v95 and v95.Instance.Transparency < 0.5 then
				return nil
			end
			if v93 then
				v93 = v93:FindFirstChild("HumanoidRootPart")
			end
			if not v93 or (v93.Position - v85.Position).Magnitude > v_u_9.CLICK_DISTANCE then
				return nil
			end
			if v90 then
				return {
					["model"] = nil,
					["kind"] = "SeatLid",
					["parts"] = nil,
					["model"] = v88,
					["parts"] = v_u_17[v88].lids
				}
			end
			if v92 then
				local v96 = {}
				for _, v97 in v_u_17[v88].stands do
					if v97.Transparency >= 1 then
						continue
					end
					table.insert(v96, v97)
				end
				return {
					["model"] = nil,
					["kind"] = "Stand",
					["parts"] = nil,
					["model"] = v88,
					["parts"] = v96
				}
			end
			local v98 = v88:GetAttribute("PlateOn") ~= false
			local v99 = {}
			for v100 in v_u_17[v88].plates do
				table.insert(v99, v100)
			end
			return {
				["model"] = v88,
				["kind"] = v98 and "PlateOn" or "PlateOff",
				["parts"] = v99
			}
		end
	end
	return nil
end
local v_u_102 = {
	["PlateOn"] = "\224\184\132\224\184\165\224\184\180\224\184\129: \224\184\150\224\184\173\224\184\148\224\184\155\224\185\137\224\184\178\224\184\162\224\184\151\224\184\176\224\185\128\224\184\154\224\184\181\224\184\162\224\184\153",
	["PlateOff"] = "\224\184\132\224\184\165\224\184\180\224\184\129: \224\185\131\224\184\170\224\185\136\224\184\155\224\185\137\224\184\178\224\184\162\224\184\151\224\184\176\224\185\128\224\184\154\224\184\181\224\184\162\224\184\153 (\224\185\128\224\184\165\224\184\183\224\184\173\224\184\129\224\185\129\224\184\154\224\184\154 \224\184\149\224\184\177\224\185\137\224\184\135\224\185\128\224\184\165\224\184\130\224\185\128\224\184\173\224\184\135)"
}
local function v_u_107(p103, p104) -- name: showHover
	-- upvalues: (ref) v_u_72, (copy) v_u_13, (copy) v_u_1, (ref) v_u_70, (copy) v_u_7, (ref) v_u_71, (copy) v_u_68, (copy) v_u_69, (copy) v_u_102
	v_u_72 = p103
	local v105 = v_u_13:FindFirstChild("HoverBike")
	if not v105 then
		v105 = v_u_1.new("ObjectValue")
		v105.Name = "HoverBike"
		v105.Parent = v_u_13
	end
	local v106
	if p103 then
		v106 = p103.model
	else
		v106 = nil
	end
	v105.Value = v106
	if p103 then
		if v_u_70 ~= true then
			v_u_70 = true
			v_u_71 = v_u_7.MouseIcon
			v_u_7.MouseIcon = "rbxasset://SystemCursors/PointingHand"
		end
		if p103.kind == "SeatLid" then
			v_u_69.Text = p103.model:GetAttribute("SeatOpen") and "\224\184\132\224\184\165\224\184\180\224\184\129: \224\184\155\224\184\180\224\184\148\224\185\128\224\184\154\224\184\178\224\184\176" or "\224\184\132\224\184\165\224\184\180\224\184\129: \224\185\128\224\184\155\224\184\180\224\184\148\224\185\128\224\184\154\224\184\178\224\184\176 (\224\184\151\224\184\181\224\185\136\224\185\128\224\184\129\224\185\135\224\184\154\224\184\130\224\184\173\224\184\135\224\185\131\224\184\149\224\185\137\224\185\128\224\184\154\224\184\178\224\184\176)"
		elseif p103.kind == "Stand" then
			v_u_69.Text = p103.model:GetAttribute("StandType") == "Center" and "Click: switch to the side stand" or "Click: switch to the center stand"
		else
			v_u_69.Text = v_u_102[p103.kind]
		end
		if p104 then
			v_u_68.Position = UDim2.fromOffset(p104.X + 18, p104.Y - 8)
			v_u_68.Visible = true
		end
	else
		if v_u_70 ~= false then
			v_u_70 = false
			v_u_7.MouseIcon = v_u_71
		end
		v_u_68.Visible = false
	end
end
local v_u_108 = nil
local function v_u_117(p109) -- name: act
	-- upvalues: (ref) v_u_74, (ref) v_u_108, (copy) v_u_2, (copy) v_u_14, (copy) v_u_12
	if v_u_74 or not p109 then
		return
	elseif p109.kind == "PlateOff" then
		v_u_108(p109.model)
	else
		v_u_74 = true
		local v110 = p109.kind == "Stand" and "Stand" or (p109.kind == "SeatLid" and "SeatLid" or "Remove")
		local v111 = v_u_2.invoke
		local v112 = v_u_14
		local v113 = p109.model
		local v114, v115, v116 = pcall(v111, v112, v110, v113)
		v_u_74 = false
		if v114 and v116 then
			v_u_12.show(v116, v115 and "ok" or "error")
		end
	end
end
v6.RenderStepped:Connect(function()
	-- upvalues: (copy) v_u_17, (copy) v_u_29, (ref) v_u_73, (copy) v_u_11, (ref) v_u_72, (copy) v_u_13, (copy) v_u_1, (ref) v_u_70, (copy) v_u_7, (ref) v_u_71, (copy) v_u_68, (copy) v_u_101, (copy) v_u_67, (copy) v_u_107
	for v118, v119 in v_u_17 do
		if not v119.dirty then
			continue
		end
		v119.dirty = false
		v_u_29(v118, v119)
	end
	if v_u_73 or v_u_11.isTouch() then
		if v_u_72 then
			v_u_72 = nil
			local v120 = v_u_13:FindFirstChild("HoverBike")
			if not v120 then
				v120 = v_u_1.new("ObjectValue")
				v120.Name = "HoverBike"
				v120.Parent = v_u_13
			end
			v120.Value = nil
			if v_u_70 ~= false then
				v_u_70 = false
				v_u_7.MouseIcon = v_u_71
			end
			v_u_68.Visible = false
		end
	else
		local v121 = workspace.CurrentCamera
		local v122 = v_u_7:GetMouseLocation()
		if v121 then
			v121 = v_u_101(v121:ViewportPointToRay(v122.X, v122.Y))
		end
		local v123 = v_u_67.AbsolutePosition
		local v124 = v_u_107
		local v125
		if v121 then
			v125 = Vector2.new(v122.X, v122.Y) - Vector2.new(0, -v123.Y)
		else
			v125 = v121
		end
		v124(v121, v125)
	end
end)
v_u_7.InputBegan:Connect(function(p126, p127)
	-- upvalues: (ref) v_u_73, (ref) v_u_72, (copy) v_u_117
	if not (p127 or v_u_73) then
		if p126.UserInputType == Enum.UserInputType.MouseButton1 and v_u_72 then
			v_u_117(v_u_72)
		end
	end
end)
v_u_7.TouchTap:Connect(function(p128, p129)
	-- upvalues: (ref) v_u_73, (copy) v_u_101, (copy) v_u_117
	if not p129 and (not v_u_73 and p128[1]) then
		local v130 = workspace.CurrentCamera
		local v131 = p128[1]
		if v130 then
			v130 = v_u_101(v130:ScreenPointToRay(v131.X, v131.Y))
		end
		if v130 then
			v_u_117(v130)
		end
	end
end)
local function v_u_137(p_u_132) -- name: chars
	local v_u_133 = {}
	return not pcall(function()
		-- upvalues: (copy) p_u_132, (copy) v_u_133
		for _, v134 in utf8.codes(p_u_132) do
			local v135 = v_u_133
			local v136 = utf8.char
			table.insert(v135, v136(v134))
		end
	end) and {} or v_u_133
end
local function v_u_143(p138) -- name: cleanPrefix
	-- upvalues: (copy) v_u_137, (copy) v_u_9
	local v139 = {}
	local v140 = ""
	for v141, v142 in v_u_137(p138) do
		if v141 == 1 and v142:match("^[1-9]$") then
			v140 = v142
		else
			if not table.find(v_u_9.CONSONANTS, v142) or #v139 >= 3 then
				continue
			end
			table.insert(v139, v142)
		end
	end
	return v140 .. table.concat(v139)
end
local function v_u_145(p144) -- name: cleanNumber
	return p144:gsub("%D", ""):gsub("^0+", ""):sub(1, 4)
end
local v_u_146 = {}
local function v_u_149(p147) -- name: button
	-- upvalues: (copy) v_u_11, (copy) v_u_16
	local v148 = v_u_11.new("TextButton", {
		["Name"] = nil,
		["AutoButtonColor"] = true,
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["FontFace"] = nil,
		["TextColor3"] = nil,
		["TextSize"] = nil,
		["Text"] = nil,
		["Size"] = nil,
		["Position"] = nil,
		["Parent"] = nil,
		["Name"] = p147.name or "Button",
		["BackgroundColor3"] = p147.color or v_u_16,
		["FontFace"] = v_u_11.FONT_BOLD,
		["TextColor3"] = p147.textColor or v_u_11.TEXT,
		["TextSize"] = p147.textSize or 16,
		["Text"] = p147.text or "",
		["Size"] = p147.size,
		["Position"] = p147.position or UDim2.new(),
		["Parent"] = p147.parent
	})
	v_u_11.corner(v148, 6)
	return v148
end
local function v_u_154(p150, p151, p152, p153) -- name: label
	-- upvalues: (copy) v_u_11
	return v_u_11.text({
		["Text"] = nil,
		["FontFace"] = nil,
		["TextSize"] = 15,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["Size"] = nil,
		["Position"] = nil,
		["Parent"] = nil,
		["Text"] = p150,
		["FontFace"] = v_u_11.FONT_BOLD,
		["TextColor3"] = v_u_11.TEXT_DIM,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["Size"] = p153 or UDim2.fromOffset(200, 20),
		["Position"] = p151,
		["Parent"] = p152
	})
end
local function v_u_157(p155) -- name: textBox
	-- upvalues: (copy) v_u_11, (copy) v_u_9, (copy) v_u_146
	local v156 = v_u_11.new("TextBox", {
		["Name"] = nil,
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["ClearTextOnFocus"] = false,
		["FontFace"] = nil,
		["TextSize"] = nil,
		["TextColor3"] = nil,
		["PlaceholderText"] = nil,
		["PlaceholderColor3"] = nil,
		["Text"] = "",
		["Size"] = nil,
		["Position"] = nil,
		["Parent"] = nil,
		["Name"] = p155.name,
		["BackgroundColor3"] = v_u_11.LCD,
		["FontFace"] = v_u_9.FONT,
		["TextSize"] = p155.textSize or 22,
		["TextColor3"] = v_u_11.TEXT,
		["PlaceholderText"] = p155.placeholder or "",
		["PlaceholderColor3"] = v_u_11.TEXT_DIM,
		["Size"] = p155.size,
		["Position"] = p155.position,
		["Parent"] = p155.parent
	})
	v_u_11.corner(v156, 6)
	v_u_146[p155.name .. "Stroke"] = v_u_11.border(v156, v_u_11.BORDER, 0.6, 1.5)
	return v156
end
local function v_u_205() -- name: buildEditor
	-- upvalues: (copy) v_u_11, (copy) v_u_13, (copy) v_u_146, (copy) v_u_149, (copy) v_u_154, (copy) v_u_157, (copy) v_u_9, (copy) v_u_143, (copy) v_u_137, (copy) v_u_15, (copy) v_u_16, (copy) v_u_145
	local v158 = v_u_11.screen("PlateEditor", 16, v_u_13:WaitForChild("PlayerGui"))
	v158.Enabled = false
	v_u_146.gui = v158
	local v159 = v_u_11.new("Frame", {
		["Size"] = nil,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.55,
		["BorderSizePixel"] = 0,
		["Parent"] = nil,
		["Size"] = UDim2.fromScale(1, 1),
		["BackgroundColor3"] = Color3.new(0, 0, 0),
		["Parent"] = v158
	})
	local v160 = v_u_11.panel({
		["Name"] = "Panel",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.5),
		["Size"] = UDim2.fromOffset(860, 500),
		["Parent"] = v159
	})
	v_u_11.autoScale(v160)
	v_u_11.padding(v160, 16)
	v_u_146.title = v_u_11.text({
		["Text"] = "\224\184\155\224\185\137\224\184\178\224\184\162\224\184\151\224\184\176\224\185\128\224\184\154\224\184\181\224\184\162\224\184\153",
		["FontFace"] = nil,
		["TextSize"] = 22,
		["TextXAlignment"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["FontFace"] = v_u_11.FONT_BOLD,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["Size"] = UDim2.fromOffset(600, 30),
		["Parent"] = v160
	})
	v_u_149({
		["text"] = "\224\184\155\224\184\180\224\184\148",
		["size"] = nil,
		["position"] = nil,
		["parent"] = nil,
		["size"] = UDim2.fromOffset(70, 30),
		["position"] = UDim2.new(1, -70, 0, 0),
		["parent"] = v160
	}).MouseButton1Click:Connect(function()
		-- upvalues: (ref) v_u_146
		v_u_146.close()
	end)
	local v161 = v_u_11.new("Frame", {
		["Name"] = "Preview",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = Color3.fromRGB(18, 19, 21),
		["Position"] = UDim2.fromOffset(0, 40),
		["Size"] = UDim2.fromOffset(400, 176),
		["Parent"] = v160
	})
	v_u_11.corner(v161, 6)
	v_u_146.previewHolder = v_u_11.new("Frame", {
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["BackgroundTransparency"] = 1,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.5),
		["Parent"] = v161
	})
	v_u_154("\224\184\171\224\184\161\224\184\167\224\184\148", UDim2.fromOffset(0, 228), v160, UDim2.fromOffset(60, 34))
	v_u_146.prefix = v_u_157({
		["name"] = "Prefix",
		["placeholder"] = "1\224\184\129\224\184\130",
		["size"] = nil,
		["position"] = nil,
		["parent"] = nil,
		["size"] = UDim2.fromOffset(120, 34),
		["position"] = UDim2.fromOffset(56, 228),
		["parent"] = v160
	})
	v_u_154("\224\185\128\224\184\165\224\184\130", UDim2.fromOffset(196, 228), v160, UDim2.fromOffset(40, 34))
	v_u_146.number = v_u_157({
		["name"] = "Number",
		["placeholder"] = "1234",
		["size"] = nil,
		["position"] = nil,
		["parent"] = nil,
		["size"] = UDim2.fromOffset(120, 34),
		["position"] = UDim2.fromOffset(234, 228),
		["parent"] = v160
	})
	local v162 = v_u_149({
		["text"] = "\224\184\170\224\184\184\224\185\136\224\184\161",
		["size"] = nil,
		["position"] = nil,
		["parent"] = nil,
		["textSize"] = 14,
		["size"] = UDim2.fromOffset(42, 34),
		["position"] = UDim2.fromOffset(358, 228),
		["parent"] = v160
	})
	local v163 = v_u_11.new("Frame", {
		["Name"] = "Pad",
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Position"] = UDim2.fromOffset(0, 272),
		["Size"] = UDim2.fromOffset(400, 170),
		["Parent"] = v160
	})
	v_u_11.new("UIGridLayout", {
		["CellSize"] = UDim2.fromOffset(34, 30),
		["CellPadding"] = UDim2.fromOffset(2.6, 3),
		["SortOrder"] = Enum.SortOrder.LayoutOrder,
		["Parent"] = v163
	})
	for v164, v_u_165 in v_u_9.CONSONANTS do
		local v166 = v_u_149({
			["name"] = nil,
			["text"] = nil,
			["size"] = nil,
			["parent"] = nil,
			["textSize"] = 18,
			["name"] = "C" .. v164,
			["text"] = v_u_165,
			["size"] = UDim2.fromOffset(34, 30),
			["parent"] = v163
		})
		v166.FontFace = v_u_9.FONT
		v166.LayoutOrder = v164
		v166.MouseButton1Click:Connect(function()
			-- upvalues: (ref) v_u_146, (ref) v_u_143, (copy) v_u_165
			v_u_146.prefix.Text = v_u_143(v_u_146.prefix.Text .. v_u_165)
		end)
	end
	for v_u_167 = 1, 9 do
		local v168 = v_u_149({
			["name"] = "D" .. v_u_167,
			["text"] = tostring(v_u_167),
			["size"] = UDim2.fromOffset(34, 30),
			["parent"] = v163,
			["color"] = Color3.fromRGB(44, 62, 84)
		})
		v168.LayoutOrder = v_u_167 + 100
		v168.MouseButton1Click:Connect(function()
			-- upvalues: (ref) v_u_137, (ref) v_u_146, (ref) v_u_143, (copy) v_u_167
			local v169 = v_u_137(v_u_146.prefix.Text)
			if v169[1] and v169[1]:match("^%d$") then
				table.remove(v169, 1)
			end
			local v170 = v_u_167
			v_u_146.prefix.Text = v_u_143(tostring(v170) .. table.concat(v169))
		end)
	end
	local v171 = v_u_149({
		["name"] = "Back",
		["text"] = "\224\184\165\224\184\154",
		["size"] = nil,
		["parent"] = nil,
		["color"] = nil,
		["textSize"] = 14,
		["size"] = UDim2.fromOffset(34, 30),
		["parent"] = v163,
		["color"] = v_u_11.RED
	})
	v171.LayoutOrder = 200
	v171.MouseButton1Click:Connect(function()
		-- upvalues: (ref) v_u_137, (ref) v_u_146
		local v172 = v_u_137(v_u_146.prefix.Text)
		table.remove(v172)
		v_u_146.prefix.Text = table.concat(v172)
	end)
	local v173 = v_u_149({
		["name"] = "NoDigit",
		["text"] = "-",
		["size"] = nil,
		["parent"] = nil,
		["color"] = nil,
		["size"] = UDim2.fromOffset(34, 30),
		["parent"] = v163,
		["color"] = Color3.fromRGB(44, 62, 84)
	})
	v173.LayoutOrder = 199
	v173.MouseButton1Click:Connect(function()
		-- upvalues: (ref) v_u_137, (ref) v_u_146
		local v174 = v_u_137(v_u_146.prefix.Text)
		if v174[1] and v174[1]:match("^%d$") then
			table.remove(v174, 1)
		end
		v_u_146.prefix.Text = table.concat(v174)
	end)
	local v175 = v_u_11.new("Frame", {
		["Name"] = "Right",
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Position"] = UDim2.fromOffset(424, 40),
		["Size"] = UDim2.fromOffset(404, 428),
		["Parent"] = v160
	})
	v_u_154("\224\184\136\224\184\177\224\184\135\224\184\171\224\184\167\224\184\177\224\184\148 / \224\184\154\224\184\163\224\184\163\224\184\151\224\184\177\224\184\148\224\184\165\224\185\136\224\184\178\224\184\135", UDim2.fromOffset(0, 0), v175, UDim2.fromOffset(400, 20))
	v_u_146.provinceButton = v_u_149({
		["name"] = "Province",
		["text"] = "",
		["size"] = nil,
		["position"] = nil,
		["parent"] = nil,
		["textSize"] = 17,
		["size"] = UDim2.fromOffset(404, 34),
		["position"] = UDim2.fromOffset(0, 22),
		["parent"] = v175
	})
	v_u_146.provinceButton.FontFace = v_u_9.FONT
	v_u_146.custom = v_u_157({
		["name"] = "Custom",
		["placeholder"] = "\224\184\158\224\184\180\224\184\161\224\184\158\224\185\140\224\184\130\224\185\137\224\184\173\224\184\132\224\184\167\224\184\178\224\184\161\224\185\128\224\184\173\224\184\135 (\224\185\132\224\184\161\224\185\136\224\185\128\224\184\129\224\184\180\224\184\153 18 \224\184\149\224\184\177\224\184\167)",
		["size"] = nil,
		["position"] = nil,
		["parent"] = nil,
		["textSize"] = 18,
		["size"] = UDim2.fromOffset(404, 32),
		["position"] = UDim2.fromOffset(0, 60),
		["parent"] = v175
	})
	v_u_154("\224\185\129\224\184\154\224\184\154\224\184\155\224\185\137\224\184\178\224\184\162", UDim2.fromOffset(0, 98), v175)
	local v176 = v_u_11.new("ScrollingFrame", {
		["Name"] = "Themes",
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["CanvasSize"] = nil,
		["AutomaticCanvasSize"] = nil,
		["ScrollBarThickness"] = 5,
		["ScrollingDirection"] = nil,
		["Parent"] = nil,
		["Position"] = UDim2.fromOffset(0, 120),
		["Size"] = UDim2.fromOffset(404, 186),
		["CanvasSize"] = UDim2.new(),
		["AutomaticCanvasSize"] = Enum.AutomaticSize.Y,
		["ScrollingDirection"] = Enum.ScrollingDirection.Y,
		["Parent"] = v175
	})
	v_u_11.new("UIGridLayout", {
		["CellSize"] = UDim2.fromOffset(126, 58),
		["CellPadding"] = UDim2.fromOffset(6, 6),
		["SortOrder"] = Enum.SortOrder.LayoutOrder,
		["Parent"] = v176
	})
	v_u_11.padding(v176, 2)
	v_u_146.themeButtons = {}
	for v177, v_u_178 in v_u_9.THEMES do
		local v179 = v_u_11.new("TextButton", {
			["Name"] = nil,
			["Text"] = "",
			["AutoButtonColor"] = false,
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["LayoutOrder"] = nil,
			["Parent"] = nil,
			["Name"] = v_u_178.id,
			["BackgroundColor3"] = Color3.fromRGB(18, 19, 21),
			["LayoutOrder"] = v177,
			["Parent"] = v176
		})
		v_u_11.corner(v179, 5)
		local v180 = v_u_11.border(v179, v_u_15, 1, 2)
		local v181 = v_u_11.new("Frame", {
			["BackgroundTransparency"] = 1,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["Position"] = UDim2.fromOffset(4, 3),
			["Size"] = UDim2.new(1, -8, 1, -20),
			["Parent"] = v179
		})
		v_u_9.draw(v181, {
			["theme"] = nil,
			["frame"] = "None",
			["prefix"] = "\224\184\129\224\184\130",
			["number"] = "1234",
			["province"] = "\224\184\129\224\184\163\224\184\184\224\184\135\224\185\128\224\184\151\224\184\158\224\184\161\224\184\171\224\184\178\224\184\153\224\184\132\224\184\163",
			["theme"] = v_u_178.id
		}, "Car")
		v_u_11.text({
			["Text"] = nil,
			["TextSize"] = 11,
			["TextColor3"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["Text"] = v_u_178.th,
			["TextColor3"] = v_u_11.TEXT_DIM,
			["Position"] = UDim2.new(0, 0, 1, -16),
			["Size"] = UDim2.new(1, 0, 0, 14),
			["Parent"] = v179
		})
		v_u_146.themeButtons[v_u_178.id] = v180
		v179.MouseButton1Click:Connect(function()
			-- upvalues: (ref) v_u_146, (copy) v_u_178
			v_u_146.design.theme = v_u_178.id
			v_u_146.refresh()
		end)
	end
	v_u_154("\224\184\129\224\184\163\224\184\173\224\184\154\224\184\155\224\185\137\224\184\178\224\184\162", UDim2.fromOffset(0, 312), v175)
	v_u_146.frameButtons = {}
	for v182, v_u_183 in v_u_9.FRAMES do
		local v184 = v_u_149({
			["name"] = nil,
			["text"] = nil,
			["size"] = nil,
			["position"] = nil,
			["parent"] = nil,
			["textSize"] = 13,
			["name"] = v_u_183.id,
			["text"] = v_u_183.th,
			["size"] = UDim2.fromOffset(76, 30),
			["position"] = UDim2.fromOffset((v182 - 1) * 82, 334),
			["parent"] = v175
		})
		v_u_146.frameButtons[v_u_183.id] = v_u_11.border(v184, v_u_15, 1, 2)
		v184.MouseButton1Click:Connect(function()
			-- upvalues: (ref) v_u_146, (copy) v_u_183
			v_u_146.design.frame = v_u_183.id
			v_u_146.refresh()
		end)
	end
	v_u_146.message = v_u_11.text({
		["Text"] = "",
		["TextSize"] = 13,
		["TextColor3"] = nil,
		["TextWrapped"] = true,
		["TextXAlignment"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["TextColor3"] = Color3.fromRGB(255, 130, 120),
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["Position"] = UDim2.fromOffset(0, 374),
		["Size"] = UDim2.fromOffset(190, 48),
		["Parent"] = v175
	})
	v_u_149({
		["text"] = "\224\184\162\224\184\129\224\185\128\224\184\165\224\184\180\224\184\129",
		["size"] = nil,
		["position"] = nil,
		["parent"] = nil,
		["size"] = UDim2.fromOffset(84, 44),
		["position"] = UDim2.fromOffset(196, 378),
		["parent"] = v175
	}).MouseButton1Click:Connect(function()
		-- upvalues: (ref) v_u_146
		v_u_146.close()
	end)
	v_u_146.attach = v_u_149({
		["text"] = "\224\185\131\224\184\170\224\185\136\224\184\155\224\185\137\224\184\178\224\184\162",
		["size"] = nil,
		["position"] = nil,
		["parent"] = nil,
		["color"] = nil,
		["textSize"] = 18,
		["size"] = UDim2.fromOffset(116, 44),
		["position"] = UDim2.fromOffset(288, 378),
		["parent"] = v175,
		["color"] = v_u_11.GREEN
	})
	local v_u_185 = v_u_11.new("ScrollingFrame", {
		["Name"] = "Provinces",
		["Visible"] = false,
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["CanvasSize"] = nil,
		["AutomaticCanvasSize"] = nil,
		["ScrollBarThickness"] = 6,
		["ZIndex"] = 10,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_11.PANEL,
		["Position"] = UDim2.fromOffset(0, 58),
		["Size"] = UDim2.fromOffset(404, 300),
		["CanvasSize"] = UDim2.new(),
		["AutomaticCanvasSize"] = Enum.AutomaticSize.Y,
		["Parent"] = v175
	})
	v_u_11.corner(v_u_185, 6)
	v_u_11.border(v_u_185)
	v_u_11.new("UIListLayout", {
		["Padding"] = UDim.new(0, 2),
		["SortOrder"] = Enum.SortOrder.LayoutOrder,
		["Parent"] = v_u_185
	})
	v_u_11.padding(v_u_185, 4)
	v_u_146.list = v_u_185
	local v186 = { "" }
	for _, v187 in v_u_9.PROVINCES do
		table.insert(v186, v187)
	end
	for v188, v_u_189 in v186 do
		local v190 = v_u_149
		local v191 = {
			["text"] = nil,
			["size"] = nil,
			["parent"] = nil,
			["textSize"] = 16,
			["color"] = nil,
			["text"] = v_u_189 == "" and "\224\184\158\224\184\180\224\184\161\224\184\158\224\185\140\224\184\130\224\185\137\224\184\173\224\184\132\224\184\167\224\184\178\224\184\161\224\185\128\224\184\173\224\184\135..." or v_u_189,
			["size"] = UDim2.new(1, -8, 0, 30),
			["parent"] = v_u_185
		}
		local v192
		if v_u_189 == "" then
			v192 = Color3.fromRGB(44, 62, 84)
		else
			v192 = v_u_16
		end
		v191.color = v192
		local v193 = v190(v191)
		local v194
		if v_u_189 == "" then
			v194 = v_u_11.FONT_BOLD
		else
			v194 = v_u_9.FONT
		end
		v193.FontFace = v194
		v193.LayoutOrder = v188
		v193.ZIndex = 11
		v193.MouseButton1Click:Connect(function()
			-- upvalues: (copy) v_u_185, (copy) v_u_189, (ref) v_u_146
			v_u_185.Visible = false
			if v_u_189 == "" then
				v_u_146.customMode = true
				v_u_146.custom:CaptureFocus()
			else
				v_u_146.customMode = false
				v_u_146.design.province = v_u_189
			end
			v_u_146.refresh()
		end)
	end
	v_u_146.provinceButton.MouseButton1Click:Connect(function()
		-- upvalues: (copy) v_u_185
		v_u_185.Visible = not v_u_185.Visible
	end)
	local v_u_195 = v_u_146.prefix
	local v_u_196 = v_u_143
	local v_u_197 = "prefix"
	v_u_195:GetPropertyChangedSignal("Text"):Connect(function()
		-- upvalues: (copy) v_u_196, (copy) v_u_195, (ref) v_u_146, (copy) v_u_197
		local v198 = v_u_196(v_u_195.Text)
		if v198 == v_u_195.Text then
			v_u_146.design[v_u_197] = v198
			v_u_146.refresh()
		else
			v_u_195.Text = v198
		end
	end)
	local v_u_199 = v_u_146.number
	local v_u_200 = v_u_145
	local v_u_201 = "number"
	v_u_199:GetPropertyChangedSignal("Text"):Connect(function()
		-- upvalues: (copy) v_u_200, (copy) v_u_199, (ref) v_u_146, (copy) v_u_201
		local v202 = v_u_200(v_u_199.Text)
		if v202 == v_u_199.Text then
			v_u_146.design[v_u_201] = v202
			v_u_146.refresh()
		else
			v_u_199.Text = v202
		end
	end)
	v_u_146.custom:GetPropertyChangedSignal("Text"):Connect(function()
		-- upvalues: (ref) v_u_137, (ref) v_u_146, (ref) v_u_9
		local v203 = v_u_137(v_u_146.custom.Text)
		if #v203 > v_u_9.CUSTOM_MAX then
			v_u_146.custom.Text = table.concat(v203, "", 1, v_u_9.CUSTOM_MAX)
		elseif v_u_146.customMode then
			v_u_146.design.province = v_u_146.custom.Text
			v_u_146.refresh()
		end
	end)
	v162.MouseButton1Click:Connect(function()
		-- upvalues: (ref) v_u_9, (ref) v_u_146
		local v204 = v_u_9.randomDesign()
		v_u_146.prefix.Text = v204.prefix
		v_u_146.number.Text = v204.number
	end)
	v_u_146.attach.MouseButton1Click:Connect(function()
		-- upvalues: (ref) v_u_146
		v_u_146.submit()
	end)
end
function v_u_146.refresh() -- name: refresh
	-- upvalues: (copy) v_u_146, (copy) v_u_9, (copy) v_u_11
	local v206 = v_u_146.design
	local v207 = v_u_146.previewHolder
	v207:ClearAllChildren()
	local v208 = v_u_146.kind
	v207.Size = UDim2.fromOffset(330, 165)
	v_u_9.draw(v207, v206, v208)
	for v209, v210 in v_u_146.themeButtons do
		v210.Transparency = v209 == v206.theme and 0 or 1
	end
	for v211, v212 in v_u_146.frameButtons do
		v212.Transparency = v211 == v206.frame and 0 or 1
	end
	v_u_146.custom.Visible = v_u_146.customMode
	v_u_146.provinceButton.Text = v_u_146.customMode and "\224\184\130\224\185\137\224\184\173\224\184\132\224\184\167\224\184\178\224\184\161\224\184\130\224\184\173\224\184\135\224\184\137\224\184\177\224\184\153 (\224\185\128\224\184\155\224\184\165\224\184\181\224\185\136\224\184\162\224\184\153)" or v206.province .. "  \226\150\190"
	local v213 = v_u_146.PrefixStroke
	local v214
	if v_u_9.validPrefix(v206.prefix) then
		v214 = v_u_11.BORDER
	else
		v214 = v_u_11.RED
	end
	v213.Color = v214
	v_u_146.PrefixStroke.Transparency = v_u_9.validPrefix(v206.prefix) and 0.6 or 0
	local v215 = v_u_146.NumberStroke
	local v216
	if v_u_9.validNumber(v206.number) then
		v216 = v_u_11.BORDER
	else
		v216 = v_u_11.RED
	end
	v215.Color = v216
	v_u_146.NumberStroke.Transparency = v_u_9.validNumber(v206.number) and 0.6 or 0
	local _, v217 = v_u_9.check(v206)
	v_u_146.message.Text = v217 or (v_u_9.theme(v206.theme).image and "\224\185\129\224\184\154\224\184\154\224\184\153\224\184\181\224\185\137\224\184\161\224\184\181\224\184\149\224\184\177\224\184\167\224\185\128\224\184\165\224\184\130\224\184\158\224\184\180\224\184\161\224\184\158\224\185\140\224\184\161\224\184\178\224\185\131\224\184\153\224\184\163\224\184\185\224\184\155\224\185\129\224\184\165\224\185\137\224\184\167 (\224\184\171\224\184\161\224\184\167\224\184\148 / \224\185\128\224\184\165\224\184\130\224\184\151\224\184\181\224\185\136\224\184\158\224\184\180\224\184\161\224\184\158\224\185\140\224\184\136\224\184\176\224\185\132\224\184\161\224\185\136\224\185\129\224\184\170\224\184\148\224\184\135)" or "")
	v_u_146.attach.AutoButtonColor = v217 == nil
	local v218 = v_u_146.attach
	local v219
	if v217 then
		v219 = Color3.fromRGB(70, 74, 78)
	else
		v219 = v_u_11.GREEN
	end
	v218.BackgroundColor3 = v219
end
function v_u_146.close() -- name: close
	-- upvalues: (ref) v_u_73, (copy) v_u_146
	v_u_73 = false
	v_u_146.model = nil
	if v_u_146.gui then
		v_u_146.gui.Enabled = false
		v_u_146.list.Visible = false
	end
end
function v_u_146.submit() -- name: submit
	-- upvalues: (copy) v_u_146, (ref) v_u_74, (copy) v_u_9, (copy) v_u_2, (copy) v_u_14, (copy) v_u_12
	local v220 = v_u_146.model
	if v_u_74 or not v220 then
		return
	else
		local v221, v222 = v_u_9.check(v_u_146.design)
		if v221 then
			v_u_74 = true
			v_u_146.attach.Text = "..."
			local v223 = v_u_2.invoke
			local v224 = v_u_14
			local v225, v226, v227 = pcall(v223, v224, "Attach", v220, v221)
			v_u_74 = false
			v_u_146.attach.Text = "\224\185\131\224\184\170\224\185\136\224\184\155\224\185\137\224\184\178\224\184\162"
			if v225 and v226 then
				v_u_146.close()
				v_u_12.show(v227 or "\224\185\131\224\184\170\224\185\136\224\184\155\224\185\137\224\184\178\224\184\162\224\185\129\224\184\165\224\185\137\224\184\167", "ok")
			else
				v_u_146.message.Text = v225 and v227 and v227 or "\224\185\131\224\184\170\224\185\136\224\184\155\224\185\137\224\184\178\224\184\162\224\185\132\224\184\161\224\185\136\224\184\170\224\184\179\224\185\128\224\184\163\224\185\135\224\184\136 \224\184\165\224\184\173\224\184\135\224\184\173\224\184\181\224\184\129\224\184\132\224\184\163\224\184\177\224\185\137\224\184\135"
			end
		else
			v_u_146.message.Text = v222
			return
		end
	end
end
v_u_108 = function(p228)
	-- upvalues: (copy) v_u_146, (copy) v_u_205, (copy) v_u_17, (copy) v_u_9, (ref) v_u_73
	if not v_u_146.gui then
		v_u_205()
	end
	local v229 = v_u_17[p228]
	local v230 = "Car"
	if v229 then
		for v231 in v229.plates do
			v230 = v231:GetAttribute("PlateKind") or v230
		end
	end
	v_u_146.model = p228
	v_u_146.kind = v230
	v_u_146.design = v_u_9.design(p228)
	v_u_146.customMode = not v_u_9.isProvince(v_u_146.design.province)
	v_u_146.title.Text = "\224\184\155\224\185\137\224\184\178\224\184\162\224\184\151\224\184\176\224\185\128\224\184\154\224\184\181\224\184\162\224\184\153 \194\183 " .. (p228:GetAttribute("DisplayName") or p228:GetAttribute("BikeName") or (p228:GetAttribute("CarName") or ""))
	v_u_146.prefix.Text = v_u_146.design.prefix
	v_u_146.number.Text = v_u_146.design.number
	v_u_146.custom.Text = not v_u_146.customMode and "" or v_u_146.design.province
	v_u_146.message.Text = ""
	v_u_73 = true
	v_u_146.gui.Enabled = true
	v_u_146.refresh()
end
v6.Heartbeat:Connect(function()
	-- upvalues: (copy) v_u_146, (ref) v_u_73, (copy) v_u_13, (copy) v_u_9
	local v232 = v_u_146.model
	if v_u_73 and v232 then
		local v233 = v_u_13.Character
		if v233 then
			v233 = v_u_13.Character:FindFirstChild("HumanoidRootPart")
		end
		if v232.Parent and (v233 and (v232:GetPivot().Position - v233.Position).Magnitude <= v_u_9.CLICK_DISTANCE + 25) then
			if v232:GetAttribute("PlateOn") ~= false then
				v_u_146.close()
			end
		else
			v_u_146.close()
		end
	else
		return
	end
end)
v_u_7.InputBegan:Connect(function(p234)
	-- upvalues: (ref) v_u_73, (copy) v_u_146
	if v_u_73 and p234.KeyCode == Enum.KeyCode.Escape then
		v_u_146.close()
	end
end)