-- Path: ReplicatedStorage/RaceShared
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_14 = {
	["REMOTE"] = "Race",
	["EVENT"] = "RaceGo",
	["RADIUS"] = 80,
	["MAX_RACERS"] = 7,
	["LEAD"] = 1.2,
	["STEP"] = 1,
	["GO_TIME"] = 1.4,
	["COOLDOWN"] = 8,
	["phase"] = function(p1) -- name: phase
		-- upvalues: (copy) v_u_14
		if p1 < 0 then
			return nil
		else
			return p1 < v_u_14.STEP and "3" or (p1 < 2 * v_u_14.STEP and "2" or (p1 < 3 * v_u_14.STEP and "1" or (p1 < 3 * v_u_14.STEP + v_u_14.GO_TIME and "GO!" or nil)))
		end
	end,
	["nearby"] = function(p2, p3, p4, p5) -- name: nearby
		-- upvalues: (copy) v_u_14
		local v6 = {}
		for _, v7 in p2 do
			if v7 == p4 then
				continue
			end
			local v8 = v7.Character
			local v9
			if v8 then
				v9 = v8:FindFirstChild("HumanoidRootPart")
			else
				v9 = v8
			end
			if v8 then
				v8 = v8:FindFirstChildOfClass("Humanoid")
			end
			if not v9 or (not v8 or v8.Health <= 0) then
				continue
			end
			local v10 = (v9.Position - p3).Magnitude
			if v10 > v_u_14.RADIUS then
				continue
			end
			local v11 = {
				["player"] = v7,
				["distance"] = v10,
				["riding"] = v8.SeatPart ~= nil
			}
			table.insert(v6, v11)
		end
		table.sort(v6, function(p12, p13)
			if p12.riding == p13.riding then
				return p12.distance < p13.distance
			else
				return p12.riding
			end
		end)
		while p5 < #v6 do
			table.remove(v6)
		end
		return v6
	end
}
return v_u_14