-- Path: StarterPlayer/PlayerModule/ServerAuthority/ServerAuthorityClient
-- Class: Script  false/Enum.RunContext.Client
-- Decompiled by BALL KUN Universal Map Dump

require(script.Parent):Initialize()