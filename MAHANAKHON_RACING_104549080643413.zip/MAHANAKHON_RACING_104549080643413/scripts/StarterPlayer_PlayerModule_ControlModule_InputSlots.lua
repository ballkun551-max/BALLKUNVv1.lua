-- Path: StarterPlayer/PlayerModule/ControlModule/InputSlots
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v1 = require(script.Parent.Parent:WaitForChild("CommonUtils")).get("FlagUtil")
local v_u_2 = game:GetService("StarterPlayer")
local v3 = game:GetService("Players")
local v_u_4 = game:GetService("RunService")
UserSettings():GetService("UserGameSettings")
local v_u_5 = game:GetService("UserInputService")
local v_u_6 = require(script.Parent:WaitForChild("InputReplication"))
local v_u_7 = require(script.Parent:WaitForChild("AvatarAbilitiesInterface")).get(v3.LocalPlayer)
local v_u_8 = v1.getUserFlag("UserPlayerScriptsPlayerControlState2") or v1.getUserFlag("UserPlayerScriptsPlayerControlState2GA")
local v_u_9 = v1.getUserFlag("UserAbilitiesUserInterfaceB")
local v_u_10 = v1.getUserFlag("UserPSUseBindToAnimation")
local v_u_11 = v_u_9 and "ControlState" or "PlayerControlState"
local v_u_12 = {}
v_u_12.__index = v_u_12
local v_u_13 = {}
local v_u_14 = {}
local v_u_15 = {}
local v_u_16 = 0
local v_u_17 = {}
local v_u_18 = {}
local v_u_19 = {}
local v_u_20 = Instance.new("BindableEvent")
local v_u_21 = 0
local v_u_22 = Instance.new("BindableEvent")
local v_u_23 = { "ButtonAssetId", "ButtonPressedAssetId", "ButtonInvalidAssetId" }
local function v_u_35() -- name: updateAbilityActionMetadata
	-- upvalues: (copy) v_u_17, (copy) v_u_13, (copy) v_u_7, (copy) v_u_23, (copy) v_u_18
	for v24 = 1, 11 do
		local v25 = v_u_17[v24]
		if not v25 then
			continue
		end
		local v26 = v_u_13[v24]
		local v_u_27
		if v26 == nil then
			v_u_27 = false
		else
			v_u_27 = v26 ~= ""
		end
		local v_u_28 = not v_u_27 and "" or v26
		local v_u_29
		if v_u_27 then
			v_u_29 = v_u_7:GetAbilityConfig(v26)
		else
			v_u_29 = nil
		end
		local function v33(p30) -- name: updateAction
			-- upvalues: (copy) v_u_27, (copy) v_u_28, (ref) v_u_23, (copy) v_u_29
			p30.Enabled = v_u_27
			p30.DisplayName = v_u_28
			for _, v31 in v_u_23 do
				local v32
				if v_u_29 then
					v32 = v_u_29[v31]
				else
					v32 = nil
				end
				p30:SetAttribute(v31, type(v32) ~= "string" and "" or v32)
			end
		end
		v33(v25)
		local v34 = v_u_18[v24]
		if not v34 or v34 == v25 then
			continue
		end
		v33(v34)
	end
end
function v_u_12.GetNumAbilitySlots() -- name: GetNumAbilitySlots
	return 11
end
function v_u_12.GetNumOverflowSlots() -- name: GetNumOverflowSlots
	return 3
end
function v_u_12.getOverflowScrollIndex() -- name: getOverflowScrollIndex
	-- upvalues: (ref) v_u_21
	return v_u_21
end
function v_u_12.setOverflowScrollIndex(p36) -- name: setOverflowScrollIndex
	-- upvalues: (ref) v_u_21, (ref) v_u_14, (copy) v_u_22
	local v37 = v_u_21
	local v38 = #v_u_14 - 3
	local v39 = math.min(v38, p36)
	v_u_21 = math.max(0, v39)
	if v_u_21 ~= v37 then
		v_u_22:Fire()
	end
end
function v_u_12.getScrollIndexChangedEvent() -- name: getScrollIndexChangedEvent
	-- upvalues: (copy) v_u_22
	return v_u_22.Event
end
function v_u_12.setupSlotActions(p_u_40, p_u_41, p42) -- name: setupSlotActions
	-- upvalues: (copy) v_u_8, (copy) v_u_10, (copy) v_u_4, (copy) v_u_7, (copy) v_u_6, (copy) v_u_13, (ref) v_u_14, (copy) v_u_5, (copy) v_u_2, (copy) v_u_15, (ref) v_u_16, (copy) v_u_12, (copy) v_u_35, (copy) v_u_20, (copy) v_u_9, (copy) v_u_11, (copy) v_u_17, (copy) v_u_18, (copy) v_u_19, (ref) v_u_21
	local function v_u_46(p43) -- name: getAbilityAction
		-- upvalues: (ref) v_u_8, (ref) p_u_41, (copy) p_u_40
		if p43 then
			local v44
			if v_u_8 and not p_u_41 then
				v44 = script.Parent.Parent:FindFirstChild("InputContexts")
			else
				v44 = p_u_40:FindFirstChild("InputContexts")
			end
			if v44 then
				local v45 = v44:FindFirstChild("CharacterContext")
				if v45 then
					return v45:FindFirstChild(p43 .. "Action")
				else
					return nil
				end
			else
				return nil
			end
		else
			return nil
		end
	end
	if not v_u_8 then
		if v_u_10 then
			v_u_4:BindToAnimation(function(_)
				-- upvalues: (ref) v_u_7, (ref) v_u_6, (copy) p_u_40
				if v_u_7:isEnabled() then
					v_u_6.FireCustomInputs(p_u_40)
					v_u_6.SendInputToCCLCharacter(p_u_40)
				end
			end, Enum.StepFrequency.Hz60)
		else
			v_u_4:BindToSimulation(function(_)
				-- upvalues: (ref) v_u_7, (ref) v_u_6, (copy) p_u_40
				if v_u_7:isEnabled() then
					v_u_6.FireCustomInputs(p_u_40)
					v_u_6.SendInputToCCLCharacter(p_u_40)
				end
			end, Enum.StepFrequency.Hz60)
		end
	end
	local v_u_47 = {}
	local function v99() -- name: updateSlotMap
		-- upvalues: (ref) v_u_13, (ref) v_u_14, (ref) v_u_7, (ref) v_u_5, (ref) v_u_2, (copy) v_u_47, (ref) v_u_15, (ref) v_u_16, (ref) v_u_12, (ref) v_u_35, (ref) v_u_20
		local v48 = table.clone(v_u_13)
		local v49 = table.clone(v_u_14)
		local v50 = v_u_7:GetAbilities()
		local v51 = v_u_5.PreferredInput == Enum.PreferredInput.Touch and 7 or 11
		for v52, v53 in v_u_13 do
			for v56, v55 in v50 do
				if v55 ~= v53 then
					continue
				end
			end
			local v56 = nil
			if v56 and v51 >= v52 then
				break
			end
			v_u_13[v52] = nil
		end
		v_u_14 = {}
		local v57 = {}
		for _, v58 in v50 do
			for v61, v60 in v_u_13 do
				if v60 ~= v58 then
					continue
				end
			end
			local v61 = nil
			if v61 then
				break
			end
			table.insert(v57, v58)
		end
		local v62 = v_u_2:FindFirstChild("AbilitySlotConflictFifo")
		local v63 = v62 ~= nil and v62:IsA("BoolValue")
		if v63 then
			v63 = v62.Value
		end
		for _, v64 in v57 do
			local v65 = v_u_7:GetAbilityConfig(v64)
			if not v65 then
				continue
			end
			local v66 = v65.Slot
			local v67 = tonumber(v66)
			if v67 <= 0 then
				continue
			end
			local v68 = v_u_13[v67]
			for v71, v70 in v48 do
				if v70 ~= v64 then
					continue
				end
			end
			local v71 = nil
			local v72 = not v71
			if v72 then
				v72 = not table.find(v49, v64)
			end
			if v67 <= v51 and not v68 then
				v_u_13[v67] = v64
			elseif v67 <= v51 and (v63 and v72) then
				local v73 = v_u_14
				table.insert(v73, v68)
				v_u_13[v67] = v64
			else
				local v74 = v_u_14
				table.insert(v74, v64)
			end
		end
		for _, v75 in v57 do
			local v76 = v_u_7:GetAbilityConfig(v75)
			if not v76 then
				continue
			end
			local v77 = v76.Slot
			if tonumber(v77) ~= 0 then
				continue
			end
			local v78 = v_u_47[v75]
			if v78 then
				if v78 <= v51 and not v_u_13[v78] then
					v_u_13[v78] = v75
				else
					local v79 = v_u_14
					table.insert(v79, v75)
				end
			else
				local v80 = -1
				for v81 = 1, v51 do
					if v_u_13[v81] then
						continue
					end
					v80 = v81
				end
				if v80 == -1 then
					local v82 = v_u_14
					table.insert(v82, v75)
				else
					v_u_13[v80] = v75
					v_u_47[v75] = v80
				end
			end
		end
		local v83 = {}
		for _, v84 in v_u_14 do
			v83[v84] = true
			if v_u_15[v84] ~= nil then
				continue
			end
			v_u_16 = v_u_16 + 1
			v_u_15[v84] = v_u_16
		end
		for v85 in v_u_15 do
			if v83[v85] then
				continue
			end
			v_u_15[v85] = nil
		end
		table.sort(v_u_14, function(p86, p87)
			-- upvalues: (ref) v_u_15
			return v_u_15[p86] < v_u_15[p87]
		end)
		local v88 = v_u_14
		local v89
		if v88 == v49 then
			v89 = true
		else
			for v90, v91 in v88 do
				if v49[v90] == v91 then
					continue
				end
				v89 = false
			end
			for v92, _ in v49 do
				if v88[v92] ~= nil then
					continue
				end
				v89 = false
			end
			v89 = true
		end
		local v93 = not v89
		if v93 then
			v_u_12.setOverflowScrollIndex(#v_u_14 - 3)
		else
			v_u_12.setOverflowScrollIndex(v_u_12.getOverflowScrollIndex())
		end
		local v94 = v_u_13
		local v95
		if v94 == v48 then
			v95 = true
		else
			for v96, v97 in v94 do
				if v48[v96] == v97 then
					continue
				end
				v95 = false
			end
			for v98, _ in v48 do
				if v94[v98] ~= nil then
					continue
				end
				v95 = false
			end
			v95 = true
		end
		if not v95 or v93 then
			v_u_35()
			v_u_20:Fire()
		end
	end
	v_u_7:GetAbilitiesChangedSignal():Connect(v99)
	v_u_5:GetPropertyChangedSignal("PreferredInput"):Connect(v99)
	v99()
	local function v_u_105(p100, p101, p102) -- name: UpdateAbilityInPCS
		-- upvalues: (ref) v_u_9, (ref) v_u_11
		local v103 = p100.Character
		if v103 then
			local v104
			if v_u_9 then
				v104 = v103:FindFirstChildOfClass(v_u_11)
			else
				v104 = v103:FindFirstChild(v_u_11)
			end
			if v104 then
				v104:UpdateFields({
					[p101] = p102
				})
			end
		else
			return
		end
	end
	local v_u_106 = {}
	local v_u_107 = {}
	local v_u_108 = {}
	local v_u_109 = 0
	local function v_u_139() -- name: resolveAndWireActions
		-- upvalues: (ref) v_u_109, (copy) v_u_108, (ref) v_u_8, (ref) p_u_41, (copy) p_u_40, (ref) v_u_17, (ref) v_u_18, (copy) v_u_106, (ref) v_u_13, (copy) v_u_105, (copy) v_u_46, (ref) v_u_35, (ref) v_u_19, (copy) v_u_107, (ref) v_u_14, (ref) v_u_21, (ref) v_u_20
		v_u_109 = v_u_109 + 1
		local v110 = v_u_109
		for _, v111 in v_u_108 do
			v111:Disconnect()
		end
		table.clear(v_u_108)
		local v112
		if v_u_8 and not p_u_41 then
			v112 = script.Parent.Parent:WaitForChild("InputContexts", (1 / 0))
		else
			v112 = p_u_40:WaitForChild("InputContexts", (1 / 0))
		end
		local v113 = v112:WaitForChild("CharacterContext")
		if v110 == v_u_109 then
			local v114 = script.Parent.Parent:FindFirstChild("InputContexts")
			if v114 then
				v114 = v114:FindFirstChild("CharacterContext")
			end
			for v_u_115 = 1, 11 do
				local v116 = v113:WaitForChild("AbilityAction" .. tostring(v_u_115))
				if v110 ~= v_u_109 then
					return
				end
				v_u_17[v_u_115] = v116
				local v117 = v_u_18
				local v118
				if v114 then
					v118 = v114:FindFirstChild("AbilityAction" .. tostring(v_u_115))
				else
					v118 = nil
				end
				v117[v_u_115] = v118
				local v119 = v_u_108
				local v120 = v116.StateChanged
				local function v128(p121)
					-- upvalues: (ref) v_u_106, (copy) v_u_115, (ref) v_u_13, (ref) v_u_8, (ref) v_u_105, (ref) p_u_40, (ref) v_u_46
					local v122 = v_u_106
					local v123 = v_u_115
					local v124 = v_u_13[v_u_115]
					if p121 then
						v122[v123] = v124
					else
						local v125 = v122[v123]
						v122[v123] = nil
						if v125 ~= nil then
							v124 = v125
						end
					end
					if v_u_8 then
						if v124 ~= nil and v124 ~= "" then
							v_u_105(p_u_40, v124, p121)
							return
						end
					else
						local v126 = v_u_46(v124)
						local v127 = v126 and v126:FindFirstChild("ScriptableBinding")
						if v127 then
							v127:Fire(p121)
						end
					end
				end
				table.insert(v119, v120:Connect(v128))
			end
			v_u_35()
			if v_u_8 then
				for v_u_129 = 1, 3 do
					local v130 = v113:WaitForChild("OverflowAction" .. tostring(v_u_129))
					if v110 ~= v_u_109 then
						return
					end
					v_u_19[v_u_129] = v130
					local v131 = v_u_108
					local v132 = v130.StateChanged
					local function v138(p133)
						-- upvalues: (ref) v_u_107, (copy) v_u_129, (ref) v_u_14, (ref) v_u_21, (ref) v_u_105, (ref) p_u_40
						local v134 = v_u_107
						local v135 = v_u_129
						local v136 = v_u_14[v_u_129 + v_u_21]
						if p133 then
							v134[v135] = v136
						else
							local v137 = v134[v135]
							v134[v135] = nil
							if v137 ~= nil then
								v136 = v137
							end
						end
						if v136 ~= nil and v136 ~= "" then
							v_u_105(p_u_40, v136, p133)
						end
					end
					table.insert(v131, v132:Connect(v138))
				end
			end
			v_u_20:Fire()
		end
	end
	task.spawn(v_u_139)
	if p42 then
		p42:subscribe("SERVER_AUTHORITY_CHANGED"):Connect(function(p140)
			-- upvalues: (ref) p_u_41, (copy) v_u_139
			if p140 ~= p_u_41 then
				p_u_41 = p140
				task.spawn(v_u_139)
			end
		end)
	end
end
function v_u_12.GetSlotMapChangedSignal() -- name: GetSlotMapChangedSignal
	-- upvalues: (copy) v_u_20
	return v_u_20.Event
end
function v_u_12.GetSlotMap() -- name: GetSlotMap
	-- upvalues: (copy) v_u_13
	return v_u_13
end
function v_u_12.GetAbilitiesInOverflow() -- name: GetAbilitiesInOverflow
	-- upvalues: (ref) v_u_14
	return v_u_14
end
function v_u_12.GetActionInSlot(p141) -- name: GetActionInSlot
	-- upvalues: (copy) v_u_17
	return v_u_17[p141]
end
function v_u_12.GetOverflowAction(p142) -- name: GetOverflowAction
	-- upvalues: (copy) v_u_19
	return v_u_19[p142]
end
return v_u_12