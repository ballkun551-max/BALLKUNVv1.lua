-- Path: Players/ygggggg55551/PlayerScripts/ShardMark
-- Class: LocalScript  true/Enum.RunContext.Legacy
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("Lighting")
local v3 = v_u_1:WaitForChild(require(v_u_1:WaitForChild("GameShared")).REMOTES):WaitForChild("Shard", 60)
if v3 then
	v3.OnClientEvent:Connect(function(p_u_4) -- name: stamp
		-- upvalues: (copy) v_u_1, (copy) v_u_2
		if type(p_u_4) == "string" and #p_u_4 <= 64 then
			local function v7()
				-- upvalues: (copy) p_u_4, (ref) v_u_1, (ref) v_u_2
				local v5 = workspace:FindFirstChild("Map")
				if v5 then
					v5:SetAttribute("ShardKey", p_u_4)
				end
				local v6 = v_u_1:FindFirstChild("GameUI")
				if v6 then
					v6:SetAttribute("Build", p_u_4)
				end
				v_u_2:SetAttribute("Grade", p_u_4)
				workspace.Terrain:SetAttribute("Seed", p_u_4)
				v_u_1:SetAttribute("Region", p_u_4)
			end
			pcall(v7)
		end
	end)
end