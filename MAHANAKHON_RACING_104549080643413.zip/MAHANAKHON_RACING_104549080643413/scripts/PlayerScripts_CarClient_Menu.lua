-- Path: Players/ygggggg55551/PlayerScripts/CarClient/Menu
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = require(game:GetService("ReplicatedStorage"):WaitForChild("NetSeal"))
local v_u_2 = game:GetService("CollectionService")
local v_u_3 = game:GetService("Players")
local v_u_4 = game:GetService("ProximityPromptService")
local v_u_5 = game:GetService("ReplicatedStorage")
local v_u_6 = game:GetService("RunService")
local v_u_7 = require(v_u_5:WaitForChild("CarShared"))
local v8 = {}
local v_u_9 = false
local function v_u_12(p10) -- name: carOf
	-- upvalues: (copy) v_u_7
	local v11 = p10.Parent
	while v11 and not (v11:IsA("Model") and v11:HasTag(v_u_7.TAG)) do
		v11 = v11.Parent
	end
	return v11
end
local v_u_13 = require(game:GetService("ReplicatedStorage"):WaitForChild("DriveAccess"))
local function v_u_26() -- name: refreshPrompts
	-- upvalues: (copy) v_u_3, (copy) v_u_2, (copy) v_u_7, (ref) v_u_9, (copy) v_u_13
	local v14 = v_u_3.LocalPlayer.Character
	if v14 then
		v14 = v14:FindFirstChild("HumanoidRootPart")
	end
	for _, v15 in v_u_2:GetTagged(v_u_7.TAG) do
		local v16 = v15:GetAttribute("CarWashBusy") == true
		local v17 = {}
		local v18 = (1 / 0)
		local v19 = nil
		for _, v20 in v15:GetDescendants() do
			if not (v20:IsA("ProximityPrompt") and v20:GetAttribute("CarPrompt")) then
				continue
			end
			table.insert(v17, v20)
			local v21 = v15:FindFirstChild(v20:GetAttribute("SeatName") or "")
			local v22
			if v21 == nil then
				v22 = false
			else
				v22 = v21.Occupant == nil
			end
			if v_u_9 or (v16 or (not v22 or v21:IsA("VehicleSeat") and not v_u_13.mayDriveNow(v_u_3.LocalPlayer, v15))) then
				continue
			end
			local v23
			if v20.Parent:IsA("Attachment") then
				v23 = v20.Parent.WorldPosition
			elseif v20.Parent:IsA("BasePart") then
				v23 = v20.Parent.Position
			else
				v23 = nil
			end
			local v24 = not (v14 and v23) and 0 or (v14.Position - v23).Magnitude
			if v24 >= v18 then
				continue
			end
			v19 = v20
			v18 = v24
		end
		for _, v25 in v17 do
			v25.Enabled = v25 == v19
		end
	end
end
function v8.close() -- name: close end
function v8.setSeated(p27) -- name: setSeated
	-- upvalues: (ref) v_u_9, (copy) v_u_26
	v_u_9 = p27
	v_u_26()
end
function v8.start() -- name: start
	-- upvalues: (copy) v_u_4, (copy) v_u_3, (ref) v_u_9, (copy) v_u_12, (copy) v_u_5, (copy) v_u_7, (copy) v_u_1, (copy) v_u_6, (copy) v_u_26
	v_u_4.PromptTriggered:Connect(function(p28, p29)
		-- upvalues: (ref) v_u_3, (ref) v_u_9, (ref) v_u_12, (ref) v_u_5, (ref) v_u_7, (ref) v_u_1
		if p29 == v_u_3.LocalPlayer and (p28:GetAttribute("CarPrompt") and not v_u_9) then
			local v30 = v_u_12(p28)
			local v31
			if v30 then
				v31 = v30:FindFirstChild(p28:GetAttribute("SeatName") or "")
			else
				v31 = v30
			end
			local v32 = v_u_5:FindFirstChild(v_u_7.REMOTE_NAME)
			if v31 and v32 then
				v_u_1.fire(v32, "Enter", v30, v31:IsA("VehicleSeat") and "Driver" or "Passenger", v31.Name)
			end
		end
	end)
	local v_u_33 = 0
	v_u_6.Heartbeat:Connect(function()
		-- upvalues: (ref) v_u_33, (ref) v_u_26
		if os.clock() - v_u_33 > 0.1 then
			v_u_33 = os.clock()
			v_u_26()
		end
	end)
end
return v8