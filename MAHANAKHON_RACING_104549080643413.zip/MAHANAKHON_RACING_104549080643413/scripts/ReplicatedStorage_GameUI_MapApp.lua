-- Path: ReplicatedStorage/GameUI/MapApp
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v1 = game:GetService("Players")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = require(v2:WaitForChild("MapPlaces"))
local v_u_5 = require(v2:WaitForChild("RouteArrows"))
local v_u_6 = require(v2:WaitForChild("DeliveryShared"))
local v_u_7 = require(script.Parent:WaitForChild("Theme"))
local v_u_8 = require(script.Parent:WaitForChild("Icons"))
local v_u_9 = require(script.Parent:WaitForChild("Toast"))
local v_u_10 = require(script.Parent:WaitForChild("NavMap"))
local v11 = {}
local v_u_12 = Color3.new(1, 1, 1)
local v_u_13 = Color3.fromRGB(28, 30, 36)
local v_u_14 = Color3.fromRGB(112, 116, 128)
local v_u_15 = Color3.fromRGB(243, 244, 247)
local v_u_16 = Color3.fromRGB(32, 196, 168)
local v_u_17 = Color3.fromRGB(24, 112, 226)
local v_u_18 = Color3.fromRGB(30, 132, 255)
local v_u_19 = Color3.fromRGB(232, 64, 64)
local v_u_20 = Color3.fromRGB(40, 190, 240)
local v_u_21 = TweenInfo.new(0.3, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
local v_u_22 = {
	{
		["id"] = "all",
		["th"] = "\224\184\151\224\184\177\224\185\137\224\184\135\224\184\171\224\184\161\224\184\148"
	},
	{
		["id"] = "fix",
		["th"] = "\224\184\173\224\184\185\224\185\136"
	},
	{
		["id"] = "gas",
		["th"] = "\224\184\155\224\184\177\224\185\138\224\184\161"
	},
	{
		["id"] = "hill",
		["th"] = "\224\184\160\224\184\185\224\185\128\224\184\130\224\184\178"
	},
	{
		["id"] = "bridge",
		["th"] = "\224\184\170\224\184\176\224\184\158\224\184\178\224\184\153"
	},
	{
		["id"] = "work",
		["th"] = "\224\184\135\224\184\178\224\184\153"
	}
}
local v_u_23 = {
	["fix"] = "\224\184\173\224\184\185\224\185\136\224\184\163\224\184\150",
	["gas"] = "\224\184\155\224\184\177\224\185\138\224\184\161\224\184\153\224\185\137\224\184\179\224\184\161\224\184\177\224\184\153",
	["hill"] = "\224\184\160\224\184\185\224\185\128\224\184\130\224\184\178",
	["bridge"] = "\224\184\170\224\184\176\224\184\158\224\184\178\224\184\153",
	["work"] = "\224\184\151\224\184\181\224\185\136\224\184\151\224\184\179\224\184\135\224\184\178\224\184\153",
	["dam"] = "\224\185\128\224\184\130\224\184\183\224\185\136\224\184\173\224\184\153"
}
local v_u_24 = v1.LocalPlayer
local function v_u_42(p25, p26, p27, p28, p29, p30, p31, p32, p33, p34) -- name: label
	-- upvalues: (copy) v_u_7
	local v35 = v_u_7.text
	local v36 = {
		["Text"] = p26
	}
	local v37
	if p33 then
		v37 = v_u_7.FONT_BOLD
	else
		v37 = v_u_7.FONT
	end
	v36.FontFace = v37
	v36.TextSize = p31
	v36.TextColor3 = p32
	v36.TextXAlignment = Enum.TextXAlignment.Left
	v36.TextTruncate = Enum.TextTruncate.AtEnd
	v36.Position = UDim2.new(0, p27, 0, p28)
	local v38
	if p29 then
		v38 = UDim2.fromOffset(p29, p30)
	else
		v38 = UDim2.new(1, -p27 - 8, 0, p30)
	end
	v36.Size = v38
	v36.Parent = p25
	local v39 = v35(v36)
	for v40, v41 in p34 or {} do
		v39[v40] = v41
	end
	return v39
end
local function v_u_46(p43) -- name: pressable
	-- upvalues: (copy) v_u_7, (copy) v_u_3
	local v_u_44 = v_u_7.new("UIScale", {
		["Parent"] = p43
	})
	p43.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_3, (copy) v_u_44
		v_u_3:Create(v_u_44, TweenInfo.new(0.1), {
			["Scale"] = 0.93
		}):Play()
	end)
	for _, v45 in { p43.MouseButton1Up, p43.MouseLeave } do
		v45:Connect(function()
			-- upvalues: (ref) v_u_3, (copy) v_u_44
			v_u_3:Create(v_u_44, TweenInfo.new(0.1), {
				["Scale"] = 1
			}):Play()
		end)
	end
end
local function v_u_59(p47, p48, p49, p50, p51, p52) -- name: emojiBadge
	-- upvalues: (copy) v_u_12, (copy) v_u_7
	local v53 = {
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_12,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromOffset(p51, p52),
		["Size"] = UDim2.fromOffset(p50, p50),
		["Parent"] = p47
	}
	local v54 = v_u_7.new("Frame", v53)
	v_u_7.corner(v54, p50 / 2)
	local v55 = {
		["ApplyStrokeMode"] = nil,
		["Color"] = nil,
		["Thickness"] = 2.5,
		["Parent"] = nil,
		["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
		["Color"] = p49,
		["Parent"] = v54
	}
	v_u_7.new("UIStroke", v55)
	local v56 = v_u_7.text
	local v57 = {
		["Text"] = p48
	}
	local v58 = p50 * 0.52
	v57.TextSize = math.floor(v58)
	v57.Size = UDim2.fromScale(1, 1)
	v57.Parent = v54
	v56(v57)
	return v54
end
function v11.build(p60, p_u_61, p_u_62, p63) -- name: build
	-- upvalues: (copy) v_u_15, (copy) v_u_7, (copy) v_u_12, (copy) v_u_16, (copy) v_u_17, (copy) v_u_8, (copy) v_u_42, (copy) v_u_20, (copy) v_u_14, (copy) v_u_13, (copy) v_u_18, (copy) v_u_46, (copy) v_u_19, (copy) v_u_10, (copy) v_u_5, (copy) v_u_23, (copy) v_u_9, (copy) v_u_22, (copy) v_u_4, (copy) v_u_59, (copy) v_u_6, (copy) v_u_24, (copy) v_u_3, (copy) v_u_21
	local v64 = p63.X
	local _ = p63.Y
	local v65 = {}
	local v66 = {
		["Name"] = "MapApp",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["Visible"] = false,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_15,
		["Size"] = UDim2.fromScale(1, 1),
		["Parent"] = p60
	}
	local v_u_67 = v_u_7.new("Frame", v66)
	local v_u_68 = v_u_7.new("UIScale", {
		["Parent"] = v_u_67
	})
	v65.frame = v_u_67
	local v69 = {
		["Name"] = "Header",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_12,
		["Size"] = UDim2.new(1, 0, 0, 92),
		["Parent"] = v_u_67
	}
	local v70 = v_u_7.new("Frame", v69)
	local v71 = {
		["Rotation"] = 25,
		["Color"] = nil,
		["Parent"] = nil,
		["Color"] = ColorSequence.new(v_u_16, v_u_17),
		["Parent"] = v70
	}
	v_u_7.new("UIGradient", v71)
	local v72 = {
		["Name"] = "Back",
		["Text"] = "",
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Position"] = UDim2.fromOffset(4, 42),
		["Size"] = UDim2.fromOffset(30, 44),
		["Parent"] = v70
	}
	local v73 = v_u_7.new("TextButton", v72)
	local v74 = v_u_8.make("arrow", v_u_12, 20)
	v74.AnchorPoint = Vector2.new(0.5, 0.5)
	v74.Position = UDim2.fromScale(0.5, 0.5)
	v74.Parent = v73
	v73.Activated:Connect(function()
		-- upvalues: (copy) p_u_61
		p_u_61()
	end)
	v_u_42(v70, "Map", 38, 40, nil, 26, 22, v_u_12, true)
	v_u_42(v70, "\224\185\128\224\184\165\224\184\183\224\184\173\224\184\129\224\184\151\224\184\181\224\185\136\224\184\151\224\184\181\224\185\136\224\184\136\224\184\176\224\185\132\224\184\155 \224\185\129\224\184\165\224\185\137\224\184\167\224\184\130\224\184\177\224\184\154\224\184\149\224\184\178\224\184\161\224\184\165\224\184\185\224\184\129\224\184\168\224\184\163\224\184\154\224\184\153\224\184\150\224\184\153\224\184\153", 38, 66, nil, 16, 12, v_u_12, false, {
		["TextTransparency"] = 0.08
	})
	local v75 = {
		["Name"] = "Going",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["Visible"] = false,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_12,
		["Position"] = UDim2.fromOffset(14, 102),
		["Size"] = UDim2.new(1, -28, 0, 92),
		["Parent"] = v_u_67
	}
	local v_u_76 = v_u_7.new("Frame", v75)
	v_u_7.corner(v_u_76, 14)
	local v77 = {
		["ApplyStrokeMode"] = nil,
		["Color"] = nil,
		["Thickness"] = 2,
		["Parent"] = nil,
		["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
		["Color"] = v_u_20,
		["Parent"] = v_u_76
	}
	v_u_7.new("UIStroke", v77)
	local v_u_78 = nil
	v_u_42(v_u_76, "\224\184\129\224\184\179\224\184\165\224\184\177\224\184\135\224\184\153\224\184\179\224\184\151\224\184\178\224\184\135\224\185\132\224\184\155", 58, 8, nil, 16, 12, v_u_14, true)
	local v_u_79 = v_u_42(v_u_76, "", 58, 24, nil, 20, 16, v_u_13, true)
	local v_u_80 = v_u_42(v_u_76, "", 0, 9, nil, 16, 13, v_u_18, true, {
		["TextXAlignment"] = Enum.TextXAlignment.Right,
		["Size"] = UDim2.new(1, -12, 0, 16)
	})
	local v81 = (v64 - 28 - 24 - 8) / 2
	local v82 = {
		["Name"] = "Map",
		["Text"] = "",
		["AutoButtonColor"] = false,
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_12,
		["Position"] = UDim2.fromOffset(12, 52),
		["Size"] = UDim2.fromOffset(v81, 32),
		["Parent"] = v_u_76
	}
	local v83 = v_u_7.new("TextButton", v82)
	v_u_7.corner(v83, 16)
	local v84 = {
		["Rotation"] = 90,
		["Color"] = nil,
		["Parent"] = nil,
		["Color"] = ColorSequence.new(Color3.fromRGB(70, 160, 255), Color3.fromRGB(18, 108, 232)),
		["Parent"] = v83
	}
	v_u_7.new("UIGradient", v84)
	v_u_42(v83, "\224\185\129\224\184\156\224\184\153\224\184\151\224\184\181\224\185\136", 0, 0, nil, 32, 14, v_u_12, true, {
		["TextXAlignment"] = Enum.TextXAlignment.Center,
		["Size"] = UDim2.fromScale(1, 1)
	})
	v_u_46(v83)
	local v85 = {
		["Name"] = "Cancel",
		["Text"] = "",
		["AutoButtonColor"] = false,
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_12,
		["Position"] = UDim2.fromOffset(12 + v81 + 8, 52),
		["Size"] = UDim2.fromOffset(v81, 32),
		["Parent"] = v_u_76
	}
	local v86 = v_u_7.new("TextButton", v85)
	v_u_7.corner(v86, 16)
	local v87 = {
		["ApplyStrokeMode"] = nil,
		["Color"] = nil,
		["Thickness"] = 1.5,
		["Parent"] = nil,
		["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
		["Color"] = v_u_19,
		["Parent"] = v86
	}
	v_u_7.new("UIStroke", v87)
	v_u_42(v86, "\224\184\162\224\184\129\224\185\128\224\184\165\224\184\180\224\184\129", 0, 0, nil, 32, 14, v_u_19, true, {
		["TextXAlignment"] = Enum.TextXAlignment.Center,
		["Size"] = UDim2.fromScale(1, 1)
	})
	v_u_46(v86)
	local v88 = {
		["Name"] = "Tabs",
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Position"] = UDim2.fromOffset(14, 102),
		["Size"] = UDim2.new(1, -28, 0, 32),
		["Parent"] = v_u_67
	}
	local v_u_89 = v_u_7.new("Frame", v88)
	local v90 = {
		["FillDirection"] = Enum.FillDirection.Horizontal,
		["Padding"] = UDim.new(0, 4),
		["SortOrder"] = Enum.SortOrder.LayoutOrder,
		["Parent"] = v_u_89
	}
	v_u_7.new("UIListLayout", v90)
	local v_u_91 = {}
	local v_u_92 = "all"
	local v93 = {
		["Name"] = "List",
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["CanvasSize"] = nil,
		["AutomaticCanvasSize"] = nil,
		["ScrollBarThickness"] = 3,
		["ScrollBarImageColor3"] = nil,
		["ScrollingDirection"] = nil,
		["Parent"] = nil,
		["Position"] = UDim2.fromOffset(0, 144),
		["Size"] = UDim2.new(1, 0, 1, -170),
		["CanvasSize"] = UDim2.new(),
		["AutomaticCanvasSize"] = Enum.AutomaticSize.Y,
		["ScrollBarImageColor3"] = v_u_14,
		["ScrollingDirection"] = Enum.ScrollingDirection.Y,
		["Parent"] = v_u_67
	}
	local v_u_94 = v_u_7.new("ScrollingFrame", v93)
	local v95 = {
		["Padding"] = UDim.new(0, 8),
		["SortOrder"] = Enum.SortOrder.LayoutOrder,
		["Parent"] = v_u_94
	}
	v_u_7.new("UIListLayout", v95)
	local v96 = {
		["PaddingLeft"] = UDim.new(0, 14),
		["PaddingRight"] = UDim.new(0, 14),
		["PaddingTop"] = UDim.new(0, 2),
		["PaddingBottom"] = UDim.new(0, 8),
		["Parent"] = v_u_94
	}
	v_u_7.new("UIPadding", v96)
	local v_u_97 = false
	local v_u_98 = false
	local v_u_100 = v_u_10.new(v_u_67, p63, function()
		-- upvalues: (ref) v_u_98, (ref) v_u_97, (copy) p_u_62
		local v99 = v_u_98 and v_u_97
		if v99 then
			v99 = p_u_62()
		end
		return v99
	end, {
		["length"] = v_u_5.length
	})
	local v_u_101 = nil
	local v_u_102 = {}
	local v_u_103 = nil
	local function v104() -- name: openNav
		-- upvalues: (ref) v_u_101, (ref) v_u_97, (copy) v_u_100
		if v_u_101 then
			v_u_97 = true
			v_u_100.show(true)
		end
	end
	local function v_u_109(p105) -- name: go
		-- upvalues: (ref) v_u_101, (ref) v_u_5, (copy) v_u_100, (ref) v_u_23, (ref) v_u_20, (ref) v_u_9, (ref) v_u_103, (ref) v_u_97
		v_u_101 = p105
		local v106 = p105.x
		local v107 = p105.z
		local v108 = Vector3.new(v106, 0, v107)
		v_u_5.set(v108, p105.th)
		v_u_100.setTarget(v108, {
			["verb"] = "\224\185\132\224\184\155\224\184\151\224\184\181\224\185\136",
			["who"] = nil,
			["where"] = nil,
			["color"] = nil,
			["pinText"] = "\226\152\133",
			["who"] = p105.th,
			["where"] = v_u_23[p105.go] or "",
			["color"] = v_u_20
		})
		v_u_9.show(("\224\184\153\224\184\179\224\184\151\224\184\178\224\184\135\224\185\132\224\184\155 %s: \224\184\130\224\184\177\224\184\154\224\184\149\224\184\178\224\184\161\224\184\165\224\184\185\224\184\129\224\184\168\224\184\163\224\184\154\224\184\153\224\184\150\224\184\153\224\184\153"):format(p105.th), "info")
		v_u_103()
		if v_u_101 then
			v_u_97 = true
			v_u_100.show(true)
		end
	end
	local function v110() -- name: stop
		-- upvalues: (ref) v_u_101, (ref) v_u_5, (copy) v_u_100, (ref) v_u_97, (ref) v_u_103
		v_u_101 = nil
		v_u_5.set(nil)
		v_u_100.setTarget(nil)
		v_u_97 = false
		v_u_100.hide(true)
		v_u_103()
	end
	local v_u_111 = v_u_98
	local v_u_112 = v_u_97
	local v_u_113 = v_u_101
	local v_u_114 = v_u_103
	for v115, v_u_116 in v_u_22 do
		local v117 = {
			["Name"] = nil,
			["Text"] = "",
			["AutoButtonColor"] = false,
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["LayoutOrder"] = nil,
			["Parent"] = nil,
			["Name"] = v_u_116.id,
			["BackgroundColor3"] = v_u_12,
			["Size"] = UDim2.fromOffset(0, 32),
			["AutomaticSize"] = Enum.AutomaticSize.X,
			["LayoutOrder"] = v115,
			["Parent"] = v_u_89
		}
		local v118 = v_u_7.new("TextButton", v117)
		v_u_7.corner(v118, 16)
		local v119 = {
			["ApplyStrokeMode"] = nil,
			["Color"] = nil,
			["Thickness"] = 1,
			["Parent"] = nil,
			["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
			["Color"] = Color3.fromRGB(220, 223, 230),
			["Parent"] = v118
		}
		local v120 = v_u_7.new("UIStroke", v119)
		local v121 = {
			["PaddingLeft"] = UDim.new(0, 8),
			["PaddingRight"] = UDim.new(0, 8),
			["Parent"] = v118
		}
		v_u_7.new("UIPadding", v121)
		local v122 = {
			["chip"] = v118,
			["caption"] = v_u_7.text({
				["Text"] = nil,
				["FontFace"] = nil,
				["TextSize"] = 13,
				["TextColor3"] = nil,
				["Size"] = nil,
				["AutomaticSize"] = nil,
				["Parent"] = nil,
				["Text"] = v_u_116.th,
				["FontFace"] = v_u_7.FONT_BOLD,
				["TextColor3"] = v_u_14,
				["Size"] = UDim2.fromScale(0, 1),
				["AutomaticSize"] = Enum.AutomaticSize.X,
				["Parent"] = v118
			}),
			["stroke"] = v120
		}
		v_u_91[v_u_116.id] = v122
		v118.Activated:Connect(function()
			-- upvalues: (ref) v_u_92, (copy) v_u_116, (ref) v_u_114
			v_u_92 = v_u_116.id
			v_u_114()
		end)
	end
	for _, v_u_123 in v_u_4 do
		if not v_u_123.go then
			continue
		end
		local v124 = {
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["Parent"] = nil,
			["BackgroundColor3"] = v_u_12,
			["Size"] = UDim2.new(1, 0, 0, 66),
			["Parent"] = v_u_94
		}
		local v125 = v_u_7.new("Frame", v124)
		v_u_7.corner(v125, 14)
		v_u_59(v125, v_u_123.icon, v_u_123.color, 42, 32, 33)
		v_u_42(v125, v_u_123.th, 62, 12, v64 - 28 - 62 - 94, 20, 15, v_u_13, true)
		local v126 = v_u_42(v125, "", 62, 35, v64 - 28 - 62 - 94, 18, 12, v_u_14, false)
		local v127 = {
			["Name"] = "Go",
			["Text"] = "",
			["AutoButtonColor"] = false,
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["BackgroundColor3"] = v_u_12,
			["AnchorPoint"] = Vector2.new(1, 0.5),
			["Position"] = UDim2.new(1, -10, 0.5, 0),
			["Size"] = UDim2.fromOffset(80, 38),
			["Parent"] = v125
		}
		local v128 = v_u_7.new("TextButton", v127)
		v_u_7.corner(v128, 19)
		local v129 = v_u_7.new("UIGradient", {
			["Rotation"] = 90,
			["Parent"] = nil,
			["Parent"] = v128
		})
		local v130 = {
			["ApplyStrokeMode"] = nil,
			["Thickness"] = 1.5,
			["Parent"] = nil,
			["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
			["Parent"] = v128
		}
		local v131 = v_u_7.new("UIStroke", v130)
		local v132 = v_u_42(v128, "", 0, 0, nil, 38, 13, v_u_12, true, {
			["TextXAlignment"] = Enum.TextXAlignment.Center,
			["Size"] = UDim2.fromScale(1, 1)
		})
		v_u_46(v128)
		v128.Activated:Connect(function()
			-- upvalues: (ref) v_u_113, (copy) v_u_123, (ref) v_u_112, (copy) v_u_100, (copy) v_u_109
			if v_u_113 == v_u_123 then
				if v_u_113 then
					v_u_112 = true
					v_u_100.show(true)
				end
			else
				v_u_109(v_u_123)
				return
			end
		end)
		table.insert(v_u_102, {
			["place"] = v_u_123,
			["frame"] = v125,
			["sub"] = v126,
			["fill"] = v129,
			["stroke"] = v131,
			["caption"] = v132
		})
	end
	v_u_103 = function() -- name: refresh
		-- upvalues: (copy) v_u_91, (ref) v_u_92, (ref) v_u_13, (ref) v_u_12, (ref) v_u_14, (copy) v_u_76, (ref) v_u_113, (copy) v_u_89, (copy) v_u_94, (ref) v_u_78, (ref) v_u_59, (copy) v_u_79, (ref) v_u_5, (copy) v_u_80, (ref) v_u_6, (ref) v_u_24, (copy) v_u_102, (ref) v_u_23, (ref) v_u_20
		for v133, v134 in v_u_91 do
			local v135 = v133 == v_u_92
			local v136 = v134.chip
			local v137
			if v135 then
				v137 = v_u_13
			else
				v137 = v_u_12
			end
			v136.BackgroundColor3 = v137
			local v138 = v134.caption
			local v139
			if v135 then
				v139 = v_u_12
			else
				v139 = v_u_14
			end
			v138.TextColor3 = v139
			v134.stroke.Transparency = v135 and 1 or 0
		end
		v_u_76.Visible = v_u_113 ~= nil
		local v140 = (v_u_113 and 102 or 0) + 102
		v_u_89.Position = UDim2.fromOffset(14, v140)
		v_u_94.Position = UDim2.fromOffset(0, v140 + 32 + 10)
		v_u_94.Size = UDim2.new(1, 0, 1, -(v140 + 32 + 10 + 26))
		if v_u_113 then
			if v_u_78 then
				v_u_78:Destroy()
			end
			v_u_78 = v_u_59(v_u_76, v_u_113.icon, v_u_113.color, 38, 30, 28)
			v_u_79.Text = v_u_113.th
			local v141 = v_u_5.length()
			v_u_80.Text = not v141 and "" or v_u_6.distanceText(v141)
		end
		local v142 = v_u_24.Character
		if v142 then
			v142 = v_u_24.Character:FindFirstChild("HumanoidRootPart")
		end
		local v143 = {}
		for _, v144 in v_u_102 do
			local v145
			if v142 then
				local v146 = v142.Position
				local v147 = v144.place.x
				local v148 = v144.place.z
				v145 = Vector2.new(v146.X - v147, v146.Z - v148).Magnitude
			else
				v145 = 0
			end
			v144.far = v145
			table.insert(v143, v144)
		end
		table.sort(v143, function(p149, p150)
			return p149.far < p150.far
		end)
		for v151, v152 in v143 do
			v152.frame.LayoutOrder = v151
			v152.frame.Visible = v_u_92 == "all" and true or v152.place.go == v_u_92
			v152.sub.Text = ("%s \194\183 \224\184\171\224\185\136\224\184\178\224\184\135 %s"):format(v_u_23[v152.place.go] or "", v_u_6.distanceText(v152.far))
			if v_u_113 == v152.place then
				v152.fill.Color = ColorSequence.new(v_u_12, v_u_12)
				v152.stroke.Color = v_u_20
				v152.stroke.Transparency = 0
				v152.caption.Text = "\224\184\129\224\184\179\224\184\165\224\184\177\224\184\135\224\185\132\224\184\155 \226\156\147"
				v152.caption.TextColor3 = v_u_20:Lerp(v_u_13, 0.3)
			else
				v152.fill.Color = ColorSequence.new(Color3.fromRGB(255, 214, 90), Color3.fromRGB(244, 150, 20))
				v152.stroke.Transparency = 1
				v152.caption.Text = "\224\185\132\224\184\155\224\184\151\224\184\181\224\185\136\224\184\153\224\184\181\224\185\136"
				v152.caption.TextColor3 = Color3.fromRGB(40, 28, 8)
			end
		end
	end
	v83.Activated:Connect(v104)
	v86.Activated:Connect(v110)
	v_u_100.dismissed.Event:Connect(function()
		-- upvalues: (ref) v_u_112, (copy) v_u_100
		v_u_112 = false
		v_u_100.hide(true)
	end)
	v_u_5.arrived.Event:Connect(function(p153)
		-- upvalues: (ref) v_u_113, (copy) v_u_100, (ref) v_u_112, (ref) v_u_9, (ref) v_u_103
		v_u_113 = nil
		v_u_100.setTarget(nil)
		v_u_112 = false
		v_u_100.hide(true)
		v_u_9.show(("\224\184\150\224\184\182\224\184\135\224\185\129\224\184\165\224\185\137\224\184\167: %s"):format(p153 or ""), "ok")
		v_u_103()
	end)
	function v65.show() -- name: show
		-- upvalues: (ref) v_u_111, (copy) v_u_67, (ref) v_u_103, (copy) v_u_68, (ref) v_u_3, (ref) v_u_21, (ref) v_u_113, (ref) v_u_112, (copy) v_u_100
		v_u_111 = true
		v_u_67.Visible = true
		v_u_103()
		v_u_68.Scale = 0.92
		v_u_3:Create(v_u_68, v_u_21, {
			["Scale"] = 1
		}):Play()
		if v_u_113 then
			if not v_u_113 then
				return
			end
			v_u_112 = true
			v_u_100.show(true)
		end
	end
	function v65.hide() -- name: hide
		-- upvalues: (ref) v_u_111, (copy) v_u_67
		v_u_111 = false
		v_u_67.Visible = false
	end
	function v65.isShown() -- name: isShown
		-- upvalues: (ref) v_u_111
		return v_u_111
	end
	task.spawn(function()
		-- upvalues: (copy) v_u_67, (ref) v_u_111, (ref) v_u_103
		while v_u_67.Parent do
			task.wait(1)
			if not v_u_111 then
				continue
			end
			v_u_103()
		end
	end)
	v_u_103()
	return v65
end
return v11