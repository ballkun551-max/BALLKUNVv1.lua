-- Path: ReplicatedStorage/RoadGraph
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v1 = require(script.Parent:WaitForChild("MapRoads"))
local v2 = v1.NODES
local v_u_3 = {}
local v_u_4 = {}
local v_u_5 = {}
local v6 = {}
for v7 = 1, #v2, 2 do
	local v8 = Vector2.new
	local v9 = v2[v7]
	local v10 = v2[v7 + 1]
	table.insert(v_u_3, v8(v9, v10))
	v_u_4[#v_u_3] = {}
end
local v11 = v1.EDGES
for v12 = 1, #v11, 3 do
	local v13 = v11[v12]
	local v14 = v11[v12 + 1]
	local v15 = v11[v12 + 2]
	if not v1.KINDS[v15].gps then
		continue
	end
	local v16 = (v_u_3[v13] - v_u_3[v14]).Magnitude
	table.insert(v_u_5, {
		["a"] = v13,
		["b"] = v14,
		["len"] = v16
	})
	local v17 = v_u_4[v13]
	table.insert(v17, { v14, v16 })
	local v18 = v_u_4[v14]
	table.insert(v18, { v13, v16 })
end
v6.nodes = v_u_3
v6.edges = v_u_5
local function v_u_20(p19) -- name: flat
	return Vector2.new(p19.X, p19.Z)
end
local function v_u_35(p21) -- name: snap
	-- upvalues: (copy) v_u_5, (copy) v_u_3
	local v22 = nil
	local v23 = nil
	local v24 = nil
	local v25 = nil
	for _, v26 in v_u_5 do
		local v27 = v_u_3[v26.a]
		local v28 = v_u_3[v26.b] - v27
		local v29 = (p21 - v27):Dot(v28)
		local v30 = v28:Dot(v28)
		local v31 = v29 / math.max(v30, 1e-6)
		local v32 = math.clamp(v31, 0, 1)
		local v33 = v27 + v28 * v32
		local v34 = (v33 - p21).Magnitude
		if v22 and v34 >= v22 then
			continue
		end
		v25 = v32
		v24 = v26
		v23 = v33
		v22 = v34
	end
	return v23, v24, v25, v22
end
function v6.nearest(p36) -- name: nearest
	-- upvalues: (copy) v_u_35, (copy) v_u_20
	local v37, _, _, v38 = v_u_35(v_u_20(p36))
	return v37, v38
end
local function v_u_45(p39, p40) -- name: push
	table.insert(p39, p40)
	local v41 = #p39
	while v41 > 1 do
		local v42 = v41 // 2
		if p39[v42][1] <= p39[v41][1] then
			break
		end
		local v43 = p39[v41]
		local v44 = p39[v42]
		p39[v42] = v43
		p39[v41] = v44
		v41 = v42
	end
end
local function v_u_54(p46) -- name: pop
	local v47 = p46[1]
	local v48 = table.remove(p46)
	if #p46 > 0 then
		p46[1] = v48
		local v49 = 1
		while true do
			local v50
			if true then
				local v51 = v49 * 2
				v50 = v49 * 2 + 1
				if p46[v51] then
					if p46[v51][1] >= p46[v49][1] then
						v51 = v49
					end
				else
					v51 = v49
				end
			end
			if p46[v50] then
				if p46[v50][1] >= p46[v51][1] then
					v50 = v51
				end
			else
				v50 = v51
			end
			if v50 == v49 then
				break
			end
			local v52 = p46[v49]
			local v53 = p46[v50]
			p46[v50] = v52
			p46[v49] = v53
			v49 = v50
		end
	end
	return v47
end
function v6.route(p55, p56) -- name: route
	-- upvalues: (copy) v_u_35, (copy) v_u_3, (copy) v_u_45, (copy) v_u_54, (copy) v_u_4
	local v_u_57 = Vector2.new(p55.X, p55.Z)
	local v_u_58 = Vector2.new(p56.X, p56.Z)
	local v_u_59, v60, v61 = v_u_35(v_u_57)
	local v_u_62, v63, v64 = v_u_35(v_u_58)
	if not (v_u_59 and v_u_62) then
		return { v_u_57, v_u_58 }, (v_u_58 - v_u_57).Magnitude
	end
	local function v65() -- name: straight
		-- upvalues: (copy) v_u_57, (copy) v_u_59, (copy) v_u_62, (copy) v_u_58
		return {
			v_u_57,
			v_u_59,
			v_u_62,
			v_u_58
		}, (v_u_59 - v_u_57).Magnitude + (v_u_62 - v_u_59).Magnitude + (v_u_58 - v_u_62).Magnitude
	end
	if v60 == v63 then
		return v65()
	end
	local v66 = { 0 }
	local v67 = {}
	local v68 = {}
	for _, v69 in {
		{ v60.a, v60.len * v61 },
		{ v60.b, v60.len * (1 - v61) }
	} do
		local v70 = v69[1]
		local v71 = v69[2]
		if v66[v70] and v71 >= v66[v70] then
			continue
		end
		v66[v70] = v71
		v67[v70] = 0
		v_u_45(v68, { v71 + (v_u_3[v70] - v_u_62).Magnitude, v70 })
	end
	local v72 = {
		[v63.a] = v63.len * v64,
		[v63.b] = v63.len * (1 - v64)
	}
	local v73 = (1 / 0)
	local v74 = nil
	while #v68 > 0 do
		local v75 = v_u_54(v68)
		local v76 = v75[2]
		local v77 = v66[v76]
		if v75[1] - (v_u_3[v76] - v_u_62).Magnitude > v77 + 1e-6 then
			continue
		end
		if v73 <= v75[1] then
			break
		end
		if v72[v76] and v77 + v72[v76] < v73 then
			v73 = v77 + v72[v76]
			v74 = v76
		end
		for _, v78 in v_u_4[v76] do
			local v79 = v78[1]
			local v80 = v77 + v78[2]
			if v66[v79] and v80 >= v66[v79] then
				continue
			end
			v66[v79] = v80
			v67[v79] = v76
			v_u_45(v68, { v80 + (v_u_3[v79] - v_u_62).Magnitude, v79 })
		end
	end
	if not v74 then
		return v65()
	end
	local v81 = {}
	while v74 and v74 ~= 0 do
		local v82 = v_u_3[v74]
		table.insert(v81, 1, v82)
		v74 = v67[v74]
	end
	local v83 = { v_u_57, v_u_59 }
	for _, v84 in v81 do
		table.insert(v83, v84)
	end
	table.insert(v83, v_u_62)
	table.insert(v83, v_u_58)
	local v85 = 0
	for v86 = 2, #v83 do
		v85 = v85 + (v83[v86] - v83[v86 - 1]).Magnitude
	end
	return v83, v85
end
function v6.reachable() -- name: reachable
	-- upvalues: (copy) v_u_4, (copy) v_u_3
	local v87 = { 1 }
	local v88 = 0
	local v89 = { true }
	while #v87 > 0 do
		local v90 = table.remove(v87)
		v88 = v88 + 1
		for _, v91 in v_u_4[v90] do
			if v89[v91[1]] then
				continue
			end
			v89[v91[1]] = true
			local v92 = v91[1]
			table.insert(v87, v92)
		end
	end
	local v93 = 0
	for v94 in v_u_3 do
		if #v_u_4[v94] <= 0 then
			continue
		end
		v93 = v93 + 1
	end
	return v88, v93
end
return v6