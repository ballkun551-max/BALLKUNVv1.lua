-- Path: ReplicatedStorage/NpcLooks
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = {
	["SKINS"] = {
		Color3.fromRGB(234, 192, 160),
		Color3.fromRGB(222, 176, 138),
		Color3.fromRGB(204, 150, 112),
		Color3.fromRGB(176, 124, 90),
		Color3.fromRGB(242, 206, 178)
	},
	["HAIR_MEN"] = {
		7193401217,
		9243992729,
		9244021842,
		3814450142,
		398672920,
		9174353649
	},
	["HAIR_WOMEN"] = {
		7193442167,
		6993754725,
		9244111257,
		9244089488,
		7193454569
	},
	["SHIRTS"] = {
		257926853,
		18204225288,
		5825106221,
		10305813257,
		139637579996070,
		1039292284,
		415680454,
		14542273245,
		10095878000,
		8990493825,
		13733439379,
		4959260131,
		6650794522
	},
	["PANTS"] = {
		7322526269,
		10878429510,
		1645628769,
		125870001776408,
		90681449456848,
		11995095258,
		7527076277,
		8318933906
	},
	["PANTS_WOMEN"] = { 9201810748, 6792462303, 5968381025 },
	["GLASSES"] = { 17377068146 },
	["GLASSES_CHANCE"] = 0.15
}
local v2 = {
	["Grab"] = {
		["shirt"] = 10305813257,
		["pants"] = 7322526269,
		["shirtTemplate"] = "rbxassetid://119040154283305",
		["pantsTemplate"] = "rbxassetid://74733419079963"
	},
	["Delivery"] = {
		["shirt"] = 8080388380,
		["pants"] = 7322526269,
		["hat"] = 7097890336,
		["glasses"] = 17377068146,
		["shirtTemplate"] = "rbxassetid://87894760304110",
		["pantsTemplate"] = "rbxassetid://122779018192990"
	},
	["Courier"] = {
		["shirt"] = 415680454,
		["pants"] = 1645628769,
		["hat"] = 3210191970,
		["hair"] = 7193401217,
		["shirtTemplate"] = "rbxassetid://99253362998098",
		["pantsTemplate"] = "rbxassetid://128418015307055"
	},
	["Mechanic"] = {
		["shirt"] = 107724574563566,
		["pants"] = 14559405338,
		["hair"] = 3814450142,
		["shirtTemplate"] = "rbxassetid://109958693317912",
		["pantsTemplate"] = "rbxassetid://117204089288106"
	},
	["Builder"] = {
		["shirt"] = 6013492651,
		["pants"] = 10878429510,
		["hat"] = 115631525084200,
		["glasses"] = 17377068146,
		["shirtTemplate"] = "rbxassetid://70974014277477",
		["pantsTemplate"] = "rbxassetid://83207245268165"
	},
	["IceCream"] = {
		["shirt"] = 257926853,
		["pants"] = 7322526269,
		["shirtTemplate"] = "rbxassetid://128677662590716",
		["pantsTemplate"] = "rbxassetid://125426057576359"
	},
	["Citizen"] = {
		["shirt"] = 257926853,
		["pants"] = 7322526269,
		["hair"] = 9243992729,
		["glasses"] = 17377068146
	},
	["CarWash"] = {
		["shirt"] = 10305813257,
		["pants"] = 7322526269,
		["hat"] = 3210191970,
		["shirtTemplate"] = "rbxassetid://116613500847549",
		["pantsTemplate"] = "rbxassetid://89625532092063",
		["cap"] = true,
		["capLogo"] = "rbxassetid://108211945026753",
		["capColor"] = nil,
		["capColor"] = Color3.fromRGB(24, 74, 196)
	}
}
v_u_1.JOBS = v2
function v_u_1.random(p3) -- name: random
	-- upvalues: (copy) v_u_1
	local v4 = p3 or Random.new()
	local v5 = v4:NextNumber() < 0.45
	local v6 = {}
	local v7 = v_u_1.SKINS
	v6.skin = v7[v4:NextInteger(1, #v7)]
	local v8 = v_u_1.SHIRTS
	v6.shirt = v8[v4:NextInteger(1, #v8)]
	local v9
	if v5 then
		v9 = v_u_1.HAIR_WOMEN
	else
		v9 = v_u_1.HAIR_MEN
	end
	v6.hair = v9[v4:NextInteger(1, #v9)]
	local v10
	if v5 and v4:NextNumber() < 0.5 then
		local v11 = v_u_1.PANTS_WOMEN
		v10 = v11[v4:NextInteger(1, #v11)]
	else
		local v12 = v_u_1.PANTS
		v10 = v12[v4:NextInteger(1, #v12)]
	end
	v6.pants = v10
	if v4:NextNumber() < v_u_1.GLASSES_CHANCE then
		local v13 = v_u_1.GLASSES
		v6.glasses = v13[v4:NextInteger(1, #v13)]
	end
	return v6
end
function v_u_1.apply(p14, p15) -- name: apply
	if p15.skin then
		local v16 = p15.skin
		p14.HeadColor = v16
		p14.TorsoColor = v16
		p14.LeftArmColor = v16
		p14.RightArmColor = v16
		p14.LeftLegColor = v16
		p14.RightLegColor = v16
	end
	p14.Shirt = p15.shirt or 0
	p14.Pants = p15.pants or 0
	local v17
	if p15.hair then
		local v18 = p15.hair
		v17 = tostring(v18)
	else
		v17 = ""
	end
	p14.HairAccessory = v17
	local v19
	if p15.hat then
		local v20 = p15.hat
		v19 = tostring(v20)
	else
		v19 = ""
	end
	p14.HatAccessory = v19
	local v21
	if p15.glasses then
		local v22 = p15.glasses
		v21 = tostring(v22)
	else
		v21 = ""
	end
	p14.FaceAccessory = v21
	return p14
end
return v_u_1