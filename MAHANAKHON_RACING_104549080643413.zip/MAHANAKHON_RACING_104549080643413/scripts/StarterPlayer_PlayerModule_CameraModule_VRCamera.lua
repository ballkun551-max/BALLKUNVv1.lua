-- Path: StarterPlayer/PlayerModule/CameraModule/VRCamera
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("VRService")
require(script.Parent:WaitForChild("CameraInput"))
require(script.Parent:WaitForChild("CameraUtils"))
local v_u_3 = require(script.Parent:WaitForChild("VRCameraTeleportDetector"))
local v4 = require(script.Parent.Parent:WaitForChild("CommonUtils")).get("FlagUtil")
local v_u_5 = v4.getUserFlag("UserVRRecenterOnExternalTeleport")
local v_u_6 = v4.getUserFlag("UserVRSkipOcclusionInFirstPerson")
local v_u_7 = v4.getUserFlag("UserFixVRImmersionAutoRotate")
local v_u_8 = require(script.Parent:WaitForChild("VRBaseCamera"))
local v_u_9 = setmetatable({}, v_u_8)
v_u_9.__index = v_u_9
function v_u_9.new() -- name: new
	-- upvalues: (copy) v_u_8, (copy) v_u_9
	local v10 = v_u_8.new()
	local v11 = v_u_9
	local v12 = setmetatable(v10, v11)
	v12.lastUpdate = tick()
	v12.focusOffset = CFrame.new()
	v12:Reset()
	v12.controlModule = require(script.Parent.Parent:WaitForChild("ControlModule"))
	v12.savedAutoRotate = true
	v12.autoRotateOverridden = false
	return v12
end
function v_u_9.Reset(p13) -- name: Reset
	-- upvalues: (copy) v_u_8
	p13.needsReset = true
	p13.needsBlackout = true
	p13.motionDetTime = 0
	p13.blackOutTimer = 0
	p13.lastCameraResetPosition = nil
	v_u_8.Reset(p13)
end
function v_u_9.Update(p14, p15) -- name: Update
	-- upvalues: (copy) v_u_1, (copy) v_u_6, (copy) v_u_2
	local v16 = workspace.CurrentCamera
	local v17 = v16.CFrame
	local v18 = v16.Focus
	local v19 = v_u_1.LocalPlayer
	if p14.lastUpdate == nil or p15 > 1 then
		p14.lastCameraTransform = nil
	end
	p14:UpdateFadeFromBlack(p15)
	local v20 = p14.lastSubjectPosition
	local v21 = p14:GetSubjectPosition()
	if p14.needsBlackout then
		p14:StartFadeFromBlack()
		local v22 = math.clamp(p15, 0.0001, 0.1)
		p14.blackOutTimer = p14.blackOutTimer + v22
		if p14.blackOutTimer > 0.1 and game:IsLoaded() then
			p14.needsBlackout = false
			p14.needsReset = true
		end
	end
	if v21 and (v19 and v16) then
		local v23 = p14:GetVRFocus(v21, p15)
		if v_u_6 then
			local v24 = p14:IsInFirstPerson()
			if v24 then
				v24 = v19.DevCameraOcclusionMode ~= Enum.DevCameraOcclusionMode.Invisicam
			end
			p14.skipOcclusion = v24
		end
		if p14:IsInFirstPerson() then
			if v_u_2.AvatarGestures then
				v17, v18 = p14:UpdateImmersionCamera(p15, v17, v23, v20, v21)
			else
				v17, v18 = p14:UpdateFirstPersonTransform(p15, v17, v23, v20, v21)
			end
		elseif v_u_2.ThirdPersonFollowCamEnabled then
			v17, v18 = p14:UpdateThirdPersonFollowTransform(p15, v17, v23, v20, v21)
		else
			v17, v18 = p14:UpdateThirdPersonComfortTransform(p15, v17, v23, v20, v21)
		end
		p14.lastCameraTransform = v17
		p14.lastCameraFocus = v18
	end
	p14.lastUpdate = tick()
	return v17, v18
end
function v_u_9.GetAvatarFeetWorldYValue(_) -- name: GetAvatarFeetWorldYValue
	local v25 = workspace.CurrentCamera.CameraSubject
	if not v25 then
		return nil
	end
	if not (v25:IsA("Humanoid") and v25.RootPart) then
		return nil
	end
	local v26 = v25.RootPart
	return v26.Position.Y - v26.Size.Y / 2 - v25.HipHeight
end
function v_u_9.UpdateFirstPersonTransform(p27, p28, _, p29, _, _) -- name: UpdateFirstPersonTransform
	if p27.needsReset then
		p27:StartFadeFromBlack()
		p27.needsReset = false
	end
	local v30 = p29.Position
	local v31 = p27:GetCameraLookVector()
	local v32 = v31.X
	local v33 = v31.Z
	local v34 = Vector3.new(v32, 0, v33).Unit
	local v35 = p27:getRotation(p28)
	local v36 = p27:CalculateNewLookVectorFromArg(v34, Vector2.new(v35, 0))
	return CFrame.new(v30 - 0.5 * v36, v30), p29
end
function v_u_9.UpdateImmersionCamera(p37, p38, _, _, p39, p40) -- name: UpdateImmersionCamera
	-- upvalues: (copy) v_u_1, (copy) v_u_5, (copy) v_u_7, (copy) v_u_2, (copy) v_u_3
	local v41 = p37:GetSubjectCFrame()
	local v42 = workspace.CurrentCamera
	local v43 = v_u_1.LocalPlayer.Character
	local v44 = p37:GetHumanoid()
	if not v44 then
		return v42.CFrame, v42.Focus
	end
	local v45 = v43:FindFirstChild("HumanoidRootPart")
	if not v45 then
		return v42.CFrame, v42.Focus
	end
	local v46
	if v_u_5 then
		if p39 then
			local v47 = p40.X - p39.X
			local v48 = p40.Z - p39.Z
			v46 = Vector3.new(v47, 0, v48).Magnitude
		else
			v46 = 0
		end
	else
		v46 = nil
	end
	p37.characterOrientation = v45:FindFirstChild("CharacterAlignOrientation")
	if not p37.characterOrientation then
		local v49 = v45:FindFirstChild("RootAttachment")
		if not v49 then
			return
		end
		p37.characterOrientation = Instance.new("AlignOrientation")
		p37.characterOrientation.Name = "CharacterAlignOrientation"
		p37.characterOrientation.Mode = Enum.OrientationAlignmentMode.OneAttachment
		p37.characterOrientation.Attachment0 = v49
		p37.characterOrientation.RigidityEnabled = true
		p37.characterOrientation.Parent = v45
	end
	if p37.characterOrientation.Enabled == false then
		p37.characterOrientation.Enabled = true
	end
	if p37.needsReset then
		p37.needsReset = false
		if v_u_7 then
			p37:updateImmersionAutoRotate()
		else
			p37.savedAutoRotate = v44.AutoRotate
			v44.AutoRotate = false
		end
		if v_u_5 then
			v_u_2:RecenterUserHeadCFrame()
			p37.lastTeleportRecenter = tick()
		end
		p37:StartFadeFromBlack()
	elseif not v44.Sit then
		local v50 = p37.controlModule:GetEstimatedVRTorsoFrame()
		p37.characterOrientation.CFrame = v42.CFrame * v50
		if p37.controlModule.inputMoveVector.Magnitude > 0 then
			p37.motionDetTime = 0.1
		end
		if p37.controlModule.inputMoveVector.Magnitude > 0 or p37.motionDetTime > 0 then
			p37.motionDetTime = p37.motionDetTime - p38
			local v51 = v_u_2:GetUserCFrame(Enum.UserCFrame.Head)
			local v52 = v51.Rotation + v51.Position * v42.HeadScale
			local v53 = v43.HumanoidRootPart
			local v54 = -0.7 * v53.Size.Y / 2
			local v55 = v42.CFrame * v52 * CFrame.new(0, v54, 0)
			local v56 = v53.CFrame.LookVector
			local v57 = v56.X
			local v58 = v56.Z
			local v59 = p40 - (v55 - Vector3.new(v57, 0, v58).Unit * v53.Size.Y * 0.125).Position + v42.CFrame.Position
			local v60 = v59.X
			local v61 = p40.Y
			local v62 = v59.Z
			local v63 = Vector3.new(v60, v61, v62)
			v41 = v42.CFrame.Rotation + v63
		elseif v_u_5 and v_u_3.shouldRecenter(p37.prevSubjStep, v46, p37.lastTeleportRecenter, tick()) then
			local v64 = v_u_2:GetUserCFrame(Enum.UserCFrame.Head)
			local v65 = v64.Rotation + v64.Position * v42.HeadScale
			local v66 = v43.HumanoidRootPart
			local v67 = -0.7 * v66.Size.Y / 2
			local v68 = v42.CFrame * v65 * CFrame.new(0, v67, 0)
			local v69 = v66.CFrame.LookVector
			local v70 = v69.X
			local v71 = v69.Z
			local v72 = p40 - (v68 - Vector3.new(v70, 0, v71).Unit * v66.Size.Y * 0.125).Position + v42.CFrame.Position
			local v73 = v72.X
			local v74 = p40.Y
			local v75 = v72.Z
			local v76 = Vector3.new(v73, v74, v75)
			v41 = v42.CFrame.Rotation + v76
			v_u_2:RecenterUserHeadCFrame()
			p37:StartFadeFromBlack()
			p37.lastTeleportRecenter = tick()
		else
			local v77 = v42.CFrame.Rotation
			local v78 = v42.CFrame.Position.X
			local v79 = p40.Y
			local v80 = v42.CFrame.Position.Z
			v41 = v77 + Vector3.new(v78, v79, v80)
		end
		local v81 = p37:getRotation(p38)
		if math.abs(v81) > 0 then
			local v82 = v_u_2:GetUserCFrame(Enum.UserCFrame.Head)
			local v83 = v82.Rotation + v82.Position * v42.HeadScale
			local v84 = v41 * v83
			local v85 = CFrame.new(v84.Position)
			local v86 = CFrame.Angles
			local v87 = v81 * 90
			v41 = v85 * v86(0, -math.rad(v87), 0) * v84.Rotation * v83:Inverse()
		end
	end
	if v_u_5 then
		p37.prevSubjStep = v46
	end
	return v41, v41 * CFrame.new(0, 0, -0.5)
end
function v_u_9.UpdateThirdPersonComfortTransform(p88, p89, p90, p91, p92, p93) -- name: UpdateThirdPersonComfortTransform
	-- upvalues: (copy) v_u_2
	local v94 = p88:GetCameraToSubjectDistance()
	local v95 = v94 < 0.5 and 0.5 or v94
	if p92 ~= nil and p88.lastCameraFocus ~= nil then
		local v96 = p92 - p93
		local v97 = p88.controlModule.inputMoveVector
		local v98 = v96.magnitude > 0.01 and true or v97.magnitude > 0.01
		if v98 then
			p88.motionDetTime = 0.1
		end
		p88.motionDetTime = p88.motionDetTime - p89
		if (p88.motionDetTime > 0 and true or v98) and not p88.needsReset then
			local v99 = p88.lastCameraFocus
			p88.VRCameraFocusFrozen = true
			return p90, v99
		end
		local v100 = p88.lastCameraResetPosition == nil and true or (p93 - p88.lastCameraResetPosition).Magnitude > 1
		local v101 = p88:getRotation(p89)
		if math.abs(v101) > 0 then
			local v102 = p91:ToObjectSpace(p90)
			p90 = p91 * CFrame.Angles(0, -v101, 0) * v102
		end
		if p88.VRCameraFocusFrozen and v100 or p88.needsReset then
			v_u_2:RecenterUserHeadCFrame()
			p88.VRCameraFocusFrozen = false
			p88.needsReset = false
			p88.lastCameraResetPosition = p93
			p88:ResetZoom()
			p88:StartFadeFromBlack()
			local v103 = p88:GetHumanoid()
			local v104 = v103.Torso and v103.Torso.CFrame.lookVector or Vector3.new(1, 0, 0)
			local v105 = v104.X
			local v106 = v104.Z
			local v107 = Vector3.new(v105, 0, v106)
			local v108 = p91.Position - v107 * v95
			local v109 = p91.Position.X
			local v110 = v108.Y
			local v111 = p91.Position.Z
			local v112 = Vector3.new(v109, v110, v111)
			p90 = CFrame.new(v108, v112)
		end
	end
	return p90, p91
end
function v_u_9.UpdateThirdPersonFollowTransform(p113, p114, _, _, p115, p116) -- name: UpdateThirdPersonFollowTransform
	-- upvalues: (copy) v_u_2
	local v117 = workspace.CurrentCamera
	local v118 = p113:GetCameraToSubjectDistance()
	local v119 = p113:GetVRFocus(p116, p114)
	if p113.needsReset then
		p113.needsReset = false
		v_u_2:RecenterUserHeadCFrame()
		p113:ResetZoom()
		p113:StartFadeFromBlack()
	end
	if p113.recentered then
		local v120 = p113:GetSubjectCFrame()
		if not v120 then
			return v117.CFrame, v117.Focus
		end
		local v121 = v119 * v120.Rotation * CFrame.new(0, 0, v118)
		p113.focusOffset = v119:ToObjectSpace(v121)
		p113.recentered = false
		return v121, v119
	end
	local v122 = v119:ToWorldSpace(p113.focusOffset)
	local v123 = p115 - p116
	local v124 = p113.controlModule
	local v125 = v124.inputMoveVector
	if v123.magnitude > 0.01 or v125.magnitude > 0 then
		local v126 = v124:GetEstimatedVRTorsoFrame()
		local v127 = v126.Rotation + v126.Position * v117.HeadScale
		local v128 = v117.CFrame * v127
		local v129 = v128.LookVector
		local v130 = v129.X
		local v131 = v129.Z
		local v132 = Vector3.new(v130, 0, v131).Unit * v118
		local v133 = v119.Position - v132
		v122 = v122:Lerp(CFrame.new(v117.CFrame.Position + v133 - v128.Position) * v122.Rotation, 0.01)
	end
	local v134 = p113:getRotation(p114)
	if math.abs(v134) > 0 then
		local v135 = v119:ToObjectSpace(v122)
		v122 = v119 * CFrame.Angles(0, -v134, 0) * v135
	end
	p113.focusOffset = v119:ToObjectSpace(v122)
	return v122, v122 * CFrame.new(0, 0, -v118)
end
function v_u_9.updateImmersionAutoRotate(p136) -- name: updateImmersionAutoRotate
	-- upvalues: (copy) v_u_2
	local v137 = p136:GetHumanoid()
	if v137 then
		if p136:IsInFirstPerson() and v_u_2.AvatarGestures then
			if not p136.autoRotateOverridden then
				p136.savedAutoRotate = v137.AutoRotate
				p136.autoRotateOverridden = true
			end
			v137.AutoRotate = false
		elseif p136.autoRotateOverridden then
			v137.AutoRotate = p136.savedAutoRotate
			p136.autoRotateOverridden = false
		end
	else
		return
	end
end
function v_u_9.OnEnabledChanged(p_u_138) -- name: OnEnabledChanged
	-- upvalues: (copy) v_u_8, (copy) v_u_7, (copy) v_u_2
	v_u_8.OnEnabledChanged(p_u_138)
	if v_u_7 then
		if p_u_138.enabled then
			if not p_u_138.avatarGesturesChangedConn then
				p_u_138.avatarGesturesChangedConn = v_u_2:GetPropertyChangedSignal("AvatarGestures"):Connect(function()
					-- upvalues: (copy) p_u_138
					p_u_138:updateImmersionAutoRotate()
				end)
				return
			end
		elseif p_u_138.avatarGesturesChangedConn then
			p_u_138.avatarGesturesChangedConn:Disconnect()
			p_u_138.avatarGesturesChangedConn = nil
		end
	end
end
function v_u_9.LeaveFirstPerson(p139) -- name: LeaveFirstPerson
	-- upvalues: (copy) v_u_8, (copy) v_u_7
	v_u_8.LeaveFirstPerson(p139)
	p139.needsReset = true
	if p139.VRBlur then
		p139.VRBlur.Visible = false
	end
	if p139.characterOrientation then
		p139.characterOrientation.Enabled = false
	end
	if v_u_7 then
		p139:updateImmersionAutoRotate()
	else
		local v140 = p139:GetHumanoid()
		if v140 then
			v140.AutoRotate = p139.savedAutoRotate
		end
	end
end
return v_u_9