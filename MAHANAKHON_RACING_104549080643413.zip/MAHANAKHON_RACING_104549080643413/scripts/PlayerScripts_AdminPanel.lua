-- Path: Players/ygggggg55551/PlayerScripts/AdminPanel
-- Class: LocalScript  true/Enum.RunContext.Legacy
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = require(game:GetService("ReplicatedStorage"):WaitForChild("NetSeal"))
local v_u_2 = game:GetService("Players")
local v3 = game:GetService("ReplicatedStorage")
game:GetService("TweenService")
local v_u_4 = game:GetService("UserInputService")
local v_u_5 = require(v3:WaitForChild("GameShared"))
local v_u_6 = require(v3:WaitForChild("PistonShared"))
local v_u_7 = require(v3:WaitForChild("RankShared"))
local v_u_8 = v3:WaitForChild("GameUI")
local v_u_9 = require(v_u_8:WaitForChild("Theme"))
local v_u_10 = require(v_u_8:WaitForChild("Icons"))
local v_u_11 = {
	["BG"] = Color3.fromRGB(12, 13, 17),
	["SIDE"] = Color3.fromRGB(17, 18, 23),
	["PANEL"] = Color3.fromRGB(22, 24, 30),
	["ROW"] = Color3.fromRGB(29, 31, 39),
	["FIELD"] = Color3.fromRGB(16, 17, 22),
	["DIM"] = Color3.fromRGB(136, 142, 156),
	["INK"] = Color3.fromRGB(16, 16, 20),
	["ACCENT"] = Color3.fromRGB(99, 102, 241),
	["VALUE"] = Color3.fromRGB(96, 156, 255),
	["KEY"] = Color3.fromRGB(40, 43, 54)
}
local v_u_12 = {
	["blue"] = Color3.fromRGB(59, 130, 246),
	["yellow"] = Color3.fromRGB(234, 179, 8),
	["green"] = Color3.fromRGB(34, 197, 94),
	["red"] = Color3.fromRGB(239, 68, 68),
	["orange"] = Color3.fromRGB(249, 115, 22),
	["cyan"] = Color3.fromRGB(6, 182, 212),
	["purple"] = Color3.fromRGB(168, 85, 247),
	["pink"] = Color3.fromRGB(236, 72, 153),
	["teal"] = Color3.fromRGB(20, 184, 166),
	["indigo"] = v_u_11.ACCENT
}
local v13 = v_u_11.ACCENT
local v14 = v_u_11.PANEL
local v15 = v_u_12.red
local v16 = v_u_12.green
local v17 = v_u_12.yellow
v_u_11.MINT = v13
v_u_11.PAPER = v14
v_u_11.ERROR = v15
v_u_11.SUCCESS = v16
v_u_11.WARN = v17
local v_u_18 = setmetatable({}, {
	["__index"] = v_u_9
})
local v19 = v_u_11.ROW
local v20 = v_u_11.FIELD
local v21 = v_u_11.ACCENT
local v22 = v_u_11.DIM
local v23 = v_u_12.green
v_u_18.CARD = v19
v_u_18.CARD_DARK = v20
v_u_18.YELLOW = v21
v_u_18.TEXT_DIM = v22
v_u_18.GREEN_TEXT = v23
local v_u_24 = {
	["gold"] = v_u_11.ACCENT,
	["accent"] = v_u_11.ACCENT,
	["purple"] = v_u_12.purple,
	["green"] = v_u_12.green,
	["red"] = v_u_12.red,
	["orange"] = v_u_12.orange,
	["blue"] = v_u_12.blue,
	["cyan"] = v_u_12.cyan,
	["yellow"] = v_u_12.yellow,
	["money"] = v_u_12.yellow,
	["pink"] = v_u_12.pink,
	["teal"] = v_u_12.teal,
	["indigo"] = v_u_11.ACCENT
}
local function v_u_28(p25, p26) -- name: tint
	for _, v27 in p25:GetDescendants() do
		if v27:IsA("TextLabel") then
			v27.TextColor3 = p26
		elseif v27:IsA("ImageLabel") then
			v27.ImageColor3 = p26
		elseif v27:IsA("UIStroke") then
			v27.Color = p26
		else
			if not v27:IsA("Frame") or v27.BackgroundTransparency >= 1 then
				continue
			end
			v27.BackgroundColor3 = p26
		end
	end
end
local function v_u_36(p29, p30, p31) -- name: paint
	-- upvalues: (copy) v_u_24, (copy) v_u_9, (copy) v_u_11, (copy) v_u_28
	local v32
	if typeof(p30) == "Color3" then
		v32 = p30
	elseif type(p30) == "string" then
		v32 = v_u_24[p30]
	else
		v32 = nil
	end
	local v33 = p29:FindFirstChild("Edge")
	local v34
	if v32 then
		if v_u_9.lum(v32) > 0.62 then
			v34 = v_u_11.INK
		else
			v34 = Color3.new(1, 1, 1)
		end
		if v33 then
			v33.Color = v32
			v33.Thickness = 2
			v33.Transparency = 0.5
		end
	elseif p30 == "grey" then
		v32 = v_u_11.FIELD
		v34 = v_u_11.DIM
		if v33 then
			v33.Color = Color3.new(1, 1, 1)
			v33.Thickness = 1
			v33.Transparency = 0.9
		end
	else
		v32 = v_u_11.KEY
		v34 = Color3.new(1, 1, 1)
		if v33 then
			v33.Color = Color3.new(1, 1, 1)
			v33.Thickness = 1
			v33.Transparency = 0.9
		end
	end
	p29.BackgroundColor3 = v32
	p29.BackgroundTransparency = 0
	p29:SetAttribute("TxFill", v32)
	local v35 = p29:FindFirstChild("Row")
	if v35 then
		v_u_28(v35, p31 or v34)
	end
end
function v_u_18.button(p37) -- name: button
	-- upvalues: (copy) v_u_18, (copy) v_u_10, (copy) v_u_36
	local v_u_38 = v_u_18.new("TextButton", {
		["Name"] = nil,
		["Text"] = "",
		["AutoButtonColor"] = false,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = nil,
		["Parent"] = nil,
		["Name"] = p37.name or "Button",
		["AnchorPoint"] = p37.anchor or Vector2.zero,
		["Position"] = p37.position or UDim2.new(),
		["Size"] = p37.size or UDim2.fromOffset(140, 40),
		["ZIndex"] = p37.zindex or 1,
		["Parent"] = p37.parent
	})
	v_u_18.corner(v_u_38, 7)
	v_u_18.new("UIStroke", {
		["Name"] = "Edge",
		["ApplyStrokeMode"] = nil,
		["Thickness"] = 1,
		["Parent"] = nil,
		["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
		["Parent"] = v_u_38
	})
	local v39 = v_u_18.new("Frame", {
		["Name"] = "Row",
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["ZIndex"] = nil,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.5),
		["Size"] = UDim2.fromScale(0, 1),
		["AutomaticSize"] = Enum.AutomaticSize.X,
		["ZIndex"] = v_u_38.ZIndex + 1,
		["Parent"] = v_u_38
	})
	v_u_18.new("UIListLayout", {
		["FillDirection"] = Enum.FillDirection.Horizontal,
		["VerticalAlignment"] = Enum.VerticalAlignment.Center,
		["HorizontalAlignment"] = Enum.HorizontalAlignment.Center,
		["Padding"] = UDim.new(0, 7),
		["SortOrder"] = Enum.SortOrder.LayoutOrder,
		["Parent"] = v39
	})
	if p37.icon then
		local v40 = v_u_10.make(p37.icon, Color3.new(1, 1, 1), p37.iconSize or 15)
		v40.LayoutOrder = 1
		for _, v41 in v40:GetDescendants() do
			if not v41:IsA("GuiObject") then
				continue
			end
			v41.ZIndex = v_u_38.ZIndex + 2
		end
		v40.ZIndex = v_u_38.ZIndex + 2
		v40.Parent = v39
	end
	local v42 = v_u_18.text
	local v43 = {
		["Name"] = "Caption",
		["Text"] = nil,
		["FontFace"] = nil,
		["TextSize"] = nil,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = 2,
		["ZIndex"] = nil,
		["Parent"] = nil,
		["Text"] = p37.text or "",
		["FontFace"] = v_u_18.FONT_BOLD
	}
	local v44 = p37.textSize or 14
	v43.TextSize = math.min(v44, 15)
	v43.Size = UDim2.fromScale(0, 1)
	v43.AutomaticSize = Enum.AutomaticSize.X
	v43.ZIndex = v_u_38.ZIndex + 2
	v43.Parent = v39
	local v45 = v42(v43)
	v_u_36(v_u_38, p37.grad, p37.textColor)
	v_u_38.MouseEnter:Connect(function()
		-- upvalues: (copy) v_u_38
		local v46 = v_u_38:GetAttribute("TxFill")
		if typeof(v46) == "Color3" then
			v_u_38.BackgroundColor3 = v46:Lerp(Color3.new(1, 1, 1), 0.12)
		end
	end)
	v_u_38.MouseLeave:Connect(function()
		-- upvalues: (copy) v_u_38
		local v47 = v_u_38:GetAttribute("TxFill")
		if typeof(v47) == "Color3" then
			v_u_38.BackgroundColor3 = v47
		end
	end)
	return v_u_38, v45, nil
end
function v_u_18.setButton(p48, p49, p50, p51) -- name: setButton
	-- upvalues: (copy) v_u_36
	local v52 = p48:FindFirstChild("Row")
	if v52 then
		v52 = p48.Row:FindFirstChild("Caption")
	end
	if v52 and p50 then
		v52.Text = p50
	end
	if p49 then
		v_u_36(p48, p49, p51)
	end
end
local v_u_53 = require(v_u_8:WaitForChild("Toast"))
local v_u_54 = v_u_2.LocalPlayer
local v55 = v3:WaitForChild(v_u_5.REMOTES)
local v_u_56 = v_u_18.isTouch()
local v_u_57 = v_u_18.screen("AdminPanel", 60, v_u_54:WaitForChild("PlayerGui"))
local v_u_58 = require(v_u_8:WaitForChild("Notice"))
v55:WaitForChild("Announce").OnClientEvent:Connect(function(p59, p60, p61)
	-- upvalues: (copy) v_u_58
	v_u_58.show({
		["title"] = nil,
		["text"] = nil,
		["kind"] = nil,
		["hold"] = false,
		["seconds"] = 10,
		["title"] = "Announcement from " .. tostring(p60),
		["text"] = tostring(p59),
		["kind"] = p61 or "notify"
	})
end)
v55:WaitForChild("Notice").OnClientEvent:Connect(function(p62)
	-- upvalues: (copy) v_u_58
	if type(p62) == "table" then
		v_u_58.show({
			["title"] = nil,
			["text"] = nil,
			["kind"] = nil,
			["seconds"] = 6,
			["title"] = p62.title,
			["text"] = p62.text,
			["kind"] = p62.kind
		})
	end
end)
local v_u_63 = nil
local v_u_64 = v_u_18.button({
	["name"] = "StopSpectate",
	["text"] = "Stop spectating",
	["icon"] = "close",
	["grad"] = "red",
	["textSize"] = 16,
	["anchor"] = nil,
	["position"] = nil,
	["size"] = nil,
	["parent"] = nil,
	["anchor"] = Vector2.new(0.5, 1),
	["position"] = UDim2.new(0.5, 0, 1, -24),
	["size"] = UDim2.fromOffset(220, 46),
	["parent"] = v_u_57
})
v_u_64.Visible = false
local v_u_65 = v_u_18.text({
	["Text"] = "",
	["TextSize"] = 18,
	["FontFace"] = nil,
	["TextStrokeTransparency"] = 0.4,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Visible"] = false,
	["Parent"] = nil,
	["FontFace"] = v_u_18.FONT_HEAVY,
	["AnchorPoint"] = Vector2.new(0.5, 1),
	["Position"] = UDim2.new(0.5, 0, 1, -78),
	["Size"] = UDim2.fromOffset(400, 24),
	["Parent"] = v_u_57
})
local v_u_66 = v55:WaitForChild("Admin")
local v_u_67 = 0
local function v_u_87(p_u_68) -- name: spectate
	-- upvalues: (ref) v_u_67, (ref) v_u_63, (copy) v_u_1, (copy) v_u_66, (copy) v_u_54, (copy) v_u_64, (copy) v_u_65, (copy) v_u_53, (copy) v_u_87
	v_u_67 = v_u_67 + 1
	local v_u_69 = v_u_67
	local v_u_70 = workspace.CurrentCamera
	if p_u_68 then
		v_u_63 = p_u_68
		v_u_64.Visible = true
		v_u_65.Visible = true
		v_u_65.Text = "Finding " .. p_u_68.Name .. "\226\128\166"
		task.spawn(function()
			-- upvalues: (ref) v_u_1, (ref) v_u_66, (copy) p_u_68, (ref) v_u_53, (copy) v_u_69, (ref) v_u_67, (ref) v_u_87, (ref) v_u_54, (copy) v_u_70, (ref) v_u_65
			local v71 = v_u_1.invoke
			local v72 = v_u_66
			local v73 = p_u_68.UserId
			local v74, v75, v76 = pcall(v71, v72, "Spectate", v73)
			if not (v74 and v75) then
				v_u_53.show(v74 and v76 and v76 or "Couldn\'t spectate", "error")
				if v_u_69 == v_u_67 then
					v_u_87(nil)
				end
				return
			end
			if typeof(v76) == "Vector3" then
				local v77 = v_u_54.RequestStreamAroundAsync
				local v78 = v_u_54
				pcall(v77, v78, v76, 6)
			end
			local v79 = os.clock()
			while v_u_69 == v_u_67 do
				local v80 = p_u_68
				local v81 = v80 and v80.Character and (v80.Character:FindFirstChildOfClass("Humanoid") and v80.Character:FindFirstChild("HumanoidRootPart"))
				if v81 then
					v81 = v80.Character:FindFirstChildOfClass("Humanoid")
				end
				if v81 or os.clock() - v79 >= 8 then
					break
				end
				task.wait(0.2)
			end
			if v_u_69 == v_u_67 then
				local v82 = p_u_68
				local v83 = v82 and v82.Character and (v82.Character:FindFirstChildOfClass("Humanoid") and v82.Character:FindFirstChild("HumanoidRootPart"))
				if v83 then
					v83 = v82.Character:FindFirstChildOfClass("Humanoid")
				end
				if v83 then
					v_u_70.CameraSubject = v83
					v_u_65.Text = "Spectating " .. p_u_68.Name
				else
					v_u_53.show(p_u_68.Name .. " couldn\'t be found, try again", "error")
					v_u_87(nil)
				end
			else
				return
			end
		end)
	else
		v_u_63 = nil
		local v84 = v_u_1.invoke
		local v85 = v_u_66
		pcall(v84, v85, "Spectate", nil)
		local v86 = v_u_54.Character
		if v86 then
			v86 = v_u_54.Character:FindFirstChildOfClass("Humanoid")
		end
		if v86 then
			v_u_70.CameraSubject = v86
		end
		v_u_64.Visible = false
		v_u_65.Visible = false
	end
end
v_u_64.Activated:Connect(function()
	-- upvalues: (ref) v_u_67, (ref) v_u_63, (copy) v_u_1, (copy) v_u_66, (copy) v_u_54, (copy) v_u_64, (copy) v_u_65
	v_u_67 = v_u_67 + 1
	local v88 = workspace.CurrentCamera
	v_u_63 = nil
	local v89 = v_u_1.invoke
	local v90 = v_u_66
	pcall(v89, v90, "Spectate", nil)
	local v91 = v_u_54.Character
	if v91 then
		v91 = v_u_54.Character:FindFirstChildOfClass("Humanoid")
	end
	if v91 then
		v88.CameraSubject = v91
	end
	v_u_64.Visible = false
	v_u_65.Visible = false
end)
task.spawn(function()
	-- upvalues: (ref) v_u_63, (copy) v_u_65
	while true do
		repeat
			task.wait(1)
		until v_u_63 and v_u_65.Text:find("^Spectating")
		local v92 = v_u_63
		local v93 = v92 and v92.Character and (v92.Character:FindFirstChildOfClass("Humanoid") and v92.Character:FindFirstChild("HumanoidRootPart"))
		if v93 then
			v93 = v92.Character:FindFirstChildOfClass("Humanoid")
		end
		if not v93 or workspace.CurrentCamera.CameraSubject == v93 then
			continue
		end
		workspace.CurrentCamera.CameraSubject = v93
	end
end)
v_u_2.PlayerRemoving:Connect(function(p94)
	-- upvalues: (ref) v_u_63, (ref) v_u_67, (copy) v_u_1, (copy) v_u_66, (copy) v_u_54, (copy) v_u_64, (copy) v_u_65
	if p94 == v_u_63 then
		v_u_67 = v_u_67 + 1
		local v95 = workspace.CurrentCamera
		v_u_63 = nil
		local v96 = v_u_1.invoke
		local v97 = v_u_66
		pcall(v96, v97, "Spectate", nil)
		local v98 = v_u_54.Character
		if v98 then
			v98 = v_u_54.Character:FindFirstChildOfClass("Humanoid")
		end
		if v98 then
			v95.CameraSubject = v98
		end
		v_u_64.Visible = false
		v_u_65.Visible = false
	end
end)
local v_u_99 = v55:WaitForChild("Admin")
local function v_u_106(p100, ...) -- name: call
	-- upvalues: (copy) v_u_1, (copy) v_u_99
	local v101 = v_u_1.invoke
	local v102 = v_u_99
	local v103, v104, v105 = pcall(v101, v102, p100, ...)
	if v103 then
		return v104, v105
	else
		return false, "Couldn\'t reach the server"
	end
end
local v_u_107 = v_u_18.button({
	["name"] = "AdminOpen",
	["text"] = nil,
	["icon"] = "shield",
	["grad"] = "red",
	["textSize"] = 15,
	["anchor"] = nil,
	["position"] = nil,
	["size"] = nil,
	["parent"] = nil,
	["text"] = v_u_56 and "" or "Admin",
	["anchor"] = Vector2.new(1, 0),
	["position"] = UDim2.new(1, -12, 0, v_u_56 and 56 or 12),
	["size"] = UDim2.fromOffset(v_u_56 and 46 or 112, 40),
	["parent"] = v_u_57
})
v_u_107.Visible = false
local v_u_108 = false
local v_u_109 = v_u_18.button({
	["name"] = "CtrlWarp",
	["text"] = "Ctrl Warp: OFF",
	["icon"] = "zap",
	["grad"] = "grey",
	["textSize"] = 14,
	["anchor"] = nil,
	["position"] = nil,
	["size"] = nil,
	["parent"] = nil,
	["anchor"] = Vector2.new(1, 0),
	["position"] = UDim2.new(1, -12, 0, v_u_56 and 106 or 58),
	["size"] = UDim2.fromOffset(150, 34),
	["parent"] = v_u_57
})
v_u_109.Visible = false
v_u_109.Activated:Connect(function()
	-- upvalues: (ref) v_u_108, (copy) v_u_18, (copy) v_u_109, (copy) v_u_53
	local v110 = not v_u_108
	v_u_108 = v110
	v_u_18.setButton(v_u_109, v110 and "green" or "grey", v110 and "Ctrl Warp: ON" or "Ctrl Warp: OFF")
	v_u_53.show(v110 and "Ctrl + click to warp: on" or "Ctrl + click to warp: off", "ok")
end)
v_u_4.InputBegan:Connect(function(p111, p112)
	-- upvalues: (ref) v_u_108, (copy) v_u_4, (copy) v_u_7, (copy) v_u_54, (copy) v_u_53, (copy) v_u_106
	if p112 or (not v_u_108 or p111.UserInputType ~= Enum.UserInputType.MouseButton1) or not (v_u_4:IsKeyDown(Enum.KeyCode.LeftControl) or v_u_4:IsKeyDown(Enum.KeyCode.RightControl)) then
		return
	elseif v_u_7.isStaff(v_u_54) then
		local v113 = workspace.CurrentCamera
		local v114 = v_u_4:GetMouseLocation()
		local v115 = v113:ViewportPointToRay(v114.X, v114.Y)
		local v116 = {}
		local v117 = v_u_54.Character
		if v117 then
			table.insert(v116, v117)
			local v118 = v117:FindFirstChildOfClass("Humanoid")
			if v118 then
				v118 = v118.SeatPart
			end
			if v118 then
				v118 = v118:FindFirstAncestorWhichIsA("Model")
			end
			local v119 = workspace:FindFirstChild("SpawnedVehicles")
			while v118 and (v119 and (v118.Parent ~= v119 and v118.Parent ~= workspace)) do
				v118 = v118.Parent
			end
			if v118 and v118 ~= workspace then
				table.insert(v116, v118)
			end
		end
		local v120 = RaycastParams.new()
		v120.FilterType = Enum.RaycastFilterType.Exclude
		v120.FilterDescendantsInstances = v116
		v120.IgnoreWater = false
		local v_u_121 = workspace:Raycast(v115.Origin, v115.Direction * 5000, v120)
		if v_u_121 then
			task.spawn(function()
				-- upvalues: (ref) v_u_106, (copy) v_u_121, (ref) v_u_53
				local v122, v123 = v_u_106("ClickWarp", v_u_121.Position)
				if not v122 and v123 then
					v_u_53.show(tostring(v123), "error")
				end
			end)
		else
			v_u_53.show("Point at the ground to warp", "error")
		end
	else
		return
	end
end)
local v124 = v_u_18.isPhone()
local v125 = v_u_56 and 196 or 236
local v_u_126 = {
	["changed"] = Instance.new("BindableEvent")
}
local v127 = v_u_18.new
local v128 = "Frame"
local v129 = {
	["Name"] = "AdminWindow",
	["BackgroundColor3"] = nil,
	["BorderSizePixel"] = 0,
	["Visible"] = false,
	["Active"] = true,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["ZIndex"] = 5,
	["Parent"] = nil,
	["BackgroundColor3"] = v_u_11.BG,
	["AnchorPoint"] = Vector2.new(0.5, 0.5),
	["Position"] = UDim2.fromScale(0.5, 0.5)
}
local v130
if v_u_56 then
	v130 = UDim2.fromScale(0.97, 0.94)
else
	v130 = UDim2.fromScale(0.84, 0.84)
end
v129.Size = v130
v129.Parent = v_u_57
local v_u_131 = v127(v128, v129)
v_u_18.corner(v_u_131, 12)
v_u_18.border(v_u_131, Color3.new(1, 1, 1), 0.9, 1)
v_u_18.new("UISizeConstraint", {
	["MaxSize"] = Vector2.new(1260, 780),
	["Parent"] = v_u_131
})
if v124 then
	v_u_18.new("UIScale", {
		["Scale"] = 0.8,
		["Parent"] = nil,
		["Parent"] = v_u_131
	})
	v_u_131.Size = UDim2.fromScale(1.2125, 1.1749999999999998)
end
local v132 = v_u_18.new("Frame", {
	["Name"] = "Side",
	["BackgroundColor3"] = nil,
	["BorderSizePixel"] = 0,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["BackgroundColor3"] = v_u_11.SIDE,
	["Position"] = UDim2.fromOffset(10, 10),
	["Size"] = UDim2.new(0, v125, 1, -20),
	["Parent"] = v_u_131
})
v_u_18.corner(v132, 10)
v_u_18.padding(v132, 10, 10)
local v133 = v_u_18.new("Frame", {
	["Name"] = "Me",
	["BackgroundColor3"] = nil,
	["BorderSizePixel"] = 0,
	["Size"] = nil,
	["Parent"] = nil,
	["BackgroundColor3"] = v_u_11.PANEL,
	["Size"] = UDim2.new(1, 0, 0, 60),
	["Parent"] = v132
})
v_u_18.corner(v133, 8)
local v134 = v_u_18.new
local v135 = {
	["BackgroundColor3"] = v_u_11.ROW
}
local v136 = v_u_54.UserId
v135.Image = ("rbxthumb://type=AvatarHeadShot&id=%d&w=150&h=150"):format(tonumber(v136) or 1)
v135.Position = UDim2.fromOffset(9, 10)
v135.Size = UDim2.fromOffset(40, 40)
v135.Parent = v133
local v137 = v134("ImageLabel", v135)
v_u_18.corner(v137, 8)
local v138 = v_u_18.new("Frame", {
	["BackgroundColor3"] = nil,
	["BorderSizePixel"] = 0,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["BackgroundColor3"] = v_u_12.green,
	["Position"] = UDim2.fromOffset(41, 42),
	["Size"] = UDim2.fromOffset(10, 10),
	["Parent"] = v133
})
v_u_18.corner(v138, 5)
v_u_18.border(v138, v_u_11.PANEL, 0, 2)
v_u_18.text({
	["Text"] = nil,
	["TextSize"] = 15,
	["FontFace"] = nil,
	["TextXAlignment"] = nil,
	["TextTruncate"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["Text"] = v_u_54.DisplayName,
	["FontFace"] = v_u_18.FONT_BOLD,
	["TextXAlignment"] = Enum.TextXAlignment.Left,
	["TextTruncate"] = Enum.TextTruncate.AtEnd,
	["Position"] = UDim2.fromOffset(60, 11),
	["Size"] = UDim2.new(1, -66, 0, 20),
	["Parent"] = v133
})
local v_u_139 = v_u_18.text({
	["Text"] = "",
	["TextSize"] = 12,
	["FontFace"] = nil,
	["TextXAlignment"] = nil,
	["TextTruncate"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["FontFace"] = v_u_18.FONT_BOLD,
	["TextXAlignment"] = Enum.TextXAlignment.Left,
	["TextTruncate"] = Enum.TextTruncate.AtEnd,
	["Position"] = UDim2.fromOffset(60, 31),
	["Size"] = UDim2.new(1, -66, 0, 16),
	["Parent"] = v133
})
local v140 = v_u_18.new("Frame", {
	["Name"] = "Nav",
	["BackgroundTransparency"] = 1,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["Position"] = UDim2.fromOffset(0, 72),
	["Size"] = UDim2.new(1, 0, 1, -96),
	["Parent"] = v132
})
v_u_18.new("UIListLayout", {
	["Padding"] = UDim.new(0, 4),
	["SortOrder"] = Enum.SortOrder.LayoutOrder,
	["Parent"] = v140
})
v_u_126.sub = v_u_18.text({
	["Name"] = "Status",
	["Text"] = "",
	["TextSize"] = 12,
	["TextColor3"] = nil,
	["TextWrapped"] = true,
	["TextXAlignment"] = nil,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["TextColor3"] = v_u_11.DIM,
	["TextXAlignment"] = Enum.TextXAlignment.Left,
	["AnchorPoint"] = Vector2.new(0, 1),
	["Position"] = UDim2.fromScale(0, 1),
	["Size"] = UDim2.new(1, 0, 0, 18),
	["Parent"] = v132
})
local v_u_141 = {}
for v142, v143 in {
	{
		["id"] = "main",
		["label"] = "\224\185\128\224\184\161\224\184\153\224\184\185\224\184\171\224\184\165\224\184\177\224\184\129",
		["icon"] = "zap"
	},
	{
		["id"] = "Top",
		["label"] = "\224\184\132\224\184\167\224\184\178\224\184\161\224\185\128\224\184\163\224\185\135\224\184\167\224\184\130\224\184\177\224\185\137\224\184\153\224\184\170\224\184\185\224\184\135\224\184\170\224\184\184\224\184\148",
		["icon"] = "gauge"
	},
	{
		["id"] = "all",
		["label"] = "\224\184\156\224\184\185\224\185\137\224\185\128\224\184\165\224\185\136\224\184\153\224\184\151\224\184\184\224\184\129\224\185\128\224\184\139\224\184\180\224\184\163\224\185\140\224\184\159",
		["icon"] = "people"
	},
	{
		["id"] = "here",
		["label"] = "\224\184\156\224\184\185\224\185\137\224\185\128\224\184\165\224\185\136\224\184\153\224\185\128\224\184\139\224\184\180\224\184\163\224\185\140\224\184\159\224\184\153\224\184\181\224\185\137",
		["icon"] = "person"
	},
	{
		["id"] = "inspect",
		["label"] = "\224\184\149\224\184\163\224\184\167\224\184\136\224\184\156\224\184\185\224\185\137\224\185\128\224\184\165\224\185\136\224\184\153",
		["icon"] = "shield"
	},
	{
		["id"] = "Watch",
		["label"] = "\224\184\163\224\184\178\224\184\162\224\184\138\224\184\183\224\185\136\224\184\173\224\185\128\224\184\157\224\185\137\224\184\178\224\184\148\224\184\185",
		["icon"] = "pin"
	},
	{
		["id"] = "Log",
		["label"] = "\224\184\155\224\184\163\224\184\176\224\184\167\224\184\177\224\184\149\224\184\180\224\185\129\224\184\173\224\184\148\224\184\161\224\184\180\224\184\153",
		["icon"] = "clock"
	},
	{
		["id"] = "codes",
		["label"] = "\224\184\132\224\185\137\224\184\153\224\184\171\224\184\178\224\185\128\224\184\136\224\185\137\224\184\178\224\184\130\224\184\173\224\184\135\224\185\130\224\184\132\224\185\137\224\184\148",
		["icon"] = "key"
	},
	{
		["id"] = "Creator",
		["label"] = "\224\184\132\224\184\163\224\184\181\224\185\128\224\184\173\224\185\128\224\184\149\224\184\173\224\184\163\224\185\140",
		["icon"] = "camera"
	},
	{
		["id"] = "Passes",
		["label"] = "\224\185\128\224\184\129\224\184\161\224\184\158\224\184\178\224\184\170",
		["icon"] = "store"
	}
} do
	local v_u_144 = v_u_18.new("TextButton", {
		["Name"] = nil,
		["Text"] = "",
		["AutoButtonColor"] = false,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["LayoutOrder"] = nil,
		["Parent"] = nil,
		["Name"] = "Nav_" .. v143.id,
		["BackgroundColor3"] = Color3.new(1, 1, 1),
		["Size"] = UDim2.new(1, 0, 0, 40),
		["LayoutOrder"] = v142,
		["Parent"] = v140
	})
	v_u_18.corner(v_u_144, 8)
	local v145 = v_u_18.new("Frame", {
		["Name"] = "Tile",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_11.ACCENT,
		["Position"] = UDim2.fromOffset(6, 6),
		["Size"] = UDim2.fromOffset(28, 28),
		["Parent"] = v_u_144
	})
	v_u_18.corner(v145, 7)
	local v146 = v_u_10.make(v143.icon, v_u_11.DIM, 15)
	local v147 = Vector2.new(0.5, 0.5)
	local v148 = UDim2.fromScale(0.5, 0.5)
	v146.AnchorPoint = v147
	v146.Position = v148
	v146.Parent = v145
	local v149 = {
		["key"] = v_u_144,
		["tile"] = v145,
		["icon"] = v146,
		["label"] = v_u_18.text({
			["Text"] = nil,
			["TextSize"] = 14,
			["FontFace"] = nil,
			["TextColor3"] = nil,
			["TextXAlignment"] = nil,
			["TextTruncate"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["Text"] = v143.label,
			["FontFace"] = v_u_18.FONT_BOLD,
			["TextColor3"] = v_u_11.DIM,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["TextTruncate"] = Enum.TextTruncate.AtEnd,
			["Position"] = UDim2.fromOffset(44, 0),
			["Size"] = UDim2.new(1, -48, 1, 0),
			["Parent"] = v_u_144
		})
	}
	v_u_141[v143.id] = v149
	v_u_144.MouseEnter:Connect(function()
		-- upvalues: (copy) v_u_144
		if v_u_144:GetAttribute("On") ~= true then
			v_u_144.BackgroundTransparency = 0.96
		end
	end)
	v_u_144.MouseLeave:Connect(function()
		-- upvalues: (copy) v_u_144
		if v_u_144:GetAttribute("On") ~= true then
			v_u_144.BackgroundTransparency = 1
		end
	end)
end
local v150 = v_u_18.new("Frame", {
	["Name"] = "Content",
	["BackgroundTransparency"] = 1,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["Position"] = UDim2.fromOffset(v125 + 22, 10),
	["Size"] = UDim2.new(1, -(v125 + 32), 1, -20),
	["Parent"] = v_u_131
})
local v151 = v_u_18.new("Frame", {
	["Name"] = "Top",
	["BackgroundTransparency"] = 1,
	["Size"] = nil,
	["Parent"] = nil,
	["Size"] = UDim2.new(1, -46, 0, 40),
	["Parent"] = v150
})
local v_u_152 = v_u_18.text({
	["Name"] = "Title",
	["Text"] = "",
	["TextSize"] = 19,
	["FontFace"] = nil,
	["TextXAlignment"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["FontFace"] = v_u_18.FONT_HEAVY,
	["TextXAlignment"] = Enum.TextXAlignment.Left,
	["Size"] = UDim2.fromScale(1, 1),
	["Parent"] = v151
})
local v_u_153 = v_u_18.new("Frame", {
	["Name"] = "Search",
	["BackgroundTransparency"] = 1,
	["Size"] = nil,
	["Visible"] = false,
	["Parent"] = nil,
	["Size"] = UDim2.fromScale(1, 1),
	["Parent"] = v151
})
local v154 = v_u_18.new("TextButton", {
	["Name"] = "Close",
	["Text"] = "",
	["AutoButtonColor"] = false,
	["BackgroundColor3"] = nil,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["BackgroundColor3"] = Color3.fromRGB(190, 32, 44),
	["AnchorPoint"] = Vector2.new(1, 0),
	["Position"] = UDim2.new(1, 0, 0, 5),
	["Size"] = UDim2.fromOffset(30, 30),
	["Parent"] = v150
})
v_u_18.corner(v154, 7)
local v155 = v_u_10.make("close", Color3.new(1, 1, 1), 14)
local v156 = Vector2.new(0.5, 0.5)
local v157 = UDim2.fromScale(0.5, 0.5)
v155.AnchorPoint = v156
v155.Position = v157
v155.Parent = v154
local v_u_158 = v_u_18.new("Frame", {
	["Name"] = "Pages",
	["BackgroundTransparency"] = 1,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["Position"] = UDim2.fromOffset(0, 52),
	["Size"] = UDim2.new(1, 0, 1, -52),
	["Parent"] = v150
})
local v159 = v_u_18.new("Frame", {
	["Name"] = "Detail",
	["BackgroundTransparency"] = 1,
	["Size"] = nil,
	["Visible"] = false,
	["Parent"] = nil,
	["Size"] = UDim2.fromScale(1, 1),
	["Parent"] = v_u_158
})
local v160 = v_u_18.new("Frame", {
	["Name"] = "Head",
	["BackgroundColor3"] = nil,
	["BorderSizePixel"] = 0,
	["Size"] = nil,
	["Parent"] = nil,
	["BackgroundColor3"] = v_u_11.PANEL,
	["Size"] = UDim2.new(1, -10, 0, 66),
	["Parent"] = v159
})
v_u_18.corner(v160, 10)
v_u_18.border(v160, Color3.new(1, 1, 1), 0.93, 1)
local v_u_161 = v_u_18.new("Frame", {
	["Name"] = "Glow",
	["BackgroundColor3"] = nil,
	["BackgroundTransparency"] = 0.78,
	["BorderSizePixel"] = 0,
	["Size"] = nil,
	["ZIndex"] = 0,
	["Parent"] = nil,
	["BackgroundColor3"] = v_u_11.ACCENT,
	["Size"] = UDim2.fromScale(1, 1),
	["Parent"] = v160
})
v_u_18.corner(v_u_161, 10)
v_u_18.new("UIGradient", {
	["Transparency"] = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.55, 1), NumberSequenceKeypoint.new(1, 1) }),
	["Parent"] = v_u_161
})
local v162 = v_u_18.button({
	["name"] = "Back",
	["text"] = "\226\128\185  \224\184\129\224\184\165\224\184\177\224\184\154",
	["grad"] = "dark",
	["textSize"] = 14,
	["anchor"] = nil,
	["position"] = nil,
	["size"] = nil,
	["parent"] = nil,
	["anchor"] = Vector2.new(0, 0.5),
	["position"] = UDim2.new(0, 12, 0.5, 0),
	["size"] = UDim2.fromOffset(84, 36),
	["parent"] = v160
})
local v_u_163 = v_u_18.new("ImageLabel", {
	["BackgroundColor3"] = nil,
	["Image"] = "",
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["BackgroundColor3"] = v_u_11.ROW,
	["Position"] = UDim2.fromOffset(110, 11),
	["Size"] = UDim2.fromOffset(44, 44),
	["Parent"] = v160
})
v_u_18.corner(v_u_163, 22)
local v_u_164 = v_u_18.text({
	["Text"] = "",
	["TextSize"] = 18,
	["FontFace"] = nil,
	["TextXAlignment"] = nil,
	["TextTruncate"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["FontFace"] = v_u_18.FONT_HEAVY,
	["TextXAlignment"] = Enum.TextXAlignment.Left,
	["TextTruncate"] = Enum.TextTruncate.AtEnd,
	["Position"] = UDim2.fromOffset(166, 12),
	["Size"] = UDim2.new(1, -176, 0, 22),
	["Parent"] = v160
})
local v_u_165 = v_u_18.text({
	["Text"] = "",
	["TextSize"] = 13,
	["FontFace"] = nil,
	["TextColor3"] = nil,
	["TextXAlignment"] = nil,
	["RichText"] = true,
	["TextTruncate"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["FontFace"] = v_u_18.FONT_BOLD,
	["TextColor3"] = v_u_11.DIM,
	["TextXAlignment"] = Enum.TextXAlignment.Left,
	["TextTruncate"] = Enum.TextTruncate.AtEnd,
	["Position"] = UDim2.fromOffset(166, 36),
	["Size"] = UDim2.new(1, -176, 0, 18),
	["Parent"] = v160
})
local v166 = v_u_18.new("Frame", {
	["Name"] = "Tabs",
	["BackgroundTransparency"] = 1,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["Position"] = UDim2.fromOffset(0, 76),
	["Size"] = UDim2.new(1, -10, 0, 36),
	["Parent"] = v159
})
v_u_18.new("UIListLayout", {
	["FillDirection"] = Enum.FillDirection.Horizontal,
	["Padding"] = UDim.new(0, 8),
	["SortOrder"] = Enum.SortOrder.LayoutOrder,
	["Parent"] = v166
})
local v_u_167 = v_u_18.new("ScrollingFrame", {
	["Name"] = "Body",
	["BackgroundTransparency"] = 1,
	["BorderSizePixel"] = 0,
	["Position"] = nil,
	["Size"] = nil,
	["CanvasSize"] = nil,
	["AutomaticCanvasSize"] = nil,
	["ScrollingDirection"] = nil,
	["ScrollBarThickness"] = 4,
	["Parent"] = nil,
	["Position"] = UDim2.fromOffset(0, 122),
	["Size"] = UDim2.new(1, 0, 1, -122),
	["CanvasSize"] = UDim2.new(),
	["AutomaticCanvasSize"] = Enum.AutomaticSize.Y,
	["ScrollingDirection"] = Enum.ScrollingDirection.Y,
	["Parent"] = v159
})
v_u_18.new("UIPadding", {
	["PaddingLeft"] = UDim.new(0, 2),
	["PaddingTop"] = UDim.new(0, 2),
	["PaddingBottom"] = UDim.new(0, 14),
	["Parent"] = v_u_167
})
v_u_18.new("UIListLayout", {
	["Padding"] = UDim.new(0, 12),
	["SortOrder"] = Enum.SortOrder.LayoutOrder,
	["Parent"] = v_u_167
})
local v_u_168 = {}
local function v_u_178(p169) -- name: paintNav
	-- upvalues: (copy) v_u_141, (copy) v_u_28, (copy) v_u_11
	for v170, v171 in v_u_141 do
		local v172 = v170 == p169
		v171.key:SetAttribute("On", v172)
		v171.key.BackgroundTransparency = v172 and 0.93 or 1
		v171.tile.BackgroundTransparency = v172 and 0 or 1
		local v173 = v_u_28
		local v174 = v171.icon
		local v175
		if v172 then
			v175 = Color3.new(1, 1, 1)
		else
			v175 = v_u_11.DIM
		end
		v173(v174, v175)
		local v176 = v171.label
		local v177
		if v172 then
			v177 = Color3.new(1, 1, 1)
		else
			v177 = v_u_11.DIM
		end
		v176.TextColor3 = v177
	end
end
for v179, v180 in {
	{
		["id"] = "info",
		["label"] = "\224\184\130\224\185\137\224\184\173\224\184\161\224\184\185\224\184\165 & \224\184\132\224\184\179\224\184\170\224\184\177\224\185\136\224\184\135"
	},
	{
		["id"] = "vehicles",
		["label"] = "\224\184\163\224\184\150\224\184\151\224\184\177\224\185\137\224\184\135\224\184\171\224\184\161\224\184\148"
	},
	{
		["id"] = "passes",
		["label"] = "\224\185\128\224\184\129\224\184\161\224\184\158\224\184\178\224\184\170"
	},
	{
		["id"] = "items",
		["label"] = "\224\184\130\224\184\173\224\184\135\224\185\131\224\184\153\224\184\149\224\184\177\224\184\167"
	}
} do
	local v181 = v_u_18.new("TextButton", {
		["Name"] = nil,
		["Text"] = nil,
		["TextSize"] = 14,
		["FontFace"] = nil,
		["TextColor3"] = nil,
		["AutoButtonColor"] = false,
		["BackgroundColor3"] = nil,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = nil,
		["Parent"] = nil,
		["Name"] = "Tab_" .. v180.id,
		["Text"] = v180.label,
		["FontFace"] = v_u_18.FONT_BOLD,
		["TextColor3"] = v_u_11.DIM,
		["BackgroundColor3"] = v_u_11.PANEL,
		["Size"] = UDim2.fromScale(0, 1),
		["AutomaticSize"] = Enum.AutomaticSize.X,
		["LayoutOrder"] = v179,
		["Parent"] = v166
	})
	v_u_18.corner(v181, 8)
	v_u_18.new("UIPadding", {
		["PaddingLeft"] = UDim.new(0, 18),
		["PaddingRight"] = UDim.new(0, 18),
		["Parent"] = v181
	})
	v_u_168[v180.id] = v181
end
local v_u_182 = nil
local v_u_183 = nil
local v_u_184 = nil
local function v187(p185) -- name: scroller
	-- upvalues: (copy) v_u_18, (copy) v_u_158
	local v186 = v_u_18.new("ScrollingFrame", {
		["Name"] = nil,
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["CanvasSize"] = nil,
		["AutomaticCanvasSize"] = nil,
		["ScrollingDirection"] = nil,
		["ScrollBarThickness"] = 5,
		["Visible"] = false,
		["Parent"] = nil,
		["Name"] = p185,
		["Size"] = UDim2.fromScale(1, 1),
		["CanvasSize"] = UDim2.new(),
		["AutomaticCanvasSize"] = Enum.AutomaticSize.Y,
		["ScrollingDirection"] = Enum.ScrollingDirection.Y,
		["Parent"] = v_u_158
	})
	v_u_18.new("UIPadding", {
		["PaddingLeft"] = UDim.new(0, 2),
		["PaddingTop"] = UDim.new(0, 2),
		["PaddingRight"] = UDim.new(0, 8),
		["PaddingBottom"] = UDim.new(0, 12),
		["Parent"] = v186
	})
	v_u_18.new("UIListLayout", {
		["Padding"] = UDim.new(0, 10),
		["SortOrder"] = Enum.SortOrder.LayoutOrder,
		["Parent"] = v186
	})
	return v186
end
local v_u_188 = v187("Players")
local v_u_189 = v187("Server")
local v_u_190 = v187("Log")
local v_u_191 = v187("Money")
local v_u_192 = v187("Watch")
local v_u_193 = v187("Creator")
local v_u_194 = v187("Codes")
local v_u_195 = v187("Top")
local v_u_196 = v187("Passes")
local v_u_197 = v187("Main")
local v_u_198 = v187("Here")
local v_u_199 = v187("Inspect")
local v_u_200 = {}
local function v_u_209(p201, p202, p203) -- name: card
	-- upvalues: (copy) v_u_18
	local v204 = v_u_18.new
	local v205 = "Frame"
	local v206 = {
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_18.CARD,
		["Size"] = UDim2.new(1, 0, 0, p203 or 0)
	}
	local v207
	if p203 then
		v207 = Enum.AutomaticSize.None
	else
		v207 = Enum.AutomaticSize.Y
	end
	v206.AutomaticSize = v207
	v206.LayoutOrder = p202
	v206.Parent = p201
	local v208 = v204(v205, v206)
	v_u_18.corner(v208, 14)
	v_u_18.border(v208, Color3.new(1, 1, 1), 0.88, 1)
	v_u_18.padding(v208, 12, 10)
	return v208
end
local function v_u_220(p210, p211, p212) -- name: box
	-- upvalues: (copy) v_u_18
	local v213 = v_u_18.new("Frame", {
		["BackgroundColor3"] = v_u_18.CARD_DARK,
		["Size"] = UDim2.new(1, 0, 0, 40),
		["Parent"] = p210
	})
	v_u_18.corner(v213, 10)
	local v_u_214 = v_u_18.border(v213, Color3.new(1, 1, 1), 0.82, 1.2)
	local v215 = v_u_18.new("TextBox", {
		["BackgroundTransparency"] = 1,
		["Text"] = "",
		["PlaceholderText"] = nil,
		["PlaceholderColor3"] = nil,
		["ClearTextOnFocus"] = false,
		["FontFace"] = nil,
		["TextSize"] = 16,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["PlaceholderText"] = p211,
		["PlaceholderColor3"] = Color3.fromRGB(110, 114, 130),
		["FontFace"] = v_u_18.FONT_BOLD,
		["TextColor3"] = v_u_18.TEXT,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["Position"] = UDim2.fromOffset(12, 0),
		["Size"] = UDim2.new(1, -24, 1, 0),
		["Parent"] = v213
	})
	v215.Focused:Connect(function()
		-- upvalues: (copy) v_u_214, (ref) v_u_18
		local v216 = v_u_214
		v_u_214.Color = v_u_18.YELLOW
		v216.Transparency = 0.2
	end)
	v215.FocusLost:Connect(function()
		-- upvalues: (copy) v_u_214
		local v217 = v_u_214
		v_u_214.Color = Color3.new(1, 1, 1)
		v217.Transparency = 0.82
	end)
	for v218, v219 in p212 or {} do
		v213[v218] = v219
	end
	return v215, v213
end
local function v_u_244(p221, p222, p223, p_u_224) -- name: buttonRow
	-- upvalues: (copy) v_u_18, (ref) v_u_200
	local v_u_225 = v_u_18.new("Frame", {
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["LayoutOrder"] = nil,
		["Parent"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 42),
		["LayoutOrder"] = p222,
		["Parent"] = p221
	})
	local v_u_226 = v_u_18.new("UIGridLayout", {
		["CellPadding"] = UDim2.fromOffset(8, 8),
		["SortOrder"] = Enum.SortOrder.LayoutOrder,
		["Parent"] = v_u_225
	})
	local v_u_227 = 0
	local function v239() -- name: layout
		-- upvalues: (ref) v_u_18, (copy) v_u_225, (ref) v_u_227, (copy) p_u_224, (copy) v_u_226
		local v228 = v_u_18.unscaledSize(v_u_225).X
		if v228 > 0 then
			local v229 = v_u_227
			local v230 = math.max(v229, 1)
			local v231 = (v228 + 8) / ((p_u_224 or 122) + 8)
			local v232 = math.floor(v231)
			local v233 = math.clamp(v232, 1, v230)
			local v234 = v_u_226
			local v235 = UDim2.fromOffset
			local v236 = (v228 - (v233 - 1) * 8) / v233
			v234.CellSize = v235(math.floor(v236), 42)
			local v237 = v230 / v233
			local v238 = math.ceil(v237)
			v_u_225.Size = UDim2.new(1, 0, 0, v238 * 42 + (v238 - 1) * 8)
		end
	end
	v_u_225:GetPropertyChangedSignal("AbsoluteSize"):Connect(v239)
	task.defer(v239)
	local v240 = v_u_227
	for v241, v242 in p223 do
		if v242[5] and not v_u_200[v242[5]] then
			continue
		end
		v_u_227 = v240 + 1
		local v243 = v_u_18.button({
			["text"] = nil,
			["grad"] = nil,
			["icon"] = nil,
			["textSize"] = 15,
			["parent"] = nil,
			["text"] = v242[1],
			["grad"] = v242[2],
			["icon"] = v242[3],
			["parent"] = v_u_225
		})
		v243.LayoutOrder = v241
		v243.Activated:Connect(v242[4])
		v240 = v_u_227
	end
	v_u_225.Visible = v240 > 0
	return v_u_225
end
local function v_u_248(p245, p246, p247) -- name: heading
	-- upvalues: (copy) v_u_18
	return v_u_18.text({
		["Text"] = nil,
		["TextSize"] = 17,
		["FontFace"] = nil,
		["TextXAlignment"] = nil,
		["Size"] = nil,
		["LayoutOrder"] = nil,
		["Parent"] = nil,
		["Text"] = p247,
		["FontFace"] = v_u_18.FONT_HEAVY,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["Size"] = UDim2.new(1, 0, 0, 22),
		["LayoutOrder"] = p246,
		["Parent"] = p245
	})
end
local v_u_249 = nil
local v_u_250 = nil
local v_u_251 = 1
local v_u_252 = nil
local v_u_253 = ""
local v_u_254 = nil
local v255 = v_u_18.new("Frame", {
	["BackgroundTransparency"] = 1,
	["Size"] = nil,
	["LayoutOrder"] = 1,
	["Parent"] = nil,
	["Size"] = UDim2.new(1, 0, 0, 40),
	["Parent"] = v_u_153
})
local v_u_256, v257 = v_u_220(v255, "\240\159\148\142   \224\184\132\224\185\137\224\184\153\224\184\171\224\184\178\224\184\138\224\184\183\224\185\136\224\184\173\224\184\156\224\184\185\224\185\137\224\185\128\224\184\165\224\185\136\224\184\153 \224\184\171\224\184\163\224\184\183\224\184\173\224\184\138\224\184\183\224\185\136\224\184\173\224\185\128\224\184\129\224\184\161\224\184\158\224\184\178\224\184\170\226\128\166")
v257.Size = UDim2.new(1, -48, 1, 0)
local v258 = v_u_18.button({
	["text"] = "",
	["icon"] = "zap",
	["grad"] = "dark",
	["textSize"] = 15,
	["anchor"] = nil,
	["position"] = nil,
	["size"] = nil,
	["parent"] = nil,
	["anchor"] = Vector2.new(1, 0),
	["position"] = UDim2.fromScale(1, 0),
	["size"] = UDim2.new(0, 40, 1, 0),
	["parent"] = v255
})
local v_u_259 = 0
v_u_256:GetPropertyChangedSignal("Text"):Connect(function()
	-- upvalues: (ref) v_u_253, (copy) v_u_256, (ref) v_u_251, (ref) v_u_259, (ref) v_u_254
	v_u_253 = v_u_256.Text:lower()
	v_u_251 = 1
	v_u_259 = v_u_259 + 1
	local v_u_260 = v_u_259
	task.delay(0.35, function()
		-- upvalues: (copy) v_u_260, (ref) v_u_259, (ref) v_u_254
		if v_u_260 == v_u_259 then
			v_u_254()
		end
	end)
end)
local v_u_261 = v_u_18.new("Frame", {
	["BackgroundTransparency"] = 1,
	["Size"] = nil,
	["AutomaticSize"] = nil,
	["LayoutOrder"] = 3,
	["Parent"] = nil,
	["Size"] = UDim2.new(1, 0, 0, 0),
	["AutomaticSize"] = Enum.AutomaticSize.Y,
	["Parent"] = v_u_188
})
v_u_18.new("UIListLayout", {
	["Padding"] = UDim.new(0, 6),
	["SortOrder"] = Enum.SortOrder.LayoutOrder,
	["Parent"] = v_u_261
})
local function v_u_264(p262) -- name: clear
	for _, v263 in p262:GetChildren() do
		if not v263:IsA("GuiObject") then
			continue
		end
		v263:Destroy()
	end
end
local v_u_265 = Color3.fromRGB(255, 205, 90)
local function v_u_288(p266, p267, p_u_268) -- name: playerRow
	-- upvalues: (copy) v_u_18, (copy) v_u_11, (copy) v_u_7, (ref) v_u_183
	local v269 = v_u_18.new
	local v270 = {
		["Name"] = nil,
		["Text"] = "",
		["AutoButtonColor"] = false,
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["LayoutOrder"] = nil,
		["Parent"] = nil
	}
	local v271 = p_u_268.id
	v270.Name = "P_" .. tostring(v271)
	v270.BackgroundColor3 = v_u_11.PANEL
	v270.Size = UDim2.new(1, -10, 0, 60)
	v270.LayoutOrder = p267
	v270.Parent = p266
	local v_u_272 = v269("TextButton", v270)
	v_u_18.corner(v_u_272, 10)
	v_u_18.border(v_u_272, Color3.new(1, 1, 1), 0.94, 1)
	local v273 = v_u_18.new
	local v274 = {
		["BackgroundColor3"] = v_u_11.ROW
	}
	local v275 = p_u_268.id
	v274.Image = ("rbxthumb://type=AvatarHeadShot&id=%d&w=150&h=150"):format(tonumber(v275) or 1)
	v274.AnchorPoint = Vector2.new(0, 0.5)
	v274.Position = UDim2.new(0, 10, 0.5, 0)
	v274.Size = UDim2.fromOffset(40, 40)
	v274.Parent = v_u_272
	local v276 = v273("ImageLabel", v274)
	v_u_18.corner(v276, 20)
	local v277 = v_u_7.info(p_u_268.rank)
	local v278 = v_u_18.text
	local v279 = {
		["Text"] = nil,
		["TextSize"] = 15,
		["FontFace"] = nil,
		["TextXAlignment"] = nil,
		["TextTruncate"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil
	}
	local v280 = p_u_268.name
	v279.Text = tostring(v280)
	v279.FontFace = v_u_18.FONT_BOLD
	v279.TextXAlignment = Enum.TextXAlignment.Left
	v279.TextTruncate = Enum.TextTruncate.AtEnd
	v279.Position = UDim2.fromOffset(62, 10)
	v279.Size = UDim2.new(0.46, -62, 0, 20)
	v279.Parent = v_u_272
	v278(v279)
	local v281 = v_u_18.text
	local v282 = {
		["Text"] = nil,
		["TextSize"] = 12,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["TextTruncate"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil
	}
	local v283 = p_u_268.display
	v282.Text = tostring(v283)
	v282.TextColor3 = v_u_11.DIM
	v282.TextXAlignment = Enum.TextXAlignment.Left
	v282.TextTruncate = Enum.TextTruncate.AtEnd
	v282.Position = UDim2.fromOffset(62, 31)
	v282.Size = UDim2.new(0.46, -62, 0, 16)
	v282.Parent = v_u_272
	v281(v282)
	local v284 = v_u_18.new("Frame", {
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.82,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = v277.color,
		["AnchorPoint"] = Vector2.new(0, 0.5),
		["Position"] = UDim2.new(0.46, 0, 0.5, 0),
		["Size"] = UDim2.fromOffset(0, 24),
		["AutomaticSize"] = Enum.AutomaticSize.X,
		["Parent"] = v_u_272
	})
	v_u_18.corner(v284, 12)
	v_u_18.new("UIPadding", {
		["PaddingLeft"] = UDim.new(0, 10),
		["PaddingRight"] = UDim.new(0, 10),
		["Parent"] = v284
	})
	v_u_18.text({
		["Text"] = nil,
		["TextSize"] = 12,
		["FontFace"] = nil,
		["TextColor3"] = nil,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["Parent"] = nil,
		["Text"] = v_u_7.label(p_u_268.rank),
		["FontFace"] = v_u_18.FONT_BOLD,
		["TextColor3"] = v277.color,
		["Size"] = UDim2.fromScale(0, 1),
		["AutomaticSize"] = Enum.AutomaticSize.X,
		["Parent"] = v284
	})
	local v285 = v_u_18.text
	local v286 = {
		["Text"] = nil,
		["TextSize"] = 12,
		["FontFace"] = nil,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil
	}
	local v287 = p_u_268.where
	v286.Text = tostring(v287) .. ((p_u_268.passes or 0) <= 0 and "" or ("     \240\159\146\142 %d"):format(p_u_268.passes))
	v286.FontFace = v_u_18.FONT_BOLD
	v286.TextColor3 = v_u_11.DIM
	v286.TextXAlignment = Enum.TextXAlignment.Right
	v286.AnchorPoint = Vector2.new(1, 0.5)
	v286.Position = UDim2.new(1, -34, 0.5, 0)
	v286.Size = UDim2.new(0.28, 0, 0, 18)
	v286.Parent = v_u_272
	v285(v286)
	v_u_18.text({
		["Text"] = "\226\128\186",
		["TextSize"] = 24,
		["FontFace"] = nil,
		["TextColor3"] = nil,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["FontFace"] = v_u_18.FONT_BOLD,
		["TextColor3"] = v_u_11.DIM,
		["AnchorPoint"] = Vector2.new(1, 0.5),
		["Position"] = UDim2.new(1, -12, 0.5, -2),
		["Size"] = UDim2.fromOffset(14, 30),
		["Parent"] = v_u_272
	})
	v_u_272.MouseEnter:Connect(function()
		-- upvalues: (copy) v_u_272, (ref) v_u_11
		v_u_272.BackgroundColor3 = v_u_11.ROW
	end)
	v_u_272.MouseLeave:Connect(function()
		-- upvalues: (copy) v_u_272, (ref) v_u_11
		v_u_272.BackgroundColor3 = v_u_11.PANEL
	end)
	v_u_272.Activated:Connect(function()
		-- upvalues: (ref) v_u_183, (copy) p_u_268
		v_u_183(p_u_268.id, "info", p_u_268.entry)
	end)
	return v_u_272
end
local function v_u_296(p289, p290, p291, _, p292) -- name: row
	-- upvalues: (copy) v_u_288
	local v293 = v_u_288
	local v294 = {
		["id"] = p291.id,
		["name"] = p291.name,
		["display"] = p291.display,
		["rank"] = p291.rank,
		["where"] = p292 and "\224\185\128\224\184\139\224\184\180\224\184\163\224\185\140\224\184\159\224\184\153\224\184\181\224\185\137" or "\224\184\173\224\184\181\224\184\129\224\185\128\224\184\139\224\184\180\224\184\163\224\185\140\224\184\159"
	}
	local v295 = p291.passes
	v294.passes = type(v295) == "table" and #p291.passes or 0
	v294.entry = p291
	v293(p289, p290, v294)
end
local function v_u_315() -- name: passSummary
	-- upvalues: (ref) v_u_250, (copy) v_u_264, (copy) v_u_196, (copy) v_u_18, (ref) v_u_253, (copy) v_u_265, (copy) v_u_256, (ref) v_u_182
	local v297 = {}
	local v298 = {}
	for _, v299 in v_u_250.passes or {} do
		local v300 = v299.name
		table.insert(v297, v300)
		v298[v299.name] = v299.count
	end
	v_u_264(v_u_196)
	local v_u_301 = v_u_18.new("Frame", {
		["Name"] = "Passes",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = 0,
		["Parent"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y,
		["Parent"] = v_u_196
	})
	v_u_18.new("UIListLayout", {
		["FillDirection"] = nil,
		["Wraps"] = true,
		["Padding"] = nil,
		["SortOrder"] = nil,
		["Parent"] = nil,
		["FillDirection"] = Enum.FillDirection.Horizontal,
		["Padding"] = UDim.new(0, 6),
		["SortOrder"] = Enum.SortOrder.LayoutOrder,
		["Parent"] = v_u_301
	})
	local function v312(p302, p303, p_u_304) -- name: chip
		-- upvalues: (ref) v_u_253, (ref) v_u_18, (ref) v_u_265, (copy) v_u_301, (ref) v_u_256, (ref) v_u_182
		local v_u_305
		if p_u_304 == nil then
			v_u_305 = false
		else
			v_u_305 = v_u_253 == p_u_304:lower()
		end
		local v306 = v_u_18.new
		local v307 = "TextButton"
		local v308 = {
			["Text"] = nil,
			["TextSize"] = 14,
			["FontFace"] = nil,
			["TextColor3"] = nil,
			["AutoButtonColor"] = false,
			["BackgroundColor3"] = nil,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["LayoutOrder"] = nil,
			["Parent"] = nil,
			["Text"] = p302,
			["FontFace"] = v_u_18.FONT_BOLD
		}
		local v309
		if v_u_305 then
			v309 = v_u_18.DARK_TEXT
		else
			v309 = v_u_265
		end
		v308.TextColor3 = v309
		local v310
		if v_u_305 then
			v310 = v_u_265
		else
			v310 = v_u_18.CARD_DARK
		end
		v308.BackgroundColor3 = v310
		v308.Size = UDim2.fromOffset(0, 30)
		v308.AutomaticSize = Enum.AutomaticSize.X
		v308.LayoutOrder = p303
		v308.Parent = v_u_301
		local v311 = v306(v307, v308)
		v_u_18.corner(v311, 15)
		v_u_18.new("UIPadding", {
			["PaddingLeft"] = UDim.new(0, 12),
			["PaddingRight"] = UDim.new(0, 12),
			["Parent"] = v311
		})
		if p_u_304 then
			v311.Activated:Connect(function()
				-- upvalues: (ref) v_u_256, (copy) v_u_305, (copy) p_u_304, (ref) v_u_182
				v_u_256.Text = v_u_305 and "" or p_u_304
				v_u_182("all")
			end)
		end
	end
	v312(#v297 > 0 and "\240\159\146\142 Game passes:" or "\240\159\146\142 Nobody on has a game pass", 0, nil)
	for v313, v314 in v297 do
		v312(("%s  %d"):format(v314, v298[v314]), v313, v314)
	end
end
local function v_u_320(p316) -- name: pager
	-- upvalues: (copy) v_u_18, (copy) v_u_261, (ref) v_u_251, (ref) v_u_254, (copy) v_u_188, (ref) v_u_250
	local v317 = v_u_18.new("Frame", {
		["Name"] = "Pager",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["LayoutOrder"] = nil,
		["Parent"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 40),
		["LayoutOrder"] = p316,
		["Parent"] = v_u_261
	})
	local v318 = v_u_18.button({
		["text"] = "\226\151\128",
		["grad"] = "dark",
		["textSize"] = 15,
		["size"] = nil,
		["parent"] = nil,
		["size"] = UDim2.new(0, 48, 1, 0),
		["parent"] = v317
	})
	v318.Visible = v_u_250.page > 1
	v318.Activated:Connect(function()
		-- upvalues: (ref) v_u_250, (ref) v_u_251, (ref) v_u_254, (ref) v_u_188
		v_u_251 = v_u_250.page - 1
		v_u_254()
		v_u_188.CanvasPosition = Vector2.zero
	end)
	local v319 = v_u_18.button({
		["text"] = "\226\150\182",
		["grad"] = "dark",
		["textSize"] = 15,
		["anchor"] = nil,
		["position"] = nil,
		["size"] = nil,
		["parent"] = nil,
		["anchor"] = Vector2.new(1, 0),
		["position"] = UDim2.fromScale(1, 0),
		["size"] = UDim2.new(0, 48, 1, 0),
		["parent"] = v317
	})
	v319.Visible = v_u_250.page < v_u_250.pages
	v319.Activated:Connect(function()
		-- upvalues: (ref) v_u_250, (ref) v_u_251, (ref) v_u_254, (ref) v_u_188
		v_u_251 = v_u_250.page + 1
		v_u_254()
		v_u_188.CanvasPosition = Vector2.zero
	end)
	v_u_18.text({
		["Text"] = nil,
		["TextSize"] = 13,
		["FontFace"] = nil,
		["TextColor3"] = nil,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Text"] = ("%d / %d   \194\183   %d-%d of %d"):format(v_u_250.page, v_u_250.pages, v_u_250.from, v_u_250.from + #v_u_250.rows - 1, v_u_250.matches),
		["FontFace"] = v_u_18.FONT_BOLD,
		["TextColor3"] = v_u_18.TEXT_DIM,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.5),
		["Size"] = UDim2.new(1, -110, 1, 0),
		["Parent"] = v317
	})
end
local function v_u_329() -- name: buildPlayers
	-- upvalues: (copy) v_u_264, (copy) v_u_261, (ref) v_u_250, (copy) v_u_315, (copy) v_u_248, (copy) v_u_296, (copy) v_u_18, (ref) v_u_253, (copy) v_u_320, (copy) v_u_126
	v_u_264(v_u_261)
	if v_u_250 then
		v_u_315()
		local v321 = nil
		local v322 = 0
		for _, v323 in v_u_250.rows do
			if v323.index ~= v321 then
				v321 = v323.index
				v322 = v322 + 1
				v_u_248(v_u_261, v322, (v323.here and "This server" or "Server " .. v323.index) .. (v323.private and "  \240\159\145\145 VIP server" or "") .. "  (" .. v323.size .. ")")
			end
			v322 = v322 + 1
			v_u_296(v_u_261, v322, v323.entry, v323.job, v323.here)
		end
		if #v_u_250.rows == 0 then
			v322 = v322 + 1
			v_u_18.text({
				["Text"] = nil,
				["TextSize"] = 16,
				["TextColor3"] = nil,
				["Size"] = nil,
				["LayoutOrder"] = nil,
				["Parent"] = nil,
				["Text"] = v_u_253 == "" and "Nobody on" or "No one found",
				["TextColor3"] = v_u_18.TEXT_DIM,
				["Size"] = UDim2.new(1, 0, 0, 40),
				["LayoutOrder"] = v322,
				["Parent"] = v_u_261
			})
		end
		if v_u_250.pages > 1 then
			v_u_320(v322 + 1)
		end
		local v324 = v_u_126.sub
		local v325 = ("%d players in %d servers"):format(v_u_250.total, v_u_250.serverCount)
		local v326 = v_u_253 == "" and "" or ("   \194\183   %d found"):format(v_u_250.matches)
		local v327
		if v_u_250.note then
			local v328 = v_u_250.note
			v327 = "   \194\183   \224\184\173\224\185\136\224\184\178\224\184\153\224\185\128\224\184\139\224\184\180\224\184\163\224\185\140\224\184\159\224\184\173\224\184\183\224\185\136\224\184\153\224\185\132\224\184\161\224\185\136\224\185\132\224\184\148\224\185\137: " .. tostring(v328)
		else
			v327 = ""
		end
		v324.Text = v325 .. v326 .. v327
	end
end
local v_u_330 = false
local v_u_331 = false
v_u_254 = function() -- name: refresh
	-- upvalues: (ref) v_u_330, (ref) v_u_331, (copy) v_u_106, (ref) v_u_253, (ref) v_u_251, (ref) v_u_252, (ref) v_u_200, (ref) v_u_250, (ref) v_u_249, (ref) v_u_184, (copy) v_u_197, (ref) v_u_329, (ref) v_u_254
	if v_u_330 then
		v_u_331 = true
	else
		v_u_330 = true
		local v332 = v_u_106
		local v333 = "List"
		local v334 = v_u_253
		local v335 = v_u_251
		local v336 = v_u_252
		if v336 then
			v336 = v_u_252.entry.id
		end
		local v337, v338 = v332(v333, v334, v335, v336)
		v_u_330 = false
		if v337 and type(v338) == "table" then
			local v339 = v338.rows
			if type(v339) == "table" then
				local v340 = v_u_200
				local v341 = v338.allowed
				v_u_200 = type(v341) == "table" and (v338.allowed or {}) or {}
				v_u_250 = v338
				v_u_251 = v338.page
				local v342 = false
				for v343, v344 in v_u_200 do
					if v340[v343] == v344 then
						continue
					end
					v342 = true
				end
				if v342 then
					v_u_249()
					if v_u_184 and v_u_197.Visible then
						v_u_184()
					end
				end
				if v_u_252 then
					local v345 = v338.selected
					v_u_252 = type(v345) == "table" and {
						["entry"] = v338.selected.entry,
						["job"] = v338.selected.job,
						["here"] = v338.selected.here
					} or nil
				end
				v_u_329()
			end
		end
		if v_u_331 then
			v_u_331 = false
			v_u_254()
		end
	end
end
v258.Activated:Connect(v_u_254)
v_u_249 = function()
	-- upvalues: (copy) v_u_264, (copy) v_u_189, (copy) v_u_209, (ref) v_u_200, (copy) v_u_18, (copy) v_u_248, (copy) v_u_220, (copy) v_u_244, (copy) v_u_106, (copy) v_u_53, (copy) v_u_5, (copy) v_u_7
	v_u_264(v_u_189)
	local v346 = v_u_209(v_u_189, 1)
	v346.Visible = v_u_200.Announce == true
	v_u_18.new("UIListLayout", {
		["Padding"] = UDim.new(0, 8),
		["SortOrder"] = Enum.SortOrder.LayoutOrder,
		["Parent"] = v346
	})
	v_u_248(v346, 1, "\240\159\147\162 Announce to every server")
	local v_u_347 = v_u_220(v346, "Message\226\128\166", {
		["LayoutOrder"] = 2
	})
	v_u_244(v346, 3, {
		{
			"Send",
			"gold",
			"zap",
			function()
				-- upvalues: (ref) v_u_106, (copy) v_u_347, (ref) v_u_53
				local v348, v349 = v_u_106("Announce", v_u_347.Text)
				if v349 then
					v_u_53.show(tostring(v349), v348 and "ok" or "error")
				end
				if v348 then
					v_u_347.Text = ""
				end
			end
		}
	})
	local v350 = v_u_209(v_u_189, 0)
	v350.Visible = v_u_200.MySpeed == true
	v_u_18.new("UIListLayout", {
		["Padding"] = UDim.new(0, 8),
		["SortOrder"] = Enum.SortOrder.LayoutOrder,
		["Parent"] = v350
	})
	v_u_248(v350, 1, "\240\159\143\141\239\184\143 My vehicle speed")
	local v351 = {}
	for _, v_u_352 in v_u_5.ADMIN_SPEEDS do
		local v355 = {
			("x%g"):format(v_u_352),
			v_u_352 == 1 and "green" or "dark",
			nil,
			function()
				-- upvalues: (ref) v_u_106, (copy) v_u_352, (ref) v_u_53
				local v353, v354 = v_u_106("MySpeed", v_u_352)
				if v354 then
					v_u_53.show(tostring(v354), v353 and "ok" or "error")
				end
			end,
			"MySpeed"
		}
		table.insert(v351, v355)
	end
	v_u_244(v350, 2, v351, 72)
	local v356 = v_u_209(v_u_189, 2)
	v356.Visible = v_u_200.GiveAll == true
	v_u_18.new("UIListLayout", {
		["Padding"] = UDim.new(0, 8),
		["SortOrder"] = Enum.SortOrder.LayoutOrder,
		["Parent"] = v356
	})
	v_u_248(v356, 1, "\240\159\146\176 Give everyone money (every server)")
	local v_u_357 = v_u_220(v356, "Amount (\224\184\191)", {
		["LayoutOrder"] = 2
	})
	v_u_244(v356, 3, {
		{
			"Give everyone",
			"green",
			"coin",
			function()
				-- upvalues: (ref) v_u_106, (copy) v_u_357, (ref) v_u_53
				local v358 = v_u_106
				local v359 = v_u_357.Text:gsub("[,%s]", "")
				local v360, v361 = v358("GiveAll", (tonumber(v359)))
				if v361 then
					v_u_53.show(tostring(v361), v360 and "ok" or "error")
				end
			end
		}
	})
	local v362 = v_u_209(v_u_189, 3)
	v362.Visible = v_u_200.Ban == true and true or v_u_200.Unban == true
	v_u_18.new("UIListLayout", {
		["Padding"] = UDim.new(0, 8),
		["SortOrder"] = Enum.SortOrder.LayoutOrder,
		["Parent"] = v362
	})
	v_u_248(v362, 1, "\240\159\148\168 Ban / unban by username")
	local v_u_363 = v_u_220(v362, "Username", {
		["LayoutOrder"] = 2
	})
	local v_u_364 = v_u_220(v362, "Ban hours (empty or 0 = forever)", {
		["LayoutOrder"] = 3
	})
	local v_u_365 = v_u_220(v362, "Reason", {
		["LayoutOrder"] = 4
	})
	v_u_244(v362, 5, {
		{
			"Ban",
			"red",
			"lock",
			function()
				-- upvalues: (ref) v_u_106, (copy) v_u_363, (copy) v_u_364, (copy) v_u_365, (ref) v_u_53
				local v366 = v_u_106
				local v367 = v_u_363.Text
				local v368 = v_u_364.Text
				local v369, v370 = v366("Ban", v367, tonumber(v368) or 0, v_u_365.Text)
				if v370 then
					v_u_53.show(tostring(v370), v369 and "ok" or "error")
				end
			end,
			"Ban"
		},
		{
			"Unban",
			"dark",
			"key",
			function()
				-- upvalues: (ref) v_u_106, (copy) v_u_363, (ref) v_u_53
				local v371, v372 = v_u_106("Unban", v_u_363.Text)
				if v372 then
					v_u_53.show(tostring(v372), v371 and "ok" or "error")
				end
			end,
			"Unban"
		}
	})
	local v373 = v_u_209(v_u_189, 4)
	v373.Visible = v_u_200.SetTag == true
	v_u_18.new("UIListLayout", {
		["Padding"] = UDim.new(0, 8),
		["SortOrder"] = Enum.SortOrder.LayoutOrder,
		["Parent"] = v373
	})
	v_u_248(v373, 1, "\240\159\143\183\239\184\143 Title over their head by username \194\183 online or offline")
	local v_u_374 = v_u_220(v373, "Username or user ID", {
		["LayoutOrder"] = 2
	})
	v_u_18.text({
		["Text"] = "Offline: it shows when they next join. Auto = their own rank again.",
		["TextSize"] = 13,
		["TextColor3"] = nil,
		["TextWrapped"] = true,
		["TextXAlignment"] = nil,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = 3,
		["Parent"] = nil,
		["TextColor3"] = v_u_18.TEXT_DIM,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y,
		["Parent"] = v373
	})
	local v_u_375 = false
	local function v_u_380(p376) -- name: giveTag
		-- upvalues: (copy) v_u_374, (ref) v_u_53, (ref) v_u_375, (ref) v_u_106
		local v377 = v_u_374.Text:gsub("^%s*@?", ""):gsub("%s*$", "")
		if v377 == "" then
			v_u_53.show(tostring("Type a username first"), "error")
			return
		elseif not v_u_375 then
			v_u_375 = true
			local v378, v379 = v_u_106("SetTag", v377, p376)
			if v379 then
				v_u_53.show(tostring(v379), v378 and "ok" or "error")
			end
			v_u_375 = false
		end
	end
	local v381 = {
		{
			"Auto",
			"gold",
			nil,
			function()
				-- upvalues: (copy) v_u_380
				v_u_380("Auto")
			end,
			"SetTag"
		}
	}
	for _, v_u_382 in v_u_7.TAG_CHOICES do
		table.insert(v381, {
			v_u_382,
			"dark",
			nil,
			function()
				-- upvalues: (copy) v_u_380, (copy) v_u_382
				v_u_380(v_u_382)
			end,
			"SetTag"
		})
	end
	v_u_244(v373, 4, v381, 96)
	if not (v350.Visible or (v346.Visible or (v356.Visible or (v362.Visible or v373.Visible)))) then
		v_u_18.text({
			["Text"] = "Nothing here for your rank",
			["TextSize"] = 16,
			["TextColor3"] = nil,
			["Size"] = nil,
			["LayoutOrder"] = 9,
			["Parent"] = nil,
			["TextColor3"] = v_u_18.TEXT_DIM,
			["Size"] = UDim2.new(1, 0, 0, 40),
			["Parent"] = v_u_189
		})
	end
end
local function v_u_432() -- name: buildLog
	-- upvalues: (copy) v_u_264, (copy) v_u_190, (ref) v_u_200, (copy) v_u_18, (copy) v_u_106, (copy) v_u_5, (copy) v_u_209
	v_u_264(v_u_190)
	if v_u_200.Log then
		local v383, v384 = v_u_106("Log")
		local v385, v386 = v_u_106("Bans")
		if v385 and type(v386) == "table" then
			local v387 = {}
			local v388 = {}
			for _, v389 in {
				{ "hub", "UI \224\185\130\224\184\155\224\184\163 (\224\184\138\224\184\183\224\185\136\224\184\173 hub)" },
				{ "ui5", "UI \224\185\129\224\184\155\224\184\165\224\184\129\224\184\132\224\184\163\224\184\154 5 \224\184\132\224\184\163\224\184\177\224\185\137\224\184\135" },
				{ "speed", "\224\184\132\224\184\167\224\184\178\224\184\161\224\185\128\224\184\163\224\185\135\224\184\167 (AntiCheat)" },
				{ "staff", "\224\185\129\224\184\173\224\184\148\224\184\161\224\184\180\224\184\153\224\185\129\224\184\154\224\184\153" },
				{ "tool", "\224\185\128\224\184\132\224\184\163\224\184\183\224\185\136\224\184\173\224\184\135\224\184\161\224\184\183\224\184\173\224\185\130\224\184\155\224\184\163 (ECU.lua \224\184\175\224\184\165\224\184\175)" },
				{ "wave", "Ban wave (\224\184\163\224\184\178\224\184\162\224\184\138\224\184\183\224\185\136\224\184\173\224\185\128\224\184\157\224\185\137\224\184\178\224\184\148\224\184\185)" }
			} do
				v387[v389[1]] = v389[2]
				local v390 = v386.kinds
				local v391
				if type(v390) == "table" then
					local v392 = v386.kinds[v389[1]]
					v391 = tonumber(v392) or 0
				else
					v391 = 0
				end
				if v391 <= 0 then
					continue
				end
				local v393 = v389[2]
				local v394 = v_u_5.formatNumber
				table.insert(v388, ("%s %s"):format(v393, v394(v391)))
			end
			local v395 = { ("\240\159\148\168 \224\185\129\224\184\154\224\184\153\224\185\129\224\184\165\224\185\137\224\184\167 \224\184\151\224\184\184\224\184\129\224\185\128\224\184\139\224\184\180\224\184\163\224\185\140\224\184\159\224\185\128\224\184\167\224\184\173\224\184\163\224\185\140: %s \224\184\132\224\184\153  \194\183  \224\184\167\224\184\177\224\184\153\224\184\153\224\184\181\224\185\137 %s  \194\183  \224\184\155\224\184\165\224\184\148\224\185\129\224\184\154\224\184\153\224\185\129\224\184\165\224\185\137\224\184\167 %s"):format(v_u_5.formatNumber(v386.total or 0), v_u_5.formatNumber(v386.today or 0), v_u_5.formatNumber(v386.unbanned or 0)) }
			if #v388 > 0 then
				local v396 = table.concat
				table.insert(v395, v396(v388, "  \194\183  "))
			end
			if v386.since then
				local v397 = os.date
				local v398 = v386.since
				table.insert(v395, ("\224\184\153\224\184\177\224\184\154\224\184\149\224\184\177\224\185\137\224\184\135\224\185\129\224\184\149\224\185\136 %s (\224\184\129\224\185\136\224\184\173\224\184\153\224\184\171\224\184\153\224\185\137\224\184\178\224\184\153\224\184\177\224\185\137\224\184\153\224\185\128\224\184\173\224\184\178\224\184\136\224\184\178\224\184\129 Log \224\185\129\224\184\173\224\184\148\224\184\161\224\184\180\224\184\153 300 \224\184\163\224\184\178\224\184\162\224\184\129\224\184\178\224\184\163\224\184\165\224\185\136\224\184\178\224\184\170\224\184\184\224\184\148)"):format(v397("%d/%m %H:%M", v398)))
			end
			local v399 = v386.recent
			local v400 = type(v399) == "table" and (#v386.recent or 0) or 0
			for v401 = 1, math.min(20, v400) do
				local v402 = v386.recent[v401]
				local v403 = "     %s   %s%s  \194\183  %s  \194\183  %s"
				local v404 = os.date("%d/%m %H:%M", v402.t or 0)
				local v405 = v402.name or "?"
				local v406 = tostring(v405)
				local v407 = v402.id
				local v408 = (tonumber(v407) or 0) <= 0 and "" or (" (%d)"):format(v402.id)
				local v409 = v387[v402.kind]
				if not v409 then
					local v410 = v402.kind
					v409 = tostring(v410)
				end
				local v411 = v402.why or ""
				local v412 = tostring(v411)
				table.insert(v395, v403:format(v404, v406, v408, v409, v412))
			end
			if v386.note then
				local v413 = v386.note
				local v414 = tostring(v413)
				table.insert(v395, v414)
			end
			local v415 = v_u_209(v_u_190, 0)
			v_u_18.text({
				["Text"] = nil,
				["TextSize"] = 14,
				["FontFace"] = nil,
				["TextXAlignment"] = nil,
				["TextWrapped"] = true,
				["Size"] = nil,
				["AutomaticSize"] = nil,
				["Parent"] = nil,
				["Text"] = table.concat(v395, "\n"),
				["FontFace"] = v_u_18.FONT_BOLD,
				["TextXAlignment"] = Enum.TextXAlignment.Left,
				["Size"] = UDim2.new(1, 0, 0, 0),
				["AutomaticSize"] = Enum.AutomaticSize.Y,
				["Parent"] = v415
			})
		end
		if v383 and type(v384) == "table" then
			local v416 = #v384
			local v417 = #v384 - 150
			for v418 = v416, math.max(1, v417), -1 do
				local v419 = v384[v418]
				if type(v419) ~= "table" then
					continue
				end
				local v420 = v_u_209(v_u_190, #v384 - v418 + 1)
				local v421 = v_u_18.text
				local v422 = {
					["Text"] = nil,
					["TextSize"] = 14,
					["FontFace"] = nil,
					["TextXAlignment"] = nil,
					["TextWrapped"] = true,
					["Size"] = nil,
					["AutomaticSize"] = nil,
					["Parent"] = nil
				}
				local v423 = os.date("%d/%m %H:%M", v419.t or 0)
				local v424 = v419.by
				local v425 = tostring(v424)
				local v426 = v419.action
				local v427 = tostring(v426)
				local v428 = v419.detail or ""
				v422.Text = ("%s   %s  %s %s"):format(v423, v425, v427, (tostring(v428)))
				v422.FontFace = v_u_18.FONT_BOLD
				v422.TextXAlignment = Enum.TextXAlignment.Left
				v422.Size = UDim2.new(1, 0, 0, 0)
				v422.AutomaticSize = Enum.AutomaticSize.Y
				v422.Parent = v420
				v421(v422)
				local v429 = v_u_18.text
				local v430 = {
					["Text"] = nil,
					["TextSize"] = 13,
					["TextColor3"] = nil,
					["TextXAlignment"] = nil,
					["TextWrapped"] = true,
					["Position"] = nil,
					["Size"] = nil,
					["AutomaticSize"] = nil,
					["Parent"] = nil
				}
				local v431 = v419.result or ""
				v430.Text = tostring(v431)
				v430.TextColor3 = v_u_18.TEXT_DIM
				v430.TextXAlignment = Enum.TextXAlignment.Left
				v430.Position = UDim2.fromOffset(0, 20)
				v430.Size = UDim2.new(1, 0, 0, 0)
				v430.AutomaticSize = Enum.AutomaticSize.Y
				v430.Parent = v420
				v429(v430)
			end
		end
	else
		v_u_18.text({
			["Text"] = "Only the Owner sees the log",
			["TextSize"] = 16,
			["TextColor3"] = nil,
			["Size"] = nil,
			["LayoutOrder"] = 1,
			["Parent"] = nil,
			["TextColor3"] = v_u_18.TEXT_DIM,
			["Size"] = UDim2.new(1, 0, 0, 40),
			["Parent"] = v_u_190
		})
		return
	end
end
local v_u_433 = nil
local v_u_434 = {}
local v_u_435 = v_u_6.SIZES[1]
local v_u_436 = 1
local v_u_437 = ""
local v_u_438 = false
local v_u_439 = {}
local v_u_440 = nil
local function v_u_448(p441) -- name: lookup
	-- upvalues: (ref) v_u_438, (copy) v_u_106, (copy) v_u_53, (ref) v_u_433, (copy) v_u_434, (ref) v_u_440
	if v_u_438 then
		return
	else
		v_u_438 = true
		local v442, v443 = v_u_106("Lookup", p441)
		v_u_438 = false
		if v442 and type(v443) == "table" then
			v_u_433 = v443
			for v444 = #v_u_434, 1, -1 do
				if v_u_434[v444].id ~= v443.id then
					continue
				end
				table.remove(v_u_434, v444)
			end
			local v445 = v_u_434
			local v446 = {
				["id"] = v443.id,
				["name"] = v443.name,
				["display"] = v443.display
			}
			table.insert(v445, 1, v446)
			while #v_u_434 > 8 do
				table.remove(v_u_434)
			end
			v_u_440()
		else
			local v447 = type(v443) ~= "string" and "Not found" or v443
			if v447 then
				v_u_53.show(tostring(v447), "error")
			end
		end
	end
end
local function v_u_454(p449, p450, p451, p452, p453) -- name: moneyLine
	-- upvalues: (copy) v_u_18
	v_u_18.text({
		["Text"] = nil,
		["TextSize"] = 12,
		["FontFace"] = nil,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Text"] = p451,
		["FontFace"] = v_u_18.FONT_HEAVY,
		["TextColor3"] = v_u_18.TEXT_DIM,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["Position"] = UDim2.new(p450, 12, 0, 8),
		["Size"] = UDim2.new(0.5, -18, 0, 14),
		["Parent"] = p449
	})
	v_u_18.text({
		["Text"] = nil,
		["TextSize"] = 22,
		["FontFace"] = nil,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["TextTruncate"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Text"] = p452,
		["FontFace"] = v_u_18.FONT_DISPLAY,
		["TextColor3"] = p453,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["TextTruncate"] = Enum.TextTruncate.AtEnd,
		["Position"] = UDim2.new(p450, 12, 0, 26),
		["Size"] = UDim2.new(0.5, -18, 0, 28),
		["Parent"] = p449
	})
end
v_u_440 = function()
	-- upvalues: (copy) v_u_264, (copy) v_u_191, (ref) v_u_200, (copy) v_u_18, (copy) v_u_209, (copy) v_u_248, (copy) v_u_220, (ref) v_u_437, (copy) v_u_448, (ref) v_u_433, (copy) v_u_7, (copy) v_u_454, (copy) v_u_5, (copy) v_u_265, (copy) v_u_244, (copy) v_u_106, (copy) v_u_53, (copy) v_u_6, (ref) v_u_435, (ref) v_u_440, (ref) v_u_436, (copy) v_u_439, (copy) v_u_434
	v_u_264(v_u_191)
	if v_u_200.Lookup then
		local v455 = v_u_209(v_u_191, 1)
		v_u_18.new("UIListLayout", {
			["Padding"] = UDim.new(0, 8),
			["SortOrder"] = Enum.SortOrder.LayoutOrder,
			["Parent"] = v455
		})
		v_u_248(v455, 1, "\240\159\148\142 Find any player \194\183 on the game or not")
		local v456 = v_u_18.new("Frame", {
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["LayoutOrder"] = 2,
			["Parent"] = nil,
			["Size"] = UDim2.new(1, 0, 0, 40),
			["Parent"] = v455
		})
		local v_u_457, v458 = v_u_220(v456, "Username or user ID")
		v458.Size = UDim2.new(1, -130, 1, 0)
		v_u_457.Text = v_u_437
		local v459 = v_u_18.button({
			["text"] = "Search",
			["icon"] = "pin",
			["grad"] = "gold",
			["textSize"] = 15,
			["anchor"] = nil,
			["position"] = nil,
			["size"] = nil,
			["parent"] = nil,
			["anchor"] = Vector2.new(1, 0),
			["position"] = UDim2.fromScale(1, 0),
			["size"] = UDim2.new(0, 122, 1, 0),
			["parent"] = v456
		})
		v_u_18.text({
			["Text"] = "Their username (not the display name), or the number in their profile link",
			["TextSize"] = 13,
			["TextColor3"] = nil,
			["TextWrapped"] = true,
			["TextXAlignment"] = nil,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["LayoutOrder"] = 3,
			["Parent"] = nil,
			["TextColor3"] = v_u_18.TEXT_DIM,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["Size"] = UDim2.new(1, 0, 0, 0),
			["AutomaticSize"] = Enum.AutomaticSize.Y,
			["Parent"] = v455
		})
		local function v460() -- name: submit
			-- upvalues: (ref) v_u_437, (copy) v_u_457, (ref) v_u_448
			v_u_437 = v_u_457.Text
			if v_u_457.Text:gsub("%s", "") ~= "" then
				task.spawn(v_u_448, v_u_457.Text)
			end
		end
		v459.Activated:Connect(v460)
		v_u_457.FocusLost:Connect(function(p461)
			-- upvalues: (ref) v_u_437, (copy) v_u_457, (ref) v_u_448
			if p461 then
				v_u_437 = v_u_457.Text
				if v_u_457.Text:gsub("%s", "") ~= "" then
					task.spawn(v_u_448, v_u_457.Text)
				end
			end
		end)
		local v_u_462 = v_u_433
		if v_u_462 then
			local v463 = v_u_209(v_u_191, 2)
			v_u_18.new("UIListLayout", {
				["Padding"] = UDim.new(0, 8),
				["SortOrder"] = Enum.SortOrder.LayoutOrder,
				["Parent"] = v463
			})
			local v464 = v_u_18.new("Frame", {
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["LayoutOrder"] = 1,
				["Parent"] = nil,
				["Size"] = UDim2.new(1, 0, 0, 72),
				["Parent"] = v463
			})
			local v465 = v_u_18.new("ImageLabel", {
				["BackgroundColor3"] = Color3.fromRGB(30, 32, 44),
				["Image"] = ("rbxthumb://type=AvatarHeadShot&id=%d&w=150&h=150"):format(v_u_462.id),
				["Size"] = UDim2.fromOffset(72, 72),
				["Parent"] = v464
			})
			v_u_18.corner(v465, 36)
			v_u_18.text({
				["Text"] = nil,
				["TextSize"] = 22,
				["FontFace"] = nil,
				["TextXAlignment"] = nil,
				["TextTruncate"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["Text"] = v_u_462.display,
				["FontFace"] = v_u_18.FONT_HEAVY,
				["TextXAlignment"] = Enum.TextXAlignment.Left,
				["TextTruncate"] = Enum.TextTruncate.AtEnd,
				["Position"] = UDim2.fromOffset(84, 0),
				["Size"] = UDim2.new(1, -84, 0, 26),
				["Parent"] = v464
			})
			v_u_18.text({
				["Text"] = nil,
				["TextSize"] = 14,
				["TextColor3"] = nil,
				["TextXAlignment"] = nil,
				["TextTruncate"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["Text"] = ("@%s  \194\183  ID %d"):format(v_u_462.name, v_u_462.id),
				["TextColor3"] = v_u_18.TEXT_DIM,
				["TextXAlignment"] = Enum.TextXAlignment.Left,
				["TextTruncate"] = Enum.TextTruncate.AtEnd,
				["Position"] = UDim2.fromOffset(84, 27),
				["Size"] = UDim2.new(1, -84, 0, 18),
				["Parent"] = v464
			})
			local v466 = v_u_462.here and "\240\159\159\162 Online \194\183 this server" or (not v_u_462.online and "\226\154\170 Offline" or "\240\159\159\162 Online \194\183 another server" .. (v_u_462.private and " (VIP)" or ""))
			local v467 = v_u_18.text
			local v468 = {
				["Text"] = nil,
				["TextSize"] = 14,
				["FontFace"] = nil,
				["TextColor3"] = nil,
				["TextXAlignment"] = nil,
				["TextTruncate"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["Text"] = v466 .. "   \194\183   " .. v_u_7.label(v_u_462.rank),
				["FontFace"] = v_u_18.FONT_BOLD
			}
			local v469
			if v_u_462.online then
				v469 = v_u_18.GREEN_TEXT
			else
				v469 = v_u_18.TEXT_DIM
			end
			v468.TextColor3 = v469
			v468.TextXAlignment = Enum.TextXAlignment.Left
			v468.TextTruncate = Enum.TextTruncate.AtEnd
			v468.Position = UDim2.fromOffset(84, 48)
			v468.Size = UDim2.new(1, -84, 0, 20)
			v468.Parent = v464
			v467(v468)
			local v470 = v_u_18.new("Frame", {
				["BackgroundColor3"] = nil,
				["Size"] = nil,
				["LayoutOrder"] = 2,
				["Parent"] = nil,
				["BackgroundColor3"] = v_u_18.CARD_DARK,
				["Size"] = UDim2.new(1, 0, 0, 62),
				["Parent"] = v463
			})
			v_u_18.corner(v470, 10)
			v_u_454(v470, 0, v_u_462.online and "MONEY NOW" or "SAVED MONEY", not v_u_462.cash and "\226\128\148" or v_u_5.formatCash(v_u_462.cash), v_u_18.YELLOW)
			local v471 = v_u_462.waiting
			local v472 = "\226\128\148"
			local v473 = v_u_18.TEXT_DIM
			if v471 and (v471.give > 0 or v471.take > 0) then
				local v474 = {}
				if v471.give > 0 then
					local v475 = "+" .. v_u_5.formatCash(v471.give)
					table.insert(v474, v475)
				end
				if v471.take > 0 then
					local v476 = "\226\136\146" .. v_u_5.formatCash(v471.take)
					table.insert(v474, v476)
				end
				v472 = table.concat(v474, "  ")
				if v471.give >= v471.take then
					v473 = v_u_18.GREEN_TEXT
				else
					v473 = Color3.fromRGB(255, 110, 110)
				end
			elseif v471 then
				v472 = "nothing"
			end
			v_u_454(v470, 0.5, "WAITING IN THEIR INBOX", v472, v473)
			local v477 = v_u_462.passes
			local v478 = {}
			for _, v479 in type(v477) ~= "table" and {} or v_u_462.passes do
				local v480 = v479.name .. (v479.how == "gift" and " (gift / code)" or "")
				table.insert(v478, v480)
			end
			local v481 = v_u_18.new("Frame", {
				["BackgroundColor3"] = nil,
				["Size"] = nil,
				["AutomaticSize"] = nil,
				["LayoutOrder"] = 3,
				["Parent"] = nil,
				["BackgroundColor3"] = v_u_18.CARD_DARK,
				["Size"] = UDim2.new(1, 0, 0, 0),
				["AutomaticSize"] = Enum.AutomaticSize.Y,
				["Parent"] = v463
			})
			v_u_18.corner(v481, 10)
			v_u_18.padding(v481, 12, 8)
			local v482 = v_u_18.text
			local v483 = {
				["Text"] = nil,
				["TextSize"] = 15,
				["FontFace"] = nil,
				["TextColor3"] = nil,
				["TextWrapped"] = true,
				["TextXAlignment"] = nil,
				["Size"] = nil,
				["AutomaticSize"] = nil,
				["Parent"] = nil
			}
			local v484 = "\240\159\146\142 Game passes: "
			local v485
			if #v478 > 0 then
				v485 = table.concat(v478, "  \194\183  ")
			else
				v485 = v_u_462.passes and "none" or "couldn\'t check"
			end
			v483.Text = v484 .. v485
			v483.FontFace = v_u_18.FONT_BOLD
			local v486
			if #v478 > 0 then
				v486 = v_u_265
			else
				v486 = v_u_18.TEXT_DIM
			end
			v483.TextColor3 = v486
			v483.TextXAlignment = Enum.TextXAlignment.Left
			v483.Size = UDim2.new(1, 0, 0, 0)
			v483.AutomaticSize = Enum.AutomaticSize.Y
			v483.Parent = v481
			v482(v483)
			local v487 = v_u_462.stuff
			if type(v487) == "table" then
				local v488 = {}
				local v489 = "\240\159\142\146 <b>Carrying:</b> "
				local v490
				if #v487.items > 0 then
					local v491 = table.concat(v487.items, "  \194\183  ")
					v490 = tostring(v491):gsub("&", "&amp;"):gsub("<", "&lt;"):gsub(">", "&gt;")
				else
					v490 = "nothing"
				end
				local v492 = v489 .. v490
				local v493 = "\240\159\148\169 <b>Pistons in the bag:</b> "
				local v494
				if #v487.pistons > 0 then
					local v495 = table.concat(v487.pistons, "  \194\183  ")
					v494 = tostring(v495):gsub("&", "&amp;"):gsub("<", "&lt;"):gsub(">", "&gt;")
				else
					v494 = "none"
				end
				local v496 = v493 .. v494
				local v497 = "\226\155\145\239\184\143 <b>Helmet:</b> "
				local v498
				if v487.helmet then
					local v499 = v487.helmet
					v498 = tostring(v499):gsub("&", "&amp;"):gsub("<", "&lt;"):gsub(">", "&gt;")
				else
					v498 = "none"
				end
				__set_list(v488, 1, {v492, v496, v497 .. v498, ("\240\159\143\141\239\184\143 <b>Vehicles (%d)</b>%s"):format(#v487.vehicles, v_u_462.online and not v_u_462.here and "  \194\183  as last saved" or "")})
				for _, v500 in v487.vehicles do
					local v501
					if v500.bore and (v500.stock and v500.bore > v500.stock) then
						v501 = ("<font color=\"%s\">piston %g mm</font> (stock %g)"):format(v500.bore >= 80 and "#FF9A3C" or "#FFD34D", v500.bore, v500.stock)
					else
						v501 = not v500.stock and "no piston (car)" or ("stock piston %g mm"):format(v500.bore or v500.stock)
					end
					local v502 = v500.name
					local v503 = tostring(v502):gsub("&", "&amp;"):gsub("<", "&lt;"):gsub(">", "&gt;")
					local v504 = v500.out and "  <i>(out now)</i>" or ""
					local v505 = v_u_5.formatNumber
					local v506 = v500.km or 0
					table.insert(v488, ("     %s%s  \226\128\148  %s  \194\183  %s km"):format(v503, v504, v501, v505(v506)))
				end
				local v507 = v_u_18.new("Frame", {
					["BackgroundColor3"] = nil,
					["Size"] = nil,
					["AutomaticSize"] = nil,
					["LayoutOrder"] = 4,
					["Parent"] = nil,
					["BackgroundColor3"] = v_u_18.CARD_DARK,
					["Size"] = UDim2.new(1, 0, 0, 0),
					["AutomaticSize"] = Enum.AutomaticSize.Y,
					["Parent"] = v463
				})
				v_u_18.corner(v507, 10)
				v_u_18.padding(v507, 12, 8)
				v_u_18.text({
					["Text"] = nil,
					["RichText"] = true,
					["TextSize"] = 14,
					["FontFace"] = nil,
					["TextColor3"] = nil,
					["TextWrapped"] = true,
					["TextXAlignment"] = nil,
					["Size"] = nil,
					["AutomaticSize"] = nil,
					["Parent"] = nil,
					["Text"] = table.concat(v488, "\n"),
					["FontFace"] = v_u_18.FONT_BOLD,
					["TextColor3"] = v_u_18.TEXT,
					["TextXAlignment"] = Enum.TextXAlignment.Left,
					["Size"] = UDim2.new(1, 0, 0, 0),
					["AutomaticSize"] = Enum.AutomaticSize.Y,
					["Parent"] = v507
				})
			end
			local v508 = {}
			if v_u_462.played == false then
				table.insert(v508, "Hasn\'t played here yet: money waits until they first join.")
			elseif not v_u_462.online then
				table.insert(v508, "Offline: what you give or take reaches them when they next join.")
			end
			if v_u_462.note then
				local v509 = v_u_462.note
				table.insert(v508, v509)
			end
			local v510 = v_u_462.farm
			if type(v510) == "table" then
				local v511 = (v510.hoursWorked or 0) <= 0 and 0 or (v510.day or 0) / v510.hoursWorked
				local v512 = v510.checks
				local v513 = type(v512) == "table" and (v510.checks or {}) or {}
				local v514 = (v510.bestBase or (v510.bestHour or 0)) >= 90000 and true or ((v513.slow or 0) >= 3 and true or (v510.legs or 0) > 0)
				local v515 = v_u_18.new
				local v516 = "Frame"
				local v517 = {
					["BackgroundColor3"] = nil,
					["Size"] = nil,
					["AutomaticSize"] = nil,
					["LayoutOrder"] = 5,
					["Parent"] = nil
				}
				local v518
				if v514 then
					v518 = Color3.fromRGB(70, 28, 30)
				else
					v518 = v_u_18.CARD_DARK
				end
				v517.BackgroundColor3 = v518
				v517.Size = UDim2.new(1, 0, 0, 0)
				v517.AutomaticSize = Enum.AutomaticSize.Y
				v517.Parent = v463
				local v519 = v515(v516, v517)
				v_u_18.corner(v519, 10)
				v_u_18.padding(v519, 12, 8)
				local v520 = v_u_18.text
				local v521 = {
					["Text"] = nil,
					["TextSize"] = 14,
					["FontFace"] = nil,
					["TextColor3"] = nil,
					["TextWrapped"] = true,
					["TextXAlignment"] = nil,
					["Size"] = nil,
					["AutomaticSize"] = nil,
					["Parent"] = nil,
					["Text"] = ("\240\159\149\181\239\184\143 Jobs (FarmGuard)   this hour %s   \194\183   best hour %s%s\nlast 24 h: %s in %d jobs, %d hours worked = %s / hour%s\nperson checks: %d passed \194\183 %d wrong \194\183 %d slow/unanswered%s"):format(v_u_5.formatCash(v510.thisHour or 0), v_u_5.formatCash(v510.bestHour or 0), not v510.bestHourAt and "" or " (" .. os.date("%d/%m %H:00", v510.bestHourAt) .. ")", v_u_5.formatCash(v510.day or 0), v510.dayJobs or 0, v510.hoursWorked or 0, v_u_5.formatCash(v511), (v510.boost or 1) <= 1 and "" or ("\npasses pay x%g: best hour without them %s"):format(v510.boost, v_u_5.formatCash(v510.bestBase or 0)), v513.ok or 0, v513.bad or 0, v513.slow or 0, (v510.legs or 0) <= 0 and "" or ("   \194\183   %d legs voided (too fast)"):format(v510.legs)),
					["FontFace"] = v_u_18.FONT_BOLD
				}
				local v522
				if v514 then
					v522 = Color3.fromRGB(255, 150, 150)
				else
					v522 = v_u_18.TEXT
				end
				v521.TextColor3 = v522
				v521.TextXAlignment = Enum.TextXAlignment.Left
				v521.Size = UDim2.new(1, 0, 0, 0)
				v521.AutomaticSize = Enum.AutomaticSize.Y
				v521.Parent = v519
				v520(v521)
			elseif v_u_462.played then
				table.insert(v508, "No job record yet (FarmGuard keeps it from 31 Oct on).")
			end
			if #v508 > 0 then
				v_u_18.text({
					["Text"] = nil,
					["TextSize"] = 13,
					["TextColor3"] = nil,
					["TextWrapped"] = true,
					["TextXAlignment"] = nil,
					["Size"] = nil,
					["AutomaticSize"] = nil,
					["LayoutOrder"] = 6,
					["Parent"] = nil,
					["Text"] = table.concat(v508, "\n"),
					["TextColor3"] = v_u_18.TEXT_DIM,
					["TextXAlignment"] = Enum.TextXAlignment.Left,
					["Size"] = UDim2.new(1, 0, 0, 0),
					["AutomaticSize"] = Enum.AutomaticSize.Y,
					["Parent"] = v463
				})
			end
			local v_u_523 = v_u_220(v463, "Amount of money (\224\184\191)", {
				["LayoutOrder"] = 7
			})
			v_u_244(v463, 8, {
				{
					"+1K",
					"dark",
					nil,
					function()
						-- upvalues: (copy) v_u_523
						local v524 = v_u_523.Text:gsub("[^%d]", "")
						local v525 = v_u_523
						local v526 = (tonumber(v524) or 0) + 1000
						v525.Text = tostring(v526)
					end
				},
				{
					"+10K",
					"dark",
					nil,
					function()
						-- upvalues: (copy) v_u_523
						local v527 = v_u_523.Text:gsub("[^%d]", "")
						local v528 = v_u_523
						local v529 = (tonumber(v527) or 0) + 10000
						v528.Text = tostring(v529)
					end
				},
				{
					"+100K",
					"dark",
					nil,
					function()
						-- upvalues: (copy) v_u_523
						local v530 = v_u_523.Text:gsub("[^%d]", "")
						local v531 = v_u_523
						local v532 = (tonumber(v530) or 0) + 100000
						v531.Text = tostring(v532)
					end
				},
				{
					"Clear",
					"dark",
					nil,
					function()
						-- upvalues: (copy) v_u_523
						v_u_523.Text = ""
					end
				}
			})
			local function v_u_541(p533) -- name: act
				-- upvalues: (ref) v_u_106, (copy) v_u_462, (copy) v_u_523, (ref) v_u_53, (ref) v_u_433, (ref) v_u_448
				local v534 = v_u_106
				local v535 = v_u_462.id
				local v536 = v_u_523.Text:gsub("[,%s]", "")
				local v537, v538 = v534(p533, v535, (tonumber(v536)))
				if v538 then
					v_u_53.show(tostring(v538), v537 and "ok" or "error")
				end
				if v537 then
					task.delay(1.5, function()
						-- upvalues: (ref) v_u_433, (ref) v_u_462, (ref) v_u_448
						if v_u_433 and v_u_433.id == v_u_462.id then
							local v539 = v_u_448
							local v540 = v_u_462.id
							v539((tostring(v540)))
						end
					end)
				end
			end
			v_u_244(v463, 9, {
				{
					"Give \224\184\191",
					"green",
					"coin",
					function()
						-- upvalues: (copy) v_u_541
						v_u_541("Give")
					end,
					"Give"
				},
				{
					"Take \224\184\191",
					"red",
					"trash",
					function()
						-- upvalues: (copy) v_u_541
						v_u_541("Take")
					end,
					"Take"
				}
			})
			if v_u_200.GivePiston then
				v_u_248(v463, 11, "\240\159\148\169 Give pistons \194\183 Owner only")
				local v542 = v_u_18.new("Frame", {
					["BackgroundTransparency"] = 1,
					["Size"] = nil,
					["AutomaticSize"] = nil,
					["LayoutOrder"] = 12,
					["Parent"] = nil,
					["Size"] = UDim2.new(1, 0, 0, 0),
					["AutomaticSize"] = Enum.AutomaticSize.Y,
					["Parent"] = v463
				})
				v_u_18.new("UIGridLayout", {
					["CellPadding"] = UDim2.fromOffset(6, 6),
					["CellSize"] = UDim2.fromOffset(78, 38),
					["SortOrder"] = Enum.SortOrder.LayoutOrder,
					["Parent"] = v542
				})
				for v543, v_u_544 in v_u_6.SIZES do
					local v545 = v_u_18.button({
						["text"] = nil,
						["grad"] = nil,
						["textSize"] = 14,
						["parent"] = nil,
						["text"] = ("%g mm"):format(v_u_544),
						["grad"] = v_u_544 == v_u_435 and "gold" or "dark",
						["parent"] = v542
					})
					v545.LayoutOrder = v543
					v545.Activated:Connect(function()
						-- upvalues: (ref) v_u_435, (copy) v_u_544, (ref) v_u_440
						v_u_435 = v_u_544
						v_u_440()
					end)
				end
				local v_u_546 = v_u_220(v463, ("How many (1 to %d)"):format(20), {
					["LayoutOrder"] = 13
				})
				local v547 = v_u_436
				v_u_546.Text = tostring(v547)
				local function v550() -- name: readCount
					-- upvalues: (ref) v_u_436, (copy) v_u_546
					local v548 = v_u_546.Text
					local v549 = tonumber(v548:match("%d+")) or 1
					v_u_436 = math.clamp(v549, 1, 20)
					return v_u_436
				end
				v_u_546.FocusLost:Connect(v550)
				v_u_244(v463, 14, {
					{
						("Give %g mm"):format(v_u_435),
						"orange",
						nil,
						function()
							-- upvalues: (ref) v_u_106, (copy) v_u_462, (ref) v_u_435, (ref) v_u_436, (copy) v_u_546, (ref) v_u_53, (ref) v_u_433, (ref) v_u_448
							local v551 = v_u_106
							local v552 = v_u_462.id
							local v553 = v_u_435
							local v554 = v_u_546.Text
							local v555 = tonumber(v554:match("%d+")) or 1
							v_u_436 = math.clamp(v555, 1, 20)
							local v556, v557 = v551("GivePiston", v552, v553, v_u_436)
							if v557 then
								v_u_53.show(tostring(v557), v556 and "ok" or "error")
							end
							if v556 then
								task.delay(1.5, function()
									-- upvalues: (ref) v_u_433, (ref) v_u_462, (ref) v_u_448
									if v_u_433 and v_u_433.id == v_u_462.id then
										local v558 = v_u_448
										local v559 = v_u_462.id
										v558((tostring(v559)))
									end
								end)
							end
						end,
						"GivePiston"
					}
				})
			end
			local v_u_560 = false
			v_u_244(v463, 10, {
				{
					"Money history",
					"purple",
					"clock",
					function()
						-- upvalues: (ref) v_u_560, (ref) v_u_53, (ref) v_u_106, (copy) v_u_462, (ref) v_u_439, (ref) v_u_440
						if v_u_560 then
							return
						else
							v_u_560 = true
							v_u_53.show(tostring("Reading their saves..."), "ok")
							local v561, v562 = v_u_106("History", v_u_462.id)
							v_u_560 = false
							if v561 and type(v562) == "table" then
								v_u_439[v_u_462.id] = v562
								v_u_440()
							elseif v562 then
								v_u_53.show(tostring(v562), "error")
							end
						end
					end,
					"History"
				}
			})
			local v563 = v_u_439[v_u_462.id]
			if v563 then
				local v564 = v_u_209(v_u_191, 3)
				v_u_18.new("UIListLayout", {
					["Padding"] = UDim.new(0, 4),
					["SortOrder"] = Enum.SortOrder.LayoutOrder,
					["Parent"] = v564
				})
				v_u_248(v564, 0, ("\240\159\149\146 Money at each save \194\183 %d saves, newest first"):format(#v563.list))
				if #v563.list == 0 then
					v_u_18.text({
						["Text"] = "No saves in the last 30 days",
						["TextSize"] = 14,
						["TextColor3"] = nil,
						["Size"] = nil,
						["TextXAlignment"] = nil,
						["LayoutOrder"] = 1,
						["Parent"] = nil,
						["TextColor3"] = v_u_18.TEXT_DIM,
						["Size"] = UDim2.new(1, 0, 0, 24),
						["TextXAlignment"] = Enum.TextXAlignment.Left,
						["Parent"] = v564
					})
				end
				for v565, v566 in v563.list do
					local v567 = v563.list[v565 + 1]
					local v568
					if v567 and (v566.cash and v567.cash) then
						v568 = v566.cash - v567.cash
					else
						v568 = nil
					end
					local v569 = v_u_18.new("Frame", {
						["BackgroundColor3"] = v_u_18.CARD_DARK,
						["BackgroundTransparency"] = v565 % 2 == 0 and 0.4 or 0,
						["Size"] = UDim2.new(1, 0, 0, 30),
						["LayoutOrder"] = v565,
						["Parent"] = v564
					})
					v_u_18.corner(v569, 6)
					v_u_18.text({
						["Text"] = nil,
						["TextSize"] = 14,
						["TextColor3"] = nil,
						["TextXAlignment"] = nil,
						["Position"] = nil,
						["Size"] = nil,
						["Parent"] = nil,
						["Text"] = os.date("%d %b  %H:%M", v566.at),
						["TextColor3"] = v_u_18.TEXT_DIM,
						["TextXAlignment"] = Enum.TextXAlignment.Left,
						["Position"] = UDim2.fromOffset(10, 0),
						["Size"] = UDim2.new(0.34, -10, 1, 0),
						["Parent"] = v569
					})
					v_u_18.text({
						["Text"] = nil,
						["TextSize"] = 15,
						["FontFace"] = nil,
						["TextColor3"] = nil,
						["TextXAlignment"] = nil,
						["Position"] = nil,
						["Size"] = nil,
						["Parent"] = nil,
						["Text"] = not v566.cash and "\226\128\148" or v_u_5.formatCash(v566.cash),
						["FontFace"] = v_u_18.FONT_HEAVY,
						["TextColor3"] = v_u_18.YELLOW,
						["TextXAlignment"] = Enum.TextXAlignment.Left,
						["Position"] = UDim2.fromScale(0.34, 0),
						["Size"] = UDim2.new(0.3, 0, 1, 0),
						["Parent"] = v569
					})
					local v570 = v_u_18.text
					local v571 = {
						["Text"] = nil,
						["TextSize"] = 14,
						["FontFace"] = nil,
						["TextColor3"] = nil,
						["TextXAlignment"] = nil,
						["Position"] = nil,
						["Size"] = nil,
						["Parent"] = nil,
						["Text"] = v568 == nil and "" or (v568 == 0 and "\194\183" or (v568 > 0 and "+" or "\226\136\146") .. v_u_5.formatCash((math.abs(v568)))),
						["FontFace"] = v_u_18.FONT_BOLD
					}
					local v572
					if v568 and v568 > 0 then
						v572 = v_u_18.GREEN_TEXT
					elseif v568 and v568 < 0 then
						v572 = Color3.fromRGB(255, 110, 110)
					else
						v572 = v_u_18.TEXT_DIM
					end
					v571.TextColor3 = v572
					v571.TextXAlignment = Enum.TextXAlignment.Left
					v571.Position = UDim2.fromScale(0.64, 0)
					v571.Size = UDim2.new(0.22, 0, 1, 0)
					v571.Parent = v569
					v570(v571)
					v_u_18.text({
						["Text"] = nil,
						["TextSize"] = 13,
						["TextColor3"] = nil,
						["TextXAlignment"] = nil,
						["Position"] = nil,
						["Size"] = nil,
						["Parent"] = nil,
						["Text"] = ("%d \240\159\143\141"):format(v566.vehicles or 0),
						["TextColor3"] = v_u_18.TEXT_DIM,
						["TextXAlignment"] = Enum.TextXAlignment.Right,
						["Position"] = UDim2.fromScale(0.86, 0),
						["Size"] = UDim2.new(0.14, -10, 1, 0),
						["Parent"] = v569
					})
				end
				if v563.note then
					v_u_18.text({
						["Text"] = nil,
						["TextSize"] = 13,
						["TextColor3"] = nil,
						["TextWrapped"] = true,
						["TextXAlignment"] = nil,
						["Size"] = nil,
						["AutomaticSize"] = nil,
						["LayoutOrder"] = 999,
						["Parent"] = nil,
						["Text"] = v563.note,
						["TextColor3"] = v_u_18.TEXT_DIM,
						["TextXAlignment"] = Enum.TextXAlignment.Left,
						["Size"] = UDim2.new(1, 0, 0, 0),
						["AutomaticSize"] = Enum.AutomaticSize.Y,
						["Parent"] = v564
					})
				end
			end
		end
		if #v_u_434 > 0 then
			local v573 = v_u_209(v_u_191, 4)
			v_u_18.new("UIListLayout", {
				["Padding"] = UDim.new(0, 6),
				["SortOrder"] = Enum.SortOrder.LayoutOrder,
				["Parent"] = v573
			})
			v_u_248(v573, 0, "Recent")
			for v574, v_u_575 in v_u_434 do
				local v576 = v_u_18.new("TextButton", {
					["Text"] = "",
					["AutoButtonColor"] = false,
					["BackgroundColor3"] = nil,
					["Size"] = nil,
					["LayoutOrder"] = nil,
					["Parent"] = nil,
					["BackgroundColor3"] = v_u_18.CARD_DARK,
					["Size"] = UDim2.new(1, 0, 0, 44),
					["LayoutOrder"] = v574,
					["Parent"] = v573
				})
				v_u_18.corner(v576, 10)
				local v577 = v_u_18.new("ImageLabel", {
					["BackgroundColor3"] = Color3.fromRGB(30, 32, 44),
					["Image"] = ("rbxthumb://type=AvatarHeadShot&id=%d&w=48&h=48"):format(v_u_575.id),
					["Position"] = UDim2.fromOffset(6, 5),
					["Size"] = UDim2.fromOffset(34, 34),
					["Parent"] = v576
				})
				v_u_18.corner(v577, 17)
				v_u_18.text({
					["Text"] = nil,
					["TextSize"] = 15,
					["FontFace"] = nil,
					["TextXAlignment"] = nil,
					["TextTruncate"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["Parent"] = nil,
					["Text"] = v_u_575.display .. (v_u_575.display == v_u_575.name and "" or "  @" .. v_u_575.name),
					["FontFace"] = v_u_18.FONT_HEAVY,
					["TextXAlignment"] = Enum.TextXAlignment.Left,
					["TextTruncate"] = Enum.TextTruncate.AtEnd,
					["Position"] = UDim2.fromOffset(50, 0),
					["Size"] = UDim2.new(1, -60, 1, 0),
					["Parent"] = v576
				})
				v576.Activated:Connect(function()
					-- upvalues: (ref) v_u_437, (copy) v_u_575, (ref) v_u_448
					v_u_437 = v_u_575.name
					local v578 = task.spawn
					local v579 = v_u_448
					local v580 = v_u_575.id
					v578(v579, (tostring(v580)))
				end)
			end
		end
	else
		v_u_18.text({
			["Text"] = "Only the Owner can look players up",
			["TextSize"] = 16,
			["TextColor3"] = nil,
			["Size"] = nil,
			["LayoutOrder"] = 1,
			["Parent"] = nil,
			["TextColor3"] = v_u_18.TEXT_DIM,
			["Size"] = UDim2.new(1, 0, 0, 40),
			["Parent"] = v_u_191
		})
	end
end
local v_u_581 = "Players"
local v_u_582 = {
	["glide"] = "\224\185\128\224\184\165\224\184\183\224\185\136\224\184\173\224\184\153\224\185\128\224\184\130\224\185\137\224\184\178\224\184\136\224\184\184\224\184\148\224\184\163\224\184\177\224\184\154/\224\184\170\224\185\136\224\184\135\224\184\151\224\184\177\224\185\137\224\184\135\224\184\151\224\184\181\224\185\136\224\184\132\224\184\167\224\184\178\224\184\161\224\185\128\224\184\163\224\185\135\224\184\167 0 (Grab.lua)",
	["slide"] = "\224\184\163\224\184\150\224\185\132\224\184\150\224\184\165\224\184\132\224\184\153\224\184\165\224\184\176\224\184\151\224\184\178\224\184\135\224\184\129\224\184\177\224\184\154\224\184\132\224\184\167\224\184\178\224\184\161\224\185\128\224\184\163\224\185\135\224\184\167\224\184\149\224\184\177\224\184\167\224\185\128\224\184\173\224\184\135 (GPS)",
	["nopress"] = "\224\184\149\224\184\173\224\184\154\224\184\132\224\184\179\224\184\150\224\184\178\224\184\161\224\184\129\224\184\177\224\184\153\224\184\154\224\184\173\224\184\151\224\185\130\224\184\148\224\184\162\224\185\132\224\184\161\224\185\136\224\184\161\224\184\181\224\184\129\224\184\178\224\184\163\224\184\129\224\184\148\224\184\136\224\184\163\224\184\180\224\184\135",
	["shopblink"] = "\224\185\130\224\184\156\224\184\165\224\185\136\224\184\171\224\184\153\224\185\137\224\184\178\224\184\163\224\185\137\224\184\178\224\184\153\224\184\151\224\184\177\224\184\153\224\184\151\224\184\181\224\184\136\224\184\178\224\184\129\224\184\151\224\184\181\224\185\136\224\185\132\224\184\129\224\184\165 (\224\184\171\224\184\161\224\184\167\224\184\129/\224\184\165\224\184\185\224\184\129\224\184\170\224\184\185\224\184\154)",
	["shopfar"] = "\224\184\170\224\184\177\224\185\136\224\184\135\224\184\163\224\185\137\224\184\178\224\184\153\224\184\136\224\184\178\224\184\129\224\184\151\224\184\181\224\185\136\224\185\132\224\184\129\224\184\165",
	["shopwarp"] = "\224\184\167\224\184\178\224\184\155\224\184\165\224\184\135\224\184\171\224\184\153\224\185\137\224\184\178\224\184\163\224\185\137\224\184\178\224\184\153",
	["luarmor"] = "\224\184\154\224\184\163\224\184\163\224\184\151\224\184\177\224\184\148\224\184\130\224\184\173\224\184\135 Luarmor \224\185\131\224\184\153 F9 (Lunode)",
	["ecutimer"] = "\224\185\129\224\184\159\224\184\165\224\184\138 ECU \224\184\171\224\185\136\224\184\178\224\184\135\224\185\128\224\184\151\224\185\136\224\184\178\224\184\129\224\184\177\224\184\153\224\185\128\224\184\155\224\185\138\224\184\176 (\224\184\149\224\184\177\224\184\167\224\184\136\224\184\185\224\184\153\224\184\173\224\184\177\224\184\149\224\185\130\224\184\153\224\184\161\224\184\177\224\184\149\224\184\180)",
	["ecuauto"] = "\224\184\136\224\184\185\224\184\153 ECU \224\185\132\224\184\165\224\185\136\224\184\151\224\184\184\224\184\129\224\184\132\224\184\177\224\184\153 (Lunode)",
	["launch"] = "\224\184\173\224\184\173\224\184\129\224\184\149\224\184\177\224\184\167\224\184\136\224\184\178\224\184\129\224\184\136\224\184\184\224\184\148\224\184\170\224\185\136\224\184\135\224\184\130\224\184\173\224\184\135\224\185\128\224\184\163\224\185\135\224\184\167\224\185\128\224\184\129\224\184\180\224\184\153\224\185\128\224\184\132\224\184\163\224\184\183\224\185\136\224\184\173\224\184\135 (\224\185\128\224\184\148\224\184\180\224\184\161 T-7B00)"
}
local v_u_583 = false
local v_u_584 = 1
local v_u_585 = 0
local v_u_586 = nil
local function v_u_602(p587, p588, p_u_589) -- name: watchPager
	-- upvalues: (copy) v_u_18, (ref) v_u_584, (ref) v_u_586
	local v590 = v_u_18.new("Frame", {
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["LayoutOrder"] = nil,
		["Parent"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 38),
		["LayoutOrder"] = p588,
		["Parent"] = p587
	})
	local v591 = v_u_18.button({
		["name"] = "WatchPrev",
		["text"] = "\226\151\128 \224\184\129\224\185\136\224\184\173\224\184\153\224\184\171\224\184\153\224\185\137\224\184\178",
		["grad"] = nil,
		["textSize"] = 14,
		["position"] = nil,
		["size"] = nil,
		["parent"] = nil,
		["grad"] = p_u_589.page > 1 and "dark" or "grey",
		["position"] = UDim2.fromScale(0, 0),
		["size"] = UDim2.new(0, 130, 1, 0),
		["parent"] = v590
	})
	local v592 = v_u_18.button({
		["name"] = "WatchNext",
		["text"] = "\224\184\150\224\184\177\224\184\148\224\185\132\224\184\155 \226\150\182",
		["grad"] = nil,
		["textSize"] = 14,
		["anchor"] = nil,
		["position"] = nil,
		["size"] = nil,
		["parent"] = nil,
		["grad"] = p_u_589.page < p_u_589.pages and "dark" or "grey",
		["anchor"] = Vector2.new(1, 0),
		["position"] = UDim2.fromScale(1, 0),
		["size"] = UDim2.new(0, 130, 1, 0),
		["parent"] = v590
	})
	local v593 = v_u_18.text
	local v594 = {
		["Text"] = nil,
		["TextSize"] = 14,
		["FontFace"] = nil,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil
	}
	local v595 = p_u_589.page
	local v596 = p_u_589.pages
	local v597 = p_u_589.from
	local v598 = p_u_589.total
	local v599 = math.min(v597, v598)
	local v600 = p_u_589.from + #p_u_589.rows - 1
	local v601 = p_u_589.total
	v594.Text = ("\224\184\171\224\184\153\224\185\137\224\184\178 %d / %d  \194\183  \224\184\132\224\184\153\224\184\151\224\184\181\224\185\136 %d\226\128\147%d \224\184\136\224\184\178\224\184\129 %d"):format(v595, v596, v599, math.min(v600, v601), p_u_589.total)
	v594.FontFace = v_u_18.FONT_BOLD
	v594.AnchorPoint = Vector2.new(0.5, 0)
	v594.Position = UDim2.fromScale(0.5, 0)
	v594.Size = UDim2.new(1, -280, 1, 0)
	v594.Parent = v590
	v593(v594)
	v591.Activated:Connect(function()
		-- upvalues: (copy) p_u_589, (ref) v_u_584, (ref) v_u_586
		if p_u_589.page > 1 then
			v_u_584 = p_u_589.page - 1
			task.spawn(v_u_586)
		end
	end)
	v592.Activated:Connect(function()
		-- upvalues: (copy) p_u_589, (ref) v_u_584, (ref) v_u_586
		if p_u_589.page < p_u_589.pages then
			v_u_584 = p_u_589.page + 1
			task.spawn(v_u_586)
		end
	end)
end
v_u_586 = function()
	-- upvalues: (ref) v_u_585, (ref) v_u_200, (copy) v_u_264, (copy) v_u_192, (copy) v_u_18, (copy) v_u_106, (ref) v_u_584, (ref) v_u_581, (copy) v_u_209, (ref) v_u_586, (ref) v_u_583, (copy) v_u_53, (copy) v_u_602, (copy) v_u_582, (copy) v_u_126
	v_u_585 = v_u_585 + 1
	local v_u_603 = v_u_585
	if v_u_200.WatchList then
		local v604, v605 = v_u_106("WatchList", v_u_584)
		if v_u_581 == "Watch" and v_u_603 == v_u_585 then
			v_u_264(v_u_192)
			if v604 and type(v605) == "table" then
				local v606 = v605.rows
				v605.rows = type(v606) ~= "table" and {} or v605.rows
				local v607 = v605.page
				local v608 = tonumber(v607) or 1
				local v609 = v605.pages
				local v610 = tonumber(v609) or 1
				v605.page = v608
				v605.pages = v610
				local v611 = v605.from
				local v612 = tonumber(v611) or 1
				local v613 = v605.total
				local v614 = tonumber(v613) or #v605.rows
				v605.from = v612
				v605.total = v614
				v_u_584 = v605.page
				local v615 = v605.run
				local v616
				if type(v615) == "table" then
					v616 = v605.run
				else
					v616 = nil
				end
				local v617 = v_u_209(v_u_192, 1)
				v_u_18.new("UIListLayout", {
					["Padding"] = UDim.new(0, 8),
					["SortOrder"] = Enum.SortOrder.LayoutOrder,
					["Parent"] = v617
				})
				local v618 = {}
				local v619 = v605.total
				local v620 = v605.open
				local v621 = tonumber(v620) or 0
				local v622 = v605.banned
				local v623 = ("\240\159\154\169 \224\184\163\224\184\178\224\184\162\224\184\138\224\184\183\224\185\136\224\184\173\224\185\128\224\184\157\224\185\137\224\184\178\224\184\148\224\184\185: %d \224\184\132\224\184\153  \194\183  \224\184\162\224\184\177\224\184\135\224\185\132\224\184\161\224\185\136\224\185\129\224\184\154\224\184\153 %d  \194\183  \224\185\129\224\184\154\224\184\153\224\185\129\224\184\165\224\185\137\224\184\167 %d"):format(v619, v621, tonumber(v622) or 0)
				local v624 = v605.wave
				local v625 = tonumber(v624) or 0
				local v626 = v605.review
				__set_list(v618, 1, {v623, ("\226\156\133 \224\184\138\224\184\177\224\184\167\224\184\163\224\185\140 (\224\185\128\224\184\130\224\185\137\224\184\178 Ban wave) %d \224\184\132\224\184\153  \194\183  \240\159\159\161 \224\184\163\224\184\173\224\184\148\224\184\185\224\184\149\224\185\136\224\184\173 %d \224\184\132\224\184\153"):format(v625, tonumber(v626) or 0), "Ban wave \224\185\129\224\184\154\224\184\153\224\185\128\224\184\137\224\184\158\224\184\178\224\184\176 \226\156\133 \224\184\138\224\184\177\224\184\167\224\184\163\224\185\140: \224\184\161\224\184\181\224\184\170\224\184\177\224\184\141\224\184\141\224\184\178\224\184\147\224\184\151\224\184\181\224\185\136\224\184\132\224\184\153\224\185\128\224\184\165\224\185\136\224\184\153\224\184\155\224\184\129\224\184\149\224\184\180\224\184\151\224\184\179\224\185\132\224\184\161\224\185\136\224\185\132\224\184\148\224\185\137 (F9 \224\184\130\224\184\173\224\184\135 Luarmor, \224\184\149\224\184\173\224\184\154\224\185\132\224\184\161\224\185\136\224\184\129\224\184\148, \224\184\136\224\184\185\224\184\153\224\184\148\224\185\137\224\184\167\224\184\162\224\184\153\224\184\178\224\184\172\224\184\180\224\184\129\224\184\178\224\184\170\224\184\132\224\184\163\224\184\180\224\184\155\224\184\149\224\185\140, \224\185\129\224\184\129\224\185\137\224\184\132\224\185\136\224\184\178\224\185\128\224\184\129\224\184\161, \224\184\149\224\184\177\224\184\167\224\184\130\224\184\177\224\184\154\224\184\154\224\184\180\224\184\153, Lunode \224\184\171\224\184\153\224\185\137\224\184\178\224\184\163\224\185\137\224\184\178\224\184\153) \224\184\171\224\184\163\224\184\183\224\184\173\224\184\170\224\184\177\224\184\141\224\184\141\224\184\178\224\184\147\224\185\128\224\184\170\224\184\181\224\185\136\224\184\162\224\184\135\224\184\149\224\185\136\224\184\178\224\184\135\224\184\138\224\184\153\224\184\180\224\184\148\224\184\129\224\184\177\224\184\153 2 \224\185\129\224\184\154\224\184\154\224\184\130\224\184\182\224\185\137\224\184\153\224\185\132\224\184\155", "\240\159\159\161 \224\184\163\224\184\173\224\184\148\224\184\185\224\184\149\224\185\136\224\184\173 = \224\184\161\224\184\181\224\185\129\224\184\149\224\185\136\224\184\170\224\184\177\224\184\141\224\184\141\224\184\178\224\184\147\224\184\151\224\184\181\224\185\136\224\184\132\224\184\153\224\185\128\224\184\153\224\185\135\224\184\149\224\185\129\224\184\165\224\184\132/\224\185\128\224\184\165\224\185\136\224\184\153\224\184\136\224\184\163\224\184\180\224\184\135\224\184\173\224\184\178\224\184\136\224\185\130\224\184\148\224\184\153 (\224\184\132\224\184\167\224\184\178\224\184\161\224\185\128\224\184\163\224\185\135\224\184\167, \224\184\173\224\184\173\224\184\129\224\184\149\224\184\177\224\184\167, \224\184\163\224\184\150\224\185\132\224\184\150\224\184\165, \224\184\136\224\184\185\224\184\153\224\184\171\224\184\165\224\184\178\224\184\162\224\184\132\224\184\177\224\184\153, \224\184\171\224\184\153\224\185\137\224\184\178\224\184\149\224\185\136\224\184\178\224\184\135\224\185\129\224\184\155\224\184\165\224\184\129) \194\183 Ban wave \224\185\132\224\184\161\224\185\136\224\185\129\224\184\149\224\184\176 \194\183 \224\184\148\224\184\185\224\184\171\224\184\165\224\184\177\224\184\129\224\184\144\224\184\178\224\184\153\224\185\129\224\184\165\224\185\137\224\184\167\224\184\129\224\184\148 Ban \224\185\128\224\184\173\224\184\135\224\184\150\224\185\137\224\184\178\224\184\138\224\184\177\224\184\148, \224\184\136\224\184\148\224\184\156\224\184\180\224\184\148\224\184\129\224\184\148 Remove", v605.alts and "Ban wave = \224\185\129\224\184\154\224\184\153\224\184\150\224\184\178\224\184\167\224\184\163 \224\184\158\224\184\163\224\185\137\224\184\173\224\184\161\224\184\154\224\184\177\224\184\141\224\184\138\224\184\181\224\184\170\224\184\179\224\184\163\224\184\173\224\184\135\224\184\151\224\184\181\224\185\136 Roblox \224\184\156\224\184\185\224\184\129\224\185\132\224\184\167\224\185\137 (\224\185\129\224\184\154\224\184\153\224\185\132\224\184\173\224\184\158\224\184\181) \194\183 \224\184\156\224\184\185\224\185\137\224\185\128\224\184\165\224\185\136\224\184\153\224\185\128\224\184\171\224\185\135\224\184\153\224\185\129\224\184\132\224\185\136\224\184\163\224\184\171\224\184\177\224\184\170 W-\224\185\128\224\184\148\224\184\183\224\184\173\224\184\153\224\184\167\224\184\177\224\184\153 \194\183 \224\184\155\224\184\165\224\184\148\224\185\132\224\184\148\224\185\137\224\184\151\224\184\181\224\185\136 Unban" or "Ban wave = \224\185\129\224\184\154\224\184\153\224\184\150\224\184\178\224\184\167\224\184\163\224\185\128\224\184\137\224\184\158\224\184\178\224\184\176\224\184\154\224\184\177\224\184\141\224\184\138\224\184\181\224\184\153\224\184\177\224\185\137\224\184\153 \194\183 \224\184\156\224\184\185\224\185\137\224\185\128\224\184\165\224\185\136\224\184\153\224\185\128\224\184\171\224\185\135\224\184\153\224\185\129\224\184\132\224\185\136\224\184\163\224\184\171\224\184\177\224\184\170 W-\224\185\128\224\184\148\224\184\183\224\184\173\224\184\153\224\184\167\224\184\177\224\184\153 \194\183 \224\184\155\224\184\165\224\184\148\224\185\132\224\184\148\224\185\137\224\184\151\224\184\181\224\185\136 Unban"})
				if v616 then
					local v627
					if v616.running then
						local v628 = v616.code
						local v629 = tostring(v628)
						local v630 = v616.by
						local v631 = tostring(v630)
						local v632 = v616.done
						local v633 = tonumber(v632) or 0
						local v634 = v616.total
						local v635 = tonumber(v634) or 0
						local v636 = v616.failed
						v627 = ("\226\143\179 \224\184\129\224\184\179\224\184\165\224\184\177\224\184\135\224\185\129\224\184\154\224\184\153 (Ban wave %s \224\185\130\224\184\148\224\184\162 %s): %d / %d%s"):format(v629, v631, v633, v635, (tonumber(v636) or 0) <= 0 and "" or (" \194\183 \224\185\132\224\184\161\224\185\136\224\184\170\224\184\179\224\185\128\224\184\163\224\185\135\224\184\136 %d"):format(v616.failed))
					else
						local v637 = v616.code
						local v638 = tostring(v637)
						local v639 = v616.by
						local v640 = tostring(v639)
						local v641 = v616.done
						local v642 = tonumber(v641) or 0
						local v643 = v616.failed
						local v644 = v642 - (tonumber(v643) or 0)
						local v645 = v616.total
						local v646 = tonumber(v645) or 0
						local v647 = v616.failed
						v627 = ("\226\156\133 Ban wave \224\184\165\224\185\136\224\184\178\224\184\170\224\184\184\224\184\148 (%s \224\185\130\224\184\148\224\184\162 %s): \224\185\129\224\184\154\224\184\153\224\185\129\224\184\165\224\185\137\224\184\167 %d / %d%s"):format(v638, v640, v644, v646, (tonumber(v647) or 0) <= 0 and "" or (" \194\183 \224\185\132\224\184\161\224\185\136\224\184\170\224\184\179\224\185\128\224\184\163\224\185\135\224\184\136 %d (\224\184\129\224\184\148 Ban wave \224\184\173\224\184\181\224\184\129\224\184\132\224\184\163\224\184\177\224\185\137\224\184\135)"):format(v616.failed))
					end
					table.insert(v618, v627)
				end
				local v648 = v605.purged
				if (tonumber(v648) or 0) > 0 then
					local v649 = v605.purged
					local v650 = tonumber(v649)
					table.insert(v618, ("\240\159\167\185 \224\185\128\224\184\173\224\184\178\224\184\132\224\184\153\224\184\151\224\184\181\224\185\136\224\185\132\224\184\161\224\185\136\224\184\138\224\184\177\224\184\167\224\184\163\224\185\140 (\224\184\170\224\184\177\224\184\141\224\184\141\224\184\178\224\184\147\224\185\128\224\184\170\224\184\181\224\185\136\224\184\162\224\184\135\224\184\138\224\184\153\224\184\180\224\184\148\224\185\128\224\184\148\224\184\181\224\184\162\224\184\167) \224\184\173\224\184\173\224\184\129\224\184\136\224\184\178\224\184\129\224\184\163\224\184\178\224\184\162\224\184\138\224\184\183\224\185\136\224\184\173\224\185\129\224\184\165\224\185\137\224\184\167 %d \224\184\132\224\184\153 \194\183 \224\184\149\224\185\136\224\184\173\224\184\136\224\184\178\224\184\129\224\184\153\224\184\181\224\185\137\224\184\165\224\184\135\224\185\128\224\184\137\224\184\158\224\184\178\224\184\176\224\184\132\224\184\153\224\184\151\224\184\181\224\185\136\224\184\138\224\184\177\224\184\167\224\184\163\224\185\140"):format(v650))
				end
				if v605.note then
					local v651 = v605.note
					local v652 = "\226\154\160\239\184\143 " .. tostring(v651)
					table.insert(v618, v652)
				end
				v_u_18.text({
					["Text"] = nil,
					["TextSize"] = 14,
					["FontFace"] = nil,
					["TextXAlignment"] = nil,
					["TextWrapped"] = true,
					["Size"] = nil,
					["AutomaticSize"] = nil,
					["LayoutOrder"] = 1,
					["Parent"] = nil,
					["Text"] = table.concat(v618, "\n"),
					["FontFace"] = v_u_18.FONT_BOLD,
					["TextXAlignment"] = Enum.TextXAlignment.Left,
					["Size"] = UDim2.new(1, 0, 0, 0),
					["AutomaticSize"] = Enum.AutomaticSize.Y,
					["Parent"] = v617
				})
				local v653 = v_u_18.new("Frame", {
					["BackgroundTransparency"] = 1,
					["Size"] = nil,
					["LayoutOrder"] = 2,
					["Parent"] = nil,
					["Size"] = UDim2.new(1, 0, 0, 42),
					["Parent"] = v617
				})
				v_u_18.button({
					["name"] = "WatchRefresh",
					["text"] = "Refresh",
					["icon"] = "zap",
					["grad"] = "dark",
					["textSize"] = 15,
					["position"] = nil,
					["size"] = nil,
					["parent"] = nil,
					["position"] = UDim2.fromScale(0, 0),
					["size"] = UDim2.new(0, 130, 1, 0),
					["parent"] = v653
				}).Activated:Connect(function()
					-- upvalues: (ref) v_u_586
					task.spawn(v_u_586)
				end)
				if v_u_200.BanWave then
					local v654 = v605.wave
					local v_u_655 = tonumber(v654) or 0
					local v_u_656 = ("Ban wave (%d)"):format(v_u_655)
					if v616 and v616.running then
						local v657 = v_u_18.button
						local v658 = {
							["name"] = "BanWave",
							["text"] = nil,
							["icon"] = "shield",
							["grad"] = "grey",
							["textSize"] = 15,
							["anchor"] = nil,
							["position"] = nil,
							["size"] = nil,
							["parent"] = nil
						}
						local v659 = v616.done
						local v660 = tonumber(v659) or 0
						local v661 = v616.total
						v658.text = ("Banning %d / %d\226\128\166"):format(v660, tonumber(v661) or 0)
						v658.anchor = Vector2.new(1, 0)
						v658.position = UDim2.fromScale(1, 0)
						v658.size = UDim2.new(0, 250, 1, 0)
						v658.parent = v653
						v657(v658)
					else
						local v_u_662 = v_u_18.button({
							["name"] = "BanWave",
							["text"] = nil,
							["icon"] = "shield",
							["grad"] = nil,
							["textSize"] = 15,
							["anchor"] = nil,
							["position"] = nil,
							["size"] = nil,
							["parent"] = nil,
							["text"] = v_u_656,
							["grad"] = v_u_655 > 0 and "red" or "grey",
							["anchor"] = Vector2.new(1, 0),
							["position"] = UDim2.fromScale(1, 0),
							["size"] = UDim2.new(0, 250, 1, 0),
							["parent"] = v653
						})
						if v_u_655 > 0 then
							local v_u_663 = ("Sure? Ban %d for good"):format(v_u_655)
							local function v_u_666()
								-- upvalues: (ref) v_u_583, (ref) v_u_18, (copy) v_u_662, (ref) v_u_106, (copy) v_u_655, (ref) v_u_53, (ref) v_u_586
								if not v_u_583 then
									v_u_583 = true
									v_u_18.setButton(v_u_662, "grey", "Starting\226\128\166")
									local v664, v665 = v_u_106("BanWave", v_u_655)
									v_u_583 = false
									if v665 then
										v_u_53.show(tostring(v665), v664 and "ok" or "error")
									end
									task.spawn(v_u_586)
								end
							end
							local v_u_667 = nil
							local v_u_668 = "red"
							v_u_662.Activated:Connect(function()
								-- upvalues: (ref) v_u_667, (ref) v_u_18, (copy) v_u_662, (copy) v_u_668, (copy) v_u_656, (copy) v_u_666, (copy) v_u_663
								if v_u_667 and os.clock() - v_u_667 < 4 then
									v_u_667 = nil
									v_u_18.setButton(v_u_662, v_u_668, v_u_656)
									v_u_666()
								else
									local v_u_669 = os.clock()
									v_u_667 = v_u_669
									v_u_18.setButton(v_u_662, "red", v_u_663)
									task.delay(4, function()
										-- upvalues: (ref) v_u_667, (copy) v_u_669, (ref) v_u_662, (ref) v_u_18, (ref) v_u_668, (ref) v_u_656
										if v_u_667 == v_u_669 then
											v_u_667 = nil
											if v_u_662.Parent then
												v_u_18.setButton(v_u_662, v_u_668, v_u_656)
											end
										end
									end)
								end
							end)
						end
					end
				else
					v_u_18.text({
						["Text"] = "Ban wave: Owner only",
						["TextSize"] = 14,
						["TextColor3"] = nil,
						["TextXAlignment"] = nil,
						["AnchorPoint"] = nil,
						["Position"] = nil,
						["Size"] = nil,
						["Parent"] = nil,
						["TextColor3"] = v_u_18.TEXT_DIM,
						["TextXAlignment"] = Enum.TextXAlignment.Right,
						["AnchorPoint"] = Vector2.new(1, 0),
						["Position"] = UDim2.fromScale(1, 0),
						["Size"] = UDim2.new(0, 250, 1, 0),
						["Parent"] = v653
					})
				end
				if v605.pages > 1 then
					v_u_602(v_u_192, 2, v605)
				end
				for v670, v_u_671 in v605.rows do
					local v672 = v_u_209(v_u_192, 10 + v670)
					local v673 = v_u_671.id
					v672.Name = "Watch_" .. tostring(v673)
					local v674 = v_u_18.new("Frame", {
						["BackgroundTransparency"] = 1,
						["Size"] = nil,
						["AutomaticSize"] = nil,
						["Parent"] = nil,
						["Size"] = UDim2.new(1, -120, 0, 0),
						["AutomaticSize"] = Enum.AutomaticSize.Y,
						["Parent"] = v672
					})
					v_u_18.new("UIListLayout", {
						["Padding"] = UDim.new(0, 4),
						["SortOrder"] = Enum.SortOrder.LayoutOrder,
						["Parent"] = v674
					})
					local v675
					if v_u_671.banned then
						local v676 = os.date("%d/%m %H:%M", v_u_671.banned)
						local v677 = v_u_671.bannedBy or "?"
						v675 = ("\240\159\148\168 \224\185\129\224\184\154\224\184\153\224\185\129\224\184\165\224\185\137\224\184\167 %s \224\185\130\224\184\148\224\184\162 %s"):format(v676, (tostring(v677)))
					else
						v675 = v_u_671.staff and "\224\184\151\224\184\181\224\184\161\224\184\135\224\184\178\224\184\153 (Ban wave \224\185\132\224\184\161\224\185\136\224\185\129\224\184\149\224\184\176)" or (v_u_671.sure and "\226\156\133 \224\184\138\224\184\177\224\184\167\224\184\163\224\185\140 \194\183 \224\185\128\224\184\130\224\185\137\224\184\178 Ban wave" or "\240\159\159\161 \224\184\163\224\184\173\224\184\148\224\184\185\224\184\149\224\185\136\224\184\173 (Ban wave \224\185\132\224\184\161\224\185\136\224\185\129\224\184\149\224\184\176 \194\183 \224\184\148\224\184\185\224\184\171\224\184\165\224\184\177\224\184\129\224\184\144\224\184\178\224\184\153\224\185\129\224\184\165\224\185\137\224\184\167\224\184\129\224\184\148 Ban \224\185\128\224\184\173\224\184\135)")
					end
					local v678 = v_u_671.display
					local v679
					if type(v678) == "string" and v_u_671.display ~= "" then
						v679 = v_u_671.display
					else
						local v680 = v_u_671.name
						v679 = tostring(v680)
					end
					local v681 = v_u_671.hubs
					local v682 = (type(v681) ~= "string" or v_u_671.hubs == "") and "" or ("[%s]  "):format(v_u_671.hubs)
					local v683 = v_u_18.text
					local v684 = {
						["Text"] = nil,
						["TextSize"] = 14,
						["FontFace"] = nil,
						["TextXAlignment"] = nil,
						["TextWrapped"] = true,
						["TextColor3"] = nil,
						["Size"] = nil,
						["AutomaticSize"] = nil,
						["LayoutOrder"] = 1,
						["Parent"] = nil
					}
					local v685 = v_u_671.name
					local v686 = tostring(v685)
					local v687 = v_u_671.id
					local v688 = tonumber(v687) or 0
					local v689 = v_u_671.n
					v684.Text = ("%s%s (@%s) \194\183 %d   \194\183   %d \224\184\163\224\184\173\224\184\154\224\185\128\224\184\165\224\185\136\224\184\153 \194\183 \224\184\165\224\185\136\224\184\178\224\184\170\224\184\184\224\184\148 %s   \194\183   %s"):format(v682, v679, v686, v688, tonumber(v689) or 0, os.date("%d/%m %H:%M", v_u_671.last or 0), v675)
					v684.FontFace = v_u_18.FONT_BOLD
					v684.TextXAlignment = Enum.TextXAlignment.Left
					local v690
					if v_u_671.banned then
						v690 = v_u_18.TEXT_DIM
					else
						v690 = v_u_18.TEXT
					end
					v684.TextColor3 = v690
					v684.Size = UDim2.new(1, 0, 0, 0)
					v684.AutomaticSize = Enum.AutomaticSize.Y
					v684.Parent = v674
					v683(v684)
					local v691 = v_u_671.signs
					local v692 = {}
					for _, v693 in type(v691) ~= "table" and {} or v_u_671.signs do
						local v694 = "\226\128\162 %s  (%s)"
						local v695 = v_u_582[v693.id]
						if not v695 then
							local v696 = v693.id
							v695 = tostring(v696)
						end
						local v697 = v693.d
						local v698 = tostring(v697)
						table.insert(v692, v694:format(v695, v698))
					end
					v_u_18.text({
						["Text"] = nil,
						["TextSize"] = 13,
						["TextColor3"] = nil,
						["TextXAlignment"] = nil,
						["TextWrapped"] = true,
						["Size"] = nil,
						["AutomaticSize"] = nil,
						["LayoutOrder"] = 2,
						["Parent"] = nil,
						["Text"] = table.concat(v692, "\n"),
						["TextColor3"] = v_u_18.TEXT_DIM,
						["TextXAlignment"] = Enum.TextXAlignment.Left,
						["Size"] = UDim2.new(1, 0, 0, 0),
						["AutomaticSize"] = Enum.AutomaticSize.Y,
						["Parent"] = v674
					})
					if v_u_200.WatchDrop and not v_u_671.banned then
						local v_u_699 = v_u_18.button({
							["name"] = "WatchRemove",
							["text"] = "Remove",
							["grad"] = "dark",
							["textSize"] = 13,
							["anchor"] = nil,
							["position"] = nil,
							["size"] = nil,
							["parent"] = nil,
							["anchor"] = Vector2.new(1, 0),
							["position"] = UDim2.fromScale(1, 0),
							["size"] = UDim2.fromOffset(110, 32),
							["parent"] = v672
						})
						local function v_u_702()
							-- upvalues: (ref) v_u_106, (copy) v_u_671, (ref) v_u_53, (ref) v_u_586
							local v700, v701 = v_u_106("WatchDrop", v_u_671.id)
							if v701 then
								v_u_53.show(tostring(v701), v700 and "ok" or "error")
							end
							task.spawn(v_u_586)
						end
						local v_u_703 = nil
						local v_u_704 = "dark"
						local v_u_705 = "Remove"
						local v_u_706 = "Sure?"
						v_u_699.Activated:Connect(function()
							-- upvalues: (ref) v_u_703, (ref) v_u_18, (copy) v_u_699, (copy) v_u_704, (copy) v_u_705, (copy) v_u_702, (copy) v_u_706
							if v_u_703 and os.clock() - v_u_703 < 4 then
								v_u_703 = nil
								v_u_18.setButton(v_u_699, v_u_704, v_u_705)
								v_u_702()
							else
								local v_u_707 = os.clock()
								v_u_703 = v_u_707
								v_u_18.setButton(v_u_699, "red", v_u_706)
								task.delay(4, function()
									-- upvalues: (ref) v_u_703, (copy) v_u_707, (ref) v_u_699, (ref) v_u_18, (ref) v_u_704, (ref) v_u_705
									if v_u_703 == v_u_707 then
										v_u_703 = nil
										if v_u_699.Parent then
											v_u_18.setButton(v_u_699, v_u_704, v_u_705)
										end
									end
								end)
							end
						end)
					end
					if not v_u_200.Ban or (v_u_671.banned or (v_u_671.sure or v_u_671.staff)) then
						break
					end
					local v_u_708 = v_u_18.button({
						["name"] = "WatchBan",
						["text"] = "Ban",
						["icon"] = "shield",
						["grad"] = "red",
						["textSize"] = 13,
						["anchor"] = nil,
						["position"] = nil,
						["size"] = nil,
						["parent"] = nil,
						["anchor"] = Vector2.new(1, 0),
						["position"] = UDim2.new(1, 0, 0, 38),
						["size"] = UDim2.fromOffset(110, 32),
						["parent"] = v672
					})
					local function v_u_711()
						-- upvalues: (ref) v_u_106, (copy) v_u_671, (ref) v_u_53, (ref) v_u_586
						local v709, v710 = v_u_106("WatchBan", v_u_671.id)
						if v710 then
							v_u_53.show(tostring(v710), v709 and "ok" or "error")
						end
						task.spawn(v_u_586)
					end
					local v_u_712 = nil
					local v_u_713 = "red"
					local v_u_714 = "Ban"
					local v_u_715 = "Sure? Ban"
					v_u_708.Activated:Connect(function()
						-- upvalues: (ref) v_u_712, (ref) v_u_18, (copy) v_u_708, (copy) v_u_713, (copy) v_u_714, (copy) v_u_711, (copy) v_u_715
						if v_u_712 and os.clock() - v_u_712 < 4 then
							v_u_712 = nil
							v_u_18.setButton(v_u_708, v_u_713, v_u_714)
							v_u_711()
						else
							local v_u_716 = os.clock()
							v_u_712 = v_u_716
							v_u_18.setButton(v_u_708, "red", v_u_715)
							task.delay(4, function()
								-- upvalues: (ref) v_u_712, (copy) v_u_716, (ref) v_u_708, (ref) v_u_18, (ref) v_u_713, (ref) v_u_714
								if v_u_712 == v_u_716 then
									v_u_712 = nil
									if v_u_708.Parent then
										v_u_18.setButton(v_u_708, v_u_713, v_u_714)
									end
								end
							end)
						end
					end)
				end
				if v605.pages > 1 and #v605.rows > 0 then
					v_u_602(v_u_192, #v605.rows + 10 + 1, v605)
				end
				if v616 and v616.running then
					task.delay(3, function()
						-- upvalues: (ref) v_u_581, (copy) v_u_603, (ref) v_u_585, (ref) v_u_126, (ref) v_u_586
						if v_u_581 == "Watch" and (v_u_603 == v_u_585 and v_u_126.isOpen()) then
							v_u_586()
						end
					end)
				end
			else
				v_u_18.text({
					["Text"] = nil,
					["TextSize"] = 16,
					["TextColor3"] = nil,
					["Size"] = nil,
					["LayoutOrder"] = 1,
					["Parent"] = nil,
					["Text"] = "Couldn\'t load the list: " .. tostring(v605),
					["TextColor3"] = v_u_18.TEXT_DIM,
					["Size"] = UDim2.new(1, 0, 0, 40),
					["Parent"] = v_u_192
				})
			end
		else
			return
		end
	else
		v_u_264(v_u_192)
		v_u_18.text({
			["Text"] = "Your rank can\'t see the watch list",
			["TextSize"] = 16,
			["TextColor3"] = nil,
			["Size"] = nil,
			["LayoutOrder"] = 1,
			["Parent"] = nil,
			["TextColor3"] = v_u_18.TEXT_DIM,
			["Size"] = UDim2.new(1, 0, 0, 40),
			["Parent"] = v_u_192
		})
		return
	end
end
local v_u_717 = 0
local v_u_718 = ""
local function v_u_812()
	-- upvalues: (ref) v_u_717, (ref) v_u_200, (copy) v_u_264, (copy) v_u_193, (copy) v_u_18, (copy) v_u_106, (ref) v_u_581, (copy) v_u_209, (copy) v_u_248, (copy) v_u_53, (ref) v_u_812, (copy) v_u_220, (ref) v_u_718, (copy) v_u_244
	v_u_717 = v_u_717 + 1
	local v719 = v_u_717
	if v_u_200.CreatorList then
		local v720, v721 = v_u_106("CreatorList")
		if v_u_581 == "Creator" and v719 == v_u_717 then
			v_u_264(v_u_193)
			if v720 and type(v721) == "table" then
				local v722 = v721.rows
				local v723 = type(v722) ~= "table" and {} or v721.rows
				local v724 = v721.holders
				local v725 = type(v724) ~= "table" and {} or v721.holders
				local v726 = v721.seized
				local v727 = type(v726) ~= "table" and {} or v721.seized
				local v728 = v_u_209(v_u_193, 1)
				v_u_18.new("UIListLayout", {
					["Padding"] = UDim.new(0, 8),
					["SortOrder"] = Enum.SortOrder.LayoutOrder,
					["Parent"] = v728
				})
				v_u_248(v728, 1, ("\224\184\161\224\184\181 Panel \224\185\131\224\184\153\224\185\128\224\184\139\224\184\180\224\184\163\224\185\140\224\184\159\224\184\170\224\184\178\224\184\152\224\184\178\224\184\163\224\184\147\224\184\176 (%d \224\184\132\224\184\153)"):format(#v725))
				local v729 = v_u_18.text
				local v730 = {
					["Text"] = nil,
					["TextSize"] = 13,
					["TextColor3"] = nil,
					["TextWrapped"] = true,
					["TextXAlignment"] = nil,
					["Size"] = nil,
					["AutomaticSize"] = nil,
					["LayoutOrder"] = 2,
					["Parent"] = nil
				}
				local v731 = "\224\184\132\224\184\163\224\184\181\224\185\128\224\184\173\224\185\128\224\184\149\224\184\173\224\184\163\224\185\140\224\184\151\224\184\181\224\185\136\224\185\128\224\184\158\224\184\180\224\185\136\224\184\161\224\185\129\224\184\154\224\184\154 \224\184\151\224\184\184\224\184\129\224\185\128\224\184\139\224\184\180\224\184\163\224\185\140\224\184\159 (Server Panel: \224\185\128\224\184\149\224\184\176 / \224\184\167\224\184\178\224\184\155 / \224\184\148\224\184\182\224\184\135) \224\185\129\224\184\165\224\184\176\224\184\154\224\184\177\224\184\141\224\184\138\224\184\181\224\185\128\224\184\161\224\184\153\224\184\185\224\184\165\224\184\177\224\184\154 (\224\185\129\224\184\154\224\184\153 / \224\184\155\224\184\165\224\184\148\224\185\129\224\184\154\224\184\153) \194\183 Toxic \224\184\129\224\184\148 \224\184\162\224\184\182\224\184\148 Panel \224\184\132\224\184\183\224\184\153 = \224\185\131\224\184\138\224\185\137\224\185\132\224\184\161\224\185\136\224\185\132\224\184\148\224\185\137\224\184\151\224\184\177\224\184\153\224\184\151\224\184\181\224\184\151\224\184\184\224\184\129\224\185\128\224\184\139\224\184\180\224\184\163\224\185\140\224\184\159"
				local v732 = " \194\183 \224\184\132\224\184\183\224\184\153\224\185\131\224\184\171\224\185\137\224\185\132\224\184\148\224\185\137\224\184\151\224\184\181\224\185\136 \224\184\162\224\184\182\224\184\148 Panel \224\184\132\224\184\183\224\184\153\224\185\129\224\184\165\224\185\137\224\184\167 \224\184\148\224\185\137\224\184\178\224\184\153\224\184\165\224\185\136\224\184\178\224\184\135"
				local v733
				if v721.note then
					local v734 = v721.note
					v733 = (" \194\183 (\224\184\149\224\184\173\224\184\153\224\184\153\224\184\181\224\185\137\224\184\173\224\185\136\224\184\178\224\184\153\224\185\128\224\184\139\224\184\180\224\184\163\224\185\140\224\184\159\224\184\173\224\184\183\224\185\136\224\184\153\224\185\132\224\184\161\224\185\136\224\185\132\224\184\148\224\185\137: %s)"):format((tostring(v734)))
				else
					v733 = ""
				end
				v730.Text = v731 .. v732 .. v733
				v730.TextColor3 = v_u_18.TEXT_DIM
				v730.TextXAlignment = Enum.TextXAlignment.Left
				v730.Size = UDim2.new(1, 0, 0, 0)
				v730.AutomaticSize = Enum.AutomaticSize.Y
				v730.Parent = v728
				v729(v730)
				for v735, v_u_736 in v725 do
					local v737 = v_u_209(v_u_193, 10 + v735, 62)
					local v738 = v_u_18.text
					local v739 = {
						["Text"] = nil,
						["TextSize"] = 16,
						["FontFace"] = nil,
						["TextXAlignment"] = nil,
						["TextTruncate"] = nil,
						["Size"] = nil,
						["Parent"] = nil
					}
					local v740 = v_u_736.n
					local v741 = tostring(v740)
					local v742 = v_u_736.id
					v739.Text = ("@%s  (%s)"):format(v741, (tostring(v742)))
					v739.FontFace = v_u_18.FONT_HEAVY
					v739.TextXAlignment = Enum.TextXAlignment.Left
					v739.TextTruncate = Enum.TextTruncate.AtEnd
					v739.Size = UDim2.new(1, -160, 0, 20)
					v739.Parent = v737
					v738(v739)
					local v743 = v_u_736.kind == "banmenu" and "\224\185\128\224\184\161\224\184\153\224\184\185\224\184\165\224\184\177\224\184\154: \224\185\129\224\184\154\224\184\153 / \224\184\155\224\184\165\224\184\148\224\185\129\224\184\154\224\184\153" or "Server Panel: \224\185\128\224\184\149\224\184\176 / \224\184\167\224\184\178\224\184\155 / \224\184\148\224\184\182\224\184\135"
					local v744 = v_u_736.on
					local v745
					if type(v744) == "table" then
						v745 = v_u_736.on or nil
					else
						v745 = nil
					end
					local v746
					if v745 then
						if v745.private then
							v746 = ("<font color=\"%s\">\224\184\173\224\184\173\224\184\153\224\185\132\224\184\165\224\184\153\224\185\140 \194\183 \224\185\128\224\184\139\224\184\180\224\184\163\224\185\140\224\184\159\224\184\167\224\184\181</font>"):format("#EEE452")
						else
							v746 = ("<font color=\"%s\">\224\184\173\224\184\173\224\184\153\224\185\132\224\184\165\224\184\153\224\185\140 \194\183 \224\185\128\224\184\139\224\184\180\224\184\163\224\185\140\224\184\159\224\184\170\224\184\178\224\184\152\224\184\178\224\184\163\224\184\147\224\184\176</font>"):format("#60E896")
						end
					else
						v746 = ("<font color=\"%s\">\224\184\173\224\184\173\224\184\159\224\185\132\224\184\165\224\184\153\224\185\140</font>"):format("#8C90A0")
					end
					if v745 then
						local v747
						if v745.here then
							v747 = " (\224\185\128\224\184\139\224\184\180\224\184\163\224\185\140\224\184\159\224\184\153\224\184\181\224\185\137)"
						else
							local v748 = v745.job
							v747 = (" #%s"):format((tostring(v748)))
						end
						v746 = v746 .. v747
					end
					v_u_18.text({
						["Text"] = nil,
						["RichText"] = true,
						["TextSize"] = 13,
						["TextColor3"] = nil,
						["TextXAlignment"] = nil,
						["TextTruncate"] = nil,
						["Position"] = nil,
						["Size"] = nil,
						["Parent"] = nil,
						["Text"] = ("%s \194\183 %s"):format(v743, v746),
						["TextColor3"] = v_u_18.TEXT_DIM,
						["TextXAlignment"] = Enum.TextXAlignment.Left,
						["TextTruncate"] = Enum.TextTruncate.AtEnd,
						["Position"] = UDim2.fromOffset(0, 22),
						["Size"] = UDim2.new(1, -160, 0, 18),
						["Parent"] = v737
					})
					local v_u_749 = v_u_18.button({
						["name"] = "Seize",
						["text"] = "\224\184\162\224\184\182\224\184\148 Panel \224\184\132\224\184\183\224\184\153",
						["grad"] = "red",
						["textSize"] = 14,
						["anchor"] = nil,
						["position"] = nil,
						["size"] = nil,
						["parent"] = nil,
						["anchor"] = Vector2.new(1, 0.5),
						["position"] = UDim2.new(1, 0, 0.5, 0),
						["size"] = UDim2.fromOffset(150, 36),
						["parent"] = v737
					})
					local function v_u_752()
						-- upvalues: (ref) v_u_106, (copy) v_u_736, (ref) v_u_53, (ref) v_u_812
						local v750, v751 = v_u_106("CreatorSeize", v_u_736.id)
						if v751 then
							v_u_53.show(tostring(v751), v750 and "ok" or "error")
						end
						if v750 then
							task.spawn(v_u_812)
						end
					end
					local v_u_753 = nil
					local v_u_754 = "red"
					local v_u_755 = "\224\184\162\224\184\182\224\184\148 Panel \224\184\132\224\184\183\224\184\153"
					local v_u_756 = "\224\185\129\224\184\153\224\185\136\224\185\131\224\184\136? \224\184\162\224\184\182\224\184\148\224\184\132\224\184\183\224\184\153"
					v_u_749.Activated:Connect(function()
						-- upvalues: (ref) v_u_753, (ref) v_u_18, (copy) v_u_749, (copy) v_u_754, (copy) v_u_755, (copy) v_u_752, (copy) v_u_756
						if v_u_753 and os.clock() - v_u_753 < 4 then
							v_u_753 = nil
							v_u_18.setButton(v_u_749, v_u_754, v_u_755)
							v_u_752()
						else
							local v_u_757 = os.clock()
							v_u_753 = v_u_757
							v_u_18.setButton(v_u_749, "red", v_u_756)
							task.delay(4, function()
								-- upvalues: (ref) v_u_753, (copy) v_u_757, (ref) v_u_749, (ref) v_u_18, (ref) v_u_754, (ref) v_u_755
								if v_u_753 == v_u_757 then
									v_u_753 = nil
									if v_u_749.Parent then
										v_u_18.setButton(v_u_749, v_u_754, v_u_755)
									end
								end
							end)
						end
					end)
				end
				if #v725 == 0 then
					v_u_18.text({
						["Text"] = "\224\184\149\224\184\173\224\184\153\224\184\153\224\184\181\224\185\137\224\185\132\224\184\161\224\185\136\224\184\161\224\184\181\224\185\131\224\184\132\224\184\163\224\184\161\224\184\181 Panel \224\185\131\224\184\153\224\185\128\224\184\139\224\184\180\224\184\163\224\185\140\224\184\159\224\184\170\224\184\178\224\184\152\224\184\178\224\184\163\224\184\147\224\184\176",
						["TextSize"] = 15,
						["TextColor3"] = nil,
						["Size"] = nil,
						["LayoutOrder"] = 10,
						["Parent"] = nil,
						["TextColor3"] = v_u_18.TEXT_DIM,
						["Size"] = UDim2.new(1, 0, 0, 36),
						["Parent"] = v_u_193
					})
				end
				local v758 = v_u_209(v_u_193, 1000)
				v_u_18.new("UIListLayout", {
					["Padding"] = UDim.new(0, 8),
					["SortOrder"] = Enum.SortOrder.LayoutOrder,
					["Parent"] = v758
				})
				v_u_248(v758, 1, ("\224\184\132\224\184\163\224\184\181\224\185\128\224\184\173\224\185\128\224\184\149\224\184\173\224\184\163\224\185\140\224\184\151\224\184\181\224\185\136\224\185\131\224\184\138\224\185\137 Server Panel \224\185\132\224\184\148\224\185\137 (%d \224\184\132\224\184\153)"):format(#v723))
				v_u_18.text({
					["Text"] = "Server Panel = \224\185\128\224\184\149\224\184\176\224\184\132\224\184\153\224\184\173\224\184\173\224\184\129\224\184\136\224\184\178\224\184\129\224\185\128\224\184\139\224\184\180\224\184\163\224\185\140\224\184\159 / \224\184\167\224\184\178\224\184\155\224\185\132\224\184\155\224\184\171\224\184\178 / \224\184\148\224\184\182\224\184\135\224\184\161\224\184\178 (\224\184\167\224\184\178\224\184\155\224\184\129\224\184\177\224\184\154\224\184\148\224\184\182\224\184\135\224\184\132\224\184\185\224\184\165\224\184\148\224\184\178\224\184\167\224\184\153\224\185\140 5 \224\184\167\224\184\180) \194\183 \224\185\128\224\184\136\224\185\137\224\184\178\224\184\130\224\184\173\224\184\135\224\185\128\224\184\139\224\184\180\224\184\163\224\185\140\224\184\159\224\184\167\224\184\181\224\185\132\224\184\148\224\185\137\224\185\128\224\184\173\224\184\135\224\185\131\224\184\153\224\185\128\224\184\139\224\184\180\224\184\163\224\185\140\224\184\159\224\184\149\224\184\177\224\184\167\224\185\128\224\184\173\224\184\135 \194\183 \224\184\132\224\184\163\224\184\181\224\185\128\224\184\173\224\185\128\224\184\149\224\184\173\224\184\163\224\185\140\224\185\132\224\184\148\224\185\137\224\184\136\224\184\178\224\184\129\224\184\163\224\184\178\224\184\162\224\184\138\224\184\183\224\185\136\224\184\173\224\184\153\224\184\181\224\185\137\224\185\128\224\184\151\224\185\136\224\184\178\224\184\153\224\184\177\224\185\137\224\184\153 \194\183 \224\185\131\224\184\138\224\185\137\224\184\129\224\184\177\224\184\154\224\184\151\224\184\181\224\184\161\224\184\135\224\184\178\224\184\153 / \224\185\128\224\184\136\224\185\137\224\184\178\224\184\130\224\184\173\224\184\135\224\185\128\224\184\139\224\184\180\224\184\163\224\185\140\224\184\159\224\184\167\224\184\181 / \224\184\132\224\184\163\224\184\181\224\185\128\224\184\173\224\185\128\224\184\149\224\184\173\224\184\163\224\185\140\224\184\132\224\184\153\224\184\173\224\184\183\224\185\136\224\184\153\224\185\132\224\184\161\224\185\136\224\185\132\224\184\148\224\185\137 \194\183 \224\185\128\224\184\149\224\184\176/\224\184\148\224\184\182\224\184\135\224\184\130\224\184\173\224\184\135\224\184\132\224\184\163\224\184\181\224\185\128\224\184\173\224\185\128\224\184\149\224\184\173\224\184\163\224\185\140\224\184\165\224\184\135 Log",
					["TextSize"] = 13,
					["TextColor3"] = nil,
					["TextWrapped"] = true,
					["TextXAlignment"] = nil,
					["Size"] = nil,
					["AutomaticSize"] = nil,
					["LayoutOrder"] = 2,
					["Parent"] = nil,
					["TextColor3"] = v_u_18.TEXT_DIM,
					["TextXAlignment"] = Enum.TextXAlignment.Left,
					["Size"] = UDim2.new(1, 0, 0, 0),
					["AutomaticSize"] = Enum.AutomaticSize.Y,
					["Parent"] = v758
				})
				local v_u_759 = v_u_220(v758, "\224\184\138\224\184\183\224\185\136\224\184\173\224\184\156\224\184\185\224\185\137\224\185\131\224\184\138\224\185\137 \224\184\171\224\184\163\224\184\183\224\184\173 User ID", {
					["LayoutOrder"] = 3
				})
				v_u_759.Text = v_u_718
				v_u_759:GetPropertyChangedSignal("Text"):Connect(function()
					-- upvalues: (ref) v_u_718, (copy) v_u_759
					v_u_718 = v_u_759.Text
				end)
				local function v_u_764(p760) -- name: add
					-- upvalues: (copy) v_u_759, (ref) v_u_53, (ref) v_u_106, (ref) v_u_718, (ref) v_u_812
					local v761 = v_u_759.Text:gsub("^%s*@?", ""):gsub("%s*$", "")
					if v761 == "" then
						v_u_53.show(tostring("\224\184\158\224\184\180\224\184\161\224\184\158\224\185\140\224\184\138\224\184\183\224\185\136\224\184\173\224\184\156\224\184\185\224\185\137\224\185\131\224\184\138\224\185\137\224\184\129\224\185\136\224\184\173\224\184\153"), "error")
					else
						local v762, v763 = v_u_106("CreatorAdd", v761, p760)
						if v763 then
							v_u_53.show(tostring(v763), v762 and "ok" or "error")
						end
						if v762 then
							v_u_718 = ""
							task.spawn(v_u_812)
						end
					end
				end
				v_u_244(v758, 4, {
					{
						"\224\185\128\224\184\158\224\184\180\224\185\136\224\184\161 \194\183 \224\184\151\224\184\184\224\184\129\224\185\128\224\184\139\224\184\180\224\184\163\224\185\140\224\184\159",
						"gold",
						"people",
						function()
							-- upvalues: (copy) v_u_764
							v_u_764("all")
						end
					},
					{
						"\224\185\128\224\184\158\224\184\180\224\185\136\224\184\161 \194\183 \224\185\128\224\184\139\224\184\180\224\184\163\224\185\140\224\184\159\224\184\167\224\184\181\224\185\128\224\184\151\224\185\136\224\184\178\224\184\153\224\184\177\224\185\137\224\184\153",
						"dark",
						"lock",
						function()
							-- upvalues: (copy) v_u_764
							v_u_764("vip")
						end
					}
				})
				for v765, v_u_766 in v723 do
					local v767 = v_u_209(v_u_193, 1010 + v765, 62)
					local v768 = v_u_18.text
					local v769 = {
						["Text"] = nil,
						["TextSize"] = 16,
						["FontFace"] = nil,
						["TextXAlignment"] = nil,
						["TextTruncate"] = nil,
						["Size"] = nil,
						["Parent"] = nil
					}
					local v770 = v_u_766.n
					local v771 = tostring(v770)
					local v772 = v_u_766.id
					v769.Text = ("@%s  (%s)"):format(v771, (tostring(v772)))
					v769.FontFace = v_u_18.FONT_HEAVY
					v769.TextXAlignment = Enum.TextXAlignment.Left
					v769.TextTruncate = Enum.TextTruncate.AtEnd
					v769.Size = UDim2.new(1, -130, 0, 20)
					v769.Parent = v767
					v768(v769)
					local v773 = v_u_18.text
					local v774 = {
						["Text"] = nil,
						["TextSize"] = 13,
						["TextColor3"] = nil,
						["TextXAlignment"] = nil,
						["TextTruncate"] = nil,
						["Position"] = nil,
						["Size"] = nil,
						["Parent"] = nil
					}
					local v775 = v_u_766.s == "vip" and "\224\185\128\224\184\139\224\184\180\224\184\163\224\185\140\224\184\159\224\184\167\224\184\181\224\185\128\224\184\151\224\185\136\224\184\178\224\184\153\224\184\177\224\185\137\224\184\153" or "\224\184\151\224\184\184\224\184\129\224\185\128\224\184\139\224\184\180\224\184\163\224\185\140\224\184\159"
					local v776 = v_u_766.by
					local v777 = tostring(v776)
					local v778 = v_u_766.t
					v774.Text = ("%s \194\183 \224\185\128\224\184\158\224\184\180\224\185\136\224\184\161\224\185\130\224\184\148\224\184\162 %s \194\183 %s"):format(v775, v777, (not tonumber(v778) or v_u_766.t <= 0) and "-" or os.date("%d/%m/%Y", v_u_766.t))
					v774.TextColor3 = v_u_18.TEXT_DIM
					v774.TextXAlignment = Enum.TextXAlignment.Left
					v774.TextTruncate = Enum.TextTruncate.AtEnd
					v774.Position = UDim2.fromOffset(0, 22)
					v774.Size = UDim2.new(1, -130, 0, 18)
					v774.Parent = v767
					v773(v774)
					local v_u_779 = v_u_18.button({
						["name"] = "Drop",
						["text"] = "\224\184\165\224\184\154",
						["grad"] = "red",
						["textSize"] = 14,
						["anchor"] = nil,
						["position"] = nil,
						["size"] = nil,
						["parent"] = nil,
						["anchor"] = Vector2.new(1, 0.5),
						["position"] = UDim2.new(1, 0, 0.5, 0),
						["size"] = UDim2.fromOffset(120, 36),
						["parent"] = v767
					})
					local function v_u_782()
						-- upvalues: (ref) v_u_106, (copy) v_u_766, (ref) v_u_53, (ref) v_u_812
						local v780, v781 = v_u_106("CreatorDrop", v_u_766.id)
						if v781 then
							v_u_53.show(tostring(v781), v780 and "ok" or "error")
						end
						if v780 then
							task.spawn(v_u_812)
						end
					end
					local v_u_783 = nil
					local v_u_784 = "red"
					local v_u_785 = "\224\184\165\224\184\154"
					local v_u_786 = "\224\185\129\224\184\153\224\185\136\224\185\131\224\184\136? \224\184\165\224\184\154"
					v_u_779.Activated:Connect(function()
						-- upvalues: (ref) v_u_783, (ref) v_u_18, (copy) v_u_779, (copy) v_u_784, (copy) v_u_785, (copy) v_u_782, (copy) v_u_786
						if v_u_783 and os.clock() - v_u_783 < 4 then
							v_u_783 = nil
							v_u_18.setButton(v_u_779, v_u_784, v_u_785)
							v_u_782()
						else
							local v_u_787 = os.clock()
							v_u_783 = v_u_787
							v_u_18.setButton(v_u_779, "red", v_u_786)
							task.delay(4, function()
								-- upvalues: (ref) v_u_783, (copy) v_u_787, (ref) v_u_779, (ref) v_u_18, (ref) v_u_784, (ref) v_u_785
								if v_u_783 == v_u_787 then
									v_u_783 = nil
									if v_u_779.Parent then
										v_u_18.setButton(v_u_779, v_u_784, v_u_785)
									end
								end
							end)
						end
					end)
				end
				if #v723 == 0 then
					v_u_18.text({
						["Text"] = "\224\184\162\224\184\177\224\184\135\224\185\132\224\184\161\224\185\136\224\184\161\224\184\181\224\184\132\224\184\163\224\184\181\224\185\128\224\184\173\224\185\128\224\184\149\224\184\173\224\184\163\224\185\140\224\185\131\224\184\153\224\184\163\224\184\178\224\184\162\224\184\138\224\184\183\224\185\136\224\184\173",
						["TextSize"] = 15,
						["TextColor3"] = nil,
						["Size"] = nil,
						["LayoutOrder"] = 1010,
						["Parent"] = nil,
						["TextColor3"] = v_u_18.TEXT_DIM,
						["Size"] = UDim2.new(1, 0, 0, 36),
						["Parent"] = v_u_193
					})
				end
				if #v727 > 0 then
					local v788 = v_u_209(v_u_193, 3000)
					v_u_18.new("UIListLayout", {
						["Padding"] = UDim.new(0, 6),
						["SortOrder"] = Enum.SortOrder.LayoutOrder,
						["Parent"] = v788
					})
					v_u_248(v788, 1, ("\224\184\162\224\184\182\224\184\148 Panel \224\184\132\224\184\183\224\184\153\224\185\129\224\184\165\224\185\137\224\184\167 (%d \224\184\132\224\184\153)"):format(#v727))
					for v789, v_u_790 in v727 do
						local v791 = v_u_209(v_u_193, 3000 + v789, 62)
						local v792 = v_u_18.text
						local v793 = {
							["Text"] = nil,
							["TextSize"] = 16,
							["FontFace"] = nil,
							["TextXAlignment"] = nil,
							["TextTruncate"] = nil,
							["Size"] = nil,
							["Parent"] = nil
						}
						local v794 = v_u_790.n
						local v795 = tostring(v794)
						local v796 = v_u_790.id
						v793.Text = ("@%s  (%s)"):format(v795, (tostring(v796)))
						v793.FontFace = v_u_18.FONT_HEAVY
						v793.TextXAlignment = Enum.TextXAlignment.Left
						v793.TextTruncate = Enum.TextTruncate.AtEnd
						v793.Size = UDim2.new(1, -130, 0, 20)
						v793.Parent = v791
						v792(v793)
						local v797 = v_u_790.what == "banmenu" and "\224\185\128\224\184\161\224\184\153\224\184\185\224\184\165\224\184\177\224\184\154" or (v_u_790.what == "vip" and "Server Panel \224\185\128\224\184\139\224\184\180\224\184\163\224\185\140\224\184\159\224\184\167\224\184\181\224\185\128\224\184\151\224\185\136\224\184\178\224\184\153\224\184\177\224\185\137\224\184\153" or "Server Panel \224\184\151\224\184\184\224\184\129\224\185\128\224\184\139\224\184\180\224\184\163\224\185\140\224\184\159")
						local v798 = v_u_18.text
						local v799 = {
							["Text"] = nil,
							["TextSize"] = 13,
							["TextColor3"] = nil,
							["TextXAlignment"] = nil,
							["TextTruncate"] = nil,
							["Position"] = nil,
							["Size"] = nil,
							["Parent"] = nil
						}
						local v800 = v_u_790.by
						local v801 = tostring(v800)
						local v802 = v_u_790.t
						v799.Text = ("\224\185\128\224\184\132\224\184\162\224\184\161\224\184\181 %s \194\183 \224\184\162\224\184\182\224\184\148\224\185\130\224\184\148\224\184\162 %s \194\183 %s"):format(v797, v801, (not tonumber(v802) or v_u_790.t <= 0) and "-" or os.date("%d/%m/%Y %H:%M", v_u_790.t))
						v799.TextColor3 = v_u_18.TEXT_DIM
						v799.TextXAlignment = Enum.TextXAlignment.Left
						v799.TextTruncate = Enum.TextTruncate.AtEnd
						v799.Position = UDim2.fromOffset(0, 22)
						v799.Size = UDim2.new(1, -130, 0, 18)
						v799.Parent = v791
						v798(v799)
						local v_u_803 = v_u_18.button({
							["name"] = "Return",
							["text"] = "\224\184\132\224\184\183\224\184\153 Panel",
							["grad"] = "green",
							["textSize"] = 14,
							["anchor"] = nil,
							["position"] = nil,
							["size"] = nil,
							["parent"] = nil,
							["anchor"] = Vector2.new(1, 0.5),
							["position"] = UDim2.new(1, 0, 0.5, 0),
							["size"] = UDim2.fromOffset(120, 36),
							["parent"] = v791
						})
						local function v_u_806()
							-- upvalues: (ref) v_u_106, (copy) v_u_790, (ref) v_u_53, (ref) v_u_812
							local v804, v805 = v_u_106("CreatorReturn", v_u_790.id)
							if v805 then
								v_u_53.show(tostring(v805), v804 and "ok" or "error")
							end
							if v804 then
								task.spawn(v_u_812)
							end
						end
						local v_u_807 = nil
						local v_u_808 = "green"
						local v_u_809 = "\224\184\132\224\184\183\224\184\153 Panel"
						local v_u_810 = "\224\185\129\224\184\153\224\185\136\224\185\131\224\184\136? \224\184\132\224\184\183\224\184\153"
						v_u_803.Activated:Connect(function()
							-- upvalues: (ref) v_u_807, (ref) v_u_18, (copy) v_u_803, (copy) v_u_808, (copy) v_u_809, (copy) v_u_806, (copy) v_u_810
							if v_u_807 and os.clock() - v_u_807 < 4 then
								v_u_807 = nil
								v_u_18.setButton(v_u_803, v_u_808, v_u_809)
								v_u_806()
							else
								local v_u_811 = os.clock()
								v_u_807 = v_u_811
								v_u_18.setButton(v_u_803, "red", v_u_810)
								task.delay(4, function()
									-- upvalues: (ref) v_u_807, (copy) v_u_811, (ref) v_u_803, (ref) v_u_18, (ref) v_u_808, (ref) v_u_809
									if v_u_807 == v_u_811 then
										v_u_807 = nil
										if v_u_803.Parent then
											v_u_18.setButton(v_u_803, v_u_808, v_u_809)
										end
									end
								end)
							end
						end)
					end
				end
			else
				v_u_18.text({
					["Text"] = nil,
					["TextSize"] = 16,
					["TextColor3"] = nil,
					["Size"] = nil,
					["LayoutOrder"] = 1,
					["Parent"] = nil,
					["Text"] = "Couldn\'t load the list: " .. tostring(v721),
					["TextColor3"] = v_u_18.TEXT_DIM,
					["Size"] = UDim2.new(1, 0, 0, 40),
					["Parent"] = v_u_193
				})
			end
		else
			return
		end
	else
		v_u_264(v_u_193)
		v_u_18.text({
			["Text"] = "\224\185\128\224\184\137\224\184\158\224\184\178\224\184\176\224\184\162\224\184\168 Owner",
			["TextSize"] = 16,
			["TextColor3"] = nil,
			["Size"] = nil,
			["LayoutOrder"] = 1,
			["Parent"] = nil,
			["TextColor3"] = v_u_18.TEXT_DIM,
			["Size"] = UDim2.new(1, 0, 0, 40),
			["Parent"] = v_u_193
		})
		return
	end
end
local function v_u_819(p813) -- name: show
	-- upvalues: (ref) v_u_581, (copy) v_u_193, (copy) v_u_191, (copy) v_u_189, (copy) v_u_190, (copy) v_u_192, (copy) v_u_196, (ref) v_u_254, (copy) v_u_432, (ref) v_u_200, (ref) v_u_330, (ref) v_u_812, (ref) v_u_586, (ref) v_u_440
	v_u_581 = p813
	for v814, v815 in {
		["Creator"] = v_u_193,
		["Money"] = v_u_191,
		["Server"] = v_u_189,
		["Log"] = v_u_190,
		["Watch"] = v_u_192,
		["Passes"] = v_u_196
	} do
		v815.Visible = v814 == p813
	end
	if p813 == "Players" then
		task.spawn(v_u_254)
		return
	elseif p813 == "Log" then
		task.spawn(v_u_432)
		return
	elseif p813 == "Creator" then
		task.spawn(function()
			-- upvalues: (ref) v_u_200, (ref) v_u_254, (ref) v_u_330, (ref) v_u_581, (ref) v_u_812
			if next(v_u_200) == nil then
				v_u_254()
				local v816 = os.clock()
				while v_u_330 and os.clock() - v816 < 15 do
					task.wait(0.1)
				end
			end
			if v_u_581 == "Creator" then
				v_u_812()
			end
		end)
		return
	elseif p813 == "Watch" then
		task.spawn(function()
			-- upvalues: (ref) v_u_200, (ref) v_u_254, (ref) v_u_330, (ref) v_u_581, (ref) v_u_586
			if next(v_u_200) == nil then
				v_u_254()
				local v817 = os.clock()
				while v_u_330 and os.clock() - v817 < 15 do
					task.wait(0.1)
				end
			end
			if v_u_581 == "Watch" then
				v_u_586()
			end
		end)
	elseif p813 == "Money" then
		task.spawn(function()
			-- upvalues: (ref) v_u_200, (ref) v_u_254, (ref) v_u_330, (ref) v_u_581, (ref) v_u_440
			if next(v_u_200) == nil then
				v_u_254()
				local v818 = os.clock()
				while v_u_330 and os.clock() - v818 < 15 do
					task.wait(0.1)
				end
			end
			if v_u_581 == "Money" then
				v_u_440()
			end
		end)
	end
end
v_u_249()
local v_u_820 = require(v_u_8:WaitForChild("VehicleArt"))
local v_u_821 = require(v_u_8:WaitForChild("StoreConfig"))
local v_u_822 = {
	["gold"] = v_u_12.yellow,
	["pink"] = v_u_12.pink,
	["purple"] = v_u_12.purple,
	["orange"] = v_u_12.orange,
	["green"] = v_u_12.green,
	["red"] = v_u_12.red,
	["blue"] = v_u_12.blue,
	["cyan"] = v_u_12.cyan
}
local v_u_823 = v_u_250
local v_u_824 = v_u_330
local v_u_825 = v_u_254
local v_u_826 = v_u_183
local v_u_827 = v_u_435
local v_u_828 = v_u_200
local v_u_829 = v_u_182
local v_u_830 = v_u_436
local v_u_831 = {}
for _, v832 in v_u_5.VEHICLES do
	v_u_831[v832.id] = v832
end
local function v_u_841(p833, p834, p835, p836) -- name: sectionHead
	-- upvalues: (copy) v_u_18, (copy) v_u_10, (copy) v_u_11
	local v837 = v_u_18.new("Frame", {
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["LayoutOrder"] = nil,
		["Parent"] = nil,
		["Size"] = UDim2.new(1, -10, 0, 22),
		["LayoutOrder"] = p834,
		["Parent"] = p833
	})
	local v838 = v_u_10.make(p835, v_u_11.ACCENT, 14)
	local v839 = Vector2.new(0, 0.5)
	local v840 = UDim2.new(0, 0, 0.5, 0)
	v838.AnchorPoint = v839
	v838.Position = v840
	v838.Parent = v837
	v_u_18.text({
		["Text"] = nil,
		["TextSize"] = 13,
		["FontFace"] = nil,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Text"] = string.upper(p836),
		["FontFace"] = v_u_18.FONT_HEAVY,
		["TextColor3"] = Color3.new(1, 1, 1),
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["Position"] = UDim2.fromOffset(22, 0),
		["Size"] = UDim2.new(1, -22, 1, 0),
		["Parent"] = v837
	})
	return v837
end
local function v_u_861(p842, p843, p_u_844, p_u_845) -- name: cardGrid
	-- upvalues: (copy) v_u_18
	local v_u_846 = v_u_18.new("Frame", {
		["Name"] = "Grid",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["LayoutOrder"] = nil,
		["Parent"] = nil,
		["Size"] = UDim2.new(1, -10, 0, p_u_845),
		["LayoutOrder"] = p843,
		["Parent"] = p842
	})
	local v_u_847 = v_u_18.new("UIGridLayout", {
		["CellPadding"] = UDim2.fromOffset(12, 12),
		["CellSize"] = UDim2.fromOffset(p_u_844, p_u_845),
		["SortOrder"] = Enum.SortOrder.LayoutOrder,
		["Parent"] = v_u_846
	})
	local function v_u_860() -- name: layout
		-- upvalues: (ref) v_u_18, (copy) v_u_846, (copy) p_u_844, (copy) v_u_847, (copy) p_u_845
		local v848 = v_u_18.unscaledSize(v_u_846).X
		if v848 > 0 then
			local v849 = 0
			for _, v850 in v_u_846:GetChildren() do
				if not v850:IsA("GuiObject") then
					continue
				end
				v849 = v849 + 1
			end
			v_u_846.Visible = v849 > 0
			local v851 = math.max(v849, 1)
			local v852 = (v848 + 12) / (p_u_844 + 12)
			local v853 = math.floor(v852)
			local v854 = math.clamp(v853, 1, v851)
			local v855 = v_u_847
			local v856 = UDim2.fromOffset
			local v857 = (v848 - (v854 - 1) * 12) / v854
			v855.CellSize = v856(math.floor(v857), p_u_845)
			local v858 = v851 / v854
			local v859 = math.ceil(v858)
			v_u_846.Size = UDim2.new(1, -10, 0, v859 * p_u_845 + (v859 - 1) * 12)
		end
	end
	v_u_846:GetPropertyChangedSignal("AbsoluteSize"):Connect(v_u_860)
	v_u_846.ChildAdded:Connect(function()
		-- upvalues: (copy) v_u_860
		task.defer(v_u_860)
	end)
	task.defer(v_u_860)
	return v_u_846
end
local function v_u_875(p862, p863, p864, p865, p866, p867, p868) -- name: actionCard
	-- upvalues: (copy) v_u_18, (copy) v_u_11, (copy) v_u_10
	local v869 = v_u_18.new("Frame", {
		["Name"] = "Card",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["LayoutOrder"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_11.PANEL,
		["LayoutOrder"] = p863,
		["Parent"] = p862
	})
	v_u_18.corner(v869, 10)
	v_u_18.border(v869, Color3.new(1, 1, 1), 0.93, 1)
	v_u_18.padding(v869, 12, 12)
	local v870 = v_u_18.new("Frame", {
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = p864,
		["Size"] = UDim2.fromOffset(30, 30),
		["Parent"] = v869
	})
	v_u_18.corner(v870, 8)
	local v871 = v_u_10.make(p865, Color3.new(1, 1, 1), 16)
	local v872 = Vector2.new(0.5, 0.5)
	local v873 = UDim2.fromScale(0.5, 0.5)
	v871.AnchorPoint = v872
	v871.Position = v873
	v871.Parent = v870
	v_u_18.text({
		["Text"] = nil,
		["RichText"] = true,
		["TextSize"] = 15,
		["FontFace"] = nil,
		["TextXAlignment"] = nil,
		["TextTruncate"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Text"] = ("%s <font color=\"#%s\">%s</font>"):format(p866, p864:ToHex(), p867 or ""),
		["FontFace"] = v_u_18.FONT_BOLD,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["TextTruncate"] = Enum.TextTruncate.AtEnd,
		["Position"] = UDim2.fromOffset(40, 0),
		["Size"] = UDim2.new(1, -40, 0, 30),
		["Parent"] = v869
	})
	v_u_18.text({
		["Text"] = nil,
		["TextSize"] = 12,
		["TextColor3"] = nil,
		["TextWrapped"] = true,
		["TextXAlignment"] = nil,
		["TextYAlignment"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Text"] = p868 or "",
		["TextColor3"] = v_u_11.DIM,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["TextYAlignment"] = Enum.TextYAlignment.Top,
		["Position"] = UDim2.fromOffset(0, 37),
		["Size"] = UDim2.new(1, 0, 0, 30),
		["Parent"] = v869
	})
	local v874 = v_u_18.new("Frame", {
		["Name"] = "Foot",
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0, 1),
		["Position"] = UDim2.fromScale(0, 1),
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y,
		["Parent"] = v869
	})
	v_u_18.new("UIListLayout", {
		["Padding"] = UDim.new(0, 6),
		["SortOrder"] = Enum.SortOrder.LayoutOrder,
		["Parent"] = v874
	})
	return v869, v874
end
local function v_u_891(p876, p877, p878, p879) -- name: keys
	-- upvalues: (copy) v_u_18
	local v880 = v_u_18.new("Frame", {
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["LayoutOrder"] = nil,
		["Parent"] = nil,
		["Size"] = UDim2.new(1, 0, 0, p879 or 34),
		["LayoutOrder"] = p877,
		["Parent"] = p876
	})
	local v881 = #p878
	for v882, v883 in p878 do
		local v_u_884 = v_u_18.button({
			["text"] = nil,
			["grad"] = nil,
			["textSize"] = 14,
			["position"] = nil,
			["size"] = nil,
			["parent"] = nil,
			["text"] = v883[1],
			["grad"] = v883[2],
			["position"] = UDim2.new((v882 - 1) / v881, (v882 - 1) * 6 / v881, 0, 0),
			["size"] = UDim2.new(1 / v881, (v881 - 1) * -6 / v881, 1, 0),
			["parent"] = v880
		})
		if v883[4] then
			local v_u_885 = v883[2]
			local v_u_886 = v883[1]
			local v_u_887 = v883[4]
			local v_u_888 = v883[3]
			local v_u_889 = nil
			v_u_884.Activated:Connect(function()
				-- upvalues: (ref) v_u_889, (ref) v_u_18, (copy) v_u_884, (copy) v_u_885, (copy) v_u_886, (copy) v_u_888, (copy) v_u_887
				if v_u_889 and os.clock() - v_u_889 < 4 then
					v_u_889 = nil
					v_u_18.setButton(v_u_884, v_u_885, v_u_886)
					v_u_888()
				else
					local v_u_890 = os.clock()
					v_u_889 = v_u_890
					v_u_18.setButton(v_u_884, "red", v_u_887)
					task.delay(4, function()
						-- upvalues: (ref) v_u_889, (copy) v_u_890, (ref) v_u_884, (ref) v_u_18, (ref) v_u_885, (ref) v_u_886
						if v_u_889 == v_u_890 then
							v_u_889 = nil
							if v_u_884.Parent then
								v_u_18.setButton(v_u_884, v_u_885, v_u_886)
							end
						end
					end)
				end
			end)
		else
			v_u_884.Activated:Connect(v883[3])
		end
	end
	return v880
end
local function v_u_903(p892, p893, p894, p895, p896) -- name: chips
	-- upvalues: (copy) v_u_18
	local v897 = #p894 / p895
	local v898 = math.ceil(v897)
	local v899 = v_u_18.new("Frame", {
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["LayoutOrder"] = nil,
		["Parent"] = nil,
		["Size"] = UDim2.new(1, 0, 0, v898 * p896 + (v898 - 1) * 6),
		["LayoutOrder"] = p893,
		["Parent"] = p892
	})
	v_u_18.new("UIGridLayout", {
		["CellPadding"] = UDim2.fromOffset(6, 6),
		["CellSize"] = UDim2.new(1 / p895, -6 * (p895 - 1) / p895 - 1, 0, p896),
		["SortOrder"] = Enum.SortOrder.LayoutOrder,
		["Parent"] = v899
	})
	for v900, v901 in p894 do
		local v902 = v_u_18.button({
			["text"] = nil,
			["grad"] = nil,
			["textSize"] = 13,
			["parent"] = nil,
			["text"] = v901[1],
			["grad"] = v901[2],
			["parent"] = v899
		})
		v902.LayoutOrder = v900
		v902.Activated:Connect(v901[3])
	end
	return v899
end
local function v_u_916(p904, p905, p906, p907) -- name: fieldPair
	-- upvalues: (copy) v_u_18, (copy) v_u_220
	local v908 = v_u_18.new("Frame", {
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["LayoutOrder"] = nil,
		["Parent"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 34),
		["LayoutOrder"] = p905,
		["Parent"] = p904
	})
	local v909, v910 = v_u_220(v908, p906)
	local v911, v912 = v_u_220(v908, p907)
	local v913 = UDim2.new(0.5, -3, 1, 0)
	local v914 = UDim2.new(0.5, -3, 1, 0)
	local v915 = UDim2.new(0.5, 3, 0, 0)
	v910.Size = v913
	v912.Size = v914
	v912.Position = v915
	v909.TextSize = 14
	v911.TextSize = 14
	return v909, v911
end
local v_u_917 = table.find(v_u_5.ADMIN_SPEEDS, 1) or 1
v_u_184 = function()
	-- upvalues: (copy) v_u_264, (copy) v_u_197, (copy) v_u_841, (copy) v_u_861, (copy) v_u_875, (ref) v_u_828, (copy) v_u_11, (copy) v_u_220, (copy) v_u_891, (ref) v_u_826, (copy) v_u_12, (copy) v_u_18, (copy) v_u_106, (copy) v_u_53, (copy) v_u_5, (ref) v_u_917, (ref) v_u_184, (copy) v_u_903, (copy) v_u_4, (ref) v_u_108, (copy) v_u_109, (copy) v_u_916, (copy) v_u_7
	v_u_264(v_u_197)
	v_u_841(v_u_197, 1, "zap", "\224\185\128\224\184\161\224\184\153\224\184\185\224\184\171\224\184\165\224\184\177\224\184\129  \194\183  \224\184\132\224\184\179\224\184\170\224\184\177\224\185\136\224\184\135\224\185\129\224\184\173\224\184\148\224\184\161\224\184\180\224\184\153")
	local v_u_918 = v_u_861(v_u_197, 2, 250, 214)
	local v_u_919 = 0
	local function v920(...) -- name: card
		-- upvalues: (ref) v_u_919, (ref) v_u_875, (copy) v_u_918
		v_u_919 = v_u_919 + 1
		return v_u_875(v_u_918, v_u_919, ...)
	end
	if v_u_828.Lookup then
		local _, v921 = v920(v_u_11.ACCENT, "shield", "\224\184\149\224\184\163\224\184\167\224\184\136", "\224\184\156\224\184\185\224\185\137\224\185\128\224\184\165\224\185\136\224\184\153", "\224\184\130\224\185\137\224\184\173\224\184\161\224\184\185\224\184\165 \224\185\128\224\184\135\224\184\180\224\184\153 \224\184\163\224\184\150\224\184\151\224\184\184\224\184\129\224\184\132\224\184\177\224\184\153 \224\184\165\224\184\185\224\184\129\224\184\170\224\184\185\224\184\154 \224\184\130\224\184\173\224\184\135\224\185\131\224\184\153\224\184\149\224\184\177\224\184\167 \226\128\148 \224\184\173\224\184\173\224\184\153\224\185\132\224\184\165\224\184\153\224\185\140\224\184\171\224\184\163\224\184\183\224\184\173\224\184\173\224\184\173\224\184\159\224\185\132\224\184\165\224\184\153\224\185\140\224\184\129\224\185\135\224\185\132\224\184\148\224\185\137")
		local v922, v923 = v_u_220(v921, "\224\184\138\224\184\183\224\185\136\224\184\173\224\184\156\224\184\185\224\185\137\224\185\131\224\184\138\224\185\137 \224\184\171\224\184\163\224\184\183\224\184\173 User ID", {
			["LayoutOrder"] = 1
		})
		v923.Size = UDim2.new(1, 0, 0, 34)
		v922.TextSize = 14
		local v_u_924 = v922
		v_u_891(v921, 2, {
			{ "\224\184\149\224\184\163\224\184\167\224\184\136\224\185\128\224\184\165\224\184\162", "indigo", function()
					-- upvalues: (copy) v_u_924, (ref) v_u_826
					local v925 = v_u_924.Text or ""
					if tostring(v925):gsub("^%s*@?", ""):gsub("%s*$", "") ~= "" then
						local v926 = v_u_826
						local v927 = v_u_924.Text or ""
						v926(tostring(v927):gsub("^%s*@?", ""):gsub("%s*$", ""), "info")
					end
				end }
		})
	end
	if v_u_828.Announce then
		local _, v928 = v920(v_u_12.yellow, "phone", "\224\184\155\224\184\163\224\184\176\224\184\129\224\184\178\224\184\168", "\224\184\151\224\184\184\224\184\129\224\185\128\224\184\139\224\184\180\224\184\163\224\185\140\224\184\159", "\224\184\130\224\184\182\224\185\137\224\184\153\224\185\129\224\184\154\224\184\153\224\185\128\224\184\153\224\184\173\224\184\163\224\185\140\224\184\154\224\184\153\224\184\136\224\184\173\224\184\151\224\184\184\224\184\129\224\184\132\224\184\153 \224\185\131\224\184\153\224\184\151\224\184\184\224\184\129\224\185\128\224\184\139\224\184\180\224\184\163\224\185\140\224\184\159\224\185\128\224\184\167\224\184\173\224\184\163\224\185\140")
		local v929, v930 = v_u_220(v928, "\224\184\130\224\185\137\224\184\173\224\184\132\224\184\167\224\184\178\224\184\161\224\184\155\224\184\163\224\184\176\224\184\129\224\184\178\224\184\168\226\128\166", {
			["LayoutOrder"] = 1
		})
		v930.Size = UDim2.new(1, 0, 0, 34)
		v929.TextSize = 14
		local v_u_931 = v929
		local v_u_932 = "notify"
		local v933 = v_u_18.new("Frame", {
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["LayoutOrder"] = 2,
			["Parent"] = nil,
			["Size"] = UDim2.new(1, 0, 0, 30),
			["Parent"] = v928
		})
		local v_u_934 = {}
		local function v_u_938() -- name: paintKinds
			-- upvalues: (copy) v_u_934, (ref) v_u_932
			for _, v935 in v_u_934 do
				local v936 = v935.caption
				local v937
				if v935.kind == v_u_932 then
					v937 = "\226\150\184" .. v935.text .. "\226\151\130"
				else
					v937 = v935.text
				end
				v936.Text = v937
			end
		end
		local v_u_939 = v_u_932
		for v940, v_u_941 in {
			{ "!", "red", "error" },
			{ "\240\159\148\148", "yellow", "notify" },
			{ "\226\156\147", "green", "success" },
			{ "i", "blue", "info" },
			{ "$", "teal", "payment" }
		} do
			local v942, v943 = v_u_18.button({
				["text"] = nil,
				["grad"] = nil,
				["textSize"] = 14,
				["position"] = nil,
				["size"] = nil,
				["parent"] = nil,
				["text"] = v_u_941[1],
				["grad"] = v_u_941[2],
				["position"] = UDim2.new((v940 - 1) / 5, (v940 - 1) * 4 / 5, 0, 0),
				["size"] = UDim2.new(0.2, -3.2, 1, 0),
				["parent"] = v933
			})
			v_u_934[v940] = {
				["button"] = v942,
				["caption"] = v943,
				["text"] = v_u_941[1],
				["kind"] = v_u_941[3]
			}
			v942.Activated:Connect(function()
				-- upvalues: (ref) v_u_939, (copy) v_u_941, (copy) v_u_938
				v_u_939 = v_u_941[3]
				v_u_938()
			end)
		end
		v_u_938()
		v_u_891(v928, 3, {
			{ "\224\184\170\224\185\136\224\184\135\224\184\155\224\184\163\224\184\176\224\184\129\224\184\178\224\184\168", "yellow", function()
					-- upvalues: (ref) v_u_106, (copy) v_u_931, (ref) v_u_939, (ref) v_u_53
					local v944, v945 = v_u_106("Announce", v_u_931.Text, v_u_939)
					if v945 then
						v_u_53.show(tostring(v945), v944 and "ok" or "error")
					end
				end }
		})
	end
	if v_u_828.GiveAll then
		local _, v946 = v920(v_u_12.green, "coin", "\224\185\129\224\184\136\224\184\129\224\185\128\224\184\135\224\184\180\224\184\153", "\224\184\151\224\184\184\224\184\129\224\184\132\224\184\153", "\224\184\151\224\184\184\224\184\129\224\184\132\224\184\153\224\185\131\224\184\153\224\184\151\224\184\184\224\184\129\224\185\128\224\184\139\224\184\180\224\184\163\224\185\140\224\184\159\224\185\132\224\184\148\224\185\137\224\185\128\224\184\135\224\184\180\224\184\153\224\185\128\224\184\151\224\185\136\224\184\178\224\184\129\224\184\177\224\184\153 (\224\184\132\224\184\153\224\184\173\224\184\173\224\184\159\224\185\132\224\184\165\224\184\153\224\185\140\224\185\132\224\184\161\224\185\136\224\185\132\224\184\148\224\185\137)")
		local v947, v948 = v_u_220(v946, "\224\184\136\224\184\179\224\184\153\224\184\167\224\184\153\224\185\128\224\184\135\224\184\180\224\184\153 (\224\184\191)", {
			["LayoutOrder"] = 1
		})
		v948.Size = UDim2.new(1, 0, 0, 34)
		v947.TextSize = 14
		local v_u_949 = v947
		v_u_891(v946, 2, {
			{
				"\224\185\129\224\184\136\224\184\129\224\184\151\224\184\184\224\184\129\224\184\132\224\184\153",
				"green",
				function()
					-- upvalues: (ref) v_u_106, (copy) v_u_949, (ref) v_u_53
					local v950 = v_u_106
					local v951 = v_u_949.Text or ""
					local v952 = tostring(v951):gsub("[,%s\224\184\191]", "")
					local v953, v954 = v950("GiveAll", (tonumber(v952)))
					if v954 then
						v_u_53.show(tostring(v954), v953 and "ok" or "error")
					end
				end,
				"\224\184\162\224\184\183\224\184\153\224\184\162\224\184\177\224\184\153? \224\185\129\224\184\136\224\184\129\224\185\128\224\184\165\224\184\162"
			}
		})
	end
	if v_u_828.MySpeed then
		local _, v955 = v920(v_u_12.blue, "zap", "\224\184\132\224\184\167\224\184\178\224\184\161\224\185\128\224\184\163\224\185\135\224\184\167", "\224\184\163\224\184\150\224\184\130\224\184\173\224\184\135\224\184\137\224\184\177\224\184\153", "\224\184\132\224\184\185\224\184\147\224\184\132\224\184\167\224\184\178\224\184\161\224\185\128\224\184\163\224\185\135\224\184\167\224\184\163\224\184\150\224\184\151\224\184\181\224\185\136\224\184\132\224\184\184\224\184\147\224\184\130\224\184\181\224\185\136\224\184\173\224\184\162\224\184\185\224\185\136 (\224\184\155\224\184\129\224\184\149\224\184\180 x1)")
		local v956 = {}
		for v_u_957, v_u_958 in v_u_5.ADMIN_SPEEDS do
			local v961 = { ("x%g"):format(v_u_958), v_u_957 == v_u_917 and "blue" or "dark", function()
					-- upvalues: (ref) v_u_106, (copy) v_u_958, (ref) v_u_53, (ref) v_u_917, (copy) v_u_957, (ref) v_u_184
					local v959, v960 = v_u_106("MySpeed", v_u_958)
					if v960 then
						v_u_53.show(tostring(v960), v959 and "ok" or "error")
					end
					if v959 then
						v_u_917 = v_u_957
						v_u_184()
					end
				end }
			table.insert(v956, v961)
		end
		v_u_903(v955, 1, v956, 4, 30)
	end
	if v_u_4.KeyboardEnabled and v_u_4.MouseEnabled then
		local _, v962 = v920(v_u_12.purple, "pin", "\224\184\167\224\184\178\224\184\163\224\185\140\224\184\155", "Ctrl + \224\184\132\224\184\165\224\184\180\224\184\129", "\224\185\128\224\184\155\224\184\180\224\184\148\224\185\129\224\184\165\224\185\137\224\184\167 \224\184\129\224\184\148 Ctrl \224\184\132\224\185\137\224\184\178\224\184\135\224\185\129\224\184\165\224\185\137\224\184\167\224\184\132\224\184\165\224\184\180\224\184\129\224\184\139\224\185\137\224\184\178\224\184\162\224\184\151\224\184\181\224\185\136\224\184\158\224\184\183\224\185\137\224\184\153 = \224\184\167\224\184\178\224\184\163\224\185\140\224\184\155\224\185\132\224\184\155\224\184\149\224\184\163\224\184\135\224\184\153\224\184\177\224\185\137\224\184\153 (\224\184\130\224\184\181\224\185\136\224\184\173\224\184\162\224\184\185\224\185\136\224\185\132\224\184\155\224\184\151\224\184\177\224\185\137\224\184\135\224\184\132\224\184\177\224\184\153)")
		v_u_891(v962, 1, {
			{ "Enabled", v_u_108 and "green" or "grey", function()
					-- upvalues: (ref) v_u_108, (ref) v_u_18, (ref) v_u_109, (ref) v_u_53, (ref) v_u_184
					v_u_108 = true
					v_u_18.setButton(v_u_109, "green", "Ctrl Warp: ON")
					v_u_53.show("Ctrl + click to warp: on", "ok")
					v_u_184()
				end },
			{ "Disabled", v_u_108 and "grey" or "red", function()
					-- upvalues: (ref) v_u_108, (ref) v_u_18, (ref) v_u_109, (ref) v_u_53, (ref) v_u_184
					v_u_108 = false
					v_u_18.setButton(v_u_109, "grey", "Ctrl Warp: OFF")
					v_u_53.show("Ctrl + click to warp: off", "ok")
					v_u_184()
				end }
		})
	end
	if v_u_828.Ban or v_u_828.Unban then
		local _, v963 = v920(v_u_12.red, "lock", "\224\185\129\224\184\154\224\184\153 / \224\184\155\224\184\165\224\184\148\224\185\129\224\184\154\224\184\153", "\224\184\148\224\185\137\224\184\167\224\184\162\224\184\138\224\184\183\224\185\136\224\184\173", "\224\184\132\224\184\153\224\184\151\224\184\181\224\185\136\224\185\132\224\184\161\224\185\136\224\184\173\224\184\162\224\184\185\224\185\136\224\185\128\224\184\139\224\184\180\224\184\163\224\185\140\224\184\159\224\184\153\224\184\181\224\185\137 \224\184\171\224\184\163\224\184\183\224\184\173\224\184\173\224\184\173\224\184\159\224\185\132\224\184\165\224\184\153\224\185\140 \194\183 \224\184\138\224\184\177\224\185\136\224\184\167\224\185\130\224\184\161\224\184\135\224\184\167\224\185\136\224\184\178\224\184\135 = \224\184\150\224\184\178\224\184\167\224\184\163")
		local v_u_964, v_u_965 = v_u_916(v963, 1, "\224\184\138\224\184\183\224\185\136\224\184\173\224\184\156\224\184\185\224\185\137\224\185\131\224\184\138\224\185\137", "\224\184\138\224\184\177\224\185\136\224\184\167\224\185\130\224\184\161\224\184\135")
		local v_u_966, v967 = v_u_220(v963, "\224\185\128\224\184\171\224\184\149\224\184\184\224\184\156\224\184\165 (\224\184\156\224\184\185\224\185\137\224\185\128\224\184\165\224\185\136\224\184\153\224\185\128\224\184\171\224\185\135\224\184\153)", {
			["LayoutOrder"] = 2
		})
		v967.Size = UDim2.new(1, 0, 0, 34)
		v_u_966.TextSize = 14
		v_u_891(v963, 3, {
			{
				"\224\185\129\224\184\154\224\184\153",
				"red",
				function()
					-- upvalues: (ref) v_u_106, (copy) v_u_964, (copy) v_u_965, (copy) v_u_966, (ref) v_u_53
					local v968 = v_u_106
					local v969 = v_u_964.Text or ""
					local v970 = tostring(v969):gsub("^%s*@?", ""):gsub("%s*$", "")
					local v971 = v_u_965.Text
					local v972, v973 = v968("Ban", v970, tonumber(v971) or 0, v_u_966.Text)
					if v973 then
						v_u_53.show(tostring(v973), v972 and "ok" or "error")
					end
				end,
				"\224\184\162\224\184\183\224\184\153\224\184\162\224\184\177\224\184\153? \224\185\129\224\184\154\224\184\153"
			},
			{ "\224\184\155\224\184\165\224\184\148\224\185\129\224\184\154\224\184\153", "green", function()
					-- upvalues: (ref) v_u_106, (copy) v_u_964, (ref) v_u_53
					local v974 = v_u_106
					local v975 = v_u_964.Text or ""
					local v976, v977 = v974("Unban", (tostring(v975):gsub("^%s*@?", ""):gsub("%s*$", "")))
					if v977 then
						v_u_53.show(tostring(v977), v976 and "ok" or "error")
					end
				end }
		})
	end
	if v_u_828.SetTag then
		local _, v978 = v920(v_u_12.cyan, "shield", "\224\184\155\224\185\137\224\184\178\224\184\162\224\184\154\224\184\153\224\184\171\224\184\177\224\184\167", "\224\184\148\224\185\137\224\184\167\224\184\162\224\184\138\224\184\183\224\185\136\224\184\173", "\224\184\132\224\184\179\224\184\154\224\184\153\224\184\171\224\184\177\224\184\167 (\224\185\128\224\184\138\224\185\136\224\184\153 TikTok Creator) \194\183 Auto = \224\184\162\224\184\168\224\184\136\224\184\163\224\184\180\224\184\135\224\184\130\224\184\173\224\184\135\224\185\128\224\184\130\224\184\178")
		local v_u_979, v980 = v_u_220(v978, "\224\184\138\224\184\183\224\185\136\224\184\173\224\184\156\224\184\185\224\185\137\224\185\131\224\184\138\224\185\137 \224\184\171\224\184\163\224\184\183\224\184\173 User ID", {
			["LayoutOrder"] = 1
		})
		v980.Size = UDim2.new(1, 0, 0, 34)
		v_u_979.TextSize = 14
		local v981 = {}
		local v982 = v_u_7.TAG_CHOICES
		__set_list(v981, 1, {"Auto", table.unpack(v982)})
		local v983 = {}
		for _, v_u_984 in v981 do
			local v990 = { v_u_984, "dark", function()
					-- upvalues: (copy) v_u_979, (ref) v_u_53, (ref) v_u_106, (copy) v_u_984
					local v985 = v_u_979.Text or ""
					if tostring(v985):gsub("^%s*@?", ""):gsub("%s*$", "") == "" then
						v_u_53.show(tostring("\224\184\158\224\184\180\224\184\161\224\184\158\224\185\140\224\184\138\224\184\183\224\185\136\224\184\173\224\184\156\224\184\185\224\185\137\224\185\131\224\184\138\224\185\137\224\184\129\224\185\136\224\184\173\224\184\153"), "error")
					else
						local v986 = v_u_106
						local v987 = v_u_979.Text or ""
						local v988, v989 = v986("SetTag", tostring(v987):gsub("^%s*@?", ""):gsub("%s*$", ""), v_u_984)
						if v989 then
							v_u_53.show(tostring(v989), v988 and "ok" or "error")
						end
					end
				end }
			table.insert(v983, v990)
		end
		v_u_903(v978, 2, v983, 4, 28)
	end
end
local function v_u_1004()
	-- upvalues: (copy) v_u_264, (copy) v_u_198, (copy) v_u_256, (copy) v_u_2, (copy) v_u_841, (copy) v_u_54, (copy) v_u_288, (copy) v_u_18, (copy) v_u_11
	v_u_264(v_u_198)
	local v991 = string.lower
	local v992 = v_u_256.Text or ""
	local v993 = v991((tostring(v992):gsub("^%s*@?", ""):gsub("%s*$", "")))
	local v994 = {}
	for _, v995 in v_u_2:GetPlayers() do
		if v993 ~= "" and not (string.lower(v995.Name):find(v993, 1, true) or string.lower(v995.DisplayName):find(v993, 1, true)) then
			continue
		end
		table.insert(v994, v995)
	end
	table.sort(v994, function(p996, p997)
		return string.lower(p996.Name) < string.lower(p997.Name)
	end)
	v_u_841(v_u_198, 0, "person", ("\224\184\156\224\184\185\224\185\137\224\185\128\224\184\165\224\185\136\224\184\153\224\185\128\224\184\139\224\184\180\224\184\163\224\185\140\224\184\159\224\184\153\224\184\181\224\185\137  \194\183  %d \224\184\132\224\184\153"):format(#v_u_2:GetPlayers()))
	local v998 = v_u_54.Character
	if v998 then
		v998 = v_u_54.Character:FindFirstChild("HumanoidRootPart")
	end
	for v999, v1000 in v994 do
		local v1001
		if v1000 == v_u_54 then
			v1001 = "\224\184\132\224\184\184\224\184\147"
		else
			local v1002 = v1000.Character
			if v1002 then
				v1002 = v1000.Character:FindFirstChild("HumanoidRootPart")
			end
			if v998 and v1002 then
				local v1003 = (v998.Position - v1002.Position).Magnitude * 0.28 + 0.5
				v1001 = ("\224\184\171\224\185\136\224\184\178\224\184\135 %d m"):format((math.floor(v1003)))
			else
				v1001 = "\224\184\171\224\185\136\224\184\178\224\184\135 ?? m"
			end
		end
		v_u_288(v_u_198, v999, {
			["id"] = nil,
			["name"] = nil,
			["display"] = nil,
			["rank"] = nil,
			["where"] = nil,
			["passes"] = 0,
			["id"] = v1000.UserId,
			["name"] = v1000.Name,
			["display"] = v1000.DisplayName,
			["rank"] = v1000:GetAttribute("Rank") or "Member",
			["where"] = v1001
		})
	end
	if #v994 == 0 then
		v_u_18.text({
			["Text"] = "\224\185\132\224\184\161\224\185\136\224\184\158\224\184\154\224\184\138\224\184\183\224\185\136\224\184\173\224\184\153\224\184\181\224\185\137",
			["TextSize"] = 15,
			["TextColor3"] = nil,
			["Size"] = nil,
			["LayoutOrder"] = 9999,
			["Parent"] = nil,
			["TextColor3"] = v_u_11.DIM,
			["Size"] = UDim2.new(1, 0, 0, 40),
			["Parent"] = v_u_198
		})
	end
end
local function v_u_1015() -- name: buildInspect
	-- upvalues: (copy) v_u_264, (copy) v_u_199, (copy) v_u_841, (copy) v_u_861, (copy) v_u_875, (copy) v_u_11, (copy) v_u_220, (ref) v_u_826, (copy) v_u_891
	v_u_264(v_u_199)
	v_u_841(v_u_199, 1, "shield", "\224\184\149\224\184\163\224\184\167\224\184\136\224\184\156\224\184\185\224\185\137\224\185\128\224\184\165\224\185\136\224\184\153  \194\183  \224\184\173\224\184\173\224\184\153\224\185\132\224\184\165\224\184\153\224\185\140\224\184\171\224\184\163\224\184\183\224\184\173\224\184\173\224\184\173\224\184\159\224\185\132\224\184\165\224\184\153\224\185\140")
	local _, v1005 = v_u_875(v_u_861(v_u_199, 2, 420, 214), 1, v_u_11.ACCENT, "shield", "\224\184\149\224\184\163\224\184\167\224\184\136", "\224\184\156\224\184\185\224\185\137\224\185\128\224\184\165\224\185\136\224\184\153", "\224\184\130\224\185\137\224\184\173\224\184\161\224\184\185\224\184\165 \194\183 \224\185\128\224\184\135\224\184\180\224\184\153 \194\183 \224\185\128\224\184\129\224\184\161\224\184\158\224\184\178\224\184\170 \194\183 \224\184\163\224\184\150\224\184\151\224\184\184\224\184\129\224\184\132\224\184\177\224\184\153 (\224\185\128\224\184\155\224\185\135\224\184\153\224\184\163\224\184\185\224\184\155) \194\183 \224\184\165\224\184\185\224\184\129\224\184\170\224\184\185\224\184\154 \194\183 \224\184\130\224\184\173\224\184\135\224\185\131\224\184\153\224\184\149\224\184\177\224\184\167 \194\183 \224\184\162\224\184\182\224\184\148\224\184\163\224\184\150 / \224\184\162\224\184\182\224\184\148\224\184\165\224\184\185\224\184\129\224\184\170\224\184\185\224\184\154 (\224\184\162\224\184\182\224\184\148\224\184\165\224\184\185\224\184\129\224\184\170\224\184\185\224\184\154\224\185\132\224\184\148\224\185\137\224\184\129\224\184\177\224\184\154\224\184\132\224\184\153\224\184\151\224\184\181\224\185\136\224\184\173\224\184\162\224\184\185\224\185\136\224\185\128\224\184\139\224\184\180\224\184\163\224\185\140\224\184\159\224\184\153\224\184\181\224\185\137)")
	local v_u_1006, v1007 = v_u_220(v1005, "\224\184\138\224\184\183\224\185\136\224\184\173\224\184\156\224\184\185\224\185\137\224\185\131\224\184\138\224\185\137 \224\184\171\224\184\163\224\184\183\224\184\173 User ID", {
		["LayoutOrder"] = 1
	})
	v1007.Size = UDim2.new(1, 0, 0, 34)
	v_u_1006.TextSize = 14
	v_u_891(v1005, 2, {
		{ "\224\184\149\224\184\163\224\184\167\224\184\136\224\184\156\224\184\185\224\185\137\224\185\128\224\184\165\224\185\136\224\184\153", "indigo", function() -- name: go
				-- upvalues: (copy) v_u_1006, (ref) v_u_826
				local v1008 = v_u_1006.Text or ""
				if tostring(v1008):gsub("^%s*@?", ""):gsub("%s*$", "") ~= "" then
					local v1009 = v_u_826
					local v1010 = v_u_1006.Text or ""
					v1009(tostring(v1010):gsub("^%s*@?", ""):gsub("%s*$", ""), "info")
				end
			end }
	}, 38)
	v_u_1006.FocusLost:Connect(function(p1011)
		-- upvalues: (copy) v_u_1006, (ref) v_u_826
		if p1011 then
			local v1012 = v_u_1006.Text or ""
			if tostring(v1012):gsub("^%s*@?", ""):gsub("%s*$", "") ~= "" then
				local v1013 = v_u_826
				local v1014 = v_u_1006.Text or ""
				v1013(tostring(v1014):gsub("^%s*@?", ""):gsub("%s*$", ""), "info")
			end
		end
	end)
end
local v_u_1016 = {
	["seq"] = 0,
	["tab"] = "info",
	["data"] = nil,
	["entry"] = nil
}
local function v_u_1022() -- name: paintDetailTabs
	-- upvalues: (copy) v_u_168, (copy) v_u_1016, (copy) v_u_11
	for v1017, v1018 in v_u_168 do
		local v1019 = v1017 == v_u_1016.tab
		local v1020
		if v1019 then
			v1020 = v_u_11.ACCENT
		else
			v1020 = v_u_11.PANEL
		end
		v1018.BackgroundColor3 = v1020
		local v1021
		if v1019 then
			v1021 = Color3.new(1, 1, 1)
		else
			v1021 = v_u_11.DIM
		end
		v1018.TextColor3 = v1021
	end
end
local function v_u_1034(p1023, p1024, p1025, p1026, p1027, p1028) -- name: detailRow
	-- upvalues: (copy) v_u_18, (copy) v_u_11, (copy) v_u_10
	local v1029 = v_u_18.new("Frame", {
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_11.PANEL,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y,
		["LayoutOrder"] = p1024,
		["Parent"] = p1023
	})
	v_u_18.corner(v1029, 8)
	v_u_18.padding(v1029, 10, 8)
	local v1030 = v_u_18.new("Frame", {
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_11.ROW,
		["Size"] = UDim2.fromOffset(30, 30),
		["Parent"] = v1029
	})
	v_u_18.corner(v1030, 7)
	local v1031 = v_u_10.make(p1025, Color3.new(1, 1, 1), 14)
	local v1032 = Vector2.new(0.5, 0.5)
	local v1033 = UDim2.fromScale(0.5, 0.5)
	v1031.AnchorPoint = v1032
	v1031.Position = v1033
	v1031.Parent = v1030
	v_u_18.text({
		["Text"] = nil,
		["TextSize"] = 13,
		["FontFace"] = nil,
		["TextXAlignment"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Text"] = p1026,
		["FontFace"] = v_u_18.FONT_BOLD,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["Position"] = UDim2.fromOffset(42, 0),
		["Size"] = UDim2.new(1, -42, 0, 16),
		["Parent"] = v1029
	})
	v_u_18.text({
		["Text"] = nil,
		["TextSize"] = 13,
		["FontFace"] = nil,
		["TextColor3"] = nil,
		["TextWrapped"] = true,
		["TextXAlignment"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["Parent"] = nil,
		["Text"] = tostring(p1027),
		["FontFace"] = v_u_18.FONT_BOLD,
		["TextColor3"] = p1028 or v_u_11.VALUE,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["Position"] = UDim2.fromOffset(42, 16),
		["Size"] = UDim2.new(1, -42, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y,
		["Parent"] = v1029
	})
	return v1029
end
local function v_u_1041(p1035) -- name: passNames
	local v1036 = p1035.passes
	local v1037 = {}
	for _, v1038 in type(v1036) ~= "table" and {} or p1035.passes do
		local v1039
		if type(v1038) == "table" then
			local v1040 = v1038.name or (v1038.key or "?")
			v1039 = tostring(v1040)
		else
			v1039 = tostring(v1038)
		end
		table.insert(v1037, v1039)
	end
	return v1037
end
local function v_u_1046(p1042, p1043) -- name: vehicleArt
	-- upvalues: (copy) v_u_820, (copy) v_u_831, (copy) v_u_18
	local v1044 = v_u_820.of(p1043)
	local v1045
	if v1044 then
		v1045 = v1044
	else
		v1045 = v_u_831[p1043]
		if v1045 then
			v1045 = v1045.thumb
		end
		if type(v1045) == "number" then
			v1045 = "rbxassetid://" .. v1045
		elseif type(v1045) ~= "string" then
			v1045 = v1044
		end
	end
	return v_u_18.new("ImageLabel", {
		["Name"] = "Art",
		["BackgroundTransparency"] = 1,
		["Image"] = nil,
		["ScaleType"] = nil,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Image"] = v1045 or "",
		["ScaleType"] = Enum.ScaleType.Fit,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.54),
		["Size"] = UDim2.new(1, -18, 1, -16),
		["Parent"] = p1042
	})
end
local function v_u_1048(p1047) -- name: reload
	-- upvalues: (copy) v_u_1016, (ref) v_u_826
	if v_u_1016.data then
		v_u_826(v_u_1016.data.id, p1047 or v_u_1016.tab, v_u_1016.entry)
	end
end
local function v_u_1364()
	-- upvalues: (copy) v_u_1016, (copy) v_u_264, (copy) v_u_167, (copy) v_u_7, (copy) v_u_12, (copy) v_u_11, (copy) v_u_163, (copy) v_u_161, (copy) v_u_164, (copy) v_u_165, (copy) v_u_18, (copy) v_u_5, (copy) v_u_1041, (copy) v_u_10, (copy) v_u_56, (copy) v_u_841, (copy) v_u_1034, (copy) v_u_861, (copy) v_u_875, (ref) v_u_828, (copy) v_u_891, (copy) v_u_106, (copy) v_u_53, (copy) v_u_2, (copy) v_u_126, (copy) v_u_87, (copy) v_u_8, (copy) v_u_220, (copy) v_u_1048, (copy) v_u_916, (copy) v_u_903, (ref) v_u_1364, (copy) v_u_831, (copy) v_u_1046, (copy) v_u_821, (copy) v_u_822, (copy) v_u_6, (ref) v_u_827, (ref) v_u_830
	local v_u_1049 = v_u_1016.data
	v_u_264(v_u_167)
	if not v_u_1049 then
		return
	end
	local v1050 = v_u_7.info(v_u_1049.rank)
	local v1051 = v_u_1049.here and "\224\184\173\224\184\162\224\184\185\224\185\136\224\185\128\224\184\139\224\184\180\224\184\163\224\185\140\224\184\159\224\184\153\224\184\181\224\185\137" or (not v_u_1049.online and "\224\184\173\224\184\173\224\184\159\224\185\132\224\184\165\224\184\153\224\185\140" or "\224\184\173\224\184\173\224\184\153\224\185\132\224\184\165\224\184\153\224\185\140 \224\184\173\224\184\181\224\184\129\224\185\128\224\184\139\224\184\180\224\184\163\224\185\140\224\184\159" .. (v_u_1049.private and " (VIP)" or ""))
	local v1052
	if v_u_1049.online then
		v1052 = v_u_12.green
	else
		v1052 = v_u_11.DIM
	end
	local v1053 = v_u_163
	local v1054 = v_u_1049.id
	v1053.Image = ("rbxthumb://type=AvatarHeadShot&id=%d&w=150&h=150"):format(tonumber(v1054) or 1)
	v_u_161.BackgroundColor3 = v1050.color
	local v1055 = v_u_164
	local v1056 = v_u_1049.display
	local v1057 = tostring(v1056)
	local v1058
	if v_u_1049.display == v_u_1049.name then
		v1058 = ""
	else
		local v1059 = v_u_1049.name
		v1058 = "   @" .. tostring(v1059)
	end
	v1055.Text = v1057 .. v1058
	v_u_165.Text = ("<font color=\"#%s\">%s</font>   \194\183   <font color=\"#%s\">%s</font>   \194\183   ID %d"):format(v1050.color:ToHex(), v_u_7.label(v_u_1049.rank), v1052:ToHex(), v1051, v_u_1049.id)
	local v1060 = v_u_1049.stuff
	local v1061
	if type(v1060) == "table" then
		v1061 = v_u_1049.stuff
	else
		v1061 = nil
	end
	local v1062 = v_u_1049.online == true
	local v1063 = v_u_1049.here == true
	if v_u_1016.tab == "info" then
		local v1064 = v_u_18.new("Frame", {
			["Name"] = "Stats",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["LayoutOrder"] = 0,
			["Parent"] = nil,
			["Size"] = UDim2.new(1, -10, 0, 72),
			["Parent"] = v_u_167
		})
		local v1065 = 0
		local v1066
		if v1061 then
			local v1067 = v1061.bag
			v1066 = type(v1067) ~= "table" and {} or v1061.bag
		else
			v1066 = {}
		end
		for _, v1068 in v1066 do
			local v1069 = v1068.count
			v1065 = v1065 + (tonumber(v1069) or 0)
		end
		local v1070 = {}
		local v1071 = {
			v_u_12.yellow,
			"coin",
			not v_u_1049.cash and "\226\128\148" or "\224\184\191" .. v_u_5.formatNumber(v_u_1049.cash),
			"\224\185\128\224\184\135\224\184\180\224\184\153\224\185\131\224\184\153\224\185\128\224\184\139\224\184\159"
		}
		local v1072 = {}
		local v1073 = v_u_12.blue
		local v1074 = "key"
		local v1075 = "%d \224\184\132\224\184\177\224\184\153"
		local v1076, v1077
		if v1061 then
			local v1078 = v1061.vehicles
			if type(v1078) == "table" then
				v1076 = v1061.vehicles
			else
				v1077 = v_u_1049.vehicles
				v1076 = type(v1077) ~= "table" and {} or v_u_1049.vehicles
			end
		else
			v1077 = v_u_1049.vehicles
			v1076 = type(v1077) ~= "table" and {} or v_u_1049.vehicles
		end
		__set_list(v1072, 1, {v1073, v1074, v1075:format(#v1076), "\224\184\163\224\184\150\224\185\131\224\184\153\224\185\130\224\184\163\224\184\135\224\184\163\224\184\150"})
		__set_list(v1070, 1, {v1071, v1072, {
	v_u_12.purple,
	"store",
	("%d \224\184\173\224\184\177\224\184\153"):format(#v_u_1041(v_u_1049)),
	"\224\185\128\224\184\129\224\184\161\224\184\158\224\184\178\224\184\170"
}, {
	v_u_12.orange,
	"zap",
	("%d \224\184\165\224\184\185\224\184\129"):format(v1065),
	"\224\184\165\224\184\185\224\184\129\224\184\170\224\184\185\224\184\154\224\185\131\224\184\153\224\184\129\224\184\163\224\184\176\224\185\128\224\184\155\224\185\139\224\184\178"
}})
		for v1079, v1080 in v1070 do
			local v1081 = v_u_18.new("Frame", {
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["BackgroundColor3"] = v_u_11.PANEL,
				["Position"] = UDim2.new((v1079 - 1) / 4, (v1079 - 1) * 10 / 4, 0, 0),
				["Size"] = UDim2.new(0.25, -7.5, 1, 0),
				["Parent"] = v1064
			})
			v_u_18.corner(v1081, 10)
			v_u_18.border(v1081, v1080[1], 0.75, 1)
			local v1082 = v_u_18.new("Frame", {
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.82,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["ZIndex"] = 0,
				["Parent"] = nil,
				["BackgroundColor3"] = v1080[1],
				["Size"] = UDim2.fromScale(1, 1),
				["Parent"] = v1081
			})
			v_u_18.corner(v1082, 10)
			v_u_18.new("UIGradient", {
				["Transparency"] = NumberSequence.new(0, 1),
				["Parent"] = v1082
			})
			local v1083 = v_u_18.new("Frame", {
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["BackgroundColor3"] = v1080[1],
				["AnchorPoint"] = Vector2.new(0, 0.5),
				["Position"] = UDim2.new(0, 12, 0.5, 0),
				["Size"] = UDim2.fromOffset(38, 38),
				["Parent"] = v1081
			})
			v_u_18.corner(v1083, 9)
			local v1084 = v_u_10.make(v1080[2], Color3.new(1, 1, 1), 18)
			local v1085 = Vector2.new(0.5, 0.5)
			local v1086 = UDim2.fromScale(0.5, 0.5)
			v1084.AnchorPoint = v1085
			v1084.Position = v1086
			v1084.Parent = v1083
			v_u_18.text({
				["Text"] = nil,
				["TextSize"] = 19,
				["FontFace"] = nil,
				["TextXAlignment"] = nil,
				["TextTruncate"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["Text"] = v1080[3],
				["FontFace"] = v_u_18.FONT_HEAVY,
				["TextXAlignment"] = Enum.TextXAlignment.Left,
				["TextTruncate"] = Enum.TextTruncate.AtEnd,
				["Position"] = UDim2.fromOffset(60, 13),
				["Size"] = UDim2.new(1, -66, 0, 24),
				["Parent"] = v1081
			})
			v_u_18.text({
				["Text"] = nil,
				["TextSize"] = 12,
				["FontFace"] = nil,
				["TextColor3"] = nil,
				["TextXAlignment"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["Text"] = v1080[4],
				["FontFace"] = v_u_18.FONT_BOLD,
				["TextColor3"] = v_u_11.DIM,
				["TextXAlignment"] = Enum.TextXAlignment.Left,
				["Position"] = UDim2.fromOffset(60, 38),
				["Size"] = UDim2.new(1, -66, 0, 16),
				["Parent"] = v1081
			})
		end
		local v1087 = v_u_18.new("Frame", {
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["LayoutOrder"] = 1,
			["Parent"] = nil,
			["Size"] = UDim2.new(1, -10, 0, 0),
			["AutomaticSize"] = Enum.AutomaticSize.Y,
			["Parent"] = v_u_167
		})
		local v1088 = v_u_18.new
		local v1089 = "Frame"
		local v1090 = {
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["Parent"] = nil
		}
		local v1091
		if v_u_56 then
			v1091 = UDim2.new(1, 0, 0, 0)
		else
			v1091 = UDim2.new(0.35, -6, 0, 0)
		end
		v1090.Size = v1091
		v1090.AutomaticSize = Enum.AutomaticSize.Y
		v1090.Parent = v1087
		local v1092 = v1088(v1089, v1090)
		v_u_18.new("UIListLayout", {
			["Padding"] = UDim.new(0, 6),
			["SortOrder"] = Enum.SortOrder.LayoutOrder,
			["Parent"] = v1092
		})
		local v1093 = v_u_18.new
		local v1094 = "Frame"
		local v1095 = {
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["Position"] = nil,
			["AutomaticSize"] = nil,
			["Parent"] = nil
		}
		local v1096
		if v_u_56 then
			v1096 = UDim2.new(1, 0, 0, 0)
		else
			v1096 = UDim2.new(0.65, -6, 0, 0)
		end
		v1095.Size = v1096
		local v1097
		if v_u_56 then
			v1097 = UDim2.new()
		else
			v1097 = UDim2.new(0.35, 6, 0, 0)
		end
		v1095.Position = v1097
		v1095.AutomaticSize = Enum.AutomaticSize.Y
		v1095.Parent = v1087
		local v1098 = v1093(v1094, v1095)
		v_u_18.new("UIListLayout", {
			["Padding"] = UDim.new(0, 8),
			["SortOrder"] = Enum.SortOrder.LayoutOrder,
			["Parent"] = v1098
		})
		if v_u_56 then
			v_u_18.new("UIListLayout", {
				["Padding"] = UDim.new(0, 12),
				["SortOrder"] = Enum.SortOrder.LayoutOrder,
				["Parent"] = v1087
			})
			v1092.LayoutOrder = 1
			v1098.LayoutOrder = 2
		end
		v_u_841(v1092, 0, "person", "\224\184\163\224\184\178\224\184\162\224\184\165\224\184\176\224\185\128\224\184\173\224\184\181\224\184\162\224\184\148\224\184\156\224\184\185\224\185\137\224\185\128\224\184\165\224\185\136\224\184\153")
		local v1099 = v_u_1034
		local v1100 = v_u_1049.name
		v1099(v1092, 1, "person", "\224\184\138\224\184\183\224\185\136\224\184\173\224\184\156\224\184\185\224\185\137\224\185\131\224\184\138\224\185\137", "@" .. tostring(v1100))
		local v1101 = v_u_1034
		local v1102 = v_u_1049.display
		v1101(v1092, 2, "person", "\224\184\138\224\184\183\224\185\136\224\184\173\224\184\151\224\184\181\224\185\136\224\185\129\224\184\170\224\184\148\224\184\135", (tostring(v1102)))
		local v1103 = v_u_1034
		local v1104 = v_u_1049.id
		v1103(v1092, 3, "pin", "User ID", (tostring(v1104)))
		v_u_1034(v1092, 4, "shield", "\224\184\162\224\184\168", v_u_7.label(v_u_1049.rank), v1050.color)
		v_u_1034(v1092, 5, "zap", "\224\184\173\224\184\162\224\184\185\224\185\136\224\184\151\224\184\181\224\185\136", v1051, v1052)
		local v1105 = v_u_1034
		local v1106 = v1092
		local v1107 = 6
		local v1108 = "coin"
		local v1109 = "\224\185\128\224\184\135\224\184\180\224\184\153"
		local v1110
		if v_u_1049.cash then
			v1110 = "\224\184\191" .. v_u_5.formatNumber(v_u_1049.cash)
		else
			local v1111 = v_u_1049.note or "\224\184\173\224\185\136\224\184\178\224\184\153\224\185\132\224\184\161\224\185\136\224\185\132\224\184\148\224\185\137"
			v1110 = tostring(v1111)
		end
		v1105(v1106, v1107, v1108, v1109, v1110, v_u_12.yellow)
		local v1112 = v_u_1049.waiting
		local v1113
		if type(v1112) == "table" then
			v1113 = v_u_1049.waiting
		else
			v1113 = nil
		end
		if v1113 then
			local v1114 = v1113.give
			local v1115, v1116, v1117, v1118, v1119, v1120
			if (tonumber(v1114) or 0) > 0 then
				v1115 = v_u_1034
				v1116 = v_u_5.formatNumber
				v1117 = v1113.give
				v1118 = v1116(tonumber(v1117) or 0)
				v1119 = v_u_5.formatNumber
				v1120 = v1113.take
				v1115(v1092, 7, "clock", "\224\184\163\224\184\173\224\185\128\224\184\130\224\185\137\224\184\178\224\184\129\224\184\163\224\184\176\224\185\128\224\184\155\224\185\139\224\184\178 (inbox)", ("+\224\184\191%s   \226\136\146\224\184\191%s"):format(v1118, v1119(tonumber(v1120) or 0)))
			else
				local v1121 = v1113.take
				if (tonumber(v1121) or 0) > 0 then
					v1115 = v_u_1034
					v1116 = v_u_5.formatNumber
					v1117 = v1113.give
					v1118 = v1116(tonumber(v1117) or 0)
					v1119 = v_u_5.formatNumber
					v1120 = v1113.take
					v1115(v1092, 7, "clock", "\224\184\163\224\184\173\224\185\128\224\184\130\224\185\137\224\184\178\224\184\129\224\184\163\224\184\176\224\185\128\224\184\155\224\185\139\224\184\178 (inbox)", ("+\224\184\191%s   \226\136\146\224\184\191%s"):format(v1118, v1119(tonumber(v1120) or 0)))
				end
			end
		end
		local v1122 = v_u_1041(v_u_1049)
		local v1123 = v_u_1034(v1092, 8, "store", ("\224\185\128\224\184\129\224\184\161\224\184\158\224\184\178\224\184\170 (%d)  \194\183  \224\184\148\224\184\185\224\185\131\224\184\153\224\185\129\224\184\151\224\185\135\224\184\154\224\185\128\224\184\129\224\184\161\224\184\158\224\184\178\224\184\170"):format(#v1122), #v1122 > 0 and "" or "\224\185\132\224\184\161\224\185\136\224\184\161\224\184\181", v_u_12.yellow)
		if #v1122 > 0 then
			local v1124 = v_u_18.new("Frame", {
				["BackgroundTransparency"] = 1,
				["Position"] = nil,
				["Size"] = nil,
				["AutomaticSize"] = nil,
				["Parent"] = nil,
				["Position"] = UDim2.fromOffset(42, 20),
				["Size"] = UDim2.new(1, -42, 0, 0),
				["AutomaticSize"] = Enum.AutomaticSize.Y,
				["Parent"] = v1123
			})
			v_u_18.new("UIListLayout", {
				["FillDirection"] = nil,
				["Wraps"] = true,
				["Padding"] = nil,
				["SortOrder"] = nil,
				["Parent"] = nil,
				["FillDirection"] = Enum.FillDirection.Horizontal,
				["Padding"] = UDim.new(0, 4),
				["SortOrder"] = Enum.SortOrder.LayoutOrder,
				["Parent"] = v1124
			})
			for v1125, v1126 in v_u_1049.passes do
				if type(v1126) ~= "table" then
					continue
				end
				local v1127 = v_u_18.chip
				local v1128 = v1126.name or v1126.key
				local v1129 = tostring(v1128)
				local v1130
				if v1126.how == "bought" then
					v1130 = v_u_12.green
				else
					v1130 = v_u_12.purple
				end
				v1127(v1124, v1129, v1130, {
					["LayoutOrder"] = v1125
				})
			end
		end
		if v1061 then
			v_u_1034(v1092, 9, "key", "\224\184\163\224\184\150\224\185\131\224\184\153\224\185\130\224\184\163\224\184\135\224\184\163\224\184\150", ("%d \224\184\132\224\184\177\224\184\153"):format(#(v1061.vehicles or {})))
			if v1061.helmet then
				v_u_1034(v1092, 10, "shield", "\224\184\171\224\184\161\224\184\167\224\184\129", v1061.helmet)
			end
		end
		v_u_841(v1098, 0, "zap", "\224\184\132\224\184\179\224\184\170\224\184\177\224\185\136\224\184\135\224\184\129\224\184\177\224\184\154\224\184\156\224\184\185\224\185\137\224\185\128\224\184\165\224\185\136\224\184\153")
		local v_u_1131 = v_u_861(v1098, 1, 200, 128)
		local v_u_1132 = v_u_861(v1098, 2, 210, 200)
		local v_u_1133 = 0
		local function v1134(...) -- name: card
			-- upvalues: (ref) v_u_1133, (ref) v_u_875, (copy) v_u_1132
			v_u_1133 = v_u_1133 + 1
			return v_u_875(v_u_1132, v_u_1133, ...)
		end
		local function v1135(...) -- name: quick
			-- upvalues: (ref) v_u_1133, (ref) v_u_875, (copy) v_u_1131
			v_u_1133 = v_u_1133 + 1
			return v_u_875(v_u_1131, v_u_1133, ...)
		end
		if v_u_828.Goto and v1062 then
			local _, v1136 = v1135(v_u_12.blue, "pin", "\224\184\167\224\184\178\224\184\155\224\185\132\224\184\155", "\224\184\171\224\184\178\224\185\128\224\184\130\224\184\178", "\224\185\132\224\184\155\224\184\162\224\184\183\224\184\153\224\184\130\224\185\137\224\184\178\224\184\135\224\185\134 (\224\184\173\224\184\162\224\184\185\224\185\136\224\184\173\224\184\181\224\184\129\224\185\128\224\184\139\224\184\180\224\184\163\224\185\140\224\184\159 = \224\184\162\224\185\137\224\184\178\224\184\162\224\185\128\224\184\139\224\184\180\224\184\163\224\185\140\224\184\159\224\185\132\224\184\155\224\184\171\224\184\178)")
			v_u_891(v1136, 1, {
				{ "\224\184\167\224\184\178\224\184\155\224\185\132\224\184\155", "blue", function()
						-- upvalues: (ref) v_u_106, (copy) v_u_1049, (ref) v_u_53
						local v1137, v1138 = v_u_106("Goto", v_u_1049.id)
						if v1138 then
							v_u_53.show(tostring(v1138), v1137 and "ok" or "error")
						end
					end }
			})
		end
		if v_u_828.Bring and v1062 then
			local _, v1139 = v1135(v_u_12.cyan, "people", "\224\184\148\224\184\182\224\184\135", "\224\184\161\224\184\178\224\184\171\224\184\178\224\184\137\224\184\177\224\184\153", "\224\184\148\224\184\182\224\184\135\224\184\161\224\184\178\224\184\162\224\184\183\224\184\153\224\184\130\224\185\137\224\184\178\224\184\135\224\184\132\224\184\184\224\184\147 (\224\184\173\224\184\162\224\184\185\224\185\136\224\184\173\224\184\181\224\184\129\224\185\128\224\184\139\224\184\180\224\184\163\224\185\140\224\184\159 = \224\184\148\224\184\182\224\184\135\224\184\130\224\185\137\224\184\178\224\184\161\224\185\128\224\184\139\224\184\180\224\184\163\224\185\140\224\184\159)")
			v_u_891(v1139, 1, {
				{ "\224\184\148\224\184\182\224\184\135\224\184\161\224\184\178", "cyan", function()
						-- upvalues: (ref) v_u_106, (copy) v_u_1049, (ref) v_u_53
						local v1140, v1141 = v_u_106("Bring", v_u_1049.id)
						if v1141 then
							v_u_53.show(tostring(v1141), v1140 and "ok" or "error")
						end
					end }
			})
		end
		if v_u_828.Spectate and v1063 then
			local _, v1142 = v1135(v_u_12.purple, "camera", "\224\184\170\224\185\136\224\184\173\224\184\135", "\224\184\156\224\184\185\224\185\137\224\185\128\224\184\165\224\185\136\224\184\153", "\224\184\129\224\184\165\224\185\137\224\184\173\224\184\135\224\184\149\224\184\178\224\184\161\224\185\128\224\184\130\224\184\178\224\185\132\224\184\155 (\224\184\155\224\184\184\224\185\136\224\184\161 Stop spectating \224\184\148\224\185\137\224\184\178\224\184\153\224\184\165\224\185\136\224\184\178\224\184\135\224\184\136\224\184\173)")
			v_u_891(v1142, 1, {
				{ "\224\184\170\224\185\136\224\184\173\224\184\135", "purple", function()
						-- upvalues: (ref) v_u_2, (copy) v_u_1049, (ref) v_u_126, (ref) v_u_87
						local v1143 = v_u_2:GetPlayerByUserId(v_u_1049.id)
						if v1143 then
							v_u_126.setOpen(false)
							v_u_87(v1143)
						end
					end }
			})
		end
		if v_u_828.UiCheck and v1062 then
			local _, v1144 = v1135(v_u_12.teal, "shield", "\224\185\128\224\184\138\224\185\135\224\184\132", "\224\184\171\224\184\153\224\185\137\224\184\178\224\184\136\224\184\173 UI", "\224\184\148\224\184\185\224\184\160\224\184\178\224\184\158 UI \224\184\154\224\184\153\224\184\136\224\184\173\224\185\128\224\184\130\224\184\178 (\224\184\171\224\184\178\224\184\171\224\184\153\224\185\137\224\184\178\224\184\149\224\185\136\224\184\178\224\184\135\224\185\130\224\184\155\224\184\163)")
			v_u_891(v1144, 1, {
				{ "\224\184\148\224\184\185\224\184\136\224\184\173 UI", "teal", function()
						-- upvalues: (ref) v_u_126, (ref) v_u_8, (copy) v_u_1049
						v_u_126.setOpen(false)
						require(v_u_8:WaitForChild("UiCheckView")).open(v_u_1049.id, v_u_1049.name)
					end }
			})
		end
		if v_u_828.Kick and v1062 then
			local _, v1145 = v1134(v_u_12.orange, "exit", "\224\185\128\224\184\149\224\184\176", "\224\184\173\224\184\173\224\184\129\224\184\136\224\184\178\224\184\129\224\185\128\224\184\129\224\184\161", "\224\185\128\224\184\130\224\184\178\224\185\128\224\184\171\224\185\135\224\184\153\224\185\128\224\184\171\224\184\149\224\184\184\224\184\156\224\184\165\224\184\154\224\184\153\224\184\136\224\184\173")
			local v_u_1146, v1147 = v_u_220(v1145, "\224\185\128\224\184\171\224\184\149\224\184\184\224\184\156\224\184\165 (\224\185\132\224\184\161\224\185\136\224\185\131\224\184\170\224\185\136\224\184\129\224\185\135\224\185\132\224\184\148\224\185\137)", {
				["LayoutOrder"] = 1
			})
			v1147.Size = UDim2.new(1, 0, 0, 34)
			v_u_1146.TextSize = 14
			v_u_891(v1145, 2, {
				{ "\224\185\128\224\184\149\224\184\176", "orange", function()
						-- upvalues: (ref) v_u_106, (copy) v_u_1049, (copy) v_u_1146, (ref) v_u_53
						local v1148, v1149 = v_u_106("Kick", v_u_1049.id, v_u_1146.Text)
						if v1149 then
							v_u_53.show(tostring(v1149), v1148 and "ok" or "error")
						end
					end }
			})
		end
		if v_u_828.Give or v_u_828.Take then
			local _, v1150 = v1134(v_u_12.green, "coin", "\224\185\128\224\184\135\224\184\180\224\184\153", "\224\185\131\224\184\171\224\185\137 / \224\184\162\224\184\182\224\184\148", "\224\184\173\224\184\173\224\184\153\224\185\132\224\184\165\224\184\153\224\185\140\224\185\132\224\184\148\224\185\137\224\184\151\224\184\177\224\184\153\224\184\151\224\184\181 \194\183 \224\184\173\224\184\173\224\184\159\224\185\132\224\184\165\224\184\153\224\185\140\224\184\163\224\184\173\224\185\128\224\184\130\224\185\137\224\184\178\224\184\129\224\184\163\224\184\176\224\185\128\224\184\155\224\185\139\224\184\178\224\184\149\224\184\173\224\184\153\224\185\128\224\184\130\224\185\137\224\184\178\224\185\128\224\184\129\224\184\161")
			local v_u_1151, v1152 = v_u_220(v1150, "\224\184\136\224\184\179\224\184\153\224\184\167\224\184\153\224\185\128\224\184\135\224\184\180\224\184\153 (\224\184\191)", {
				["LayoutOrder"] = 1
			})
			v1152.Size = UDim2.new(1, 0, 0, 34)
			v_u_1151.TextSize = 14
			v_u_891(v1150, 2, {
				{ "\224\185\131\224\184\171\224\185\137\224\185\128\224\184\135\224\184\180\224\184\153", "green", function()
						-- upvalues: (ref) v_u_106, (copy) v_u_1049, (copy) v_u_1151, (ref) v_u_53, (ref) v_u_1048
						local v1153 = v_u_106
						local v1154 = v_u_1049.id
						local v1155 = v_u_1151.Text or ""
						local v1156 = tostring(v1155):gsub("[,%s\224\184\191]", "")
						local v1157, v1158 = v1153("Give", v1154, (tonumber(v1156)))
						if v1158 then
							v_u_53.show(tostring(v1158), v1157 and "ok" or "error")
						end
						task.delay(0.6, v_u_1048)
					end },
				{
					"\224\184\162\224\184\182\224\184\148\224\185\128\224\184\135\224\184\180\224\184\153",
					"red",
					function()
						-- upvalues: (ref) v_u_106, (copy) v_u_1049, (copy) v_u_1151, (ref) v_u_53, (ref) v_u_1048
						local v1159 = v_u_106
						local v1160 = v_u_1049.id
						local v1161 = v_u_1151.Text or ""
						local v1162 = tostring(v1161):gsub("[,%s\224\184\191]", "")
						local v1163, v1164 = v1159("Take", v1160, (tonumber(v1162)))
						if v1164 then
							v_u_53.show(tostring(v1164), v1163 and "ok" or "error")
						end
						task.delay(0.6, v_u_1048)
					end,
					"\224\184\162\224\184\183\224\184\153\224\184\162\224\184\177\224\184\153? \224\184\162\224\184\182\224\184\148"
				}
			})
		end
		if v_u_828.Ban then
			local _, v1165 = v1134(v_u_12.red, "lock", "\224\185\129\224\184\154\224\184\153", "\224\184\151\224\184\177\224\185\137\224\184\135\224\185\128\224\184\129\224\184\161", "\224\184\151\224\184\184\224\184\129\224\185\128\224\184\139\224\184\180\224\184\163\224\185\140\224\184\159 \194\183 \224\184\138\224\184\177\224\185\136\224\184\167\224\185\130\224\184\161\224\184\135\224\184\167\224\185\136\224\184\178\224\184\135 = \224\184\150\224\184\178\224\184\167\224\184\163")
			local v_u_1166, v_u_1167 = v_u_916(v1165, 1, "\224\185\128\224\184\171\224\184\149\224\184\184\224\184\156\224\184\165", "\224\184\138\224\184\177\224\185\136\224\184\167\224\185\130\224\184\161\224\184\135")
			v_u_891(v1165, 2, {
				{
					"\224\185\129\224\184\154\224\184\153",
					"red",
					function()
						-- upvalues: (ref) v_u_106, (copy) v_u_1049, (copy) v_u_1167, (copy) v_u_1166, (ref) v_u_53
						local v1168 = v_u_106
						local v1169 = v_u_1049.id
						local v1170 = v_u_1167.Text
						local v1171, v1172 = v1168("Ban", v1169, tonumber(v1170) or 0, v_u_1166.Text)
						if v1172 then
							v_u_53.show(tostring(v1172), v1171 and "ok" or "error")
						end
					end,
					"\224\184\162\224\184\183\224\184\153\224\184\162\224\184\177\224\184\153? \224\185\129\224\184\154\224\184\153"
				}
			})
		end
		if v_u_828.Speed and v1062 then
			local _, v1173 = v1134(v_u_12.blue, "zap", "\224\184\132\224\184\167\224\184\178\224\184\161\224\185\128\224\184\163\224\185\135\224\184\167", "\224\184\163\224\184\150\224\184\130\224\184\173\224\184\135\224\185\128\224\184\130\224\184\178", "\224\184\132\224\184\185\224\184\147\224\184\132\224\184\167\224\184\178\224\184\161\224\185\128\224\184\163\224\185\135\224\184\167\224\184\163\224\184\150\224\184\130\224\184\173\224\184\135\224\185\128\224\184\130\224\184\178 (\224\184\155\224\184\129\224\184\149\224\184\180 x1)")
			local v1174 = {}
			for _, v_u_1175 in v_u_5.ADMIN_SPEEDS do
				local v1178 = { ("x%g"):format(v_u_1175), v_u_1175 == 1 and "blue" or "dark", function()
						-- upvalues: (ref) v_u_106, (copy) v_u_1049, (copy) v_u_1175, (ref) v_u_53
						local v1176, v1177 = v_u_106("Speed", v_u_1049.id, v_u_1175)
						if v1177 then
							v_u_53.show(tostring(v1177), v1176 and "ok" or "error")
						end
					end }
				table.insert(v1174, v1178)
			end
			v_u_903(v1173, 1, v1174, 4, 28)
		end
		if v_u_828.SetTag then
			local v_u_1179 = v_u_1016.entry
			local _, v1180 = v1134(v_u_12.yellow, "shield", "\224\184\155\224\185\137\224\184\178\224\184\162", "\224\184\154\224\184\153\224\184\171\224\184\177\224\184\167", not v_u_1179 and "\224\184\132\224\184\179\224\184\154\224\184\153\224\184\171\224\184\177\224\184\167 \194\183 Auto = \224\184\162\224\184\168\224\184\136\224\184\163\224\184\180\224\184\135\224\184\130\224\184\173\224\184\135\224\185\128\224\184\130\224\184\178" or ("\224\185\131\224\184\171\224\185\137\224\184\173\224\184\162\224\184\185\224\185\136: %s \194\183 \224\185\130\224\184\138\224\184\167\224\185\140: %s"):format(not v_u_1179.grant and "\224\185\132\224\184\161\224\185\136\224\184\161\224\184\181" or v_u_7.label(v_u_1179.grant), v_u_7.label(v_u_1179.tag or v_u_1179.rank)))
			local v1181 = {}
			local v1182 = v_u_7.TAG_CHOICES
			__set_list(v1181, 1, {"Auto", table.unpack(v1182)})
			local v1183 = {}
			for _, v_u_1184 in v1181 do
				local v1185
				if v_u_1179 then
					v1185 = v_u_1184 == "Auto" and v_u_1179.grant == nil and true or v_u_1179.grant == v_u_1184
				else
					v1185 = v_u_1179
				end
				local v1192 = { v_u_1184, v1185 and "yellow" or "dark", function()
						-- upvalues: (ref) v_u_106, (copy) v_u_1049, (copy) v_u_1184, (ref) v_u_53, (copy) v_u_1179, (ref) v_u_1364
						local v1186, v1187 = v_u_106("SetTag", v_u_1049.id, v_u_1184)
						if v1187 then
							v_u_53.show(tostring(v1187), v1186 and "ok" or "error")
						end
						if v1186 and v_u_1179 then
							local v1188 = v_u_1179
							local v1189
							if v_u_1184 == "Auto" then
								v1189 = nil
							else
								v1189 = v_u_1184
							end
							v1188.grant = v1189
							local v1190 = v_u_1179
							local v1191
							if v_u_1179.grant == v_u_1179.rank then
								v1191 = nil
							else
								v1191 = v_u_1179.grant
							end
							v1190.tag = v1191
							v_u_1364()
						end
					end }
				table.insert(v1183, v1192)
			end
			v_u_903(v1180, 1, v1183, 4, 28)
		end
		if v_u_1133 == 0 then
			v_u_18.text({
				["Text"] = "\224\184\162\224\184\168\224\184\130\224\184\173\224\184\135\224\184\132\224\184\184\224\184\147\224\185\131\224\184\138\224\185\137\224\184\132\224\184\179\224\184\170\224\184\177\224\185\136\224\184\135\224\184\129\224\184\177\224\184\154\224\184\132\224\184\153\224\184\153\224\184\181\224\185\137\224\185\132\224\184\161\224\185\136\224\185\132\224\184\148\224\185\137 (\224\184\171\224\184\163\224\184\183\224\184\173\224\185\128\224\184\130\224\184\178\224\184\173\224\184\173\224\184\159\224\185\132\224\184\165\224\184\153\224\185\140)",
				["TextSize"] = 14,
				["TextColor3"] = nil,
				["Size"] = nil,
				["LayoutOrder"] = 2,
				["Parent"] = nil,
				["TextColor3"] = v_u_11.DIM,
				["Size"] = UDim2.new(1, 0, 0, 30),
				["Parent"] = v1098
			})
		end
		return
	elseif v_u_1016.tab == "vehicles" then
		local v1193 = {}
		local v1194, v1195
		if v1061 then
			local v1196 = v1061.vehicles
			if type(v1196) == "table" then
				v1193 = v1061.vehicles
			else
				v1194 = v_u_1049.vehicles
				for v1199, v1200 in type(v1194) ~= "table" and {} or v_u_1049.vehicles do
					v1195 = {
						["id"] = v1200.id,
						["name"] = v_u_831[v1200.id] and (v_u_831[v1200.id].th or v_u_831[v1200.id].en) or v1200.id,
						["km"] = v1200.km
					}
					table.insert(v1193, v1195)
				end
			end
		else
			v1194 = v_u_1049.vehicles
			for v1199, v1200 in type(v1194) ~= "table" and {} or v_u_1049.vehicles do
				v1195 = {
					["id"] = v1200.id,
					["name"] = v_u_831[v1200.id] and (v_u_831[v1200.id].th or v_u_831[v1200.id].en) or v1200.id,
					["km"] = v1200.km
				}
				table.insert(v1193, v1195)
			end
		end
		local v1201 = table.clone(v1193)
		table.sort(v1201, function(p1202, p1203)
			local v1204 = p1202.bore
			local v1205 = tonumber(v1204) or 0
			local v1206 = p1202.stock
			local v1207 = (tonumber(v1206) or (1 / 0)) < v1205
			local v1208 = p1203.bore
			local v1209 = tonumber(v1208) or 0
			local v1210 = p1203.stock
			if v1207 ~= ((tonumber(v1210) or (1 / 0)) < v1209) then
				return v1207
			end
			if p1202.out == true ~= (p1203.out == true) then
				return p1202.out == true
			end
			local v1211 = p1202.name
			local v1212 = tostring(v1211)
			local v1213 = p1203.name
			return v1212 < tostring(v1213)
		end)
		v_u_841(v_u_167, 1, "key", ("\224\184\163\224\184\150\224\184\151\224\184\177\224\185\137\224\184\135\224\184\171\224\184\161\224\184\148  \194\183  %d \224\184\132\224\184\177\224\184\153"):format(#v1201))
		if not v1063 then
			v_u_18.text({
				["Text"] = "\224\184\162\224\184\182\224\184\148\224\184\165\224\184\185\224\184\129\224\184\170\224\184\185\224\184\154\224\185\132\224\184\148\224\185\137\224\185\128\224\184\161\224\184\183\224\185\136\224\184\173\224\185\128\224\184\130\224\184\178\224\184\173\224\184\162\224\184\185\224\185\136\224\185\128\224\184\139\224\184\180\224\184\163\224\185\140\224\184\159\224\184\153\224\184\181\224\185\137 (\224\184\129\224\184\148 \224\184\167\224\184\178\224\184\155\224\185\132\224\184\155 / \224\184\148\224\184\182\224\184\135\224\184\161\224\184\178 \224\184\129\224\185\136\224\184\173\224\184\153) \194\183 \224\184\162\224\184\182\224\184\148\224\184\163\224\184\150\224\185\132\224\184\148\224\185\137\224\184\151\224\184\184\224\184\129\224\184\151\224\184\181\224\185\136 \224\184\173\224\184\173\224\184\159\224\185\132\224\184\165\224\184\153\224\185\140\224\184\129\224\185\135\224\185\132\224\184\148\224\185\137",
				["TextSize"] = 13,
				["TextColor3"] = nil,
				["TextXAlignment"] = nil,
				["Size"] = nil,
				["LayoutOrder"] = 2,
				["Parent"] = nil,
				["TextColor3"] = v_u_11.DIM,
				["TextXAlignment"] = Enum.TextXAlignment.Left,
				["Size"] = UDim2.new(1, -10, 0, 18),
				["Parent"] = v_u_167
			})
		end
		local v1214 = v_u_861(v_u_167, 3, 236, 286)
		for v1215, v_u_1216 in v1201 do
			local v1217 = v_u_18.new
			local v1218 = {
				["Name"] = nil,
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["LayoutOrder"] = nil,
				["Parent"] = nil
			}
			local v1219 = v_u_1216.id
			v1218.Name = "V_" .. tostring(v1219)
			v1218.BackgroundColor3 = v_u_11.PANEL
			v1218.LayoutOrder = v1215
			v1218.Parent = v1214
			local v1220 = v1217("Frame", v1218)
			v_u_18.corner(v1220, 10)
			v_u_18.border(v1220, Color3.new(1, 1, 1), 0.93, 1)
			v_u_18.padding(v1220, 10, 10)
			local v1221 = v_u_18.new("Frame", {
				["Name"] = "Stage",
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["Parent"] = nil,
				["BackgroundColor3"] = v_u_11.ROW,
				["Size"] = UDim2.new(1, 0, 0, 128),
				["Parent"] = v1220
			})
			v_u_18.corner(v1221, 8)
			v_u_18.new("UIGradient", {
				["Rotation"] = 90,
				["Color"] = nil,
				["Parent"] = nil,
				["Color"] = ColorSequence.new(Color3.fromRGB(255, 255, 255), Color3.fromRGB(150, 156, 175)),
				["Parent"] = v1221
			})
			if v_u_1216.id then
				v_u_1046(v1221, v_u_1216.id)
			end
			if v_u_1216.out then
				v_u_18.chip(v1221, "\224\184\130\224\184\181\224\185\136\224\184\173\224\184\162\224\184\185\224\185\136 / \224\184\173\224\184\162\224\184\185\224\185\136\224\184\153\224\184\173\224\184\129\224\185\130\224\184\163\224\184\135\224\184\163\224\184\150", v_u_12.green, {
					["Position"] = UDim2.fromOffset(8, 8)
				}).ZIndex = 3
			end
			local v1222 = v_u_18.text
			local v1223 = {
				["Text"] = nil,
				["TextSize"] = 15,
				["FontFace"] = nil,
				["TextXAlignment"] = nil,
				["TextTruncate"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil
			}
			local v1224 = v_u_1216.name
			v1223.Text = tostring(v1224)
			v1223.FontFace = v_u_18.FONT_BOLD
			v1223.TextXAlignment = Enum.TextXAlignment.Left
			v1223.TextTruncate = Enum.TextTruncate.AtEnd
			v1223.Position = UDim2.fromOffset(0, 136)
			v1223.Size = UDim2.new(1, 0, 0, 20)
			v1223.Parent = v1220
			v1222(v1223)
			local v1225 = v_u_18.text
			local v1226 = {
				["Text"] = nil,
				["TextSize"] = 12,
				["TextColor3"] = nil,
				["TextXAlignment"] = nil,
				["TextTruncate"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil
			}
			local v1227 = v_u_1216.id
			local v1228 = tostring(v1227)
			local v1229 = v_u_5.formatNumber
			local v1230 = v_u_1216.km
			v1226.Text = ("%s   \194\183   %s km"):format(v1228, v1229(tonumber(v1230) or 0))
			v1226.TextColor3 = v_u_11.DIM
			v1226.TextXAlignment = Enum.TextXAlignment.Left
			v1226.TextTruncate = Enum.TextTruncate.AtEnd
			v1226.Position = UDim2.fromOffset(0, 156)
			v1226.Size = UDim2.new(1, 0, 0, 16)
			v1226.Parent = v1220
			v1225(v1226)
			local v1231 = v_u_18.new("Frame", {
				["BackgroundTransparency"] = 1,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["Position"] = UDim2.fromOffset(0, 178),
				["Size"] = UDim2.new(1, 0, 0, 22),
				["Parent"] = v1220
			})
			v_u_18.new("UIListLayout", {
				["FillDirection"] = Enum.FillDirection.Horizontal,
				["Padding"] = UDim.new(0, 6),
				["SortOrder"] = Enum.SortOrder.LayoutOrder,
				["Parent"] = v1231
			})
			local v1232 = v_u_1216.bore
			local v1233 = tonumber(v1232)
			if v1233 then
				local v1234 = v_u_1216.stock
				v1233 = tonumber(v1234)
				if v1233 then
					v1233 = v_u_1216.bore > v_u_1216.stock
				end
			end
			if v_u_1216.bore then
				local v1235 = v_u_18.chip
				local v1236
				if v1233 then
					v1236 = ("\224\184\165\224\184\185\224\184\129\224\184\170\224\184\185\224\184\154 %g mm"):format(v_u_1216.bore)
				else
					v1236 = ("\224\184\165\224\184\185\224\184\129\224\184\170\224\184\185\224\184\154\224\185\128\224\184\148\224\184\180\224\184\161 %g mm"):format(v_u_1216.bore)
				end
				local v1237
				if v1233 then
					v1237 = v_u_12.orange
				else
					v1237 = v_u_11.KEY
				end
				v1235(v1231, v1236, v1237, {
					["LayoutOrder"] = 1
				})
			end
			local v1238 = v_u_1216.gain
			if tonumber(v1238) and v_u_1216.gain > 1.01 then
				v_u_18.chip(v1231, ("ECU x%.2f"):format(v_u_1216.gain), v_u_12.purple, {
					["LayoutOrder"] = 2
				})
			end
			local v1239 = v_u_18.new("Frame", {
				["BackgroundTransparency"] = 1,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["AnchorPoint"] = Vector2.new(0, 1),
				["Position"] = UDim2.fromScale(0, 1),
				["Size"] = UDim2.new(1, 0, 0, 34),
				["Parent"] = v1220
			})
			local v1240 = {}
			if v_u_828.TakeVehicle and (v1233 and v1063) then
				local v1243 = {
					"\224\184\162\224\184\182\224\184\148\224\184\165\224\184\185\224\184\129\224\184\170\224\184\185\224\184\154",
					"orange",
					function()
						-- upvalues: (ref) v_u_106, (copy) v_u_1049, (copy) v_u_1216, (ref) v_u_53, (ref) v_u_1048
						local v1241, v1242 = v_u_106("TakePiston", v_u_1049.id, "vehicle", v_u_1216.id)
						if v1242 then
							v_u_53.show(tostring(v1242), v1241 and "ok" or "error")
						end
						task.delay(0.5, v_u_1048, "vehicles")
					end,
					"\224\184\162\224\184\183\224\184\153\224\184\162\224\184\177\224\184\153? \224\184\162\224\184\182\224\184\148"
				}
				table.insert(v1240, v1243)
			end
			if v_u_828.TakeVehicle and v_u_1216.id then
				local v1246 = {
					"\224\184\162\224\184\182\224\184\148\224\184\163\224\184\150",
					"red",
					function()
						-- upvalues: (ref) v_u_106, (copy) v_u_1049, (copy) v_u_1216, (ref) v_u_53, (ref) v_u_1048
						local v1244, v1245 = v_u_106("TakeVehicle", v_u_1049.id, v_u_1216.id)
						if v1245 then
							v_u_53.show(tostring(v1245), v1244 and "ok" or "error")
						end
						task.delay(0.5, v_u_1048, "vehicles")
					end,
					"\224\184\162\224\184\183\224\184\153\224\184\162\224\184\177\224\184\153? \224\184\162\224\184\182\224\184\148\224\184\163\224\184\150"
				}
				table.insert(v1240, v1246)
			end
			if #v1240 <= 0 then
				continue
			end
			v_u_891(v1239, 1, v1240)
		end
		if #v1201 == 0 then
			v_u_18.text({
				["Text"] = nil,
				["TextSize"] = 14,
				["TextColor3"] = nil,
				["Size"] = nil,
				["LayoutOrder"] = 4,
				["Parent"] = nil,
				["Text"] = v1061 and "\224\185\132\224\184\161\224\185\136\224\184\161\224\184\181\224\184\163\224\184\150\224\185\131\224\184\153\224\185\130\224\184\163\224\184\135\224\184\163\224\184\150" or "\224\184\173\224\185\136\224\184\178\224\184\153\224\184\130\224\185\137\224\184\173\224\184\161\224\184\185\224\184\165\224\184\163\224\184\150\224\185\132\224\184\161\224\185\136\224\185\132\224\184\148\224\185\137 (\224\185\131\224\184\153 Studio \224\184\173\224\185\136\224\184\178\224\184\153\224\184\132\224\184\153\224\184\173\224\184\173\224\184\159\224\185\132\224\184\165\224\184\153\224\185\140\224\185\132\224\184\161\224\185\136\224\185\132\224\184\148\224\185\137)",
				["TextColor3"] = v_u_11.DIM,
				["Size"] = UDim2.new(1, -10, 0, 30),
				["Parent"] = v_u_167
			})
		end
		local v1247 = v_u_1049.seized
		local v1248 = type(v1247) ~= "table" and {} or v_u_1049.seized
		if #v1248 > 0 then
			v_u_841(v_u_167, 5, "lock", ("\224\184\162\224\184\182\224\184\148\224\184\129\224\184\184\224\184\141\224\185\129\224\184\136\224\185\132\224\184\167\224\185\137  \194\183  %d \224\184\132\224\184\177\224\184\153"):format(#v1248))
			local v1249 = v_u_861(v_u_167, 6, 236, 214)
			for v1250, v_u_1251 in v1248 do
				local v1252 = v_u_18.new("Frame", {
					["BackgroundColor3"] = nil,
					["BorderSizePixel"] = 0,
					["LayoutOrder"] = nil,
					["Parent"] = nil,
					["BackgroundColor3"] = v_u_11.PANEL,
					["LayoutOrder"] = v1250,
					["Parent"] = v1249
				})
				v_u_18.corner(v1252, 10)
				v_u_18.border(v1252, v_u_12.red, 0.7, 1)
				v_u_18.padding(v1252, 10, 10)
				local v1253 = v_u_18.new("Frame", {
					["BackgroundColor3"] = nil,
					["BorderSizePixel"] = 0,
					["Size"] = nil,
					["Parent"] = nil,
					["BackgroundColor3"] = v_u_11.ROW,
					["Size"] = UDim2.new(1, 0, 0, 110),
					["Parent"] = v1252
				})
				v_u_18.corner(v1253, 8)
				v_u_1046(v1253, v_u_1251).ImageTransparency = 0.45
				local v1254 = v_u_831[v_u_1251]
				v_u_18.text({
					["Text"] = nil,
					["TextSize"] = 15,
					["FontFace"] = nil,
					["TextXAlignment"] = nil,
					["TextTruncate"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["Parent"] = nil,
					["Text"] = v1254 and (v1254.th or v1254.en) or tostring(v_u_1251),
					["FontFace"] = v_u_18.FONT_BOLD,
					["TextXAlignment"] = Enum.TextXAlignment.Left,
					["TextTruncate"] = Enum.TextTruncate.AtEnd,
					["Position"] = UDim2.fromOffset(0, 118),
					["Size"] = UDim2.new(1, 0, 0, 20),
					["Parent"] = v1252
				})
				local v1255 = v_u_18.new("Frame", {
					["BackgroundTransparency"] = 1,
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["Parent"] = nil,
					["AnchorPoint"] = Vector2.new(0, 1),
					["Position"] = UDim2.fromScale(0, 1),
					["Size"] = UDim2.new(1, 0, 0, 34),
					["Parent"] = v1252
				})
				if not v_u_828.GiveVehicle then
					continue
				end
				v_u_891(v1255, 1, {
					{ "\224\184\132\224\184\183\224\184\153\224\184\163\224\184\150\224\185\131\224\184\171\224\185\137", "green", function()
							-- upvalues: (ref) v_u_106, (copy) v_u_1049, (copy) v_u_1251, (ref) v_u_53, (ref) v_u_1048
							local v1256, v1257 = v_u_106("GiveVehicle", v_u_1049.id, v_u_1251)
							if v1257 then
								v_u_53.show(tostring(v1257), v1256 and "ok" or "error")
							end
							task.delay(0.5, v_u_1048, "vehicles")
						end }
				})
			end
			return
		end
	elseif v_u_1016.tab == "passes" then
		local v1258 = v_u_1049.passes
		local v1259 = {}
		local v1260 = {}
		local v1261 = 0
		for _, v1262 in type(v1258) ~= "table" and {} or v_u_1049.passes do
			if type(v1262) == "table" and v1262.key then
				v1260[v1262.key] = v1262.how
			else
				if type(v1262) ~= "table" then
					continue
				end
				local v1263 = v1262.name
				local v1264 = tostring(v1263)
				table.insert(v1259, v1264)
			end
		end
		for _, v1265 in v_u_821.GAMEPASSES do
			if not v1260[v1265.key] then
				continue
			end
			v1261 = v1261 + 1
		end
		v_u_841(v_u_167, 1, "store", ("\224\185\128\224\184\129\224\184\161\224\184\158\224\184\178\224\184\170  \194\183  \224\184\161\224\184\181 %d \224\184\136\224\184\178\224\184\129 %d"):format(v1261, #v_u_821.GAMEPASSES))
		v_u_18.text({
			["Text"] = "\224\184\139\224\184\183\224\185\137\224\184\173\224\185\128\224\184\173\224\184\135\224\184\154\224\184\153 Roblox = \224\184\162\224\184\182\224\184\148\224\185\132\224\184\161\224\185\136\224\185\132\224\184\148\224\185\137 (\224\185\128\224\184\155\224\185\135\224\184\153\224\184\130\224\184\173\224\184\135 Roblox)  \194\183  \224\185\132\224\184\148\224\185\137\224\184\159\224\184\163\224\184\181 / \224\185\130\224\184\132\224\185\137\224\184\148 / \224\185\129\224\184\173\224\184\148\224\184\161\224\184\180\224\184\153\224\185\131\224\184\171\224\185\137 = \224\184\162\224\184\182\224\184\148\224\184\132\224\184\183\224\184\153\224\185\132\224\184\148\224\185\137  \194\183  \224\185\131\224\184\171\224\185\137\224\184\159\224\184\163\224\184\181\224\185\132\224\184\148\224\185\137\224\184\151\224\184\184\224\184\129\224\184\173\224\184\177\224\184\153 \224\184\173\224\184\173\224\184\159\224\185\132\224\184\165\224\184\153\224\185\140\224\184\129\224\185\135\224\185\132\224\184\148\224\185\137",
			["TextSize"] = 12,
			["TextColor3"] = nil,
			["TextWrapped"] = true,
			["TextXAlignment"] = nil,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["LayoutOrder"] = 2,
			["Parent"] = nil,
			["TextColor3"] = v_u_11.DIM,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["Size"] = UDim2.new(1, -10, 0, 0),
			["AutomaticSize"] = Enum.AutomaticSize.Y,
			["Parent"] = v_u_167
		})
		local v1266 = v_u_861(v_u_167, 3, 220, 178)
		for v1267, v_u_1268 in v_u_821.GAMEPASSES do
			local v1269 = v1260[v_u_1268.key]
			local v1270 = v_u_822[v_u_1268.grad] or v_u_12.purple
			local v1271 = v_u_18.new
			local v1272 = {
				["Name"] = nil,
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["LayoutOrder"] = nil,
				["Parent"] = nil
			}
			local v1273 = v_u_1268.key
			v1272.Name = "Pass_" .. tostring(v1273)
			v1272.BackgroundColor3 = v_u_11.PANEL
			v1272.LayoutOrder = v1267
			v1272.Parent = v1266
			local v1274 = v1271("Frame", v1272)
			v_u_18.corner(v1274, 10)
			local v1275 = v_u_18.border
			local v1276 = v1274
			local v1277
			if v1269 then
				v1277 = v1270
			else
				v1277 = Color3.new(1, 1, 1)
			end
			v1275(v1276, v1277, v1269 and 0.45 or 0.93, 1)
			if v1269 then
				local v1278 = v_u_18.new("Frame", {
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = 0.84,
					["BorderSizePixel"] = 0,
					["Size"] = nil,
					["ZIndex"] = 0,
					["Parent"] = nil,
					["BackgroundColor3"] = v1270,
					["Size"] = UDim2.fromScale(1, 1),
					["Parent"] = v1274
				})
				v_u_18.corner(v1278, 10)
				v_u_18.new("UIGradient", {
					["Rotation"] = 90,
					["Transparency"] = nil,
					["Parent"] = nil,
					["Transparency"] = NumberSequence.new(0, 1),
					["Parent"] = v1278
				})
			end
			local v1279 = v_u_18.new("Frame", {
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["Parent"] = nil,
				["Size"] = UDim2.fromScale(1, 1),
				["Parent"] = v1274
			})
			v_u_18.padding(v1279, 12, 12)
			local v1280 = v_u_18.new("Frame", {
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = nil,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["Parent"] = nil,
				["BackgroundColor3"] = v1270,
				["BackgroundTransparency"] = v1269 and 0 or 0.6,
				["Size"] = UDim2.fromOffset(44, 44),
				["Parent"] = v1279
			})
			v_u_18.corner(v1280, 10)
			local v1281 = v_u_10.make(v_u_1268.icon or "store", Color3.new(1, 1, 1), 22)
			local v1282 = Vector2.new(0.5, 0.5)
			local v1283 = UDim2.fromScale(0.5, 0.5)
			v1281.AnchorPoint = v1282
			v1281.Position = v1283
			v1281.Parent = v1280
			local v1284 = v_u_18.text
			local v1285 = {
				["Text"] = nil,
				["TextSize"] = 15,
				["FontFace"] = nil,
				["TextXAlignment"] = nil,
				["TextTruncate"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil
			}
			local v1286 = v_u_1268.name
			v1285.Text = tostring(v1286)
			v1285.FontFace = v_u_18.FONT_BOLD
			v1285.TextXAlignment = Enum.TextXAlignment.Left
			v1285.TextTruncate = Enum.TextTruncate.AtEnd
			v1285.Position = UDim2.fromOffset(54, 2)
			v1285.Size = UDim2.new(1, -54, 0, 20)
			v1285.Parent = v1279
			v1284(v1285)
			local v1287 = v_u_18.chip
			local v1288 = v1269 == "bought" and "\224\184\139\224\184\183\224\185\137\224\184\173\224\185\128\224\184\173\224\184\135\224\185\129\224\184\165\224\185\137\224\184\167" or (v1269 and "\224\185\132\224\184\148\224\185\137\224\184\159\224\184\163\224\184\181 / \224\185\130\224\184\132\224\185\137\224\184\148" or "\224\184\162\224\184\177\224\184\135\224\185\132\224\184\161\224\185\136\224\184\161\224\184\181")
			local v1289
			if v1269 == "bought" then
				v1289 = v_u_12.green
			elseif v1269 then
				v1289 = v_u_12.purple
			else
				v1289 = v_u_11.KEY
			end
			v1287(v1279, v1288, v1289, {
				["Position"] = UDim2.fromOffset(54, 25)
			})
			local v1290 = v_u_18.text
			local v1291 = {
				["Text"] = nil,
				["TextSize"] = 12,
				["TextColor3"] = nil,
				["TextWrapped"] = true,
				["TextXAlignment"] = nil,
				["TextYAlignment"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil
			}
			local v1292 = v_u_1268.description or ""
			v1291.Text = tostring(v1292)
			v1291.TextColor3 = v_u_11.DIM
			v1291.TextXAlignment = Enum.TextXAlignment.Left
			v1291.TextYAlignment = Enum.TextYAlignment.Top
			v1291.Position = UDim2.fromOffset(0, 54)
			v1291.Size = UDim2.new(1, 0, 0, 32)
			v1291.Parent = v1279
			v1290(v1291)
			local v1293 = v_u_18.new("Frame", {
				["BackgroundTransparency"] = 1,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["AnchorPoint"] = Vector2.new(0, 1),
				["Position"] = UDim2.fromScale(0, 1),
				["Size"] = UDim2.new(1, 0, 0, 34),
				["Parent"] = v1279
			})
			if not v_u_828.GivePass then
				continue
			end
			if v1269 == "bought" then
				v_u_891(v1293, 1, {
					{ "\224\184\139\224\184\183\224\185\137\224\184\173\224\185\128\224\184\173\224\184\135 \194\183 \224\184\162\224\184\182\224\184\148\224\185\132\224\184\161\224\185\136\224\185\132\224\184\148\224\185\137", "grey", function()
							-- upvalues: (ref) v_u_53
							v_u_53.show(tostring("\224\184\139\224\184\183\224\185\137\224\184\173\224\184\154\224\184\153 Roblox: \224\185\128\224\184\155\224\185\135\224\184\153\224\184\130\224\184\173\224\184\135 Roblox \224\184\162\224\184\182\224\184\148\224\184\132\224\184\183\224\184\153\224\185\132\224\184\161\224\185\136\224\185\132\224\184\148\224\185\137"), "error")
						end }
				})
			elseif v1269 then
				v_u_891(v1293, 1, {
					{
						"\224\184\162\224\184\182\224\184\148\224\184\132\224\184\183\224\184\153",
						"red",
						function()
							-- upvalues: (ref) v_u_106, (copy) v_u_1049, (copy) v_u_1268, (ref) v_u_53, (ref) v_u_1048
							local v1294, v1295 = v_u_106("TakePass", v_u_1049.id, v_u_1268.key)
							if v1295 then
								v_u_53.show(tostring(v1295), v1294 and "ok" or "error")
							end
							task.delay(0.6, v_u_1048, "passes")
						end,
						"\224\184\162\224\184\183\224\184\153\224\184\162\224\184\177\224\184\153? \224\184\162\224\184\182\224\184\148\224\184\132\224\184\183\224\184\153"
					}
				})
			else
				v_u_891(v1293, 1, {
					{
						"\224\185\131\224\184\171\224\185\137\224\184\159\224\184\163\224\184\181",
						"green",
						function()
							-- upvalues: (ref) v_u_106, (copy) v_u_1049, (copy) v_u_1268, (ref) v_u_53, (ref) v_u_1048
							local v1296, v1297 = v_u_106("GivePass", v_u_1049.id, v_u_1268.key)
							if v1297 then
								v_u_53.show(tostring(v1297), v1296 and "ok" or "error")
							end
							task.delay(0.6, v_u_1048, "passes")
						end,
						"\224\184\162\224\184\183\224\184\153\224\184\162\224\184\177\224\184\153? \224\185\131\224\184\171\224\185\137\224\184\159\224\184\163\224\184\181"
					}
				})
			end
		end
		if #v1259 > 0 then
			v_u_841(v_u_167, 4, "coin", ("\224\185\129\224\184\158\224\185\135\224\184\129\224\185\128\224\184\135\224\184\180\224\184\153\224\184\151\224\184\181\224\185\136\224\184\139\224\184\183\224\185\137\224\184\173\224\185\129\224\184\165\224\185\137\224\184\167  \194\183  %d"):format(#v1259))
			local v1298 = v_u_18.new("Frame", {
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["AutomaticSize"] = nil,
				["LayoutOrder"] = 5,
				["Parent"] = nil,
				["Size"] = UDim2.new(1, -10, 0, 0),
				["AutomaticSize"] = Enum.AutomaticSize.Y,
				["Parent"] = v_u_167
			})
			v_u_18.new("UIListLayout", {
				["FillDirection"] = nil,
				["Wraps"] = true,
				["Padding"] = nil,
				["SortOrder"] = nil,
				["Parent"] = nil,
				["FillDirection"] = Enum.FillDirection.Horizontal,
				["Padding"] = UDim.new(0, 6),
				["SortOrder"] = Enum.SortOrder.LayoutOrder,
				["Parent"] = v1298
			})
			for v1299, v1300 in v1259 do
				v_u_18.chip(v1298, v1300, v_u_12.green, {
					["LayoutOrder"] = v1299,
					["Size"] = UDim2.fromOffset(0, 24)
				})
			end
			return
		end
	else
		local v_u_1301 = v_u_828.TakeVehicle
		local function v1319(p1302, p1303, p1304, p1305, p1306, p_u_1307, p_u_1308) -- name: carryRow
			-- upvalues: (ref) v_u_18, (ref) v_u_11, (ref) v_u_167, (ref) v_u_10, (copy) v_u_1301
			local v1309 = v_u_18.new("Frame", {
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["LayoutOrder"] = nil,
				["Parent"] = nil,
				["BackgroundColor3"] = v_u_11.PANEL,
				["Size"] = UDim2.new(1, -10, 0, 50),
				["LayoutOrder"] = p1302,
				["Parent"] = v_u_167
			})
			v_u_18.corner(v1309, 8)
			v_u_18.padding(v1309, 12, 8)
			local v1310 = v_u_18.new("Frame", {
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["BackgroundColor3"] = p1304,
				["AnchorPoint"] = Vector2.new(0, 0.5),
				["Position"] = UDim2.fromScale(0, 0.5),
				["Size"] = UDim2.fromOffset(30, 30),
				["Parent"] = v1309
			})
			v_u_18.corner(v1310, 7)
			local v1311 = v_u_10.make(p1303, Color3.new(1, 1, 1), 15)
			local v1312 = Vector2.new(0.5, 0.5)
			local v1313 = UDim2.fromScale(0.5, 0.5)
			v1311.AnchorPoint = v1312
			v1311.Position = v1313
			v1311.Parent = v1310
			v_u_18.text({
				["Text"] = nil,
				["TextSize"] = 15,
				["FontFace"] = nil,
				["TextXAlignment"] = nil,
				["TextTruncate"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["Text"] = p1305,
				["FontFace"] = v_u_18.FONT_BOLD,
				["TextXAlignment"] = Enum.TextXAlignment.Left,
				["TextTruncate"] = Enum.TextTruncate.AtEnd,
				["Position"] = UDim2.fromOffset(42, 0),
				["Size"] = UDim2.new(1, -230, 1, 0),
				["Parent"] = v1309
			})
			if p1306 then
				v_u_18.text({
					["Text"] = nil,
					["TextSize"] = 15,
					["FontFace"] = nil,
					["TextColor3"] = nil,
					["TextXAlignment"] = nil,
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["Parent"] = nil,
					["Text"] = p1306,
					["FontFace"] = v_u_18.FONT_BOLD,
					["TextColor3"] = v_u_11.VALUE,
					["TextXAlignment"] = Enum.TextXAlignment.Right,
					["AnchorPoint"] = Vector2.new(1, 0),
					["Position"] = UDim2.new(1, -128, 0, 0),
					["Size"] = UDim2.new(0, 70, 1, 0),
					["Parent"] = v1309
				})
			end
			if v_u_1301 and p_u_1308 then
				local v_u_1314 = v_u_18.button({
					["text"] = nil,
					["grad"] = "orange",
					["textSize"] = 13,
					["anchor"] = nil,
					["position"] = nil,
					["size"] = nil,
					["parent"] = nil,
					["text"] = p_u_1307,
					["anchor"] = Vector2.new(1, 0.5),
					["position"] = UDim2.new(1, 0, 0.5, 0),
					["size"] = UDim2.fromOffset(116, 32),
					["parent"] = v1309
				})
				local v_u_1315 = nil
				local v_u_1316 = "orange"
				local v_u_1317 = "\224\184\162\224\184\183\224\184\153\224\184\162\224\184\177\224\184\153? \224\184\162\224\184\182\224\184\148"
				v_u_1314.Activated:Connect(function()
					-- upvalues: (ref) v_u_1315, (ref) v_u_18, (copy) v_u_1314, (copy) v_u_1316, (copy) p_u_1307, (copy) p_u_1308, (copy) v_u_1317
					if v_u_1315 and os.clock() - v_u_1315 < 4 then
						v_u_1315 = nil
						v_u_18.setButton(v_u_1314, v_u_1316, p_u_1307)
						p_u_1308()
					else
						local v_u_1318 = os.clock()
						v_u_1315 = v_u_1318
						v_u_18.setButton(v_u_1314, "red", v_u_1317)
						task.delay(4, function()
							-- upvalues: (ref) v_u_1315, (copy) v_u_1318, (ref) v_u_1314, (ref) v_u_18, (ref) v_u_1316, (ref) p_u_1307
							if v_u_1315 == v_u_1318 then
								v_u_1315 = nil
								if v_u_1314.Parent then
									v_u_18.setButton(v_u_1314, v_u_1316, p_u_1307)
								end
							end
						end)
					end
				end)
			end
			return v1309
		end
		if not v1063 and v_u_1301 then
			v_u_18.text({
				["Text"] = nil,
				["TextSize"] = 13,
				["TextColor3"] = nil,
				["TextXAlignment"] = nil,
				["TextWrapped"] = true,
				["Size"] = nil,
				["LayoutOrder"] = 0,
				["Parent"] = nil,
				["Text"] = v1062 and "\224\185\128\224\184\130\224\184\178\224\184\173\224\184\162\224\184\185\224\185\136\224\184\173\224\184\181\224\184\129\224\185\128\224\184\139\224\184\180\224\184\163\224\185\140\224\184\159: \224\184\129\224\184\148\224\184\162\224\184\182\224\184\148\224\185\129\224\184\165\224\185\137\224\184\167\224\185\130\224\184\148\224\184\153\224\184\162\224\184\182\224\184\148\224\184\151\224\184\177\224\184\153\224\184\151\224\184\181 (\224\184\149\224\184\177\224\184\167\224\185\128\224\184\165\224\184\130\224\184\151\224\184\181\224\185\136\224\184\153\224\184\181\224\185\136 = \224\184\151\224\184\181\224\185\136\224\185\128\224\184\139\224\184\159\224\184\165\224\185\136\224\184\178\224\184\170\224\184\184\224\184\148)" or "\224\185\128\224\184\130\224\184\178\224\184\173\224\184\173\224\184\159\224\185\132\224\184\165\224\184\153\224\185\140: \224\184\129\224\184\148\224\184\162\224\184\182\224\184\148\224\185\129\224\184\165\224\185\137\224\184\167\224\185\130\224\184\148\224\184\153\224\184\162\224\184\182\224\184\148\224\184\149\224\184\173\224\184\153\224\185\128\224\184\130\224\185\137\224\184\178\224\185\128\224\184\129\224\184\161\224\184\132\224\184\163\224\184\177\224\185\137\224\184\135\224\184\150\224\184\177\224\184\148\224\185\132\224\184\155 (\224\184\149\224\184\177\224\184\167\224\185\128\224\184\165\224\184\130\224\184\151\224\184\181\224\185\136\224\184\153\224\184\181\224\185\136 = \224\184\151\224\184\181\224\185\136\224\185\128\224\184\139\224\184\159\224\184\165\224\185\136\224\184\178\224\184\170\224\184\184\224\184\148)",
				["TextColor3"] = v_u_11.DIM,
				["TextXAlignment"] = Enum.TextXAlignment.Left,
				["Size"] = UDim2.new(1, -10, 0, 18),
				["Parent"] = v_u_167
			})
		end
		v_u_841(v_u_167, 1, "zap", "\224\184\165\224\184\185\224\184\129\224\184\170\224\184\185\224\184\154\224\185\131\224\184\153\224\184\129\224\184\163\224\184\176\224\185\128\224\184\155\224\185\139\224\184\178")
		local v1320
		if v1061 then
			local v1321 = v1061.bag
			v1320 = type(v1321) ~= "table" and {} or v1061.bag
		else
			v1320 = {}
		end
		for v1322, v_u_1323 in v1320 do
			v1319(1 + v1322, "zap", v_u_12.orange, ("\224\184\165\224\184\185\224\184\129\224\184\170\224\184\185\224\184\154 %g mm"):format(v_u_1323.size), ("\195\151 %d"):format(v_u_1323.count), "\224\184\162\224\184\182\224\184\148\224\184\151\224\184\177\224\185\137\224\184\135\224\184\171\224\184\161\224\184\148", function()
				-- upvalues: (ref) v_u_106, (copy) v_u_1049, (copy) v_u_1323, (ref) v_u_53, (ref) v_u_1048
				local v1324, v1325 = v_u_106("TakePiston", v_u_1049.id, "bag", v_u_1323.size)
				if v1325 then
					v_u_53.show(tostring(v1325), v1324 and "ok" or "error")
				end
				task.delay(0.8, v_u_1048, "items")
			end)
		end
		if #v1320 == 0 then
			v_u_18.text({
				["Text"] = nil,
				["TextSize"] = 14,
				["TextColor3"] = nil,
				["TextXAlignment"] = nil,
				["Size"] = nil,
				["LayoutOrder"] = 2,
				["Parent"] = nil,
				["Text"] = v1061 and "\224\185\132\224\184\161\224\185\136\224\184\161\224\184\181\224\184\165\224\184\185\224\184\129\224\184\170\224\184\185\224\184\154\224\185\131\224\184\153\224\184\129\224\184\163\224\184\176\224\185\128\224\184\155\224\185\139\224\184\178" or "\224\184\173\224\185\136\224\184\178\224\184\153\224\184\130\224\185\137\224\184\173\224\184\161\224\184\185\224\184\165\224\185\132\224\184\161\224\185\136\224\185\132\224\184\148\224\185\137",
				["TextColor3"] = v_u_11.DIM,
				["TextXAlignment"] = Enum.TextXAlignment.Left,
				["Size"] = UDim2.new(1, -10, 0, 22),
				["Parent"] = v_u_167
			})
		end
		if v_u_828.GivePiston then
			v_u_841(v_u_167, 40, "zap", "\224\185\128\224\184\170\224\184\129\224\184\165\224\184\185\224\184\129\224\184\170\224\184\185\224\184\154\224\185\128\224\184\130\224\185\137\224\184\178\224\184\149\224\184\177\224\184\167 \194\183 Owner")
			local v1326 = v_u_18.new("Frame", {
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["AutomaticSize"] = nil,
				["LayoutOrder"] = 41,
				["Parent"] = nil,
				["Size"] = UDim2.new(1, -10, 0, 0),
				["AutomaticSize"] = Enum.AutomaticSize.Y,
				["Parent"] = v_u_167
			})
			v_u_18.new("UIGridLayout", {
				["CellPadding"] = UDim2.fromOffset(6, 6),
				["CellSize"] = UDim2.fromOffset(84, 36),
				["SortOrder"] = Enum.SortOrder.LayoutOrder,
				["Parent"] = v1326
			})
			for v1327, v_u_1328 in v_u_6.SIZES do
				local v1329 = v_u_18.button({
					["text"] = nil,
					["grad"] = nil,
					["textSize"] = 14,
					["parent"] = nil,
					["text"] = ("%g mm"):format(v_u_1328),
					["grad"] = v_u_1328 == v_u_827 and "gold" or "dark",
					["parent"] = v1326
				})
				v1329.LayoutOrder = v1327
				v1329.Activated:Connect(function()
					-- upvalues: (ref) v_u_827, (copy) v_u_1328, (ref) v_u_1364
					v_u_827 = v_u_1328
					v_u_1364()
				end)
			end
			local v1330 = v_u_18.new("Frame", {
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["LayoutOrder"] = 42,
				["Parent"] = nil,
				["BackgroundColor3"] = v_u_11.PANEL,
				["Size"] = UDim2.new(1, -10, 0, 50),
				["Parent"] = v_u_167
			})
			v_u_18.corner(v1330, 8)
			v_u_18.padding(v1330, 12, 8)
			local v1331 = v_u_18.button({
				["text"] = "\226\136\146",
				["grad"] = "dark",
				["textSize"] = 18,
				["size"] = nil,
				["position"] = nil,
				["anchor"] = nil,
				["parent"] = nil,
				["size"] = UDim2.fromOffset(40, 34),
				["position"] = UDim2.new(0, 0, 0.5, 0),
				["anchor"] = Vector2.new(0, 0.5),
				["parent"] = v1330
			})
			local v_u_1332 = v_u_18.text({
				["Text"] = nil,
				["TextSize"] = 16,
				["FontFace"] = nil,
				["TextXAlignment"] = nil,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["Text"] = ("\195\151 %d"):format(v_u_830),
				["FontFace"] = v_u_18.FONT_BOLD,
				["TextXAlignment"] = Enum.TextXAlignment.Center,
				["AnchorPoint"] = Vector2.new(0, 0.5),
				["Position"] = UDim2.new(0, 46, 0.5, 0),
				["Size"] = UDim2.fromOffset(60, 34),
				["Parent"] = v1330
			})
			local v1333 = v_u_18.button({
				["text"] = "+",
				["grad"] = "dark",
				["textSize"] = 18,
				["size"] = nil,
				["position"] = nil,
				["anchor"] = nil,
				["parent"] = nil,
				["size"] = UDim2.fromOffset(40, 34),
				["position"] = UDim2.new(0, 112, 0.5, 0),
				["anchor"] = Vector2.new(0, 0.5),
				["parent"] = v1330
			})
			v1331.Activated:Connect(function()
				-- upvalues: (ref) v_u_830, (copy) v_u_1332
				local v1334 = v_u_830 - 1
				v_u_830 = math.clamp(v1334, 1, 20)
				v_u_1332.Text = ("\195\151 %d"):format(v_u_830)
			end)
			v1333.Activated:Connect(function()
				-- upvalues: (ref) v_u_830, (copy) v_u_1332
				local v1335 = v_u_830 + 1
				v_u_830 = math.clamp(v1335, 1, 20)
				v_u_1332.Text = ("\195\151 %d"):format(v_u_830)
			end)
			local v_u_1336 = v_u_18.button({
				["text"] = nil,
				["grad"] = "green",
				["textSize"] = 13,
				["anchor"] = nil,
				["position"] = nil,
				["size"] = nil,
				["parent"] = nil,
				["text"] = ("\224\185\128\224\184\170\224\184\129 %g mm \224\185\128\224\184\130\224\185\137\224\184\178\224\184\149\224\184\177\224\184\167"):format(v_u_827),
				["anchor"] = Vector2.new(1, 0.5),
				["position"] = UDim2.new(1, 0, 0.5, 0),
				["size"] = UDim2.fromOffset(170, 34),
				["parent"] = v1330
			})
			local v_u_1337 = ("\224\185\128\224\184\170\224\184\129 %g mm \224\185\128\224\184\130\224\185\137\224\184\178\224\184\149\224\184\177\224\184\167"):format(v_u_827)
			local function v_u_1340()
				-- upvalues: (ref) v_u_106, (copy) v_u_1049, (ref) v_u_827, (ref) v_u_830, (ref) v_u_53, (ref) v_u_1048
				local v1338, v1339 = v_u_106("GivePiston", v_u_1049.id, v_u_827, v_u_830)
				if v1339 then
					v_u_53.show(tostring(v1339), v1338 and "ok" or "error")
				end
				task.delay(0.8, v_u_1048, "items")
			end
			local v_u_1341 = nil
			local v_u_1342 = "green"
			local v_u_1343 = "\224\184\162\224\184\183\224\184\153\224\184\162\224\184\177\224\184\153? \224\185\128\224\184\170\224\184\129"
			v_u_1336.Activated:Connect(function()
				-- upvalues: (ref) v_u_1341, (ref) v_u_18, (copy) v_u_1336, (copy) v_u_1342, (copy) v_u_1337, (copy) v_u_1340, (copy) v_u_1343
				if v_u_1341 and os.clock() - v_u_1341 < 4 then
					v_u_1341 = nil
					v_u_18.setButton(v_u_1336, v_u_1342, v_u_1337)
					v_u_1340()
				else
					local v_u_1344 = os.clock()
					v_u_1341 = v_u_1344
					v_u_18.setButton(v_u_1336, "red", v_u_1343)
					task.delay(4, function()
						-- upvalues: (ref) v_u_1341, (copy) v_u_1344, (ref) v_u_1336, (ref) v_u_18, (ref) v_u_1342, (ref) v_u_1337
						if v_u_1341 == v_u_1344 then
							v_u_1341 = nil
							if v_u_1336.Parent then
								v_u_18.setButton(v_u_1336, v_u_1342, v_u_1337)
							end
						end
					end)
				end
			end)
		end
		v_u_841(v_u_167, 100, "store", "\224\185\132\224\184\173\224\185\128\224\184\151\224\184\161")
		local v1345
		if v1061 then
			local v1346 = v1061.itemList
			v1345 = type(v1346) ~= "table" and {} or v1061.itemList
		else
			v1345 = {}
		end
		for v1347, v_u_1348 in v1345 do
			local v1349 = 100 + v1347
			local v1350 = "store"
			local v1351 = v_u_12.blue
			local v1352 = v_u_1348.name
			local v1353 = tostring(v1352)
			local v1354
			if v_u_1348.once then
				v1354 = nil
			else
				local v1355 = v_u_1348.count
				v1354 = ("\195\151 %d"):format(tonumber(v1355) or 0)
			end
			v1319(v1349, v1350, v1351, v1353, v1354, "\224\184\162\224\184\182\224\184\148", function()
				-- upvalues: (ref) v_u_106, (copy) v_u_1049, (copy) v_u_1348, (ref) v_u_53, (ref) v_u_1048
				local v1356, v1357 = v_u_106("TakeItem", v_u_1049.id, v_u_1348.id)
				if v1357 then
					v_u_53.show(tostring(v1357), v1356 and "ok" or "error")
				end
				task.delay(0.8, v_u_1048, "items")
			end)
		end
		if #v1345 == 0 then
			local v1358
			if v1061 then
				local v1359 = v1061.items
				v1358 = type(v1359) ~= "table" and {} or v1061.items
			else
				v1358 = {}
			end
			v_u_18.text({
				["Text"] = nil,
				["TextSize"] = 14,
				["TextColor3"] = nil,
				["TextXAlignment"] = nil,
				["Size"] = nil,
				["LayoutOrder"] = 101,
				["Parent"] = nil,
				["Text"] = #v1358 <= 0 and "\224\185\132\224\184\161\224\185\136\224\184\161\224\184\181\224\185\132\224\184\173\224\185\128\224\184\151\224\184\161" or table.concat(v1358, " \194\183 "),
				["TextColor3"] = v_u_11.DIM,
				["TextXAlignment"] = Enum.TextXAlignment.Left,
				["Size"] = UDim2.new(1, -10, 0, 22),
				["Parent"] = v_u_167
			})
		end
		v_u_841(v_u_167, 200, "shield", "\224\184\171\224\184\161\224\184\167\224\184\129")
		if v1061 and v1061.helmet then
			local v1360 = v_u_12.purple
			local v1361 = v1061.helmet
			v1319(201, "shield", v1360, tostring(v1361), nil, "\224\184\162\224\184\182\224\184\148\224\184\171\224\184\161\224\184\167\224\184\129", function()
				-- upvalues: (ref) v_u_106, (copy) v_u_1049, (ref) v_u_53, (ref) v_u_1048
				local v1362, v1363 = v_u_106("TakeHelmet", v_u_1049.id)
				if v1363 then
					v_u_53.show(tostring(v1363), v1362 and "ok" or "error")
				end
				task.delay(0.8, v_u_1048, "items")
			end)
			return
		end
		v_u_18.text({
			["Text"] = "\224\185\132\224\184\161\224\185\136\224\185\132\224\184\148\224\185\137\224\185\131\224\184\170\224\185\136\224\184\171\224\184\161\224\184\167\224\184\129",
			["TextSize"] = 14,
			["TextColor3"] = nil,
			["TextXAlignment"] = nil,
			["Size"] = nil,
			["LayoutOrder"] = 201,
			["Parent"] = nil,
			["TextColor3"] = v_u_11.DIM,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["Size"] = UDim2.new(1, -10, 0, 22),
			["Parent"] = v_u_167
		})
	end
end
v_u_183 = function(p_u_1365, p1366, p1367) -- name: openDetail
	-- upvalues: (copy) v_u_1016, (copy) v_u_1022, (ref) v_u_829, (copy) v_u_164, (copy) v_u_165, (copy) v_u_163, (copy) v_u_264, (copy) v_u_167, (copy) v_u_106, (ref) v_u_1364
	local v1368 = v_u_1016
	v1368.seq = v1368.seq + 1
	local v_u_1369 = v_u_1016.seq
	local v1370 = v_u_1016
	local v1371 = v_u_1016
	v_u_1016.tab = p1366 or "info"
	v1370.entry = p1367
	v1371.data = nil
	v_u_1022()
	v_u_829("detail")
	local v1372 = v_u_165
	v_u_164.Text = "\224\184\129\224\184\179\224\184\165\224\184\177\224\184\135\224\185\130\224\184\171\224\184\165\224\184\148\226\128\166"
	v1372.Text = ""
	local v1373 = v_u_163
	local v1374
	if tonumber(p_u_1365) then
		local v1375 = tonumber(p_u_1365)
		v1374 = ("rbxthumb://type=AvatarHeadShot&id=%d&w=150&h=150"):format(tonumber(v1375) or 1)
	else
		v1374 = ""
	end
	v1373.Image = v1374
	v_u_264(v_u_167)
	task.spawn(function()
		-- upvalues: (ref) v_u_106, (copy) p_u_1365, (copy) v_u_1369, (ref) v_u_1016, (ref) v_u_164, (ref) v_u_165, (ref) v_u_1364
		local v1376 = p_u_1365
		local v1377, v1378 = v_u_106("Lookup", (tostring(v1376)))
		if v_u_1369 == v_u_1016.seq then
			if v1377 and type(v1378) == "table" then
				v_u_1016.data = v1378
				v_u_1364()
			else
				local v1379 = v_u_164
				local v1380 = v_u_165
				local v1381 = tostring(v1378 or "")
				v1379.Text = "\224\185\132\224\184\161\224\185\136\224\184\158\224\184\154\224\184\156\224\184\185\224\185\137\224\185\128\224\184\165\224\185\136\224\184\153"
				v1380.Text = v1381
			end
		else
			return
		end
	end)
end
local _ = v_u_183
local v_u_1382 = v_u_184
local v_u_1383 = v_u_1364
for v_u_1384, v1385 in v_u_168 do
	v1385.Activated:Connect(function()
		-- upvalues: (copy) v_u_1016, (copy) v_u_1384, (copy) v_u_1022, (ref) v_u_1383
		v_u_1016.tab = v_u_1384
		v_u_1022()
		v_u_1383()
	end)
end
local v_u_1386 = ""
local function v_u_1398() -- name: buildCodes
	-- upvalues: (copy) v_u_264, (copy) v_u_194, (copy) v_u_209, (copy) v_u_18, (copy) v_u_248, (copy) v_u_220, (ref) v_u_1386, (copy) v_u_53, (copy) v_u_106, (copy) v_u_244
	v_u_264(v_u_194)
	local v1387 = v_u_209(v_u_194, 1)
	v_u_18.new("UIListLayout", {
		["Padding"] = UDim.new(0, 8),
		["SortOrder"] = Enum.SortOrder.LayoutOrder,
		["Parent"] = v1387
	})
	v_u_248(v1387, 1, "\224\184\132\224\185\137\224\184\153\224\184\171\224\184\178\224\184\167\224\185\136\224\184\178\224\185\131\224\184\132\224\184\163\224\184\170\224\184\163\224\185\137\224\184\178\224\184\135\224\185\130\224\184\132\224\185\137\224\184\148\224\184\136\224\184\185\224\184\153")
	v_u_18.text({
		["Text"] = "\224\185\131\224\184\170\224\185\136\224\185\130\224\184\132\224\185\137\224\184\148\224\184\136\224\184\185\224\184\153 (\224\184\151\224\184\181\224\185\136\224\184\156\224\184\185\224\185\137\224\185\128\224\184\165\224\185\136\224\184\153\224\184\129\224\184\148\224\184\170\224\184\163\224\185\137\224\184\178\224\184\135\224\185\131\224\184\153\224\184\171\224\184\153\224\185\137\224\184\178 ECU) \224\185\129\224\184\165\224\185\137\224\184\167\224\184\129\224\184\148\224\184\132\224\185\137\224\184\153\224\184\171\224\184\178 \224\184\136\224\184\176\224\184\130\224\184\182\224\185\137\224\184\153\224\184\138\224\184\183\224\185\136\224\184\173\224\184\132\224\184\153\224\184\170\224\184\163\224\185\137\224\184\178\224\184\135 \224\184\167\224\184\177\224\184\153\224\184\151\224\184\181\224\185\136 \224\184\163\224\184\150 \224\185\129\224\184\165\224\184\176\224\184\132\224\184\153\224\184\151\224\184\181\224\185\136\224\185\131\224\184\138\224\185\137\224\185\130\224\184\132\224\185\137\224\184\148\224\185\132\224\184\155\224\185\129\224\184\165\224\185\137\224\184\167",
		["TextSize"] = 13,
		["TextColor3"] = nil,
		["TextWrapped"] = true,
		["TextXAlignment"] = nil,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = 2,
		["Parent"] = nil,
		["TextColor3"] = v_u_18.TEXT_DIM,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y,
		["Parent"] = v1387
	})
	local v_u_1388 = v_u_220(v1387, "\224\185\130\224\184\132\224\185\137\224\184\148 \224\185\128\224\184\138\224\185\136\224\184\153 ABCD1234", {
		["LayoutOrder"] = 3
	})
	v_u_1388.Text = v_u_1386
	v_u_1388:GetPropertyChangedSignal("Text"):Connect(function()
		-- upvalues: (ref) v_u_1386, (copy) v_u_1388
		v_u_1386 = v_u_1388.Text
	end)
	local v_u_1389 = v_u_18.text({
		["Name"] = "Result",
		["Text"] = "",
		["TextSize"] = 15,
		["FontFace"] = nil,
		["TextWrapped"] = true,
		["RichText"] = false,
		["TextXAlignment"] = nil,
		["TextYAlignment"] = nil,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = 5,
		["Parent"] = nil,
		["FontFace"] = v_u_18.FONT_BOLD,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["TextYAlignment"] = Enum.TextYAlignment.Top,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y,
		["Parent"] = v1387
	})
	local v_u_1390 = false
	local function v_u_1396() -- name: search
		-- upvalues: (ref) v_u_1390, (copy) v_u_1388, (ref) v_u_53, (copy) v_u_1389, (ref) v_u_18, (ref) v_u_106
		if v_u_1390 then
			return
		else
			local v1391 = v_u_1388.Text:gsub("%s", "")
			if v1391 == "" then
				v_u_53.show(tostring("\224\185\131\224\184\170\224\185\136\224\185\130\224\184\132\224\185\137\224\184\148\224\184\129\224\185\136\224\184\173\224\184\153"), "error")
			else
				v_u_1390 = true
				v_u_1389.TextColor3 = v_u_18.TEXT_DIM
				v_u_1389.Text = "\224\184\129\224\184\179\224\184\165\224\184\177\224\184\135\224\184\132\224\185\137\224\184\153\224\184\171\224\184\178\226\128\166"
				local v1392, v1393 = v_u_106("CodeOwner", v1391)
				v_u_1390 = false
				local v1394 = v_u_1389
				local v1395
				if v1392 then
					v1395 = Color3.new(1, 1, 1)
				else
					v1395 = Color3.fromRGB(255, 120, 120)
				end
				v1394.TextColor3 = v1395
				v_u_1389.Text = tostring(v1393 or "")
			end
		end
	end
	v_u_1388.FocusLost:Connect(function(p1397)
		-- upvalues: (copy) v_u_1396
		if p1397 then
			v_u_1396()
		end
	end)
	v_u_244(v1387, 4, {
		{
			"\224\184\132\224\185\137\224\184\153\224\184\171\224\184\178",
			"gold",
			"key",
			v_u_1396
		}
	})
end
local function v_u_1406() -- name: buildTop
	-- upvalues: (copy) v_u_264, (copy) v_u_195, (copy) v_u_209, (copy) v_u_18, (copy) v_u_248, (copy) v_u_244, (copy) v_u_106, (copy) v_u_53
	v_u_264(v_u_195)
	local v1399 = v_u_209(v_u_195, 1)
	v_u_18.new("UIListLayout", {
		["Padding"] = UDim.new(0, 8),
		["SortOrder"] = Enum.SortOrder.LayoutOrder,
		["Parent"] = v1399
	})
	v_u_248(v1399, 1, "\224\184\136\224\184\185\224\184\153\224\185\128\224\184\149\224\185\135\224\184\161 \224\184\155\224\184\184\224\185\136\224\184\161\224\185\128\224\184\148\224\184\181\224\184\162\224\184\167")
	v_u_18.text({
		["Text"] = "\224\184\130\224\184\182\224\185\137\224\184\153\224\184\153\224\184\177\224\185\136\224\184\135\224\184\151\224\184\181\224\185\136\224\184\132\224\184\153\224\184\130\224\184\177\224\184\154\224\184\163\224\184\150\224\184\130\224\184\173\224\184\135\224\184\132\224\184\184\224\184\147 \224\185\129\224\184\165\224\185\137\224\184\167\224\184\129\224\184\148\224\184\155\224\184\184\224\185\136\224\184\161\224\184\148\224\185\137\224\184\178\224\184\153\224\184\165\224\185\136\224\184\178\224\184\135: \224\185\128\224\184\132\224\184\163\224\184\183\224\185\136\224\184\173\224\184\135 Stage 3 \194\183 \224\185\128\224\184\154\224\184\163\224\184\129\224\184\149\224\184\177\224\184\167\224\184\151\224\185\135\224\184\173\224\184\155 \194\183 \224\184\165\224\184\185\224\184\129 90 (\224\184\161\224\184\173\224\185\132\224\184\139\224\184\132\224\185\140\224\184\151\224\184\181\224\185\136\224\185\131\224\184\170\224\185\136\224\185\132\224\184\148\224\185\137) \194\183 ECU \224\184\136\224\184\185\224\184\153\224\185\128\224\184\149\224\185\135\224\184\161 x2 \194\183 \224\184\153\224\185\137\224\184\179\224\184\161\224\184\177\224\184\153\224\185\129\224\184\165\224\184\176\224\185\128\224\184\132\224\184\163\224\184\183\224\185\136\224\184\173\224\184\135\224\185\128\224\184\149\224\185\135\224\184\161 100% \194\183 \224\185\129\224\184\163\224\184\135\224\184\170\224\184\184\224\184\148\224\185\128\224\184\151\224\185\136\224\184\178\224\184\151\224\184\181\224\185\136\224\185\128\224\184\129\224\184\161\224\185\131\224\184\171\224\185\137 (\224\185\132\224\184\161\224\185\136\224\185\128\224\184\129\224\184\180\224\184\153\224\185\128\224\184\158\224\184\148\224\184\178\224\184\153\224\184\132\224\184\167\224\184\178\224\184\161\224\185\128\224\184\163\224\185\135\224\184\167\224\184\130\224\184\173\224\184\135\224\185\128\224\184\129\224\184\161)",
		["TextSize"] = 13,
		["TextColor3"] = nil,
		["TextWrapped"] = true,
		["TextXAlignment"] = nil,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = 2,
		["Parent"] = nil,
		["TextColor3"] = v_u_18.TEXT_DIM,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y,
		["Parent"] = v1399
	})
	local v_u_1400 = v_u_18.text({
		["Name"] = "Result",
		["Text"] = "",
		["TextSize"] = 15,
		["FontFace"] = nil,
		["TextWrapped"] = true,
		["TextXAlignment"] = nil,
		["TextYAlignment"] = nil,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = 4,
		["Parent"] = nil,
		["FontFace"] = v_u_18.FONT_BOLD,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["TextYAlignment"] = Enum.TextYAlignment.Top,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y,
		["Parent"] = v1399
	})
	local v_u_1401 = false
	v_u_244(v1399, 3, {
		{
			"\224\184\136\224\184\185\224\184\153\224\185\128\224\184\149\224\185\135\224\184\161  Stage 3 + \224\184\165\224\184\185\224\184\129 90",
			"gold",
			"gauge",
			function()
				-- upvalues: (ref) v_u_1401, (copy) v_u_1400, (ref) v_u_18, (ref) v_u_106, (ref) v_u_53
				if not v_u_1401 then
					v_u_1401 = true
					v_u_1400.TextColor3 = v_u_18.TEXT_DIM
					v_u_1400.Text = "\224\184\129\224\184\179\224\184\165\224\184\177\224\184\135\224\184\136\224\184\185\224\184\153\226\128\166"
					local v1402, v1403 = v_u_106("MaxTune")
					v_u_1401 = false
					local v1404 = v_u_1400
					local v1405
					if v1402 then
						v1405 = Color3.fromRGB(120, 230, 150)
					else
						v1405 = Color3.fromRGB(255, 120, 120)
					end
					v1404.TextColor3 = v1405
					v_u_1400.Text = tostring(v1403 or "")
					if v1403 then
						v_u_53.show(tostring(v1403), v1402 and "ok" or "error")
					end
				end
			end
		}
	})
end
local v_u_1407 = "main"
local v_u_1408 = "all"
local v_u_1409 = {
	["main"] = v_u_197,
	["all"] = v_u_188,
	["here"] = v_u_198,
	["inspect"] = v_u_199,
	["detail"] = v159,
	["codes"] = v_u_194,
	["Top"] = v_u_195
}
local v_u_1410 = {
	["Top"] = "\224\184\132\224\184\167\224\184\178\224\184\161\224\185\128\224\184\163\224\185\135\224\184\167\224\184\130\224\184\177\224\185\137\224\184\153\224\184\170\224\184\185\224\184\135\224\184\170\224\184\184\224\184\148",
	["codes"] = "\224\184\132\224\185\137\224\184\153\224\184\171\224\184\178\224\185\128\224\184\136\224\185\137\224\184\178\224\184\130\224\184\173\224\184\135\224\185\130\224\184\132\224\185\137\224\184\148 (\224\185\130\224\184\132\224\185\137\224\184\148\224\184\136\224\184\185\224\184\153)",
	["main"] = "\224\185\128\224\184\161\224\184\153\224\184\185\224\184\171\224\184\165\224\184\177\224\184\129",
	["inspect"] = "\224\184\149\224\184\163\224\184\167\224\184\136\224\184\156\224\184\185\224\185\137\224\185\128\224\184\165\224\185\136\224\184\153",
	["detail"] = "\224\184\130\224\185\137\224\184\173\224\184\161\224\184\185\224\184\165\224\184\156\224\184\185\224\185\137\224\185\128\224\184\165\224\185\136\224\184\153",
	["Watch"] = "\224\184\163\224\184\178\224\184\162\224\184\138\224\184\183\224\185\136\224\184\173\224\185\128\224\184\157\224\185\137\224\184\178\224\184\148\224\184\185",
	["Log"] = "\224\184\155\224\184\163\224\184\176\224\184\167\224\184\177\224\184\149\224\184\180\224\185\129\224\184\173\224\184\148\224\184\161\224\184\180\224\184\153",
	["Creator"] = "\224\184\132\224\184\163\224\184\181\224\185\128\224\184\173\224\185\128\224\184\149\224\184\173\224\184\163\224\185\140",
	["Passes"] = "\224\185\128\224\184\129\224\184\161\224\184\158\224\184\178\224\184\170  \194\183  \224\185\131\224\184\132\224\184\163\224\184\161\224\184\181\224\184\173\224\184\176\224\185\132\224\184\163 (\224\185\129\224\184\149\224\184\176\224\185\128\224\184\158\224\184\183\224\185\136\224\184\173\224\184\148\224\184\185\224\184\163\224\184\178\224\184\162\224\184\138\224\184\183\224\185\136\224\184\173)"
}
local function v_u_1411() -- name: applyAllowed
	-- upvalues: (copy) v_u_141, (ref) v_u_828
	v_u_141.inspect.key.Visible = v_u_828.Lookup == true
	v_u_141.Watch.key.Visible = v_u_828.WatchList == true
	v_u_141.Log.key.Visible = v_u_828.Log == true
	v_u_141.codes.key.Visible = v_u_828.Log == true
	v_u_141.Creator.key.Visible = v_u_828.CreatorList == true
	v_u_141.Top.key.Visible = v_u_828.MaxTune == true
end
v_u_182 = function(p_u_1412) -- name: nav
	-- upvalues: (ref) v_u_1407, (ref) v_u_1408, (copy) v_u_178, (copy) v_u_1409, (copy) v_u_819, (copy) v_u_153, (copy) v_u_152, (copy) v_u_1410, (ref) v_u_828, (ref) v_u_825, (ref) v_u_824, (copy) v_u_1411, (ref) v_u_1382, (ref) v_u_1004, (copy) v_u_1015, (ref) v_u_1398, (copy) v_u_1406, (ref) v_u_823
	v_u_1407 = p_u_1412
	if p_u_1412 == "all" or p_u_1412 == "here" then
		v_u_1408 = p_u_1412
	end
	local v1413 = v_u_178
	local v1414
	if p_u_1412 == "detail" then
		v1414 = nil
	else
		v1414 = p_u_1412
	end
	v1413(v1414)
	for v1415, v1416 in v_u_1409 do
		v1416.Visible = v1415 == p_u_1412
	end
	v_u_819(p_u_1412)
	local v1417 = p_u_1412 == "all" and true or p_u_1412 == "here"
	v_u_153.Visible = v1417
	v_u_152.Visible = not v1417
	v_u_152.Text = v_u_1410[p_u_1412] or ""
	task.spawn(function()
		-- upvalues: (ref) v_u_828, (ref) v_u_825, (ref) v_u_824, (ref) v_u_1411, (ref) v_u_1407, (copy) p_u_1412, (ref) v_u_1382, (ref) v_u_1004, (ref) v_u_1015, (ref) v_u_1398, (ref) v_u_1406, (ref) v_u_823
		if next(v_u_828) == nil then
			v_u_825()
			local v1418 = os.clock()
			while v_u_824 and os.clock() - v1418 < 15 do
				task.wait(0.1)
			end
		end
		v_u_1411()
		if v_u_1407 == p_u_1412 then
			if p_u_1412 == "main" then
				v_u_1382()
				return
			elseif p_u_1412 == "all" then
				v_u_825()
				return
			elseif p_u_1412 == "here" then
				v_u_1004()
				return
			elseif p_u_1412 == "inspect" then
				v_u_1015()
				return
			elseif p_u_1412 == "codes" then
				v_u_1398()
				return
			elseif p_u_1412 == "Top" then
				v_u_1406()
			elseif p_u_1412 == "Passes" and not v_u_823 then
				v_u_825()
			end
		else
			return
		end
	end)
end
local v_u_1419 = v_u_1407
local v_u_1420 = v_u_1408
local v_u_1421 = v_u_182
for v_u_1422, v1423 in v_u_141 do
	v1423.key.Activated:Connect(function()
		-- upvalues: (ref) v_u_1421, (copy) v_u_1422
		v_u_1421(v_u_1422)
	end)
end
v162.Activated:Connect(function()
	-- upvalues: (ref) v_u_1421, (ref) v_u_1420
	v_u_1421(v_u_1420)
end)
v_u_256:GetPropertyChangedSignal("Text"):Connect(function()
	-- upvalues: (ref) v_u_1419, (ref) v_u_1004
	if v_u_1419 == "here" then
		v_u_1004()
	end
end)
local v_u_1424 = false
function v_u_126.setOpen(p1425) -- name: setOpen
	-- upvalues: (ref) v_u_1424, (copy) v_u_131, (copy) v_u_126
	if p1425 ~= v_u_1424 then
		v_u_1424 = p1425
		v_u_131.Visible = p1425
		v_u_126.changed:Fire(p1425)
	end
end
function v_u_126.isOpen() -- name: isOpen
	-- upvalues: (ref) v_u_1424
	return v_u_1424
end
v154.Activated:Connect(function()
	-- upvalues: (copy) v_u_126
	v_u_126.setOpen(false)
end)
local function v_u_1428(p1426) -- name: setOpen
	-- upvalues: (copy) v_u_7, (copy) v_u_54, (copy) v_u_126, (copy) v_u_139, (ref) v_u_1421, (ref) v_u_1419
	if not p1426 or v_u_7.isStaff(v_u_54) then
		v_u_126.setOpen(p1426)
		if p1426 then
			local v1427 = v_u_54:GetAttribute("Rank")
			v_u_139.Text = v_u_7.label(v1427)
			v_u_139.TextColor3 = v_u_7.info(v1427).color
			v_u_1421(v_u_1419)
		end
	end
end
v_u_107.Activated:Connect(function()
	-- upvalues: (copy) v_u_1428, (copy) v_u_126
	v_u_1428(not v_u_126.isOpen())
end)
v_u_57:GetAttributeChangedSignal("Open"):Connect(function()
	-- upvalues: (copy) v_u_1428, (copy) v_u_57
	v_u_1428(v_u_57:GetAttribute("Open") == true)
end)
v_u_126.changed.Event:Connect(function(p1429)
	-- upvalues: (copy) v_u_57
	v_u_57:SetAttribute("Open", p1429)
end)
v_u_4.InputBegan:Connect(function(p1430, p1431)
	-- upvalues: (copy) v_u_1428, (copy) v_u_126
	if not p1431 and p1430.KeyCode == Enum.KeyCode.F2 then
		v_u_1428(not v_u_126.isOpen())
	end
end)
task.spawn(function()
	-- upvalues: (copy) v_u_126, (ref) v_u_1419, (ref) v_u_825
	while true do
		repeat
			task.wait(10)
		until v_u_126.isOpen() and v_u_1419 == "all"
		v_u_825()
	end
end)
local function v1435() -- name: onRank
	-- upvalues: (copy) v_u_7, (copy) v_u_54, (copy) v_u_107, (copy) v_u_109, (copy) v_u_4, (ref) v_u_108, (copy) v_u_18, (copy) v_u_126
	local v1432 = v_u_7.isStaff(v_u_54)
	v_u_107.Visible = v1432
	local v1433 = v_u_109
	local v1434 = v1432 and v_u_4.KeyboardEnabled
	if v1434 then
		v1434 = v_u_4.MouseEnabled
	end
	v1433.Visible = v1434
	if not v1432 and v_u_108 then
		v_u_108 = false
		v_u_18.setButton(v_u_109, "grey", "Ctrl Warp: OFF")
	end
	if not v1432 and v_u_126.isOpen() then
		v_u_126.setOpen(false)
	end
end
v_u_54:GetAttributeChangedSignal("Rank"):Connect(v1435)
v1435()