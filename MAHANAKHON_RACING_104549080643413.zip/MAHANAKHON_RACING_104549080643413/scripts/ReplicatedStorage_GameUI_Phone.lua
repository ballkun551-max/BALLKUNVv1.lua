-- Path: ReplicatedStorage/GameUI/Phone
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_2 = {
	["changed"] = Instance.new("BindableEvent"),
	["launched"] = Instance.new("BindableEvent"),
	["routeLength"] = nil,
	["launch"] = function(p1) -- name: launch
		-- upvalues: (copy) v_u_2
		v_u_2.launched:Fire(p1)
	end,
	["toggle"] = function() -- name: toggle
		-- upvalues: (copy) v_u_2
		v_u_2.changed:Fire("toggle")
	end,
	["open"] = function() -- name: open
		-- upvalues: (copy) v_u_2
		v_u_2.changed:Fire("open")
	end,
	["close"] = function() -- name: close
		-- upvalues: (copy) v_u_2
		v_u_2.changed:Fire("close")
	end
}
return v_u_2