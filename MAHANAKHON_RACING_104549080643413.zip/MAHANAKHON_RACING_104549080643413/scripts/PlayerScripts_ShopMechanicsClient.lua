-- Path: Players/ygggggg55551/PlayerScripts/ShopMechanicsClient
-- Class: LocalScript  true/Enum.RunContext.Legacy
-- Decompiled by BALL KUN Universal Map Dump

local v1 = game:GetService("CollectionService")
local v2 = game:GetService("RunService")
local v_u_3 = require(game:GetService("ReplicatedStorage"):WaitForChild("ShopMechanicPose"))
local v_u_4 = {}
local function v_u_9(p5) -- name: add
	-- upvalues: (copy) v_u_4, (copy) v_u_3
	if v_u_4[p5] or not p5:IsA("Model") then
		return
	else
		local v6 = v_u_3.rig(p5)
		local v7 = v_u_3.ANIMS[p5:GetAttribute("Anim")]
		local v8 = p5:GetAttribute("Home")
		if v6.root and (#v6.joints >= 15 and (v7 and typeof(v8) == "CFrame")) then
			v_u_4[p5] = {
				["rig"] = v6,
				["anim"] = v7,
				["home"] = v8,
				["floor"] = p5:GetAttribute("FloorY"),
				["phase"] = p5:GetAttribute("Phase") or 0
			}
		end
	end
end
v1:GetInstanceAddedSignal("ShopMechanic"):Connect(function(p10)
	-- upvalues: (copy) v_u_9
	task.defer(v_u_9, p10)
end)
v1:GetInstanceRemovedSignal("ShopMechanic"):Connect(function(p11)
	-- upvalues: (copy) v_u_4
	v_u_4[p11] = nil
end)
for _, v12 in v1:GetTagged("ShopMechanic") do
	task.defer(v_u_9, v12)
end
local v_u_13 = 0
v2.Heartbeat:Connect(function(p14)
	-- upvalues: (ref) v_u_13, (copy) v_u_4, (copy) v_u_3
	v_u_13 = v_u_13 + p14
	if v_u_13 < 0.03333333333333333 then
		return
	else
		v_u_13 = 0
		local v15 = workspace.CurrentCamera
		if v15 then
			local v16 = v15.CFrame.Position
			local v17 = os.clock()
			for v18, v19 in v_u_4 do
				if v18.Parent then
					if (v19.home.Position - v16).Magnitude >= 120 then
						continue
					end
					local v20, v21 = v_u_3.solve(v19.rig, v19.home, v19.anim(v17 + v19.phase), v19.floor)
					workspace:BulkMoveTo(v20, v21, Enum.BulkMoveMode.FireCFrameChanged)
				else
					v_u_4[v18] = nil
				end
			end
		end
	end
end)