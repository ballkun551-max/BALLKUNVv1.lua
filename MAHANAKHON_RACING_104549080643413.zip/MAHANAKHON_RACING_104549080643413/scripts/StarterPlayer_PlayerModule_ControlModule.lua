-- Path: StarterPlayer/PlayerModule/ControlModule
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = {}
v_u_1.__index = v_u_1
local v_u_2 = game:GetService("Players")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("UserInputService")
local v_u_5 = game:GetService("GuiService")
local v_u_6 = game:GetService("Workspace")
local v_u_7 = game:GetService("StarterPlayer")
local v_u_8 = UserSettings():GetService("UserGameSettings")
local v_u_9 = game:GetService("VRService")
local v_u_10 = game:GetService("ContextActionService")
local v11 = require(script.Parent:WaitForChild("CommonUtils"))
local v12 = v11.get("FlagUtil")
local v_u_13 = v12.getUserFlag("UserVRFixCameraCloseArticulation")
local v_u_14 = v12.getUserFlag("UserPlayerScriptsCCLIntegrationD") or v12.getUserFlag("UserPlayerScriptsCCLIntegrationDGA")
local v_u_15 = v12.getUserFlag("UserPlayerScriptsBindActivateOnIAS")
local v_u_16 = v12.getUserFlag("UserPlayerScriptsPlayerControlState2") or v12.getUserFlag("UserPlayerScriptsPlayerControlState2GA")
local v_u_17 = v12.getUserFlag("UserPlayerScriptsTaskDeferSimulation")
local v_u_18 = v12.getUserFlag("UserPlayerScriptsFixSAuthRenderStepMove")
local v_u_19 = v12.getUserFlag("UserPlayerScriptsSupportMicroGamepad")
local v_u_20 = v12.getUserFlag("UserAbilitiesUserInterfaceA")
local v_u_21 = v12.getUserFlag("UserAbilitiesUserInterfaceC")
local v_u_22 = v12.getUserFlag("UserPSUseBindToAnimation")
local v_u_23 = v12.getUserFlag("UserServerAuthorityDontSetAutoRotate")
local v_u_24 = v12.getUserFlag("UserPlayerModuleEngineAPI")
local v_u_25 = v12.getUserFlag("UserControlModuleDisabledUpdate")
local v_u_26 = require(script:WaitForChild("ActionController"))
local v_u_27
if v_u_14 or v_u_16 then
	v_u_27 = require(script:WaitForChild("InputReplication"))
else
	v_u_27 = nil
end
local v_u_28
if v_u_14 then
	v_u_28 = require(script:WaitForChild("InputSlots"))
else
	v_u_28 = nil
end
local v_u_29
if v_u_3:IsClient() then
	v_u_29 = require(script:WaitForChild("DynamicThumbstick"))
else
	v_u_29 = nil
end
local v_u_30 = require(script:WaitForChild("ClassicThumbstick"))
local v_u_31 = require(script:WaitForChild("ClickToMoveController"))
local v_u_32 = require(script:WaitForChild("TouchJump"))
local v_u_33
if v_u_14 then
	v_u_33 = require(script:WaitForChild("TouchAbilities"))
else
	v_u_33 = nil
end
local v_u_34
if v_u_14 then
	v_u_34 = require(script:WaitForChild("AbilitiesOverflowMenu"))
else
	v_u_34 = nil
end
local v_u_35
if v_u_14 then
	v_u_35 = require(script:WaitForChild("AbilitiesKeybindBar"))
else
	v_u_35 = nil
end
local v_u_36 = require(script:WaitForChild("VehicleController"))
local v_u_37, v_u_38
if v_u_14 then
	v_u_37 = require(script:WaitForChild("AvatarAbilitiesInterface"))
	v_u_38 = v_u_37.get(v_u_2.LocalPlayer)
else
	v_u_38 = nil
	v_u_37 = nil
end
local v_u_39 = script.Parent:WaitForChild("InputContexts"):WaitForChild("CameraContext"):WaitForChild("CameraRotationAction")
local _ = Enum.ContextActionPriority.Medium.Value
local v_u_40 = v11.get("VRFirstPersonState")
local v_u_41 = {
	[Enum.TouchMovementMode.DPad] = v_u_29,
	[Enum.DevTouchMovementMode.DPad] = v_u_29,
	[Enum.TouchMovementMode.Thumbpad] = v_u_29,
	[Enum.DevTouchMovementMode.Thumbpad] = v_u_29,
	[Enum.TouchMovementMode.Thumbstick] = v_u_30,
	[Enum.DevTouchMovementMode.Thumbstick] = v_u_30,
	[Enum.TouchMovementMode.DynamicThumbstick] = v_u_29,
	[Enum.DevTouchMovementMode.DynamicThumbstick] = v_u_29,
	[Enum.TouchMovementMode.ClickToMove] = v_u_31,
	[Enum.DevTouchMovementMode.ClickToMove] = v_u_31,
	[Enum.TouchMovementMode.Default] = v_u_29,
	[Enum.ComputerMovementMode.Default] = v_u_26,
	[Enum.ComputerMovementMode.KeyboardMouse] = v_u_26,
	[Enum.DevComputerMovementMode.KeyboardMouse] = v_u_26,
	[Enum.DevComputerMovementMode.Scriptable] = nil,
	[Enum.ComputerMovementMode.ClickToMove] = v_u_31,
	[Enum.DevComputerMovementMode.ClickToMove] = v_u_31
}
function v_u_1.new() -- name: new
	-- upvalues: (copy) v_u_1, (copy) v_u_3, (copy) v_u_2, (copy) v_u_36, (copy) v_u_24, (copy) v_u_8, (copy) v_u_14, (ref) v_u_38, (copy) v_u_5, (copy) v_u_4, (copy) v_u_15, (copy) v_u_10
	local v42 = v_u_1
	local v_u_43 = setmetatable({}, v42)
	if v_u_3:IsServer() then
		return v_u_43
	end
	v_u_43.controllers = {}
	v_u_43.activeControlModule = nil
	v_u_43.activeController = nil
	v_u_43.touchJumpController = nil
	v_u_43.touchAbilitiesController = nil
	v_u_43.abilitiesOverflowController = nil
	v_u_43.abilitiesKeybindBarController = nil
	v_u_43.moveFunction = v_u_2.LocalPlayer.Move
	v_u_43.humanoid = nil
	v_u_43.controlsEnabled = true
	v_u_43.enabled = false
	v_u_43.humanoidSeatedConn = nil
	v_u_43.vehicleController = nil
	v_u_43.touchControlFrame = nil
	v_u_43.abilitiesGui = nil
	v_u_43.abilitiesFrame = nil
	v_u_43.currentTorsoAngle = 0
	v_u_43.inputMoveVector = Vector3.new(0, 0, 0)
	v_u_43.renderedRotationOverride = nil
	v_u_43.vehicleController = v_u_36.new()
	if not v_u_24 then
		v_u_2.LocalPlayer.CharacterAdded:Connect(function(p44)
			-- upvalues: (copy) v_u_43
			v_u_43:OnCharacterAdded(p44)
		end)
		v_u_2.LocalPlayer.CharacterRemoving:Connect(function(p45)
			-- upvalues: (copy) v_u_43
			v_u_43:OnCharacterRemoving(p45)
		end)
		if v_u_2.LocalPlayer.Character then
			v_u_43:OnCharacterAdded(v_u_2.LocalPlayer.Character)
		end
	end
	v_u_8:GetPropertyChangedSignal("TouchMovementMode"):Connect(function()
		-- upvalues: (copy) v_u_43
		v_u_43:UpdateMovementMode()
	end)
	v_u_2.LocalPlayer:GetPropertyChangedSignal("DevTouchMovementMode"):Connect(function()
		-- upvalues: (copy) v_u_43
		v_u_43:UpdateMovementMode()
	end)
	v_u_8:GetPropertyChangedSignal("ComputerMovementMode"):Connect(function()
		-- upvalues: (copy) v_u_43
		v_u_43:UpdateMovementMode()
	end)
	v_u_2.LocalPlayer:GetPropertyChangedSignal("DevComputerMovementMode"):Connect(function()
		-- upvalues: (copy) v_u_43
		v_u_43:UpdateMovementMode()
	end)
	if v_u_14 then
		v_u_38:GetEnabledChangedSignal():Connect(function()
			-- upvalues: (copy) v_u_43
			v_u_43:UpdateAbilitiesControllers()
		end)
	end
	v_u_43.playerGui = nil
	v_u_43.touchGui = nil
	v_u_43.playerGuiAddedConn = nil
	v_u_5:GetPropertyChangedSignal("TouchControlsEnabled"):Connect(function()
		-- upvalues: (copy) v_u_43
		v_u_43:UpdateMovementMode()
		v_u_43:UpdateActiveControlModuleEnabled()
	end)
	v_u_4:GetPropertyChangedSignal("PreferredInput"):Connect(function()
		-- upvalues: (copy) v_u_43
		v_u_43:UpdateMovementMode()
	end)
	v_u_43.playerGui = v_u_2.LocalPlayer:FindFirstChildOfClass("PlayerGui")
	if not v_u_43.playerGui then
		v_u_43.playerGuiAddedConn = v_u_2.LocalPlayer.ChildAdded:Connect(function(p46)
			-- upvalues: (copy) v_u_43, (ref) v_u_14
			if p46:IsA("PlayerGui") then
				v_u_43.playerGui = p46
				v_u_43.playerGuiAddedConn:Disconnect()
				v_u_43.playerGuiAddedConn = nil
				v_u_43:UpdateMovementMode()
				if v_u_14 then
					v_u_43:UpdateAbilitiesControllers()
				end
			end
		end)
	end
	if v_u_15 then
		v_u_10:BindActivate(Enum.UserInputType.Gamepad1, Enum.KeyCode.ButtonR2)
	end
	return v_u_43
end
local function v_u_53(p47) -- name: _fireCustomInputs
	-- upvalues: (copy) v_u_25, (copy) v_u_8
	local v48 = not v_u_25
	assert(v48)
	local v49 = p47:FindFirstChild("InputContexts")
	if v49 == nil then
		return
	else
		local v50 = v49:FindFirstChild("CharacterContext")
		if v50 ~= nil then
			local v51 = v50:FindFirstChild("RotationAction")
			local v52 = v51 and v51:FindFirstChild("RotationScriptableBinding")
			if v52 then
				v52:Fire(v_u_8.RotationType == Enum.RotationType.CameraRelative)
			end
		end
	end
end
function v_u_1.restoreSimulatedRotation(p54) -- name: restoreSimulatedRotation
	local v55 = p54.renderedRotationOverride
	if v55 ~= nil then
		if v55.rootPart.Parent ~= nil then
			v55.rootPart.CFrame = CFrame.new(v55.rootPart.CFrame.Position) * v55.simulatedRotation
		end
		p54.renderedRotationOverride = nil
	end
end
function v_u_1.applyRenderedRotation(p56) -- name: applyRenderedRotation
	-- upvalues: (copy) v_u_6
	local v57 = v_u_6.CurrentCamera
	local v58 = p56.humanoid
	local v59
	if v58 then
		v59 = v58.RootPart
	else
		v59 = v58
	end
	if v57 == nil or (v59 == nil or (v58.Sit or (v58.SeatPart ~= nil or (v59:IsGrounded() or v58:GetState() == Enum.HumanoidStateType.Swimming)))) then
		return
	else
		local v60 = v57.CFrame.LookVector
		local v61 = v60.X
		local v62 = v60.Z
		local v63 = Vector3.new(v61, 0, v62)
		if v63.Magnitude >= 0.001 then
			if p56.renderedRotationOverride ~= nil and p56.renderedRotationOverride.rootPart ~= v59 then
				p56:restoreSimulatedRotation()
			end
			if p56.renderedRotationOverride == nil then
				p56.renderedRotationOverride = {
					["rootPart"] = v59,
					["simulatedRotation"] = v59.CFrame.Rotation
				}
			end
			local v64 = v59.CFrame.Position
			v59.CFrame = CFrame.lookAt(v64, v64 + v63)
		end
	end
end
local function v_u_67(p65) -- name: _cloneInputs
	-- upvalues: (copy) v_u_7
	local v66 = v_u_7.PlayerModule.InputContexts:Clone()
	v66.CharacterContext.Enabled = true
	v66.CameraContext.Enabled = true
	v66.Parent = p65
end
function v_u_1.InitializeServerAuthority(p_u_68) -- name: InitializeServerAuthority
	-- upvalues: (copy) v_u_3, (copy) v_u_14, (copy) v_u_2, (copy) v_u_27, (copy) v_u_7, (copy) v_u_67, (copy) v_u_16, (copy) v_u_17, (ref) v_u_37, (copy) v_u_22, (copy) v_u_23, (copy) v_u_25, (copy) v_u_53, (copy) v_u_8, (ref) v_u_38
	if v_u_3:IsServer() then
		if v_u_14 then
			for _, v69 in v_u_2:GetPlayers() do
				v_u_27.CloneInputsIfAbsent(v69)
			end
			v_u_2.PlayerAdded:Connect(v_u_27.CloneInputsIfAbsent)
		else
			for _, v70 in v_u_2:GetPlayers() do
				local v71 = v_u_7.PlayerModule.InputContexts:Clone()
				v71.CharacterContext.Enabled = true
				v71.CameraContext.Enabled = true
				v71.Parent = v70
			end
			v_u_2.PlayerAdded:Connect(v_u_67)
		end
		if v_u_16 then
			for _, v72 in v_u_2:GetPlayers() do
				v_u_27.createPlayerControlState(v72)
			end
			v_u_2.PlayerAdded:Connect(v_u_27.createPlayerControlState)
		end
		if v_u_14 and v_u_17 then
			for _, v73 in v_u_2:GetPlayers() do
				v_u_37.get(v73)
			end
			v_u_2.PlayerAdded:Connect(function(p74)
				-- upvalues: (ref) v_u_37
				v_u_37.get(p74)
			end)
		end
		if v_u_22 then
			v_u_3:BindToAnimation(function(p75)
				-- upvalues: (ref) v_u_2, (copy) p_u_68
				for _, v76 in v_u_2:GetPlayers() do
					p_u_68:ProcessInputs(v76, p75)
				end
			end, Enum.StepFrequency.Hz60)
		else
			v_u_3:BindToSimulation(function(p77)
				-- upvalues: (ref) v_u_2, (copy) p_u_68
				for _, v78 in v_u_2:GetPlayers() do
					p_u_68:ProcessInputs(v78, p77)
				end
			end, Enum.StepFrequency.Hz60)
		end
	else
		if v_u_16 then
			v_u_27.watchForPlayerControlState(v_u_2.LocalPlayer)
		end
		if v_u_23 then
			v_u_3.PreAnimation:Connect(function()
				-- upvalues: (copy) p_u_68
				p_u_68:restoreSimulatedRotation()
			end)
		end
		v_u_3:BindToRenderStep("CameraInput", Enum.RenderPriority.Last.Value, function()
			-- upvalues: (ref) v_u_25, (ref) v_u_16, (ref) v_u_27, (ref) v_u_2, (copy) p_u_68, (ref) v_u_14, (ref) v_u_53, (ref) v_u_23, (ref) v_u_8, (ref) v_u_38
			if not v_u_25 then
				if v_u_16 then
					v_u_27.writeInputToCS(v_u_2.LocalPlayer, p_u_68)
				elseif v_u_14 then
					v_u_27.FireCustomInputs(v_u_2.LocalPlayer)
				else
					v_u_53(v_u_2.LocalPlayer)
				end
			end
			if v_u_23 and (v_u_8.RotationType == Enum.RotationType.CameraRelative and not (v_u_14 and v_u_38:isEnabled())) then
				p_u_68:applyRenderedRotation()
			end
		end)
		if v_u_22 then
			v_u_3:BindToAnimation(function(p79)
				-- upvalues: (copy) p_u_68, (ref) v_u_2
				p_u_68:ProcessInputs(v_u_2.LocalPlayer, p79)
			end, Enum.StepFrequency.Hz60)
		else
			v_u_3:BindToSimulation(function(p80)
				-- upvalues: (copy) p_u_68, (ref) v_u_2
				p_u_68:ProcessInputs(v_u_2.LocalPlayer, p80)
			end, Enum.StepFrequency.Hz60)
		end
	end
	if p_u_68.data and p_u_68.data.eventBus then
		p_u_68.data.isServerAuthority = true
		p_u_68.data.eventBus:publish("SERVER_AUTHORITY_CHANGED", true)
	end
end
function v_u_1.GetEstimatedVRTorsoFrame(p81) -- name: GetEstimatedVRTorsoFrame
	-- upvalues: (copy) v_u_9
	local v82 = v_u_9:GetUserCFrame(Enum.UserCFrame.Head)
	local _, v83, _ = v82:ToEulerAnglesYXZ()
	local v84 = -v83
	if v_u_9:GetUserCFrameEnabled(Enum.UserCFrame.RightHand) and v_u_9:GetUserCFrameEnabled(Enum.UserCFrame.LeftHand) then
		local v85 = v_u_9:GetUserCFrame(Enum.UserCFrame.LeftHand)
		local v86 = v_u_9:GetUserCFrame(Enum.UserCFrame.RightHand)
		local v87 = v82.Position - v85.Position
		local v88 = v82.Position - v86.Position
		local v89 = v87.X
		local v90 = v87.Z
		local v91 = -math.atan2(v89, v90)
		local v92 = v88.X
		local v93 = v88.Z
		local v94 = (-math.atan2(v92, v93) - v91 + 12.566370614359172) % 6.283185307179586
		if v94 > 3.141592653589793 then
			v94 = v94 - 6.283185307179586
		end
		local v95 = (v91 + v94 / 2 + 12.566370614359172) % 6.283185307179586
		if v95 > 3.141592653589793 then
			v95 = v95 - 6.283185307179586
		end
		local v96 = (v84 - p81.currentTorsoAngle + 12.566370614359172) % 6.283185307179586
		if v96 > 3.141592653589793 then
			v96 = v96 - 6.283185307179586
		end
		local v97 = (v95 - p81.currentTorsoAngle + 12.566370614359172) % 6.283185307179586
		if v97 > 3.141592653589793 then
			v97 = v97 - 6.283185307179586
		end
		local v98
		if v97 > -1.5707963267948966 then
			v98 = v97 < 1.5707963267948966
		else
			v98 = false
		end
		if not v98 then
			v97 = v96
		end
		local v99 = math.min(v97, v96)
		local v100 = math.max(v97, v96)
		local v101 = 0
		if v99 > 0 then
			v100 = v99
		elseif v100 >= 0 then
			v100 = v101
		end
		p81.currentTorsoAngle = v100 + p81.currentTorsoAngle
	else
		p81.currentTorsoAngle = v84
	end
	return CFrame.new(v82.Position) * CFrame.fromEulerAnglesYXZ(0, -p81.currentTorsoAngle, 0)
end
function v_u_1.GetActiveController(p102) -- name: GetActiveController
	return p102.activeController
end
function v_u_1.UpdateAbilitiesControllers(p103) -- name: UpdateAbilitiesControllers
	-- upvalues: (copy) v_u_4, (copy) v_u_31, (copy) v_u_30, (ref) v_u_29, (ref) v_u_38, (copy) v_u_32, (copy) v_u_33, (copy) v_u_20, (copy) v_u_21, (copy) v_u_34, (copy) v_u_35
	local v104 = p103.enabled and p103.touchControlFrame
	if v104 then
		if v_u_4.PreferredInput == Enum.PreferredInput.Touch then
			v104 = (p103.activeControlModule == v_u_31 or p103.activeControlModule == v_u_30) and true or p103.activeControlModule == v_u_29
		else
			v104 = false
		end
	end
	local v105
	if v104 then
		v105 = not v_u_38:isEnabled()
	else
		v105 = v104
	end
	if v104 then
		v104 = v_u_38:isEnabled()
	end
	if v105 then
		if not p103.controllers[v_u_32] then
			p103.controllers[v_u_32] = v_u_32.new(p103.data)
		end
		p103.touchJumpController = p103.controllers[v_u_32]
		p103.touchJumpController:Enable(true, p103.touchControlFrame)
	elseif p103.touchJumpController then
		if v104 then
			p103.touchJumpController:Destroy()
			p103.controllers[v_u_32] = nil
			p103.touchJumpController = nil
		else
			p103.touchJumpController:Enable(false)
		end
	end
	if v104 then
		if not p103.controllers[v_u_33] then
			p103.controllers[v_u_33] = v_u_33.new(p103.touchControlFrame)
		end
		p103.touchAbilitiesController = p103.controllers[v_u_33]
		p103.touchAbilitiesController:Enable(true)
	elseif p103.touchAbilitiesController then
		if v105 then
			p103.touchAbilitiesController:Destroy()
			p103.controllers[v_u_33] = nil
			p103.touchAbilitiesController = nil
		else
			p103.touchAbilitiesController:Enable(false)
		end
	end
	local v106 = p103.enabled and (v_u_20 and v_u_21)
	if v106 then
		v106 = v_u_38:isEnabled()
	end
	if v106 then
		if not p103.abilitiesGui then
			p103:CreateAbilitiesGuiContainer()
		end
		if p103.abilitiesGui then
			if not p103.controllers[v_u_34] then
				p103.controllers[v_u_34] = v_u_34.new(p103.abilitiesFrame)
			end
			p103.abilitiesOverflowController = p103.controllers[v_u_34]
			p103.abilitiesOverflowController:Enable(true)
			if v_u_35 then
				if not p103.controllers[v_u_35] then
					p103.controllers[v_u_35] = v_u_35.new(p103.abilitiesGui)
				end
				p103.abilitiesKeybindBarController = p103.controllers[v_u_35]
				p103.abilitiesKeybindBarController:Enable(true)
			end
			p103.abilitiesGui.Enabled = true
			return
		end
	else
		if p103.abilitiesOverflowController then
			p103.abilitiesOverflowController:Enable(false)
		end
		if p103.abilitiesKeybindBarController then
			p103.abilitiesKeybindBarController:Enable(false)
		end
		if p103.abilitiesGui then
			p103.abilitiesGui.Enabled = false
		end
	end
end
function v_u_1.UpdateActiveControlModuleEnabled(p_u_107) -- name: UpdateActiveControlModuleEnabled
	-- upvalues: (copy) v_u_14, (ref) v_u_38, (copy) v_u_2, (copy) v_u_4, (copy) v_u_31, (copy) v_u_30, (ref) v_u_29, (copy) v_u_32, (copy) v_u_5
	local function v108()
		-- upvalues: (ref) v_u_14, (copy) p_u_107, (ref) v_u_38, (ref) v_u_2
		if v_u_14 then
			p_u_107.enabled = false
		end
		p_u_107.activeController:Enable(false)
		if v_u_14 then
			p_u_107:UpdateAbilitiesControllers()
		elseif p_u_107.touchJumpController then
			p_u_107.touchJumpController:Enable(false)
		end
		if p_u_107.moveFunction and not (v_u_14 and v_u_38:isEnabled()) then
			p_u_107.moveFunction(v_u_2.LocalPlayer, Vector3.new(0, 0, 0), true)
		end
	end
	local function v109()
		-- upvalues: (ref) v_u_14, (copy) p_u_107, (ref) v_u_4, (ref) v_u_31, (ref) v_u_30, (ref) v_u_29, (ref) v_u_32, (ref) v_u_2
		if v_u_14 then
			p_u_107.enabled = true
			p_u_107:UpdateAbilitiesControllers()
		elseif p_u_107.touchControlFrame and (v_u_4.PreferredInput == Enum.PreferredInput.Touch and (p_u_107.activeControlModule == v_u_31 or (p_u_107.activeControlModule == v_u_30 or p_u_107.activeControlModule == v_u_29))) then
			if not p_u_107.controllers[v_u_32] then
				p_u_107.controllers[v_u_32] = v_u_32.new(p_u_107.data)
			end
			p_u_107.touchJumpController = p_u_107.controllers[v_u_32]
			p_u_107.touchJumpController:Enable(true, p_u_107.touchControlFrame)
		elseif p_u_107.touchJumpController then
			p_u_107.touchJumpController:Enable(false)
		end
		if p_u_107.activeControlModule == v_u_31 then
			p_u_107.activeController:Enable(true, v_u_2.LocalPlayer.DevComputerMovementMode == Enum.DevComputerMovementMode.UserChoice, p_u_107.touchJumpController)
			return
		elseif p_u_107.touchControlFrame then
			p_u_107.activeController:Enable(true, p_u_107.touchControlFrame)
		else
			p_u_107.activeController:Enable(true)
		end
	end
	if p_u_107.activeController then
		if p_u_107.controlsEnabled then
			if v_u_5.TouchControlsEnabled or (v_u_4.PreferredInput ~= Enum.PreferredInput.Touch or p_u_107.activeControlModule ~= v_u_31 and (p_u_107.activeControlModule ~= v_u_30 and p_u_107.activeControlModule ~= v_u_29)) then
				v109()
			else
				v108()
			end
		else
			v108()
			return
		end
	else
		return
	end
end
function v_u_1.Enable(p110, p111) -- name: Enable
	-- upvalues: (copy) v_u_25
	if v_u_25 then
		warn("ControlModule:Enable() and ControlModule:Disable() are deprecated and will be removed soon; set require(\"@rbx/PlayerModule\").ControlModule.Enabled instead")
		return
	else
		local v112 = p111 == nil and true or p111
		if p110.controlsEnabled == v112 then
			return
		else
			p110.controlsEnabled = v112
			if p110.activeController then
				p110:UpdateActiveControlModuleEnabled()
			end
		end
	end
end
function v_u_1.Disable(p113) -- name: Disable
	p113:Enable(false)
end
function v_u_1.SelectComputerMovementModule(_) -- name: SelectComputerMovementModule
	-- upvalues: (copy) v_u_19, (copy) v_u_4, (copy) v_u_26, (copy) v_u_2, (copy) v_u_8, (copy) v_u_31, (copy) v_u_41
	local v_u_114 = false
	if v_u_19 then
		local function v115()
			-- upvalues: (ref) v_u_114, (ref) v_u_4
			v_u_114 = v_u_4.PreferredInput == Enum.PreferredInput.MicroGamepad
		end
		pcall(v115)
	end
	if v_u_4.PreferredInput == Enum.PreferredInput.KeyboardAndMouse or (v_u_4.PreferredInput == Enum.PreferredInput.Gamepad or v_u_114) then
		local v116 = v_u_26
		local v117 = v_u_2.LocalPlayer.DevComputerMovementMode
		if v117 == Enum.DevComputerMovementMode.UserChoice then
			if v_u_8.ComputerMovementMode == Enum.ComputerMovementMode.ClickToMove then
				v116 = v_u_31
			end
		else
			v116 = v_u_41[v117]
			if not v116 and v117 ~= Enum.DevComputerMovementMode.Scriptable then
				warn("No character control module is associated with DevComputerMovementMode ", v117)
			end
		end
		if v116 then
			return v116, true
		elseif v117 == Enum.DevComputerMovementMode.Scriptable then
			return nil, true
		else
			return nil, false
		end
	else
		return nil, false
	end
end
function v_u_1.SelectTouchModule(_) -- name: SelectTouchModule
	-- upvalues: (copy) v_u_2, (copy) v_u_41, (copy) v_u_8
	local v118 = v_u_2.LocalPlayer.DevTouchMovementMode
	local v119
	if v118 == Enum.DevTouchMovementMode.UserChoice then
		v119 = v_u_41[v_u_8.TouchMovementMode]
	else
		if v118 == Enum.DevTouchMovementMode.Scriptable then
			return nil, true
		end
		v119 = v_u_41[v118]
	end
	return v119, true
end
function v_u_1.calculateRawMoveVector(p120, p121, p122) -- name: calculateRawMoveVector
	-- upvalues: (copy) v_u_6, (copy) v_u_9, (copy) v_u_39
	local v123 = v_u_6.CurrentCamera
	if not v123 then
		return p122
	end
	local v124 = v123.CFrame
	if v_u_9.VREnabled and p121.RootPart then
		local v125 = p120:GetEstimatedVRTorsoFrame()
		if (v123.Focus.Position - v124.Position).Magnitude < 3 then
			v124 = v124 * v125
		else
			v124 = v123.CFrame * (v125.Rotation + v125.Position * v123.HeadScale)
		end
	end
	if p121:GetState() ~= Enum.HumanoidStateType.Swimming then
		local _, _, _, v130, v127, v128, _, _, v129, _, _, v130 = v124:GetComponents()
		if v129 >= 1 or v129 <= -1 then
			v128 = -v127 * math.sign(v129)
		end
		local v131 = v130 * v130 + v128 * v128
		local v132 = math.sqrt(v131)
		local v133 = (v130 * p122.X + v128 * p122.Z) / v132
		local v134 = (v130 * p122.Z - v128 * p122.X) / v132
		return Vector3.new(v133, 0, v134)
	end
	if not v_u_9.VREnabled then
		return v124:VectorToWorldSpace(p122)
	end
	local v135 = p122.X
	local v136 = p122.Z
	local v137 = Vector3.new(v135, 0, v136)
	if v137.Magnitude < 0.01 then
		return Vector3.new(0, 0, 0)
	end
	local v138 = not (v_u_39 and v_u_39.Enabled) and 0 or -v_u_39:GetState().Y / 2.31
	local v139 = -v137.X
	local v140 = -v137.Z
	local v141 = math.atan2(v139, v140)
	local _, v142, _ = v124:ToEulerAnglesYXZ()
	local v143 = v141 + v142
	return CFrame.fromEulerAnglesYXZ(v138, v143, 0).LookVector
end
function v_u_1.initialize(p144, p145) -- name: initialize
	-- upvalues: (copy) v_u_24, (copy) v_u_26, (copy) v_u_14, (copy) v_u_28
	p144.data = p145
	p144:UpdateMovementMode()
	if not v_u_24 then
		v_u_26.initializeActions(p144.data)
	end
	if v_u_14 then
		v_u_28.setupSlotActions(p144.data.engineInterface.player, p144.data.isServerAuthority, p144.data.eventBus)
	end
end
function v_u_1.Update(p146, p147, p148) -- name: Update
	-- upvalues: (copy) v_u_24, (copy) v_u_25, (copy) v_u_26, (copy) v_u_9
	local v149 = p147.engineInterface.player
	assert(v149)
	local v150 = p147.controlModule
	local v151 = p147.playerModule.ControlModule
	local v152 = p147.engineInterface
	if v_u_24 then
		local v153 = v152.humanoid
		if v152.characterChanged then
			p146:OnCharacterChanged(v153)
		end
		if not (v_u_25 or v153) then
			return
		end
	else
		local v154 = v152.character
		assert(v154)
		if not (v_u_25 or p146.humanoid) then
			return
		end
	end
	local v155 = v151.Enabled
	if v_u_25 then
		v150.enabled = v155
		if v155 == p146.controlsEnabled then
			if not v155 then
				return
			end
		else
			p146.controlsEnabled = v155
			p146:UpdateActiveControlModuleEnabled()
		end
	end
	if v155 then
		if v_u_25 and not p146.humanoid then
			return
		else
			v_u_26.initializeActions(p147)
			if not v_u_25 or v150.actions.MoveAction and v150.actions.JumpAction then
				if p146.activeController and (p146.activeController.enabled and p146.humanoid) then
					v_u_26.update(p147)
					p146:GetClickToMoveController():Update(p147, p148)
					local v156 = v150.moveVector.X
					local v157 = -v150.moveVector.Y
					local v158 = Vector3.new(v156, 0, v157)
					if p146.vehicleController then
						local v159
						v158, v159 = p146.vehicleController:Update(v158, true)
						_ = v159
					end
					local v160 = p146:calculateRawMoveVector(p146.humanoid, v158)
					p146.inputMoveVector = v160
					if v_u_9.VREnabled then
						v160 = p146:updateVRMoveVector(v160)
					end
					v150.worldMoveVector = v160
					p146:characterMove(p147)
				end
			end
		end
	else
		v150.isJumping = false
		v150.moveVector = Vector2.new()
		v150.worldMoveVector = Vector3.new()
		v_u_26.update(p147)
		p146.inputMoveVector = Vector3.new()
		if p146.vehicleController then
			p146.vehicleController:Update(Vector3.new(), true)
		end
		p146:characterMove(p147)
		return
	end
end
function v_u_1.characterMove(p161, p162) -- name: characterMove
	-- upvalues: (copy) v_u_25, (copy) v_u_16, (copy) v_u_14, (ref) v_u_38, (copy) v_u_27, (copy) v_u_2, (copy) v_u_18
	if not v_u_25 or p161.humanoid then
		local v163 = p162.controlModule
		if v_u_16 then
			if not p162.isServerAuthority then
				if not (v_u_14 and v_u_38:isEnabled()) then
					p161.moveFunction(v_u_2.LocalPlayer, v163.worldMoveVector, false)
					p161.humanoid.Jump = v163.isJumping
					return
				end
				if not v_u_25 then
					v_u_27.writeInputToCS(v_u_2.LocalPlayer, p161)
					return
				end
			end
		elseif not (v_u_18 and p162.isServerAuthority or v_u_14 and v_u_38:isEnabled()) then
			p161.moveFunction(v_u_2.LocalPlayer, v163.worldMoveVector, false)
			p161.humanoid.Jump = v163.isJumping
		end
	end
end
function v_u_1.updateVRMoveVector(p164, p165) -- name: updateVRMoveVector
	-- upvalues: (copy) v_u_13, (copy) v_u_40, (copy) v_u_9
	local v166 = workspace.CurrentCamera
	local v167 = v166.Focus.Position - v166.CFrame.Position
	local v168
	if v_u_13 then
		v168 = v_u_40.inFirstPerson
	else
		v168 = v167.Magnitude < 5
	end
	if p165.Magnitude ~= 0 or (not v168 or (not v_u_9.AvatarGestures or (not p164.humanoid or p164.humanoid.Sit))) then
		return p165
	end
	local v169 = v_u_9:GetUserCFrame(Enum.UserCFrame.Head)
	local v170 = v169.Rotation + v169.Position * v166.HeadScale
	local v171 = -0.7 * p164.humanoid.RootPart.Size.Y / 2
	local v172 = (v166.CFrame * v170 * CFrame.new(0, v171, 0)).Position - p164.humanoid.RootPart.CFrame.Position
	local v173 = v172.x
	local v174 = v172.z
	local v175 = Vector3.new(v173, 0, v174)
	if v_u_13 then
		local v176 = (v166.Focus.Position - v166.CFrame.Position).Magnitude
		local v177 = 4 * v166.HeadScale
		if math.max(v177, 1) < v176 then
			return p165
		end
	end
	return v175
end
function v_u_1.OnHumanoidSeated(p178, p179, p180) -- name: OnHumanoidSeated
	if p179 then
		if p180 and p180:IsA("VehicleSeat") then
			if not p178.vehicleController then
				p178.vehicleController = p178.vehicleController.new()
			end
			p178.vehicleController:Enable(true, p180)
			return
		end
	elseif p178.vehicleController then
		p178.vehicleController:Enable(false, p180)
	end
end
if v_u_24 then
	function v_u_1.OnCharacterChanged(p_u_181, p182) -- name: OnCharacterChanged
		p_u_181.humanoid = p182
		p_u_181:UpdateMovementMode()
		if p182 then
			if p_u_181.humanoidSeatedConn then
				p_u_181.humanoidSeatedConn:Disconnect()
				p_u_181.humanoidSeatedConn = nil
			end
			p_u_181.humanoidSeatedConn = p182.Seated:Connect(function(p183, p184)
				-- upvalues: (copy) p_u_181
				p_u_181:OnHumanoidSeated(p183, p184)
			end)
		end
	end
else
	function v_u_1.OnCharacterAdded(p_u_185, p186) -- name: OnCharacterAdded
		p_u_185.humanoid = p186:FindFirstChildOfClass("Humanoid")
		while not p_u_185.humanoid do
			p186.ChildAdded:wait()
			p_u_185.humanoid = p186:FindFirstChildOfClass("Humanoid")
		end
		if p_u_185.humanoidSeatedConn then
			p_u_185.humanoidSeatedConn:Disconnect()
			p_u_185.humanoidSeatedConn = nil
		end
		p_u_185.humanoidSeatedConn = p_u_185.humanoid.Seated:Connect(function(p187, p188)
			-- upvalues: (copy) p_u_185
			p_u_185:OnHumanoidSeated(p187, p188)
		end)
		p_u_185:UpdateMovementMode()
	end
	function v_u_1.OnCharacterRemoving(p189, _) -- name: OnCharacterRemoving
		p189.humanoid = nil
		p189:UpdateMovementMode()
	end
end
function v_u_1.UpdateTouchGuiVisibility(p190) -- name: UpdateTouchGuiVisibility
	-- upvalues: (copy) v_u_5, (copy) v_u_4
	local v191 = p190.humanoid and v_u_5.TouchControlsEnabled
	if v191 then
		v191 = v_u_4.PreferredInput == Enum.PreferredInput.Touch
	end
	if v191 and not p190.touchGui then
		p190:CreateTouchGuiContainer()
	end
	if p190.touchGui then
		p190.touchGui.Enabled = v191 and true or false
	end
end
function v_u_1.SwitchToController(p192, p193) -- name: SwitchToController
	if p193 then
		if not p192.controllers[p193] then
			p192.controllers[p193] = p193.new(p192.data)
		end
		if p192.activeController ~= p192.controllers[p193] then
			if p192.activeController then
				p192.activeController:Enable(false)
			end
			p192.activeController = p192.controllers[p193]
			p192.activeControlModule = p193
			p192:UpdateActiveControlModuleEnabled()
		end
	else
		if p192.activeController then
			p192.activeController:Enable(false)
		end
		p192.activeController = nil
		p192.activeControlModule = nil
	end
end
function v_u_1.UpdateMovementMode(p194) -- name: UpdateMovementMode
	-- upvalues: (copy) v_u_4
	p194:UpdateTouchGuiVisibility()
	if v_u_4.PreferredInput == Enum.PreferredInput.Touch then
		local v195, v196 = p194:SelectTouchModule()
		if v196 and p194.touchControlFrame then
			p194:SwitchToController(v195)
			return
		end
	else
		p194:SwitchToController((p194:SelectComputerMovementModule()))
	end
end
function v_u_1.CreateTouchGuiContainer(p197) -- name: CreateTouchGuiContainer
	-- upvalues: (copy) v_u_14, (copy) v_u_21
	if p197.playerGui then
		if p197.touchGui then
			p197.touchGui:Destroy()
		end
		p197.touchGui = Instance.new("ScreenGui")
		p197.touchGui.Name = "TouchGui"
		p197.touchGui.ResetOnSpawn = false
		p197.touchGui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
		if v_u_14 and v_u_21 then
			p197.touchGui.ScreenInsets = Enum.ScreenInsets.DeviceSafeInsets
		end
		p197.touchGui.ClipToDeviceSafeArea = false
		p197.touchControlFrame = Instance.new("Frame")
		p197.touchControlFrame.Name = "TouchControlFrame"
		p197.touchControlFrame.Size = UDim2.new(1, 0, 1, 0)
		p197.touchControlFrame.BackgroundTransparency = 1
		p197.touchControlFrame.Parent = p197.touchGui
		p197.touchGui.Parent = p197.playerGui
	end
end
function v_u_1.CreateAbilitiesGuiContainer(p198) -- name: CreateAbilitiesGuiContainer
	if p198.playerGui then
		if p198.abilitiesGui then
			p198.abilitiesGui:Destroy()
		end
		p198.abilitiesGui = Instance.new("ScreenGui")
		p198.abilitiesGui.Name = "AbilitiesGui"
		p198.abilitiesGui.ResetOnSpawn = false
		p198.abilitiesGui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
		p198.abilitiesGui.ScreenInsets = Enum.ScreenInsets.DeviceSafeInsets
		p198.abilitiesGui.ClipToDeviceSafeArea = false
		p198.abilitiesFrame = Instance.new("Frame")
		p198.abilitiesFrame.Name = "AbilitiesFrame"
		p198.abilitiesFrame.Size = UDim2.new(1, 0, 1, 0)
		p198.abilitiesFrame.BackgroundTransparency = 1
		p198.abilitiesFrame.Parent = p198.abilitiesGui
		p198.abilitiesGui.Parent = p198.playerGui
	end
end
function v_u_1.GetClickToMoveController(p199) -- name: GetClickToMoveController
	-- upvalues: (copy) v_u_31
	if not p199.controllers[v_u_31] then
		p199.controllers[v_u_31] = v_u_31.new()
	end
	return p199.controllers[v_u_31]
end
function v_u_1.ProcessInputs(_, p200, _) -- name: ProcessInputs
	-- upvalues: (copy) v_u_14, (ref) v_u_37, (copy) v_u_16, (copy) v_u_27
	if v_u_14 then
		if not v_u_37.get(p200):isEnabled() then
			if v_u_16 then
				v_u_27.processPCSInputs(p200)
			else
				v_u_27.SendInputToHumanoidForServerAuth(p200)
			end
		end
	else
		if v_u_16 then
			v_u_27.processPCSInputs(p200)
			return
		end
		local v201 = p200.Character
		if v201 == nil then
			return
		end
		local v202 = v201:FindFirstChild("Humanoid")
		if v202 == nil then
			return
		end
		local v203 = p200:FindFirstChild("InputContexts")
		if v203 == nil then
			return
		end
		local v204 = v203:FindFirstChild("CharacterContext")
		if v204 == nil then
			return
		end
		local v205 = v204.MoveAction
		local v206 = v204.RotationAction
		local v207 = v204.JumpAction
		local v208
		if v205 == nil then
			v208 = Vector2.new(0, 0)
		else
			v208 = v205:GetState()
		end
		local v209 = p200:GetCameraState().CFrame.LookVector
		if v208.X == v208.X and (v208.Y == v208.Y and v208.X ~= (1 / 0)) and v208.Y ~= (1 / 0) and (v209.X == v209.X and (v209.Y == v209.Y and (v209.Z == v209.Z and (v209.X ~= (1 / 0) and v209.Y ~= (1 / 0)))) and v209.Z ~= (1 / 0) and v209.Magnitude > 0) then
			if v202:GetState() ~= Enum.HumanoidStateType.Swimming then
				local v210 = v209.X
				local v211 = v209.Z
				v209 = Vector3.new(v210, 0, v211).Unit
			end
			local v212 = v209:Cross(Vector3.new(0, 1, 0)).Unit
			v202:Move(v209 * v208.Y + v212 * v208.X)
			if v206:GetState() then
				v202.AutoRotate = false
				if v202.SeatPart == nil and (v202.RootPart ~= nil and not (v202.Sit or v202.RootPart:IsGrounded())) then
					v202.RootPart.CFrame = CFrame.new(v202.RootPart.CFrame.Position, v202.RootPart.CFrame.Position + v209)
				end
			else
				v202.AutoRotate = true
			end
		end
		local v213
		if v207 == nil then
			v213 = false
		else
			v213 = v207:GetState()
		end
		v202.Jump = v213
	end
end
if v_u_3:IsClient() then
	return v_u_1.new()
else
	return v_u_1
end