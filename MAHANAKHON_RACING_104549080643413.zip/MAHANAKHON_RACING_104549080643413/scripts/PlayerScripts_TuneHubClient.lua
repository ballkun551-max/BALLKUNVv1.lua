-- Path: Players/ygggggg55551/PlayerScripts/TuneHubClient
-- Class: LocalScript  true/Enum.RunContext.Legacy
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = require(game:GetService("ReplicatedStorage"):WaitForChild("UiOwn")).Instance
local v_u_2 = require(game:GetService("ReplicatedStorage"):WaitForChild("NetSeal"))
local v_u_3 = game:GetService("Players")
local v4 = game:GetService("ReplicatedStorage")
local v_u_5 = game:GetService("RunService")
local v_u_6 = game:GetService("UserInputService")
local v_u_7 = require(game:GetService("ReplicatedStorage"):WaitForChild("PartsShared"))
local v_u_8 = require(v4:WaitForChild("GameShared"))
local v_u_9 = require(v4:WaitForChild("GameUI"):WaitForChild("Toast"))
local v_u_10 = require(v4:WaitForChild("GameUI"):WaitForChild("Skin"))
local v_u_11 = require(v4:WaitForChild("GameUI"):WaitForChild("Theme"))
local v_u_12 = require(v4:WaitForChild("GameUI"):WaitForChild("EcuPanel"))
local v_u_13 = v_u_3.LocalPlayer
local v_u_14 = v4:WaitForChild(v_u_8.REMOTES):WaitForChild("TuneUpgrade")
local v_u_15 = v4:WaitForChild(v_u_8.REMOTES):WaitForChild("TuneShop")
local v_u_16 = {
	2.478367537831948,
	3.8048177693476384,
	0.6632251157578453,
	-0.6632251157578453,
	0
}
local v_u_17 = {
	["TuneHub"] = true,
	["PCX160Paint"] = true,
	["CarTune"] = true,
	["VehicleHint"] = true,
	["GameToast"] = true,
	["StoreWindow"] = true,
	["EcuTune"] = true
}
local v_u_18 = game:GetService("GuiService")
local v_u_19 = require(v4:WaitForChild("GameUI"):WaitForChild("Icons"))
local v_u_20 = v_u_10.PANEL
local v_u_21 = v_u_10.IDLE
local v_u_22 = v_u_10.SELECTED
local v23 = v_u_11.ACCENT
local v_u_24 = Color3.fromRGB(238, 240, 245)
local v_u_25 = Color3.fromRGB(150, 154, 168)
local v_u_26 = Color3.fromRGB(110, 114, 128)
local v_u_27 = Color3.fromRGB(255, 150, 150)
local v_u_28 = {
	{
		["id"] = "Paint",
		["label"] = "Paint",
		["icon"] = "brush"
	},
	{
		["id"] = "Other",
		["label"] = "Other",
		["icon"] = "bulb"
	},
	{
		["id"] = "Parts",
		["label"] = "\224\184\173\224\184\176\224\185\132\224\184\171\224\184\165\224\185\136",
		["icon"] = "settings"
	},
	{
		["id"] = "Engine",
		["label"] = "Engine",
		["icon"] = "zap"
	},
	{
		["id"] = "Brake",
		["label"] = "Brakes",
		["icon"] = "shield"
	},
	{
		["id"] = "ECU",
		["label"] = "ECU Tune",
		["icon"] = "gauge"
	}
}
local v_u_29 = {
	["ExhaustSound"] = true,
	["EngineSound"] = true
}
local function v_u_32(p30) -- name: partsHere
	-- upvalues: (copy) v_u_7, (copy) v_u_29
	for v31 in v_u_7.fitted(p30:GetAttribute("VehicleId") or p30.Name) or {} do
		if v_u_29[v31] then
			continue
		end
		return true
	end
	return false
end
local v_u_33 = {
	["Paint"] = {
		["bike"] = "Body  Shocks  Wheels  Carbon",
		["car"] = "Body color  Gloss / Matte"
	},
	["Other"] = {
		["bike"] = "DRL lights  Lowering  Glass  \224\185\132\224\184\159\224\185\128\224\184\165\224\184\181\224\185\137\224\184\162\224\184\167",
		["car"] = "Lights  Carbon  Exhaust  Tint  Lowering"
	},
	["ECU"] = {
		["bike"] = "Find the recipe: up to x2 power",
		["car"] = "Find the recipe: up to x2 power"
	},
	["Parts"] = {
		["bike"] = "\224\184\165\224\185\137\224\184\173  \224\184\151\224\185\136\224\184\173  \224\185\130\224\184\138\224\185\138\224\184\132  \224\184\171\224\184\161\224\185\137\224\184\173\224\184\153\224\185\137\224\184\179  \224\185\128\224\184\154\224\184\178\224\184\176",
		["car"] = ""
	}
}
local v_u_34 = {
	["Engine"] = "Engine Upgrades",
	["Brake"] = "Brake Upgrades"
}
local v_u_35 = Vector2.new(540, 436)
local v_u_36 = Vector2.new(250, 58)
local v_u_37 = {
	{
		["id"] = "Engine",
		["label"] = "Engine",
		["color"] = nil,
		["color"] = Color3.fromRGB(96, 232, 150)
	},
	{
		["id"] = "Brake",
		["label"] = "Brakes",
		["color"] = nil,
		["color"] = Color3.fromRGB(255, 140, 60)
	},
	{
		["id"] = "Ecu",
		["label"] = "ECU",
		["color"] = nil,
		["color"] = Color3.fromRGB(176, 120, 255)
	},
	{
		["id"] = "Lower",
		["label"] = "Lowering",
		["color"] = nil,
		["color"] = Color3.fromRGB(70, 210, 255)
	},
	{
		["id"] = "Top",
		["label"] = "Top speed",
		["color"] = nil,
		["color"] = v_u_11.ACCENT
	}
}
local v_u_38 = Font.new("rbxasset://fonts/families/Oswald.json", Enum.FontWeight.Bold)
local v_u_39 = nil
local v_u_40 = nil
local v_u_41 = nil
local v_u_42 = nil
local v_u_43 = nil
local v_u_44 = nil
local v_u_45 = nil
local v_u_46 = nil
local v_u_47 = nil
local v_u_48 = {}
local v_u_49 = {}
local v_u_50 = {}
local v_u_51 = nil
local v_u_52 = nil
local v_u_53 = nil
local v_u_54 = nil
local v_u_55 = nil
local v_u_56 = {}
local v_u_57 = require(v4:WaitForChild("GameUI"):WaitForChild("TuneDock"))
local v_u_58 = nil
local function v_u_65(p59, p60, p61) -- name: text
	-- upvalues: (copy) v_u_1
	local v62 = v_u_1.new(p59)
	v62.BackgroundTransparency = 1
	v62.Font = Enum.Font.GothamBold
	v62.TextColor3 = Color3.new(1, 1, 1)
	v62.TextSize = 18
	v62.TextXAlignment = Enum.TextXAlignment.Left
	for v63, v64 in p60 do
		v62[v63] = v64
	end
	v62.Parent = p61
	return v62
end
local function v_u_73(p66, p67) -- name: effectText
	-- upvalues: (copy) v_u_8
	local v68 = v_u_8.UPGRADES[p66][p67 + 1]
	if p67 == 0 then
		return "Factory stock"
	end
	if p66 ~= "Engine" then
		local v69 = (v68.brake - 1) * 100 + 0.5
		return ("Braking +%d%%"):format((math.floor(v69)))
	end
	local v70 = (v68.accel - 1) * 100 + 0.5
	local v71 = math.floor(v70)
	local v72 = (v68.top - 1) * 100 + 0.5
	return ("Acceleration +%d%%   Top speed +%d%%"):format(v71, (math.floor(v72)))
end
local function v_u_89() -- name: refreshSpecs
	-- upvalues: (ref) v_u_55, (ref) v_u_58, (copy) v_u_37, (copy) v_u_56, (copy) v_u_8
	if v_u_55 and v_u_58 then
		local v74 = v_u_58.model
		for _, v75 in v_u_37 do
			local v76 = v_u_56[v75.id]
			local v77, v78
			if v75.id == "Engine" or v75.id == "Brake" then
				local v79 = v74:GetAttribute(v75.id .. "Level") or 0
				v77 = v79 / 3
				local v80 = v_u_8.UPGRADES[v75.id][v79 + 1]
				if v80 then
					v78 = v80.th
				else
					v78 = tostring(v79)
				end
			elseif v75.id == "Ecu" then
				local v81 = v74:GetAttribute("EcuGain")
				local v82 = type(v81) ~= "number" and 1 or v81
				local v83 = v82 - 1
				v77 = math.clamp(v83, 0, 1)
				v78 = ("x%.2f"):format(v82)
			elseif v75.id == "Lower" then
				local v84 = ((tonumber(v74:GetAttribute("LowerFront")) or 0) + (tonumber(v74:GetAttribute("LowerRear")) or 0)) / 8
				v77 = math.clamp(v84, 0, 1)
				if v77 <= 0 then
					v78 = "Stock"
				else
					local v85 = v77 * 100 + 0.5
					v78 = ("%d%%"):format((math.floor(v85)))
				end
			else
				local v86 = v_u_8.topKmh(v74)
				if v86 then
					local v87 = v86 / 300
					v77 = math.clamp(v87, 0, 1)
				else
					v77 = 0
				end
				if v86 then
					local v88 = v86 + 0.5
					v78 = ("%d km/h"):format((math.floor(v88)))
				else
					v78 = "-"
				end
			end
			v76.Value.Text = v78
			v76.Track.Fill.Size = UDim2.fromScale(math.max(v77, 0.03), 1)
		end
	end
end
local function v_u_99(p90, p91) -- name: litKey
	-- upvalues: (copy) v_u_11, (copy) v_u_25, (copy) v_u_19
	local v92
	if p91 then
		v92 = v_u_11.ACCENT
	else
		v92 = Color3.new(1, 1, 1)
	end
	p90.BackgroundColor3 = v92
	p90.BackgroundTransparency = p91 and 0 or 0.95
	local v93 = p90:FindFirstChild("Edge")
	if v93 then
		v93.Transparency = p91 and 1 or 0.88
	end
	local v94 = p90:FindFirstChild("Label")
	if v94 then
		local v95
		if p91 then
			v95 = v_u_11.DARK_TEXT
		else
			v95 = v_u_25
		end
		v94.TextColor3 = v95
	end
	local v96 = p90:FindFirstChild("Ico")
	if v96 then
		local v97 = v_u_19.tint
		local v98
		if p91 then
			v98 = v_u_11.DARK_TEXT
		else
			v98 = v_u_25
		end
		v97(v96, v98)
	end
	p90:SetAttribute("Lit", p91)
end
local function v_u_110(p100, p101) -- name: tabLit
	-- upvalues: (copy) v_u_11, (copy) v_u_24, (copy) v_u_25, (copy) v_u_19
	local v102
	if p101 then
		v102 = v_u_11.ACCENT
	else
		v102 = Color3.new(1, 1, 1)
	end
	p100.BackgroundColor3 = v102
	p100.BackgroundTransparency = p101 and 0.87 or 1
	local v103 = p100:FindFirstChild("Label", true)
	if v103 then
		local v104
		if p101 then
			v104 = v_u_24
		else
			v104 = v_u_25
		end
		v103.TextColor3 = v104
	end
	local v105 = p100:FindFirstChild("Ico", true)
	if v105 then
		local v106 = v_u_19.tint
		local v107
		if p101 then
			v107 = v_u_11.ACCENT
		else
			v107 = v_u_25
		end
		v106(v105, v107)
	end
	for _, v108 in { "Line", "Halo" } do
		local v109 = p100:FindFirstChild(v108)
		if not v109 then
			continue
		end
		v109.Visible = p101
	end
	p100:SetAttribute("Lit", p101)
end
local function v_u_122() -- name: refreshBar
	-- upvalues: (ref) v_u_39, (ref) v_u_54, (ref) v_u_58, (copy) v_u_8, (copy) v_u_50, (copy) v_u_99, (copy) v_u_24, (copy) v_u_26, (copy) v_u_89
	if v_u_39 and v_u_54 then
		local v111 = v_u_58
		if v111 then
			v111 = v_u_58.model
		end
		local v112
		if v111 == nil then
			v112 = false
		else
			v112 = v111:GetAttribute("TuneBaseline") ~= nil
		end
		local v113, v114
		if v112 then
			v113, v114 = v_u_8.tuneDue(v111)
		else
			v114 = {}
			v113 = 0
		end
		for _, v115 in v_u_50 do
			local v116 = v115.frame
			local v117
			if v111 == nil then
				v117 = false
			else
				v117 = v115.frame:GetAttribute("Shown") == true
			end
			v116.Visible = v117
			v115.due.Text = v_u_8.formatCash(v113)
			v_u_99(v115.confirm, v112)
			v115.undo.Visible = v112
			v115.confirm.Size = UDim2.new(1, not v112 and 0 or -v115.gap, 1, 0)
			if not v115.items then
				continue
			end
			local v118 = v115.items
			local v119
			if #v114 > 0 then
				v119 = table.concat(v114, "\n")
			else
				v119 = v112 and "Nothing new to pay" or "Nothing changed yet"
			end
			v118.Text = v119
			local v120 = v115.items
			local v121
			if #v114 > 0 then
				v121 = v_u_24
			else
				v121 = v_u_26
			end
			v120.TextColor3 = v121
		end
		v_u_89()
	end
end
local v_u_123 = false
local function v_u_131(p124) -- name: settle
	-- upvalues: (ref) v_u_123, (ref) v_u_58, (copy) v_u_2, (copy) v_u_15, (copy) v_u_9, (copy) v_u_122
	if not v_u_123 and v_u_58 then
		v_u_123 = true
		local v125 = v_u_2.invoke
		local v126 = v_u_15
		local v127 = v_u_58.model
		local v128, v129, v130 = pcall(v125, v126, p124, v127)
		v_u_123 = false
		if v128 then
			if v130 then
				v_u_9.show(v130, v129 and "ok" or "error")
			end
		else
			v_u_9.show("Failed", "error")
		end
		task.delay(0.15, v_u_122)
	end
end
local function v_u_137(p132) -- name: subtitleOf
	-- upvalues: (ref) v_u_58, (copy) v_u_8, (copy) v_u_33
	local v133 = v_u_58
	if v133 then
		v133 = v_u_58.model
	end
	if not v133 then
		return ""
	end
	if p132 == "Parts" and v_u_58.hasParts == false then
		return "\224\184\132\224\184\177\224\184\153\224\184\153\224\184\181\224\185\137\224\185\132\224\184\161\224\185\136\224\184\170\224\184\178\224\184\161\224\184\178\224\184\163\224\184\150\224\185\129\224\184\149\224\185\136\224\184\135\224\184\173\224\184\176\224\185\132\224\184\171\224\184\165\224\185\136\224\185\132\224\184\148\224\185\137"
	end
	if p132 == "Engine" or p132 == "Brake" then
		local v134 = v_u_8.UPGRADES[p132][(v133:GetAttribute(p132 .. "Level") or 0) + 1]
		return not v134 and "" or v134.th
	end
	if p132 == "ECU" then
		local v135 = v133:GetAttribute("EcuGain")
		if type(v135) == "number" and v135 > 1.005 then
			return ("x%.2f"):format(v135)
		end
	end
	local v136 = v_u_33[p132]
	return v136 and (v136[v_u_58.kind] or "") or ""
end
local function v_u_159() -- name: refresh
	-- upvalues: (ref) v_u_39, (ref) v_u_58, (copy) v_u_32, (copy) v_u_28, (copy) v_u_48, (copy) v_u_110, (copy) v_u_99, (copy) v_u_137, (ref) v_u_42, (copy) v_u_49, (copy) v_u_8, (copy) v_u_13, (copy) v_u_122, (ref) v_u_44, (ref) v_u_51, (ref) v_u_52, (copy) v_u_34, (ref) v_u_53, (copy) v_u_73, (copy) v_u_11, (copy) v_u_22, (copy) v_u_21
	if v_u_39 and v_u_58 then
		if v_u_58.hasParts == nil then
			v_u_58.hasParts = v_u_32(v_u_58.model)
		end
		for _, v138 in v_u_28 do
			local v139 = not v_u_58.exhaustOnly
			local v140 = v_u_48[v138.id]
			v140.tab.Visible = v139
			v_u_110(v140.tab, v_u_58.tile == v138.id)
			v140.rail.Visible = v139
			v_u_99(v140.rail, v_u_58.tile == v138.id)
			v140.card.Visible = v139
			v140.card.Sub.Text = v_u_137(v138.id)
		end
		local v141 = v_u_42
		if v141 then
			v141 = v_u_42:FindFirstChild("Tabs")
		end
		if v141 then
			v141.Visible = not v_u_58.exhaustOnly
		end
		for _, v142 in v_u_49 do
			v142.Text = v_u_8.formatCash(v_u_13:GetAttribute("Cash") or 0)
		end
		v_u_122()
		local v143 = v_u_58.tile
		local v144 = v_u_44
		local v145
		if v143 == nil then
			v145 = not v_u_58.exhaustOnly
		else
			v145 = false
		end
		v144.Visible = v145
		v_u_51.Visible = v143 == "Engine" and true or v143 == "Brake"
		if v_u_51.Visible then
			v_u_52.Text = v_u_34[v143]
			local v146 = v_u_58
			if v146 then
				v146 = v_u_58.model
			end
			local v147 = v146 and (v146:GetAttribute(v143 .. "Level") or 0) or 0
			for v148, v149 in v_u_53 do
				local v150 = v_u_8.UPGRADES[v143][v148 + 1]
				v149.Name_.Text = v150.th
				v149.Effect.Text = v_u_73(v143, v148)
				local v151 = v149.Buy
				v149.RowEdge.Transparency = v148 == v147 and 0.35 or 1
				local v152 = v149.Stage
				local v153
				if v148 == v147 then
					v153 = v_u_11.ACCENT_LIGHT
				else
					v153 = Color3.new(1, 1, 1)
				end
				v152.BackgroundColor3 = v153
				v149.Stage.BackgroundTransparency = v148 == v147 and 0 or 0.93
				local v154 = v149.Stage.Num
				local v155
				if v148 == v147 then
					v155 = v_u_11.INK
				else
					v155 = v_u_11.ACCENT_LIGHT
				end
				v154.TextColor3 = v155
				if v148 == v147 then
					v151.Text = "Installed"
					v151.BackgroundColor3 = v_u_22
					v149.BackgroundColor3 = v_u_21
				elseif v148 < v147 then
					v151.Text = "Switch back"
					v151.BackgroundColor3 = v_u_21
					v149.BackgroundColor3 = v_u_21
				elseif v_u_58.model and v148 <= v_u_8.upgradeOwned(v_u_58.model, v143) then
					v151.Text = "Owned \194\183 fit"
					v151.BackgroundColor3 = v_u_21
					v149.BackgroundColor3 = v_u_21
				else
					local v156 = "Buy "
					local v157 = v_u_8.formatCash
					local v158 = v_u_58
					if v158 then
						v158 = v_u_58.model
					end
					v151.Text = v156 .. v157(not v158 and 0 or v_u_8.upgradeCost(v158, v143, v148))
					v151.BackgroundColor3 = Color3.fromRGB(32, 140, 70)
					v149.BackgroundColor3 = v_u_21
				end
			end
		end
	else
		return
	end
end
local v_u_160 = false
local function v_u_169(p161) -- name: buy
	-- upvalues: (ref) v_u_160, (ref) v_u_58, (copy) v_u_2, (copy) v_u_14, (copy) v_u_9, (copy) v_u_159
	if not v_u_160 and v_u_58 then
		v_u_160 = true
		local v162 = v_u_2.invoke
		local v163 = v_u_14
		local v164 = v_u_58.tile
		local v165 = v_u_58.model
		local v166, v167, v168 = pcall(v162, v163, v164, v165, p161)
		v_u_160 = false
		if v166 then
			v_u_9.show(v168 or "", v167 and "ok" or "error")
		else
			v_u_9.show("Failed", "error")
		end
		task.delay(0.15, v_u_159)
	end
end
local v_u_170 = nil
local v_u_171 = nil
local function v_u_175(p172, p173, p174) -- name: heading
	-- upvalues: (copy) v_u_65, (copy) v_u_11
	return v_u_65("TextLabel", {
		["Name"] = "Heading",
		["Text"] = nil,
		["FontFace"] = nil,
		["TextSize"] = 13,
		["TextColor3"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Text"] = p172,
		["FontFace"] = v_u_11.FONT_HEAVY,
		["TextColor3"] = v_u_11.ACCENT_LIGHT,
		["Position"] = UDim2.fromOffset(0, p173),
		["Size"] = UDim2.new(1, 0, 0, 16)
	}, p174)
end
local function v_u_182(p176, p177) -- name: rule
	-- upvalues: (copy) v_u_1
	local v178 = {
		["BackgroundTransparency"] = 0.92,
		["BackgroundColor3"] = nil,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = Color3.new(1, 1, 1),
		["AnchorPoint"] = Vector2.new(0, 1),
		["Position"] = UDim2.new(0, 0, 1, -p177),
		["Size"] = UDim2.new(1, 0, 0, 1)
	}
	local v179 = v_u_1.new("Frame")
	v179.Name = "Rule"
	v179.BorderSizePixel = 0
	v179.BackgroundTransparency = 1
	for v180, v181 in v178 do
		v179[v180] = v181
	end
	v179.Parent = p176
	return v179
end
local function v_u_184(p_u_183) -- name: hover
	p_u_183.MouseEnter:Connect(function()
		-- upvalues: (copy) p_u_183
		if not p_u_183:GetAttribute("Lit") then
			p_u_183.BackgroundTransparency = 0.9
		end
	end)
	p_u_183.MouseLeave:Connect(function()
		-- upvalues: (copy) p_u_183
		if not p_u_183:GetAttribute("Lit") then
			p_u_183.BackgroundTransparency = 0.95
		end
	end)
end
local function v_u_235(p_u_185, p186, p187, p188, p189) -- name: categoryKeys
	-- upvalues: (copy) v_u_1, (copy) v_u_25, (copy) v_u_19, (copy) v_u_65, (copy) v_u_11, (copy) v_u_24, (copy) v_u_26, (copy) v_u_184, (ref) v_u_170, (copy) v_u_48
	local v190 = "Cat" .. p_u_185.id
	local v_u_191 = v_u_1.new("TextButton")
	v_u_191.Name = v190
	v_u_191.Text = ""
	v_u_191.AutoButtonColor = false
	v_u_191.BorderSizePixel = 0
	v_u_191:SetAttribute("SkinSkip", true)
	v_u_191.Parent = p187
	v_u_191.LayoutOrder = p186
	v_u_191.AutomaticSize = Enum.AutomaticSize.X
	v_u_191.Size = UDim2.fromOffset(0, 40)
	v_u_191.BackgroundTransparency = 1
	local v192 = v_u_1.new("UICorner")
	v192.CornerRadius = UDim.new(0, 9)
	v192.Parent = v_u_191
	local v193 = {
		["AutomaticSize"] = Enum.AutomaticSize.X,
		["Size"] = UDim2.fromScale(0, 1)
	}
	local v194 = v_u_1.new("Frame")
	v194.Name = "Content"
	v194.BorderSizePixel = 0
	v194.BackgroundTransparency = 1
	for v195, v196 in v193 do
		v194[v195] = v196
	end
	v194.Parent = v_u_191
	local v197 = v_u_1.new("UIPadding")
	v197.PaddingLeft = UDim.new(0, 16)
	v197.PaddingRight = UDim.new(0, 18)
	v197.Parent = v194
	local v198 = v_u_1.new("UIListLayout")
	v198.FillDirection = Enum.FillDirection.Horizontal
	v198.VerticalAlignment = Enum.VerticalAlignment.Center
	v198.SortOrder = Enum.SortOrder.LayoutOrder
	v198.Padding = UDim.new(0, 9)
	v198.Parent = v194
	local v199 = p_u_185.icon
	local v200 = v_u_25
	local v201 = v_u_19.make(v199, v200, 20)
	v201.Name = "Ico"
	v201.Parent = v194
	v201.LayoutOrder = 1
	v_u_65("TextLabel", {
		["Name"] = "Label",
		["Text"] = nil,
		["FontFace"] = nil,
		["TextSize"] = 16,
		["TextColor3"] = nil,
		["AutomaticSize"] = nil,
		["Size"] = nil,
		["LayoutOrder"] = 2,
		["Text"] = p_u_185.label,
		["FontFace"] = v_u_11.FONT_BOLD,
		["TextColor3"] = v_u_25,
		["AutomaticSize"] = Enum.AutomaticSize.X,
		["Size"] = UDim2.fromOffset(0, 40)
	}, v194)
	local v202 = {
		["Visible"] = false,
		["BackgroundTransparency"] = 0,
		["BackgroundColor3"] = nil,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = v_u_11.ACCENT,
		["AnchorPoint"] = Vector2.new(0.5, 1),
		["Position"] = UDim2.new(0.5, 0, 1, 0),
		["Size"] = UDim2.new(1, -10, 0, 18)
	}
	local v203 = v_u_1.new("Frame")
	v203.Name = "Halo"
	v203.BorderSizePixel = 0
	v203.BackgroundTransparency = 1
	for v204, v205 in v202 do
		v203[v204] = v205
	end
	v203.Parent = v_u_191
	local v206 = v_u_1.new("UICorner")
	v206.CornerRadius = UDim.new(0, 9)
	v206.Parent = v203
	local v207 = v_u_1.new("UIGradient")
	v207.Rotation = 90
	v207.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(1, 0.62) })
	v207.Parent = v203
	local v208 = {
		["Visible"] = false,
		["BackgroundTransparency"] = 0,
		["BackgroundColor3"] = nil,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = v_u_11.ACCENT,
		["AnchorPoint"] = Vector2.new(0.5, 1),
		["Position"] = UDim2.new(0.5, 0, 1, 0),
		["Size"] = UDim2.new(1, -26, 0, 3)
	}
	local v209 = v_u_1.new("Frame")
	v209.Name = "Line"
	v209.BorderSizePixel = 0
	v209.BackgroundTransparency = 1
	for v210, v211 in v208 do
		v209[v210] = v211
	end
	v209.Parent = v_u_191
	local v212 = v_u_1.new("UICorner")
	v212.CornerRadius = UDim.new(0, 2)
	v212.Parent = v209
	v_u_191.MouseEnter:Connect(function()
		-- upvalues: (copy) v_u_191
		if not v_u_191:GetAttribute("Lit") then
			v_u_191.BackgroundTransparency = 0.93
		end
	end)
	v_u_191.MouseLeave:Connect(function()
		-- upvalues: (copy) v_u_191
		if not v_u_191:GetAttribute("Lit") then
			v_u_191.BackgroundTransparency = 1
		end
	end)
	local v213 = "Rail" .. p_u_185.id
	local v214 = v_u_1.new("TextButton")
	v214.Name = v213
	v214.Text = ""
	v214.AutoButtonColor = false
	v214.BorderSizePixel = 0
	v214:SetAttribute("SkinSkip", true)
	v214.Parent = p188
	v214.LayoutOrder = p186
	v214.Size = UDim2.new(1, 0, 0, 44)
	local v215 = v_u_1.new("UICorner")
	v215.CornerRadius = UDim.new(0, 12)
	v215.Parent = v214
	local v216 = v_u_1.new("UIStroke")
	v216.Name = "Edge"
	v216.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v216.Color = Color3.new(1, 1, 1)
	v216.Transparency = 0.88
	v216.Parent = v214
	local v217 = p_u_185.icon
	local v218 = v_u_25
	local v219 = v_u_19.make(v217, v218, 20)
	v219.Name = "Ico"
	v219.Parent = v214
	v219.AnchorPoint = Vector2.new(0.5, 0.5)
	v219.Position = UDim2.new(0.5, 0, 0.5, -7)
	v_u_65("TextLabel", {
		["Name"] = "Label",
		["Text"] = nil,
		["FontFace"] = nil,
		["TextSize"] = 11,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["TextTruncate"] = nil,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Text"] = p_u_185.label,
		["FontFace"] = v_u_11.FONT_BOLD,
		["TextColor3"] = v_u_25,
		["TextXAlignment"] = Enum.TextXAlignment.Center,
		["TextTruncate"] = Enum.TextTruncate.AtEnd,
		["AnchorPoint"] = Vector2.new(0, 1),
		["Position"] = UDim2.new(0, 2, 1, -3),
		["Size"] = UDim2.new(1, -4, 0, 13)
	}, v214)
	local v220 = "Card" .. p_u_185.id
	local v_u_221 = v_u_1.new("TextButton")
	v_u_221.Name = v220
	v_u_221.Text = ""
	v_u_221.AutoButtonColor = false
	v_u_221.BorderSizePixel = 0
	v_u_221:SetAttribute("SkinSkip", true)
	v_u_221.Parent = p189
	v_u_221.LayoutOrder = p186
	v_u_221.BackgroundColor3 = Color3.new(1, 1, 1)
	v_u_221.BackgroundTransparency = 0.95
	local v222 = v_u_1.new("UICorner")
	v222.CornerRadius = UDim.new(0, 14)
	v222.Parent = v_u_221
	local v_u_223 = v_u_1.new("UIStroke")
	v_u_223.Name = "Edge"
	v_u_223.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v_u_223.Color = Color3.new(1, 1, 1)
	v_u_223.Transparency = 0.9
	v_u_223.Parent = v_u_221
	local v224 = {
		["BackgroundTransparency"] = 0.84,
		["BackgroundColor3"] = nil,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = v_u_11.ACCENT,
		["AnchorPoint"] = Vector2.new(0, 0.5),
		["Position"] = UDim2.new(0, 16, 0.5, 0),
		["Size"] = UDim2.fromOffset(54, 54)
	}
	local v225 = v_u_1.new("Frame")
	v225.Name = "Tile"
	v225.BorderSizePixel = 0
	v225.BackgroundTransparency = 1
	for v226, v227 in v224 do
		v225[v226] = v227
	end
	v225.Parent = v_u_221
	local v228 = v_u_1.new("UICorner")
	v228.CornerRadius = UDim.new(0, 14)
	v228.Parent = v225
	local v229 = v_u_11.ACCENT
	local v230 = v_u_1.new("UIStroke")
	v230.Name = "Edge"
	v230.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v230.Color = v229 or Color3.new(1, 1, 1)
	v230.Transparency = 0.55
	v230.Parent = v225
	local v231 = p_u_185.icon
	local v232 = v_u_11.ACCENT_LIGHT
	local v233 = v_u_19.make(v231, v232, 28)
	v233.Name = "Ico"
	v233.Parent = v225
	v233.AnchorPoint = Vector2.new(0.5, 0.5)
	v233.Position = UDim2.fromScale(0.5, 0.5)
	v_u_65("TextLabel", {
		["Name"] = "Label",
		["Text"] = nil,
		["FontFace"] = nil,
		["TextSize"] = 19,
		["TextColor3"] = nil,
		["TextTruncate"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Text"] = p_u_185.label,
		["FontFace"] = v_u_11.FONT_TITLE,
		["TextColor3"] = v_u_24,
		["TextTruncate"] = Enum.TextTruncate.AtEnd,
		["Position"] = UDim2.fromOffset(84, 24),
		["Size"] = UDim2.new(1, -112, 0, 24)
	}, v_u_221)
	v_u_65("TextLabel", {
		["Name"] = "Sub",
		["Text"] = "",
		["FontFace"] = nil,
		["TextSize"] = 13,
		["TextColor3"] = nil,
		["TextTruncate"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["FontFace"] = v_u_11.FONT_BOLD,
		["TextColor3"] = v_u_25,
		["TextTruncate"] = Enum.TextTruncate.AtEnd,
		["Position"] = UDim2.fromOffset(84, 51),
		["Size"] = UDim2.new(1, -112, 0, 18)
	}, v_u_221)
	v_u_65("TextLabel", {
		["Name"] = "Go",
		["Text"] = "\226\128\186",
		["FontFace"] = nil,
		["TextSize"] = 30,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["FontFace"] = v_u_11.FONT_HEAVY,
		["TextColor3"] = v_u_26,
		["TextXAlignment"] = Enum.TextXAlignment.Center,
		["AnchorPoint"] = Vector2.new(1, 0.5),
		["Position"] = UDim2.new(1, -8, 0.5, -2),
		["Size"] = UDim2.fromOffset(24, 40)
	}, v_u_221)
	v_u_221.MouseEnter:Connect(function()
		-- upvalues: (copy) v_u_221, (copy) v_u_223, (ref) v_u_11
		v_u_221.BackgroundTransparency = 0.9
		v_u_223.Color = v_u_11.ACCENT
		v_u_223.Transparency = 0.55
	end)
	v_u_221.MouseLeave:Connect(function()
		-- upvalues: (copy) v_u_221, (copy) v_u_223
		v_u_221.BackgroundTransparency = 0.95
		v_u_223.Color = Color3.new(1, 1, 1)
		v_u_223.Transparency = 0.9
	end)
	v_u_184(v214)
	for _, v234 in { v_u_191, v214, v_u_221 } do
		v234.Activated:Connect(function()
			-- upvalues: (ref) v_u_170, (copy) p_u_185
			v_u_170(p_u_185.id)
		end)
	end
	v_u_48[p_u_185.id] = {
		["tab"] = v_u_191,
		["rail"] = v214,
		["card"] = v_u_221
	}
end
local function v_u_250(p236, p237, p238, p239) -- name: confirmKeys
	-- upvalues: (copy) v_u_1, (copy) v_u_65, (copy) v_u_11, (copy) v_u_25, (copy) v_u_131, (copy) v_u_24
	local v240 = {
		["AnchorPoint"] = Vector2.new(0, 1),
		["Position"] = UDim2.fromScale(0, 1),
		["Size"] = UDim2.new(1, 0, 0, p237)
	}
	local v241 = v_u_1.new("Frame")
	v241.Name = "Keys"
	v241.BorderSizePixel = 0
	v241.BackgroundTransparency = 1
	for v242, v243 in v240 do
		v241[v242] = v243
	end
	v241.Parent = p236
	local v_u_244 = v_u_1.new("TextButton")
	v_u_244.Name = "Confirm"
	v_u_244.Text = ""
	v_u_244.AutoButtonColor = false
	v_u_244.BorderSizePixel = 0
	v_u_244:SetAttribute("SkinSkip", true)
	v_u_244.Parent = v241
	v_u_244.Size = UDim2.new(1, -p238, 1, 0)
	local v245 = v_u_1.new("UICorner")
	v245.CornerRadius = UDim.new(0, 12)
	v245.Parent = v_u_244
	local v246 = v_u_1.new("UIStroke")
	v246.Name = "Edge"
	v246.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v246.Color = Color3.new(1, 1, 1)
	v246.Transparency = 0.88
	v246.Parent = v_u_244
	v_u_65("TextLabel", {
		["Name"] = "Label",
		["Text"] = "Confirm",
		["FontFace"] = nil,
		["TextSize"] = nil,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["Size"] = nil,
		["FontFace"] = v_u_11.FONT_HEAVY,
		["TextSize"] = p239,
		["TextColor3"] = v_u_25,
		["TextXAlignment"] = Enum.TextXAlignment.Center,
		["Size"] = UDim2.fromScale(1, 1)
	}, v_u_244)
	v_u_244.Activated:Connect(function()
		-- upvalues: (copy) v_u_244, (ref) v_u_131
		if v_u_244:GetAttribute("Lit") then
			v_u_131("Confirm")
		end
	end)
	local v247 = v_u_1.new("TextButton")
	v247.Name = "Undo"
	v247.Text = ""
	v247.AutoButtonColor = false
	v247.BorderSizePixel = 0
	v247:SetAttribute("SkinSkip", true)
	v247.Parent = v241
	v247.AnchorPoint = Vector2.new(1, 0)
	v247.Position = UDim2.fromScale(1, 0)
	v247.Size = UDim2.new(0, p238 - 10, 1, 0)
	v247.BackgroundColor3 = Color3.new(1, 1, 1)
	v247.BackgroundTransparency = 0.93
	local v248 = v_u_1.new("UICorner")
	v248.CornerRadius = UDim.new(0, 12)
	v248.Parent = v247
	local v249 = v_u_1.new("UIStroke")
	v249.Name = "Edge"
	v249.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v249.Color = Color3.new(1, 1, 1)
	v249.Transparency = 0.85
	v249.Parent = v247
	v_u_65("TextLabel", {
		["Name"] = "Label",
		["Text"] = "Undo",
		["FontFace"] = nil,
		["TextSize"] = nil,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["Size"] = nil,
		["FontFace"] = v_u_11.FONT_BOLD,
		["TextSize"] = p239 - 3,
		["TextColor3"] = v_u_24,
		["TextXAlignment"] = Enum.TextXAlignment.Center,
		["Size"] = UDim2.fromScale(1, 1)
	}, v247)
	v247.Activated:Connect(function()
		-- upvalues: (ref) v_u_131
		v_u_131("Cancel")
	end)
	return v_u_244, v247
end
local function v_u_456() -- name: build
	-- upvalues: (ref) v_u_39, (copy) v_u_1, (copy) v_u_13, (copy) v_u_10, (ref) v_u_40, (ref) v_u_41, (copy) v_u_11, (ref) v_u_42, (copy) v_u_65, (copy) v_u_38, (copy) v_u_24, (copy) v_u_27, (copy) v_u_19, (ref) v_u_171, (copy) v_u_3, (copy) v_u_49, (ref) v_u_43, (copy) v_u_20, (ref) v_u_44, (copy) v_u_35, (copy) v_u_28, (copy) v_u_235, (ref) v_u_51, (copy) v_u_35, (ref) v_u_52, (copy) v_u_21, (ref) v_u_170, (ref) v_u_53, (copy) v_u_25, (ref) v_u_58, (copy) v_u_169, (ref) v_u_54, (copy) v_u_175, (copy) v_u_26, (copy) v_u_182, (ref) v_u_55, (copy) v_u_37, (copy) v_u_56, (copy) v_u_250, (copy) v_u_50, (ref) v_u_45, (ref) v_u_46, (copy) v_u_36, (ref) v_u_47, (copy) v_u_159
	v_u_39 = v_u_1.new("ScreenGui")
	v_u_39.Name = "TuneHub"
	v_u_39.ResetOnSpawn = false
	v_u_39.DisplayOrder = 6
	v_u_39.ScreenInsets = Enum.ScreenInsets.DeviceSafeInsets
	v_u_39.Enabled = false
	v_u_39.Parent = v_u_13:WaitForChild("PlayerGui")
	v_u_10.apply(v_u_39)
	local v251 = {
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v252 = v_u_39
	local v253 = v_u_1.new("Frame")
	v253.Name = "Root"
	v253.BorderSizePixel = 0
	v253.BackgroundTransparency = 1
	for v254, v255 in v251 do
		v253[v254] = v255
	end
	v253.Parent = v252
	v_u_40 = v253
	local v256 = v_u_40
	local v257 = v_u_1.new("Frame")
	v257.Name = "Window"
	v257.BorderSizePixel = 0
	v257.BackgroundTransparency = 1
	for v258, v259 in {} do
		v257[v258] = v259
	end
	v257.Parent = v256
	v_u_41 = v257
	local v260 = v_u_41
	local v261 = v_u_1.new("UICorner")
	v261.CornerRadius = UDim.new(0, 18)
	v261.Parent = v260
	for _, v262 in {
		Vector2.new(0, 0),
		Vector2.new(1, 0),
		Vector2.new(0, 1),
		Vector2.new(1, 1)
	} do
		for _, v263 in { true, false } do
			local v264 = {
				["BackgroundTransparency"] = v262 == Vector2.zero and 0 or 0.4,
				["BackgroundColor3"] = v_u_11.ACCENT,
				["AnchorPoint"] = v262,
				["Position"] = UDim2.fromScale(v262.X, v262.Y)
			}
			local v265
			if v263 then
				v265 = UDim2.fromOffset(30, 3)
			else
				v265 = UDim2.fromOffset(3, 30)
			end
			v264.Size = v265
			local v266 = v_u_41
			local v267 = v_u_1.new("Frame")
			v267.Name = "Corner"
			v267.BorderSizePixel = 0
			v267.BackgroundTransparency = 1
			for v268, v269 in v264 do
				v267[v268] = v269
			end
			v267.Parent = v266
			v267.ZIndex = 2
			local v270 = v_u_1.new("UICorner")
			v270.CornerRadius = UDim.new(0, 2)
			v270.Parent = v267
		end
	end
	local v271 = {
		["BackgroundTransparency"] = 0,
		["BackgroundColor3"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = Color3.fromRGB(8, 9, 12),
		["Size"] = UDim2.new(1, 0, 0, 140)
	}
	local v272 = v_u_41
	local v273 = v_u_1.new("Frame")
	v273.Name = "Shade"
	v273.BorderSizePixel = 0
	v273.BackgroundTransparency = 1
	for v274, v275 in v271 do
		v273[v274] = v275
	end
	v273.Parent = v272
	local v276 = v_u_1.new("UIGradient")
	v276.Rotation = 90
	v276.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.3), NumberSequenceKeypoint.new(0.6, 0.55), NumberSequenceKeypoint.new(1, 1) })
	v276.Parent = v273
	local v277 = {
		["Size"] = UDim2.fromOffset(1000, 106)
	}
	local v278 = v_u_40
	local v279 = v_u_1.new("Frame")
	v279.Name = "Head"
	v279.BorderSizePixel = 0
	v279.BackgroundTransparency = 1
	for v280, v281 in v277 do
		v279[v280] = v281
	end
	v279.Parent = v278
	v_u_42 = v279
	local v282 = v_u_42
	local v283 = v_u_1.new("UIScale")
	v283.Name = "DockScale"
	v283.Parent = v282
	local v284 = {
		["BackgroundTransparency"] = 0,
		["BackgroundColor3"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = v_u_11.ACCENT,
		["Position"] = UDim2.fromOffset(0, 4),
		["Size"] = UDim2.fromOffset(4, 46)
	}
	local v285 = v_u_42
	local v286 = v_u_1.new("Frame")
	v286.Name = "Mark"
	v286.BorderSizePixel = 0
	v286.BackgroundTransparency = 1
	for v287, v288 in v284 do
		v286[v287] = v288
	end
	v286.Parent = v285
	v_u_65("TextLabel", {
		["Name"] = "Sub",
		["Text"] = "M A H A N A K H O N   \194\183   B A N G K O K",
		["FontFace"] = nil,
		["TextSize"] = 12,
		["TextColor3"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["FontFace"] = v_u_11.FONT_BOLD,
		["TextColor3"] = v_u_11.ACCENT,
		["Position"] = UDim2.fromOffset(16, 2),
		["Size"] = UDim2.new(1, -440, 0, 14)
	}, v_u_42)
	v_u_65("TextLabel", {
		["Name"] = "Name",
		["Text"] = "TUNING GARAGE",
		["FontFace"] = nil,
		["TextSize"] = 38,
		["TextColor3"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["FontFace"] = v_u_38,
		["TextColor3"] = v_u_24,
		["Position"] = UDim2.fromOffset(15, 14),
		["Size"] = UDim2.new(1, -440, 0, 40)
	}, v_u_42)
	local v289 = {
		["Position"] = nil,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["BackgroundTransparency"] = 0.3,
		["BackgroundColor3"] = nil,
		["Position"] = UDim2.fromOffset(0, 58),
		["Size"] = UDim2.fromOffset(0, 48),
		["AutomaticSize"] = Enum.AutomaticSize.X,
		["BackgroundColor3"] = Color3.fromRGB(10, 11, 15)
	}
	local v290 = v_u_42
	local v291 = v_u_1.new("Frame")
	v291.Name = "Tabs"
	v291.BorderSizePixel = 0
	v291.BackgroundTransparency = 1
	for v292, v293 in v289 do
		v291[v292] = v293
	end
	v291.Parent = v290
	local v294 = v_u_1.new("UICorner")
	v294.CornerRadius = UDim.new(0, 12)
	v294.Parent = v291
	local v295 = v_u_1.new("UIStroke")
	v295.Name = "Edge"
	v295.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v295.Color = Color3.new(1, 1, 1)
	v295.Transparency = 0.9
	v295.Parent = v291
	local v296 = v_u_1.new("UIPadding")
	for _, v297 in {
		"PaddingTop",
		"PaddingBottom",
		"PaddingLeft",
		"PaddingRight"
	} do
		v296[v297] = UDim.new(0, 4)
	end
	v296.Parent = v291
	local v298 = v_u_1.new("UIListLayout")
	v298.FillDirection = Enum.FillDirection.Horizontal
	v298.VerticalAlignment = Enum.VerticalAlignment.Center
	v298.SortOrder = Enum.SortOrder.LayoutOrder
	v298.Padding = UDim.new(0, 2)
	v298.Parent = v291
	local v299 = v_u_42
	local v_u_300 = v_u_1.new("TextButton")
	v_u_300.Name = "Exit"
	v_u_300.Text = ""
	v_u_300.AutoButtonColor = false
	v_u_300.BorderSizePixel = 0
	v_u_300:SetAttribute("SkinSkip", true)
	v_u_300.Parent = v299
	v_u_300.AnchorPoint = Vector2.new(1, 0)
	v_u_300.Position = UDim2.new(1, 0, 0, 2)
	v_u_300.Size = UDim2.fromOffset(104, 42)
	v_u_300.BackgroundColor3 = v_u_11.RED
	v_u_300.BackgroundTransparency = 0.82
	local v301 = v_u_1.new("UICorner")
	v301.CornerRadius = UDim.new(0, 11)
	v301.Parent = v_u_300
	local v302 = v_u_11.RED
	local v303 = v_u_1.new("UIStroke")
	v303.Name = "Edge"
	v303.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v303.Color = v302 or Color3.new(1, 1, 1)
	v303.Transparency = 0.45
	v303.Parent = v_u_300
	local v304 = v_u_27
	local v305 = v_u_19.make("exit", v304, 18)
	v305.Name = "Ico"
	v305.Parent = v_u_300
	v305.AnchorPoint = Vector2.new(0, 0.5)
	v305.Position = UDim2.new(0, 15, 0.5, 0)
	v_u_65("TextLabel", {
		["Name"] = "Label",
		["Text"] = "Exit",
		["FontFace"] = nil,
		["TextSize"] = 16,
		["TextColor3"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["FontFace"] = v_u_11.FONT_BOLD,
		["TextColor3"] = v_u_27,
		["Position"] = UDim2.fromOffset(42, 0),
		["Size"] = UDim2.new(1, -48, 1, 0)
	}, v_u_300)
	v_u_300.MouseEnter:Connect(function()
		-- upvalues: (copy) v_u_300
		v_u_300.BackgroundTransparency = 0.7
	end)
	v_u_300.MouseLeave:Connect(function()
		-- upvalues: (copy) v_u_300
		v_u_300.BackgroundTransparency = 0.82
	end)
	v_u_300.Activated:Connect(function()
		-- upvalues: (ref) v_u_171
		v_u_171()
	end)
	local v306 = {
		["AnchorPoint"] = Vector2.new(1, 0),
		["Position"] = UDim2.new(1, -120, 0, 0),
		["Size"] = UDim2.fromOffset(260, 46)
	}
	local v307 = v_u_42
	local v308 = v_u_1.new("Frame")
	v308.Name = "Player"
	v308.BorderSizePixel = 0
	v308.BackgroundTransparency = 1
	for v309, v310 in v306 do
		v308[v309] = v310
	end
	v308.Parent = v307
	local v_u_311 = v_u_1.new("ImageLabel")
	v_u_311.Name = "Avatar"
	v_u_311.BackgroundColor3 = Color3.fromRGB(30, 31, 40)
	v_u_311.AnchorPoint = Vector2.new(1, 0.5)
	v_u_311.Position = UDim2.new(1, 0, 0.5, 0)
	v_u_311.Size = UDim2.fromOffset(42, 42)
	v_u_311.Parent = v308
	local v312 = v_u_1.new("UICorner")
	v312.CornerRadius = UDim.new(0, 21)
	v312.Parent = v_u_311
	local v313 = v_u_11.ACCENT
	local v314 = v_u_1.new("UIStroke")
	v314.Name = "Edge"
	v314.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v314.Color = v313 or Color3.new(1, 1, 1)
	v314.Transparency = 0.2
	v314.Parent = v_u_311
	v314.Thickness = 2
	task.spawn(function()
		-- upvalues: (ref) v_u_3, (ref) v_u_13, (copy) v_u_311
		local v315 = v_u_3.GetUserThumbnailAsync
		local v316 = v_u_3
		local v317 = v_u_13.UserId
		local v318 = Enum.ThumbnailType.HeadShot
		local v319 = Enum.ThumbnailSize.Size100x100
		local v320, v321 = pcall(v315, v316, v317, v318, v319)
		if v320 then
			v_u_311.Image = v321
		end
	end)
	v_u_65("TextLabel", {
		["Name"] = "Name",
		["Text"] = nil,
		["FontFace"] = nil,
		["TextSize"] = 15,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["TextTruncate"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Text"] = v_u_13.DisplayName,
		["FontFace"] = v_u_11.FONT_BOLD,
		["TextColor3"] = v_u_24,
		["TextXAlignment"] = Enum.TextXAlignment.Right,
		["TextTruncate"] = Enum.TextTruncate.AtEnd,
		["Position"] = UDim2.fromOffset(0, 3),
		["Size"] = UDim2.new(1, -54, 0, 20)
	}, v308)
	local v322 = v_u_49
	local v323 = v_u_65("TextLabel", {
		["Name"] = "Cash",
		["Text"] = "",
		["FontFace"] = nil,
		["TextSize"] = 16,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["TextTruncate"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["FontFace"] = v_u_11.FONT_DISPLAY,
		["TextColor3"] = v_u_11.GOLD,
		["TextXAlignment"] = Enum.TextXAlignment.Right,
		["TextTruncate"] = Enum.TextTruncate.AtEnd,
		["Position"] = UDim2.fromOffset(0, 23),
		["Size"] = UDim2.new(1, -54, 0, 20)
	}, v308)
	table.insert(v322, v323)
	local v324 = {
		["Visible"] = false,
		["BackgroundTransparency"] = 0.1,
		["BackgroundColor3"] = nil,
		["BackgroundColor3"] = v_u_20
	}
	local v325 = v_u_40
	local v326 = v_u_1.new("Frame")
	v326.Name = "Rail"
	v326.BorderSizePixel = 0
	v326.BackgroundTransparency = 1
	for v327, v328 in v324 do
		v326[v327] = v328
	end
	v326.Parent = v325
	v_u_43 = v326
	v_u_10.glass(v_u_43)
	local v329 = v_u_1.new("UIPadding")
	for _, v330 in {
		"PaddingTop",
		"PaddingBottom",
		"PaddingLeft",
		"PaddingRight"
	} do
		v329[v330] = UDim.new(0, 4)
	end
	v329.Parent = v_u_43
	local v331 = v_u_1.new("UIListLayout")
	v331.SortOrder = Enum.SortOrder.LayoutOrder
	v331.Padding = UDim.new(0, 4)
	v331.Parent = v_u_43
	local v332 = {
		["BackgroundTransparency"] = 0.1,
		["BackgroundColor3"] = nil,
		["Size"] = nil,
		["Visible"] = false,
		["BackgroundColor3"] = v_u_20,
		["Size"] = UDim2.fromOffset(v_u_35.X, v_u_35.Y)
	}
	local v333 = v_u_40
	local v334 = v_u_1.new("Frame")
	v334.Name = "Choose"
	v334.BorderSizePixel = 0
	v334.BackgroundTransparency = 1
	for v335, v336 in v332 do
		v334[v335] = v336
	end
	v334.Parent = v333
	v_u_44 = v334
	v_u_10.glass(v_u_44)
	local v337 = v_u_44
	local v338 = v_u_1.new("UIScale")
	v338.Name = "DockScale"
	v338.Parent = v337
	v_u_65("TextLabel", {
		["Name"] = "Kicker",
		["Text"] = nil,
		["FontFace"] = nil,
		["TextSize"] = 11,
		["TextColor3"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Text"] = ("TUNING"):gsub(".", "%0\226\128\137"):gsub("\226\128\137$", ""),
		["FontFace"] = v_u_11.FONT_HEAVY,
		["TextColor3"] = v_u_11.ACCENT_LIGHT,
		["Position"] = UDim2.fromOffset(22, 18),
		["Size"] = UDim2.fromOffset(200, 12)
	}, v_u_44)
	v_u_65("TextLabel", {
		["Name"] = "Title",
		["Text"] = "Choose what to tune",
		["FontFace"] = nil,
		["TextSize"] = 22,
		["TextColor3"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["FontFace"] = v_u_11.FONT_DISPLAY,
		["TextColor3"] = v_u_24,
		["Position"] = UDim2.fromOffset(22, 32),
		["Size"] = UDim2.new(1, -44, 0, 28)
	}, v_u_44)
	local v339 = {
		["BackgroundTransparency"] = 0.92,
		["BackgroundColor3"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = Color3.new(1, 1, 1),
		["Position"] = UDim2.fromOffset(20, 74),
		["Size"] = UDim2.new(1, -40, 0, 1)
	}
	local v340 = v_u_44
	local v341 = v_u_1.new("Frame")
	v341.Name = "Rule"
	v341.BorderSizePixel = 0
	v341.BackgroundTransparency = 1
	for v342, v343 in v339 do
		v341[v342] = v343
	end
	v341.Parent = v340
	local v344 = {
		["Position"] = UDim2.fromOffset(20, 90),
		["Size"] = UDim2.new(1, -40, 1, -104)
	}
	local v345 = v_u_44
	local v346 = v_u_1.new("Frame")
	v346.Name = "Grid"
	v346.BorderSizePixel = 0
	v346.BackgroundTransparency = 1
	for v347, v348 in v344 do
		v346[v347] = v348
	end
	v346.Parent = v345
	local v349 = v_u_1.new("UIGridLayout")
	v349.CellSize = UDim2.fromOffset(242, 100)
	v349.CellPadding = UDim2.fromOffset(16, 12)
	v349.SortOrder = Enum.SortOrder.LayoutOrder
	v349.Parent = v346
	for v350, v351 in v_u_28 do
		v_u_235(v351, v350, v291, v_u_43, v346)
	end
	local v352 = {
		["BackgroundTransparency"] = 0.1,
		["BackgroundColor3"] = nil,
		["Size"] = nil,
		["Visible"] = false,
		["BackgroundColor3"] = v_u_20,
		["Size"] = UDim2.fromOffset(v_u_35.X, v_u_35.Y)
	}
	local v353 = v_u_40
	local v354 = v_u_1.new("Frame")
	v354.Name = "Upgrades"
	v354.BorderSizePixel = 0
	v354.BackgroundTransparency = 1
	for v355, v356 in v352 do
		v354[v355] = v356
	end
	v354.Parent = v353
	v_u_51 = v354
	v_u_10.glass(v_u_51)
	local v357 = v_u_51
	local v358 = v_u_1.new("UIScale")
	v358.Name = "DockScale"
	v358.Parent = v357
	v_u_65("TextLabel", {
		["Name"] = "Kicker",
		["Text"] = nil,
		["FontFace"] = nil,
		["TextSize"] = 11,
		["TextColor3"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Text"] = ("UPGRADE"):gsub(".", "%0\226\128\137"):gsub("\226\128\137$", ""),
		["FontFace"] = v_u_11.FONT_HEAVY,
		["TextColor3"] = v_u_11.ACCENT_LIGHT,
		["Position"] = UDim2.fromOffset(20, 10),
		["Size"] = UDim2.fromOffset(200, 12)
	}, v_u_51)
	v_u_52 = v_u_65("TextLabel", {
		["Name"] = "Title",
		["Font"] = nil,
		["TextSize"] = 21,
		["Position"] = nil,
		["Size"] = nil,
		["Font"] = Enum.Font.GothamBlack,
		["Position"] = UDim2.fromOffset(20, 18),
		["Size"] = UDim2.new(1, -100, 0, 28)
	}, v_u_51)
	local v359 = v_u_1.new("Frame")
	v359.Name = "TitleBar"
	v359.BorderSizePixel = 0
	v359.BackgroundColor3 = v_u_11.ACCENT
	v359.Position = UDim2.fromOffset(20, 46)
	v359.Size = UDim2.fromOffset(34, 3)
	v359.Parent = v_u_51
	local v360 = v_u_1.new("UICorner")
	v360.CornerRadius = UDim.new(0, 2)
	v360.Parent = v359
	local v361 = v_u_1.new("TextButton")
	v361.Name = "Close"
	v361.Text = "Close"
	v361.Font = Enum.Font.GothamBold
	v361.TextSize = 18
	v361.TextColor3 = Color3.new(1, 1, 1)
	v361.BackgroundColor3 = v_u_21
	v361.Position = UDim2.new(1, -72, 0, 8)
	v361.Size = UDim2.fromOffset(60, 40)
	v361.Parent = v_u_51
	local v362 = v_u_1.new("UICorner")
	v362.CornerRadius = UDim.new(0, 10)
	v362.Parent = v361
	v361.Activated:Connect(function()
		-- upvalues: (ref) v_u_170
		v_u_170(nil)
	end)
	v_u_53 = {}
	for v_u_363 = 0, 3 do
		local v364 = v_u_1.new("Frame")
		v364.Name = "Level" .. v_u_363
		v364.Position = UDim2.fromOffset(14, v_u_363 * 88 + 64)
		v364.Size = UDim2.new(1, -28, 0, 80)
		v364.BackgroundColor3 = v_u_21
		v364.BackgroundTransparency = 0.25
		v364.Parent = v_u_51
		local v365 = v_u_1.new("UICorner")
		v365.CornerRadius = UDim.new(0, 12)
		v365.Parent = v364
		local v366 = v_u_1.new("UIStroke")
		v366.Name = "RowEdge"
		v366.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
		v366.Color = v_u_11.ACCENT
		v366.Thickness = 1.5
		v366.Transparency = 1
		v366.Parent = v364
		local v367 = v_u_1.new("Frame")
		v367.Name = "Stage"
		v367.BackgroundColor3 = Color3.new(1, 1, 1)
		v367.BackgroundTransparency = 0.93
		v367.AnchorPoint = Vector2.new(0, 0.5)
		v367.Position = UDim2.new(0, 14, 0.5, 0)
		v367.Size = UDim2.fromOffset(46, 46)
		v367.Parent = v364
		local v368 = v_u_1.new("UICorner")
		v368.CornerRadius = UDim.new(0, 10)
		v368.Parent = v367
		v_u_65("TextLabel", {
			["Name"] = "Num",
			["Text"] = nil,
			["FontFace"] = nil,
			["TextSize"] = 22,
			["TextColor3"] = nil,
			["TextXAlignment"] = nil,
			["Size"] = nil,
			["Text"] = tostring(v_u_363),
			["FontFace"] = v_u_11.FONT_DISPLAY,
			["TextColor3"] = v_u_11.ACCENT_LIGHT,
			["TextXAlignment"] = Enum.TextXAlignment.Center,
			["Size"] = UDim2.fromScale(1, 1)
		}, v367)
		v_u_65("TextLabel", {
			["Name"] = "Name_",
			["Font"] = nil,
			["TextSize"] = 19,
			["Position"] = nil,
			["Size"] = nil,
			["Font"] = Enum.Font.GothamBlack,
			["Position"] = UDim2.fromOffset(74, 12),
			["Size"] = UDim2.new(1, -236, 0, 26)
		}, v364)
		v_u_65("TextLabel", {
			["Name"] = "Effect",
			["TextSize"] = 13,
			["TextColor3"] = nil,
			["TextWrapped"] = true,
			["TextYAlignment"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["TextColor3"] = v_u_25,
			["TextYAlignment"] = Enum.TextYAlignment.Top,
			["Position"] = UDim2.fromOffset(74, 40),
			["Size"] = UDim2.new(1, -236, 0, 34)
		}, v364)
		local v369 = v_u_1.new("TextButton")
		v369.Name = "Buy"
		v369.Font = Enum.Font.GothamBold
		v369.TextSize = 16
		v369.TextColor3 = Color3.new(1, 1, 1)
		v369.AnchorPoint = Vector2.new(1, 0.5)
		v369.Position = UDim2.new(1, -10, 0.5, 0)
		v369.Size = UDim2.fromOffset(146, 48)
		v369.Parent = v364
		local v370 = v_u_1.new("UICorner")
		v370.CornerRadius = UDim.new(0, 10)
		v370.Parent = v369
		v369.Activated:Connect(function()
			-- upvalues: (ref) v_u_58, (copy) v_u_363, (ref) v_u_169
			local v371 = v_u_58 and v_u_58.tile or ""
			local v372 = v_u_58
			if v372 then
				v372 = v_u_58.model
			end
			if (v372 and v372:GetAttribute(v371 .. "Level") or 0) ~= v_u_363 then
				v_u_169(v_u_363)
			end
		end)
		v_u_53[v_u_363] = v364
	end
	local v373 = {
		["BackgroundTransparency"] = 0.1,
		["BackgroundColor3"] = nil,
		["Size"] = nil,
		["Visible"] = false,
		["BackgroundColor3"] = v_u_20,
		["Size"] = UDim2.fromOffset(300, 560)
	}
	local v374 = v_u_40
	local v375 = v_u_1.new("Frame")
	v375.Name = "Column"
	v375.BorderSizePixel = 0
	v375.BackgroundTransparency = 1
	for v376, v377 in v373 do
		v375[v376] = v377
	end
	v375.Parent = v374
	v_u_54 = v375
	v_u_10.glass(v_u_54)
	local v378 = v_u_54
	local v379 = v_u_1.new("UIScale")
	v379.Name = "DockScale"
	v379.Parent = v378
	local v380 = {
		["Position"] = UDim2.fromOffset(20, 18),
		["Size"] = UDim2.new(1, -40, 1, -36)
	}
	local v381 = v_u_54
	local v382 = v_u_1.new("Frame")
	v382.Name = "Inner"
	v382.BorderSizePixel = 0
	v382.BackgroundTransparency = 1
	for v383, v384 in v380 do
		v382[v383] = v384
	end
	v382.Parent = v381
	v_u_175("Changes", 0, v382)
	local v385 = v_u_65("TextLabel", {
		["Name"] = "Items",
		["Text"] = "",
		["FontFace"] = nil,
		["TextSize"] = 14,
		["TextColor3"] = nil,
		["TextWrapped"] = true,
		["TextYAlignment"] = nil,
		["TextTruncate"] = nil,
		["ClipsDescendants"] = true,
		["LineHeight"] = 1.15,
		["Position"] = nil,
		["Size"] = nil,
		["FontFace"] = v_u_11.FONT_BOLD,
		["TextColor3"] = v_u_26,
		["TextYAlignment"] = Enum.TextYAlignment.Top,
		["TextTruncate"] = Enum.TextTruncate.AtEnd,
		["Position"] = UDim2.fromOffset(0, 24),
		["Size"] = UDim2.new(1, 0, 1, -392)
	}, v382)
	local v386 = {
		["AnchorPoint"] = Vector2.new(0, 1),
		["Position"] = UDim2.new(0, 0, 1, -294),
		["Size"] = UDim2.new(1, 0, 0, 62)
	}
	local v387 = v_u_1.new("Frame")
	v387.Name = "Total"
	v387.BorderSizePixel = 0
	v387.BackgroundTransparency = 1
	for v388, v389 in v386 do
		v387[v388] = v389
	end
	v387.Parent = v382
	v_u_175("Total price", 0, v387)
	local v390 = v_u_65("TextLabel", {
		["Name"] = "Due",
		["Text"] = "",
		["FontFace"] = nil,
		["TextSize"] = 36,
		["TextColor3"] = nil,
		["TextTruncate"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["FontFace"] = v_u_11.FONT_DISPLAY,
		["TextColor3"] = v_u_24,
		["TextTruncate"] = Enum.TextTruncate.AtEnd,
		["Position"] = UDim2.fromOffset(0, 18),
		["Size"] = UDim2.new(1, 0, 0, 42)
	}, v387)
	v_u_182(v382, 280)
	local v391 = {
		["AnchorPoint"] = Vector2.new(0, 1),
		["Position"] = UDim2.new(0, 0, 1, -84),
		["Size"] = UDim2.new(1, 0, 0, 182)
	}
	local v392 = v_u_1.new("Frame")
	v392.Name = "Specs"
	v392.BorderSizePixel = 0
	v392.BackgroundTransparency = 1
	for v393, v394 in v391 do
		v392[v393] = v394
	end
	v392.Parent = v382
	v_u_55 = v392
	v_u_175("Vehicle specs", 0, v_u_55)
	for v395, v396 in v_u_37 do
		local v397 = "Spec" .. v396.id
		local v398 = {
			["Position"] = UDim2.fromOffset(0, 24 + (v395 - 1) * 32),
			["Size"] = UDim2.new(1, 0, 0, 28)
		}
		local v399 = v_u_55
		local v400 = v_u_1.new("Frame")
		v400.Name = v397
		v400.BorderSizePixel = 0
		v400.BackgroundTransparency = 1
		for v401, v402 in v398 do
			v400[v401] = v402
		end
		v400.Parent = v399
		v_u_65("TextLabel", {
			["Name"] = "Label",
			["Text"] = nil,
			["FontFace"] = nil,
			["TextSize"] = 13,
			["TextColor3"] = nil,
			["Size"] = nil,
			["Text"] = v396.label,
			["FontFace"] = v_u_11.FONT_BOLD,
			["TextColor3"] = Color3.fromRGB(214, 216, 224),
			["Size"] = UDim2.new(0.55, 0, 0, 16)
		}, v400)
		v_u_65("TextLabel", {
			["Name"] = "Value",
			["Text"] = "",
			["FontFace"] = nil,
			["TextSize"] = 13,
			["TextColor3"] = nil,
			["TextXAlignment"] = nil,
			["TextTruncate"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["FontFace"] = v_u_11.FONT_BOLD,
			["TextColor3"] = v_u_25,
			["TextXAlignment"] = Enum.TextXAlignment.Right,
			["TextTruncate"] = Enum.TextTruncate.AtEnd,
			["Position"] = UDim2.fromScale(0.35, 0),
			["Size"] = UDim2.new(0.65, 0, 0, 16)
		}, v400)
		local v403 = {
			["BackgroundTransparency"] = 0.9,
			["BackgroundColor3"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = Color3.new(1, 1, 1),
			["Position"] = UDim2.fromOffset(0, 20),
			["Size"] = UDim2.new(1, 0, 0, 4)
		}
		local v404 = v_u_1.new("Frame")
		v404.Name = "Track"
		v404.BorderSizePixel = 0
		v404.BackgroundTransparency = 1
		for v405, v406 in v403 do
			v404[v405] = v406
		end
		v404.Parent = v400
		local v407 = v_u_1.new("UICorner")
		v407.CornerRadius = UDim.new(0, 2)
		v407.Parent = v404
		local v408 = {
			["BackgroundTransparency"] = 0,
			["BackgroundColor3"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = v396.color,
			["Size"] = UDim2.fromScale(0.03, 1)
		}
		local v409 = v_u_1.new("Frame")
		v409.Name = "Fill"
		v409.BorderSizePixel = 0
		v409.BackgroundTransparency = 1
		for v410, v411 in v408 do
			v409[v410] = v411
		end
		v409.Parent = v404
		local v412 = v_u_1.new("UICorner")
		v412.CornerRadius = UDim.new(0, 2)
		v412.Parent = v409
		v_u_56[v396.id] = v400
	end
	v_u_182(v382, 68)
	local v413, v414 = v_u_250(v382, 52, 96, 19)
	local v415 = v_u_50
	local v416 = {
		["frame"] = nil,
		["due"] = nil,
		["items"] = nil,
		["confirm"] = nil,
		["undo"] = nil,
		["gap"] = 96,
		["frame"] = v_u_54,
		["due"] = v390,
		["items"] = v385,
		["confirm"] = v413,
		["undo"] = v414
	}
	table.insert(v415, v416)
	v_u_45 = v_u_65("TextLabel", {
		["Name"] = "Hint",
		["Text"] = "Drag to turn the view",
		["FontFace"] = nil,
		["TextSize"] = 13,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["AnchorPoint"] = nil,
		["Size"] = nil,
		["FontFace"] = v_u_11.FONT_BOLD,
		["TextColor3"] = v_u_26,
		["TextXAlignment"] = Enum.TextXAlignment.Center,
		["AnchorPoint"] = Vector2.new(0.5, 1),
		["Size"] = UDim2.fromOffset(320, 18)
	}, v_u_40)
	local v417 = {
		["BackgroundTransparency"] = 0.1,
		["BackgroundColor3"] = nil,
		["Size"] = nil,
		["Visible"] = false,
		["BackgroundColor3"] = v_u_20,
		["Size"] = UDim2.fromOffset(v_u_36.X, v_u_36.Y)
	}
	local v418 = v_u_40
	local v419 = v_u_1.new("Frame")
	v419.Name = "PhoneBar"
	v419.BorderSizePixel = 0
	v419.BackgroundTransparency = 1
	for v420, v421 in v417 do
		v419[v420] = v421
	end
	v419.Parent = v418
	v_u_46 = v419
	v_u_10.glass(v_u_46)
	local v422 = v_u_46
	local v423 = v_u_1.new("UIScale")
	v423.Name = "DockScale"
	v423.Parent = v422
	local v424 = {
		["Position"] = UDim2.fromOffset(12, 8),
		["Size"] = UDim2.new(1, -20, 1, -16)
	}
	local v425 = v_u_46
	local v426 = v_u_1.new("Frame")
	v426.Name = "Inner"
	v426.BorderSizePixel = 0
	v426.BackgroundTransparency = 1
	for v427, v428 in v424 do
		v426[v427] = v428
	end
	v426.Parent = v425
	local v429 = {
		["Size"] = UDim2.new(0.34, 0, 1, 0)
	}
	local v430 = v_u_1.new("Frame")
	v430.Name = "Total"
	v430.BorderSizePixel = 0
	v430.BackgroundTransparency = 1
	for v431, v432 in v429 do
		v430[v431] = v432
	end
	v430.Parent = v426
	v_u_65("TextLabel", {
		["Name"] = "Heading",
		["Text"] = "Total price",
		["FontFace"] = nil,
		["TextSize"] = 11,
		["TextColor3"] = nil,
		["Size"] = nil,
		["FontFace"] = v_u_11.FONT_HEAVY,
		["TextColor3"] = v_u_11.ACCENT_LIGHT,
		["Size"] = UDim2.new(1, 0, 0, 13)
	}, v430)
	local v433 = v_u_65("TextLabel", {
		["Name"] = "Due",
		["Text"] = "",
		["FontFace"] = nil,
		["TextSize"] = 19,
		["TextColor3"] = nil,
		["TextTruncate"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["FontFace"] = v_u_11.FONT_DISPLAY,
		["TextColor3"] = v_u_24,
		["TextTruncate"] = Enum.TextTruncate.AtEnd,
		["Position"] = UDim2.fromOffset(0, 14),
		["Size"] = UDim2.new(1, 0, 0, 24)
	}, v430)
	local v434 = {
		["AnchorPoint"] = Vector2.new(1, 0),
		["Position"] = UDim2.fromScale(1, 0),
		["Size"] = UDim2.new(0.66, 0, 1, 0)
	}
	local v435 = v_u_1.new("Frame")
	v435.Name = "Keys"
	v435.BorderSizePixel = 0
	v435.BackgroundTransparency = 1
	for v436, v437 in v434 do
		v435[v436] = v437
	end
	v435.Parent = v426
	local v438, v439 = v_u_250(v435, 42, 64, 16)
	local v440 = v_u_50
	local v441 = {
		["frame"] = nil,
		["due"] = nil,
		["confirm"] = nil,
		["undo"] = nil,
		["gap"] = 64,
		["frame"] = v_u_46,
		["due"] = v433,
		["confirm"] = v438,
		["undo"] = v439
	}
	table.insert(v440, v441)
	local v442 = v_u_40
	local v443 = v_u_1.new("TextButton")
	v443.Name = "ExitPhone"
	v443.Text = ""
	v443.AutoButtonColor = false
	v443.BorderSizePixel = 0
	v443:SetAttribute("SkinSkip", true)
	v443.Parent = v442
	v_u_47 = v443
	v_u_47.Visible = false
	v_u_47.Size = UDim2.fromOffset(42, 42)
	v_u_47.BackgroundColor3 = v_u_11.RED
	v_u_47.BackgroundTransparency = 0.25
	local v444 = v_u_47
	local v445 = v_u_1.new("UICorner")
	v445.CornerRadius = UDim.new(0, 21)
	v445.Parent = v444
	local v446 = v_u_47
	local v447 = Color3.new(1, 1, 1)
	local v448 = v_u_1.new("UIStroke")
	v448.Name = "Edge"
	v448.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v448.Color = v447 or Color3.new(1, 1, 1)
	v448.Transparency = 0.5
	v448.Parent = v446
	local v449 = Color3.new(1, 1, 1)
	local v450 = v_u_47
	local v451 = v_u_19.make("close", v449, 18)
	v451.Name = "Ico"
	v451.Parent = v450
	v451.AnchorPoint = Vector2.new(0.5, 0.5)
	v451.Position = UDim2.fromScale(0.5, 0.5)
	v_u_47.Activated:Connect(function()
		-- upvalues: (ref) v_u_171
		v_u_171()
	end)
	local v452 = v_u_65("TextLabel", {
		["Name"] = "Cash",
		["Text"] = "",
		["FontFace"] = nil,
		["TextSize"] = 14,
		["TextColor3"] = nil,
		["BackgroundTransparency"] = 0.25,
		["BackgroundColor3"] = nil,
		["AutomaticSize"] = nil,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["FontFace"] = v_u_11.FONT_DISPLAY,
		["TextColor3"] = v_u_11.GOLD,
		["BackgroundColor3"] = Color3.fromRGB(10, 11, 15),
		["AutomaticSize"] = Enum.AutomaticSize.X,
		["AnchorPoint"] = Vector2.new(0, 0.5),
		["Position"] = UDim2.new(0, 50, 0.5, 0),
		["Size"] = UDim2.fromOffset(0, 30)
	}, v_u_47)
	local v453 = v_u_1.new("UICorner")
	v453.CornerRadius = UDim.new(0, 15)
	v453.Parent = v452
	local v454 = v_u_1.new("UIPadding")
	v454.PaddingLeft = UDim.new(0, 12)
	v454.PaddingRight = UDim.new(0, 12)
	v454.Parent = v452
	local v455 = v_u_49
	table.insert(v455, v452)
	v_u_13:GetAttributeChangedSignal("Cash"):Connect(v_u_159)
end
local function v_u_459(p457) -- name: hideTree
	-- upvalues: (ref) v_u_58
	for _, v458 in p457:GetDescendants() do
		if not (v458:IsA("BasePart") or v458:IsA("Decal")) or v_u_58.hidden[v458] then
			continue
		end
		v_u_58.hidden[v458] = v458.LocalTransparencyModifier
		v458.LocalTransparencyModifier = 1
	end
end
local function v_u_466() -- name: hideOthers
	-- upvalues: (copy) v_u_8, (ref) v_u_58, (copy) v_u_3, (copy) v_u_13, (copy) v_u_459
	local v460 = v_u_8.tuneBay(v_u_58.model:GetPivot().Position)
	local v461
	if v460 then
		v461 = v460.Position
	else
		v461 = v_u_58.model:GetPivot().Position
	end
	for _, v462 in v_u_3:GetPlayers() do
		local v463 = v462 ~= v_u_13 and v462.Character
		if v463 then
			v463 = v462.Character:FindFirstChild("HumanoidRootPart")
		end
		if not v463 or (v463.Position - v461).Magnitude >= 80 then
			continue
		end
		v_u_459(v462.Character)
	end
	local v464 = workspace:FindFirstChild("SpawnedVehicles")
	for _, v465 in not v464 and {} or v464:GetChildren() do
		if v465 == v_u_58.model or (not v465:IsA("Model") or (v465:GetPivot().Position - v461).Magnitude >= 80) then
			continue
		end
		v_u_459(v465)
	end
end
local function v_u_469() -- name: hideOwnBody
	-- upvalues: (copy) v_u_13
	local v467 = v_u_13.Character
	if v467 then
		for _, v468 in v467:GetDescendants() do
			if not (v468:IsA("BasePart") or v468:IsA("Decal")) then
				continue
			end
			v468.LocalTransparencyModifier = 1
		end
	end
end
local function v_u_471() -- name: hideHud
	-- upvalues: (copy) v_u_13, (copy) v_u_17, (ref) v_u_58
	for _, v470 in v_u_13.PlayerGui:GetChildren() do
		if not v470:IsA("ScreenGui") or (not v470.Enabled or v_u_17[v470.Name]) then
			continue
		end
		v470.Enabled = false
		v_u_58.guis[v470] = true
	end
end
local function v_u_482(p472) -- name: freeArea
	-- upvalues: (ref) v_u_44, (ref) v_u_51, (ref) v_u_43, (ref) v_u_54, (copy) v_u_13
	local v473 = p472.X
	local v474 = {
		v_u_44,
		v_u_51,
		v_u_43,
		v_u_54
	}
	local v475 = 0
	for _, v476 in { "PCX160Paint", "CarTune" } do
		local v477 = v_u_13.PlayerGui:FindFirstChild(v476)
		if not (v477 and v477.Enabled) then
			continue
		end
		table.insert(v474, v477:FindFirstChild("Panel"))
	end
	local v478 = v_u_13.PlayerGui:FindFirstChild("EcuTune")
	if v478 and v478.Enabled then
		table.insert(v474, v478:FindFirstChild("EcuPanel"))
	end
	for _, v479 in v474 do
		if not v479 or (not v479.Visible or v479.AbsoluteSize.X <= 0) then
			continue
		end
		local v480 = v479.AbsolutePosition.X
		local v481 = v480 + v479.AbsoluteSize.X
		if (v480 + v481) / 2 < p472.X / 2 then
			v475 = math.max(v475, v481)
		else
			v473 = math.min(v473, v480)
		end
	end
	if v473 - v475 < 80 then
		v473 = p472.X
		v475 = 0
	end
	return v475, v473
end
local function v_u_489() -- name: topBar
	-- upvalues: (ref) v_u_39, (copy) v_u_18
	local v483 = v_u_39.AbsoluteSize
	local function v484()
		-- upvalues: (ref) v_u_18
		return v_u_18.TopbarInset
	end
	local v485, v486 = pcall(v484)
	if not v485 or (not v486 or v486.Height <= 0) then
		return 0, 0, v483.X
	end
	local v487 = v_u_39.AbsolutePosition + v_u_18:GetGuiInset()
	local v488 = v486.Max.Y - v487.Y
	return math.max(v488, 0), v486.Min.X - v487.X, v486.Max.X - v487.X
end
local function v_u_501() -- name: redockMenu
	-- upvalues: (ref) v_u_58, (copy) v_u_57
	local v490 = v_u_58
	if v490 then
		v490 = v_u_58.menuGui
	end
	local v491 = v490 and v490.Enabled
	if v491 then
		v491 = v490:FindFirstChild("Panel")
	end
	local v492
	if v491 then
		v492 = v491:FindFirstChild("DockScale")
	else
		v492 = v491
	end
	if v492 and (v_u_57.set and (v_u_57.size and (v491.Size.X.Offset > 0 and v491.Size.Y.Offset > 0))) then
		local v493 = v_u_57.size
		local v494 = v493.Y - v_u_57.top - v_u_57.bottom
		local v495 = v493.X - v_u_57.left - v_u_57.right
		local v496 = v_u_57.max or 1
		local v497 = v494 / v491.Size.Y.Offset
		local v498 = v495 / v491.Size.X.Offset
		local v499 = math.min(v497, v498, v496)
		local v500 = math.max(v496, 0.45)
		v492.Scale = math.clamp(v499, 0.45, v500)
		if v_u_57.insets then
			v490.ScreenInsets = v_u_57.insets
		end
		if v_u_57.anchor == "left" then
			v491.AnchorPoint = Vector2.zero
			v491.Position = UDim2.fromOffset(v_u_57.left, v_u_57.top)
		else
			v491.AnchorPoint = Vector2.new(1, 0)
			v491.Position = UDim2.new(1, -v_u_57.right, 0, v_u_57.top)
		end
	else
		return
	end
end
local v_u_502 = ""
local function v_u_567() -- name: layout
	-- upvalues: (ref) v_u_39, (ref) v_u_58, (copy) v_u_489, (ref) v_u_502, (copy) v_u_32, (copy) v_u_28, (ref) v_u_41, (ref) v_u_42, (ref) v_u_54, (copy) v_u_35, (copy) v_u_57, (ref) v_u_45, (ref) v_u_43, (ref) v_u_46, (ref) v_u_47, (copy) v_u_48, (copy) v_u_36, (ref) v_u_44, (ref) v_u_51, (copy) v_u_501, (copy) v_u_159
	if v_u_39 and v_u_58 then
		local v503 = v_u_39.AbsoluteSize
		if v503.Y <= 0 then
			return
		else
			local v504, _, v505 = v_u_489()
			local v506 = v503.X
			local v507 = v503.Y
			local v508 = v_u_58.tile
			local v509 = ("%d|%d|%d|%d|%s"):format(v506, v507, v504, v505, (tostring(v508)))
			if v509 ~= v_u_502 then
				v_u_502 = v509
				if v_u_58.hasParts == nil then
					v_u_58.hasParts = v_u_32(v_u_58.model)
				end
				local v510 = #v_u_28
				local v511 = v_u_58.tile == "ECU"
				local v512 = v503.Y < 520
				local v513, v514, v515, v516, v517
				if v512 then
					v_u_41.Visible = false
					v_u_42.Visible = false
					v_u_45.Visible = false
					v_u_54:SetAttribute("Shown", false)
					local v518 = v504 + 4
					v_u_43.Visible = not v_u_58.exhaustOnly
					local v519 = v503.Y - v518 - 6
					local v520 = (v519 - 8 - (v510 - 1) * 4) / math.max(v510, 1)
					local v521 = math.floor(v520)
					local v522 = math.clamp(v521, 30, 52)
					v_u_43.Position = UDim2.fromOffset(6, v518)
					v_u_43.Size = UDim2.fromOffset(64, v519)
					for _, v523 in v_u_28 do
						v_u_48[v523.id].rail.Size = UDim2.new(1, 0, 0, v522)
					end
					local v524 = v_u_43.Visible and 76 or 6
					v513 = v503.X - 6 - 1 <= v505 and 6 or v518
					v514 = v503.Y - v513 - 6
					local v525 = v514 / v_u_35.Y
					local v526 = (v503.X - v524 - 6 - 220) / v_u_35.X
					local v527 = math.min(v525, v526, 1)
					local v528 = math.clamp(v527, 0.45, 1)
					v515 = v_u_35.X * v528
					v516 = v503.X - 6 - v515
					v_u_57.ecu = {
						["x"] = v524,
						["y"] = v513,
						["w"] = v503.X - v524 - 6,
						["h"] = v514,
						["insets"] = v_u_39.ScreenInsets
					}
					local v529 = v516 - 6
					v_u_46:SetAttribute("Shown", not v511)
					local v530 = v_u_46.DockScale
					local v531 = (v529 - v524) / v_u_36.X
					v530.Scale = math.clamp(v531, 0.6, 1)
					v_u_46.AnchorPoint = Vector2.new(0.5, 1)
					v_u_46.Position = UDim2.fromOffset((v524 + v529) / 2, v503.Y - 6)
					v_u_47.Visible = true
					v_u_47.Position = UDim2.fromOffset(v524, v518)
					v517 = 1
				else
					local v532 = v503.Y / 760
					v517 = math.clamp(v532, 0.62, 1.25)
					local v533 = v517 * 14 + 0.5
					local v534 = math.floor(v533)
					local v535 = math.max(v504, v534)
					local v536 = v517 * 6 + 0.5
					local v537 = v535 + math.floor(v536)
					local v538 = v517 * 22 + 0.5
					local v539 = math.floor(v538)
					v_u_41.Visible = true
					v_u_41.Position = UDim2.fromOffset(v534, v537)
					v_u_41.Size = UDim2.fromOffset(v503.X - v534 * 2, v503.Y - v537 - v534)
					v_u_41.Shade.Position = UDim2.fromOffset(-v534, -v537)
					local v540 = v_u_41.Shade
					local v541 = UDim2.new
					local v542 = v534 * 2
					local v543 = v537 + v539
					local v544 = v517 * 146 + 0.5
					v540.Size = v541(1, v542, 0, v543 + math.floor(v544))
					v_u_42.Visible = true
					v_u_42.DockScale.Scale = v517
					v_u_42.Position = UDim2.fromOffset(v534 + v539, v537 + v539)
					v_u_42.Size = UDim2.fromOffset((v503.X - (v534 + v539) * 2) / v517, 106)
					local v545 = v537 + v539
					local v546 = v517 * 122 + 0.5
					v513 = v545 + math.floor(v546)
					local v547 = v503.Y - v534 - v539
					v514 = v547 - v513
					v_u_54:SetAttribute("Shown", not v511)
					v_u_54.DockScale.Scale = v517
					v_u_54.AnchorPoint = Vector2.new(1, 0)
					v_u_54.Position = UDim2.new(1, -(v534 + v539), 0, v513)
					v_u_54.Size = UDim2.fromOffset(300, v514 / v517)
					local v548 = v503.X - (v534 + v539) - v517 * 300
					local v549 = v548 - v517 * 20 - (v534 + v539) - v503.X / 3
					local v550 = v514 / v_u_35.Y
					local v551 = v549 / v_u_35.X
					local v552 = math.min(v550, v551, v517)
					local v553 = math.clamp(v552, 0.45, 1.25)
					v516 = v534 + v539
					v515 = v_u_35.X * v553
					v_u_57.ecu = {
						["x"] = v534 + v539,
						["y"] = v513,
						["w"] = v503.X - (v534 + v539) * 2,
						["h"] = v514,
						["insets"] = v_u_39.ScreenInsets
					}
					v_u_45.Visible = not v511
					v_u_45.Position = UDim2.fromOffset((v516 + v515 + v548) / 2, v547)
					v_u_43.Visible = false
					v_u_46:SetAttribute("Shown", false)
					v_u_47.Visible = false
				end
				local v554 = v514 / v_u_35.Y
				local v555 = v515 / v_u_35.X
				local v556 = math.min(v554, v555)
				local v557 = math.clamp(v556, 0.45, 1.25)
				for _, v558 in { v_u_44, v_u_51 } do
					v558.DockScale.Scale = v557
					v558.AnchorPoint = Vector2.zero
					local v559 = UDim2.fromOffset
					local v560
					if v512 then
						v560 = v516 + v515 - v_u_35.X * v557
					else
						v560 = v516
					end
					v558.Position = v559(v560, v513)
				end
				v_u_57.set = true
				local v561 = v_u_57
				local v562 = v_u_57
				local v563 = v503.Y - v513 - v514
				v561.top = v513
				v562.bottom = v563
				local v564 = v_u_57
				local v565 = v_u_57
				local v566 = v503.X - v516 - v515
				v564.left = v516
				v565.right = v566
				v_u_57.anchor = v512 and "right" or "left"
				v_u_57.max = v517
				v_u_57.short = v512
				v_u_57.size = v503
				v_u_57.insets = v_u_39.ScreenInsets
				v_u_501()
				v_u_159()
			end
		end
	else
		return
	end
end
local function v_u_595(p568) -- name: step
	-- upvalues: (ref) v_u_58, (ref) v_u_171, (copy) v_u_159, (copy) v_u_482, (copy) v_u_567, (copy) v_u_469, (copy) v_u_471, (copy) v_u_466
	local v569 = v_u_58
	if not v569 then
		return
	end
	local v570 = workspace.CurrentCamera
	local v571 = v569.model:FindFirstChild("Chassis") or v569.model.PrimaryPart
	if not (v569.model.Parent and v571) then
		v_u_171()
		return
	end
	if (v569.tile == "Paint" or (v569.tile == "Other" or v569.tile == "Parts")) and (not (v569.menuGui and v569.menuGui.Enabled) and os.clock() - v569.tileAt > 1) then
		v569.tile = nil
		v_u_159()
	end
	local v572 = v570.ViewportSize
	local v573 = 0.41421356237309503 * v572.X / v572.Y
	local v574, v575 = v_u_482(v572)
	v_u_567()
	local v576 = (v575 - v574) / v572.X
	local v577 = math.clamp(v576, 0.2, 1)
	local v578 = (v574 + v575) / 2 / v572.X
	local v579 = v569.radius / 0.41421356237309503
	local v580 = v569.radius / (v573 * v577)
	local v581 = math.max(v579, v580) * 1.08 * v569.zoom
	local v582 = -(v578 - 0.5) * 2 * v581 * v573
	local v583 = -6 * p568
	local v584 = 1 - math.exp(v583)
	if v569.distance then
		v581 = v569.distance + (v581 - v569.distance) * v584
	end
	v569.distance = v581
	if v569.shift then
		v582 = v569.shift + (v582 - v569.shift) * v584
	end
	v569.shift = v582
	local v585 = v571.CFrame:PointToWorldSpace(v569.focusOffset)
	v570.CameraType = Enum.CameraType.Scriptable
	v570.FieldOfView = 45
	local v586 = CFrame.new(v585) * CFrame.Angles(0, v569.yaw, 0) * CFrame.Angles(v569.pitch, 0, 0) * CFrame.new(v569.shift, 0, v569.distance)
	local v587 = v586.Position - v585
	for _ = 1, 6 do
		local v588 = workspace:Raycast(v585, v587, v569.rayParams)
		if not v588 then
			break
		end
		local v589 = v588.Instance
		v569.rayParams:AddToFilter(v589)
		if v588.Normal.Y >= 0.7 then
			local v590 = v588.Distance - 0.6
			v586 = v586 - v587 * (1 - math.max(v590, 1) / v587.Magnitude)
			v569.rayParams.FilterDescendantsInstances = v569.ignore
			break
		end
		if v569.hidden[v589] == nil then
			v569.hidden[v589] = v589.LocalTransparencyModifier
		end
		v589.LocalTransparencyModifier = 1
	end
	local v591 = RaycastParams.new()
	v591.FilterType = Enum.RaycastFilterType.Exclude
	v591.FilterDescendantsInstances = v569.ignore
	for _, v592 in v569.corners do
		local v593 = v571.CFrame:PointToWorldSpace(v592)
		local v594 = workspace:Raycast(v593, v586.Position - v593, v591)
		if not v594 or v594.Instance.Size.Magnitude >= 30 then
			continue
		end
		if v569.hidden[v594.Instance] == nil then
			v569.hidden[v594.Instance] = v594.Instance.LocalTransparencyModifier
		end
		v594.Instance.LocalTransparencyModifier = 1
	end
	v570.CFrame = v586
	v_u_469()
	v_u_471()
	if os.clock() - v569.hiddenAt > 1 then
		v569.hiddenAt = os.clock()
		v_u_466()
	end
end
local function v_u_599() -- name: vehicleSeated
	-- upvalues: (copy) v_u_13
	local v596 = v_u_13.Character
	if v596 then
		v596 = v596:FindFirstChildOfClass("Humanoid")
	end
	local v597
	if v596 then
		v597 = v596.SeatPart
	else
		v597 = v596
	end
	local v598 = workspace:FindFirstChild("SpawnedVehicles")
	if v597 and v598 then
		while v597 and v597.Parent ~= v598 do
			v597 = v597.Parent
		end
		if v597 and (v597:IsA("Model") and v597:GetAttribute("OwnerUserId") == v_u_13.UserId) then
			return v597, v596
		else
			return nil
		end
	else
		return nil
	end
end
v_u_170 = function(p600) -- name: selectTile
	-- upvalues: (ref) v_u_58, (copy) v_u_32, (copy) v_u_9, (copy) v_u_13, (copy) v_u_12, (ref) v_u_39, (ref) v_u_170, (copy) v_u_159
	if v_u_58 then
		if v_u_58.tile == p600 then
			p600 = nil
		end
		if p600 == "Parts" and not v_u_58.exhaustOnly then
			if v_u_58.hasParts == nil then
				v_u_58.hasParts = v_u_32(v_u_58.model)
			end
			if not v_u_58.hasParts then
				v_u_9.show("\224\184\132\224\184\177\224\184\153\224\184\153\224\184\181\224\185\137\224\185\132\224\184\161\224\185\136\224\184\170\224\184\178\224\184\161\224\184\178\224\184\163\224\184\150\224\185\129\224\184\149\224\185\136\224\184\135\224\184\173\224\184\176\224\185\132\224\184\171\224\184\165\224\185\136\224\185\132\224\184\148\224\185\137", "info")
				return
			end
		end
		v_u_58.tile = p600
		v_u_58.tileAt = os.clock()
		if p600 == "Paint" or (p600 == "Other" or p600 == "Parts") then
			v_u_13:SetAttribute("OpenTune", p600)
		else
			v_u_13:SetAttribute("OpenTune", "Close")
		end
		if p600 == "ECU" then
			v_u_12.open(v_u_58.model, v_u_39, function()
				-- upvalues: (ref) v_u_170
				v_u_170(nil)
			end)
		else
			v_u_12.close()
		end
		v_u_159()
	end
end
local function v_u_690() -- name: open
	-- upvalues: (ref) v_u_58, (copy) v_u_599, (copy) v_u_9, (copy) v_u_8, (ref) v_u_39, (copy) v_u_456, (copy) v_u_16, (copy) v_u_13, (copy) v_u_3, (copy) v_u_2, (copy) v_u_15, (ref) v_u_502, (ref) v_u_42, (copy) v_u_159, (copy) v_u_567, (ref) v_u_170, (ref) v_u_171, (copy) v_u_122, (copy) v_u_6, (copy) v_u_5, (copy) v_u_595
	if v_u_58 then
		return
	else
		local v_u_601, v602 = v_u_599()
		if v_u_601 then
			if v_u_8.inTuneBay(v_u_601) then
				if not v_u_39 then
					v_u_456()
				end
				local v603 = v_u_601:GetAttribute("VehicleTag") == "PCX160" and "bike" or "car"
				local v604 = v_u_8.atExhaustShop(v_u_601)
				if v604 and v603 ~= "bike" then
					v_u_9.show("\224\184\163\224\185\137\224\184\178\224\184\153\224\184\151\224\185\136\224\184\173\224\185\129\224\184\149\224\185\136\224\184\135\224\185\128\224\184\170\224\184\181\224\184\162\224\184\135\224\184\151\224\185\136\224\184\173\224\185\132\224\184\148\224\185\137\224\185\128\224\184\137\224\184\158\224\184\178\224\184\176\224\184\161\224\184\173\224\185\128\224\184\149\224\184\173\224\184\163\224\185\140\224\185\132\224\184\139\224\184\132\224\185\140", "info")
				else
					local v605 = v_u_601:FindFirstChild("Chassis") or v_u_601.PrimaryPart
					local v606, v607 = v_u_601:GetBoundingBox()
					local v608 = v605.CFrame.LookVector
					local v609 = workspace.CurrentCamera
					local v610 = {
						["model"] = nil,
						["kind"] = nil,
						["exhaustOnly"] = nil,
						["humanoid"] = nil,
						["tile"] = nil,
						["tileAt"] = 0,
						["radius"] = nil,
						["focusOffset"] = nil,
						["yaw"] = nil,
						["orbitDir"] = 1,
						["arc"] = nil,
						["inArc"] = true,
						["pitch"] = -0.24434609527920614,
						["zoom"] = 1,
						["dragging"] = false,
						["hidden"] = nil,
						["hiddenAt"] = 0,
						["guis"] = nil,
						["menuGui"] = nil,
						["saved"] = nil,
						["connections"] = nil,
						["rayParams"] = nil,
						["model"] = v_u_601,
						["kind"] = v603,
						["exhaustOnly"] = v604,
						["humanoid"] = v602,
						["radius"] = v607.Magnitude / 2 * 0.8,
						["focusOffset"] = v605.CFrame:PointToObjectSpace(v606.Position)
					}
					local v611 = -v608.X
					local v612 = -v608.Z
					v610.yaw = math.atan2(v611, v612) + v_u_16[1]
					v610.hidden = {}
					v610.guis = {}
					v610.menuGui = v_u_13.PlayerGui:FindFirstChild(v603 == "bike" and "PCX160Paint" or "CarTune")
					v610.saved = {
						["type"] = v609.CameraType,
						["subject"] = v609.CameraSubject,
						["fov"] = v609.FieldOfView
					}
					v610.connections = {}
					v610.rayParams = RaycastParams.new()
					v_u_58 = v610
					v_u_58.rayParams.FilterType = Enum.RaycastFilterType.Exclude
					v_u_58.rayParams.RespectCanCollide = true
					local v613 = { workspace:FindFirstChild("SpawnedVehicles") }
					for _, v614 in v_u_3:GetPlayers() do
						local v615 = v614.Character
						table.insert(v613, v615)
					end
					v_u_58.ignore = v613
					v_u_58.corners = {}
					local v616 = v607 / 2 * 0.9
					for _, v617 in {
						Vector3.new(1, 1, 1),
						Vector3.new(-1, 1, 1),
						Vector3.new(1, 1, -1),
						Vector3.new(-1, 1, -1),
						Vector3.new(1, -0.6, 1),
						Vector3.new(-1, -0.6, 1),
						Vector3.new(1, -0.6, -1),
						Vector3.new(-1, -0.6, -1),
						Vector3.new(1, 0, 0),
						Vector3.new(-1, 0, 0)
					} do
						local v618 = v_u_58.corners
						local v619 = v605.CFrame
						local v620 = (v606 * CFrame.new(v616 * v617)).Position
						table.insert(v618, v619:PointToObjectSpace(v620))
					end
					v_u_58.rayParams.FilterDescendantsInstances = v613
					local v621 = v606.Position
					local v622 = v_u_58.radius / 0.41421356237309503 * 1.5
					local v623 = -v608.X
					local v624 = -v608.Z
					local v625 = math.atan2(v623, v624)
					local v626 = {}
					for v627 = 0, 31 do
						local v628 = (CFrame.Angles(0, v625 + v627 * 0.19634954084936207, 0) * CFrame.Angles(-0.24434609527920614, 0, 0)).LookVector * -v622
						local v629 = workspace:Spherecast(v621, 1.5, v628, v_u_58.rayParams)
						v626[v627] = not v629 or v629.Instance.Size.Magnitude < 30
					end
					local v630 = 0
					local v631 = 0
					local v632 = 0
					local v633 = 0
					for v634 = 0, 63 do
						if v626[v634 % 32] then
							if v630 == 0 then
								v632 = v634
							end
							v630 = v630 + 1
							if v631 >= v630 then
								continue
							end
							v631 = math.min(v630, 32)
							v633 = v632
						else
							v630 = 0
						end
					end
					if v631 > 0 and v631 < 32 then
						local v635 = v625 + v633 * 0.19634954084936207 + 0.13962634015954636
						local v636 = v625 + (v633 + v631 - 1) * 0.19634954084936207 - 0.13962634015954636
						if v636 < v635 then
							v635 = (v635 + v636) / 2
							v636 = v635
						end
						v_u_58.arc = { v635, v636 }
						v_u_58.yaw = (v635 + v636) / 2
						for _, v637 in v_u_16 do
							local v638 = v625 + v637
							while v638 < v635 do
								v638 = v638 + 6.283185307179586
							end
							while v635 + 6.283185307179586 < v638 do
								v638 = v638 - 6.283185307179586
							end
							if v638 > v636 then
								break
							end
							v_u_58.yaw = v638
						end
					end
					v_u_13:SetAttribute("Tuning", true)
					local v_u_639 = true
					task.spawn(function()
						-- upvalues: (ref) v_u_2, (ref) v_u_15, (copy) v_u_601, (copy) v_u_639
						local v640 = v_u_2.invoke
						local v641 = v_u_15
						local v642 = v_u_601
						local v643 = v_u_639
						pcall(v640, v641, "Hold", v642, v643)
					end)
					v_u_502 = ""
					v_u_39.Enabled = true
					local v644 = v_u_42:FindFirstChild("Name")
					if v644 then
						v644.Text = v604 and "EXHAUST GARAGE" or "TUNING GARAGE"
					end
					v_u_159()
					if v_u_58.exhaustOnly then
						v_u_567()
						v_u_170("Parts")
					end
					local v645 = v_u_58.connections
					local v646 = v602:GetPropertyChangedSignal("SeatPart")
					local function v647()
						-- upvalues: (ref) v_u_171
						v_u_171()
					end
					table.insert(v645, v646:Connect(v647))
					local v648 = v_u_58.connections
					local v649 = v602.Died
					local function v650()
						-- upvalues: (ref) v_u_171
						v_u_171()
					end
					table.insert(v648, v649:Connect(v650))
					local v651 = v_u_58.connections
					local v652 = v_u_13.PlayerGui.ChildAdded
					local function v654(p653)
						-- upvalues: (ref) v_u_58
						if p653.Name == "PCX160Paint" or p653.Name == "CarTune" then
							v_u_58.menuGui = p653
						end
					end
					table.insert(v651, v652:Connect(v654))
					local v655 = v_u_58.connections
					local v656 = v_u_601.AttributeChanged
					local function v658(p657)
						-- upvalues: (ref) v_u_8, (ref) v_u_122
						if p657 == "TuneBaseline" or (p657 == "TuneOwned" or v_u_8.isTuneAttribute(p657)) then
							v_u_122()
						end
					end
					table.insert(v655, v656:Connect(v658))
					local v659 = v_u_58.connections
					local v660 = v_u_601:GetAttributeChangedSignal("EngineLevel")
					local v661 = v_u_159
					table.insert(v659, v660:Connect(v661))
					local v662 = v_u_58.connections
					local v663 = v_u_601:GetAttributeChangedSignal("BrakeLevel")
					local v664 = v_u_159
					table.insert(v662, v663:Connect(v664))
					local v665 = v_u_58.connections
					local v666 = v_u_601:GetAttributeChangedSignal("EngineOwned")
					local v667 = v_u_159
					table.insert(v665, v666:Connect(v667))
					local v668 = v_u_58.connections
					local v669 = v_u_601:GetAttributeChangedSignal("BrakeOwned")
					local v670 = v_u_159
					table.insert(v668, v669:Connect(v670))
					local v671 = v_u_58.connections
					local v672 = v_u_6.InputBegan
					local function v675(p673, p674)
						-- upvalues: (ref) v_u_58, (ref) v_u_171
						if p674 then
							return
						elseif p673.UserInputType == Enum.UserInputType.MouseButton1 or (p673.UserInputType == Enum.UserInputType.MouseButton2 or p673.UserInputType == Enum.UserInputType.Touch) then
							v_u_58.dragging = true
							v_u_58.dragFrom = p673.Position
						elseif p673.KeyCode == Enum.KeyCode.P then
							task.defer(v_u_171)
						end
					end
					table.insert(v671, v672:Connect(v675))
					local v676 = v_u_58.connections
					local v677 = v_u_6.InputChanged
					local function v685(p678)
						-- upvalues: (ref) v_u_58
						if p678.UserInputType == Enum.UserInputType.MouseWheel then
							local v679 = v_u_58
							local v680 = v_u_58.zoom * (1 - p678.Position.Z * 0.08)
							v679.zoom = math.clamp(v680, 0.6, 1.8)
						elseif v_u_58.dragging and (p678.UserInputType == Enum.UserInputType.MouseMovement or p678.UserInputType == Enum.UserInputType.Touch) then
							local v681 = p678.Position - v_u_58.dragFrom
							v_u_58.dragFrom = p678.Position
							local v682 = v_u_58
							v682.yaw = v682.yaw - v681.X * 0.006108652381980153
							v_u_58.inArc = false
							local v683 = v_u_58
							local v684 = v_u_58.pitch - v681.Y * 0.006108652381980153 * 0.6
							v683.pitch = math.clamp(v684, -0.8726646259971648, 0.08726646259971647)
						end
					end
					table.insert(v676, v677:Connect(v685))
					local v686 = v_u_58.connections
					local v687 = v_u_6.InputEnded
					local function v689(p688)
						-- upvalues: (ref) v_u_58
						if p688.UserInputType == Enum.UserInputType.MouseButton1 or (p688.UserInputType == Enum.UserInputType.MouseButton2 or p688.UserInputType == Enum.UserInputType.Touch) then
							v_u_58.dragging = false
						end
					end
					table.insert(v686, v687:Connect(v689))
					v_u_5:BindToRenderStep("TuneHubCamera", Enum.RenderPriority.Camera.Value + 10, v_u_595)
				end
			else
				v_u_9.show(v_u_8.TUNE_HINT, "info")
				return
			end
		else
			v_u_9.show("Get on your own vehicle first", "info")
			return
		end
	end
end
v_u_171 = function() -- name: close
	-- upvalues: (ref) v_u_58, (copy) v_u_2, (copy) v_u_15, (copy) v_u_5, (copy) v_u_13, (copy) v_u_12, (ref) v_u_39, (ref) v_u_51, (ref) v_u_54
	local v691 = v_u_58
	if v691 then
		v_u_58 = nil
		local v_u_692 = v691.model
		local v_u_693 = false
		task.spawn(function()
			-- upvalues: (ref) v_u_2, (ref) v_u_15, (copy) v_u_692, (copy) v_u_693
			local v694 = v_u_2.invoke
			local v695 = v_u_15
			local v696 = v_u_692
			local v697 = v_u_693
			pcall(v694, v695, "Hold", v696, v697)
		end)
		local v698 = v_u_5.UnbindFromRenderStep
		local v699 = v_u_5
		pcall(v698, v699, "TuneHubCamera")
		for _, v700 in v691.connections do
			v700:Disconnect()
		end
		v_u_13:SetAttribute("Tuning", nil)
		v_u_13:SetAttribute("OpenTune", "Close")
		v_u_12.close()
		v_u_39.Enabled = false
		v_u_51.Visible = false
		v_u_54.Visible = false
		for v701, v702 in v691.hidden do
			if not v701.Parent then
				continue
			end
			v701.LocalTransparencyModifier = v702
		end
		local v703 = v_u_13.Character
		for _, v704 in not v703 and {} or v703:GetDescendants() do
			if not (v704:IsA("BasePart") or v704:IsA("Decal")) then
				continue
			end
			v704.LocalTransparencyModifier = 0
		end
		for v705 in v691.guis do
			if not v705.Parent then
				continue
			end
			v705.Enabled = true
		end
		local v706 = workspace.CurrentCamera
		v706.FieldOfView = v691.saved.fov
		v706.CameraType = Enum.CameraType.Custom
		local v707 = v691.saved.subject
		if v707 and v707.Parent then
			v706.CameraSubject = v707
		elseif v691.humanoid and v691.humanoid.Parent then
			v706.CameraSubject = v691.humanoid
		end
	else
		return
	end
end
local v708 = v_u_1.new("ScreenGui")
v708.Name = "TuneRideIn"
v708.ResetOnSpawn = false
v708.DisplayOrder = 6
v708.Parent = v_u_13:WaitForChild("PlayerGui")
local v_u_709 = v_u_1.new("TextButton")
v_u_709.Name = "Tune"
v_u_709.AnchorPoint = Vector2.new(0.5, 0)
v_u_709.Position = UDim2.new(0.5, 0, 0, 70)
v_u_709.Size = UDim2.fromOffset(240, 58)
v_u_709.BackgroundColor3 = v23
v_u_709.Font = Enum.Font.GothamBlack
v_u_709.TextSize = 22
v_u_709.TextColor3 = Color3.fromRGB(20, 20, 24)
v_u_709.Text = v_u_11.isTouch() and "Tune" or "Tune  [P]"
v_u_709.Visible = false
v_u_709.Parent = v708
local v710 = v_u_1.new("UICorner")
v710.CornerRadius = UDim.new(0, 14)
v710.Parent = v_u_709
v_u_10.apply(v708)
v_u_709.Activated:Connect(function()
	-- upvalues: (copy) v_u_599, (copy) v_u_9, (copy) v_u_690
	local v711 = v_u_599()
	if v711 then
		v711 = v711:FindFirstChild("Chassis") or v711.PrimaryPart
	end
	if v711 and v711.AssemblyLinearVelocity.Magnitude > 3 then
		v_u_9.show("Stop first, then tune", "info")
	else
		v_u_690()
	end
end)
task.spawn(function()
	-- upvalues: (ref) v_u_58, (copy) v_u_599, (copy) v_u_709, (copy) v_u_8
	while true do
		task.wait(0.25)
		local v712 = not v_u_58
		if v712 then
			v712 = v_u_599()
		end
		local v713 = v_u_709
		local v714
		if v712 == nil or v712 == false then
			v714 = false
		else
			v714 = v_u_8.inTuneBay(v712)
		end
		v713.Visible = v714
	end
end)
v_u_13:GetAttributeChangedSignal("TuneHub"):Connect(function()
	-- upvalues: (copy) v_u_13, (copy) v_u_690
	if v_u_13:GetAttribute("TuneHub") then
		v_u_13:SetAttribute("TuneHub", nil)
		v_u_690()
	end
end)
v_u_13.CharacterRemoving:Connect(function()
	-- upvalues: (ref) v_u_171
	v_u_171()
end)