-- Path: Players/ygggggg55551/PlayerScripts/WarpWindow
-- Class: LocalScript  true/Enum.RunContext.Legacy
-- Decompiled by BALL KUN Universal Map Dump

local v1 = game:GetService("Players")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("TweenService")
local v4 = v2:WaitForChild("GameUI")
local v_u_5 = require(v4:WaitForChild("Theme"))
local v6 = require(v4:WaitForChild("Icons"))
local v_u_7 = require(v4:WaitForChild("Warp"))
local v_u_8 = v1.LocalPlayer
local v9 = {
	{ "Auto", "Auto" },
	{ "Dawn", "Dawn" },
	{ "Day", "Day" },
	{ "Dusk", "Evening" },
	{ "Night", "Night" }
}
local v10 = {
	{ "Clear", "Sunny" },
	{ "Rain", "Rain" },
	{ "Storm", "Storm" },
	{ "Snow", "Snow" },
	{ "Fog", "Fog" }
}
local v11 = Vector2.new(640, 176)
local v_u_12 = v_u_5.GRAD.gold
local v_u_13 = v_u_5.CARD
local v14 = v_u_5.screen("WarpWindow", 21, v_u_8:WaitForChild("PlayerGui"))
local v_u_15 = v_u_5.new("TextButton", {
	["Name"] = "Shade",
	["Text"] = "",
	["AutoButtonColor"] = false,
	["BackgroundColor3"] = nil,
	["BackgroundTransparency"] = 0.45,
	["BorderSizePixel"] = 0,
	["Size"] = nil,
	["Visible"] = false,
	["Parent"] = nil,
	["BackgroundColor3"] = Color3.new(0, 0, 0),
	["Size"] = UDim2.fromScale(1, 1),
	["Parent"] = v14
})
local v_u_16 = v_u_5.panel({
	["Name"] = "WarpPanel",
	["Visible"] = false,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["AnchorPoint"] = Vector2.new(0.5, 0.5),
	["Position"] = UDim2.fromScale(0.5, 0.5),
	["Size"] = UDim2.new(0.94, 0, 0, v11.Y),
	["Parent"] = v14
})
local v17 = v_u_5.isTouch()
local v18 = not v17 and 176 or v_u_5.RAIL_W_TOUCH
v_u_5.new("UISizeConstraint", {
	["MaxSize"] = v11 + Vector2.new(v18, 0),
	["Parent"] = v_u_16
})
v_u_5.padding(v_u_16, 16)
local v_u_19 = v_u_5.new("UIScale", {
	["Parent"] = v_u_16
})
local v_u_20 = v_u_5.rail(v_u_16, {
	["grad"] = "gold",
	["icon"] = "sun",
	["title"] = "Time & Weather",
	["pad"] = 16,
	["touch"] = nil,
	["compact"] = true,
	["width"] = nil,
	["touch"] = v17,
	["width"] = v18
})
local v_u_21 = v_u_5.backdrop(v_u_15, "gold")
local v22 = v_u_16:FindFirstChildOfClass("UIStroke")
if v22 then
	v22.Color = Color3.new(1, 1, 1)
	v22.Transparency = 0.86
	v22.Thickness = 1
end
local v23 = v_u_5.new("Frame", {
	["Name"] = "HeaderLine",
	["BackgroundColor3"] = nil,
	["BackgroundTransparency"] = 0,
	["BorderSizePixel"] = 0,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["BackgroundColor3"] = v_u_12[1],
	["Position"] = UDim2.fromOffset(0, 46),
	["Size"] = UDim2.new(1, 0, 0, 1),
	["Parent"] = v_u_16
})
v_u_5.new("UIGradient", {
	["Transparency"] = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.3), NumberSequenceKeypoint.new(0.55, 0.85), NumberSequenceKeypoint.new(1, 1) }),
	["Parent"] = v23
})
local v24 = v_u_5.text
local v25 = {
	["Text"] = "TIME & WEATHER",
	["TextSize"] = nil,
	["FontFace"] = nil,
	["TextColor3"] = nil,
	["TextXAlignment"] = nil,
	["TextYAlignment"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["TextSize"] = v17 and 20 or 13
}
local v26
if v17 then
	v26 = v_u_5.FONT_DISPLAY
else
	v26 = v_u_5.FONT_HEAVY
end
v25.FontFace = v26
v25.TextColor3 = v_u_12[1]
v25.TextXAlignment = Enum.TextXAlignment.Left
v25.TextYAlignment = Enum.TextYAlignment.Top
v25.Position = UDim2.fromOffset(0, 1)
v25.Size = UDim2.new(1, -48, 0, 22)
v25.Parent = v_u_16
v24(v25)
local v27 = v_u_5.text
local v28 = {
	["Text"] = "Only you see it: pick the time of day and the weather",
	["TextSize"] = nil,
	["TextColor3"] = nil,
	["TextXAlignment"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["TextSize"] = v17 and 13 or 16
}
local v29
if v17 then
	v29 = v_u_5.TEXT_DIM
else
	v29 = v_u_5.TEXT
end
v28.TextColor3 = v29
v28.TextXAlignment = Enum.TextXAlignment.Left
v28.Position = UDim2.fromOffset(0, v17 and 24 or 19)
v28.Size = UDim2.new(1, -48, 0, 18)
v28.Parent = v_u_16
v27(v28)
local v30 = v_u_5.new("TextButton", {
	["Name"] = "Close",
	["Text"] = "",
	["AutoButtonColor"] = false,
	["BackgroundColor3"] = nil,
	["BackgroundTransparency"] = 0,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["BackgroundColor3"] = Color3.fromRGB(24, 26, 33),
	["AnchorPoint"] = Vector2.new(1, 0),
	["Position"] = UDim2.new(1, 0, 0, 0),
	["Size"] = UDim2.fromOffset(34, 34),
	["Parent"] = v_u_16
})
v_u_5.corner(v30, 6)
v_u_5.new("UIStroke", {
	["ApplyStrokeMode"] = nil,
	["Color"] = nil,
	["Transparency"] = 0.88,
	["Thickness"] = 1,
	["Parent"] = nil,
	["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
	["Color"] = Color3.new(1, 1, 1),
	["Parent"] = v30
})
local v31 = v6.make("close", v_u_5.TEXT_DIM, 20)
v31.AnchorPoint = Vector2.new(0.5, 0.5)
v31.Position = UDim2.fromScale(0.5, 0.5)
v31.Parent = v30
local function v49(p32, p33, p34, p_u_35, p_u_36) -- name: chipRow
	-- upvalues: (copy) v_u_5, (copy) v_u_16, (copy) v_u_8, (copy) v_u_12, (copy) v_u_13
	v_u_5.text({
		["Text"] = nil,
		["TextSize"] = 13,
		["FontFace"] = nil,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Text"] = p33,
		["FontFace"] = v_u_5.FONT_BOLD,
		["TextColor3"] = v_u_5.TEXT_DIM,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["AnchorPoint"] = Vector2.new(0, 1),
		["Position"] = UDim2.new(0, 2, 1, p32),
		["Size"] = UDim2.fromOffset(70, 36),
		["Parent"] = v_u_16
	})
	local v37 = v_u_5.new("Frame", {
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0, 1),
		["Position"] = UDim2.new(0, 76, 1, p32),
		["Size"] = UDim2.new(1, -76, 0, 36),
		["Parent"] = v_u_16
	})
	v_u_5.new("UIListLayout", {
		["FillDirection"] = Enum.FillDirection.Horizontal,
		["Padding"] = UDim.new(0, 6),
		["Parent"] = v37
	})
	local v_u_38 = {}
	local function v46() -- name: paint
		-- upvalues: (ref) v_u_8, (copy) p_u_35, (copy) p_u_36, (copy) v_u_38, (ref) v_u_12, (ref) v_u_13, (ref) v_u_5
		local v39 = v_u_8:GetAttribute(p_u_35) or p_u_36
		for v40, v41 in v_u_38 do
			local v42 = v40 == v39
			local v43
			if v42 then
				v43 = v_u_12[1]
			else
				v43 = v_u_13
			end
			v41.BackgroundColor3 = v43
			local v44
			if v42 then
				v44 = v_u_5.DARK_TEXT
			else
				v44 = v_u_5.TEXT_DIM
			end
			v41.TextColor3 = v44
			local v45 = v41:FindFirstChildOfClass("UIStroke")
			if not v45 then
				continue
			end
			v45.Transparency = v42 and 1 or 0.9
		end
	end
	for _, v_u_47 in p34 do
		local v48 = v_u_5.text({
			["ClassName"] = "TextButton",
			["Text"] = nil,
			["TextSize"] = 15,
			["FontFace"] = nil,
			["AutoButtonColor"] = false,
			["BackgroundTransparency"] = 0,
			["BackgroundColor3"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["Text"] = v_u_47[2],
			["FontFace"] = v_u_5.FONT_BOLD,
			["BackgroundColor3"] = v_u_13,
			["Size"] = UDim2.new(1 / #p34, -6, 1, 0),
			["Parent"] = v37
		})
		v_u_5.corner(v48, 5)
		v_u_5.new("UIStroke", {
			["ApplyStrokeMode"] = nil,
			["Color"] = nil,
			["Transparency"] = 0.9,
			["Thickness"] = 1,
			["Parent"] = nil,
			["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
			["Color"] = Color3.new(1, 1, 1),
			["Parent"] = v48
		})
		v48.Activated:Connect(function()
			-- upvalues: (ref) v_u_8, (copy) p_u_35, (copy) v_u_47
			v_u_8:SetAttribute(p_u_35, v_u_47[1])
		end)
		v_u_38[v_u_47[1]] = v48
	end
	v_u_8:GetAttributeChangedSignal(p_u_35):Connect(v46)
	v46()
end
v49(-44, "Time", v9, "TimeOfDay", "Auto")
v49(0, "Weather", v10, "Weather", "Clear")
local function v_u_51(p50) -- name: setOpen
	-- upvalues: (copy) v_u_7, (copy) v_u_16, (copy) v_u_15, (copy) v_u_19, (copy) v_u_3, (copy) v_u_20, (copy) v_u_21
	if p50 ~= v_u_7.isOpen then
		v_u_7.isOpen = p50
		v_u_16.Visible = p50
		v_u_15.Visible = p50
		if p50 then
			v_u_19.Scale = 0.92
			v_u_3:Create(v_u_19, TweenInfo.new(0.25, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
				["Scale"] = 1
			}):Play()
			v_u_20.play()
			v_u_21()
		end
	end
end
v_u_7.changed.Event:Connect(function(p52)
	-- upvalues: (ref) v_u_51, (copy) v_u_7
	if p52 == "open" then
		v_u_51(true)
		return
	elseif p52 == "close" then
		v_u_51(false)
	else
		v_u_51(not v_u_7.isOpen)
	end
end)
v30.Activated:Connect(function()
	-- upvalues: (ref) v_u_51
	v_u_51(false)
end)
v_u_15.Activated:Connect(function()
	-- upvalues: (ref) v_u_51
	v_u_51(false)
end)