-- Path: Players/ygggggg55551/PlayerScripts/TopBar
-- Class: LocalScript  true/Enum.RunContext.Legacy
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = game:GetService("ContextActionService")
local v_u_2 = game:GetService("GuiService")
local v3 = game:GetService("Players")
local v_u_4 = game:GetService("ReplicatedStorage")
local v5 = game:GetService("StarterPlayer")
local v_u_6 = game:GetService("TweenService")
local v7 = game:GetService("UserInputService")
local v8 = v_u_4:WaitForChild("GameUI")
local v_u_9 = require(v8:WaitForChild("Theme"))
local v_u_10 = require(v8:WaitForChild("Icons"))
local v11 = require(v8:WaitForChild("Phone"))
local v_u_12 = require(v8:WaitForChild("Menu"))
local v13 = require(v8:WaitForChild("EmotePanel"))
local v_u_14 = require(v8:WaitForChild("ControlLayout"))
require(v8:WaitForChild("Dash"))
local v_u_15 = v3.LocalPlayer
local v_u_16 = v5.CharacterWalkSpeed
local v17 = Color3.fromRGB(18, 18, 21)
local v_u_18 = Color3.fromRGB(255, 196, 40)
local v_u_19 = TweenInfo.new(0.1)
local v_u_20 = v_u_9.new("ScreenGui", {
	["Name"] = "TopBar",
	["ResetOnSpawn"] = false,
	["ScreenInsets"] = nil,
	["ZIndexBehavior"] = nil,
	["DisplayOrder"] = 60,
	["Parent"] = nil,
	["ScreenInsets"] = Enum.ScreenInsets.TopbarSafeInsets,
	["ZIndexBehavior"] = Enum.ZIndexBehavior.Sibling,
	["Parent"] = v_u_15:WaitForChild("PlayerGui")
})
local v_u_21 = false
local v_u_22 = v_u_9.new("Frame", {
	["Name"] = "Row",
	["BackgroundColor3"] = nil,
	["BackgroundTransparency"] = 0.3,
	["BorderSizePixel"] = 0,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["BackgroundColor3"] = v17,
	["AnchorPoint"] = Vector2.new(0, 1),
	["Position"] = UDim2.new(0, 8, 1, -2),
	["Size"] = UDim2.fromOffset(184, 44),
	["Parent"] = v_u_20
})
v_u_9.new("UICorner", {
	["CornerRadius"] = UDim.new(0.5, 0),
	["Parent"] = v_u_22
})
v_u_9.new("UIPadding", {
	["PaddingLeft"] = UDim.new(0, 4),
	["PaddingRight"] = UDim.new(0, 4),
	["Parent"] = v_u_22
})
v_u_9.new("UIListLayout", {
	["FillDirection"] = Enum.FillDirection.Horizontal,
	["Padding"] = UDim.new(0, 0),
	["SortOrder"] = Enum.SortOrder.LayoutOrder,
	["Parent"] = v_u_22
})
local v_u_23 = game:GetService("RunService")
local v_u_24 = os.clock()
local function v_u_35() -- name: place
	-- upvalues: (copy) v_u_23, (copy) v_u_20, (copy) v_u_2, (copy) v_u_24, (copy) v_u_22, (ref) v_u_21
	local v25
	if v_u_23:IsStudio() and workspace:GetAttribute("ZZTopbarNotReady") == true then
		v25 = false
	else
		local v26 = v_u_20.AbsoluteSize.Y
		if v_u_2.TopbarInset.Height > 0 and v26 > 0 then
			v25 = v26 <= 100
		else
			v25 = false
		end
	end
	local v27 = not v25
	if v27 then
		v27 = os.clock() - v_u_24 >= 12
	end
	v_u_22.Visible = v25 or v27
	if v27 then
		v_u_22.AnchorPoint = Vector2.new(0, 0)
		v_u_22.Position = UDim2.new(0, 8, 0, 8)
	else
		v_u_22.AnchorPoint = Vector2.new(0, 1)
		v_u_22.Position = UDim2.new(0, 8, 1, -2)
	end
	v_u_20:SetAttribute("Placed", v25 or v27)
	local v28 = v_u_20.AbsoluteSize.Y
	local v29
	if v25 then
		local v30 = v28 - 14
		v29 = math.clamp(v30, 32, 64)
	else
		v29 = 44
	end
	local v31 = 0
	for _, v32 in v_u_22:GetChildren() do
		if not (v32:IsA("TextButton") and v32.Visible) then
			continue
		end
		v31 = v31 + 1
	end
	v_u_22.Size = UDim2.fromOffset((v_u_21 and 1 or v31) * v29 + 8, v29)
	v_u_22.ClipsDescendants = v_u_21
	for _, v33 in v_u_22:GetChildren() do
		if not v33:IsA("TextButton") then
			continue
		end
		v33.Size = UDim2.fromOffset(v29, v29)
		local v34 = v33:FindFirstChildWhichIsA("Frame")
		if v34 then
			v34 = v34:FindFirstChildOfClass("UIScale")
		end
		if not v34 then
			continue
		end
		v34.Scale = v29 * 0.6 / 28
	end
end
v_u_20:GetPropertyChangedSignal("AbsoluteSize"):Connect(v_u_35)
v_u_2:GetPropertyChangedSignal("TopbarInset"):Connect(v_u_35)
task.delay(12.1, v_u_35)
local function v43(p36, p37, p38) -- name: button
	-- upvalues: (copy) v_u_9, (copy) v_u_18, (copy) v_u_22, (copy) v_u_10, (copy) v_u_6, (copy) v_u_19
	local v39 = v_u_9.new("TextButton", {
		["Name"] = nil,
		["Text"] = "",
		["AutoButtonColor"] = false,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["LayoutOrder"] = nil,
		["Parent"] = nil,
		["Name"] = p37,
		["BackgroundColor3"] = v_u_18,
		["Size"] = UDim2.fromOffset(44, 44),
		["LayoutOrder"] = p36,
		["Parent"] = v_u_22
	})
	v_u_9.new("UICorner", {
		["CornerRadius"] = UDim.new(0.5, 0),
		["Parent"] = v39
	})
	local v40 = v_u_10.make(p37, Color3.new(1, 1, 1), 26)
	v40.AnchorPoint = Vector2.new(0.5, 0.5)
	v40.Position = UDim2.fromScale(0.5, 0.5)
	v40.Parent = v39
	local v_u_41 = v_u_9.new("UIScale", {
		["Parent"] = v39
	})
	v39.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_6, (copy) v_u_41, (ref) v_u_19
		v_u_6:Create(v_u_41, v_u_19, {
			["Scale"] = 0.9
		}):Play()
	end)
	for _, v42 in { v39.MouseButton1Up, v39.MouseLeave } do
		v42:Connect(function()
			-- upvalues: (ref) v_u_6, (copy) v_u_41, (ref) v_u_19
			v_u_6:Create(v_u_41, v_u_19, {
				["Scale"] = 1
			}):Play()
		end)
	end
	v39.Activated:Connect(p38)
	return v39, v40
end
local v_u_44 = false
local v_u_45 = false
local v_u_46 = nil
local v_u_47 = nil
local function v54() -- name: applyRun
	-- upvalues: (copy) v_u_15, (ref) v_u_44, (ref) v_u_45, (copy) v_u_16, (ref) v_u_46, (ref) v_u_47, (copy) v_u_10
	local v48 = v_u_15.Character
	if v48 then
		v48 = v48:FindFirstChildOfClass("Humanoid")
	end
	local v49 = v_u_44 or v_u_45
	if v48 and not v48.SeatPart then
		v48.WalkSpeed = v49 and 28 or v_u_16
	end
	local v50 = v_u_47
	local v51 = v_u_44
	v_u_46.BackgroundTransparency = v51 and 0.05 or 1
	local v52 = v_u_10.tint
	local v53
	if v51 then
		v53 = Color3.fromRGB(20, 20, 24)
	else
		v53 = Color3.new(1, 1, 1)
	end
	v52(v50, v53)
end
local v61, v62 = v43(1, "run", function()
	-- upvalues: (ref) v_u_44, (copy) v_u_15, (ref) v_u_45, (copy) v_u_16, (ref) v_u_46, (ref) v_u_47, (copy) v_u_10
	v_u_44 = not v_u_44
	local v55 = v_u_15.Character
	if v55 then
		v55 = v55:FindFirstChildOfClass("Humanoid")
	end
	local v56 = v_u_44 or v_u_45
	if v55 and not v55.SeatPart then
		v55.WalkSpeed = v56 and 28 or v_u_16
	end
	local v57 = v_u_47
	local v58 = v_u_44
	v_u_46.BackgroundTransparency = v58 and 0.05 or 1
	local v59 = v_u_10.tint
	local v60
	if v58 then
		v60 = Color3.fromRGB(20, 20, 24)
	else
		v60 = Color3.new(1, 1, 1)
	end
	v59(v57, v60)
end)
v_u_46 = v61
v_u_47 = v62
v43(2, "phone", v11.toggle)
local v_u_63 = v13.build(v_u_20)
local v_u_64 = nil
local v_u_65 = nil
local v_u_66 = nil
local v72, v73 = v43(3, "person", function()
	-- upvalues: (copy) v_u_63, (ref) v_u_64, (ref) v_u_65, (copy) v_u_10, (ref) v_u_66
	v_u_63.toggle()
	local v67 = v_u_64
	local v68 = v_u_65
	local v69 = v_u_63.isOpen()
	v67.BackgroundTransparency = v69 and 0.05 or 1
	local v70 = v_u_10.tint
	local v71
	if v69 then
		v71 = Color3.fromRGB(20, 20, 24)
	else
		v71 = Color3.new(1, 1, 1)
	end
	v70(v68, v71)
	if v_u_63.isOpen() and v_u_66 then
		v_u_66()
	end
end)
v_u_64 = v72
v_u_65 = v73
local v_u_74, v_u_75 = v43(4, "home", v_u_12.toggle)
local v_u_76 = nil
local v_u_77 = nil
local v79, v80 = v43(0, "arrow", function()
	-- upvalues: (ref) v_u_21, (ref) v_u_76, (ref) v_u_77, (copy) v_u_63, (ref) v_u_64, (ref) v_u_65, (copy) v_u_10, (ref) v_u_66, (copy) v_u_35
	v_u_21 = not v_u_21
	v_u_76.Visible = v_u_21
	v_u_77.Visible = not v_u_21
	if v_u_21 then
		if v_u_63.isOpen() then
			v_u_63.setOpen(false)
			local v78 = v_u_65
			v_u_64.BackgroundTransparency = 1
			v_u_10.tint(v78, (Color3.new(1, 1, 1)))
		end
		if v_u_66 then
			v_u_66()
		end
	end
	v_u_35()
end)
local v81 = v79
v81.Name = "Fold"
v80:Destroy()
local v82 = v_u_9.new("Frame", {
	["Name"] = "FoldGlyph",
	["BackgroundTransparency"] = 1,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["AnchorPoint"] = Vector2.new(0.5, 0.5),
	["Position"] = UDim2.fromScale(0.5, 0.5),
	["Size"] = UDim2.fromOffset(28, 28),
	["Parent"] = v81
})
v_u_9.new("UIScale", {
	["Parent"] = v82
})
local function v89(p83, p84, p85, p86, p87) -- name: line
	-- upvalues: (copy) v_u_9
	local v88 = v_u_9.new("Frame", {
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Rotation"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = Color3.new(1, 1, 1),
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.new(0.5, p85, 0.5, p86),
		["Size"] = UDim2.fromOffset(p84, 3),
		["Rotation"] = p87 or 0,
		["Parent"] = p83
	})
	v_u_9.new("UICorner", {
		["CornerRadius"] = UDim.new(0.5, 0),
		["Parent"] = v88
	})
	return v88
end
v_u_76 = v_u_9.new("Frame", {
	["Name"] = "Menu",
	["BackgroundTransparency"] = 1,
	["Size"] = nil,
	["Parent"] = nil,
	["Size"] = UDim2.fromScale(1, 1),
	["Parent"] = v82
})
v89(v_u_76, 18, 0, -6)
v89(v_u_76, 18, 0, 0)
v89(v_u_76, 18, 0, 6)
v_u_77 = v_u_9.new("Frame", {
	["Name"] = "Chevron",
	["BackgroundTransparency"] = 1,
	["Size"] = nil,
	["Parent"] = nil,
	["Size"] = UDim2.fromScale(1, 1),
	["Parent"] = v82
})
v89(v_u_77, 11, -1, -3.6, -45)
v89(v_u_77, 11, -1, 3.6, 45)
v_u_76.Visible = v_u_21
v_u_77.Visible = not v_u_21
if v_u_9.isTouch() then
	local v91, v92 = v43(5, "layout", function()
		-- upvalues: (copy) v_u_63, (ref) v_u_64, (ref) v_u_65, (copy) v_u_10, (ref) v_u_66, (copy) v_u_12, (copy) v_u_14
		if v_u_63.isOpen() then
			v_u_63.setOpen(false)
			local v90 = v_u_65
			v_u_64.BackgroundTransparency = 1
			v_u_10.tint(v90, (Color3.new(1, 1, 1)))
		end
		if v_u_66 then
			v_u_66()
		end
		if v_u_12.isOpen then
			v_u_12.toggle()
		end
		v_u_14.toggle()
	end)
	local v_u_93 = v91
	local v_u_94 = v92
	v_u_14.changed.Event:Connect(function(p95)
		-- upvalues: (ref) v_u_93, (ref) v_u_94, (copy) v_u_10
		local v96 = v_u_94
		v_u_93.BackgroundTransparency = p95 and 0.05 or 1
		local v97 = v_u_10.tint
		local v98
		if p95 then
			v98 = Color3.fromRGB(20, 20, 24)
		else
			v98 = Color3.new(1, 1, 1)
		end
		v97(v96, v98)
	end)
end
if v7.TouchEnabled then
	v43(6, "camera", function()
		-- upvalues: (copy) v_u_63, (ref) v_u_64, (ref) v_u_65, (copy) v_u_10, (ref) v_u_66, (copy) v_u_12, (copy) v_u_15
		if v_u_63.isOpen() then
			v_u_63.setOpen(false)
			local v99 = v_u_65
			v_u_64.BackgroundTransparency = 1
			v_u_10.tint(v99, (Color3.new(1, 1, 1)))
		end
		if v_u_66 then
			v_u_66()
		end
		if v_u_12.isOpen then
			v_u_12.toggle()
		end
		local v100 = v_u_15.PlayerGui:FindFirstChild("FreeCamUI")
		if v100 then
			v100 = v100:FindFirstChild("ToggleFreeCam")
		end
		if v100 then
			v100:Fire()
		end
	end)
end
local v_u_101 = require(v_u_4:WaitForChild("PCX160Shared"))
local v_u_102 = require(v_u_4:WaitForChild("TuckKeyShared"))
local v_u_103 = require(v_u_4:WaitForChild("GameShared"))
local v_u_104 = require(v_u_4:WaitForChild("NetSeal"))
local v_u_105 = nil
local function v_u_110() -- name: tuckAnim
	-- upvalues: (ref) v_u_105
	if v_u_105 == nil then
		local v_u_106 = script.Parent:FindFirstChild("PCX160Client")
		if v_u_106 then
			v_u_106 = v_u_106:FindFirstChild("TuckAnim")
		end
		local v108, v109 = pcall(function()
			-- upvalues: (copy) v_u_106
			local v107 = v_u_106
			if v107 then
				v107 = require(v_u_106)
			end
			return v107
		end)
		v_u_105 = v108 and v109 and v109 or false
	end
	return v_u_105 or nil
end
local v_u_111 = v_u_9.panel({
	["Name"] = "RidePose",
	["Visible"] = false,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["AutomaticSize"] = nil,
	["Parent"] = nil,
	["AnchorPoint"] = Vector2.new(0, 0),
	["Position"] = UDim2.new(0, 8, 1, 8),
	["Size"] = UDim2.fromOffset(250, 0),
	["AutomaticSize"] = Enum.AutomaticSize.Y,
	["Parent"] = v_u_20
})
v_u_9.padding(v_u_111, 10)
v_u_9.new("UIListLayout", {
	["Padding"] = UDim.new(0, 6),
	["SortOrder"] = Enum.SortOrder.LayoutOrder,
	["Parent"] = v_u_111
})
v_u_9.text({
	["Name"] = "Title",
	["Text"] = "\224\184\151\224\185\136\224\184\178\224\184\171\224\184\161\224\184\173\224\184\154",
	["FontFace"] = nil,
	["TextSize"] = 18,
	["TextXAlignment"] = nil,
	["Size"] = nil,
	["LayoutOrder"] = 0,
	["Parent"] = nil,
	["FontFace"] = v_u_9.FONT_HEAVY,
	["TextXAlignment"] = Enum.TextXAlignment.Left,
	["Size"] = UDim2.new(1, 0, 0, 22),
	["Parent"] = v_u_111
})
local v_u_112 = v_u_9.text({
	["Name"] = "Hint",
	["Text"] = "",
	["TextSize"] = 13,
	["TextColor3"] = nil,
	["TextXAlignment"] = nil,
	["TextWrapped"] = true,
	["Size"] = nil,
	["LayoutOrder"] = 1,
	["Parent"] = nil,
	["TextColor3"] = v_u_9.TEXT_DIM,
	["TextXAlignment"] = Enum.TextXAlignment.Left,
	["Size"] = UDim2.new(1, 0, 0, 18),
	["Parent"] = v_u_111
})
local v_u_113 = {}
local v_u_114 = nil
local v_u_115 = nil
local function v_u_124(p116) -- name: poseOptions
	-- upvalues: (copy) v_u_110
	local v117 = v_u_110()
	local v118 = {}
	if v117 then
		for _, v119 in v117.list() do
			local v120
			if p116 == nil then
				v120 = false
			else
				v120 = v117.forBike(v119.name, p116) ~= nil
			end
			local v121 = {
				["key"] = v119.name,
				["label"] = v119.label,
				["fits"] = v120
			}
			table.insert(v118, v121)
		end
	end
	local v122
	if p116 == nil then
		v122 = false
	else
		v122 = p116:GetAttribute("TuckStyle") == "Wing"
	end
	local v123 = {
		["key"] = nil,
		["label"] = nil,
		["fits"] = true,
		["key"] = not v117 and "Code" or v117.CODE_POSE,
		["label"] = v122 and "\224\184\129\224\184\178\224\184\135\224\184\168\224\184\173\224\184\129" or "\224\185\130\224\184\148\224\184\148\224\184\153\224\184\173\224\184\153"
	}
	table.insert(v118, v123)
	return v118
end
local function v_u_136() -- name: refreshPoses
	-- upvalues: (copy) v_u_110, (copy) v_u_15, (copy) v_u_101, (copy) v_u_113, (copy) v_u_124, (copy) v_u_9, (copy) v_u_111, (copy) v_u_112, (copy) v_u_102
	local v125 = v_u_110()
	local v126 = v_u_15.Character
	if v126 then
		v126 = v126:FindFirstChildOfClass("Humanoid")
	end
	if v126 then
		v126 = v126.SeatPart
	end
	local v127 = v_u_101.bikeFromSeat(v126)
	if not v127 or v126 ~= v127:FindFirstChild("VehicleSeat") then
		v127 = nil
	end
	local v128 = not v125 and "Code" or v125.choice(v_u_15)
	for _, v129 in v_u_113 do
		v129:Destroy()
	end
	table.clear(v_u_113)
	for v130, v_u_131 in v_u_124(v127) do
		local v132 = v_u_131.key == v128
		local v133 = v_u_131.label .. (v_u_131.fits and "" or "  (\224\184\132\224\184\177\224\184\153\224\184\153\224\184\181\224\185\137\224\184\162\224\184\177\224\184\135\224\185\132\224\184\161\224\185\136\224\184\161\224\184\181)")
		local v134 = v_u_9.button({
			["name"] = nil,
			["text"] = nil,
			["icon"] = nil,
			["grad"] = nil,
			["textSize"] = 16,
			["size"] = nil,
			["parent"] = nil,
			["name"] = "Pose_" .. v_u_131.key,
			["text"] = v133,
			["icon"] = v132 and "check" or nil,
			["grad"] = v132 and "gold" or "dark",
			["size"] = UDim2.new(1, 0, 0, 40),
			["parent"] = v_u_111
		})
		v134.LayoutOrder = 10 + v130
		v134.Activated:Connect(function()
			-- upvalues: (ref) v_u_15, (copy) v_u_131
			v_u_15:SetAttribute("TuckPoseWant", v_u_131.key)
		end)
		local v135 = v_u_113
		table.insert(v135, v134)
	end
	v_u_112.Text = v_u_9.isTouch() and "\224\185\129\224\184\149\224\184\176\224\184\155\224\184\184\224\185\136\224\184\161 Tuck \224\184\149\224\184\173\224\184\153\224\184\130\224\184\181\224\185\136\224\185\128\224\184\158\224\184\183\224\185\136\224\184\173\224\184\171\224\184\161\224\184\173\224\184\154" or ("\224\184\129\224\184\148 %s \224\184\149\224\184\173\224\184\153\224\184\130\224\184\181\224\185\136\224\185\128\224\184\158\224\184\183\224\185\136\224\184\173\224\184\171\224\184\161\224\184\173\224\184\154"):format(v_u_102.label(v_u_102.keyOf(v_u_15)))
end
local v_u_137 = Color3.fromRGB(255, 128, 112)
local v_u_138 = v7.KeyboardEnabled
if v_u_138 then
	v_u_138 = not v_u_9.isTouch()
end
v_u_9.text({
	["Name"] = "KeyTitle",
	["Text"] = "\224\184\155\224\184\184\224\185\136\224\184\161\224\184\171\224\184\161\224\184\173\224\184\154",
	["FontFace"] = nil,
	["TextSize"] = 16,
	["TextXAlignment"] = nil,
	["Size"] = nil,
	["LayoutOrder"] = 100,
	["Visible"] = nil,
	["Parent"] = nil,
	["FontFace"] = v_u_9.FONT_HEAVY,
	["TextXAlignment"] = Enum.TextXAlignment.Left,
	["Size"] = UDim2.new(1, 0, 0, 24),
	["Visible"] = v_u_138,
	["Parent"] = v_u_111
})
local v_u_139 = v_u_9.button({
	["name"] = "TuckKey",
	["text"] = "",
	["grad"] = "dark",
	["textSize"] = 16,
	["size"] = nil,
	["parent"] = nil,
	["size"] = UDim2.new(1, 0, 0, 40),
	["parent"] = v_u_111
})
v_u_139.LayoutOrder = 101
v_u_139.Visible = v_u_138
local v_u_140 = v_u_9.text({
	["Name"] = "KeyStatus",
	["Text"] = "",
	["TextSize"] = 13,
	["TextColor3"] = nil,
	["TextXAlignment"] = nil,
	["TextWrapped"] = true,
	["Size"] = nil,
	["AutomaticSize"] = nil,
	["LayoutOrder"] = 102,
	["Visible"] = false,
	["Parent"] = nil,
	["TextColor3"] = v_u_9.TEXT_DIM,
	["TextXAlignment"] = Enum.TextXAlignment.Left,
	["Size"] = UDim2.new(1, 0, 0, 0),
	["AutomaticSize"] = Enum.AutomaticSize.Y,
	["Parent"] = v_u_111
})
local v_u_141 = v_u_9.button({
	["name"] = "TuckKeyDefault",
	["text"] = nil,
	["grad"] = "dark",
	["textSize"] = 14,
	["size"] = nil,
	["parent"] = nil,
	["text"] = ("\224\184\129\224\184\165\224\184\177\224\184\154\224\185\132\224\184\155\224\185\131\224\184\138\224\185\137 %s"):format(v_u_102.DEFAULT),
	["size"] = UDim2.new(1, 0, 0, 32),
	["parent"] = v_u_111
})
v_u_141.LayoutOrder = 103
v_u_141.Visible = false
local v_u_142 = false
local v_u_143 = false
local v_u_144 = 0
local function v_u_148() -- name: refreshKey
	-- upvalues: (copy) v_u_102, (copy) v_u_15, (ref) v_u_142, (copy) v_u_9, (copy) v_u_139, (copy) v_u_141, (copy) v_u_138, (copy) v_u_112
	local v145 = v_u_102.keyOf(v_u_15).Name
	if v_u_142 then
		v_u_9.setButton(v_u_139, "gold", "\224\184\129\224\184\148\224\184\155\224\184\184\224\185\136\224\184\161\224\184\151\224\184\181\224\185\136\224\184\136\224\184\176\224\185\131\224\184\138\224\185\137\224\184\171\224\184\161\224\184\173\224\184\154...", v_u_9.DARK_TEXT)
	else
		v_u_9.setButton(v_u_139, "dark", ("%s   (\224\184\132\224\184\165\224\184\180\224\184\129\224\185\128\224\184\158\224\184\183\224\185\136\224\184\173\224\185\128\224\184\155\224\184\165\224\184\181\224\185\136\224\184\162\224\184\153)"):format(v_u_102.label(v145)), Color3.new(1, 1, 1))
	end
	local v146 = v_u_141
	local v147 = v_u_138 and not v_u_142
	if v147 then
		v147 = v145 ~= v_u_102.DEFAULT
	end
	v146.Visible = v147
	v_u_112.Text = v_u_9.isTouch() and "\224\185\129\224\184\149\224\184\176\224\184\155\224\184\184\224\185\136\224\184\161 Tuck \224\184\149\224\184\173\224\184\153\224\184\130\224\184\181\224\185\136\224\185\128\224\184\158\224\184\183\224\185\136\224\184\173\224\184\171\224\184\161\224\184\173\224\184\154" or ("\224\184\129\224\184\148 %s \224\184\149\224\184\173\224\184\153\224\184\130\224\184\181\224\185\136\224\185\128\224\184\158\224\184\183\224\185\136\224\184\173\224\184\171\224\184\161\224\184\173\224\184\154"):format(v_u_102.label(v_u_102.keyOf(v_u_15)))
end
local function v_u_165(p149) -- name: sendKey
	-- upvalues: (ref) v_u_143, (copy) v_u_9, (copy) v_u_140, (copy) v_u_138, (copy) v_u_4, (copy) v_u_103, (copy) v_u_104, (copy) v_u_102, (copy) v_u_137, (copy) v_u_148
	v_u_143 = true
	local v150 = v_u_9.TEXT_DIM
	v_u_140.Text = "\224\184\129\224\184\179\224\184\165\224\184\177\224\184\135\224\184\154\224\184\177\224\184\153\224\184\151\224\184\182\224\184\129..."
	v_u_140.TextColor3 = v150 or v_u_9.TEXT_DIM
	local v151 = v_u_138
	v_u_140.Visible = v151 and true or v151
	local v152 = v_u_4:FindFirstChild(v_u_103.REMOTES)
	if v152 then
		v152 = v152:FindFirstChild("TuckKey")
	end
	local v153, v154, v155
	if v152 then
		local v156 = v_u_104.invoke
		v153, v154, v155 = pcall(v156, v152, p149)
	else
		v153 = false
		v154 = nil
		v155 = nil
	end
	v_u_143 = false
	if v153 and v154 then
		local v157 = ("\224\184\154\224\184\177\224\184\153\224\184\151\224\184\182\224\184\129\224\185\129\224\184\165\224\185\137\224\184\167 \224\184\129\224\184\148 %s \224\184\149\224\184\173\224\184\153\224\184\130\224\184\181\224\185\136\224\185\128\224\184\158\224\184\183\224\185\136\224\184\173\224\184\171\224\184\161\224\184\173\224\184\154"):format(v_u_102.label(p149 or v_u_102.DEFAULT))
		local v158 = v_u_9.GREEN_TEXT
		v_u_140.Text = v157 or ""
		v_u_140.TextColor3 = v158 or v_u_9.TEXT_DIM
		local v159 = v_u_140
		local v160 = v_u_138
		if v160 then
			if v157 == nil then
				v160 = false
			else
				v160 = v157 ~= ""
			end
		end
		v159.Visible = v160
	else
		local v161 = (not v153 or type(v155) ~= "string") and "\224\184\154\224\184\177\224\184\153\224\184\151\224\184\182\224\184\129\224\185\132\224\184\161\224\185\136\224\185\132\224\184\148\224\185\137 \224\184\165\224\184\173\224\184\135\224\185\131\224\184\171\224\184\161\224\185\136\224\184\173\224\184\181\224\184\129\224\184\132\224\184\163\224\184\177\224\185\137\224\184\135" or v155
		local v162 = v_u_137
		v_u_140.Text = v161 or ""
		v_u_140.TextColor3 = v162 or v_u_9.TEXT_DIM
		local v163 = v_u_140
		local v164 = v_u_138
		if v164 then
			if v161 == nil then
				v164 = false
			else
				v164 = v161 ~= ""
			end
		end
		v163.Visible = v164
	end
	v_u_148()
end
local function v_u_185(_, p166, p167) -- name: onCaptureKey
	-- upvalues: (ref) v_u_142, (copy) v_u_1, (copy) v_u_148, (copy) v_u_140, (copy) v_u_9, (copy) v_u_138, (copy) v_u_102, (copy) v_u_137, (ref) v_u_144, (copy) v_u_15, (copy) v_u_165
	if p166 ~= Enum.UserInputState.Begin or not v_u_142 then
		return Enum.ContextActionResult.Sink
	end
	local v168 = p167.KeyCode
	if v168 == Enum.KeyCode.Unknown then
		return Enum.ContextActionResult.Sink
	end
	if v168 == Enum.KeyCode.Escape then
		if v_u_142 then
			v_u_142 = false
			v_u_1:UnbindAction("TuckKeyCapture")
		end
		v_u_148()
		v_u_140.Text = ""
		v_u_140.TextColor3 = v_u_9.TEXT_DIM
		local v169 = v_u_140
		local v170 = v_u_138
		if v170 then
			v170 = false
		end
		v169.Visible = v170
		return Enum.ContextActionResult.Pass
	end
	local v171 = v_u_102.problem(v168.Name)
	if not v171 then
		if v_u_142 then
			v_u_142 = false
			v_u_1:UnbindAction("TuckKeyCapture")
		end
		v_u_148()
		if v168 == v_u_102.keyOf(v_u_15) then
			local v172 = ("\224\184\155\224\184\184\224\185\136\224\184\161\224\184\171\224\184\161\224\184\173\224\184\154\224\185\128\224\184\155\224\185\135\224\184\153 %s \224\184\173\224\184\162\224\184\185\224\185\136\224\185\129\224\184\165\224\185\137\224\184\167"):format(v_u_102.label(v168))
			local v173 = v_u_9.TEXT_DIM
			v_u_140.Text = v172 or ""
			v_u_140.TextColor3 = v173 or v_u_9.TEXT_DIM
			local v174 = v_u_140
			local v175 = v_u_138
			if v175 then
				if v172 == nil then
					v175 = false
				else
					v175 = v172 ~= ""
				end
			end
			v174.Visible = v175
		else
			local v176 = task.spawn
			local v177 = v_u_165
			local v178
			if v168.Name == v_u_102.DEFAULT then
				v178 = nil
			else
				v178 = v168.Name
			end
			v176(v177, v178)
		end
		return Enum.ContextActionResult.Sink
	end
	local v179 = v_u_137
	v_u_140.Text = v171 or ""
	v_u_140.TextColor3 = v179 or v_u_9.TEXT_DIM
	local v180 = v_u_140
	local v181 = v_u_138
	if v181 then
		if v171 == nil then
			v181 = false
		else
			v181 = v171 ~= ""
		end
	end
	v180.Visible = v181
	v_u_144 = v_u_144 + 1
	local v_u_182 = v_u_144
	task.delay(8, function()
		-- upvalues: (ref) v_u_142, (copy) v_u_182, (ref) v_u_144, (ref) v_u_1, (ref) v_u_148, (ref) v_u_140, (ref) v_u_9, (ref) v_u_138
		if v_u_142 and v_u_182 == v_u_144 then
			if v_u_142 then
				v_u_142 = false
				v_u_1:UnbindAction("TuckKeyCapture")
			end
			v_u_148()
			v_u_140.Text = ""
			v_u_140.TextColor3 = v_u_9.TEXT_DIM
			local v183 = v_u_140
			local v184 = v_u_138
			if v184 then
				v184 = false
			end
			v183.Visible = v184
		end
	end)
	return Enum.ContextActionResult.Sink
end
local function v_u_191() -- name: startCapture
	-- upvalues: (ref) v_u_142, (ref) v_u_143, (copy) v_u_138, (copy) v_u_1, (copy) v_u_185, (copy) v_u_9, (copy) v_u_140, (ref) v_u_144, (copy) v_u_148
	if not v_u_142 and (not v_u_143 and v_u_138) then
		v_u_142 = true
		v_u_1:BindActionAtPriority("TuckKeyCapture", v_u_185, false, Enum.ContextActionPriority.High.Value + 1000, Enum.UserInputType.Keyboard)
		local v186 = v_u_9.TEXT_DIM
		v_u_140.Text = "\224\184\129\224\184\148\224\184\155\224\184\184\224\185\136\224\184\161\224\184\154\224\184\153\224\184\132\224\184\181\224\184\162\224\185\140\224\184\154\224\184\173\224\184\163\224\185\140\224\184\148\224\184\151\224\184\181\224\185\136\224\184\136\224\184\176\224\185\131\224\184\138\224\185\137\224\184\171\224\184\161\224\184\173\224\184\154 (\224\184\132\224\184\165\224\184\180\224\184\129\224\184\173\224\184\181\224\184\129\224\184\132\224\184\163\224\184\177\224\185\137\224\184\135\224\184\171\224\184\163\224\184\183\224\184\173\224\184\129\224\184\148 Esc \224\185\128\224\184\158\224\184\183\224\185\136\224\184\173\224\184\162\224\184\129\224\185\128\224\184\165\224\184\180\224\184\129)"
		v_u_140.TextColor3 = v186 or v_u_9.TEXT_DIM
		local v187 = v_u_138
		v_u_140.Visible = v187 and true or v187
		v_u_144 = v_u_144 + 1
		local v_u_188 = v_u_144
		task.delay(8, function()
			-- upvalues: (ref) v_u_142, (copy) v_u_188, (ref) v_u_144, (ref) v_u_1, (ref) v_u_148, (ref) v_u_140, (ref) v_u_9, (ref) v_u_138
			if v_u_142 and v_u_188 == v_u_144 then
				if v_u_142 then
					v_u_142 = false
					v_u_1:UnbindAction("TuckKeyCapture")
				end
				v_u_148()
				v_u_140.Text = ""
				v_u_140.TextColor3 = v_u_9.TEXT_DIM
				local v189 = v_u_140
				local v190 = v_u_138
				if v190 then
					v190 = false
				end
				v189.Visible = v190
			end
		end)
		v_u_148()
	end
end
v_u_139.Activated:Connect(function()
	-- upvalues: (ref) v_u_142, (copy) v_u_1, (copy) v_u_148, (copy) v_u_140, (copy) v_u_9, (copy) v_u_138, (copy) v_u_191
	if v_u_142 then
		if v_u_142 then
			v_u_142 = false
			v_u_1:UnbindAction("TuckKeyCapture")
		end
		v_u_148()
		v_u_140.Text = ""
		v_u_140.TextColor3 = v_u_9.TEXT_DIM
		local v192 = v_u_140
		local v193 = v_u_138
		if v193 then
			v193 = false
		end
		v192.Visible = v193
	else
		v_u_191()
	end
end)
v_u_141.Activated:Connect(function()
	-- upvalues: (ref) v_u_142, (ref) v_u_143, (copy) v_u_165
	if not (v_u_142 or v_u_143) then
		task.spawn(v_u_165, nil)
	end
end)
v_u_15:GetAttributeChangedSignal("TuckKey"):Connect(v_u_148)
v_u_148()
local function v_u_206(p194) -- name: setPosesOpen
	-- upvalues: (copy) v_u_15, (copy) v_u_101, (copy) v_u_136, (copy) v_u_140, (copy) v_u_9, (copy) v_u_138, (copy) v_u_148, (copy) v_u_111, (ref) v_u_114, (copy) v_u_20, (copy) v_u_63, (ref) v_u_64, (ref) v_u_65, (copy) v_u_10, (ref) v_u_142, (copy) v_u_1, (ref) v_u_115
	if p194 then
		local v195 = v_u_15.Character
		if v195 then
			v195 = v195:FindFirstChildOfClass("Humanoid")
		end
		if v195 then
			v195 = v195.SeatPart
		end
		local v196 = v_u_101.bikeFromSeat(v195)
		if not v196 or v195 ~= v196:FindFirstChild("VehicleSeat") then
			v196 = nil
		end
		p194 = v196 ~= nil
	end
	if p194 then
		v_u_136()
		v_u_140.Text = ""
		v_u_140.TextColor3 = v_u_9.TEXT_DIM
		local v197 = v_u_140
		local v198 = v_u_138
		if v198 then
			v198 = false
		end
		v197.Visible = v198
		v_u_148()
		local v199 = v_u_111
		local v200 = UDim2.new
		local v201 = v_u_114.AbsolutePosition.X - v_u_20.AbsolutePosition.X
		v199.Position = v200(0, math.max(8, v201), 1, 8)
		if v_u_63.isOpen() then
			v_u_63.setOpen(false)
			local v202 = v_u_65
			v_u_64.BackgroundTransparency = 1
			v_u_10.tint(v202, (Color3.new(1, 1, 1)))
		end
	else
		if v_u_142 then
			v_u_142 = false
			v_u_1:UnbindAction("TuckKeyCapture")
		end
		v_u_148()
	end
	v_u_111.Visible = p194
	local v203 = v_u_115
	v_u_114.BackgroundTransparency = p194 and 0.05 or 1
	local v204 = v_u_10.tint
	local v205
	if p194 then
		v205 = Color3.fromRGB(20, 20, 24)
	else
		v205 = Color3.new(1, 1, 1)
	end
	v204(v203, v205)
end
v_u_66 = function()
	-- upvalues: (copy) v_u_206
	v_u_206(false)
end
local v207, v208 = v43(7, "rider", function()
	-- upvalues: (copy) v_u_206, (copy) v_u_111
	v_u_206(not v_u_111.Visible)
end)
local v_u_209 = v207
local _ = v208
v_u_209.Visible = false
v_u_15:GetAttributeChangedSignal("TuckPose"):Connect(function()
	-- upvalues: (copy) v_u_111, (copy) v_u_136
	if v_u_111.Visible then
		v_u_136()
	end
end)
local v_u_210 = nil
local function v_u_214() -- name: watchSeat
	-- upvalues: (copy) v_u_15, (copy) v_u_101, (ref) v_u_209, (copy) v_u_35, (copy) v_u_111, (copy) v_u_206
	local v211 = v_u_15.Character
	if v211 then
		v211 = v211:FindFirstChildOfClass("Humanoid")
	end
	if v211 then
		v211 = v211.SeatPart
	end
	local v212 = v_u_101.bikeFromSeat(v211)
	if not v212 or v211 ~= v212:FindFirstChild("VehicleSeat") then
		v212 = nil
	end
	local v213 = v212 ~= nil
	if v_u_209.Visible ~= v213 then
		v_u_209.Visible = v213
		v_u_35()
	end
	if not v213 and v_u_111.Visible then
		v_u_206(false)
	end
end
local function v220(p215) -- name: watchCharacter
	-- upvalues: (ref) v_u_210, (copy) v_u_15, (copy) v_u_214, (copy) v_u_101, (ref) v_u_209, (copy) v_u_35, (copy) v_u_111, (copy) v_u_206
	if v_u_210 then
		v_u_210:Disconnect()
		v_u_210 = nil
	end
	local v216 = p215:WaitForChild("Humanoid", 10)
	if v216 and p215 == v_u_15.Character then
		v_u_210 = v216:GetPropertyChangedSignal("SeatPart"):Connect(function()
			-- upvalues: (ref) v_u_214
			task.defer(v_u_214)
		end)
	end
	local v217 = v_u_15.Character
	if v217 then
		v217 = v217:FindFirstChildOfClass("Humanoid")
	end
	if v217 then
		v217 = v217.SeatPart
	end
	local v218 = v_u_101.bikeFromSeat(v217)
	if not v218 or v217 ~= v218:FindFirstChild("VehicleSeat") then
		v218 = nil
	end
	local v219 = v218 ~= nil
	if v_u_209.Visible ~= v219 then
		v_u_209.Visible = v219
		v_u_35()
	end
	if not v219 and v_u_111.Visible then
		v_u_206(false)
	end
end
v_u_15.CharacterAdded:Connect(v220)
if v_u_15.Character then
	task.spawn(v220, v_u_15.Character)
end
v_u_35()
v_u_12.changed.Event:Connect(function()
	-- upvalues: (copy) v_u_74, (copy) v_u_75, (copy) v_u_12, (copy) v_u_10
	task.defer(function()
		-- upvalues: (ref) v_u_74, (ref) v_u_75, (ref) v_u_12, (ref) v_u_10
		local v221 = v_u_74
		local v222 = v_u_75
		local v223 = v_u_12.isOpen
		v221.BackgroundTransparency = v223 and 0.05 or 1
		local v224 = v_u_10.tint
		local v225
		if v223 then
			v225 = Color3.fromRGB(20, 20, 24)
		else
			v225 = Color3.new(1, 1, 1)
		end
		v224(v222, v225)
	end)
end)
v7.InputBegan:Connect(function(p226, p227)
	-- upvalues: (copy) v_u_15, (ref) v_u_45, (ref) v_u_44, (copy) v_u_16, (ref) v_u_46, (ref) v_u_47, (copy) v_u_10
	if not p227 and p226.KeyCode == Enum.KeyCode.LeftShift then
		local v228 = v_u_15.Character
		if v228 then
			v228 = v228:FindFirstChildOfClass("Humanoid")
		end
		if v228 and not v228.SeatPart then
			v_u_45 = true
			local v229 = v_u_15.Character
			if v229 then
				v229 = v229:FindFirstChildOfClass("Humanoid")
			end
			local v230 = v_u_44 or v_u_45
			if v229 and not v229.SeatPart then
				v229.WalkSpeed = v230 and 28 or v_u_16
			end
			local v231 = v_u_47
			local v232 = v_u_44
			v_u_46.BackgroundTransparency = v232 and 0.05 or 1
			local v233 = v_u_10.tint
			local v234
			if v232 then
				v234 = Color3.fromRGB(20, 20, 24)
			else
				v234 = Color3.new(1, 1, 1)
			end
			v233(v231, v234)
		end
	end
end)
v7.InputEnded:Connect(function(p235)
	-- upvalues: (ref) v_u_45, (copy) v_u_15, (ref) v_u_44, (copy) v_u_16, (ref) v_u_46, (ref) v_u_47, (copy) v_u_10
	if p235.KeyCode == Enum.KeyCode.LeftShift and v_u_45 then
		v_u_45 = false
		local v236 = v_u_15.Character
		if v236 then
			v236 = v236:FindFirstChildOfClass("Humanoid")
		end
		local v237 = v_u_44 or v_u_45
		if v236 and not v236.SeatPart then
			v236.WalkSpeed = v237 and 28 or v_u_16
		end
		local v238 = v_u_47
		local v239 = v_u_44
		v_u_46.BackgroundTransparency = v239 and 0.05 or 1
		local v240 = v_u_10.tint
		local v241
		if v239 then
			v241 = Color3.fromRGB(20, 20, 24)
		else
			v241 = Color3.new(1, 1, 1)
		end
		v240(v238, v241)
	end
end)
v_u_15.CharacterAdded:Connect(function(p242)
	-- upvalues: (copy) v_u_15, (ref) v_u_44, (ref) v_u_45, (copy) v_u_16, (ref) v_u_46, (ref) v_u_47, (copy) v_u_10
	p242:WaitForChild("Humanoid")
	local v243 = v_u_15.Character
	if v243 then
		v243 = v243:FindFirstChildOfClass("Humanoid")
	end
	local v244 = v_u_44 or v_u_45
	if v243 and not v243.SeatPart then
		v243.WalkSpeed = v244 and 28 or v_u_16
	end
	local v245 = v_u_47
	local v246 = v_u_44
	v_u_46.BackgroundTransparency = v246 and 0.05 or 1
	local v247 = v_u_10.tint
	local v248
	if v246 then
		v248 = Color3.fromRGB(20, 20, 24)
	else
		v248 = Color3.new(1, 1, 1)
	end
	v247(v245, v248)
end)
if v_u_15.Character then
	task.spawn(v54)
end