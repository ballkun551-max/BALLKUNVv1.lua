-- Path: ReplicatedStorage/GameUI/IceCreamWork
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game:GetService("UserInputService")
local v_u_5 = require(script.Parent:WaitForChild("Theme"))
local v_u_6 = {}
local v_u_7 = nil
local v_u_8 = {
	["vanilla"] = Color3.fromRGB(255, 248, 230),
	["strawberry"] = Color3.fromRGB(255, 180, 202)
}
local v_u_9 = Color3.fromRGB(226, 168, 88)
local v_u_10 = Color3.fromRGB(214, 22, 46)
Color3.fromRGB(34, 28, 32)
local v_u_11 = CFrame.Angles(0, 0, 1.5707963267948966)
local function v_u_22(p12, p13, p14, p15, p16, p17, p18) -- name: prop
	local v19 = Instance.new("Part")
	v19.Name = p13
	v19.Size = p14
	v19.CFrame = p15
	v19.Color = p16
	v19.Material = p17 or Enum.Material.SmoothPlastic
	v19.Anchored = true
	v19.CanCollide = false
	v19.CanQuery = false
	v19.CanTouch = false
	v19.CastShadow = false
	v19.TopSurface = Enum.SurfaceType.Smooth
	v19.BottomSurface = Enum.SurfaceType.Smooth
	for v20, v21 in p18 or {} do
		v19[v20] = v21
	end
	v19.Parent = p12
	return v19
end
local function v_u_32(p23, p24, p25, p26, p27, p28, p29, p30) -- name: cyl
	-- upvalues: (copy) v_u_22, (copy) v_u_11
	local v31 = p30 or {}
	v31.Shape = Enum.PartType.Cylinder
	return v_u_22(p23, p24, Vector3.new(p26, p25, p25), CFrame.new(p27) * v_u_11, p28, p29, v31)
end
local function v_u_39(p33, p34, p35, p36, p37, p38) -- name: ball
	-- upvalues: (copy) v_u_22
	return v_u_22(p33, p34, Vector3.new(p35, p35, p35), CFrame.new(p36), p37, p38, {
		["Shape"] = Enum.PartType.Ball
	})
end
local v_u_40 = script:WaitForChild("Props", 5)
local function v_u_56(p41, p42, p43, p44, p45, p46) -- name: place
	-- upvalues: (copy) v_u_40
	local v47 = v_u_40
	if v47 then
		v47 = v_u_40:FindFirstChild(p42)
	end
	local v48 = v47 ~= nil and v47:IsA("MeshPart")
	if v48 then
		v48 = v47.MeshId ~= ""
	end
	if not v48 then
		return nil
	end
	local v49 = p44 or 1
	local v50 = v47:Clone()
	v50.Size = v47.Size * v49
	local v51 = p43 * CFrame.new((v47:GetAttribute("At") or Vector3.new(0, 0, 0)) * v49)
	local v52 = CFrame.Angles
	local v53 = v47:GetAttribute("Turn") or 0
	v50.CFrame = v51 * v52(0, math.rad(v53), 0)
	if p45 then
		v50.Color = p45
	end
	for v54, v55 in p46 or {} do
		v50[v54] = v55
	end
	v50.Parent = p41
	return v50
end
local function v_u_59(p57, p58) -- name: glassAt
	-- upvalues: (copy) v_u_56
	return v_u_56(p57, "Glass", CFrame.new(p58), 1, Color3.fromRGB(226, 242, 255), {
		["Material"] = nil,
		["Transparency"] = 0.55,
		["Material"] = Enum.Material.Glass
	})
end
local function v_u_69(p60, p61) -- name: ice
	-- upvalues: (copy) v_u_22
	for v62 = 1, 3 do
		local v63 = v62 / 3 * 3.141592653589793 * 2 + 0.4
		local v64 = v_u_22
		local v65 = CFrame.new
		local v66 = math.cos(v63) * 0.12
		local v67 = v62 * 0.05 + 0.08
		local v68 = math.sin(v63) * 0.12
		v64(p60, "Ice", Vector3.new(0.14, 0.14, 0.14), v65(p61 + Vector3.new(v66, v67, v68)) * CFrame.Angles(v62, v62 * 0.7, v62 * 0.3), Color3.fromRGB(214, 236, 250), Enum.Material.Ice)
	end
end
local function v_u_97(p70, p71, p72, p73, p74) -- name: swirlAt
	-- upvalues: (copy) v_u_40, (copy) v_u_11
	local v75 = v_u_40 and v_u_40:GetAttribute("SwirlCount") or 0
	if v75 <= 0 then
		return nil
	end
	local v76 = {}
	for v77 = 1, v75 do
		local v78 = v_u_40:FindFirstChild(("Swirl%02d"):format(v77))
		local v79 = v78 ~= nil and v78:IsA("MeshPart")
		if v79 then
			v79 = v78.MeshId ~= ""
		end
		if not v79 then
			return nil
		end
		local v80 = v78:Clone()
		v80.Size = v78.Size * p72
		local v81 = p71 * CFrame.new(v78:GetAttribute("At") * p72)
		local v82 = CFrame.Angles
		local v83 = v78:GetAttribute("Turn") or 0
		v80.CFrame = v81 * v82(0, math.rad(v83), 0)
		v80.Color = p73
		local v84 = (v77 - 0.5) / v75
		local v85
		if v84 < 0.72 then
			local v86 = 0.215 * (1 - 0.86 * v84) * p72
			v85 = Instance.new("Part")
			v85.Name = "Core"
			v85.Shape = Enum.PartType.Cylinder
			local v87 = 0.12 * p72
			local v88 = v86 * 2
			local v89 = v86 * 2
			v85.Size = Vector3.new(v87, v88, v89)
			v85.CFrame = p71 * CFrame.new(0, (0.085 + 0.5 * v84) * p72, 0) * v_u_11
			v85.Color = p73
			v85.Material = Enum.Material.SmoothPlastic
			v85.Anchored = true
			v85.CanCollide = false
			v85.CanQuery = false
			v85.CanTouch = false
			v85.CastShadow = false
			local v90 = Enum.SurfaceType.Smooth
			local v91 = Enum.SurfaceType.Smooth
			v85.TopSurface = v90
			v85.BottomSurface = v91
			v85.Parent = v80
		else
			v85 = nil
		end
		if v77 == 1 and v85 then
			local v92 = v85:Clone()
			v92.Name = "Mouth"
			local v93 = 0.09 * p72
			local v94 = 0.53 * p72
			local v95 = 0.53 * p72
			v92.Size = Vector3.new(v93, v94, v95)
			v92.CFrame = p71 * CFrame.new(0, 0.03 * p72, 0) * v_u_11
			v92.Parent = v80
		end
		local v96
		if p74 then
			v96 = p70
		else
			v96 = nil
		end
		v80.Parent = v96
		v76[v77] = v80
	end
	return v76
end
local function v_u_110(p98, p99, p100) -- name: cone
	-- upvalues: (copy) v_u_56, (copy) v_u_32, (copy) v_u_9
	local v101 = p100 or 1
	if not v_u_56(p98, "Cone", CFrame.new(p99), v101) then
		for v102 = 0, 7 do
			local v103 = (0.52 - v102 * 0.058) * v101
			local v104 = v_u_32
			local v105 = "Cone"
			local v106 = 0.1 * v101
			local v107 = (v102 * 0.1 + 0.05) * v101
			local v108 = p99 - Vector3.new(0, v107, 0)
			local v109
			if v102 % 2 == 0 then
				v109 = v_u_9
			else
				v109 = v_u_9:Lerp(Color3.fromRGB(120, 70, 20), 0.2)
			end
			v104(p98, v105, v103, v106, v108, v109)
		end
		v_u_32(p98, "ConeRim", 0.58 * v101, 0.08 * v101, p99, Color3.fromRGB(236, 182, 104))
	end
end
local function v_u_123(p111, p112, p113) -- name: cup
	-- upvalues: (copy) v_u_56, (copy) v_u_32, (copy) v_u_10
	local v114 = p113 or 1
	if not v_u_56(p111, "Cup", CFrame.new(p112), v114) then
		local v115 = v_u_32
		local v116 = 0.66 * v114
		local v117 = 0.56 * v114
		local v118 = 0.28 * v114
		v115(p111, "Cup", v116, v117, p112 - Vector3.new(0, v118, 0), Color3.fromRGB(250, 250, 250))
		local v119 = v_u_32
		local v120 = 0.68 * v114
		local v121 = 0.14 * v114
		local v122 = 0.3 * v114
		v119(p111, "CupBand", v120, v121, p112 - Vector3.new(0, v122, 0), v_u_10)
	end
end
local function v_u_142(p124, p125, p126, p127) -- name: pile
	-- upvalues: (copy) v_u_97, (copy) v_u_39
	local v128 = p127 or 1
	if v_u_97(p124, CFrame.new(p125) * CFrame.Angles(0, math.random() * 3.141592653589793 * 2, 0), v128, p126, true) then
		return true
	end
	for v129 = 0, 5 do
		local v130 = v129 / 6
		local v131 = (1 - v130 * 0.8) * 0.2 * v128
		for v132 = 0, 7 do
			local v133 = v132 / 8 * 3.141592653589793 * 2 + v129 * 0.5
			local v134 = v_u_39
			local v135 = (0.2 - v130 * 0.08) * v128
			local v136 = math.cos(v133) * v131
			local v137 = (v130 * 0.48 + 0.06) * v128
			local v138 = math.sin(v133) * v131
			v134(p124, "Cream", v135, p125 + Vector3.new(v136, v137, v138), p126)
		end
	end
	local v139 = v_u_39
	local v140 = 0.12 * v128
	local v141 = 0.6 * v128
	v139(p124, "Tip", v140, p125 + Vector3.new(0, v141, 0), p126)
end
local function v_u_162(p143) -- name: hud
	-- upvalues: (copy) v_u_1, (copy) v_u_5, (copy) v_u_10
	local v144 = v_u_1.LocalPlayer:WaitForChild("PlayerGui")
	local v145 = v144:FindFirstChild("WorkHud") or v_u_5.screen("WorkHud", 6, v144)
	local v146 = v_u_5.isTouch()
	local v147 = v_u_5.new("Frame", {
		["Name"] = "IceCreamWorkHud",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 5,
		["Parent"] = nil,
		["Size"] = UDim2.fromScale(1, 1),
		["Parent"] = v145
	})
	local v148 = v_u_5.new("Frame", {
		["Name"] = "Progress",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = nil,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0),
		["Position"] = UDim2.new(0.5, 0, 0, v146 and 78 or 160),
		["Size"] = UDim2.fromOffset(v146 and 330 or 450, v146 and 28 or 34),
		["BackgroundColor3"] = Color3.fromRGB(252, 252, 252),
		["Parent"] = v147
	})
	v_u_5.corner(v148, 12)
	local v149 = {
		["Color"] = nil,
		["Thickness"] = 2,
		["Transparency"] = 0.35,
		["Parent"] = nil,
		["Color"] = v_u_10,
		["Parent"] = v148
	}
	v_u_5.new("UIStroke", v149)
	v_u_5.autoScale(v148)
	local v150 = v_u_5.new("Frame", {
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = Color3.fromRGB(228, 224, 226),
		["AnchorPoint"] = Vector2.new(0, 0.5),
		["Position"] = UDim2.new(0, 14, 0.5, 0),
		["Size"] = UDim2.new(1, -86, 0, 10),
		["Parent"] = v148
	})
	v_u_5.corner(v150, 5)
	local v_u_151 = v_u_5.new("Frame", {
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_10,
		["Size"] = UDim2.fromScale(0, 1),
		["Parent"] = v150
	})
	v_u_5.corner(v_u_151, 5)
	v_u_5.new("UIGradient", {
		["Color"] = ColorSequence.new(Color3.fromRGB(250, 70, 90), Color3.fromRGB(190, 10, 34)),
		["Parent"] = v_u_151
	})
	local v_u_152 = v_u_5.text({
		["Text"] = "0%",
		["FontFace"] = nil,
		["TextSize"] = nil,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["FontFace"] = v_u_5.FONT_HEAVY,
		["TextSize"] = v146 and 15 or 18,
		["TextColor3"] = v_u_10,
		["TextXAlignment"] = Enum.TextXAlignment.Right,
		["AnchorPoint"] = Vector2.new(1, 0.5),
		["Position"] = UDim2.new(1, -14, 0.5, 0),
		["Size"] = UDim2.fromOffset(60, 24),
		["Parent"] = v148
	})
	local v153 = v_u_5.new("Frame", {
		["Name"] = "Hint",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.2,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 1),
		["Position"] = UDim2.new(0.5, 0, 1, v146 and -150 or -96),
		["Size"] = UDim2.fromOffset(0, v146 and 44 or 52),
		["AutomaticSize"] = Enum.AutomaticSize.X,
		["BackgroundColor3"] = Color3.fromRGB(18, 16, 20),
		["Parent"] = v147
	})
	v_u_5.corner(v153, v146 and 22 or 26)
	v_u_5.new("UIStroke", {
		["Color"] = nil,
		["Transparency"] = 0.8,
		["Thickness"] = 1,
		["Parent"] = nil,
		["Color"] = Color3.new(1, 1, 1),
		["Parent"] = v153
	})
	v_u_5.new("UIPadding", {
		["PaddingLeft"] = UDim.new(0, 8),
		["PaddingRight"] = UDim.new(0, 20),
		["Parent"] = v153
	})
	v_u_5.new("UIListLayout", {
		["FillDirection"] = Enum.FillDirection.Horizontal,
		["VerticalAlignment"] = Enum.VerticalAlignment.Center,
		["Padding"] = UDim.new(0, 12),
		["SortOrder"] = Enum.SortOrder.LayoutOrder,
		["Parent"] = v153
	})
	v_u_5.autoScale(v153)
	local v154 = v_u_5.new("TextButton", {
		["Name"] = "Quit",
		["Text"] = "\224\184\173\224\184\173\224\184\129",
		["FontFace"] = nil,
		["TextSize"] = nil,
		["TextColor3"] = nil,
		["AutoButtonColor"] = true,
		["BackgroundColor3"] = nil,
		["Size"] = nil,
		["LayoutOrder"] = 1,
		["Parent"] = nil,
		["FontFace"] = v_u_5.FONT_HEAVY,
		["TextSize"] = v146 and 14 or 16,
		["TextColor3"] = Color3.new(1, 1, 1),
		["BackgroundColor3"] = v_u_10,
		["Size"] = UDim2.fromOffset(v146 and 52 or 60, v146 and 32 or 38),
		["Parent"] = v153
	})
	v_u_5.corner(v154, v146 and 16 or 19)
	local v_u_155 = v_u_5.text({
		["Text"] = nil,
		["FontFace"] = nil,
		["TextSize"] = nil,
		["TextColor3"] = nil,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = 2,
		["Parent"] = nil,
		["Text"] = p143,
		["FontFace"] = v_u_5.FONT_BOLD,
		["TextSize"] = v146 and 15 or 19,
		["TextColor3"] = Color3.new(1, 1, 1),
		["Size"] = UDim2.fromScale(0, 1),
		["AutomaticSize"] = Enum.AutomaticSize.X,
		["Parent"] = v153
	})
	return {
		["root"] = v147,
		["quit"] = v154,
		["set"] = function(p156) -- name: set
			-- upvalues: (copy) v_u_151, (copy) v_u_152
			local v157 = math.clamp(p156, 0, 1)
			v_u_151.Size = UDim2.fromScale(v157, 1)
			local v158 = v_u_152
			local v159 = v157 * 100 + 0.5
			v158.Text = ("%d%%"):format((math.floor(v159)))
		end,
		["hint"] = function(p160, p161) -- name: hint
			-- upvalues: (copy) v_u_155
			v_u_155.Text = p160
			v_u_155.TextColor3 = p161 or Color3.new(1, 1, 1)
		end
	}
end
local v_u_163 = Color3.fromRGB(255, 214, 80)
local function v_u_169(p164, p165, p166) -- name: dot
	-- upvalues: (copy) v_u_5, (copy) v_u_10
	local v167 = v_u_5.new("Frame", {
		["AnchorPoint"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Size"] = UDim2.fromOffset(p165, p165),
		["BackgroundColor3"] = p166 or Color3.new(1, 1, 1),
		["Parent"] = p164
	})
	v_u_5.corner(v167, p165)
	local v168 = {
		["Color"] = nil,
		["Thickness"] = 2,
		["Transparency"] = 0.1,
		["Parent"] = nil,
		["Color"] = v_u_10,
		["Parent"] = v167
	}
	v_u_5.new("UIStroke", v168)
	return v167
end
local function v_u_171(p170) -- name: guideFrame
	-- upvalues: (copy) v_u_5
	return v_u_5.new("Frame", {
		["Name"] = "Guide",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 2,
		["Parent"] = nil,
		["Size"] = UDim2.fromScale(1, 1),
		["Parent"] = p170.hud.root
	})
end
local function v_u_173(p172) -- name: hand
	-- upvalues: (copy) v_u_5
	return v_u_5.text({
		["Text"] = "\240\159\145\134",
		["TextSize"] = 40,
		["AnchorPoint"] = nil,
		["Size"] = nil,
		["ZIndex"] = 3,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.2, 0.05),
		["Size"] = UDim2.fromOffset(48, 48),
		["Parent"] = p172
	})
end
local v_u_300 = {
	["swirl"] = function(p_u_174) -- name: swirl
		-- upvalues: (copy) v_u_8, (copy) v_u_123, (copy) v_u_110, (copy) v_u_97, (copy) v_u_56, (copy) v_u_32, (copy) v_u_11, (copy) v_u_4, (copy) v_u_171, (copy) v_u_169, (copy) v_u_173, (copy) v_u_5, (copy) v_u_2, (copy) v_u_163, (copy) v_u_39, (copy) v_u_22
		local v175 = p_u_174.kitchen:FindFirstChild("SoftServeMachine")
		local v176
		if v175 then
			v176 = v175:FindFirstChild("Head")
		else
			v176 = v175
		end
		if not v176 then
			return p_u_174.finish(nil)
		end
		local v177 = p_u_174.opts.flavor == "strawberry"
		local v_u_178
		if v177 then
			v_u_178 = v_u_8.strawberry
		else
			v_u_178 = v_u_8.vanilla
		end
		local v_u_179 = v176.Position + Vector3.new(0.15, -0.46, v177 and 0.55 or -0.55)
		local v_u_180 = v_u_179.Y - 0.66
		local v181 = v_u_179.X
		local v182 = v_u_179.Z
		local v_u_183 = Vector3.new(v181, v_u_180, v182)
		if p_u_174.opts.cup then
			v_u_123(p_u_174.folder, v_u_183 + Vector3.new(0, 0.02, 0))
		else
			v_u_110(p_u_174.folder, v_u_183)
		end
		local v_u_184 = p_u_174.opts.cup and 0.1 or 0
		local v_u_185 = p_u_174.opts.cup and 1.12 or 1
		local v_u_186 = v_u_97(p_u_174.folder, CFrame.new(v_u_183 - Vector3.new(0, v_u_184, 0)) * CFrame.Angles(0, math.random() * 3.141592653589793 * 2, 0), v_u_185, v_u_178, false)
		p_u_174.camera(CFrame.lookAt(v_u_179 + Vector3.new(2.6, 0.25, 0.3), v_u_183 + Vector3.new(0, 0.32, 0)), 44)
		local v_u_187 = v175:FindFirstChild(v177 and "LeverS" or "LeverV")
		local v_u_188
		if v_u_187 then
			v_u_188 = v_u_187:FindFirstChild("Knob")
		else
			v_u_188 = v_u_187
		end
		local v_u_189
		if v_u_187 then
			v_u_189 = v_u_187.CFrame
		else
			v_u_189 = v_u_187
		end
		local v_u_190
		if v_u_188 then
			v_u_190 = v_u_188.CFrame
		else
			v_u_190 = v_u_188
		end
		local function v_u_193(p191) -- name: pull
			-- upvalues: (copy) v_u_187, (copy) v_u_189, (copy) v_u_188, (copy) v_u_190
			if v_u_187 then
				local v192
				if p191 then
					v192 = v_u_189 * CFrame.new(0, -0.4, 0) * CFrame.Angles(0, 0, 0.6981317007977318) * CFrame.new(0, 0.4, 0)
				else
					v192 = v_u_189
				end
				v_u_187.CFrame = v192
				if v_u_188 then
					v_u_188.CFrame = v192 * v_u_189:ToObjectSpace(v_u_190)
				end
			end
		end
		local v194 = p_u_174.undo
		table.insert(v194, function()
			-- upvalues: (copy) v_u_193
			v_u_193(false)
		end)
		local v_u_195 = v_u_56(p_u_174.folder, "Ribbon", CFrame.new(v_u_179), 1, v_u_178) or v_u_32(p_u_174.folder, "Stream", 0.13, 0.1, v_u_179, v_u_178)
		v_u_195.Transparency = 1
		local v_u_196 = v_u_195:GetAttribute("Kind") == "ribbon"
		local function v_u_202(p197, p198) -- name: setStream
			-- upvalues: (copy) v_u_196, (copy) v_u_195, (copy) v_u_179, (ref) v_u_11
			if v_u_196 then
				local v199 = v_u_195
				local v200 = v_u_195.Size.X
				local v201 = v_u_195.Size.Z
				v199.Size = Vector3.new(v200, p197, v201)
				v_u_195.CFrame = CFrame.new(v_u_179.X, p198, v_u_179.Z)
			else
				v_u_195.Size = Vector3.new(p197, 0.13, 0.13)
				v_u_195.CFrame = CFrame.new(v_u_179.X, p198, v_u_179.Z) * v_u_11
			end
		end
		local v_u_203 = v_u_186 and #v_u_186 or 64
		local v_u_204 = 0
		local v_u_205 = 0
		local v_u_206 = 0
		local v_u_207 = 0
		local v_u_208 = 1
		local v_u_209 = 0
		local v_u_210 = nil
		local v_u_211 = false
		local v_u_212 = false
		local v_u_213 = nil
		local v_u_214 = 0
		local v215 = p_u_174.conns
		local v216 = v_u_4.InputBegan
		local function v223(p217, p218)
			-- upvalues: (ref) v_u_211, (ref) v_u_213, (copy) v_u_183, (ref) v_u_212
			if p218 then
				return
			elseif p217.UserInputType == Enum.UserInputType.MouseButton1 and true or p217.UserInputType == Enum.UserInputType.Touch then
				v_u_211 = true
				local v219 = p217.Position
				local v220 = workspace.CurrentCamera:WorldToScreenPoint(v_u_183 + Vector3.new(0, 0.25, 0))
				local v221 = v219.Y - v220.Y
				local v222 = v219.X - v220.X
				v_u_213 = math.atan2(v221, v222)
			elseif p217.KeyCode == Enum.KeyCode.Space then
				v_u_212 = true
			end
		end
		table.insert(v215, v216:Connect(v223))
		local v224 = p_u_174.conns
		local v225 = v_u_4.InputChanged
		local function v234(p226)
			-- upvalues: (ref) v_u_211, (copy) v_u_183, (ref) v_u_213, (ref) v_u_214, (ref) v_u_206
			if v_u_211 and (p226.UserInputType == Enum.UserInputType.MouseMovement or p226.UserInputType == Enum.UserInputType.Touch) then
				local v227 = p226.Position
				local v228 = workspace.CurrentCamera:WorldToScreenPoint(v_u_183 + Vector3.new(0, 0.25, 0))
				local v229 = v227.Y - v228.Y
				local v230 = v227.X - v228.X
				local v231 = math.atan2(v229, v230)
				if v_u_213 then
					local v232 = v231 - v_u_213
					if v232 > 3.141592653589793 then
						v232 = v232 - 6.283185307179586
					elseif v232 < -3.141592653589793 then
						v232 = v232 + 6.283185307179586
					end
					local v233 = math.clamp(v232, -0.8, 0.8)
					v_u_214 = v_u_214 + math.abs(v233)
					v_u_206 = v_u_206 + v233
				end
				v_u_213 = v231
			end
		end
		table.insert(v224, v225:Connect(v234))
		local v235 = p_u_174.conns
		local v236 = v_u_4.InputEnded
		local function v238(p237)
			-- upvalues: (ref) v_u_211, (ref) v_u_213, (ref) v_u_212
			if p237.UserInputType == Enum.UserInputType.MouseButton1 and true or p237.UserInputType == Enum.UserInputType.Touch then
				v_u_211 = false
				v_u_213 = nil
			elseif p237.KeyCode == Enum.KeyCode.Space then
				v_u_212 = false
			end
		end
		table.insert(v235, v236:Connect(v238))
		local v_u_239 = v_u_171(p_u_174)
		local v_u_240 = v_u_212
		local v_u_241 = v_u_214
		local v_u_242 = v_u_206
		local v_u_243 = v_u_211
		local v_u_244 = {}
		local v_u_245 = false
		local v_u_246 = 0
		local v_u_247 = 0
		for v248 = 1, 28 do
			v_u_244[v248] = v_u_169(v_u_239, 10)
		end
		local v_u_249 = v_u_173(v_u_239)
		local v_u_250 = v_u_5.text({
			["Text"] = "\224\184\165\224\184\178\224\184\129\224\184\167\224\184\153\224\184\149\224\184\178\224\184\161\224\185\128\224\184\170\224\185\137\224\184\153 \226\159\179",
			["FontFace"] = nil,
			["TextSize"] = 20,
			["TextColor3"] = nil,
			["TextStrokeTransparency"] = 0.3,
			["AnchorPoint"] = nil,
			["Size"] = nil,
			["ZIndex"] = 3,
			["Parent"] = nil,
			["FontFace"] = v_u_5.FONT_HEAVY,
			["TextColor3"] = Color3.new(1, 1, 1),
			["AnchorPoint"] = Vector2.new(0.5, 1),
			["Size"] = UDim2.fromOffset(240, 26),
			["Parent"] = v_u_239
		})
		local v_u_251 = v_u_183 + Vector3.new(0, 0.3, 0)
		local v252 = p_u_174.conns
		local v253 = v_u_2.RenderStepped
		local function v299(p254)
			-- upvalues: (ref) v_u_245, (copy) v_u_239, (ref) v_u_243, (ref) v_u_240, (ref) v_u_241, (copy) v_u_251, (copy) v_u_244, (ref) v_u_163, (copy) v_u_249, (copy) v_u_250, (copy) v_u_193, (ref) v_u_247, (ref) v_u_246, (ref) v_u_242, (ref) v_u_205, (ref) v_u_204, (copy) v_u_203, (copy) v_u_186, (copy) p_u_174, (ref) v_u_209, (ref) v_u_208, (ref) v_u_207, (copy) v_u_183, (ref) v_u_39, (copy) v_u_178, (ref) v_u_210, (ref) v_u_22, (copy) v_u_180, (copy) v_u_184, (copy) v_u_185, (copy) v_u_179, (copy) v_u_202, (copy) v_u_195
			if v_u_245 then
				v_u_239.Visible = false
			else
				local v255 = v_u_243 or v_u_240
				local v256 = v_u_241 / math.max(p254, 0.001)
				local v257 = workspace.CurrentCamera
				local v258 = v_u_251
				local v259 = workspace.CurrentCamera:WorldToScreenPoint(v258)
				local v260 = Vector2.new(v259.X, v259.Y)
				local v261 = v_u_251 + v257.CFrame.RightVector * 0.36
				local v262 = workspace.CurrentCamera:WorldToScreenPoint(v261)
				local v263 = (Vector2.new(v262.X, v262.Y) - v260).Magnitude
				local v264 = math.clamp(v263, 50, 150)
				local v265 = os.clock() * 2.6
				for v266, v267 in v_u_244 do
					local v268 = v266 / #v_u_244 * 3.141592653589793 * 2
					v267.Position = UDim2.fromOffset(v260.X + math.cos(v268) * v264, v260.Y + math.sin(v268) * v264)
					local v269 = (v265 - v268) % 6.283185307179586 < 1.2
					local v270
					if v269 then
						v270 = v_u_163
					else
						v270 = Color3.new(1, 1, 1)
					end
					v267.BackgroundColor3 = v270
					v267.BackgroundTransparency = v255 and v256 > 1.5 and 0.55 or (v269 and 0 or 0.25)
					v267.Size = UDim2.fromOffset(v269 and 13 or 9, v269 and 13 or 9)
				end
				local v271 = v_u_249
				local v272
				if v255 then
					v272 = v256 > 1.5
				else
					v272 = v255
				end
				v271.Visible = not v272
				v_u_249.Position = UDim2.fromOffset(v260.X + math.cos(v265) * v264, v260.Y + math.sin(v265) * v264)
				v_u_250.Position = UDim2.fromOffset(v260.X, v260.Y + v264 + 40)
				v_u_241 = 0
				v_u_193(v255)
				if v255 then
					v_u_247 = v_u_247 + p254
					if v256 > 1.5 then
						v_u_246 = v_u_246 + p254
					else
						v_u_242 = v_u_242 + p254 * 2.6
					end
					local v273 = v_u_205 + p254 * (math.min(v256, 8) * 0.03 + 0.16)
					v_u_205 = math.min(1, v273)
				end
				while true do
					local v274 = v_u_204
					local v275 = v_u_205 * v_u_203
					if v274 >= math.floor(v275) then
						break
					end
					v_u_204 = v_u_204 + 1
					if v_u_186 then
						v_u_186[v_u_204].Parent = p_u_174.folder
					else
						local v276 = v_u_204 / v_u_203
						local v277 = v_u_242 - v_u_209
						if math.abs(v277) > 0.05 then
							v_u_208 = v_u_209 < v_u_242 and 1 or -1
						end
						v_u_209 = v_u_242
						v_u_207 = v_u_207 + v_u_208 * (20.106192982974676 / v_u_203)
						local v278 = (1 - v276 * 0.88) * 0.23
						local v279 = v_u_183
						local v280 = v_u_207
						local v281 = math.cos(v280) * v278
						local v282 = v276 * 0.52 + 0.07
						local v283 = v_u_207
						local v284 = math.sin(v283) * v278
						local v285 = v279 + Vector3.new(v281, v282, v284)
						local v286 = 0.19 - v276 * 0.09
						v_u_39(p_u_174.folder, "Cream", v286, v285, v_u_178)
						if v_u_210 then
							local v287 = (v285 - v_u_210).Magnitude
							if v287 > 0.005 then
								local v288 = v_u_22
								local v289 = p_u_174.folder
								local v290 = v287 + 0.02
								v288(v289, "Cream", Vector3.new(v290, v286, v286), CFrame.lookAt((v285 + v_u_210) / 2, v285) * CFrame.Angles(0, 1.5707963267948966, 0), v_u_178, nil, {
									["Shape"] = Enum.PartType.Cylinder
								})
							end
						end
						v_u_210 = v285
					end
				end
				local v291 = v_u_180 + 0.06 + v_u_205 * 0.5
				if v_u_186 then
					v291 = v_u_180 - v_u_184 + (v_u_204 <= 0 and 0 or (v_u_186[v_u_204]:GetAttribute("Top") or 0) * v_u_185 - 0.04)
				end
				if v255 then
					local v292 = v_u_179.Y - 0.12 - v291
					local v293 = math.max(0.05, v292)
					v_u_202(v293, v291 + v293 / 2)
					v_u_195.Transparency = 0
				else
					v_u_195.Transparency = 1
				end
				p_u_174.hud.set(v_u_205)
				if v255 then
					if v256 < 1.5 then
						p_u_174.hud.hint("\224\184\167\224\184\153\224\184\148\224\185\137\224\184\167\224\184\162! \224\185\132\224\184\173\224\184\149\224\184\180\224\184\161\224\184\136\224\184\176\224\184\130\224\184\182\224\185\137\224\184\153\224\185\128\224\184\163\224\185\135\224\184\167\224\184\129\224\184\167\224\185\136\224\184\178", Color3.fromRGB(255, 214, 96))
					else
						local v294 = p_u_174.hud.hint
						local v295 = v_u_205 * 100
						v294(("\224\185\132\224\184\173\224\184\149\224\184\180\224\184\161\224\184\129\224\184\179\224\184\165\224\184\177\224\184\135\224\184\130\224\184\182\224\185\137\224\184\153\226\128\166 %d%%"):format((math.floor(v295))), Color3.fromRGB(120, 230, 150))
					end
				else
					p_u_174.hud.hint("\224\184\129\224\184\148\224\184\132\224\185\137\224\184\178\224\184\135 + \224\184\165\224\184\178\224\184\129\224\184\167\224\184\153\224\185\128\224\184\155\224\185\135\224\184\153\224\184\167\224\184\135\224\184\129\224\184\165\224\184\161 \224\185\128\224\184\158\224\184\183\224\185\136\224\184\173\224\184\129\224\184\148\224\185\132\224\184\173\224\184\149\224\184\180\224\184\161")
				end
				if v_u_205 >= 1 then
					v_u_245 = true
					v_u_193(false)
					v_u_195.Transparency = 1
					if not v_u_186 then
						local v296 = p_u_174.folder
						local v297 = v_u_183 + Vector3.new(0, 0.6, 0)
						local v298 = v_u_178
						v_u_22(v296, "Tip", Vector3.new(0.1, 0.1, 0.1), CFrame.new(v297), v298, nil, {
							["Shape"] = Enum.PartType.Ball
						})
					end
					p_u_174.success(v_u_246 >= v_u_247 * 0.4 and 1 or 0.7)
				end
			end
		end
		table.insert(v252, v253:Connect(v299))
	end
}
local v_u_301 = {
	["pearl"] = "\224\184\139\224\184\177\224\184\153\224\185\128\224\184\148\224\184\162\224\185\140",
	["orange"] = "\224\185\129\224\184\129\224\185\137\224\184\167",
	["strawberry"] = "\224\185\130\224\184\132\224\184\153"
}
local v_u_302 = {
	["pearl"] = "\224\185\132\224\184\130\224\185\136\224\184\161\224\184\184\224\184\129",
	["orange"] = "\224\184\170\224\185\137\224\184\161",
	["strawberry"] = "\224\184\170\224\184\149\224\184\163\224\184\173\224\184\167\224\185\140\224\185\128\224\184\154\224\184\173\224\184\163\224\185\140\224\184\163\224\184\181"
}
function v_u_300.scoop(p_u_303) -- name: scoop
	-- upvalues: (copy) v_u_59, (copy) v_u_32, (copy) v_u_69, (copy) v_u_123, (copy) v_u_142, (copy) v_u_8, (copy) v_u_110, (copy) v_u_2, (copy) v_u_22, (copy) v_u_302, (copy) v_u_4, (copy) v_u_301, (copy) v_u_171, (copy) v_u_169, (copy) v_u_5, (copy) v_u_163, (copy) v_u_173
	local v_u_304 = p_u_303.kitchen:FindFirstChild("ToppingBar")
	local v305
	if v_u_304 then
		v305 = v_u_304:FindFirstChild("CupHolder")
	else
		v305 = v_u_304
	end
	if not v305 then
		return p_u_303.finish(nil)
	end
	local v_u_306 = p_u_303.opts.item or "pearl"
	local v307 = p_u_303.opts.count
	local v308 = tonumber(v307) or 3
	local v309 = math.floor(v308)
	local v_u_310 = math.max(1, v309)
	local v_u_311 = v305.Position
	local v_u_312 = false
	v_u_311 = v_u_311
	local v_u_313 = 1
	local v_u_314, v_u_315
	if p_u_303.opts.tall then
		if not v_u_59(p_u_303.folder, v_u_311 + Vector3.new(0, 0.05, 0)) then
			v_u_32(p_u_303.folder, "Glass", 0.6, 1, v_u_311 + Vector3.new(0, 0.55, 0), Color3.fromRGB(215, 235, 248), Enum.Material.Glass, {
				["Transparency"] = 0.6
			})
		end
		v_u_69(p_u_303.folder, v_u_311 + Vector3.new(0, 0.125, 0))
		v_u_314 = v_u_311 + Vector3.new(0, 0.42, 0)
		v_u_315 = v_u_311
	elseif p_u_303.opts.cup then
		local v316 = v_u_311 + Vector3.new(0, 0.62, 0)
		v_u_123(p_u_303.folder, v316)
		v_u_315 = v316 - Vector3.new(0, 0.1, 0)
		v_u_313 = 1.12
		v_u_312 = v_u_142(p_u_303.folder, v_u_315, v_u_8.vanilla, v_u_313) == true
		if not v_u_312 then
			v_u_142(p_u_303.folder, v316, v_u_8.vanilla, 1)
		end
		v_u_314 = v316 + Vector3.new(0, 0.42, 0)
	else
		v_u_315 = v_u_311 + Vector3.new(0, 0.72, 0)
		v_u_110(p_u_303.folder, v_u_315)
		v_u_312 = v_u_142(p_u_303.folder, v_u_315, v_u_8.strawberry, 1) == true
		v_u_314 = v_u_315 + Vector3.new(0, 0.5, 0)
		v_u_313 = 1
	end
	p_u_303.camera(CFrame.lookAt(v_u_311 + Vector3.new(2.3, 2.5, 0), v_u_311 + Vector3.new(-0.95, 0.15, 0)), 52)
	local v_u_317 = {}
	for _, v318 in v_u_304:GetChildren() do
		if not v318:IsA("BasePart") or v318:GetAttribute("Topping") ~= v_u_306 then
			continue
		end
		table.insert(v_u_317, v318)
	end
	local v_u_319 = RaycastParams.new()
	v_u_319.FilterType = Enum.RaycastFilterType.Include
	v_u_319.FilterDescendantsInstances = v_u_317
	local v_u_320 = Instance.new("Highlight")
	v_u_320.FillColor = Color3.fromRGB(255, 230, 120)
	v_u_320.FillTransparency = 0.45
	v_u_320.OutlineColor = Color3.fromRGB(255, 214, 60)
	v_u_320.DepthMode = Enum.HighlightDepthMode.Occluded
	v_u_320.Enabled = false
	v_u_320.Parent = p_u_303.folder
	local v_u_321 = {}
	local v_u_322 = 0
	local v_u_323 = false
	local v_u_324 = 0
	local function v_u_328(p325) -- name: hit
		-- upvalues: (copy) v_u_319, (copy) v_u_304, (copy) v_u_321
		local v326 = workspace.CurrentCamera:ScreenPointToRay(p325.X, p325.Y)
		local v327 = workspace:Raycast(v326.Origin, v326.Direction * 20, v_u_319)
		if v327 then
			v327 = v327.Instance
		end
		while v327 and v327.Parent ~= v_u_304 do
			v327 = v327.Parent
		end
		if v327 and (v_u_321[v327] or 0) < os.clock() then
			return v327
		else
			return nil
		end
	end
	local function v_u_374(p_u_329) -- name: take
		-- upvalues: (ref) v_u_323, (ref) v_u_322, (copy) v_u_310, (copy) v_u_321, (ref) v_u_312, (copy) v_u_306, (ref) v_u_22, (copy) p_u_303, (ref) v_u_315, (ref) v_u_313, (ref) v_u_2, (ref) v_u_314, (ref) v_u_302
		if not v_u_323 and (v_u_310 > v_u_322 and p_u_329) then
			v_u_323 = true
			v_u_322 = v_u_322 + 1
			v_u_321[p_u_329] = os.clock() + 1.4
			for _, v330 in p_u_329:GetDescendants() do
				if not v330:IsA("BasePart") then
					continue
				end
				v330.LocalTransparencyModifier = 1
			end
			p_u_329.LocalTransparencyModifier = 1
			task.delay(1.4, function()
				-- upvalues: (copy) p_u_329
				if p_u_329.Parent then
					p_u_329.LocalTransparencyModifier = 0
					for _, v331 in p_u_329:GetDescendants() do
						if not v331:IsA("BasePart") then
							continue
						end
						v331.LocalTransparencyModifier = 0
					end
				end
			end)
			if v_u_312 and v_u_306 == "pearl" then
				for v332 = 1, 6 do
					local v333 = (v_u_322 - 1) / v_u_310 * 3.141592653589793 * 2 + (v332 - 1) * 1.05 + math.random() * 0.5
					local v334 = 0.08 + math.random() * 0.17
					local v_u_335 = v_u_22(p_u_303.folder, "Pearl", Vector3.new(0.064, 0.064, 0.064), CFrame.new(p_u_329.Position), Color3.fromRGB(44, 22, 12), Enum.Material.SmoothPlastic, {
						["Shape"] = nil,
						["Reflectance"] = 0.12,
						["Shape"] = Enum.PartType.Ball
					})
					local v_u_336 = p_u_329.Position
					local v337 = (0.313 - v334) / 0.234
					local v338 = math.clamp(v337, 0, 0.95)
					local v339 = v_u_315
					local v340 = math.cos(v333) * v334 * v_u_313
					local v341 = (v338 * 0.5 + 0.085) * v_u_313
					local v342 = math.sin(v333) * v334 * v_u_313
					local v_u_343 = v339 + Vector3.new(v340, v341, v342) + Vector3.new(0, 0.03, 0)
					local v_u_344 = v332 * 0.035 + 0.28
					local v_u_345 = (v_u_336 + v_u_343) / 2 + Vector3.new(0, 0.7, 0)
					task.spawn(function()
						-- upvalues: (copy) v_u_344, (copy) v_u_335, (copy) v_u_336, (copy) v_u_345, (copy) v_u_343, (ref) v_u_2
						local v346 = os.clock()
						while os.clock() - v346 < v_u_344 and v_u_335.Parent do
							local v347 = (os.clock() - v346) / v_u_344
							v_u_335.CFrame = CFrame.new((1 - v347) * (1 - v347) * v_u_336 + 2 * (1 - v347) * v347 * v_u_345 + v347 * v347 * v_u_343)
							v_u_2.RenderStepped:Wait()
						end
						v_u_335.CFrame = CFrame.new(v_u_343)
					end)
				end
			else
				local v_u_348 = p_u_329:Clone()
				for _, v349 in v_u_348:GetDescendants() do
					if not v349:IsA("BasePart") then
						continue
					end
					v349.Anchored = true
					v349.LocalTransparencyModifier = 0
				end
				v_u_348.LocalTransparencyModifier = 0
				v_u_348.CanQuery = false
				v_u_348.Parent = p_u_303.folder
				local v350 = (v_u_322 - 1) / v_u_310 * 3.141592653589793 * 2
				local v351 = v_u_314
				local v352 = math.cos(v350) * 0.14
				local v353 = v_u_322 % 2 * 0.05
				local v354 = math.sin(v350) * 0.14
				local v_u_355 = v351 + Vector3.new(v352, v353, v354)
				local v356
				if v_u_312 then
					local v357 = v350 + 0.6
					local v358 = v_u_315
					local v359 = math.cos(v357) * 0.16 * v_u_313
					local v360 = v_u_313 * 0.4119230769230769
					local v361 = math.sin(v357) * 0.16 * v_u_313
					v_u_355 = v358 + Vector3.new(v359, v360, v361) + Vector3.new(0, 0.06, 0)
					v356 = 0.6
				else
					v356 = 1
				end
				local v_u_362 = (p_u_329.Position + v_u_355) / 2 + Vector3.new(0, 0.7, 0)
				local v_u_363 = v_u_348:FindFirstChild("Leaf")
				v_u_363 = v_u_363
				local v_u_364
				if v_u_363 then
					v_u_364 = v_u_348.CFrame:ToObjectSpace(v_u_363.CFrame)
				else
					v_u_364 = v_u_363
				end
				if v356 ~= 1 then
					v_u_348.Size = v_u_348.Size * v356
					if v_u_363 then
						v_u_363.Size = v_u_363.Size * v356
						v_u_364 = v_u_364 - v_u_364.Position + v_u_364.Position * v356
					end
				end
				task.spawn(function()
					-- upvalues: (copy) p_u_329, (copy) v_u_362, (ref) v_u_355, (copy) v_u_348, (copy) v_u_363, (ref) v_u_364, (ref) v_u_2
					local v365 = os.clock()
					local v366 = 0.32
					while os.clock() - v365 < v366 do
						local v367 = (os.clock() - v365) / 0.32
						local v368 = (1 - v367) * (1 - v367) * p_u_329.Position + 2 * (1 - v367) * v367 * v_u_362 + v367 * v367 * v_u_355
						local v369 = CFrame.new(v368) * (p_u_329.CFrame - p_u_329.Position)
						v_u_348.CFrame = v369
						if v_u_363 then
							v_u_363.CFrame = v369 * v_u_364
						end
						v_u_2.RenderStepped:Wait()
					end
					local v370 = CFrame.new(v_u_355) * (p_u_329.CFrame - p_u_329.Position)
					v_u_348.CFrame = v370
					if v_u_363 then
						v_u_363.CFrame = v370 * v_u_364
					end
				end)
			end
			p_u_303.hud.set(v_u_322 / v_u_310)
			local v371 = p_u_303.hud.hint
			local v372 = ("\224\185\131\224\184\170\224\185\136%s\224\185\129\224\184\165\224\185\137\224\184\167 %d / %d"):format(v_u_302[v_u_306] or "", v_u_322, v_u_310)
			local v373
			if v_u_310 <= v_u_322 then
				v373 = Color3.fromRGB(120, 230, 150)
			else
				v373 = nil
			end
			v371(v372, v373)
			task.delay(0.35, function()
				-- upvalues: (ref) v_u_323, (ref) v_u_322, (ref) v_u_310, (ref) p_u_303
				v_u_323 = false
				if v_u_310 <= v_u_322 then
					p_u_303.success(1)
				end
			end)
		end
	end
	local v375 = p_u_303.conns
	local v376 = v_u_4.InputChanged
	table.insert(v375, v376:Connect(function(p377)
		-- upvalues: (copy) v_u_328, (copy) v_u_320
		if p377.UserInputType == Enum.UserInputType.MouseMovement then
			local v378 = v_u_328(p377.Position)
			v_u_320.Adornee = v378
			v_u_320.Enabled = v378 ~= nil
		end
	end))
	local v379 = p_u_303.conns
	local v380 = v_u_4.InputBegan
	local function v384(p381, p382)
		-- upvalues: (ref) v_u_324, (copy) v_u_374, (copy) v_u_328, (copy) v_u_317, (copy) v_u_321
		if p382 then
			return
		elseif p381.UserInputType == Enum.UserInputType.MouseButton1 and true or p381.UserInputType == Enum.UserInputType.Touch then
			if os.clock() - v_u_324 >= 0.25 then
				v_u_324 = os.clock()
				v_u_374((v_u_328(p381.Position)))
			end
		else
			if p381.KeyCode == Enum.KeyCode.Space then
				for _, v383 in v_u_317 do
					if (v_u_321[v383] or 0) >= os.clock() then
						continue
					end
					v_u_374(v383)
					return
				end
			end
			return
		end
	end
	table.insert(v379, v380:Connect(v384))
	p_u_303.hud.set(0)
	p_u_303.hud.hint(("\224\184\132\224\184\165\224\184\180\224\184\129%s\224\185\131\224\184\153\224\184\150\224\184\178\224\184\148 \224\185\131\224\184\170\224\185\136\224\184\165\224\184\135%s\224\185\131\224\184\171\224\185\137\224\184\132\224\184\163\224\184\154 %d"):format(v_u_302[v_u_306] or "", v_u_301[v_u_306] or "", v_u_310))
	local v_u_385 = v_u_322
	local v386 = Vector3.new(0, 0, 0)
	for _, v387 in v_u_317 do
		v386 = v386 + v387.Position
	end
	if #v_u_317 > 0 then
		v_u_311 = v386 / #v_u_317
	end
	local v_u_388 = (v_u_311 + v_u_314) / 2 + Vector3.new(0, 0.9, 0)
	local v_u_389 = v_u_171(p_u_303)
	local v_u_390 = {}
	for v391 = 1, 14 do
		v_u_390[v391] = v_u_169(v_u_389, 9)
	end
	local v_u_392 = v_u_5.new("Frame", {
		["AnchorPoint"] = nil,
		["BackgroundTransparency"] = 1,
		["ZIndex"] = 2,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Parent"] = v_u_389
	})
	v_u_5.corner(v_u_392, 999)
	local v393 = {
		["Color"] = nil,
		["Thickness"] = 3,
		["Parent"] = nil,
		["Color"] = v_u_163,
		["Parent"] = v_u_392
	}
	v_u_5.new("UIStroke", v393)
	local v_u_394 = v_u_173(v_u_389)
	local v_u_395 = v_u_5.text({
		["Text"] = "\224\184\132\224\184\165\224\184\180\224\184\129\224\184\149\224\184\163\224\184\135\224\184\153\224\184\181\224\185\137",
		["FontFace"] = nil,
		["TextSize"] = 18,
		["TextColor3"] = nil,
		["TextStrokeTransparency"] = 0.3,
		["AnchorPoint"] = nil,
		["Size"] = nil,
		["ZIndex"] = 3,
		["Parent"] = nil,
		["FontFace"] = v_u_5.FONT_HEAVY,
		["TextColor3"] = Color3.new(1, 1, 1),
		["AnchorPoint"] = Vector2.new(0.5, 1),
		["Size"] = UDim2.fromOffset(160, 24),
		["Parent"] = v_u_389
	})
	local v_u_396 = v_u_5.text({
		["Text"] = "\226\172\135",
		["TextSize"] = 34,
		["TextColor3"] = nil,
		["TextStrokeTransparency"] = 0.2,
		["AnchorPoint"] = nil,
		["Size"] = nil,
		["ZIndex"] = 3,
		["Parent"] = nil,
		["TextColor3"] = v_u_163,
		["AnchorPoint"] = Vector2.new(0.5, 1),
		["Size"] = UDim2.fromOffset(40, 40),
		["Parent"] = v_u_389
	})
	local v397 = p_u_303.conns
	local v398 = v_u_2.RenderStepped
	table.insert(v397, v398:Connect(function()
		-- upvalues: (ref) v_u_385, (copy) v_u_310, (copy) v_u_389, (copy) v_u_390, (ref) v_u_311, (copy) v_u_388, (ref) v_u_314, (copy) v_u_392, (copy) v_u_394, (copy) v_u_395, (copy) v_u_396
		if v_u_310 <= v_u_385 then
			v_u_389.Visible = false
		else
			local v399 = os.clock()
			local v400 = v399 * 0.7 % 1
			for v401, v402 in v_u_390 do
				local v403 = (v401 - 1) / #v_u_390 + v400 / #v_u_390
				local v404 = (1 - v403) * (1 - v403) * v_u_311 + 2 * (1 - v403) * v403 * v_u_388 + v403 * v403 * v_u_314
				local v405 = workspace.CurrentCamera:WorldToScreenPoint(v404)
				local v406 = Vector2.new(v405.X, v405.Y)
				v402.Position = UDim2.fromOffset(v406.X, v406.Y)
				v402.BackgroundTransparency = 0.15 + 0.5 * v403
			end
			local v407 = v_u_311
			local v408 = workspace.CurrentCamera:WorldToScreenPoint(v407)
			local v409 = Vector2.new(v408.X, v408.Y)
			local v410 = v_u_311 + workspace.CurrentCamera.CFrame.RightVector * 0.7
			local v411 = workspace.CurrentCamera:WorldToScreenPoint(v410)
			local v412 = (Vector2.new(v411.X, v411.Y) - v409).Magnitude
			local v413 = math.max(30, v412)
			local v414 = v399 * 5
			local v415 = math.sin(v414) * 0.08 + 1
			v_u_392.Position = UDim2.fromOffset(v409.X, v409.Y)
			v_u_392.Size = UDim2.fromOffset(v413 * 2 * v415, v413 * 1.3 * v415)
			local v416 = v_u_394
			local v417 = UDim2.fromOffset
			local v418 = v409.X + 8
			local v419 = v409.Y
			local v420 = v399 * 6
			v416.Position = v417(v418, v419 + math.sin(v420) * 6)
			v_u_395.Position = UDim2.fromOffset(v409.X, v409.Y - v413 * 0.7 - 6)
			local v421 = v_u_314 + Vector3.new(0, 0.35, 0)
			local v422 = workspace.CurrentCamera:WorldToScreenPoint(v421)
			local v423 = Vector2.new(v422.X, v422.Y)
			local v424 = v_u_396
			local v425 = UDim2.fromOffset
			local v426 = v423.X
			local v427 = v423.Y
			local v428 = v399 * 6
			v424.Position = v425(v426, v427 + math.sin(v428) * 5)
		end
	end))
end
function v_u_300.juice(p_u_429) -- name: juice
	-- upvalues: (copy) v_u_59, (copy) v_u_32, (copy) v_u_56, (copy) v_u_22, (copy) v_u_69, (copy) v_u_171, (copy) v_u_5, (copy) v_u_163, (copy) v_u_2, (copy) v_u_10, (copy) v_u_4, (copy) v_u_11
	local v430 = p_u_429.kitchen:FindFirstChild("JuiceDispenser")
	local v431
	if v430 then
		v431 = v430:FindFirstChild("Grate")
	else
		v431 = v430
	end
	if v430 then
		v430 = v430:FindFirstChild("Tap1")
	end
	if not (v431 and v430) then
		return p_u_429.finish(nil)
	end
	local v432 = v430.Position.X + 0.3
	local v433 = v431.Position.Y + 0.06
	local v434 = v430.Position.Z
	local v_u_435 = Vector3.new(v432, v433, v434)
	local v436 = v_u_59(p_u_429.folder, v_u_435) ~= nil
	local v_u_437 = v436 and 0.075 or 0.01
	local v_u_438 = v436 and 0.88 or 0.96
	local v_u_439 = v436 and 0.5 or 0.54
	if not v436 then
		v_u_32(p_u_429.folder, "Glass", 0.6, 1, v_u_435 + Vector3.new(0, 0.5, 0), Color3.fromRGB(215, 235, 248), Enum.Material.Glass, {
			["Transparency"] = 0.62
		})
	end
	for v440 = 1, 2 do
		local v441 = v_u_56
		local v442 = p_u_429.folder
		local v443 = CFrame.new
		local v444 = v440 * 0.04 - 0.07
		local v445 = v_u_437 + 0.12 + v440 * 0.09
		local v446 = 0.08 - v440 * 0.13
		local v447 = v443(v_u_435 + Vector3.new(v444, v445, v446))
		local v448 = CFrame.Angles
		local v449 = v440 * 50
		if v441(v442, "OrangeSlice", v447 * v448(1.1344640137963142, math.rad(v449), 0)) then
			continue
		end
		local v450 = v_u_22
		local v451 = p_u_429.folder
		local v452 = CFrame.new
		local v453 = v440 * 0.05
		local v454 = v440 * 0.06 + 0.12
		local v455 = 0.08 - v440 * 0.12
		v450(v451, "Orange", Vector3.new(0.08, 0.36, 0.36), v452(v_u_435 + Vector3.new(v453, v454, v455)) * CFrame.Angles(v440 * 0.4, 0, 1.5707963267948966), Color3.fromRGB(255, 150, 30), nil, {
			["Shape"] = Enum.PartType.Cylinder
		})
	end
	v_u_56(p_u_429.folder, "OrangeSlice", CFrame.new(v_u_435 + Vector3.new(-0.29, 0.97, 0.04)) * CFrame.Angles(0, 0, 1.5707963267948966), 1.15)
	v_u_69(p_u_429.folder, v_u_435 + Vector3.new(0, v_u_437, 0))
	local v456 = v_u_32
	local v457 = p_u_429.folder
	local v458 = v_u_437 + 0.01
	local v_u_459 = v456(v457, "Tea", v_u_439, 0.02, v_u_435 + Vector3.new(0, v458, 0), Color3.fromRGB(255, 140, 30), Enum.Material.SmoothPlastic)
	local v_u_460 = 0.62 + math.random() * 0.12
	local v_u_461 = v_u_460 + 0.13
	for _, v462 in { v_u_460, v_u_461 } do
		for v463 = 1, 20 do
			local v464 = v463 / 20 * 3.141592653589793 * 2
			local v465 = p_u_429.folder
			local v466 = math.cos(v464) * 0.32
			local v467 = (v_u_437 + v462 * v_u_438) * 1
			local v468 = math.sin(v464) * 0.32
			local v469 = v_u_435 + Vector3.new(v466, v467, v468)
			local v470 = Color3.fromRGB(255, 200, 40)
			local v471 = Enum.Material.SmoothPlastic
			v_u_22(v465, "Line", Vector3.new(0.045, 0.045, 0.045), CFrame.new(v469), v470, v471, {
				["Shape"] = Enum.PartType.Ball
			})
		end
	end
	local v_u_472 = v430.Position + Vector3.new(0.18, -0.08, 0)
	local v_u_473 = v_u_32(p_u_429.folder, "Stream", 0.09, 0.1, v_u_472, Color3.fromRGB(255, 150, 40))
	v_u_473.Transparency = 1
	p_u_429.camera(CFrame.lookAt(v_u_435 + Vector3.new(2.7, 1.45, 0.15), v_u_435 + Vector3.new(-0.1, 0.62, 0)), 46)
	local v_u_474 = 0
	local v_u_475 = false
	local v_u_476 = false
	local v_u_477 = false
	local v_u_478 = v_u_171(p_u_429)
	local v_u_479 = v_u_5.text({
		["Text"] = "\226\172\135",
		["TextSize"] = 40,
		["TextColor3"] = nil,
		["TextStrokeTransparency"] = 0.2,
		["AnchorPoint"] = nil,
		["Size"] = nil,
		["ZIndex"] = 3,
		["Parent"] = nil,
		["TextColor3"] = v_u_163,
		["AnchorPoint"] = Vector2.new(0.5, 1),
		["Size"] = UDim2.fromOffset(44, 44),
		["Parent"] = v_u_478
	})
	local v_u_480 = v_u_5.text({
		["Text"] = "\226\151\128 \224\185\128\224\184\149\224\184\180\224\184\161\224\184\150\224\184\182\224\184\135\224\184\138\224\185\136\224\184\167\224\184\135\224\184\153\224\184\181\224\185\137",
		["FontFace"] = nil,
		["TextSize"] = 18,
		["TextColor3"] = nil,
		["TextStrokeTransparency"] = 0.3,
		["TextXAlignment"] = nil,
		["AnchorPoint"] = nil,
		["Size"] = nil,
		["ZIndex"] = 3,
		["Parent"] = nil,
		["FontFace"] = v_u_5.FONT_HEAVY,
		["TextColor3"] = v_u_163,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["AnchorPoint"] = Vector2.new(0, 0.5),
		["Size"] = UDim2.fromOffset(170, 24),
		["Parent"] = v_u_478
	})
	local v_u_481 = v_u_5.text({
		["Text"] = "\224\184\129\224\184\148\224\184\132\224\185\137\224\184\178\224\184\135",
		["FontFace"] = nil,
		["TextSize"] = 18,
		["TextColor3"] = nil,
		["TextStrokeTransparency"] = 0.3,
		["AnchorPoint"] = nil,
		["Size"] = nil,
		["ZIndex"] = 3,
		["Parent"] = nil,
		["FontFace"] = v_u_5.FONT_HEAVY,
		["TextColor3"] = Color3.new(1, 1, 1),
		["AnchorPoint"] = Vector2.new(0.5, 1),
		["Size"] = UDim2.fromOffset(120, 24),
		["Parent"] = v_u_478
	})
	local v482 = p_u_429.conns
	local v483 = v_u_2.RenderStepped
	local function v498()
		-- upvalues: (ref) v_u_477, (copy) v_u_478, (copy) v_u_435, (copy) v_u_479, (copy) v_u_481, (ref) v_u_475, (ref) v_u_476, (copy) v_u_460, (copy) v_u_461, (copy) v_u_437, (copy) v_u_438, (copy) v_u_480
		if v_u_477 then
			v_u_478.Visible = false
		else
			local v484 = os.clock()
			local v485 = v_u_435 + Vector3.new(0, 1.25, 0)
			local v486 = workspace.CurrentCamera:WorldToScreenPoint(v485)
			local v487 = Vector2.new(v486.X, v486.Y)
			local v488 = v_u_479
			local v489 = UDim2.fromOffset
			local v490 = v487.X
			local v491 = v487.Y
			local v492 = v484 * 6
			v488.Position = v489(v490, v491 + math.sin(v492) * 6)
			v_u_481.Position = UDim2.fromOffset(v487.X, v487.Y - 40)
			v_u_481.Visible = not (v_u_475 or v_u_476)
			local v493 = v_u_435
			local v494 = (v_u_437 + (v_u_460 + v_u_461) / 2 * v_u_438) * 1
			local v495 = v493 + Vector3.new(0, v494, 0) + workspace.CurrentCamera.CFrame.RightVector * 0.42
			local v496 = workspace.CurrentCamera:WorldToScreenPoint(v495)
			local v497 = Vector2.new(v496.X, v496.Y)
			v_u_480.Position = UDim2.fromOffset(v497.X + 6, v497.Y)
		end
	end
	table.insert(v482, v483:Connect(v498))
	local function v_u_500() -- name: release
		-- upvalues: (ref) v_u_474, (copy) v_u_460, (ref) v_u_477, (copy) v_u_473, (copy) p_u_429, (ref) v_u_22, (copy) v_u_435, (ref) v_u_10, (copy) v_u_461
		if v_u_460 <= v_u_474 and not v_u_477 then
			v_u_477 = true
			v_u_473.Transparency = 1
			for _, v499 in p_u_429.folder:GetChildren() do
				if v499.Name ~= "Line" then
					continue
				end
				v499.Transparency = 1
			end
			v_u_22(p_u_429.folder, "Straw", Vector3.new(1.25, 0.055, 0.055), CFrame.new(v_u_435 + Vector3.new(-0.1, 0.8, 0.07)) * CFrame.Angles(0, 0, 1.361356816555577), v_u_10, nil, {
				["Shape"] = Enum.PartType.Cylinder
			})
			p_u_429.success(v_u_474 <= v_u_461 and 1 or (v_u_474 <= v_u_461 + 0.08 and 0.6 or 0.3))
		end
	end
	local v501 = p_u_429.conns
	local v502 = v_u_4.InputBegan
	local function v505(p503, p504)
		-- upvalues: (ref) v_u_475, (ref) v_u_476
		if p504 then
			return
		elseif p503.UserInputType == Enum.UserInputType.MouseButton1 and true or p503.UserInputType == Enum.UserInputType.Touch then
			v_u_475 = true
		elseif p503.KeyCode == Enum.KeyCode.Space then
			v_u_476 = true
		end
	end
	table.insert(v501, v502:Connect(v505))
	local v506 = p_u_429.conns
	local v507 = v_u_4.InputEnded
	local function v509(p508)
		-- upvalues: (ref) v_u_475, (copy) v_u_500, (ref) v_u_476
		if p508.UserInputType == Enum.UserInputType.MouseButton1 and true or p508.UserInputType == Enum.UserInputType.Touch then
			v_u_475 = false
			v_u_500()
		elseif p508.KeyCode == Enum.KeyCode.Space then
			v_u_476 = false
			v_u_500()
		end
	end
	table.insert(v506, v507:Connect(v509))
	local v510 = p_u_429.conns
	local v511 = v_u_2.RenderStepped
	local function v534(p512)
		-- upvalues: (ref) v_u_477, (ref) v_u_475, (ref) v_u_476, (ref) v_u_474, (copy) v_u_438, (copy) v_u_459, (copy) v_u_439, (copy) v_u_435, (copy) v_u_437, (ref) v_u_11, (copy) v_u_472, (copy) v_u_473, (copy) p_u_429, (copy) v_u_460, (copy) v_u_461
		if v_u_477 then
			return
		else
			local v513 = v_u_475 or v_u_476
			if v513 then
				local v514 = v_u_474 + p512 * 0.28
				v_u_474 = math.min(1, v514)
			end
			local v515 = v_u_474 * v_u_438
			local v516 = math.max(0.02, v515)
			local v517 = v_u_439
			local v518 = v_u_439
			v_u_459.Size = Vector3.new(v516, v517, v518)
			local v519 = v_u_459
			local v520 = CFrame.new
			local v521 = v_u_435
			local v522 = v_u_437 + v516 / 2
			v519.CFrame = v520(v521 + Vector3.new(0, v522, 0)) * v_u_11
			if v513 then
				local v523 = v_u_435.Y + v_u_437 + v516
				local v524 = v_u_472.Y - v523
				local v525 = math.max(0.05, v524)
				v_u_473.Size = Vector3.new(v525, 0.09, 0.09)
				local v526 = v_u_473
				local v527 = CFrame.new
				local v528 = v_u_472.X
				local v529 = v523 + v525 / 2
				local v530 = v_u_472.Z
				v526.CFrame = v527((Vector3.new(v528, v529, v530))) * v_u_11
				v_u_473.Transparency = 0.1
			else
				v_u_473.Transparency = 1
			end
			p_u_429.hud.set(v_u_474 / v_u_460)
			if v513 then
				local v531 = p_u_429.hud.hint
				local v532 = v_u_461 < v_u_474 and "\224\184\165\224\185\137\224\184\153\224\185\129\224\184\165\224\185\137\224\184\167! \224\184\155\224\184\165\224\185\136\224\184\173\224\184\162\224\185\128\224\184\165\224\184\162" or (v_u_460 <= v_u_474 and "\224\184\158\224\184\173\224\184\148\224\184\181\224\185\129\224\184\165\224\185\137\224\184\167 \224\184\155\224\184\165\224\185\136\224\184\173\224\184\162\224\185\132\224\184\148\224\185\137" or "\224\184\129\224\184\179\224\184\165\224\184\177\224\184\135\224\185\128\224\184\151\226\128\166")
				local v533
				if v_u_461 < v_u_474 then
					v533 = Color3.fromRGB(255, 110, 110)
				elseif v_u_460 <= v_u_474 then
					v533 = Color3.fromRGB(120, 230, 150)
				else
					v533 = nil
				end
				v531(v532, v533)
			else
				p_u_429.hud.hint(v_u_460 <= v_u_474 and "\224\184\155\224\184\165\224\185\136\224\184\173\224\184\162\224\185\132\224\184\148\224\185\137\224\185\128\224\184\165\224\184\162" or "\224\184\129\224\184\148\224\184\132\224\185\137\224\184\178\224\184\135\224\185\132\224\184\167\224\185\137\224\185\128\224\184\158\224\184\183\224\185\136\224\184\173\224\185\128\224\184\151\224\184\138\224\184\178\224\184\170\224\185\137\224\184\161\224\184\165\224\184\135\224\185\129\224\184\129\224\185\137\224\184\167")
			end
		end
	end
	table.insert(v510, v511:Connect(v534))
end
function v_u_6.isOpen() -- name: isOpen
	-- upvalues: (ref) v_u_7
	return v_u_7 ~= nil
end
function v_u_6.close() -- name: close
	-- upvalues: (ref) v_u_7
	if v_u_7 then
		v_u_7.finish(nil)
	end
end
function v_u_6.play(p535, p536, p_u_537) -- name: play
	-- upvalues: (copy) v_u_6, (copy) v_u_300, (copy) v_u_1, (copy) v_u_162, (copy) v_u_3, (ref) v_u_7, (copy) v_u_2
	v_u_6.close()
	if p536 then
		p536 = p536:FindFirstAncestor("Kitchen")
	end
	if p535 and (p536 and v_u_300[p535.game]) then
		local v538 = v_u_1.LocalPlayer
		local v_u_539 = workspace.CurrentCamera
		local v_u_540 = {
			["fov"] = v_u_539.FieldOfView
		}
		local v_u_541 = Instance.new("Folder")
		v_u_541.Name = "IceCreamWork"
		v_u_541.Parent = v_u_539
		local v_u_542 = {
			["kitchen"] = p536,
			["folder"] = v_u_541,
			["opts"] = p535.opts or {},
			["conns"] = {},
			["undo"] = {},
			["hud"] = v_u_162("")
		}
		local v_u_543 = nil
		function v_u_542.camera(p544, p545) -- name: camera
			-- upvalues: (ref) v_u_543, (copy) v_u_539, (ref) v_u_3
			v_u_543 = p544
			v_u_539.CameraType = Enum.CameraType.Scriptable
			v_u_3:Create(v_u_539, TweenInfo.new(0.45, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
				["CFrame"] = p544,
				["FieldOfView"] = p545
			}):Play()
		end
		local v_u_546 = v538.Character
		local function v_u_549(p547) -- name: hideBody
			-- upvalues: (copy) v_u_546
			if v_u_546 then
				for _, v548 in v_u_546:GetDescendants() do
					if not (v548:IsA("BasePart") or v548:IsA("Decal")) then
						continue
					end
					v548.LocalTransparencyModifier = p547
				end
			end
		end
		local v_u_550 = false
		local function v_u_555(p551) -- name: finish
			-- upvalues: (ref) v_u_550, (copy) v_u_542, (copy) v_u_549, (copy) v_u_541, (copy) v_u_539, (copy) v_u_546, (copy) v_u_540, (ref) v_u_7, (copy) p_u_537
			if not v_u_550 then
				v_u_550 = true
				for _, v552 in v_u_542.conns do
					v552:Disconnect()
				end
				for _, v553 in v_u_542.undo do
					pcall(v553)
				end
				v_u_549(0)
				v_u_541:Destroy()
				v_u_542.hud.root:Destroy()
				v_u_539.CameraType = Enum.CameraType.Custom
				local v554 = v_u_546
				if v554 then
					v554 = v_u_546:FindFirstChildOfClass("Humanoid")
				end
				if v554 then
					v_u_539.CameraSubject = v554
				end
				v_u_539.FieldOfView = v_u_540.fov
				v_u_7 = nil
				p_u_537(p551)
			end
		end
		v_u_542.finish = v_u_555
		function v_u_542.success(p_u_556) -- name: success
			-- upvalues: (copy) v_u_542, (copy) v_u_555
			v_u_542.hud.set(1)
			v_u_542.hud.hint("\224\184\170\224\184\179\224\185\128\224\184\163\224\185\135\224\184\136! \226\156\147", Color3.fromRGB(120, 230, 150))
			task.delay(0.9, function()
				-- upvalues: (ref) v_u_555, (copy) p_u_556
				v_u_555(p_u_556)
			end)
		end
		v_u_542.hud.quit.Activated:Connect(function()
			-- upvalues: (copy) v_u_555
			v_u_555(nil)
		end)
		local v557 = v_u_542.conns
		local v558 = v_u_2.RenderStepped
		local function v559()
			-- upvalues: (copy) v_u_549, (ref) v_u_543, (copy) v_u_539
			v_u_549(1)
			if v_u_543 and v_u_539.CameraType ~= Enum.CameraType.Scriptable then
				v_u_539.CameraType = Enum.CameraType.Scriptable
				v_u_539.CFrame = v_u_543
			end
		end
		table.insert(v557, v558:Connect(v559))
		v_u_7 = {
			["finish"] = v_u_555
		}
		v_u_300[p535.game](v_u_542)
	else
		p_u_537(nil)
	end
end
return v_u_6