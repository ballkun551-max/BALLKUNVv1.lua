-- Path: ReplicatedStorage/RankShared
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = {
	["ORDER"] = {
		"Member",
		"TikTok Creator",
		"VIP",
		"Developer",
		"Admin",
		"Owner"
	}
}
local v2 = {
	["Member"] = {
		["level"] = 1,
		["emoji"] = "",
		["color"] = nil,
		["color"] = Color3.fromRGB(80, 230, 120)
	},
	["TikTok Creator"] = {
		["level"] = 1,
		["emoji"] = "\240\159\142\181",
		["color"] = nil,
		["gradient"] = nil,
		["color"] = Color3.fromRGB(37, 244, 238),
		["gradient"] = { Color3.fromRGB(37, 244, 238), Color3.fromRGB(254, 44, 85) }
	},
	["VIP"] = {
		["level"] = 2,
		["emoji"] = "\240\159\145\145",
		["color"] = nil,
		["color"] = Color3.fromRGB(255, 200, 40)
	},
	["Developer"] = {
		["level"] = 3,
		["emoji"] = "\240\159\155\160\239\184\143",
		["color"] = nil,
		["color"] = Color3.fromRGB(70, 210, 255)
	},
	["Admin"] = {
		["level"] = 4,
		["emoji"] = "\240\159\155\161\239\184\143",
		["color"] = nil,
		["color"] = Color3.fromRGB(255, 72, 72)
	},
	["Owner"] = {
		["level"] = 5,
		["emoji"] = "\240\159\146\142",
		["color"] = nil,
		["gradient"] = nil,
		["color"] = Color3.fromRGB(196, 110, 255),
		["gradient"] = { Color3.fromRGB(255, 96, 196), Color3.fromRGB(140, 110, 255) }
	}
}
v_u_1.RANKS = v2
v_u_1.STAFF_LEVEL = 3
v_u_1.TAG_CHOICES = {
	"Member",
	"TikTok Creator",
	"VIP",
	"Developer",
	"Admin",
	"Owner"
}
v_u_1.TAG_COLORS = {
	Color3.fromRGB(255, 200, 40),
	Color3.fromRGB(255, 140, 30),
	Color3.fromRGB(255, 70, 90),
	Color3.fromRGB(255, 100, 200),
	Color3.fromRGB(170, 110, 255),
	Color3.fromRGB(70, 150, 255),
	Color3.fromRGB(60, 220, 255),
	Color3.fromRGB(70, 230, 130),
	Color3.fromRGB(255, 255, 255)
}
function v_u_1.info(p3) -- name: info
	-- upvalues: (copy) v_u_1
	return v_u_1.RANKS[p3] or v_u_1.RANKS.Member
end
function v_u_1.level(p4) -- name: level
	-- upvalues: (copy) v_u_1
	return v_u_1.info(p4).level
end
function v_u_1.label(p5) -- name: label
	-- upvalues: (copy) v_u_1
	local v6 = v_u_1.info(p5)
	local v7 = not v_u_1.RANKS[p5] and "Member" or p5
	if v6.emoji == "" then
		return v7
	else
		return v6.emoji .. " " .. v7
	end
end
function v_u_1.shown(p8) -- name: shown
	-- upvalues: (copy) v_u_1
	local v9 = p8:GetAttribute("TagRank")
	return (type(v9) ~= "string" or not v_u_1.RANKS[v9]) and (p8:GetAttribute("Rank") or "Member") or v9
end
function v_u_1.owned(p10) -- name: owned
	-- upvalues: (copy) v_u_1
	local v11 = {
		["Member"] = true,
		[p10:GetAttribute("Rank") or "Member"] = true
	}
	if p10:GetAttribute("Pass_VIP") == true then
		v11.VIP = true
	end
	local v12 = p10:GetAttribute("TagGrant")
	if type(v12) == "string" and v_u_1.RANKS[v12] then
		v11[v12] = true
	end
	local v13 = {}
	for _, v14 in v_u_1.TAG_CHOICES do
		if not v11[v14] then
			continue
		end
		table.insert(v13, v14)
	end
	return v13
end
function v_u_1.isStaff(p15) -- name: isStaff
	-- upvalues: (copy) v_u_1
	return v_u_1.level(p15:GetAttribute("Rank")) >= v_u_1.STAFF_LEVEL
end
return v_u_1