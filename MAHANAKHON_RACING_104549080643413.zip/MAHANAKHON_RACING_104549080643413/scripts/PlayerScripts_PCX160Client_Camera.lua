-- Path: Players/ygggggg55551/PlayerScripts/PCX160Client/Camera
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = game:GetService("Players")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("UserInputService")
local v_u_5 = require(v2:WaitForChild("Cam360Shared"))
local v_u_6 = CFrame.new(0, 0.2, 0.15)
local v_u_7 = { "DashSpeedo", "DashNeedle" }
local v_u_8 = {}
local v_u_9 = nil
local v_u_10 = {
	["Head"] = true
}
local function v_u_13(p11) -- name: inHelmet
	local v12 = p11:FindFirstAncestorOfClass("Model")
	while v12 and not v12:FindFirstChildOfClass("Humanoid") do
		if v12:GetAttribute("HelmetName") then
			return true
		end
		v12 = v12:FindFirstAncestorOfClass("Model")
	end
	return false
end
local function v_u_17(p14) -- name: collectBody
	local v15 = {}
	for _, v16 in p14:GetDescendants() do
		if not (v16:IsA("BasePart") or v16:IsA("Decal")) then
			continue
		end
		table.insert(v15, v16)
	end
	return v15
end
local function v_u_22(p18) -- name: applyHiding
	-- upvalues: (ref) v_u_9, (copy) v_u_10, (copy) v_u_13
	for _, v19 in v_u_9.body do
		if not v19.Parent then
			continue
		end
		local v20
		if v19:IsA("Decal") then
			v20 = v19.Parent
		else
			v20 = v19
		end
		local v21 = p18 and v20:IsA("BasePart")
		if v21 then
			v21 = (v_u_10[v20.Name] == true or v20:FindFirstAncestorOfClass("Accessory") ~= nil) and true or v_u_13(v20)
		end
		v19.LocalTransparencyModifier = v21 and 1 or 0
	end
end
local function v_u_75(p23) -- name: update
	-- upvalues: (ref) v_u_9, (copy) v_u_4, (copy) v_u_6, (copy) v_u_22
	local v24 = v_u_9
	if v24 and v24.mode == "first" then
		local v25 = workspace.CurrentCamera
		local v26 = v24.character:FindFirstChild("Head")
		if v26 then
			local v27
			if v_u_4.MouseEnabled and (not v_u_4.TouchEnabled or v_u_4.KeyboardEnabled) and v_u_4.MouseBehavior == Enum.MouseBehavior.LockCenter then
				v27 = v_u_4:GetMouseDelta()
				if v27.Magnitude > 250 then
					v27 = Vector2.zero
				end
			else
				v27 = Vector2.zero
			end
			if v27.Magnitude > 0.5 or (v24.touchDelta.Magnitude > 0 or v24.stick.Magnitude > 0) then
				v24.lookAt = os.clock()
			end
			v24.lookYaw = v24.lookYaw - (v27.X * 0.004363323129985824 + v24.touchDelta.X * 0.005235987755982988 + v24.stick.X * 2.6179938779914944 * p23)
			v24.lookPitch = v24.lookPitch - (v27.Y * 0.004363323129985824 + v24.touchDelta.Y * 0.005235987755982988 - v24.stick.Y * 2.6179938779914944 * p23)
			v24.touchDelta = Vector2.zero
			if os.clock() - v24.lookAt > 0.6 and v24.chassis.AssemblyLinearVelocity.Magnitude > 4 then
				local v28 = -3 * p23
				local v29 = math.exp(v28)
				v24.lookYaw = v24.lookYaw * v29
				v24.lookPitch = v24.lookPitch * v29
			end
			local v30 = v24.lookYaw
			v24.lookYaw = math.clamp(v30, -1.2217304763960306, 1.2217304763960306)
			local v31 = v24.lookPitch
			v24.lookPitch = math.clamp(v31, -0.6981317007977318, 0.6981317007977318)
			local v32, v33, v34 = v24.chassis.CFrame:ToEulerAnglesYXZ()
			local v35 = (v26.CFrame * v_u_6).Position
			if v25.CameraType ~= Enum.CameraType.Scriptable then
				v25.CameraType = Enum.CameraType.Scriptable
			end
			local v36 = v24.model:GetAttribute("RideHunch") or 0
			local v37 = (v24.model:GetAttribute("FirstPersonFov") or 80) + v36 * 12
			local v38 = -0.3490658503988659 - v36 * 0.17453292519943295
			local v39
			if v24.dash and v24.dash.Parent then
				local v40 = v24.chassis.CFrame:PointToObjectSpace(v24.dash.Position) - v24.chassis.CFrame:PointToObjectSpace(v35)
				local v41 = -v40.Y
				local v42 = -v40.Z
				local v43 = math.max(v42, 0.3)
				local v44 = math.atan2(v41, v43)
				local v45 = v24.model:GetAttribute("DashScreenDrop") or 0.5
				local v46 = -v44
				local v47 = v37 / 2
				local v48 = math.rad(v47)
				local v49 = v45 * math.tan(v48)
				local v50 = v46 + math.atan(v49)
				v38 = math.clamp(v50, -1.0471975511965976, 0)
				local v51 = v37 / 2
				if v38 + math.rad(v51) < 0.3839724354387525 then
					v39 = math.max(v37, 105)
					local v52 = -v44
					local v53 = v39 / 2
					local v54 = math.rad(v53)
					local v55 = v45 * math.tan(v54)
					local v56 = v52 + math.atan(v55)
					local v57 = math.clamp(v56, -1.0471975511965976, 0)
					local v58 = v39 / 2
					if v57 + math.rad(v58) > 0.3839724354387525 then
						for _ = 1, 14 do
							local v59 = (v37 + v39) / 2
							local v60 = -v44
							local v61 = v59 / 2
							local v62 = math.rad(v61)
							local v63 = v45 * math.tan(v62)
							local v64 = v60 + math.atan(v63)
							local v65 = math.clamp(v64, -1.0471975511965976, 0)
							local v66 = v59 / 2
							if v65 + math.rad(v66) < 0.3839724354387525 then
								v37 = v59
							else
								v39 = v59
							end
						end
					end
					local v67 = -v44
					local v68 = v39 / 2
					local v69 = math.rad(v68)
					local v70 = v45 * math.tan(v69)
					local v71 = v67 + math.atan(v70)
					v38 = math.clamp(v71, -1.0471975511965976, 0)
				else
					v39 = v37
				end
			else
				v39 = v37
			end
			local v72 = v39 / 2
			local v73 = 0.3839724354387525 - math.rad(v72)
			local v74 = math.max(v38, v73)
			v25.CFrame = CFrame.new(v35) * CFrame.fromEulerAnglesYXZ(v32 + v74 + v24.lookPitch, v33 + v24.lookYaw, v34 * 0.6)
			v25.FieldOfView = v39
			v_u_4.MouseBehavior = Enum.MouseBehavior.LockCenter
			v_u_22(true)
		end
	else
		return
	end
end
local function v_u_81() -- name: update360
	-- upvalues: (ref) v_u_9, (copy) v_u_5
	local v76 = v_u_9
	if v76 and v76.mode == "360" then
		local v77 = v76.model:GetAttribute(v_u_5.ATTRIBUTE)
		if v76.lensMount ~= v77 then
			v76.lens = v_u_5.lensLocal(v76.model, v77)
			v76.lensMount = v77
		end
		local v78 = v76.character:FindFirstChild("Head")
		if v76.lens and v78 then
			local v79 = workspace.CurrentCamera
			if v79.CameraType ~= Enum.CameraType.Scriptable then
				v79.CameraType = Enum.CameraType.Scriptable
			end
			local v80 = v76.chassis.CFrame.UpVector
			v79.CFrame = CFrame.lookAt(v76.chassis.CFrame:PointToWorldSpace(v76.lens), v78.Position - v80 * (v_u_5.LOOK_DOWN[v77] or 0.5), v80)
			v79.FieldOfView = v_u_5.FOV[v77] or 100
		end
	else
		return
	end
end
local function v_u_92(p82) -- name: setMode
	-- upvalues: (ref) v_u_9, (copy) v_u_3, (copy) v_u_17, (copy) v_u_75, (copy) v_u_4, (copy) v_u_81
	local v_u_83 = v_u_9
	local v84 = workspace.CurrentCamera
	local v85 = v_u_3.UnbindFromRenderStep
	local v86 = v_u_3
	pcall(v85, v86, "PCX160Cam360")
	v_u_83.lensMount = nil
	v_u_83.mode = p82
	if p82 == "first" then
		v_u_83.lookYaw = 0
		v_u_83.lookPitch = 0
		v_u_83.body = v_u_17(v_u_83.character)
		v_u_83.added = v_u_83.character.DescendantAdded:Connect(function(p87)
			-- upvalues: (copy) v_u_83
			if p87:IsA("BasePart") or p87:IsA("Decal") then
				local v88 = v_u_83.body
				table.insert(v88, p87)
			end
		end)
		v84.CameraType = Enum.CameraType.Scriptable
		v_u_3:BindToRenderStep("PCX160FirstPerson", Enum.RenderPriority.Camera.Value + 1, v_u_75)
	else
		if v_u_83.added then
			v_u_83.added:Disconnect()
			v_u_83.added = nil
		end
		local v89 = v_u_3.UnbindFromRenderStep
		local v90 = v_u_3
		pcall(v89, v90, "PCX160FirstPerson")
		v84.CameraType = Enum.CameraType.Custom
		v84.CameraSubject = v_u_83.seat
		v84.FieldOfView = v_u_83.savedFov
		v_u_4.MouseBehavior = Enum.MouseBehavior.Default
		if v_u_83.body then
			for _, v91 in v_u_9.body do
				if not v91.Parent then
					continue
				end
				if v91:IsA("Decal") then
					local _ = v91.Parent
				end
				v91.LocalTransparencyModifier = 0
			end
		end
		if p82 == "360" then
			v84.CameraType = Enum.CameraType.Scriptable
			v_u_3:BindToRenderStep("PCX160Cam360", Enum.RenderPriority.Camera.Value + 1, v_u_81)
		end
	end
end
local function v_u_103() -- name: toThird
	-- upvalues: (ref) v_u_9, (copy) v_u_3, (copy) v_u_4, (copy) v_u_1
	local v93 = v_u_9
	local v94 = v_u_9
	local v95 = workspace.CurrentCamera
	local v96 = v_u_3.UnbindFromRenderStep
	local v97 = v_u_3
	pcall(v96, v97, "PCX160Cam360")
	v94.lensMount = nil
	v94.mode = "third"
	if v94.added then
		v94.added:Disconnect()
		v94.added = nil
	end
	local v98 = v_u_3.UnbindFromRenderStep
	local v99 = v_u_3
	pcall(v98, v99, "PCX160FirstPerson")
	v95.CameraType = Enum.CameraType.Custom
	v95.CameraSubject = v94.seat
	v95.FieldOfView = v94.savedFov
	v_u_4.MouseBehavior = Enum.MouseBehavior.Default
	if v94.body then
		for _, v100 in v_u_9.body do
			if not v100.Parent then
				continue
			end
			if v100:IsA("Decal") then
				local _ = v100.Parent
			end
			v100.LocalTransparencyModifier = 0
		end
	end
	v93.zoomHold = os.clock() + 0.6
	local v_u_101 = v_u_1.LocalPlayer
	local v_u_102 = v_u_101.CameraMinZoomDistance
	if v_u_102 < 12 then
		v_u_101.CameraMinZoomDistance = 12
		task.delay(0.15, function()
			-- upvalues: (copy) v_u_101, (copy) v_u_102
			if v_u_101.CameraMinZoomDistance == 12 then
				v_u_101.CameraMinZoomDistance = v_u_102
			end
		end)
	end
end
function v_u_8.start(p_u_104, p105) -- name: start
	-- upvalues: (copy) v_u_8, (ref) v_u_9, (copy) v_u_7, (copy) v_u_4, (copy) v_u_3, (copy) v_u_17, (copy) v_u_75, (copy) v_u_103, (copy) v_u_5, (copy) v_u_92
	v_u_8.stop()
	v_u_9 = {
		["model"] = nil,
		["chassis"] = nil,
		["seat"] = nil,
		["humanoid"] = nil,
		["character"] = nil,
		["savedFov"] = nil,
		["mode"] = "third",
		["lookYaw"] = 0,
		["lookPitch"] = 0,
		["lookAt"] = 0,
		["touchDelta"] = nil,
		["lookTouches"] = nil,
		["stick"] = nil,
		["body"] = nil,
		["dash"] = nil,
		["model"] = p_u_104,
		["chassis"] = p_u_104.Chassis,
		["seat"] = p_u_104.VehicleSeat,
		["humanoid"] = p105,
		["character"] = p105.Parent,
		["savedFov"] = workspace.CurrentCamera.FieldOfView,
		["touchDelta"] = Vector2.zero,
		["lookTouches"] = {},
		["stick"] = Vector2.zero
	}
	for _, v106 in v_u_7 do
		v_u_9.dash = v_u_9.dash or p_u_104:FindFirstChild(v106, true)
	end
	v_u_9.inputChanged = v_u_4.InputChanged:Connect(function(p107, p108)
		-- upvalues: (ref) v_u_9
		if p107.KeyCode == Enum.KeyCode.Thumbstick2 then
			local v109 = Vector2.new(p107.Position.X, p107.Position.Y)
			local v110 = v_u_9
			if v109.Magnitude <= 0.15 then
				v109 = Vector2.zero
			end
			v110.stick = v109
		elseif p107.UserInputType == Enum.UserInputType.Touch and (not p108 and v_u_9.lookTouches[p107]) then
			local v111 = v_u_9
			v111.touchDelta = v111.touchDelta + Vector2.new(p107.Delta.X, p107.Delta.Y)
		end
	end)
	v_u_9.inputBegan = v_u_4.InputBegan:Connect(function(p112, p113)
		-- upvalues: (ref) v_u_9
		if p112.UserInputType == Enum.UserInputType.Touch and (not p113 and p112.Position.X > workspace.CurrentCamera.ViewportSize.X * 0.45) then
			v_u_9.lookTouches[p112] = true
		end
	end)
	v_u_9.inputEnded = v_u_4.InputEnded:Connect(function(p114)
		-- upvalues: (ref) v_u_9
		v_u_9.lookTouches[p114] = nil
	end)
	v_u_9.zoomWatch = v_u_3.Heartbeat:Connect(function()
		-- upvalues: (ref) v_u_9, (ref) v_u_3, (ref) v_u_17, (ref) v_u_75
		local v115 = v_u_9
		local v116 = workspace.CurrentCamera
		if v115 and (v115.mode == "third" and (os.clock() > (v115.zoomHold or 0) and (v116.CameraType == Enum.CameraType.Custom and (v116.CameraSubject == v115.seat and (v116.CFrame.Position - v116.Focus.Position).Magnitude < 4)))) then
			local v_u_117 = v_u_9
			local v118 = workspace.CurrentCamera
			local v119 = v_u_3.UnbindFromRenderStep
			local v120 = v_u_3
			pcall(v119, v120, "PCX160Cam360")
			v_u_117.lensMount = nil
			v_u_117.mode = "first"
			v_u_117.lookYaw = 0
			v_u_117.lookPitch = 0
			v_u_117.body = v_u_17(v_u_117.character)
			v_u_117.added = v_u_117.character.DescendantAdded:Connect(function(p121)
				-- upvalues: (copy) v_u_117
				if p121:IsA("BasePart") or p121:IsA("Decal") then
					local v122 = v_u_117.body
					table.insert(v122, p121)
				end
			end)
			v118.CameraType = Enum.CameraType.Scriptable
			v_u_3:BindToRenderStep("PCX160FirstPerson", Enum.RenderPriority.Camera.Value + 1, v_u_75)
		end
	end)
	v_u_9.zoomOut = v_u_4.InputChanged:Connect(function(p123, p124)
		-- upvalues: (ref) v_u_9, (ref) v_u_103
		if v_u_9 and (v_u_9.mode == "first" and (not p124 and (p123.UserInputType == Enum.UserInputType.MouseWheel and p123.Position.Z < 0))) then
			v_u_103()
		end
	end)
	v_u_9.zoomKey = v_u_4.InputBegan:Connect(function(p125)
		-- upvalues: (ref) v_u_9, (ref) v_u_4, (ref) v_u_103
		if v_u_9 and (v_u_9.mode == "first" and (p125.KeyCode == Enum.KeyCode.O and not v_u_4:GetFocusedTextBox())) then
			v_u_103()
		end
	end)
	v_u_9.pinch = v_u_4.TouchPinch:Connect(function(_, p126, _, p127, p128)
		-- upvalues: (ref) v_u_9, (ref) v_u_103
		if v_u_9 and (v_u_9.mode == "first" and (not p128 and (p127 == Enum.UserInputState.End and p126 < 0.85))) then
			v_u_103()
		end
	end)
	v_u_9.cam360 = p_u_104:GetAttributeChangedSignal(v_u_5.ATTRIBUTE):Connect(function()
		-- upvalues: (ref) v_u_9, (copy) p_u_104, (ref) v_u_5, (ref) v_u_92, (ref) v_u_103
		if v_u_9 then
			if p_u_104:GetAttribute(v_u_5.ATTRIBUTE) then
				v_u_92("360")
			elseif v_u_9.mode == "360" then
				v_u_103()
			end
		else
			return
		end
	end)
	local v129 = v_u_9
	local v130 = workspace.CurrentCamera
	local v131 = v_u_3.UnbindFromRenderStep
	local v132 = v_u_3
	pcall(v131, v132, "PCX160Cam360")
	v129.lensMount = nil
	v129.mode = "third"
	if v129.added then
		v129.added:Disconnect()
		v129.added = nil
	end
	local v133 = v_u_3.UnbindFromRenderStep
	local v134 = v_u_3
	pcall(v133, v134, "PCX160FirstPerson")
	v130.CameraType = Enum.CameraType.Custom
	v130.CameraSubject = v129.seat
	v130.FieldOfView = v129.savedFov
	v_u_4.MouseBehavior = Enum.MouseBehavior.Default
	if v129.body then
		for _, v135 in v_u_9.body do
			if not v135.Parent then
				continue
			end
			if v135:IsA("Decal") then
				local _ = v135.Parent
			end
			v135.LocalTransparencyModifier = 0
		end
	end
end
function v_u_8.toggle() -- name: toggle
	-- upvalues: (ref) v_u_9, (copy) v_u_3, (copy) v_u_17, (copy) v_u_75, (copy) v_u_5, (copy) v_u_92, (copy) v_u_103
	if v_u_9 then
		if v_u_9.mode == "third" then
			local v_u_136 = v_u_9
			local v137 = workspace.CurrentCamera
			local v138 = v_u_3.UnbindFromRenderStep
			local v139 = v_u_3
			pcall(v138, v139, "PCX160Cam360")
			v_u_136.lensMount = nil
			v_u_136.mode = "first"
			v_u_136.lookYaw = 0
			v_u_136.lookPitch = 0
			v_u_136.body = v_u_17(v_u_136.character)
			v_u_136.added = v_u_136.character.DescendantAdded:Connect(function(p140)
				-- upvalues: (copy) v_u_136
				if p140:IsA("BasePart") or p140:IsA("Decal") then
					local v141 = v_u_136.body
					table.insert(v141, p140)
				end
			end)
			v137.CameraType = Enum.CameraType.Scriptable
			v_u_3:BindToRenderStep("PCX160FirstPerson", Enum.RenderPriority.Camera.Value + 1, v_u_75)
			return
		end
		if v_u_9.mode == "first" and v_u_9.model:GetAttribute(v_u_5.ATTRIBUTE) then
			v_u_92("360")
			return
		end
		v_u_103()
	end
end
function v_u_8.view360() -- name: view360
	-- upvalues: (ref) v_u_9, (copy) v_u_5, (copy) v_u_103, (copy) v_u_92
	if not (v_u_9 and v_u_9.model:GetAttribute(v_u_5.ATTRIBUTE)) then
		return false
	end
	if v_u_9.mode == "360" then
		v_u_103()
	else
		v_u_92("360")
	end
	return true
end
function v_u_8.mode() -- name: mode
	-- upvalues: (ref) v_u_9
	return v_u_9 and v_u_9.mode or "third"
end
function v_u_8.look() -- name: look
	-- upvalues: (ref) v_u_9
	if v_u_9 then
		return v_u_9.lookYaw, v_u_9.lookPitch
	else
		return 0, 0
	end
end
function v_u_8.stop() -- name: stop
	-- upvalues: (ref) v_u_9, (copy) v_u_3, (copy) v_u_4
	if v_u_9 then
		local v142 = v_u_9
		local v143 = workspace.CurrentCamera
		local v144 = v_u_3.UnbindFromRenderStep
		local v145 = v_u_3
		pcall(v144, v145, "PCX160Cam360")
		v142.lensMount = nil
		v142.mode = "third"
		if v142.added then
			v142.added:Disconnect()
			v142.added = nil
		end
		local v146 = v_u_3.UnbindFromRenderStep
		local v147 = v_u_3
		pcall(v146, v147, "PCX160FirstPerson")
		v143.CameraType = Enum.CameraType.Custom
		v143.CameraSubject = v142.seat
		v143.FieldOfView = v142.savedFov
		v_u_4.MouseBehavior = Enum.MouseBehavior.Default
		if v142.body then
			for _, v148 in v_u_9.body do
				if not v148.Parent then
					continue
				end
				if v148:IsA("Decal") then
					local _ = v148.Parent
				end
				v148.LocalTransparencyModifier = 0
			end
		end
		v_u_9.inputChanged:Disconnect()
		v_u_9.inputBegan:Disconnect()
		v_u_9.inputEnded:Disconnect()
		v_u_9.zoomWatch:Disconnect()
		v_u_9.zoomOut:Disconnect()
		v_u_9.zoomKey:Disconnect()
		v_u_9.pinch:Disconnect()
		v_u_9.cam360:Disconnect()
		local v149 = v_u_9.humanoid
		if v149 and v149.Parent then
			workspace.CurrentCamera.CameraSubject = v149
		end
		v_u_9 = nil
	end
end
return v_u_8