-- Path: Players/ygggggg55551/PlayerScripts/DynoLive
-- Class: LocalScript  true/Enum.RunContext.Legacy
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = require(game:GetService("ReplicatedStorage"):WaitForChild("UiOwn")).Instance
local v_u_2 = game:GetService("Players")
local v3 = game:GetService("ReplicatedStorage")
local v4 = game:GetService("RunService")
local v_u_5 = require(v3:WaitForChild("GameShared"))
local v_u_6 = require(v3:WaitForChild("CareShared"))
local v_u_7 = require(v3:WaitForChild("LiveRpm"))
local v_u_8 = Color3.fromRGB(255, 50, 140)
local v_u_9 = Color3.fromRGB(40, 220, 255)
local v_u_10 = Color3.fromRGB(236, 242, 255)
local v_u_11 = Color3.fromRGB(255, 176, 40)
local v_u_12 = Color3.fromRGB(255, 50, 70)
local v_u_13 = Color3.fromRGB(44, 48, 66)
local v_u_14 = Color3.fromRGB(110, 24, 36)
local v_u_15 = Color3.fromRGB(80, 230, 120)
local v_u_16 = Color3.fromRGB(255, 190, 60)
local v_u_17 = Color3.fromRGB(255, 84, 84)
local function v_u_26(p18, p19) -- name: hpAt
	-- upvalues: (copy) v_u_5
	local v20 = v_u_5.upgradeScales(p18)
	local v21 = (p18:GetAttribute("MaxSpeed") or 100) * 0.12 * v20
	local v22 = p19 / 9000
	local v23 = math.clamp(v22, 0, 1) / 0.86
	local v24
	if v23 <= 1 then
		v24 = v23 ^ 1.5 * (2.5 - v23 * 1.5)
	else
		v24 = 1 - (v23 - 1) * 0.86 * 2.2
	end
	local v25 = v21 * v24
	return math.max(0, v25)
end
local function v_u_34(p27) -- name: graphTop
	-- upvalues: (copy) v_u_26
	local v28 = 0
	for v29 = 1700, 9000, 100 do
		local v30 = v_u_26(p27, v29)
		local v31 = v29 <= 500 and 0 or v30 * 5252 / v29
		v28 = math.max(v28, v30, v31)
	end
	local v32 = v28 * 1.2 / 5
	local v33 = math.ceil(v32) * 5
	return math.max(10, v33)
end
local v_u_35 = {}
local function v_u_40(p36) -- name: register
	-- upvalues: (copy) v_u_35
	if p36.Name == "DynoLive" and p36:IsA("SurfaceGui") then
		local v37 = p36:FindFirstChild("Root") or p36:WaitForChild("Root", 5)
		local v38 = not p36:FindFirstAncestor("DynoCell") and p36.Parent
		if v38 then
			v38 = p36.Parent.Parent
		end
		if v37 and v38 then
			local v39 = v_u_35[v38]
			if not v39 then
				v39 = {
					["run"] = nil,
					["last"] = nil,
					["top"] = 0,
					["run"] = {}
				}
				v_u_35[v38] = v39
			end
			v39.tel = v37:FindFirstChild("Telemetry") or v39.tel
			v39.dyn = v37:FindFirstChild("Dyno") or v39.dyn
		end
	else
		return
	end
end
task.spawn(function()
	-- upvalues: (copy) v_u_40
	local v41 = workspace:WaitForChild("Map", 60)
	if v41 then
		v41.DescendantAdded:Connect(function(p42)
			-- upvalues: (ref) v_u_40
			if p42.Name == "DynoLive" then
				task.spawn(v_u_40, p42)
			end
		end)
		for _, v43 in v41:GetDescendants() do
			if v43.Name ~= "DynoLive" then
				continue
			end
			task.spawn(v_u_40, v43)
		end
	end
end)
local function v_u_54(p44) -- name: onPad
	local v45 = workspace:FindFirstChild("SpawnedVehicles")
	local v46 = 9
	local v47 = nil
	for _, v48 in not v45 and {} or v45:GetChildren() do
		local v49 = v48:GetPivot().Position - p44.Position
		local v50 = v49.X
		local v51 = v49.Z
		local v52 = Vector3.new(v50, 0, v51).Magnitude
		if v52 >= v46 then
			continue
		end
		local v53 = v49.Y
		if math.abs(v53) >= 8 then
			continue
		end
		v47 = v48
		v46 = v52
	end
	return v47
end
local function v_u_67(p55, p56, p57, p58, p59, p60) -- name: segment
	-- upvalues: (copy) v_u_1
	local v61 = (p56 + p57) / 2
	local v62 = p57 - p56
	local v63 = v_u_1.new("Frame")
	v63.BorderSizePixel = 0
	v63.BackgroundColor3 = p58
	v63.BackgroundTransparency = p60 or 0
	v63.AnchorPoint = Vector2.new(0.5, 0.5)
	v63.Position = UDim2.fromOffset(v61.X, v61.Y)
	v63.Size = UDim2.fromOffset(v62.Magnitude + 2, p59 or 4)
	local v64 = v62.Y
	local v65 = v62.X
	local v66 = math.atan2(v64, v65)
	v63.Rotation = math.deg(v66)
	v63.Parent = p55
end
local function v_u_79(p68, p69, p70, p71, p72) -- name: column
	-- upvalues: (copy) v_u_1
	local v73 = v_u_1.new("Frame")
	v73.BorderSizePixel = 0
	v73.BackgroundColor3 = p72
	v73.Position = UDim2.fromOffset(p69, p71)
	local v74 = UDim2.fromOffset
	local v75 = p70 - p69 + 1
	local v76 = math.max(1, v75)
	local v77 = 400 - p71
	v73.Size = v74(v76, (math.max(0, v77)))
	local v78 = v_u_1.new("UIGradient")
	v78.Rotation = 90
	v78.Transparency = NumberSequence.new(0.6, 0.97)
	v78.Parent = v73
	v73.Parent = p68
end
local function v_u_96(p80, p81, p82) -- name: drawTicks
	-- upvalues: (copy) v_u_12, (copy) v_u_11, (copy) v_u_10, (copy) v_u_14, (copy) v_u_13
	local v83 = p81.Rpm:FindFirstChild("Ticks")
	if v83 then
		local v84 = p80.ticks
		if not v84 or v84.folder ~= v83 then
			v84 = {
				["folder"] = v83
			}
			for _, v85 in v83:GetChildren() do
				table.insert(v84, v85)
			end
			table.sort(v84, function(p86, p87)
				return (p86:GetAttribute("Rpm") or 0) < (p87:GetAttribute("Rpm") or 0)
			end)
			p80.ticks = v84
			p80.lit = nil
		end
		local v88 = 0
		for v89, v90 in ipairs(v84) do
			if (v90:GetAttribute("Rpm") or 0) > p82 then
				continue
			end
			v88 = v89
		end
		if v88 ~= p80.lit then
			p80.lit = v88
			for v91, v92 in ipairs(v84) do
				local v93 = v92:GetAttribute("Rpm") or 0
				if v91 <= v88 then
					local v94
					if v93 >= 8600 then
						v94 = v_u_12
					elseif v93 >= 6800 then
						v94 = v_u_11
					else
						v94 = v_u_10
					end
					v92.BackgroundColor3 = v94
				else
					local v95
					if v93 >= 8600 then
						v95 = v_u_14
					else
						v95 = v_u_13
					end
					v92.BackgroundColor3 = v95
				end
			end
		end
	else
		return
	end
end
local function v_u_131(p97, p98, p99, p100) -- name: drawGraph
	-- upvalues: (copy) v_u_8, (copy) v_u_9, (copy) v_u_79, (copy) v_u_67, (copy) v_u_1
	local v101 = p97.dyn
	if v101 then
		local v102 = v101.Graph.Plot.Points
		v102:ClearAllChildren()
		for v103 = 0, 4 do
			local v104 = v101.Graph["Y" .. v103]
			local v105 = p99 * v103 / 4
			local v106 = math.floor(v105)
			v104.Text = tostring(v106)
		end
		local v107 = #p98 / 90
		local v108 = math.ceil(v107)
		local v109 = math.max(1, v108)
		local v110 = -1
		local v111 = nil
		for _, v112 in {
			{ "hp", v_u_8 },
			{ "tq", v_u_9 }
		} do
			local v113 = nil
			for v114 = 1, #p98, v109 do
				local v115 = p98[v114]
				local v116 = Vector2.new
				local v117 = v115.rpm / 9000
				local v118 = math.clamp(v117, 0, 1) * 584
				local v119 = v115[v112[1]] / p99
				local v120 = v116(v118, (1 - math.clamp(v119, 0, 1)) * 400)
				if v113 then
					if v112[1] == "hp" then
						local v121 = v_u_79
						local v122 = v113.X
						local v123 = math.floor(v122)
						local v124 = v120.X
						local v125 = math.floor(v124)
						local v126 = v113.Y
						local v127 = v120.Y
						v121(v102, v123, v125, math.min(v126, v127), v_u_8)
					end
					v_u_67(v102, v113, v120, v112[2], 12, 0.82)
					v_u_67(v102, v113, v120, v112[2], 4)
				end
				if v112[1] == "hp" and v110 < v115.hp then
					v110 = v115.hp
					v111 = v120
				end
				v113 = v120
			end
		end
		if p100 and v111 then
			local v128 = v_u_1.new("Frame")
			v128.BorderSizePixel = 0
			v128.BackgroundColor3 = Color3.new(1, 1, 1)
			v128.AnchorPoint = Vector2.new(0.5, 0.5)
			v128.Position = UDim2.fromOffset(v111.X, v111.Y)
			v128.Size = UDim2.fromOffset(16, 16)
			local v129 = v_u_1.new("UICorner")
			v129.CornerRadius = UDim.new(0.5, 0)
			v129.Parent = v128
			local v130 = v_u_1.new("UIStroke")
			v130.Color = v_u_8
			v130.Thickness = 4
			v130.Parent = v128
			v128.Parent = v102
		end
	end
end
local function v_u_183(p132) -- name: update
	-- upvalues: (copy) v_u_54, (copy) v_u_96, (copy) v_u_5, (copy) v_u_7, (copy) v_u_26, (copy) v_u_17, (copy) v_u_6, (copy) v_u_16, (copy) v_u_15, (copy) v_u_131, (copy) v_u_34
	local v133 = p132.tel
	local v134 = p132.dyn
	local v135
	if v133 == nil then
		v135 = false
	else
		v135 = v133:IsDescendantOf(workspace)
	end
	if v135 then
		local v136
		if v134 == nil then
			v136 = false
		else
			v136 = v134:IsDescendantOf(workspace)
		end
		if v136 then
			local v137 = v_u_54(p132.pad)
			if v137 then
				if p132.model ~= v137 then
					p132.model = v137
					p132.run = {}
					p132.top = 0
				end
				local v138 = v_u_5.vehicle(v137:GetAttribute("VehicleId"))
				local v139 = v134.Vehicle
				local v140
				if v138 then
					v140 = v138.th
				else
					v140 = v137.Name
				end
				v139.Text = v140 .. "  \194\183  " .. (v137:GetAttribute("OwnerName") or "")
				local v141 = v137:GetAttribute("EngineOn") == true
				local v142 = v141 and (v_u_7[v137] or 1700) or 0
				local v143 = v137:FindFirstChild("VehicleSeat") or v137:FindFirstChild("DriverSeat")
				local v144
				if v143 and v143.Occupant then
					local v145 = v143.ThrottleFloat
					v144 = math.max(0, v145)
				else
					v144 = 0
				end
				local _, _, v146 = v_u_5.upgradeScales(v137)
				local v147 = (v137:GetAttribute("MaxSpeed") or 100) * v146 * 1.008
				local v148 = v142 - 1700
				local v149 = math.max(0, v148) / 7300 * v147 + 0.5
				local v150 = math.floor(v149)
				local v151 = p132.top
				p132.top = math.max(v151, v150)
				local v152 = not v141 and 0 or v_u_26(v137, v142)
				local v153 = v142 <= 500 and 0 or v152 * 5252 / v142
				v133.Status.Text = v141 and (v144 > 0 and "RUN" or "idle") or "engine off"
				local v154 = v133.Rpm.Value
				local v155
				if v141 then
					local v156 = v142 / 10 + 0.5
					v155 = ("%d"):format(math.floor(v156) * 10)
				else
					v155 = "\226\128\148"
				end
				v154.Text = v155
				local v157 = v133.Rpm.Bar
				local v158 = v142 / 9000
				local v159
				if v142 >= 8600 then
					v159 = v_u_17
				else
					v159 = Color3.fromRGB(255, 196, 46)
				end
				v157.Fill.Size = UDim2.fromScale(math.clamp(v158, 0, 1), 1)
				if v159 then
					v157.Fill.BackgroundColor3 = v159
				end
				v_u_96(p132, v133, v142)
				v133.Gear.Value.Text = "N"
				v133.Roller.Value.Text = tostring(v150)
				local v160 = v133.Top.Value
				local v161 = p132.top
				v160.Text = tostring(v161)
				local v162 = v133.Throttle.Value
				local v163 = v144 * 100 + 0.5
				v162.Text = ("%d%%"):format((math.floor(v163)))
				v133.Throttle.Bar.Fill.Size = UDim2.fromScale(math.clamp(v144, 0, 1), 1)
				v133.Hp.Value.Text = not v141 and "\226\128\148" or ("%.1f"):format(v152)
				v133.Tq.Value.Text = not v141 and "\226\128\148" or ("%.1f"):format(v153)
				local v164 = v_u_6.health(v137)
				local v165 = v133.Engine.Value
				local v166 = v164 + 0.5
				v165.Text = ("%d%%"):format((math.floor(v166)))
				local v167 = v133.Engine.Value
				local v168
				if v164 < 15 then
					v168 = v_u_17
				elseif v164 < 40 then
					v168 = v_u_16
				else
					v168 = v_u_15
				end
				v167.TextColor3 = v168
				if v142 >= 8600 then
					v133.Warn.Text.Text = "\226\154\160 LIMITER: the engine is wearing fast!"
					v133.Warn.Text.TextColor3 = v_u_17
				elseif v141 then
					local v169 = v133.Warn.Text
					local v170 = v_u_6.fuel(v137) + 0.5
					v169.Text = ("Fuel %d%%  \194\183  hold full throttle from idle to the limiter for a run"):format((math.floor(v170)))
					v133.Warn.Text.TextColor3 = Color3.fromRGB(140, 148, 170)
				else
					v133.Warn.Text.Text = "Start the engine, then hold full throttle for a run."
					v133.Warn.Text.TextColor3 = Color3.fromRGB(140, 148, 170)
				end
				if v141 and v144 > 0.5 then
					local v171 = p132.run[#p132.run]
					if not v171 or v171.rpm + 25 < v142 then
						local v172 = p132.run
						table.insert(v172, {
							["rpm"] = v142,
							["hp"] = v152,
							["tq"] = v153
						})
						p132.drawRun = true
					end
				elseif #p132.run > 0 then
					local v173 = p132.run[1]
					if p132.run[#p132.run].rpm - v173.rpm > 2500 then
						local v174 = 0
						local v175 = 0
						local v176 = 0
						local v177 = 0
						for _, v178 in p132.run do
							if v174 < v178.hp then
								v174 = v178.hp
								v176 = v178.rpm
							end
							if v175 >= v178.tq then
								continue
							end
							v175 = v178.tq
							v177 = v178.rpm
						end
						p132.last = {
							["points"] = p132.run,
							["peak"] = v174,
							["peakRpm"] = v176,
							["tq"] = v175,
							["tqRpm"] = v177
						}
						local v179 = v134.Peak
						local v180 = v176 / 50
						local v181 = math.floor(v180) * 50
						local v182 = v177 / 50
						v179.Text = ("PEAK  %.1f hp @ %d  \194\183  %.1f lb-ft @ %d"):format(v174, v181, v175, math.floor(v182) * 50)
						v_u_131(p132, p132.last.points, v_u_34(v137), true)
					end
					p132.run = {}
				end
				if p132.drawRun and #p132.run > 1 then
					p132.drawRun = false
					v_u_131(p132, p132.run, (v_u_34(v137)))
				end
			else
				v133.Status.Text = "waiting for a bike"
				v133.Rpm.Value.Text = "\226\128\148"
				v133.Rpm.Bar.Fill.Size = UDim2.fromScale(0, 1)
				v_u_96(p132, v133, 0)
				v133.Throttle.Value.Text = "0%"
				v133.Throttle.Bar.Fill.Size = UDim2.fromScale(0, 1)
				v133.Roller.Value.Text = "0"
				v133.Hp.Value.Text = "\226\128\148"
				v133.Tq.Value.Text = "\226\128\148"
				v133.Warn.Text.Text = "Park a bike on the pad, engine on, then rev.\nRevving at the limiter wears the engine fast."
				v133.Warn.Text.TextColor3 = Color3.fromRGB(140, 148, 170)
				v134.Vehicle.Text = ""
				p132.model = nil
			end
		end
	end
end
local v_u_184 = 0
v4.Heartbeat:Connect(function(p185)
	-- upvalues: (ref) v_u_184, (copy) v_u_2, (copy) v_u_35, (copy) v_u_183
	v_u_184 = v_u_184 + p185
	if v_u_184 >= 0.03333333333333333 then
		v_u_184 = 0
		local v186 = v_u_2.LocalPlayer.Character
		if v186 then
			v186 = v_u_2.LocalPlayer.Character:FindFirstChild("HumanoidRootPart")
		end
		for v187, v188 in v_u_35 do
			local v189
			if v187 == nil then
				v189 = false
			else
				v189 = v187:IsDescendantOf(workspace)
			end
			if v189 then
				local v190 = v188.pad
				local v191
				if v190 == nil then
					v191 = false
				else
					v191 = v190:IsDescendantOf(workspace)
				end
				if not v191 then
					v188.pad = v187:FindFirstChild("DynoBikePad", true) or v187:FindFirstChild("DynoRoller", true)
				end
				if not v186 or (not v188.pad or (v186.Position - v188.pad.Position).Magnitude >= 120) then
					continue
				end
				local v192 = v_u_183
				local v193, v194 = pcall(v192, v188)
				if v193 then
					continue
				end
				warn("DynoLive:", v194)
			else
				v_u_35[v187] = nil
			end
		end
	end
end)