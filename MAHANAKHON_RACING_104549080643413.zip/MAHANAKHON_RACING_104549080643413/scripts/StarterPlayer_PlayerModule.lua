-- Path: StarterPlayer/PlayerModule
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

return {
	["ControlModule"] = {
		["Enabled"] = true
	}
}