-- Path: Players/ygggggg55551/PlayerScripts/PCX160Client/Driver
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = require(game:GetService("ReplicatedStorage"):WaitForChild("NetSeal"))
local v_u_2 = game:GetService("ContextActionService")
local v_u_3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("RunService")
local v_u_5 = game:GetService("UserInputService")
local v_u_6 = require(v_u_3:WaitForChild("PCX160Shared"))
local v_u_7 = require(v_u_3:WaitForChild("GameShared"))
local v_u_8 = require(v_u_3:WaitForChild("EcuShared"))
local v_u_9 = require(v_u_3:WaitForChild("GearShared"))
local v_u_10 = require(v_u_3:WaitForChild("VehicleFx"))
local v_u_11 = require(v_u_3:WaitForChild("BumpGuard"))
local v_u_12 = require(v_u_3:WaitForChild("TuckKeyShared"))
local v_u_13 = require(v_u_3:WaitForChild("DashcamView"))
local v_u_14 = require(script.Parent:WaitForChild("Camera"))
local v_u_15 = require(script.Parent:WaitForChild("Hud"))
local v_u_16 = require(script.Parent:WaitForChild("PaintMenu"))
local v_u_17 = {
	[Enum.KeyCode.Z] = "Left",
	[Enum.KeyCode.C] = "Right",
	[Enum.KeyCode.X] = "Hazard"
}
local v_u_18 = {
	[Enum.KeyCode.LeftControl] = true,
	[Enum.KeyCode.RightControl] = true
}
local v_u_19 = {
	[Enum.KeyCode.LeftShift] = true,
	[Enum.KeyCode.RightShift] = true
}
local v_u_20 = {
	[Enum.KeyCode.Q] = true,
	[Enum.KeyCode.ButtonL1] = true
}
local v_u_21 = {}
local v_u_22 = nil
local v_u_23 = nil
local function v_u_26(p24, ...) -- name: fire
	-- upvalues: (copy) v_u_3, (copy) v_u_6, (copy) v_u_1
	local v25 = v_u_3:FindFirstChild(v_u_6.REMOTE_NAME)
	if v25 then
		v_u_1.fire(v25, p24, ...)
	end
end
local function v_u_27() -- name: toggleRainbow
	-- upvalues: (copy) v_u_26
	v_u_26("Rainbow")
end
local function v_u_28() -- name: toggleMirrors
	-- upvalues: (copy) v_u_26
	v_u_26("Mirrors")
end
local function v_u_29() -- name: cycleCam360
	-- upvalues: (ref) v_u_22, (copy) v_u_13, (copy) v_u_14, (copy) v_u_26
	if not (v_u_22 and v_u_13.toggle(v_u_22.model)) then
		if not v_u_14.view360() then
			v_u_26("Cam360")
		end
	end
end
local function v_u_31(p30) -- name: setHorn
	-- upvalues: (copy) v_u_26
	v_u_26("Horn", p30 == true)
end
local function v_u_33(p32) -- name: setIndicator
	-- upvalues: (copy) v_u_26
	v_u_26("Indicator", p32)
end
local function v_u_34() -- name: toggleTailLight
	-- upvalues: (copy) v_u_26
	v_u_26("TailLight")
end
local function v_u_35() -- name: toggleEngine
	-- upvalues: (ref) v_u_22, (copy) v_u_26
	if v_u_22 then
		v_u_26("Engine", v_u_22.model:GetAttribute("EngineOn") ~= true)
	end
end
local function v_u_37() -- name: toggleStand
	-- upvalues: (ref) v_u_22, (copy) v_u_26
	if v_u_22 then
		local v36 = v_u_22.model
		if v36:GetAttribute("StandDown") == false then
			v_u_26("Stand", true, "Side")
			return
		elseif v36:GetAttribute("StandType") == "Center" then
			v_u_26("Stand", false)
		else
			v_u_26("Stand", true, "Center")
		end
	else
		return
	end
end
local v_u_38 = game:GetService("Players").LocalPlayer
local function v_u_39() -- name: togglePaint
	-- upvalues: (ref) v_u_22, (copy) v_u_38, (copy) v_u_16, (copy) v_u_7, (copy) v_u_10
	if v_u_22 and not v_u_38:GetAttribute("Tuning") then
		if v_u_16.isOpen() then
			v_u_16.close()
			return
		elseif v_u_7.inTuneBay(v_u_22.model) then
			v_u_38:SetAttribute("TuneHub", true)
		else
			v_u_10.hint(v_u_7.TUNE_HINT)
		end
	else
		return
	end
end
v_u_38:GetAttributeChangedSignal("OpenTune"):Connect(function()
	-- upvalues: (copy) v_u_38, (ref) v_u_22, (copy) v_u_16, (copy) v_u_26
	local v40 = v_u_38:GetAttribute("OpenTune")
	if v40 and (v_u_22 and v_u_22.isDriver) then
		v_u_38:SetAttribute("OpenTune", nil)
		if v40 == "Close" then
			v_u_16.close()
			return
		end
		local v41 = v_u_16.open
		local v42 = v_u_22.model
		local v43 = v_u_26
		local v44 = {}
		local v45
		if type(v40) == "string" then
			v45 = v40
		else
			v45 = nil
		end
		v44.group = v45
		v44.dock = type(v40) == "string"
		v41(v42, v43, v44)
	end
end)
local function v_u_46() -- name: toggleTuck
	-- upvalues: (ref) v_u_22, (copy) v_u_26
	if v_u_22 then
		v_u_26("Tuck", v_u_22.model:GetAttribute("Tuck") ~= true)
	end
end
v_u_38:GetAttributeChangedSignal("TuckPoseWant"):Connect(function()
	-- upvalues: (copy) v_u_38, (ref) v_u_22, (copy) v_u_26
	local v47 = v_u_38:GetAttribute("TuckPoseWant")
	if v47 ~= nil then
		v_u_38:SetAttribute("TuckPoseWant", nil)
		if v_u_22 and type(v47) == "string" then
			v_u_26("TuckPose", v47)
		end
	end
end)
local function v_u_52(p48) -- name: shiftGear
	-- upvalues: (ref) v_u_22, (copy) v_u_9, (copy) v_u_10
	local v49 = v_u_22
	if v49 and (v49.isDriver and v49.gears) then
		local v50, v51 = v_u_9.shift(v49.gears, v49.gear, p48, v49.speed, v49.top)
		if v50 then
			v49.gear = v50
			v49.model:SetAttribute("Gear", v50)
		elseif v51 and os.clock() - v49.hintAt > 1 then
			v49.hintAt = os.clock()
			v_u_10.hint(v51)
		end
	else
		return
	end
end
local function v_u_54(p53) -- name: setWheelie
	-- upvalues: (ref) v_u_22
	if v_u_22 then
		v_u_22.wheelieHeld = p53
	end
end
local function v_u_55() -- name: startDismount
	-- upvalues: (ref) v_u_22, (copy) v_u_26
	if v_u_22 and (v_u_22.isDriver and v_u_22.model:GetAttribute("DismountStart") == nil) then
		v_u_22.model:SetAttribute("DismountStart", os.clock())
		v_u_26("Dismount", "Start")
	end
end
local function v_u_57(_, p56) -- name: onDismountAction
	-- upvalues: (copy) v_u_55
	if p56 == Enum.UserInputState.Begin then
		v_u_55()
	end
	return Enum.ContextActionResult.Sink
end
local function v_u_65(p58) -- name: writeSuspension
	local v59 = p58.frontWeld
	local v60 = p58.rearWeld
	if v59 then
		if v59.C0 ~= p58.frontWritten then
			p58.frontRest = v59.C0
		end
		local v61 = CFrame.new
		local v62 = p58.forkAxis
		local v63 = p58.compF
		local v64 = p58.forkAxis.Y
		p58.frontWritten = v61(v62 * (v63 / math.max(v64, 0.5))) * p58.frontRest
		v59.C0 = p58.frontWritten
	end
	if v60 then
		if v60.C0 ~= p58.rearWritten then
			p58.rearRest = v60.C0
		end
		p58.rearWritten = CFrame.new(0, p58.compR, 0) * p58.rearRest
		v60.C0 = p58.rearWritten
	end
end
local function v_u_67(p66) -- name: restoreSuspension
	if p66.frontWeld and (p66.frontRest and p66.frontWeld.C0 == p66.frontWritten) then
		p66.frontWeld.C0 = p66.frontRest
	end
	if p66.rearWeld and (p66.rearRest and p66.rearWeld.C0 == p66.rearWritten) then
		p66.rearWeld.C0 = p66.rearRest
	end
	p66.frontWritten = nil
	p66.rearWritten = nil
	p66.compF = 0
	p66.compR = 0
	p66.velF = 0
	p66.velR = 0
end
local function v_u_79(p68, p69, p70, p71, p72, p73) -- name: spring
	-- upvalues: (copy) v_u_6
	local v74 = math.min(p73, 0.15)
	local v75 = v74 / 0.02 - 1e-6
	local v76 = math.ceil(v75)
	local v77 = math.max(1, v76)
	local v78 = v74 / v77
	for _ = 1, v77 do
		p69 = p69 + (v_u_6.SUSP_STIFFNESS * (p70 - p68) - v_u_6.SUSP_DAMPING * p69) * v78
		p68 = p68 + p69 * v78
		if p72 < p68 then
			p69 = math.min(p69, 0)
			p68 = p72
		else
			if p68 >= p71 then
				continue
			end
			p69 = math.max(p69, 0)
			p68 = p71
		end
	end
	return p68, p69
end
local function v_u_101(p80, p81, p82, p83) -- name: stepSuspension
	-- upvalues: (copy) v_u_6, (copy) v_u_79, (copy) v_u_65
	local v84 = -p82 / v_u_6.BRAKE_DECEL
	local v85 = math.clamp(v84, 0, 1)
	local v86 = p82 / v_u_6.THROTTLE_ACCEL
	local v87 = math.clamp(v86, 0, 1)
	local v88 = p80.lean
	local v89 = 1 / math.cos(v88) - 1
	local v90 = v_u_6.SUSP_EXTEND
	local v91 = v85 * 0.85 * v_u_6.SUSP_FRONT_TRAVEL - v87 * 0.3 * v90 + v89 * v_u_6.SUSP_FRONT_TRAVEL
	local v92 = v87 * 0.7 * v_u_6.SUSP_REAR_TRAVEL - v85 * 0.5 * v90 + v89 * v_u_6.SUSP_REAR_TRAVEL
	local v93 = p80.wheelie > 0.05 and 0 or v91
	local v94 = p83 - p80.lastVy
	p80.lastVy = p83
	if v94 > 6 then
		p80.velF = p80.velF + v94 * 0.06
		p80.velR = p80.velR + v94 * 0.06
	end
	local v95, v96 = v_u_6.compressionTravel(p80.model)
	local v97, v98 = v_u_79(p80.compF, p80.velF, math.min(v93, v95), -v90, v95, p81)
	p80.compF = v97
	p80.velF = v98
	local v99, v100 = v_u_79(p80.compR, p80.velR, math.min(v92, v96), -v90, v96, p81)
	p80.compR = v99
	p80.velR = v100
	v_u_65(p80)
end
local v_u_102 = RaycastParams.new()
v_u_102.FilterType = Enum.RaycastFilterType.Exclude
v_u_102.RespectCanCollide = true
local function v_u_124(p103, p104) -- name: solidThere
	-- upvalues: (copy) v_u_102
	local v105 = p104.X
	local v106 = p104.Z
	local v107 = Vector3.new(v105, 0, v106)
	if v107.Magnitude < 1 then
		return false
	end
	local v108 = -v107.Unit
	local v109, v110 = p103.model:GetBoundingBox()
	v_u_102.FilterDescendantsInstances = { p103.model, p103.character }
	local v111 = v110.X
	local v112 = v110.Z
	local v113 = math.min(v111, v112) * 0.8
	local v114 = v110.Y - 0.6 - 0.2
	local v115 = math.max(v114, 0.8)
	local v116 = Vector3.new(v113, v115, v113)
	local v117 = v110.X
	local v118 = v110.Z
	local v119 = math.max(v117, v118) / 2 + 2.5
	local v120 = p103.chassis.AssemblyRootPart
	local v121 = CFrame.lookAt(v109.Position + Vector3.new(0, 0.3, 0), v109.Position + Vector3.new(0, 0.3, 0) + v108)
	local v122 = workspace:Blockcast(v121, v116, v108 * v119, v_u_102)
	local v123
	if v122 == nil then
		v123 = false
	else
		v123 = v122.Instance.AssemblyRootPart ~= v120
	end
	return v123
end
local function v_u_136(p125, p126) -- name: crash
	-- upvalues: (copy) v_u_67, (copy) v_u_6, (copy) v_u_10, (copy) v_u_26
	if not p125.crashed then
		p125.crashed = true
		p125.crashedAt = os.clock()
		v_u_67(p125)
		p125.linear.MaxAxesForce = Vector3.new(0, 0, 0)
		local v127 = p125.model:FindFirstChild("CrashBody")
		if v127 then
			v127.CanCollide = true
		end
		local v128 = p125.chassis
		local v129 = CFrame.Angles(0, p125.heading, 0)
		local v130 = p125.lean
		local v131
		if math.abs(v130) > 0.05 then
			local v132 = p125.lean
			v131 = math.sign(v132)
		else
			v131 = math.random() < 0.5 and -1 or 1
		end
		p125.align.Responsiveness = v_u_6.CRASH_FALL_RESPONSIVENESS
		p125.align.CFrame = v_u_6.lyingRotation(v129, v131)
		v128.AssemblyLinearVelocity = v128.AssemblyLinearVelocity * v_u_6.CRASH_BOUNCE_KEEP
		local v133 = p126.Magnitude / 90
		local v134 = math.clamp(v133, 0.3, 1)
		local v135 = v128.Position + v129.LookVector * (p125.wheelbase * 0.5 + 1)
		v_u_10.burst(v135, -v129.LookVector + Vector3.new(0, 0.7, 0), v134)
		v_u_10.report(v135, -v129.LookVector + Vector3.new(0, 0.7, 0), v134)
		v_u_10.shake(1.2)
		v_u_26("Crash", p126, v131)
	end
end
local function v_u_143(p137) -- name: onTouched
	-- upvalues: (ref) v_u_22, (copy) v_u_3, (copy) v_u_10, (copy) v_u_1
	local v138 = v_u_22
	if v138 and not v138.crashed then
		local v139 = p137:FindFirstAncestorOfClass("Model")
		local v140
		if v139 then
			v140 = v139:FindFirstChildOfClass("Humanoid")
		else
			v140 = v139
		end
		if v140 and (v139 ~= v138.character and not v140.SeatPart) then
			if v138.chassis.AssemblyLinearVelocity.Magnitude < 22 then
				return
			else
				local v141 = os.clock()
				if (v138.hitPeople[v139] or 0) <= v141 - 1 then
					v138.hitPeople[v139] = v141
					local v142 = v_u_3:FindFirstChild(v_u_10.REMOTE_NAME)
					if v142 then
						v_u_1.fire(v142, "HitPerson", v139)
					end
				end
			end
		else
			return
		end
	else
		return
	end
end
local function v_u_148(p144, p145) -- name: groundHeight
	for _ = 1, 4 do
		local v146 = workspace:Raycast(p144 + Vector3.new(0, 2.5, 0), Vector3.new(0, -8, 0), p145)
		local v147
		if v146 then
			v147 = v146.Instance:FindFirstAncestorOfClass("Model")
		else
			v147 = v146
		end
		if not (v147 and v147:FindFirstChildOfClass("Humanoid")) then
			if v146 then
				v146 = v146.Position.Y
			end
			return v146
		end
		p145:AddToFilter(v147)
	end
	return nil
end
local function v_u_162(p149) -- name: keysToSeat
	-- upvalues: (copy) v_u_5
	local v150 = p149.seat.Occupant
	if p149.seat:IsA("VehicleSeat") and (v150 and (v150.Parent == game:GetService("Players").LocalPlayer.Character and not v_u_5:GetFocusedTextBox())) then
		local v151 = Enum.KeyCode.W
		local v152 = Enum.KeyCode.Up
		local v153 = Enum.KeyCode.S
		local v154 = Enum.KeyCode.Down
		local v155 = 0
		if v_u_5:IsKeyDown(v151) or v_u_5:IsKeyDown(v152) then
			v155 = v155 + 1
		end
		if v_u_5:IsKeyDown(v153) or v_u_5:IsKeyDown(v154) then
			v155 = v155 - 1
		end
		local v156 = Enum.KeyCode.D
		local v157 = Enum.KeyCode.Right
		local v158 = Enum.KeyCode.A
		local v159 = Enum.KeyCode.Left
		local v160 = 0
		if v_u_5:IsKeyDown(v156) or v_u_5:IsKeyDown(v157) then
			v160 = v160 + 1
		end
		if v_u_5:IsKeyDown(v158) or v_u_5:IsKeyDown(v159) then
			v160 = v160 - 1
		end
		local v161 = v155 ~= 0 and true or v160 ~= 0
		if v161 or p149.keysHeld then
			p149.seat.ThrottleFloat = v155
			p149.seat.SteerFloat = v160
		end
		p149.keysHeld = v161
	end
end
local function v_u_256(p163) -- name: step
	-- upvalues: (ref) v_u_22, (copy) v_u_6, (copy) v_u_162, (copy) v_u_38, (copy) v_u_7, (copy) v_u_8, (copy) v_u_9, (copy) v_u_10, (copy) v_u_11, (copy) v_u_124, (copy) v_u_136, (copy) v_u_148, (copy) v_u_101, (copy) v_u_26, (copy) v_u_15, (copy) v_u_14, (copy) v_u_16
	local v164 = v_u_22
	if v164 then
		if p163 > 0.1 then
			v164.hitchAt = os.clock()
		end
		if v164.crashed then
			if os.clock() - v164.crashedAt > 2 and v164.seat.Occupant == v164.humanoid then
				v164.crashed = false
				v164.align.Responsiveness = v_u_6.DRIVE_RESPONSIVENESS
				local v165 = v164.model:FindFirstChild("CrashBody")
				if v165 then
					v165.CanCollide = false
				end
			end
		else
			local v166 = v164.chassis
			local v167 = v164.model
			v_u_162(v164)
			local v168 = v164.seat.ThrottleFloat
			local v169 = v164.seat.SteerFloat
			if v_u_38:GetAttribute("Tuning") then
				v168 = 0
				v169 = 0
			end
			local v170 = v167:GetAttribute("Tuck") == true
			local v171, v172, v173 = v_u_7.upgradeScales(v167)
			local v174 = v_u_7.driveTop(v167, v173, not v170 and 1 or v_u_6.TUCK_SPEED_BONUS)
			if v167:GetAttribute("SpeedCapExempt") ~= true then
				local v175
				if v170 then
					v175 = v_u_8.TUCK_TOP_KMH
				else
					v175 = v_u_8.TOP_KMH
				end
				local v176 = v175 / v_u_8.KMH_PER_STUD
				v174 = math.min(v174, v176)
			end
			local v177
			if v164.gears then
				v164.top = v174
				local v178 = v164.speed
				if math.abs(v178) < v_u_9.STOPPED and (v168 <= 0 and v164.gear ~= 1) then
					v164.gear = 1
					v164.model:SetAttribute("Gear", 1)
				end
				v177 = v174 * v_u_9.share(v164.gears, v164.gear)
				v171 = v171 * v_u_9.pull(v164.speed, v174, v164.gears, v164.gear)
			else
				v177 = v174
			end
			local v179 = v167:GetAttribute("EngineOn") == true
			local v180 = v167:GetAttribute("StandDown") ~= false
			local v181 = v167:GetAttribute("DismountStart") ~= nil
			if v181 then
				v168 = math.min(v168, 0)
			end
			if v168 > 0 and not v179 then
				if os.clock() - v164.hintAt > 2.5 then
					v164.hintAt = os.clock()
					v_u_10.hint("The engine\'s off: press R to start it")
				end
			elseif v168 > 0 and (v180 and (not v181 and (v167:GetAttribute("OnDyno") ~= true and os.clock() - v164.hintAt > 2.5))) then
				v164.hintAt = os.clock()
				v_u_10.hint("The stand is down: press K to put it up before riding")
			end
			if not v179 then
				v168 = math.min(v168, 0)
			end
			local v182 = v166.AssemblyLinearVelocity
			if v164.isDriver and not v166.Anchored then
				local v183 = v182.X
				local v184 = v182.Z
				local v185 = Vector3.new(v183, 0, v184)
				local v186 = v174 * 1.1 + 10
				if v186 < v185.Magnitude then
					v185 = v185.Unit * v186
				end
				local v187 = v182.Y
				local v188 = v185.Magnitude * 0.6
				local v189 = math.max(60, v188)
				local v190 = math.min(v187, v189)
				local v191 = v185.Magnitude
				local v192 = v182.X
				local v193 = v182.Z
				if v191 < Vector3.new(v192, 0, v193).Magnitude or v190 < v182.Y then
					local v194 = v185.X
					local v195 = v185.Z
					v166.AssemblyLinearVelocity = Vector3.new(v194, v190, v195)
				end
				v182 = v_u_11.step(v164.bump, p163, nil, nil, v164.linear.VectorVelocity)
			end
			CFrame.Angles(0, v164.heading, 0)
			v164.travel = v164.travel or v164.heading
			local v196 = v182:Dot(CFrame.Angles(0, v164.travel, 0).LookVector)
			if not v166.Anchored then
				local v197 = v164.speed
				local v198 = v196 - 6
				local v199 = math.min(v198, v174)
				local v200 = v196 + 6
				local v201 = -v_u_6.REVERSE_SPEED
				local v202 = math.max(v200, v201)
				v164.speed = math.clamp(v197, v199, v202)
				local v203 = os.clock()
				local v204 = v182.X
				local v205 = v182.Z
				local v206 = Vector3.new(v204, 0, v205)
				local v207 = v164.history
				local v208 = { v203, v182.Magnitude, v182 }
				table.insert(v207, v208)
				while #v207 > 1 and v203 - v207[1][1] > v_u_6.CRASH_WINDOW do
					table.remove(v207, 1)
				end
				local v209 = v207[1]
				for _, v210 in v207 do
					if v210[2] <= v209[2] then
						continue
					end
					v209 = v210
				end
				local v211 = v206:Dot(CFrame.Angles(0, v164.travel, 0).RightVector)
				local v212 = math.abs(v211)
				local v213 = v_u_6.CRASH_SPEED_DROP
				local v214 = v209[2] * 0.3
				local v215 = math.max(v213, v214)
				if v164.isDriver and not v181 and (v209[2] > v_u_6.CRASH_MIN_SPEED and v215 < v209[2] - v182.Magnitude or v_u_6.CRASH_SIDE_SPEED < v212) and (v203 - (v164.hitchAt or (-1 / 0)) > 0.4 and v_u_124(v164, v182 - v209[3])) then
					v_u_136(v164, v209[3])
					return
				end
			end
			local v216 = v164.speed
			if v180 or (v181 or v164.braking) then
				v164.speed = v_u_6.brake(v164.speed, p163, v172)
			else
				v164.speed = v_u_6.stepSpeed(v164.speed, v168, v174, math.min(p163, 0.15), v171, v172)
				if v177 < v164.speed then
					local v217 = v164.speed
					local v218 = math.min(v216, v217)
					v164.speed = math.max(v177, v218)
				end
			end
			if v166.Anchored then
				v164.speed = 0
			end
			v164.accel = v164.accel + ((v164.speed - v216) / math.max(p163, 0.004166666666666667) - v164.accel) * v_u_6.alpha(8, p163)
			local v219 = v_u_6.steerRate(v164.speed)
			local v220 = math.abs(v169)
			local v221 = v164.steerIn or 0
			if v220 < math.abs(v221) then
				v219 = v219 * 1.5
			end
			v164.steerIn = (v164.steerIn or 0) + (v169 - (v164.steerIn or 0)) * v_u_6.alpha(v219, p163)
			local v222 = v_u_6.yawRate(v164.speed, v164.steerIn, v164.steerBase or v164.wheelbase)
			v164.heading = v164.heading - v222 * p163
			local v223 = v164.heading - v164.travel
			local v224 = math.sin(v223)
			local v225 = v164.heading - v164.travel
			local v226 = math.cos(v225)
			local v227 = math.atan2(v224, v226)
			v164.travel = v164.travel + v227 * v_u_6.alpha(10, p163)
			if math.abs(v227) < 0.008726646259971648 then
				v164.travel = v164.heading
			end
			if v181 or v180 then
				v164.footMode = "both"
			elseif v170 then
				v164.footMode = "none"
			else
				v164.footMode = v_u_6.standFootMode(v_u_6.footMode(v164.footMode, v196, v168), v196, v169)
			end
			local v228 = v_u_6.leanFor(v164.speed, v222)
			if v180 or v181 then
				v228 = v180 and v167:GetAttribute("StandType") == "Center" and 0 or -v_u_6.FOOT_LEAN_BOTH
			elseif v164.footMode ~= "none" then
				v228 = v_u_6.footLean(v164.footMode, v169)
			end
			v164.lean = v164.lean + (v228 - v164.lean) * v_u_6.alpha(4, p163)
			local v229 = false
			if v164.frontGround and v164.rearGround then
				local v230 = v_u_148(v164.frontGround.WorldPosition, v164.params)
				local v231 = v_u_148(v164.rearGround.WorldPosition, v164.params)
				if v230 and v231 then
					local v232 = v230 - v231
					local v233 = v164.wheelbase
					local v234 = math.atan2(v232, v233)
					v164.pitch = v164.pitch + (v234 - v164.pitch) * v_u_6.alpha(8, p163)
					if v164.frontGround.WorldPosition.Y - v230 < 1.2 then
						v229 = v164.rearGround.WorldPosition.Y - v231 < 1.2
					else
						v229 = false
					end
				end
			end
			local v235
			if v164.wheelieHeld and v164.speed > v_u_6.WHEELIE_MIN_SPEED then
				local v236 = (v164.speed - v_u_6.WHEELIE_MIN_SPEED) / (v_u_6.WHEELIE_FULL_SPEED - v_u_6.WHEELIE_MIN_SPEED)
				v235 = v_u_6.WHEELIE_MAX * math.clamp(v236, 0, 1)
			else
				v235 = 0
			end
			local v237
			if v164.wheelie < v235 then
				v237 = v_u_6.WHEELIE_RISE_RATE
			else
				v237 = v_u_6.WHEELIE_FALL_RATE
			end
			local v238 = v164.wheelie
			local v239 = v235 - v164.wheelie
			local v240 = -v237 * p163
			local v241 = v237 * p163
			v164.wheelie = v238 + math.clamp(v239, v240, v241)
			if v166.Anchored then
				v164.lastVy = 0
			else
				v_u_101(v164, p163, v164.accel, v182.Y)
				if v229 and (math.abs(v196) > 60 and v164.wheelie < 0.05) then
					local v242 = math.abs(v196)
					local v243 = v164.pitch
					local v244 = v242 * math.sin(v243) + 3
					if v244 < v182.Y then
						local v245 = v182.X
						local v246 = v182.Z
						v166.AssemblyLinearVelocity = Vector3.new(v245, v244, v246)
					end
				end
			end
			local v247 = (v164.compR - v164.compF) / v164.wheelbase
			local v248 = CFrame.Angles(0, v164.heading, 0)
			local v249 = v166.AssemblyMass * v_u_6.DRIVE_FORCE_PER_MASS
			v164.linear.MaxAxesForce = Vector3.new(v249, 0, v249)
			v164.linear.VectorVelocity = CFrame.Angles(0, v164.travel, 0).LookVector * v164.speed
			v164.align.CFrame = v248 * CFrame.Angles(v164.pitch + v164.wheelie + v247, 0, 0) * CFrame.Angles(0, 0, -v164.lean)
			if v164.gears and v164.isDriver then
				if v167:GetAttribute("Gear") ~= v164.gear then
					v167:SetAttribute("Gear", v164.gear)
				end
				if v164.gear ~= v164.sentGear and os.clock() - v164.gearSentAt > v_u_9.SEND_INTERVAL then
					local v250 = v164.gear
					local v251 = os.clock()
					v164.sentGear = v250
					v164.gearSentAt = v251
					v_u_26("Gear", v164.gear)
				end
			end
			local v252 = v_u_15.update
			local v253 = {
				["kmh"] = v_u_6.toKmh(v196),
				["rpm"] = v164.rpmOf(v167)
			}
			local v254
			if v164.gears then
				local v255 = v164.gear
				v254 = tostring(v255)
			else
				v254 = nil
			end
			v253.gear = v254
			v253.rainbow = v167:GetAttribute("RainbowOn") == true
			v253.view = v_u_14.mode()
			v253.tuck = v170
			v253.wheelie = v164.wheelieHeld
			v253.mirrors = v167:GetAttribute("ShowMirrors") == true
			v253.cam360 = v167:GetAttribute("Cam360") ~= nil
			v253.indicator = v167:GetAttribute("Indicator") or "Off"
			v253.tailLight = v167:GetAttribute("TailLightOn") == true
			v253.paintOpen = v_u_16.isOpen()
			v253.engine = v179
			v253.stand = v180 and (v167:GetAttribute("StandType") == "Center" and "Center" or "Side") or "Up"
			v252(v253)
		end
	else
		return
	end
end
local function v_u_260(p257, p258) -- name: onInputBegan
	-- upvalues: (ref) v_u_22, (copy) v_u_26, (copy) v_u_14, (copy) v_u_13, (copy) v_u_17, (copy) v_u_39, (copy) v_u_37, (copy) v_u_12, (copy) v_u_38, (copy) v_u_18, (copy) v_u_19, (copy) v_u_9, (copy) v_u_52, (copy) v_u_20
	if p258 or not v_u_22 then
		return
	else
		local v259 = p257.KeyCode
		if v259 == Enum.KeyCode.L then
			v_u_26("Rainbow")
			return
		elseif v259 == Enum.KeyCode.V then
			v_u_14.toggle()
			return
		elseif v259 == Enum.KeyCode.M then
			v_u_26("Mirrors")
		elseif v259 == Enum.KeyCode.U then
			if v_u_22 and v_u_13.toggle(v_u_22.model) then
				return
			end
			if not v_u_14.view360() then
				v_u_26("Cam360")
				return
			end
		else
			if v_u_17[v259] then
				v_u_26("Indicator", v_u_17[v259])
				return
			end
			if v259 == Enum.KeyCode.T then
				v_u_26("TailLight")
				return
			end
			if v259 == Enum.KeyCode.P then
				v_u_39()
				return
			end
			if v259 == Enum.KeyCode.R then
				if v_u_22 then
					v_u_26("Engine", v_u_22.model:GetAttribute("EngineOn") ~= true)
					return
				end
			else
				if v259 == Enum.KeyCode.K then
					v_u_37()
					return
				end
				if v259 == v_u_12.keyOf(v_u_38) then
					if v_u_22 then
						v_u_26("Tuck", v_u_22.model:GetAttribute("Tuck") ~= true)
						return
					end
				elseif v_u_18[v259] then
					if v_u_22 then
						v_u_22.wheelieHeld = true
						return
					end
				else
					if v_u_19[v259] then
						v_u_22.braking = true
						return
					end
					if v_u_9.UP_KEYS[v259] then
						if not v_u_9.promptOnKey(v259) then
							v_u_52(1)
							return
						end
					else
						if v_u_20[v259] then
							v_u_52(-1)
							return
						end
						if v259 == Enum.KeyCode.H then
							v_u_26("Horn", true)
						end
					end
				end
			end
		end
	end
end
local function v_u_262(p261) -- name: onInputEnded
	-- upvalues: (ref) v_u_22, (copy) v_u_18, (copy) v_u_19, (copy) v_u_26
	if v_u_22 and (v_u_18[p261.KeyCode] and v_u_22) then
		v_u_22.wheelieHeld = false
	end
	if v_u_22 and v_u_19[p261.KeyCode] then
		v_u_22.braking = false
	end
	if v_u_22 and p261.KeyCode == Enum.KeyCode.H then
		v_u_26("Horn", false)
	end
end
function v_u_21.start(p263, p_u_264, p265) -- name: start
	-- upvalues: (ref) v_u_22, (copy) v_u_21, (ref) v_u_23, (copy) v_u_6, (copy) v_u_9, (copy) v_u_11, (copy) v_u_4, (copy) v_u_256, (copy) v_u_5, (copy) v_u_260, (copy) v_u_262, (copy) v_u_143, (copy) v_u_2, (copy) v_u_57, (copy) v_u_55, (copy) v_u_14, (copy) v_u_15, (copy) v_u_27, (copy) v_u_46, (copy) v_u_54, (copy) v_u_28, (copy) v_u_29, (copy) v_u_31, (copy) v_u_33, (copy) v_u_34, (copy) v_u_39, (copy) v_u_35, (copy) v_u_37, (copy) v_u_52
	if v_u_22 and v_u_22.model == p263 then
		return
	else
		v_u_21.stop()
		local v266 = p263:FindFirstChild("Chassis")
		local v_u_267 = p263:FindFirstChild("VehicleSeat")
		if v266 and v_u_267 then
			local v268 = {}
			v_u_23 = v268
			local v269 = v266:WaitForChild("DriveVelocity", 5)
			local v270 = v266:WaitForChild("DriveAlign", 5)
			if v_u_23 == v268 then
				v_u_23 = nil
				if v269 and v270 then
					local v271 = RaycastParams.new()
					v271.FilterType = Enum.RaycastFilterType.Exclude
					v271.FilterDescendantsInstances = { p263, p_u_264.Parent }
					local v272 = v_u_6.flatRotation(v270.CFrame).LookVector
					local v273 = p263:FindFirstChild("FrontCollider")
					local v274 = p263:FindFirstChild("RearCollider")
					local v275 = v266:FindFirstChild("SteerMotor")
					v270.Enabled = true
					v270.Responsiveness = v_u_6.DRIVE_RESPONSIVENESS
					local v276 = {
						["model"] = p263,
						["chassis"] = v266,
						["seat"] = v_u_267,
						["linear"] = v269,
						["align"] = v270,
						["rpmOf"] = p265,
						["params"] = v271
					}
					local v277 = -v272.X
					local v278 = -v272.Z
					v276.heading = math.atan2(v277, v278)
					v276.speed = v266.Anchored and 0 or v266.AssemblyLinearVelocity:Dot(v272)
					v276.lean = 0
					v276.pitch = 0
					v276.wheelie = 0
					v276.wheelieHeld = false
					v276.autoAt = 0
					v276.wheelbase = p263:GetAttribute("Wheelbase") or 5.2
					v276.steerBase = p263:GetAttribute("SteerWheelbase")
					v276.frontGround = v266:FindFirstChild("FrontGround")
					v276.rearGround = v266:FindFirstChild("RearGround")
					v276.footMode = "both"
					v276.isDriver = p_u_264.SeatPart == v_u_267
					v276.humanoid = p_u_264
					v276.character = p_u_264.Parent
					v276.hintAt = 0
					v276.history = {}
					v276.crashed = false
					v276.crashedAt = 0
					v276.hitPeople = setmetatable({}, {
						["__mode"] = "k"
					})
					v276.accel = 0
					v276.lastVy = 0
					local v279
					if v273 then
						v279 = v273:FindFirstChild("RideWeld")
					else
						v279 = v273
					end
					v276.frontWeld = v279
					local v280
					if v274 then
						v280 = v274:FindFirstChild("RideWeld")
					else
						v280 = v274
					end
					v276.rearWeld = v280
					v276.forkAxis = not v275 and Vector3.new(0, 1, 0) or v275.C0.UpVector
					v276.compF = 0
					v276.compR = 0
					v276.velF = 0
					v276.velR = 0
					v276.gears = v_u_9.gears(p263)
					v276.gear = 1
					v276.sentGear = nil
					v276.gearSentAt = 0
					v276.top = 0
					v276.bump = v_u_11.new(v266, p263, { p263, p_u_264.Parent })
					v_u_22 = v276
					if v_u_22.gears and v_u_22.isDriver then
						local v281 = v_u_22
						v281.gear = 1
						v281.model:SetAttribute("Gear", 1)
						v_u_9.watchPrompts()
					end
					v_u_22.connections = { v_u_4.Heartbeat:Connect(v_u_256), v_u_5.InputBegan:Connect(v_u_260), v_u_5.InputEnded:Connect(v_u_262) }
					for _, v282 in { v273, v274 } do
						local v283 = v_u_22.connections
						local v284 = v282.Touched
						local v285 = v_u_143
						table.insert(v283, v284:Connect(v285))
					end
					if v_u_22.isDriver then
						v_u_2:BindActionAtPriority("PCX160Dismount", v_u_57, false, Enum.ContextActionPriority.High.Value, Enum.KeyCode.Space, Enum.KeyCode.ButtonA)
						local v286 = v_u_22.connections
						local v287 = p_u_264:GetPropertyChangedSignal("Jump")
						local function v288()
							-- upvalues: (copy) p_u_264, (copy) v_u_267, (ref) v_u_55
							if p_u_264.Jump and p_u_264.SeatPart == v_u_267 then
								p_u_264.Jump = false
								v_u_55()
							end
						end
						table.insert(v286, v287:Connect(v288))
					end
					v_u_14.start(p263, p_u_264)
					v_u_15.start({
						["onRainbow"] = v_u_27,
						["onView"] = v_u_14.toggle,
						["onTuck"] = v_u_46,
						["onWheelie"] = v_u_54,
						["onMirrors"] = v_u_28,
						["onCam360"] = v_u_29,
						["onHorn"] = v_u_31,
						["onIndicator"] = v_u_33,
						["onTailLight"] = v_u_34,
						["onPaint"] = v_u_39,
						["onEngine"] = v_u_35,
						["onStand"] = v_u_37,
						["onGearUp"] = function() -- name: onGearUp
							-- upvalues: (ref) v_u_52
							v_u_52(1)
						end,
						["onGearDown"] = function() -- name: onGearDown
							-- upvalues: (ref) v_u_52
							v_u_52(-1)
						end
					}, p263, v_u_22.isDriver)
				else
					warn("PCX160: drive constraints not found on", p263:GetFullName())
				end
			else
				return
			end
		else
			return
		end
	end
end
function v_u_21.stop() -- name: stop
	-- upvalues: (ref) v_u_23, (ref) v_u_22, (copy) v_u_2, (copy) v_u_67, (copy) v_u_14, (copy) v_u_15, (copy) v_u_16
	v_u_23 = nil
	if v_u_22 then
		for _, v289 in v_u_22.connections do
			v289:Disconnect()
		end
		v_u_2:UnbindAction("PCX160Dismount")
		v_u_22.model:SetAttribute("DismountStart", nil)
		v_u_67(v_u_22)
		v_u_22 = nil
		v_u_14.stop()
		v_u_15.stop()
		v_u_16.close()
	end
end
function v_u_21.model() -- name: model
	-- upvalues: (ref) v_u_22
	local v290 = v_u_22
	if v290 then
		v290 = v_u_22.model
	end
	return v290
end
return v_u_21