-- Path: ReplicatedStorage/GameUI/Notice
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("TweenService")
local v_u_3 = game:GetService("Debris")
local v_u_4 = require(script.Parent:WaitForChild("Theme"))
local v_u_5 = require(script.Parent:WaitForChild("Icons"))
local v6 = {}
local v_u_7 = Color3.fromRGB(14, 16, 24)
local v_u_8 = {
	["error"] = {
		["color"] = nil,
		["symbol"] = "!",
		["title"] = "Error",
		["sound"] = "rbxasset://sounds/bass.wav",
		["color"] = Color3.fromRGB(239, 68, 68)
	},
	["notify"] = {
		["color"] = nil,
		["icon"] = "bulb",
		["title"] = "Notification",
		["sound"] = "rbxasset://sounds/electronicpingshort.wav",
		["color"] = Color3.fromRGB(234, 179, 8)
	},
	["success"] = {
		["color"] = nil,
		["icon"] = "check",
		["title"] = "Success",
		["sound"] = "rbxasset://sounds/victory.wav",
		["color"] = Color3.fromRGB(34, 197, 94)
	},
	["info"] = {
		["color"] = nil,
		["symbol"] = "i",
		["title"] = "Information",
		["sound"] = "rbxasset://sounds/electronicpingshort.wav",
		["color"] = Color3.fromRGB(59, 130, 246)
	},
	["payment"] = {
		["color"] = nil,
		["symbol"] = "$",
		["title"] = "Payment",
		["sound"] = "rbxasset://sounds/victory.wav",
		["color"] = Color3.fromRGB(20, 184, 166)
	}
}
local v_u_9 = TweenInfo.new(0.32, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
local v_u_10 = TweenInfo.new(0.2, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
local v_u_11 = UDim2.new(0.5, 0, 0, 72)
local v_u_12 = UDim2.new(0.5, 0, 0, 56)
local v_u_13 = nil
local v_u_14 = nil
local v_u_15 = 0
local function v_u_18(p_u_16) -- name: close
	-- upvalues: (ref) v_u_14, (copy) v_u_2, (copy) v_u_10, (copy) v_u_12
	if p_u_16 and p_u_16.Parent then
		if v_u_14 == p_u_16 then
			v_u_14 = nil
		end
		local v17 = v_u_2:Create(p_u_16, v_u_10, {
			["Position"] = nil,
			["GroupTransparency"] = 1,
			["Position"] = v_u_12
		})
		v17.Completed:Connect(function()
			-- upvalues: (copy) p_u_16
			if p_u_16.Parent then
				p_u_16:Destroy()
			end
		end)
		v17:Play()
	end
end
local function v_u_33(p19, p20, p21) -- name: build
	-- upvalues: (copy) v_u_8, (copy) v_u_4, (copy) v_u_7, (copy) v_u_12, (ref) v_u_13, (copy) v_u_1, (copy) v_u_5, (copy) v_u_18
	local v22 = v_u_8[p19]
	local v23 = v_u_4.new
	local v24 = "CanvasGroup"
	local v25 = {
		["Name"] = "Notice",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.04,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["GroupTransparency"] = 1,
		["ZIndex"] = 30,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_7:Lerp(v22.color, 0.1),
		["AnchorPoint"] = Vector2.new(0.5, 0),
		["Position"] = v_u_12,
		["Size"] = UDim2.new(0.92, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}
	if not (v_u_13 and v_u_13.Parent) then
		v_u_13 = v_u_4.screen("GameNotice", 66, v_u_1.LocalPlayer:WaitForChild("PlayerGui"))
	end
	v25.Parent = v_u_13
	local v_u_26 = v23(v24, v25)
	v_u_4.new("UISizeConstraint", {
		["MaxSize"] = Vector2.new(440, (1 / 0)),
		["Parent"] = v_u_26
	})
	v_u_4.corner(v_u_26, 12)
	v_u_4.new("UIStroke", {
		["ApplyStrokeMode"] = nil,
		["Color"] = nil,
		["Thickness"] = 1.5,
		["Transparency"] = 0.2,
		["Parent"] = nil,
		["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
		["Color"] = v22.color,
		["Parent"] = v_u_26
	})
	v_u_4.padding(v_u_26, 14, 12)
	local v27 = v_u_4.new("Frame", {
		["Name"] = "Row",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["Parent"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y,
		["Parent"] = v_u_26
	})
	v_u_4.new("UIListLayout", {
		["FillDirection"] = Enum.FillDirection.Horizontal,
		["VerticalAlignment"] = Enum.VerticalAlignment.Center,
		["Padding"] = UDim.new(0, 14),
		["SortOrder"] = Enum.SortOrder.LayoutOrder,
		["Parent"] = v27
	})
	local v28 = v_u_4.new("Frame", {
		["Name"] = "Badge",
		["BackgroundColor3"] = nil,
		["Size"] = nil,
		["LayoutOrder"] = 1,
		["Parent"] = nil,
		["BackgroundColor3"] = v22.color:Lerp(v_u_7, 0.6),
		["Size"] = UDim2.fromOffset(40, 40),
		["Parent"] = v27
	})
	v_u_4.corner(v28, 6)
	v28.Rotation = 45
	v_u_4.new("UIStroke", {
		["ApplyStrokeMode"] = nil,
		["Color"] = nil,
		["Thickness"] = 1.5,
		["Parent"] = nil,
		["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
		["Color"] = v22.color,
		["Parent"] = v28
	})
	local v29
	if v22.icon then
		v29 = v_u_5.make(v22.icon, v22.color, 20)
	else
		v29 = v_u_4.text({
			["Text"] = nil,
			["TextSize"] = 24,
			["FontFace"] = nil,
			["TextColor3"] = nil,
			["Size"] = nil,
			["Text"] = v22.symbol,
			["FontFace"] = v_u_4.FONT_HEAVY,
			["TextColor3"] = v22.color,
			["Size"] = UDim2.fromScale(1, 1)
		})
	end
	v29.AnchorPoint = Vector2.new(0.5, 0.5)
	v29.Position = UDim2.fromScale(0.5, 0.5)
	v29.Rotation = -45
	v29.Parent = v28
	local v30 = v_u_4.new("Frame", {
		["Name"] = "Text",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = 2,
		["Parent"] = nil,
		["Size"] = UDim2.new(1, -54, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y,
		["Parent"] = v27
	})
	v_u_4.new("UIListLayout", {
		["Padding"] = UDim.new(0, 3),
		["SortOrder"] = Enum.SortOrder.LayoutOrder,
		["Parent"] = v30
	})
	v_u_4.text({
		["Name"] = "Title",
		["Text"] = nil,
		["TextSize"] = 18,
		["FontFace"] = nil,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["TextWrapped"] = true,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = 1,
		["Parent"] = nil,
		["Text"] = p20 or v22.title,
		["FontFace"] = v_u_4.FONT_BOLD,
		["TextColor3"] = v22.color,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y,
		["Parent"] = v30
	})
	v_u_4.text({
		["Name"] = "Body",
		["Text"] = nil,
		["TextSize"] = 16,
		["FontFace"] = nil,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["TextWrapped"] = true,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = 2,
		["Parent"] = nil,
		["Text"] = p21 or "",
		["FontFace"] = v_u_4.FONT,
		["TextColor3"] = Color3.fromRGB(226, 228, 236),
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y,
		["Parent"] = v30
	})
	local v31 = v_u_4.new("TextButton", {
		["Name"] = "Close",
		["Text"] = "",
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 31,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(1, 0),
		["Position"] = UDim2.new(1, 4, 0, -4),
		["Size"] = UDim2.fromOffset(28, 28),
		["Parent"] = v_u_26
	})
	local v32 = v_u_5.make("close", Color3.fromRGB(150, 156, 170), 14)
	v32.AnchorPoint = Vector2.new(0.5, 0.5)
	v32.Position = UDim2.fromScale(0.5, 0.5)
	v32.Parent = v31
	v31.Activated:Connect(function()
		-- upvalues: (ref) v_u_18, (copy) v_u_26
		v_u_18(v_u_26)
	end)
	return v_u_26
end
function v6.show(p34) -- name: show
	-- upvalues: (copy) v_u_8, (ref) v_u_15, (ref) v_u_14, (copy) v_u_33, (copy) v_u_3, (copy) v_u_2, (copy) v_u_9, (copy) v_u_11, (copy) v_u_18
	local v35 = p34 or {}
	local v36 = not v_u_8[v35.kind] and "info" or v35.kind
	v_u_15 = v_u_15 + 1
	local v_u_37 = v_u_15
	if v_u_14 then
		v_u_14:Destroy()
		v_u_14 = nil
	end
	local v_u_38 = v_u_33(v36, v35.title, v35.text)
	v_u_14 = v_u_38
	local v39 = Instance.new("Sound")
	v39.Name = "NoticeSound"
	v39.SoundId = v_u_8[v36].sound
	v39.Volume = 0.7
	v39.Parent = v_u_38
	v39:Play()
	v_u_3:AddItem(v39, 8)
	v_u_2:Create(v_u_38, v_u_9, {
		["Position"] = nil,
		["GroupTransparency"] = 0,
		["Position"] = v_u_11
	}):Play()
	if not v35.hold then
		task.delay(v35.seconds or 6, function()
			-- upvalues: (ref) v_u_15, (copy) v_u_37, (ref) v_u_14, (copy) v_u_38, (ref) v_u_18
			if v_u_15 == v_u_37 and v_u_14 == v_u_38 then
				v_u_18(v_u_38)
			end
		end)
	end
	return v_u_38
end
return v6