-- Path: Players/ygggggg55551/PlayerScripts/LeaderboardClient
-- Class: LocalScript  true/Enum.RunContext.Legacy
-- Decompiled by BALL KUN Universal Map Dump

local v1 = game:GetService("ContextActionService")
local v2 = game:GetService("Players")
local v_u_3 = game:GetService("UserInputService")
local v_u_4 = v2.LocalPlayer:WaitForChild("PlayerGui")
local v_u_5 = {}
local function v_u_10(p6, p7) -- name: pathOf
	local v8 = {}
	while p6 and p6 ~= p7 do
		local v9 = p6.Name
		table.insert(v8, 1, v9)
		p6 = p6.Parent
	end
	return table.concat(v8, "/")
end
local function v_u_21(p11) -- name: boardAt
	-- upvalues: (copy) v_u_5
	local v12 = workspace.CurrentCamera
	local v13 = {}
	for _, v14 in v_u_5 do
		if not v14.gui.Adornee then
			continue
		end
		local v15 = v14.gui.Adornee
		table.insert(v13, v15)
	end
	if #v13 == 0 then
		return nil
	end
	local v16 = RaycastParams.new()
	v16.FilterType = Enum.RaycastFilterType.Include
	v16.FilterDescendantsInstances = v13
	local v17 = v12:ViewportPointToRay(p11.X, p11.Y)
	local v18 = workspace:Raycast(v17.Origin, v17.Direction * 400, v16)
	if not v18 then
		return nil
	end
	for _, v19 in v_u_5 do
		if v19.gui.Adornee ~= v18.Instance then
			continue
		end
		local v20 = v18.Instance
		return v19, 0.5 - v20.CFrame:PointToObjectSpace(v18.Position).Y / v20.Size.Y
	end
	return nil
end
local function v_u_33(p22) -- name: pixelScale
	local v23 = p22.gui.Adornee
	local v24 = workspace.CurrentCamera
	local v25 = v23.CFrame
	local v26 = v23.Size.Y / 2
	local v27 = v24:WorldToViewportPoint(v25:PointToWorldSpace((Vector3.new(0, v26, 0))))
	local v28 = v23.CFrame
	local v29 = -v23.Size.Y / 2
	local v30 = v24:WorldToViewportPoint(v28:PointToWorldSpace((Vector3.new(0, v29, 0)))).Y - v27.Y
	local v31 = math.abs(v30)
	local v32 = math.max(v31, 1)
	return p22.gui.AbsoluteSize.Y / v32
end
v1:BindActionAtPriority("LeaderboardWheel", function(_, p34, p35)
	-- upvalues: (copy) v_u_21, (copy) v_u_3
	if p34 ~= Enum.UserInputState.Change then
		return Enum.ContextActionResult.Pass
	end
	local v36 = v_u_21(v_u_3:GetMouseLocation())
	if not v36 then
		return Enum.ContextActionResult.Pass
	end
	local v37 = -p35.Position.Z * 200
	local v38 = v36.gui:FindFirstChild("List")
	if v38 then
		local v39 = v38.AbsoluteCanvasSize.Y - v38.AbsoluteWindowSize.Y
		local v40 = math.max(0, v39)
		local v41 = Vector2.new
		local v42 = v38.CanvasPosition.Y + v37
		v38.CanvasPosition = v41(0, (math.clamp(v42, 0, v40)))
	end
	return Enum.ContextActionResult.Sink
end, false, Enum.ContextActionPriority.High.Value, Enum.UserInputType.MouseWheel)
local v_u_43 = {}
v_u_3.TouchStarted:Connect(function(p44, p45)
	-- upvalues: (copy) v_u_21, (copy) v_u_43
	if not p45 then
		local v46 = Vector2.new(p44.Position.X, p44.Position.Y)
		local v47, v48 = v_u_21(v46)
		if v47 then
			v_u_43[p44] = {
				["entry"] = v47,
				["from"] = v46,
				["last"] = v46,
				["at"] = os.clock(),
				["where"] = v48
			}
		end
	end
end)
v_u_3.TouchMoved:Connect(function(p49)
	-- upvalues: (copy) v_u_43, (copy) v_u_33
	local v50 = v_u_43[p49]
	if v50 then
		local v51 = Vector2.new(p49.Position.X, p49.Position.Y)
		local v52 = v50.entry
		local v53 = -(v51.Y - v50.last.Y) * v_u_33(v50.entry)
		local v54 = v52.gui:FindFirstChild("List")
		if v54 then
			local v55 = v54.AbsoluteCanvasSize.Y - v54.AbsoluteWindowSize.Y
			local v56 = math.max(0, v55)
			local v57 = Vector2.new
			local v58 = v54.CanvasPosition.Y + v53
			v54.CanvasPosition = v57(0, (math.clamp(v58, 0, v56)))
		end
		v50.last = v51
	end
end)
v_u_3.TouchEnded:Connect(function(p59)
	-- upvalues: (copy) v_u_43
	local v60 = v_u_43[p59]
	v_u_43[p59] = nil
	if v60 and ((v60.last - v60.from).Magnitude < 12 and os.clock() - v60.at < 0.35) then
		local v61 = v60.entry
		local v62 = v60.where > 0.5 and 500 or -500
		local v63 = v61.gui:FindFirstChild("List")
		if not v63 then
			return
		end
		local v64 = v63.AbsoluteCanvasSize.Y - v63.AbsoluteWindowSize.Y
		local v65 = math.max(0, v64)
		local v66 = Vector2.new
		local v67 = v63.CanvasPosition.Y + v62
		v63.CanvasPosition = v66(0, (math.clamp(v67, 0, v65)))
	end
end)
local function v80(p68, p69, p70) -- name: copy
	-- upvalues: (copy) v_u_10, (copy) v_u_4, (copy) v_u_5
	local v71 = p68:Clone()
	v71.Name = "Leaderboard_" .. p70
	v71.Adornee = p69
	v71.ResetOnSpawn = false
	v71.Enabled = true
	local v72 = {}
	for _, v73 in v71:GetDescendants() do
		v72[v_u_10(v73, v71)] = v73
	end
	local v74 = {
		["gui"] = v71,
		["connections"] = {}
	}
	for _, v_u_75 in p68:GetDescendants() do
		local v_u_76 = v_u_75:IsA("TextLabel") and "Text" or (v_u_75:IsA("ImageLabel") and "Image" or nil)
		local v_u_77
		if v_u_76 then
			v_u_77 = v72[v_u_10(v_u_75, p68)]
		else
			v_u_77 = v_u_76
		end
		if not v_u_77 then
			continue
		end
		local v78 = v74.connections
		local v79 = v_u_75:GetPropertyChangedSignal(v_u_76)
		table.insert(v78, v79:Connect(function()
			-- upvalues: (copy) v_u_77, (copy) v_u_76, (copy) v_u_75
			v_u_77[v_u_76] = v_u_75[v_u_76]
		end))
	end
	v71.Parent = v_u_4
	p68.Enabled = false
	v_u_5[p68] = v74
end
while true do
	local v81 = workspace:FindFirstChild("Map") and workspace.Map:FindFirstChild("Landmarks")
	if v81 then
		v81 = workspace.Map.Landmarks:FindFirstChild("Garage")
	end
	if v81 then
		v81 = v81:FindFirstChild("Leaderboards")
	end
	local v82 = {}
	for _, v83 in not v81 and {} or v81:GetChildren() do
		local v84 = v83:FindFirstChild("Backdrop")
		local v85
		if v84 then
			v85 = v84:FindFirstChild("BoardGui")
		else
			v85 = v84
		end
		if not (v85 and v85:FindFirstChild("List")) then
			continue
		end
		v82[v85] = true
		if v_u_5[v85] then
			continue
		end
		v80(v85, v84, v83.Name)
	end
	for v86 in v_u_5 do
		if v82[v86] and v86.Parent then
			continue
		end
		local v87 = v_u_5[v86]
		if not v87 then
			continue
		end
		for _, v88 in v87.connections do
			v88:Disconnect()
		end
		v87.gui:Destroy()
		v_u_5[v86] = nil
	end
	task.wait(1)
end