-- Path: ReplicatedStorage/DynoScreenKit
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = require(game:GetService("ReplicatedStorage"):WaitForChild("UiOwn")).Instance
local v_u_2 = {
	["W"] = 1280,
	["H"] = 720
}
local v_u_3 = {
	["bg"] = Color3.fromRGB(10, 12, 14),
	["bg2"] = Color3.fromRGB(6, 6, 8),
	["white"] = Color3.fromRGB(228, 230, 235),
	["dim"] = Color3.fromRGB(150, 154, 162),
	["green"] = Color3.fromRGB(80, 210, 95),
	["red"] = Color3.fromRGB(235, 55, 45),
	["yellow"] = Color3.fromRGB(240, 210, 60),
	["orange"] = Color3.fromRGB(245, 160, 35),
	["teal"] = Color3.fromRGB(38, 132, 152),
	["cyan"] = Color3.fromRGB(110, 245, 235),
	["pink"] = Color3.fromRGB(255, 170, 215),
	["olive"] = Color3.fromRGB(140, 124, 52),
	["oliveEdge"] = Color3.fromRGB(196, 176, 86),
	["btnRed"] = Color3.fromRGB(218, 36, 36),
	["btnRedOn"] = Color3.fromRGB(255, 92, 70),
	["panel"] = Color3.fromRGB(236, 236, 240),
	["ink"] = Color3.fromRGB(40, 42, 48)
}
v_u_2.C = v_u_3
v_u_2.RUN_COLORS = {
	Color3.fromRGB(40, 170, 80),
	Color3.fromRGB(40, 110, 210),
	Color3.fromRGB(150, 60, 190),
	Color3.fromRGB(230, 120, 30),
	Color3.fromRGB(20, 160, 170)
}
local function v_u_14(p4, p5, p6, p7, p8, p9, p10, p11, p12) -- name: frame
	-- upvalues: (copy) v_u_1, (copy) v_u_3
	local v13 = v_u_1.new("Frame")
	v13.Name = p5
	v13.Position = UDim2.fromOffset(p6, p7)
	v13.Size = UDim2.fromOffset(p8, p9)
	v13.BackgroundColor3 = p10 or v_u_3.bg
	v13.BackgroundTransparency = p11 or 0
	v13.BorderSizePixel = 0
	v13.ZIndex = p12 or 1
	v13.Parent = p4
	return v13
end
local function v_u_28(p15, p16, p17, p18, p19, p20, p21, p22, p23, p24, p25, p26) -- name: label
	-- upvalues: (copy) v_u_1, (copy) v_u_3
	local v27 = v_u_1.new("TextLabel")
	v27.Name = p16
	v27.Text = p17
	v27.Position = UDim2.fromOffset(p18, p19)
	v27.Size = UDim2.fromOffset(p20, p21)
	v27.BackgroundTransparency = 1
	v27.TextColor3 = p22 or v_u_3.white
	v27.TextSize = p23 or 18
	v27.Font = p24 or Enum.Font.Roboto
	v27.TextXAlignment = p25 or Enum.TextXAlignment.Left
	v27.TextYAlignment = Enum.TextYAlignment.Center
	v27.ZIndex = p26 or 2
	v27.Parent = p15
	return v27
end
local function v_u_41(p29, p30, p31, p32, p33, p34, p35, p36, p37, p38, p39) -- name: button
	-- upvalues: (copy) v_u_1
	local v40 = v_u_1.new("TextButton")
	v40.Name = p30
	v40.Text = p31
	v40.Position = UDim2.fromOffset(p32, p33)
	v40.Size = UDim2.fromOffset(p34, p35)
	v40.BackgroundColor3 = p36
	v40.BorderSizePixel = 0
	v40.AutoButtonColor = true
	v40.TextColor3 = p37 or Color3.new(1, 1, 1)
	v40.TextSize = p38 or 18
	v40.Font = Enum.Font.RobotoCondensed
	v40.TextWrapped = true
	v40.ZIndex = p39 or 3
	v40.Parent = p29
	return v40
end
v_u_2.frame = v_u_14
v_u_2.label = v_u_28
v_u_2.button = v_u_41
function v_u_2.corner(p42, p43) -- name: corner
	-- upvalues: (copy) v_u_1
	local v44 = v_u_1.new("UICorner")
	v44.CornerRadius = UDim.new(0, p43)
	v44.Parent = p42
end
function v_u_2.stroke(p45, p46, p47) -- name: stroke
	-- upvalues: (copy) v_u_1
	local v48 = v_u_1.new("UIStroke")
	v48.Color = p46
	v48.Thickness = p47 or 1.5
	v48.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v48.Parent = p45
	return v48
end
local v_u_49 = {
	["0"] = "abcdef",
	["1"] = "bc",
	["2"] = "abdeg",
	["3"] = "abcdg",
	["4"] = "bcfg",
	["5"] = "acdfg",
	["6"] = "acdefg",
	["7"] = "abc",
	["8"] = "abcdefg",
	["9"] = "abcdfg",
	["-"] = "g",
	[" "] = ""
}
function v_u_2.sevenSeg(p50, p51, p52, p53, p54, p55, p56, p57, p58, p59, p60) -- name: sevenSeg
	-- upvalues: (copy) v_u_14, (copy) v_u_3, (copy) v_u_1
	local v61 = v_u_14(p50, p51, p53, p54, 10, p56, v_u_3.bg, 1, p60)
	v61:SetAttribute("Pattern", p52)
	v61:SetAttribute("On", p58)
	v61:SetAttribute("Ghost", p59)
	local v62 = p55 * 0.17 + 0.5
	local v63 = math.floor(v62)
	local v64 = math.max(2, v63)
	local v65 = 0
	for v66 = 1, #p52 do
		if p52:sub(v66, v66) == "." then
			local v67 = v_u_14(v61, "P" .. v66, v65, p56 - v64, v64, v64, p59, 0, (p60 or 1) + 1)
			local v68 = v_u_1.new("UICorner")
			v68.CornerRadius = UDim.new(0, 1)
			v68.Parent = v67
			v65 = v65 + (v64 + p57)
		else
			local v69 = v_u_14(v61, "D" .. v66, v65, 0, p55, p56, v_u_3.bg, 1, p60)
			local v70 = p56 / 2 - v64 * 0.9
			for v71, v72 in {
				["a"] = {
					v64 * 0.65,
					0,
					p55 - v64 * 1.3,
					v64
				},
				["d"] = {
					v64 * 0.65,
					p56 - v64,
					p55 - v64 * 1.3,
					v64
				},
				["g"] = {
					v64 * 0.65,
					p56 / 2 - v64 / 2,
					p55 - v64 * 1.3,
					v64
				},
				["f"] = {
					0,
					v64 * 0.7,
					v64,
					v70
				},
				["b"] = {
					p55 - v64,
					v64 * 0.7,
					v64,
					v70
				},
				["e"] = {
					0,
					p56 / 2 + v64 * 0.2,
					v64,
					v70
				},
				["c"] = {
					p55 - v64,
					p56 / 2 + v64 * 0.2,
					v64,
					v70
				}
			} do
				local v73 = v_u_14(v69, v71, v72[1], v72[2], v72[3], v72[4], p59, 0, (p60 or 1) + 1)
				local v74 = v64 / 2
				local v75 = math.floor(v74)
				local v76 = math.max(1, v75)
				local v77 = v_u_1.new("UICorner")
				v77.CornerRadius = UDim.new(0, v76)
				v77.Parent = v73
			end
			v65 = v65 + (p55 + p57)
		end
	end
	v61.Size = UDim2.fromOffset(v65 - p57, p56)
	return v61
end
function v_u_2.setSeg(p78, p79) -- name: setSeg
	-- upvalues: (copy) v_u_49
	local v80 = p78:GetAttribute("Pattern")
	local v81 = p78:GetAttribute("On")
	local v82 = p78:GetAttribute("Ghost")
	local v83, v84 = v80:match("^([^%.]*)%.?(.*)$")
	local v85, v86 = tostring(p79):match("^([^%.]*)%.?(.*)$")
	local v87 = v85 or ""
	local v88 = v86 or ""
	if #v87 > #v83 then
		v87 = v87:sub(-#v83)
	end
	local v89 = string.rep(" ", #v83 - #v87) .. v87 .. (v88 .. string.rep("0", #v84)):sub(1, #v84)
	local v90 = 0
	for v91 = 1, #v80 do
		if v80:sub(v91, v91) == "." then
			local v92 = p78:FindFirstChild("P" .. v91)
			if not v92 then
				continue
			end
			v92.BackgroundColor3 = v81
		else
			v90 = v90 + 1
			local v93 = v_u_49[v89:sub(v90, v90)] or ""
			local v94 = p78:FindFirstChild("D" .. v91)
			if not v94 then
				continue
			end
			for _, v95 in v94:GetChildren() do
				local v96
				if v93:find(v95.Name, 1, true) then
					v96 = v81
				else
					v96 = v82
				end
				v95.BackgroundColor3 = v96
			end
		end
	end
end
function v_u_2.pool(p97, p98, p99, p100, p101, p102) -- name: pool
	-- upvalues: (copy) v_u_14, (copy) v_u_3
	local v103 = p97:FindFirstChild(p98) or v_u_14(p97, p98, 0, 0, 0, 0, v_u_3.bg, 1, p102)
	v103.Size = UDim2.fromScale(1, 1)
	local v104 = {}
	for v105 = 1, p99 do
		local v106 = v103:FindFirstChild("S" .. v105)
		if not v106 then
			v106 = v_u_14(v103, "S" .. v105, 0, 0, 0, p101, p100, 0, p102)
			v106.AnchorPoint = Vector2.new(0.5, 0.5)
			v106.Visible = false
		end
		v104[v105] = v106
	end
	return {
		["holder"] = v103,
		["segs"] = v104,
		["thickness"] = p101
	}
end
function v_u_2.plot(p107, p108, p109, p110) -- name: plot
	local v111 = p107.segs
	local v112 = p107.thickness
	for v113 = 1, #v111 do
		local v114 = v111[v113]
		local v115 = p108[v113]
		local v116 = p108[v113 + 1]
		if v115 and v116 then
			local v117 = v115[1] * p109
			local v118 = (1 - v115[2]) * p110
			local v119 = v116[1] * p109
			local v120 = (1 - v116[2]) * p110
			local v121 = v119 - v117
			local v122 = v120 - v118
			v114.Position = UDim2.fromOffset((v117 + v119) / 2, (v118 + v120) / 2)
			local v123 = UDim2.fromOffset
			local v124 = v121 * v121 + v122 * v122
			v114.Size = v123(math.sqrt(v124) + v112 * 0.6, v112)
			local v125 = math.atan2(v122, v121)
			v114.Rotation = math.deg(v125)
			v114.Visible = true
		else
			if not v114.Visible then
				continue
			end
			v114.Visible = false
		end
	end
end
function v_u_2.setColor(p126, p127) -- name: setColor
	for _, v128 in p126.segs do
		v128.BackgroundColor3 = p127
	end
end
local function v_u_140(p129, p130, p131, p132, p133, p134, p135) -- name: hexagon
	-- upvalues: (copy) v_u_14
	local v136 = v_u_14(p129, p130, p131, p132, 0, 0, p134, 1, p135)
	for v137, v138 in { 0, 60, 120 } do
		local v139 = v_u_14(v136, "R" .. v137, 0, 0, p133, p133 * 1.7320508075688772, p134, 0, p135)
		v139.AnchorPoint = Vector2.new(0.5, 0.5)
		v139.Rotation = v138
	end
	return v136
end
local function v_u_155(p141, p142, p143, p144, p145, p146, p147, p148) -- name: chevron
	-- upvalues: (copy) v_u_14
	local v149 = v_u_14(p141, p142, p143, p144, 0, 0, p147, 1, p148)
	local v150 = p145 * 0.62
	local v151 = p145 * 0.2
	for v152, v153 in { -1, 1 } do
		local v154 = v_u_14(v149, "B" .. v152, v153 * p145 * 0.22, 0, v150, v151, p147, 0, p148)
		v154.AnchorPoint = Vector2.new(0.5, 0.5)
		v154.Rotation = (p146 and 1 or -1) * v153 * 40
	end
	return v149
end
function v_u_2.buildLeft(p156) -- name: buildLeft
	-- upvalues: (copy) v_u_2, (copy) v_u_3, (copy) v_u_1, (copy) v_u_28, (copy) v_u_140, (copy) v_u_41, (copy) v_u_155
	p156:ClearAllChildren()
	local v157 = v_u_2.W
	local v158 = v_u_2.H
	local v159 = v_u_3.bg
	local v160 = v_u_1.new("Frame")
	v160.Name = "Root"
	v160.Position = UDim2.fromOffset(0, 0)
	v160.Size = UDim2.fromOffset(v157, v158)
	v160.BackgroundColor3 = v159 or v_u_3.bg
	v160.BackgroundTransparency = 0
	v160.BorderSizePixel = 0
	v160.ZIndex = 1
	v160.Parent = p156
	v_u_28(v160, "SensorLabel", "Sensor RPM", 24, 16, 220, 32, v_u_3.white, 26)
	v_u_2.sevenSeg(v160, "SensorRpm", "8888", 34, 58, 34, 64, 9, v_u_3.white, Color3.fromRGB(30, 34, 38))
	v_u_28(v160, "HpLabel", "HORSE POWER", 220, 14, 360, 56, v_u_3.white, 46, Enum.Font.RobotoCondensed, Enum.TextXAlignment.Center)
	v_u_2.sevenSeg(v160, "Hp", "888.8", 238, 82, 64, 124, 13, v_u_3.green, Color3.fromRGB(20, 40, 24))
	v_u_28(v160, "RpmLabel", "RPM", 580, 20, 115, 32, v_u_3.white, 26, nil, Enum.TextXAlignment.Center)
	v_u_2.sevenSeg(v160, "Rpm", "8888", 585, 60, 22, 52, 6, v_u_3.white, Color3.fromRGB(30, 34, 38))
	v_u_28(v160, "TqLabel", "TORQUE(Nm)", 28, 182, 220, 28, v_u_3.red, 22)
	v_u_2.sevenSeg(v160, "Tq", "88.8", 44, 220, 32, 56, 7, v_u_3.red, Color3.fromRGB(46, 14, 12))
	v_u_28(v160, "SpeedLabel", "SPEED(Km/hr)", 540, 182, 170, 28, v_u_3.yellow, 22)
	v_u_2.sevenSeg(v160, "Speed", "888.8", 556, 220, 24, 56, 5, v_u_3.yellow, Color3.fromRGB(44, 40, 12))
	local v161 = v_u_3.teal
	local v162 = v_u_1.new("Frame")
	v162.Name = "Ecu"
	v162.Position = UDim2.fromOffset(24, 292)
	v162.Size = UDim2.fromOffset(662, 100)
	v162.BackgroundColor3 = v161 or v_u_3.bg
	v162.BackgroundTransparency = 0
	v162.BorderSizePixel = 0
	v162.ZIndex = 1
	v162.Parent = v160
	local v163 = v_u_1.new("UICorner")
	v163.CornerRadius = UDim.new(0, 14)
	v163.Parent = v162
	for v164, v165 in {
		{
			"Ect",
			"ECT",
			"degree",
			v_u_3.cyan
		},
		{
			"Inj",
			"INJ-TIME",
			"ms",
			v_u_3.white
		},
		{
			"Ign",
			"IGN-TIME",
			"degree",
			v_u_3.white
		},
		{
			"Stft",
			"STFT",
			"%",
			v_u_3.pink
		}
	} do
		local v166 = (v164 - 1) * 165
		v_u_28(v162, v165[1] .. "Label", v165[2], v166, 8, 165, 24, v_u_3.white, 20, nil, Enum.TextXAlignment.Center)
		v_u_28(v162, v165[1], "0.00", v166, 32, 165, 36, v165[4], 32, Enum.Font.RobotoCondensed, Enum.TextXAlignment.Center)
		v_u_28(v162, v165[1] .. "Unit", v165[3], v166, 70, 165, 20, v_u_3.white, 14, nil, Enum.TextXAlignment.Center)
	end
	for v167 = 1, 4 do
		local v168 = (v167 - 1) * 166 + 104
		v_u_140(v160, "HexEdge" .. v167, v168, 462, 80, v_u_3.oliveEdge, 2)
		v_u_140(v160, "Hex" .. v167, v168, 462, 74, v_u_3.olive, 3)
		v_u_28(v160, "HexPlus" .. v167, "+", v168 - 40, 422, 80, 80, Color3.fromRGB(240, 240, 240), 64, Enum.Font.Roboto, Enum.TextXAlignment.Center, 4)
		v_u_41(v160, "HexKey" .. v167, "", v168 - 70, 404, 140, 116, v_u_3.bg, nil, 10, 5).BackgroundTransparency = 1
	end
	v_u_28(v160, "ModeLabel", "Mode", 24, 530, 70, 38, v_u_3.white, 24)
	for v169, v170 in {
		{ "ModeDyno", "DYNO" },
		{ "ModeRoad", "ROAD SIM" },
		{ "ModeHold", "HOLD" },
		{ "ModeSet", "SET" }
	} do
		v_u_41(v160, v170[1], v170[2], 96 + (v169 - 1) * 150, 530, 142, 40, v_u_3.btnRed, Color3.new(1, 1, 1), 24)
	end
	for v171, v172 in {
		{
			"StartRpm",
			"START RPM",
			"2000",
			"Rpm"
		},
		{
			"StopRpm",
			"STOP RPM",
			"9000",
			"Rpm"
		},
		{
			"Ramp",
			"RAMP Rate",
			"0",
			"Rpm/sec"
		},
		{
			"HoldTime",
			"HOLD Time",
			"0",
			"Sec"
		}
	} do
		local v173 = 580 + (v171 - 1) * 25
		v_u_28(v160, v172[1] .. "Label", v172[2], 24, v173, 200, 24, v_u_3.white, 19)
		v_u_28(v160, v172[1], v172[3], 236, v173, 120, 24, v_u_3.yellow, 20, nil, Enum.TextXAlignment.Center)
		v_u_28(v160, v172[1] .. "Unit", v172[4], 392, v173, 120, 24, v_u_3.white, 19)
	end
	v_u_41(v160, "AutoStart", "AUTO START", 236, 683, 210, 28, Color3.fromRGB(205, 205, 208), Color3.fromRGB(70, 72, 78), 18)
	v_u_155(v160, "Up1", 600, 592, 60, true, v_u_3.white, 3)
	v_u_155(v160, "Up2", 600, 614, 60, true, v_u_3.white, 3)
	v_u_155(v160, "Down1", 600, 650, 60, false, v_u_3.white, 3)
	v_u_155(v160, "Down2", 600, 672, 60, false, v_u_3.white, 3)
	v_u_41(v160, "StopUp", "", 560, 576, 80, 50, v_u_3.bg, nil, 10, 5).BackgroundTransparency = 1
	v_u_41(v160, "StopDown", "", 560, 636, 80, 50, v_u_3.bg, nil, 10, 5).BackgroundTransparency = 1
	local v174 = v_u_3.white
	local v175 = v_u_1.new("Frame")
	v175.Name = "Gear"
	v175.Position = UDim2.fromOffset(676, 694)
	v175.Size = UDim2.fromOffset(0, 0)
	v175.BackgroundColor3 = v174 or v_u_3.bg
	v175.BackgroundTransparency = 1
	v175.BorderSizePixel = 0
	v175.ZIndex = 3
	v175.Parent = v160
	for v176 = 0, 7 do
		local v177 = "T" .. v176
		local v178 = v_u_3.white
		local v179 = v_u_1.new("Frame")
		v179.Name = v177
		v179.Position = UDim2.fromOffset(0, 0)
		v179.Size = UDim2.fromOffset(9, 38)
		v179.BackgroundColor3 = v178 or v_u_3.bg
		v179.BackgroundTransparency = 0
		v179.BorderSizePixel = 0
		v179.ZIndex = 3
		v179.Parent = v175
		v179.AnchorPoint = Vector2.new(0.5, 0.5)
		v179.Rotation = v176 * 22.5
	end
	local v180 = v_u_3.white
	local v181 = v_u_1.new("Frame")
	v181.Name = "Ring"
	v181.Position = UDim2.fromOffset(0, 0)
	v181.Size = UDim2.fromOffset(32, 32)
	v181.BackgroundColor3 = v180 or v_u_3.bg
	v181.BackgroundTransparency = 0
	v181.BorderSizePixel = 0
	v181.ZIndex = 4
	v181.Parent = v175
	v181.AnchorPoint = Vector2.new(0.5, 0.5)
	local v182 = v_u_1.new("UICorner")
	v182.CornerRadius = UDim.new(0, 16)
	v182.Parent = v181
	local v183 = v_u_3.bg
	local v184 = v_u_1.new("Frame")
	v184.Name = "Hole"
	v184.Position = UDim2.fromOffset(0, 0)
	v184.Size = UDim2.fromOffset(15, 15)
	v184.BackgroundColor3 = v183 or v_u_3.bg
	v184.BackgroundTransparency = 0
	v184.BorderSizePixel = 0
	v184.ZIndex = 5
	v184.Parent = v175
	v184.AnchorPoint = Vector2.new(0.5, 0.5)
	local v185 = v_u_1.new("UICorner")
	v185.CornerRadius = UDim.new(0, 7)
	v185.Parent = v184
	v_u_28(v160, "Brand", "MNK DYNO", 470, 678, 160, 26, v_u_3.orange, 24, Enum.Font.SciFi, Enum.TextXAlignment.Center)
	v_u_28(v160, "BrandSub", "DYNAMOMETER", 470, 701, 160, 14, v_u_3.orange, 11, Enum.Font.RobotoCondensed, Enum.TextXAlignment.Center)
	v_u_28(v160, "Connected", "Connected", 8, 702, 120, 16, v_u_3.white, 12)
	v_u_28(v160, "Msg", "", 24, 394, 662, 0, v_u_3.dim, 1)
	for v186, v187 in {
		{ "Hp", "HP", v_u_3.green },
		{ "Tq", "Torque", v_u_3.red },
		{ "Speed", "Speed", v_u_3.yellow }
	} do
		local v188 = (v186 - 1) * 230
		local v189 = v187[1] .. "Tab"
		local v190 = v188 + 2
		local v191 = v_u_3.orange
		local v192 = v_u_1.new("Frame")
		v192.Name = v189
		v192.Position = UDim2.fromOffset(716, v190)
		v192.Size = UDim2.fromOffset(470, 24)
		v192.BackgroundColor3 = v191 or v_u_3.bg
		v192.BackgroundTransparency = 0
		v192.BorderSizePixel = 0
		v192.ZIndex = 2
		v192.Parent = v160
		v_u_28(v192, "Title", v187[2], 12, 0, 200, 24, Color3.new(1, 1, 1), 18, Enum.Font.Roboto, nil, 3)
		local v193 = v187[1] .. "TabCut"
		local v194 = v188 - 8
		local v195 = v_u_3.bg
		local v196 = v_u_1.new("Frame")
		v196.Name = v193
		v196.Position = UDim2.fromOffset(1176, v194)
		v196.Size = UDim2.fromOffset(40, 40)
		v196.BackgroundColor3 = v195 or v_u_3.bg
		v196.BackgroundTransparency = 0
		v196.BorderSizePixel = 0
		v196.ZIndex = 3
		v196.Parent = v160
		v196.Rotation = 35
		v_u_28(v160, v187[1] .. "ChartValue", "0.00", 1190, v188 + 2, 80, 24, v_u_3.white, 18, nil, Enum.TextXAlignment.Right)
		local v197 = v187[1] .. "Chart"
		local v198 = v188 + 30
		local v199 = Color3.fromRGB(8, 10, 12)
		local v200 = v_u_1.new("Frame")
		v200.Name = v197
		v200.Position = UDim2.fromOffset(728, v198)
		v200.Size = UDim2.fromOffset(542, 194)
		v200.BackgroundColor3 = v199 or v_u_3.bg
		v200.BackgroundTransparency = 0
		v200.BorderSizePixel = 0
		v200.ZIndex = 2
		v200.Parent = v160
		v200.ClipsDescendants = true
		local v201 = Color3.fromRGB(205, 208, 214)
		local v202 = v_u_1.new("UIStroke")
		v202.Color = v201
		v202.Thickness = 1.5
		v202.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
		v202.Parent = v200
		v200:SetAttribute("LineColor", v187[3])
	end
	v_u_28(v160, "StatusMode", "Mode:  STANDBY", 736, 692, 170, 22, v_u_3.white, 16)
	v_u_28(v160, "StatusBaro", "1008 mbar", 900, 692, 110, 22, v_u_3.orange, 16)
	v_u_28(v160, "StatusHumid", "66.36%", 1000, 692, 80, 22, v_u_3.cyan, 16)
	v_u_28(v160, "StatusTemp", "33.20\194\176C", 1078, 692, 90, 22, v_u_3.orange, 16)
	v_u_28(v160, "StatusBrake", "Brake 0.00%", 1166, 686, 110, 18, v_u_3.white, 15, nil, Enum.TextXAlignment.Right)
	v_u_28(v160, "StatusLoad", "Abs Load-cell -0.01", 1110, 702, 166, 16, v_u_3.white, 13, nil, Enum.TextXAlignment.Right)
	return v160
end
function v_u_2.buildRight(p203) -- name: buildRight
	-- upvalues: (copy) v_u_2, (copy) v_u_3, (copy) v_u_1, (copy) v_u_28, (copy) v_u_41
	p203:ClearAllChildren()
	local v204 = v_u_2.W
	local v205 = v_u_2.H
	local v206 = v_u_3.bg2
	local v_u_207 = v_u_1.new("Frame")
	v_u_207.Name = "Root"
	v_u_207.Position = UDim2.fromOffset(0, 0)
	v_u_207.Size = UDim2.fromOffset(v204, v205)
	v_u_207.BackgroundColor3 = v206 or v_u_3.bg
	v_u_207.BackgroundTransparency = 0
	v_u_207.BorderSizePixel = 0
	v_u_207.ZIndex = 1
	v_u_207.Parent = p203
	local v208 = Color3.fromRGB(34, 34, 38)
	local v209 = v_u_1.new("Frame")
	v209.Name = "TabBar"
	v209.Position = UDim2.fromOffset(18, 20)
	v209.Size = UDim2.fromOffset(44, 320)
	v209.BackgroundColor3 = v208 or v_u_3.bg
	v209.BackgroundTransparency = 0
	v209.BorderSizePixel = 0
	v209.ZIndex = 1
	v209.Parent = v_u_207
	local v210 = Color3.fromRGB(78, 78, 84)
	local v211 = v_u_1.new("Frame")
	v211.Name = "TabRealtime"
	v211.Position = UDim2.fromOffset(18, 20)
	v211.Size = UDim2.fromOffset(44, 150)
	v211.BackgroundColor3 = v210 or v_u_3.bg
	v211.BackgroundTransparency = 0
	v211.BorderSizePixel = 0
	v211.ZIndex = 2
	v211.Parent = v_u_207
	v_u_28(v211, "Text", "Realtime", -53, 60, 150, 30, v_u_3.orange, 18, Enum.Font.RobotoCondensed, Enum.TextXAlignment.Center, 3).Rotation = -90
	v_u_28(v_u_207, "TabAnalysis", "Analysis", -35, 245, 150, 30, v_u_3.white, 18, Enum.Font.RobotoCondensed, Enum.TextXAlignment.Center, 3).Rotation = -90
	v_u_28(v_u_207, "PlotTitle", "REALTIME PLOT", 460, 40, 300, 20, v_u_3.white, 15, Enum.Font.RobotoCondensed, Enum.TextXAlignment.Center)
	for v212, v213 in {
		{ "Engine RPM", v_u_3.green },
		{ "Throttle", Color3.fromRGB(60, 200, 235) },
		{ "AFR", v_u_3.red }
	} do
		local v214 = 430 + (v212 - 1) * 120
		local v215 = "LegendDot" .. v212
		local v216 = v213[2]
		local v217 = v_u_1.new("Frame")
		v217.Name = v215
		v217.Position = UDim2.fromOffset(v214, 66)
		v217.Size = UDim2.fromOffset(10, 10)
		v217.BackgroundColor3 = v216 or v_u_3.bg
		v217.BackgroundTransparency = 0
		v217.BorderSizePixel = 0
		v217.ZIndex = 2
		v217.Parent = v_u_207
		local v218 = v_u_1.new("UICorner")
		v218.CornerRadius = UDim.new(0, 5)
		v218.Parent = v217
		v_u_28(v_u_207, "Legend" .. v212, v213[1], v214 + 14, 61, 100, 20, v_u_3.dim, 13)
	end
	for v219, v220 in {
		{
			"AxisRpm",
			"Engine RPM (x1000)",
			{
				"10",
				"7.5",
				"5.0",
				"2.5",
				"0"
			}
		},
		{
			"AxisThr",
			"Throttle (%)",
			{
				"100",
				"75",
				"50",
				"25",
				"0"
			}
		},
		{
			"AxisAfr",
			"AFR (:1)",
			{
				"18",
				"16",
				"14",
				"12",
				"10"
			}
		}
	} do
		local v221 = 92 + (v219 - 1) * 50
		local v222 = v220[1] .. "Line"
		local v223 = v221 + 40
		local v224 = v_u_3.white
		local v225 = v_u_1.new("Frame")
		v225.Name = v222
		v225.Position = UDim2.fromOffset(v223, 80)
		v225.Size = UDim2.fromOffset(2, 250)
		v225.BackgroundColor3 = v224 or v_u_3.bg
		v225.BackgroundTransparency = 0
		v225.BorderSizePixel = 0
		v225.ZIndex = 2
		v225.Parent = v_u_207
		for v226, v227 in v220[3] do
			v_u_28(v_u_207, v220[1] .. "T" .. v226, v227, v221, 72 + (v226 - 1) * 62, 36, 16, v_u_3.white, 12, nil, Enum.TextXAlignment.Right)
		end
		local v228 = v_u_28(v_u_207, v220[1] .. "Title", v220[1] == "AxisRpm" and v220[2] or v220[2], v221 - 100, 195, 230, 16, v_u_3.white, 12, Enum.Font.RobotoCondensed, Enum.TextXAlignment.Center)
		v228.Rotation = -90
		v228.Position = UDim2.fromOffset(v221 - 105, 197)
	end
	local v229 = v_u_3.bg2
	local v230 = v_u_1.new("Frame")
	v230.Name = "Plot"
	v230.Position = UDim2.fromOffset(236, 80)
	v230.Size = UDim2.fromOffset(770, 250)
	v230.BackgroundColor3 = v229 or v_u_3.bg
	v230.BackgroundTransparency = 0
	v230.BorderSizePixel = 0
	v230.ZIndex = 2
	v230.Parent = v_u_207
	v230.ClipsDescendants = true
	for v231, v232 in {
		{ "TileFlow", "Intake Flow Rate", "CFM" },
		{ "TileMap", "Manifold Press.", "kPa" },
		{ "TileBaro", "Baro", "mBar" },
		{ "TileAfr", "AFR", ":1" },
		{ "TileEgt", "EGT", "\194\176C" },
		{ "TileOil", "Oil Temp", "\194\176C" }
	} do
		local v233 = (v231 - 1) % 2
		local v234 = (v231 - 1) / 2
		local v235 = math.floor(v234)
		local v236 = v232[1]
		local v237 = 1020 + v233 * 130
		local v238 = v235 * 74 + 18
		local v239 = v_u_3.bg2
		local v240 = v_u_1.new("Frame")
		v240.Name = v236
		v240.Position = UDim2.fromOffset(v237, v238)
		v240.Size = UDim2.fromOffset(122, 66)
		v240.BackgroundColor3 = v239 or v_u_3.bg
		v240.BackgroundTransparency = 0
		v240.BorderSizePixel = 0
		v240.ZIndex = 2
		v240.Parent = v_u_207
		local v241 = v_u_1.new("UICorner")
		v241.CornerRadius = UDim.new(0, 4)
		v241.Parent = v240
		local v242 = v_u_3.orange
		local v243 = v_u_1.new("UIStroke")
		v243.Color = v242
		v243.Thickness = 1.5
		v243.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
		v243.Parent = v240
		v_u_28(v240, "Label", v232[2], 0, 4, 122, 18, v_u_3.white, 14, Enum.Font.RobotoCondensed, Enum.TextXAlignment.Center, 3)
		v_u_28(v240, "Value", "0.00", 0, 22, 122, 26, v_u_3.orange, 24, Enum.Font.RobotoCondensed, Enum.TextXAlignment.Center, 3)
		v_u_28(v240, "Unit", v232[3], 0, 47, 122, 15, v_u_3.white, 12, nil, Enum.TextXAlignment.Center, 3)
	end
	local v244 = v_u_3.bg2
	local v245 = v_u_1.new("Frame")
	v245.Name = "RunList"
	v245.Position = UDim2.fromOffset(1020, 245)
	v245.Size = UDim2.fromOffset(86, 196)
	v245.BackgroundColor3 = v244 or v_u_3.bg
	v245.BackgroundTransparency = 0
	v245.BorderSizePixel = 0
	v245.ZIndex = 2
	v245.Parent = v_u_207
	local v246 = v_u_3.orange
	local v247 = v_u_1.new("UIStroke")
	v247.Color = v246
	v247.Thickness = 1.5
	v247.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v247.Parent = v245
	local v248 = Color3.fromRGB(96, 96, 104)
	local v249 = v_u_1.new("Frame")
	v249.Name = "Head"
	v249.Position = UDim2.fromOffset(3, 3)
	v249.Size = UDim2.fromOffset(80, 24)
	v249.BackgroundColor3 = v248 or v_u_3.bg
	v249.BackgroundTransparency = 0
	v249.BorderSizePixel = 0
	v249.ZIndex = 3
	v249.Parent = v245
	v_u_28(v249, "Text", "No runs", 0, 0, 80, 24, Color3.fromRGB(255, 80, 90), 14, Enum.Font.RobotoCondensed, Enum.TextXAlignment.Center, 4)
	for v250 = 1, 5 do
		v_u_41(v245, "Run" .. v250, "", 3, (v250 - 1) * 32 + 30, 80, 28, Color3.fromRGB(26, 26, 30), v_u_3.white, 14, 4).Visible = false
	end
	local v251 = v_u_41(v_u_207, "RunPlus", "+", 1020, 448, 40, 22, v_u_3.bg2, v_u_3.orange, 20)
	local v252 = v_u_3.orange
	local v253 = v_u_1.new("UIStroke")
	v253.Color = v252
	v253.Thickness = 1.2
	v253.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v253.Parent = v251
	local v254 = v_u_41(v_u_207, "RunMinus", "\226\128\148", 1066, 448, 40, 22, v_u_3.bg2, v_u_3.orange, 18)
	local v255 = v_u_3.orange
	local v256 = v_u_1.new("UIStroke")
	v256.Color = v255
	v256.Thickness = 1.2
	v256.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v256.Parent = v254
	local function v269(p257, p258, p259, p260, p261, p262, p263, p264) -- name: big
		-- upvalues: (ref) v_u_41, (copy) v_u_207, (ref) v_u_1
		local v265 = v_u_41(v_u_207, p257, p258, p259, p260, p261, p262, p263, Color3.new(1, 1, 1), p264 or 22)
		local v266 = v_u_1.new("UICorner")
		v266.CornerRadius = UDim.new(0, 5)
		v266.Parent = v265
		local v267 = Color3.fromRGB(255, 220, 160)
		local v268 = v_u_1.new("UIStroke")
		v268.Color = v267
		v268.Thickness = 1.2
		v268.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
		v268.Parent = v265
		return v265
	end
	v269("Run", "RUN", 1114, 245, 76, 70, Color3.fromRGB(40, 195, 60))
	v269("Stop", "STOP", 1196, 245, 76, 70, Color3.fromRGB(232, 28, 28))
	v269("Hold", "HOLD", 1114, 322, 158, 56, Color3.fromRGB(150, 80, 22))
	v269("Home", "HOME", 1114, 386, 56, 46, Color3.fromRGB(122, 20, 32), 16)
	v269("SetZero", "SET ZERO", 1174, 386, 52, 46, Color3.fromRGB(132, 72, 22), 14)
	v269("Hand", "HAND", 1230, 386, 42, 46, Color3.fromRGB(40, 46, 58), 14)
	v_u_28(v_u_207, "Gain", "x1.00", 1114, 434, 56, 16, v_u_3.white, 13, nil, Enum.TextXAlignment.Center)
	v269("ShowHp", "HP", 1020, 478, 124, 30, Color3.fromRGB(40, 195, 60), 18)
	v269("ShowTq", "Torque", 1150, 478, 122, 30, v_u_3.bg2, 18)
	v269("Sampling", "SAMPLING", 1020, 514, 160, 56, Color3.fromRGB(235, 190, 30), 22)
	v_u_207.Sampling.TextColor3 = Color3.fromRGB(70, 50, 10)
	v269("AutoRun", "AUTO RUN", 1186, 514, 86, 56, Color3.fromRGB(132, 72, 22), 18)
	v_u_28(v_u_207, "ProjectTitle", "Project Info", 1020, 576, 130, 22, v_u_3.white, 18, Enum.Font.Roboto)
	local v270 = v_u_41(v_u_207, "New", "New", 1150, 578, 40, 18, v_u_3.orange, Color3.new(1, 1, 1), 12)
	local v271 = v_u_1.new("UICorner")
	v271.CornerRadius = UDim.new(0, 3)
	v271.Parent = v270
	local v272 = v_u_41(v_u_207, "EditProject", "Edit Project Setting", 1196, 578, 76, 18, v_u_3.orange, Color3.new(1, 1, 1), 9)
	local v273 = v_u_1.new("UICorner")
	v273.CornerRadius = UDim.new(0, 3)
	v273.Parent = v272
	for v274, v275 in {
		{ "InfoProject", "Project:" },
		{ "InfoOwner", "Owner:" },
		{ "InfoEngine", "Engine:" },
		{ "InfoEcu", "ECU gain:" },
		{ "InfoStep", "Step Size:" },
		{ "InfoTemp", "Ambient Temperature:" }
	} do
		local v276 = 602 + (v274 - 1) * 15
		v_u_28(v_u_207, v275[1] .. "Label", v275[2], 1020, v276, 140, 15, v_u_3.white, 12)
		v_u_28(v_u_207, v275[1], "-", 1140, v276, 132, 15, v_u_3.white, 12, nil, Enum.TextXAlignment.Right)
	end
	v_u_28(v_u_207, "Connection", "Connection Status: Connected", 1100, 703, 172, 14, v_u_3.white, 10, nil, Enum.TextXAlignment.Right)
	for v277, v278 in {
		{ "ChRpm", "Engine RPM", Color3.fromRGB(80, 230, 240) },
		{ "ChThr", "Throttle", nil },
		{ "ChAfr", "AFR", Color3.fromRGB(240, 70, 70) },
		{ "ChFlow", "Intake Flow", nil },
		{ "ChEgt", "EGT", nil },
		{ "ChOil", "Oil Temp", nil },
		{ "ChBaro", "Baro", nil }
	} do
		local v279 = v_u_41(v_u_207, v278[1], "", 22, 398 + (v277 - 1) * 44, 128, 40, Color3.fromRGB(30, 30, 34), v_u_3.white, 10, 3)
		local v280 = v_u_1.new("UICorner")
		v280.CornerRadius = UDim.new(0, 3)
		v280.Parent = v279
		local v281 = v278[3] or Color3.fromRGB(30, 30, 34)
		local v282 = v_u_1.new("UIStroke")
		v282.Color = v281
		v282.Thickness = 2
		v282.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
		v282.Parent = v279
		v282.Name = "Edge"
		v_u_28(v279, "Name", v278[2], 8, 3, 118, 18, v_u_3.white, 13, Enum.Font.Roboto, nil, 4)
		v_u_28(v279, "Value", "Value: -", 8, 20, 118, 16, v_u_3.dim, 11, nil, nil, 4)
	end
	local v283 = v_u_3.orange
	local v284 = v_u_1.new("Frame")
	v284.Name = "Scroll"
	v284.Position = UDim2.fromOffset(154, 402)
	v284.Size = UDim2.fromOffset(5, 120)
	v284.BackgroundColor3 = v283 or v_u_3.bg
	v284.BackgroundTransparency = 0
	v284.BorderSizePixel = 0
	v284.ZIndex = 2
	v284.Parent = v_u_207
	local v285 = v_u_3.panel
	local v286 = v_u_1.new("Frame")
	v286.Name = "RunFiles"
	v286.Position = UDim2.fromOffset(172, 396)
	v286.Size = UDim2.fromOffset(840, 268)
	v286.BackgroundColor3 = v285 or v_u_3.bg
	v286.BackgroundTransparency = 0
	v286.BorderSizePixel = 0
	v286.ZIndex = 2
	v286.Parent = v_u_207
	v_u_28(v286, "Title", "RUN FILES", 0, 4, 840, 18, v_u_3.ink, 13, Enum.Font.RobotoCondensed, Enum.TextXAlignment.Center, 3)
	v_u_28(v286, "Legend", "", 60, 22, 600, 16, v_u_3.ink, 11, nil, nil, 3)
	v_u_28(v286, "Readout", "", 600, 22, 230, 60, v_u_3.ink, 11, nil, Enum.TextXAlignment.Left, 6).TextYAlignment = Enum.TextYAlignment.Top
	local v287 = Color3.new(1, 1, 1)
	local v288 = v_u_1.new("Frame")
	v288.Name = "Area"
	v288.Position = UDim2.fromOffset(62, 44)
	v288.Size = UDim2.fromOffset(756, 190)
	v288.BackgroundColor3 = v287 or v_u_3.bg
	v288.BackgroundTransparency = 0
	v288.BorderSizePixel = 0
	v288.ZIndex = 3
	v288.Parent = v286
	v288.ClipsDescendants = true
	local v289 = Color3.fromRGB(190, 190, 196)
	local v290 = v_u_1.new("UIStroke")
	v290.Color = v289
	v290.Thickness = 1
	v290.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v290.Parent = v288
	for v291 = 0, 7 do
		local v292 = v291 / 7 * 756
		local v293 = math.floor(v292)
		local v294 = "GridV" .. v291
		local v295 = Color3.fromRGB(225, 225, 230)
		local v296 = v_u_1.new("Frame")
		v296.Name = v294
		v296.Position = UDim2.fromOffset(v293, 0)
		v296.Size = UDim2.fromOffset(1, 190)
		v296.BackgroundColor3 = v295 or v_u_3.bg
		v296.BackgroundTransparency = 0
		v296.BorderSizePixel = 0
		v296.ZIndex = 3
		v296.Parent = v288
		v_u_28(v286, "XTick" .. v291, ("%d"):format(v291 * 1000 + 2000), v293 + 62 - 30, 236, 60, 14, v_u_3.ink, 11, nil, Enum.TextXAlignment.Center, 3)
	end
	for v297 = 0, 4 do
		local v298 = "GridH" .. v297
		local v299 = v297 / 4 * 189
		local v300 = math.floor(v299)
		local v301 = Color3.fromRGB(225, 225, 230)
		local v302 = v_u_1.new("Frame")
		v302.Name = v298
		v302.Position = UDim2.fromOffset(0, v300)
		v302.Size = UDim2.fromOffset(756, 1)
		v302.BackgroundColor3 = v301 or v_u_3.bg
		v302.BackgroundTransparency = 0
		v302.BorderSizePixel = 0
		v302.ZIndex = 3
		v302.Parent = v288
		local v303 = v_u_28
		local v304 = "YTick" .. v297
		local v305 = v297 / 4 * 190
		v303(v286, v304, "-", 8, math.floor(v305) + 44 - 7, 50, 14, v_u_3.ink, 11, nil, Enum.TextXAlignment.Right, 3)
	end
	v_u_28(v286, "XTitle", "Engine Speed (rpm)", 300, 250, 240, 16, v_u_3.ink, 12, Enum.Font.RobotoCondensed, Enum.TextXAlignment.Center, 3)
	v_u_28(v286, "YTitle", "Power (hp)", -60, 130, 140, 16, v_u_3.ink, 12, Enum.Font.RobotoCondensed, Enum.TextXAlignment.Center, 3).Rotation = -90
	local v306 = v_u_3.ink
	local v307 = v_u_1.new("Frame")
	v307.Name = "Cursor"
	v307.Position = UDim2.fromOffset(0, 0)
	v307.Size = UDim2.fromOffset(2, 190)
	v307.BackgroundColor3 = v306 or v_u_3.bg
	v307.BackgroundTransparency = 1
	v307.BorderSizePixel = 0
	v307.ZIndex = 8
	v307.Parent = v288
	for v308 = 0, 18 do
		local v309 = "Dash" .. v308
		local v310 = v308 * 10
		local v311 = v_u_3.ink
		local v312 = v_u_1.new("Frame")
		v312.Name = v309
		v312.Position = UDim2.fromOffset(0, v310)
		v312.Size = UDim2.fromOffset(1.5, 6)
		v312.BackgroundColor3 = v311 or v_u_3.bg
		v312.BackgroundTransparency = 0
		v312.BorderSizePixel = 0
		v312.ZIndex = 8
		v312.Parent = v307
	end
	v307.Visible = false
	for v313 = 0, 14 do
		local v314 = v313 * 500 + 2000
		local v315 = v_u_41(v_u_207, "Step" .. v313, ("%.1fk"):format(v314 / 1000), v313 * 56.3 + 172, 672, 52, 28, v_u_3.orange, Color3.new(1, 1, 1), 14)
		v315:SetAttribute("Rpm", v314)
		local v316 = v_u_1.new("UICorner")
		v316.CornerRadius = UDim.new(0, 3)
		v316.Parent = v315
	end
	return v_u_207
end
return v_u_2