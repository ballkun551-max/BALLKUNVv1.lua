-- Path: ReplicatedStorage/GameUI/SoundMix
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = game:GetService("SoundService")
local v_u_2 = game:GetService("Players")
local v3 = {
	["KINDS"] = {
		{
			["key"] = "VolMaster",
			["th"] = "\224\185\128\224\184\170\224\184\181\224\184\162\224\184\135\224\184\151\224\184\177\224\185\137\224\184\135\224\184\171\224\184\161\224\184\148",
			["en"] = "All sound"
		},
		{
			["key"] = "VolEngine",
			["th"] = "\224\185\128\224\184\170\224\184\181\224\184\162\224\184\135\224\184\151\224\185\136\224\184\173 / \224\185\128\224\184\132\224\184\163\224\184\183\224\185\136\224\184\173\224\184\135\224\184\162\224\184\153\224\184\149\224\185\140",
			["en"] = "Exhaust and engines"
		},
		{
			["key"] = "VolSignal",
			["th"] = "\224\185\129\224\184\149\224\184\163 / \224\185\132\224\184\159\224\185\128\224\184\165\224\184\181\224\185\137\224\184\162\224\184\167",
			["en"] = "Horns and indicators"
		},
		{
			["key"] = "VolImpact",
			["th"] = "\224\185\128\224\184\170\224\184\181\224\184\162\224\184\135\224\184\138\224\184\153 / \224\184\132\224\184\163\224\184\185\224\184\148\224\184\158\224\184\183\224\185\137\224\184\153",
			["en"] = "Crashes and scrapes"
		},
		{
			["key"] = "VolUI",
			["th"] = "\224\185\129\224\184\136\224\185\137\224\184\135\224\185\128\224\184\149\224\184\183\224\184\173\224\184\153 / \224\184\135\224\184\178\224\184\153 / \224\185\128\224\184\161\224\184\153\224\184\185",
			["en"] = "Alerts, jobs, menus"
		},
		{
			["key"] = "VolAmbient",
			["th"] = "\224\184\154\224\184\163\224\184\163\224\184\162\224\184\178\224\184\129\224\184\178\224\184\168 \224\184\157\224\184\153 \224\184\159\224\185\137\224\184\178\224\184\163\224\185\137\224\184\173\224\184\135",
			["en"] = "Weather and ambience"
		},
		{
			["key"] = "VolOther",
			["th"] = "\224\185\128\224\184\170\224\184\181\224\184\162\224\184\135\224\185\128\224\184\173\224\184\159\224\185\128\224\184\159\224\184\132\224\184\173\224\184\183\224\185\136\224\184\153\224\185\134",
			["en"] = "Other effects"
		}
	}
}
local v_u_4 = {}
for _, v5 in v3.KINDS do
	v_u_4[v5.key] = 1
end
local v_u_6 = v_u_1:FindFirstChild("MixMaster") or Instance.new("SoundGroup")
v_u_6.Name = "MixMaster"
v_u_6.Parent = v_u_1
local v_u_7 = {}
for _, v8 in v3.KINDS do
	if v8.key == "VolMaster" then
		continue
	end
	local v9 = v_u_6:FindFirstChild("Mix" .. v8.key:sub(4)) or Instance.new("SoundGroup")
	v9.Name = "Mix" .. v8.key:sub(4)
	v9.Parent = v_u_6
	v_u_7[v8.key] = v9
end
local v_u_10 = {}
for _, v11 in v_u_7 do
	v_u_10[v11] = true
end
v_u_10[v_u_6] = true
local v_u_12 = setmetatable({}, {
	["__mode"] = "k"
})
local v_u_13 = {
	["Engine"] = true,
	["Start"] = true,
	["Rev"] = true,
	["Acc"] = true,
	["Dec"] = true,
	["Idle"] = true
}
local function v_u_17(p14) -- name: kindOf
	-- upvalues: (copy) v_u_13, (copy) v_u_1
	local v15 = p14.Name
	if v15:find("Horn") or (v15:find("Blink") or (v15:find("Indicator") or v15:find("Hazard"))) then
		return "VolSignal"
	end
	if v15:find("^Engine") or (v15:find("^PCX160_") or (v15:find("^Kit_") or (v_u_13[v15] or (p14:FindFirstAncestor("EngineSoundSet") or (v15:find("Exhaust") or (v15:find("Pop") or (v15:find("Rumble") or (v15:find("Backfire") or (v15:find("Turbo") or (v15:find("Blowoff") or (v15:find("BlowOff") or p14.Parent and (p14.Parent.Name == "Exhaust" or p14.Parent.Name == "ExhaustFx")))))))))))) then
		return "VolEngine"
	end
	if p14.Parent and (p14.Parent:IsA("Attachment") and p14.Parent.Parent == workspace.Terrain) then
		return "VolImpact"
	end
	if v15:find("Crash") or (v15:find("Impact") or (v15:find("Scrape") or v15:find("Skid"))) then
		return "VolImpact"
	end
	if v15:find("Weather") or (v15:find("Rain") or (v15:find("Thunder") or (v15:find("Wind") or v15:find("Ambient")))) then
		return "VolAmbient"
	end
	local v16 = workspace:FindFirstChild("Map")
	return v16 and p14:IsDescendantOf(v16) and "VolAmbient" or ((v15:find("Delivery") or (v15:find("Ping") or (v15:find("Beep") or (v15:find("Click") or (v15:find("Toast") or (v15:find("Notify") or (v15:find("Cash") or (v15:find("Coin") or (v15:find("Fit") or (p14:FindFirstAncestorWhichIsA("PlayerGui") or p14.Parent == v_u_1)))))))))) and "VolUI" or "VolOther")
end
local function v_u_20(p_u_18) -- name: route
	-- upvalues: (copy) v_u_10, (copy) v_u_12, (copy) v_u_4, (copy) v_u_20, (copy) v_u_7, (copy) v_u_17
	if p_u_18:IsA("Sound") then
		task.defer(function()
			-- upvalues: (copy) p_u_18, (ref) v_u_10, (ref) v_u_12, (ref) v_u_20, (ref) v_u_7, (ref) v_u_17
			if p_u_18.Parent then
				local v19 = p_u_18.SoundGroup
				if v19 and not v_u_10[v19] then
					if v19.Name == "CarEngine" and not v_u_12[v19] then
						v_u_20(v19)
					end
				else
					p_u_18.SoundGroup = v_u_7[v_u_17(p_u_18)]
				end
			else
				return
			end
		end)
	elseif p_u_18:IsA("SoundGroup") and (p_u_18.Name == "CarEngine" and not v_u_10[p_u_18]) then
		v_u_12[p_u_18] = p_u_18:GetAttribute("BaseVolume") or p_u_18.Volume
		p_u_18:SetAttribute("BaseVolume", v_u_12[p_u_18])
		p_u_18.Volume = v_u_12[p_u_18] * (v_u_4.VolEngine * v_u_4.VolMaster)
	end
end
local function v_u_24(p21) -- name: watch
	-- upvalues: (copy) v_u_20
	for _, v22 in p21:GetDescendants() do
		if not (v22:IsA("Sound") or v22:IsA("SoundGroup")) then
			continue
		end
		v_u_20(v22)
	end
	p21.DescendantAdded:Connect(function(p23)
		-- upvalues: (ref) v_u_20
		if p23:IsA("Sound") or p23:IsA("SoundGroup") then
			v_u_20(p23)
		end
	end)
end
local function v_u_30() -- name: applyLevels
	-- upvalues: (copy) v_u_6, (copy) v_u_4, (copy) v_u_7, (copy) v_u_12
	v_u_6.Volume = v_u_4.VolMaster
	for v25, v26 in v_u_7 do
		v26.Volume = v_u_4[v25]
	end
	local v27 = v_u_4.VolEngine * v_u_4.VolMaster
	for v28, v29 in v_u_12 do
		if not v28.Parent then
			continue
		end
		v28.Volume = v29 * v27
	end
end
function v3.get(p31) -- name: get
	-- upvalues: (copy) v_u_4
	return v_u_4[p31]
end
function v3.set(p32, p33) -- name: set
	-- upvalues: (copy) v_u_4, (copy) v_u_30
	if v_u_4[p32] ~= nil and (type(p33) == "number" and p33 == p33) then
		v_u_4[p32] = math.clamp(p33, 0, 1)
		v_u_30()
	end
end
local v_u_34 = false
function v3.start() -- name: start
	-- upvalues: (ref) v_u_34, (copy) v_u_24, (copy) v_u_1, (copy) v_u_2, (copy) v_u_30
	if not v_u_34 then
		v_u_34 = true
		v_u_24(workspace)
		v_u_24(v_u_1)
		local v_u_35 = v_u_2.LocalPlayer
		if v_u_35 then
			task.spawn(function()
				-- upvalues: (ref) v_u_24, (copy) v_u_35
				v_u_24(v_u_35:WaitForChild("PlayerGui"))
			end)
		end
		v_u_30()
	end
end
return v3