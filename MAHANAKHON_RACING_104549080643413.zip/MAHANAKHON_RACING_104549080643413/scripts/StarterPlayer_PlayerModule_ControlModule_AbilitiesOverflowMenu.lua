-- Path: StarterPlayer/PlayerModule/ControlModule/AbilitiesOverflowMenu
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("UserInputService")
local v_u_3 = game:GetService("GuiService")
local v_u_4 = require(script.Parent.Parent:WaitForChild("CommonUtils")).get("ConnectionUtil")
local v_u_5 = require(script.Parent:WaitForChild("AvatarAbilitiesInterface")).get(v_u_1.LocalPlayer)
local v_u_6 = require(script.Parent:WaitForChild("InputSlots"))
local v_u_7 = require(script.Parent:WaitForChild("AbilityButton"))
local v_u_8 = { 28, 44 }
local v_u_9 = { 36, 56 }
local v_u_10 = { 16, 12 }
local v_u_11 = { 16, 12 }
local v_u_12 = {}
v_u_12.__index = v_u_12
function v_u_12.new(p13) -- name: new
	-- upvalues: (copy) v_u_12, (copy) v_u_4
	local v14 = v_u_12
	local v15 = setmetatable({}, v14)
	v15.parentUIFrame = p13
	v15.managedButtons = {}
	v15.created = false
	v15.enabled = false
	v15.enabledChangedEvent = Instance.new("BindableEvent")
	v15.selectionMode = false
	v15.selectedVisibleSlot = 1
	v15.numVisibleSlots = 0
	v15.abilityButtonsByVisibleSlot = {}
	v15.selectionRing = nil
	v15.activeActionSlot = nil
	v15.activeButton = nil
	v15.scrollHighlightDirection = "none"
	v15.connections = v_u_4.new()
	v15.inputFolder = nil
	v15.navContext = nil
	return v15
end
function v_u_12.Enable(p16, p17) -- name: Enable
	if p16.enabled ~= p17 then
		p16.enabled = p17
		if p17 and not p16.created then
			p16:Create()
			p16.created = true
		end
		if not p17 then
			p16:ExitSelectionMode()
		end
		if p16.created then
			p16:UpdateInputMode()
		end
		p16.enabledChangedEvent:Fire()
	end
end
function v_u_12.CreateOverflowScrollButton(p_u_18, p_u_19) -- name: CreateOverflowScrollButton
	-- upvalues: (copy) v_u_1, (copy) v_u_8, (copy) v_u_9, (copy) v_u_10, (copy) v_u_11, (copy) v_u_6, (copy) v_u_4, (copy) v_u_12
	local v_u_20 = Instance.new("ImageButton")
	v_u_20.Name = "ScrollButton"
	v_u_20.BackgroundTransparency = 1
	v_u_20.Image = "rbxassetid://120193229129639"
	v_u_20.PressedImage = "rbxassetid://122643389561468"
	v_u_20.Parent = p_u_18.parentUIFrame
	local function v36() -- name: ResizeButton
		-- upvalues: (copy) p_u_18, (ref) v_u_1, (ref) v_u_8, (ref) v_u_9, (ref) v_u_10, (ref) v_u_11, (ref) v_u_6, (copy) v_u_20, (copy) p_u_19
		local v21 = p_u_18.parentUIFrame.AbsoluteSize.x
		local v22 = p_u_18.parentUIFrame.AbsoluteSize.y
		local v23 = math.min(v21, v22)
		local v24 = v_u_1.LocalPlayer:FindFirstChildOfClass("PlayerGui")
		local v25
		if v24 then
			v25 = v24.CurrentScreenOrientation == Enum.ScreenOrientation.Portrait
		else
			v25 = false
		end
		local v26 = v23 <= 500
		local v27 = v26 and v_u_8 or v_u_9
		local v28 = v26 and v_u_10 or v_u_11
		local v29 = v27[1]
		local v30 = v27[2]
		local v31 = v28[1]
		local v32 = v28[2]
		local v33 = 0.5 * (v30 - v29)
		local v34 = v_u_6.GetNumOverflowSlots()
		local v35 = v34 * (v26 and 44 or 56) + (v34 + 1) * (v26 and 8 or 10)
		v_u_20.Size = UDim2.new(0, v29, 0, v30)
		if p_u_19 == "previous" then
			if v25 then
				v_u_20.Position = UDim2.new(1, -v31 - v30 + v33, 0, v32 + v29 + v35 - v33)
				v_u_20.Rotation = 270
			else
				v_u_20.Position = UDim2.new(1, -v31 - 2 * v29 - v35, 0, v32)
				v_u_20.Rotation = 0
			end
		elseif v25 then
			v_u_20.Position = UDim2.new(1, -v31 - v30 + v33, 0, v32 - v33)
			v_u_20.Rotation = 90
		else
			v_u_20.Position = UDim2.new(1, -v31 - v29, 0, v32)
			v_u_20.Rotation = 180
		end
	end
	v36()
	local v_u_37 = v_u_4.new()
	v_u_37:trackConnection("ParentResize", p_u_18.parentUIFrame:GetPropertyChangedSignal("AbsoluteSize"):Connect(v36))
	v_u_20.Activated:Connect(function()
		-- upvalues: (copy) p_u_19, (ref) v_u_6
		if p_u_19 == "previous" then
			v_u_6.setOverflowScrollIndex(v_u_6.getOverflowScrollIndex() + 1)
		else
			v_u_6.setOverflowScrollIndex(v_u_6.getOverflowScrollIndex() - 1)
		end
	end)
	v_u_20.Destroying:Connect(function()
		-- upvalues: (copy) v_u_37
		v_u_37:disconnectAll()
	end)
	v_u_20.Selectable = false
	if v_u_12.IsGamepad() then
		v_u_20.Active = false
		v_u_20.AutoButtonColor = false
	end
	return v_u_20
end
function v_u_12.SetScrollHighlight(p38, p39) -- name: SetScrollHighlight
	if p38.scrollHighlightDirection ~= p39 then
		p38.scrollHighlightDirection = p39
		if p38.created then
			p38:CreateButtons()
		end
	end
end
function v_u_12.GetScrollDirectionForMove(p40, p41) -- name: GetScrollDirectionForMove
	-- upvalues: (copy) v_u_6
	if not p40.selectionMode or (p40.activeActionSlot or p41 == "none") then
		return "none"
	end
	local v42 = p41 == "previous" and 1 or -1
	local v43 = #v_u_6.GetAbilitiesInOverflow() - v_u_6.GetNumOverflowSlots()
	local v44 = math.max(0, v43)
	local v45 = v_u_6.getOverflowScrollIndex()
	local v46 = p40.selectedVisibleSlot + v42
	return v46 < 1 and v45 > 0 and "next" or (p40.numVisibleSlots < v46 and v45 < v44 and "previous" or "none")
end
function v_u_12.IsGamepad() -- name: IsGamepad
	-- upvalues: (copy) v_u_2
	return v_u_2.PreferredInput == Enum.PreferredInput.Gamepad
end
function v_u_12.IsKeyboardMouse() -- name: IsKeyboardMouse
	-- upvalues: (copy) v_u_2
	return v_u_2.PreferredInput == Enum.PreferredInput.KeyboardAndMouse
end
function v_u_12.SupportsSelection() -- name: SupportsSelection
	-- upvalues: (copy) v_u_12
	return v_u_12.IsGamepad() or v_u_12.IsKeyboardMouse()
end
function v_u_12.EnsureSelectionRing(p47) -- name: EnsureSelectionRing
	if not p47.selectionRing then
		local v48 = Instance.new("Frame")
		v48.Name = "SelectionRing"
		v48.BackgroundTransparency = 1
		v48.Size = UDim2.new(1, 8, 1, 8)
		v48.Position = UDim2.new(0, -4, 0, -4)
		local v49 = Instance.new("UICorner")
		v49.CornerRadius = UDim.new(1, 0)
		v49.Parent = v48
		local v50 = Instance.new("UIStroke")
		v50.Thickness = 3
		v50.Color = Color3.new(1, 1, 1)
		v50.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
		v50.Parent = v48
		p47.selectionRing = v48
	end
end
function v_u_12.EnsureInputObjects(p_u_51) -- name: EnsureInputObjects
	if not p_u_51.inputFolder then
		local v52 = script:FindFirstChild("AbilitiesOverflowInput")
		if v52 then
			v52:Destroy()
		end
		local v53 = Instance.new("Folder")
		v53.Name = "AbilitiesOverflowInput"
		local v_u_54 = Instance.new("InputContext")
		v_u_54.Name = "AbilitiesOverflowNavContext"
		v_u_54.Priority = 500
		v_u_54.Sink = true
		v_u_54.Enabled = false
		v_u_54.Parent = v53
		local function v61(p55, p56) -- name: createNavAction
			-- upvalues: (copy) v_u_54
			local v57 = Instance.new("InputAction")
			v57.Name = p55
			v57.Type = Enum.InputActionType.Bool
			v57.Parent = v_u_54
			for v58, v59 in p56 do
				local v60 = Instance.new("InputBinding")
				v60.Name = "Binding" .. v58
				v60.KeyCode = v59
				v60.Parent = v57
			end
			return v57
		end
		local v62 = v61("NavPreviousAction", { Enum.KeyCode.ButtonL1, Enum.KeyCode.DPadLeft, Enum.KeyCode.Left })
		p_u_51.connections:trackConnection("NavPrevious", v62.StateChanged:Connect(function(p63)
			-- upvalues: (copy) p_u_51
			if p63 then
				p_u_51:SetScrollHighlight(p_u_51:GetScrollDirectionForMove("previous"))
			else
				p_u_51:SetScrollHighlight("none")
				p_u_51:MoveSelection("previous")
			end
		end))
		local v64 = v61("NavNextAction", { Enum.KeyCode.ButtonR1, Enum.KeyCode.DPadRight, Enum.KeyCode.Right })
		p_u_51.connections:trackConnection("NavNext", v64.StateChanged:Connect(function(p65)
			-- upvalues: (copy) p_u_51
			if p65 then
				p_u_51:SetScrollHighlight(p_u_51:GetScrollDirectionForMove("next"))
			else
				p_u_51:SetScrollHighlight("none")
				p_u_51:MoveSelection("next")
			end
		end))
		local v66 = v61("ExitAction", { Enum.KeyCode.ButtonB })
		p_u_51.connections:trackConnection("Exit", v66.Pressed:Connect(function()
			-- upvalues: (copy) p_u_51
			p_u_51:ExitSelectionMode()
		end))
		local v67 = v61("ActivateAction", { Enum.KeyCode.ButtonA, Enum.KeyCode.Return, Enum.KeyCode.KeypadEnter })
		p_u_51.connections:trackConnection("Activate", v67.StateChanged:Connect(function(p68)
			-- upvalues: (copy) p_u_51
			if p68 then
				p_u_51.activeActionSlot = p_u_51.selectedVisibleSlot
				p_u_51.activeButton = p_u_51.abilityButtonsByVisibleSlot[p_u_51.activeActionSlot]
				if p_u_51.activeButton then
					p_u_51.activeButton:SetSelectionPressed(true)
					return
				end
			elseif p_u_51.activeActionSlot then
				p_u_51:ExitSelectionMode()
			end
		end))
		v61("AbilitySinkAction", {
			Enum.KeyCode.ButtonX,
			Enum.KeyCode.ButtonY,
			Enum.KeyCode.ButtonL2,
			Enum.KeyCode.ButtonR2,
			Enum.KeyCode.DPadDown
		})
		v53.Parent = script
		p_u_51.inputFolder = v53
		p_u_51.navContext = v_u_54
	end
end
function v_u_12.UpdateInputMode(p69) -- name: UpdateInputMode
	-- upvalues: (copy) v_u_12
	if p69.parentUIFrame then
		if v_u_12.SupportsSelection() then
			p69:EnsureInputObjects()
			if not p69.enabled and p69.selectionMode then
				p69:ExitSelectionMode()
			end
		elseif p69.selectionMode then
			p69:ExitSelectionMode()
		end
		p69.parentUIFrame.Visible = true
	end
end
function v_u_12.EnterSelectionMode(p70) -- name: EnterSelectionMode
	-- upvalues: (copy) v_u_12
	if p70.selectionMode then
		return
	elseif v_u_12.SupportsSelection() and p70.enabled then
		if p70.numVisibleSlots > 0 then
			p70.selectionMode = true
			if p70.navContext then
				p70.navContext.Enabled = true
			end
			p70.parentUIFrame.Visible = true
			local v71 = p70.selectedVisibleSlot
			local v72 = p70.numVisibleSlots
			p70.selectedVisibleSlot = math.clamp(v71, 1, v72)
			p70:RefreshSelection()
		end
	else
		return
	end
end
function v_u_12.ExitSelectionMode(p73) -- name: ExitSelectionMode
	p73.selectionMode = false
	if p73.navContext then
		p73.navContext.Enabled = false
	end
	if p73.scrollHighlightDirection ~= "none" then
		p73.scrollHighlightDirection = "none"
		if p73.created then
			p73:CreateButtons()
		end
	end
	if p73.activeButton then
		p73.activeButton:SetSelectionPressed(false)
		p73.activeButton = nil
	end
	p73.activeActionSlot = nil
	if p73.selectionRing then
		p73.selectionRing.Parent = nil
	end
end
function v_u_12.MoveSelection(p74, p75) -- name: MoveSelection
	-- upvalues: (copy) v_u_6
	if p74.selectionMode then
		if p74.activeActionSlot then
			return
		elseif p75 ~= "none" then
			local v76 = p75 == "previous" and 1 or -1
			local v77 = #v_u_6.GetAbilitiesInOverflow() - v_u_6.GetNumOverflowSlots()
			local v78 = math.max(0, v77)
			local v79 = v_u_6.getOverflowScrollIndex()
			local v80 = p74.selectedVisibleSlot + v76
			if v80 < 1 then
				if v79 > 0 then
					p74.selectedVisibleSlot = 1
					v_u_6.setOverflowScrollIndex(v79 - 1)
				end
			elseif p74.numVisibleSlots < v80 then
				if v79 < v78 then
					p74.selectedVisibleSlot = p74.numVisibleSlots
					v_u_6.setOverflowScrollIndex(v79 + 1)
				end
			else
				p74.selectedVisibleSlot = v80
			end
			p74:RefreshSelection()
		end
	else
		return
	end
end
function v_u_12.RefreshSelection(p81) -- name: RefreshSelection
	-- upvalues: (copy) v_u_12
	if v_u_12.SupportsSelection() and p81.selectionMode then
		if p81.numVisibleSlots > 0 then
			local v82 = p81.selectedVisibleSlot
			local v83 = p81.numVisibleSlots
			p81.selectedVisibleSlot = math.clamp(v82, 1, v83)
			local v84 = p81.abilityButtonsByVisibleSlot[p81.selectedVisibleSlot]
			if v84 then
				p81:EnsureSelectionRing()
				p81.selectionRing.Parent = v84.instance
				p81.selectionRing.Visible = true
			end
		end
	else
		return
	end
end
function v_u_12.Teardown(p85) -- name: Teardown
	p85.connections:disconnectAll()
	p85.created = false
	p85:ExitSelectionMode()
	if p85.inputFolder then
		p85.inputFolder:Destroy()
		p85.inputFolder = nil
		p85.navContext = nil
	end
	if p85.selectionRing then
		p85.selectionRing:Destroy()
		p85.selectionRing = nil
	end
end
function v_u_12.CreateButtons(p86) -- name: CreateButtons
	-- upvalues: (copy) v_u_5, (copy) v_u_6, (copy) v_u_8, (copy) v_u_9, (copy) v_u_1, (copy) v_u_10, (copy) v_u_11, (copy) v_u_7, (copy) v_u_12
	if p86.selectionRing then
		p86.selectionRing.Parent = nil
	end
	for _, v87 in p86.managedButtons do
		v87:Destroy()
	end
	p86.managedButtons = {}
	p86.abilityButtonsByVisibleSlot = {}
	p86.numVisibleSlots = 0
	if v_u_5:isEnabled() then
		local v88 = v_u_6.GetAbilitiesInOverflow()
		local v89 = #v88
		local v90 = v_u_6.GetNumOverflowSlots
		local v91 = math.min(v89, v90())
		local v92 = nil
		local v93 = nil
		local v94, v95
		if #v88 > v_u_6.GetNumOverflowSlots() then
			local v96 = v_u_6.getOverflowScrollIndex()
			local v97 = #v88 - v_u_6.GetNumOverflowSlots()
			if v96 > 0 then
				v93 = p86:CreateOverflowScrollButton("next")
				local v98 = p86.managedButtons
				table.insert(v98, v93)
			end
			if v96 < v97 then
				v92 = p86:CreateOverflowScrollButton("previous")
				local v99 = p86.managedButtons
				table.insert(v99, v92)
			end
			v94 = v_u_8[1] + 8
			v95 = v_u_9[1] + 10
		else
			v94 = 0
			v95 = 0
		end
		if p86.scrollHighlightDirection == "previous" and v92 then
			v92.Image = "rbxassetid://122643389561468"
		elseif p86.scrollHighlightDirection == "next" and v93 then
			v93.Image = "rbxassetid://122643389561468"
		end
		for v100 = 1, v91 do
			local v101 = v88[v100 + v_u_6.getOverflowScrollIndex()]
			local v102 = v_u_6.GetOverflowAction(v100)
			if not (v101 and v102) then
				continue
			end
			local v103 = v_u_5:GetAbilityConfig(v101)
			local v104 = v_u_1.LocalPlayer:FindFirstChildOfClass("PlayerGui")
			local v105
			if v104 then
				v105 = v104.CurrentScreenOrientation == Enum.ScreenOrientation.Portrait
			else
				v105 = false
			end
			local v106
			if v105 then
				v106 = {
					["small"] = { 44, v_u_10[1], v_u_10[2] + v94 + (v100 - 1) * 52 },
					["large"] = { 56, v_u_11[1], v_u_11[2] + v95 + (v100 - 1) * 66 }
				}
			else
				v106 = {
					["small"] = { 44, v_u_10[1] + v94 + (v100 - 1) * 52, v_u_10[2] },
					["large"] = { 56, v_u_11[1] + v95 + (v100 - 1) * 66, v_u_11[2] }
				}
			end
			local v107 = v_u_7.create(p86, v101, v103, v102, v106, true, true)
			local v108 = p86.managedButtons
			table.insert(v108, v107)
			p86.abilityButtonsByVisibleSlot[v100] = v107
			p86.numVisibleSlots = v100
			if v100 ~= p86.activeActionSlot then
				continue
			end
			p86.activeButton = v107
			v107:SetSelectionPressed(true)
		end
		p86.parentUIFrame.Visible = true
		if p86.selectionMode then
			if p86.numVisibleSlots <= 0 then
				p86:ExitSelectionMode()
				return
			end
			if v_u_12.SupportsSelection() then
				p86:RefreshSelection()
			end
		end
	end
end
function v_u_12.Create(p_u_109) -- name: Create
	-- upvalues: (copy) v_u_6, (copy) v_u_5, (copy) v_u_2, (copy) v_u_12, (copy) v_u_3, (copy) v_u_1
	if p_u_109.parentUIFrame then
		p_u_109:CreateButtons()
		p_u_109.connections:trackConnection("SlotMapChanged", v_u_6.GetSlotMapChangedSignal():Connect(function()
			-- upvalues: (copy) p_u_109
			p_u_109:CreateButtons()
			p_u_109.selectedVisibleSlot = p_u_109.numVisibleSlots
			p_u_109:RefreshSelection()
		end))
		p_u_109.connections:trackConnection("AbilitiesEnabledChanged", v_u_5:GetEnabledChangedSignal():Connect(function()
			-- upvalues: (copy) p_u_109
			p_u_109:CreateButtons()
		end))
		p_u_109.connections:trackConnection("ScrollIndexChanged", v_u_6.getScrollIndexChangedEvent():Connect(function()
			-- upvalues: (copy) p_u_109
			p_u_109:CreateButtons()
		end))
		p_u_109.connections:trackConnection("PreferredInput", v_u_2:GetPropertyChangedSignal("PreferredInput"):Connect(function()
			-- upvalues: (copy) p_u_109
			p_u_109:UpdateInputMode()
			p_u_109:CreateButtons()
		end))
		p_u_109.connections:trackConnection("InputBegan", v_u_2.InputBegan:Connect(function(p110, p111)
			-- upvalues: (copy) p_u_109, (ref) v_u_12
			if p111 then
				return
			elseif p_u_109.enabled then
				local v112 = ((not v_u_12.IsGamepad() or p110.KeyCode ~= Enum.KeyCode.DPadUp) and true or false) and v_u_12.IsKeyboardMouse()
				if v112 then
					v112 = p110.KeyCode == Enum.KeyCode.M
				end
				if v112 then
					if p_u_109.selectionMode then
						p_u_109:ExitSelectionMode()
					else
						p_u_109:EnterSelectionMode()
					end
				else
					return
				end
			else
				return
			end
		end))
		p_u_109.connections:trackConnection("MenuOpened", v_u_3.MenuOpened:Connect(function()
			-- upvalues: (copy) p_u_109
			if p_u_109.selectionMode then
				p_u_109:ExitSelectionMode()
			end
		end))
		local v113 = v_u_1.LocalPlayer:WaitForChild("PlayerGui", 5)
		if v113 then
			p_u_109.connections:trackConnection("ScreenOrientation", v113:GetPropertyChangedSignal("CurrentScreenOrientation"):Connect(function()
				-- upvalues: (copy) p_u_109
				p_u_109:CreateButtons()
			end))
		end
		p_u_109.parentUIFrame.Destroying:Connect(function()
			-- upvalues: (copy) p_u_109
			p_u_109:Teardown()
		end)
		p_u_109:UpdateInputMode()
	end
end
return v_u_12