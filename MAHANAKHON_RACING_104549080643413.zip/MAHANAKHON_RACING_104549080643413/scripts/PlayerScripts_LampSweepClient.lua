-- Path: Players/ygggggg55551/PlayerScripts/LampSweepClient
-- Class: LocalScript  true/Enum.RunContext.Legacy
-- Decompiled by BALL KUN Universal Map Dump

local v1 = game:GetService("CollectionService")
local v2 = game:GetService("Players")
local v3 = game:GetService("ReplicatedStorage")
local v4 = game:GetService("RunService")
local v_u_5 = require(v3:WaitForChild("CarShared"))
local v_u_6 = Color3.fromRGB(255, 250, 238)
local v_u_7 = Color3.fromRGB(255, 150, 20)
local v_u_8 = Color3.fromRGB(255, 25, 25)
local v_u_9 = v_u_8:Lerp(Color3.new(0, 0, 0), 0.4)
local v_u_10 = Color3.fromRGB(255, 244, 228)
local v_u_11 = v2.LocalPlayer
local v_u_12 = {}
local function v_u_18(p13, p14) -- name: collect
	if p13 then
		for _, v15 in p13:GetChildren() do
			local v16 = v15:IsA("BasePart")
			if v16 then
				v16 = p14[v15:GetAttribute("SweepSide")]
			end
			if not v16 then
				continue
			end
			local v17 = {
				["part"] = nil,
				["u"] = nil,
				["gate"] = nil,
				["color"] = nil,
				["material"] = nil,
				["variant"] = nil,
				["key"] = nil,
				["part"] = v15,
				["u"] = v15:GetAttribute("SweepU") or 0,
				["gate"] = v15:GetAttribute("TailZone") == "Gate",
				["color"] = v15.Color,
				["material"] = v15.Material,
				["variant"] = v15.MaterialVariant
			}
			table.insert(v16, v17)
		end
	end
end
local function v24(p19) -- name: add
	-- upvalues: (copy) v_u_12, (copy) v_u_18
	if p19:IsA("Model") and not v_u_12[p19] then
		local v20 = p19:FindFirstChild("Chassis")
		local v21 = p19:FindFirstChild("GuideSlices")
		local v22 = p19:FindFirstChild("TailSlices")
		if v20 and (v21 or v22) then
			local v23 = {
				["chassis"] = v20,
				["front"] = {
					["Left"] = {},
					["Right"] = {}
				},
				["rear"] = {
					["Left"] = {},
					["Right"] = {}
				}
			}
			v_u_18(v21, v23.front)
			v_u_18(v22, v23.rear)
			v_u_12[p19] = v23
		end
	else
		return
	end
end
v1:GetInstanceAddedSignal("GTACar"):Connect(v24)
v1:GetInstanceRemovedSignal("GTACar"):Connect(function(p25)
	-- upvalues: (copy) v_u_12
	v_u_12[p25] = nil
end)
for _, v26 in v1:GetTagged("GTACar") do
	task.spawn(v24, v26)
end
v4.RenderStepped:Connect(function()
	-- upvalues: (copy) v_u_5, (copy) v_u_12, (copy) v_u_11, (copy) v_u_6, (copy) v_u_7, (copy) v_u_8, (copy) v_u_10, (copy) v_u_9
	local v27 = workspace.CurrentCamera
	local v28 = not v27 and Vector3.new(0, 0, 0) or v27.CFrame.Position
	local v29 = workspace:GetServerTimeNow()
	local v30 = os.clock()
	local v31 = v29 % v_u_5.BLINK_PERIOD
	local v32 = v31 < v_u_5.BLINK_ON_TIME
	local v33 = v31 / (v_u_5.BLINK_ON_TIME * 0.75) * 1.08
	for v34, v35 in v_u_12 do
		if v34.Parent then
			if (v35.chassis.Position - v28).Magnitude > 250 then
				continue
			end
			local v36 = v34:GetAttribute("HeadlightsOn") == true
			local v37
			if v34:GetAttribute("EngineOn") == true then
				v37 = v34:GetAttribute("RainbowOn") == true
			else
				v37 = false
			end
			local v38
			if v34:GetAttribute("GuideLitWithEngine") == true then
				v38 = v34:GetAttribute("EngineOn") == true
			else
				v38 = false
			end
			local v39 = v34:GetAttribute("DRLStyle") or "Rainbow"
			local v40 = v34:GetAttribute("Indicator") or "Off"
			local v41 = v34:GetAttribute("Braking") == true
			local v42 = v34:GetAttribute("Reversing") == true
			if v34:GetAttribute("DriverId") == v_u_11.UserId and v34:GetAttribute("LocalBraking") ~= nil then
				v41 = v34:GetAttribute("LocalBraking") == true
				if v34:GetAttribute("LocalReversing") == true then
					v42 = true
				else
					v42 = false
				end
			end
			for _, v43 in { "Left", "Right" } do
				local v44 = v40 == v43 and true or v40 == "Hazard"
				for _, v45 in v35.front[v43] do
					local v46 = nil
					if v37 then
						local v47 = v45.u
						if v39 == "Mode" then
							v46 = v_u_5.modeColor(v34, v47, v43, v29)
						else
							v46 = v_u_5.lightColor(v34, 1 + v47 * 1000, 1001, v30)
						end
					elseif v36 or v38 then
						v46 = v_u_6
					end
					if v44 then
						local v48
						if v32 then
							local v49 = (v33 - v45.u) / 0.08
							local v50 = math.clamp(v49, 0, 1) * 8 + 0.5
							v48 = math.floor(v50) / 8
						else
							v48 = 0
						end
						local v51
						if v48 > 0 then
							v51 = v45.color:Lerp(v_u_7, v48)
						else
							v51 = nil
						end
						local v52 = v51 or false
						if v45.key == v52 then
							continue
						end
						v45.key = v52
						if v51 then
							local v53 = v45.part
							local v54 = v45.part
							local v55 = v45.part
							local v56 = Enum.Material.Neon
							v53.Color = v51
							v54.Material = v56
							v55.MaterialVariant = ""
						else
							local v57 = v45.part
							local v58 = v45.part
							local v59 = v45.part
							local v60 = v45.color
							local v61 = v45.material
							local v62 = v45.variant
							v57.Color = v60
							v58.Material = v61
							v59.MaterialVariant = v62
						end
					else
						local v63 = v46 or false
						if v45.key == v63 then
							continue
						end
						v45.key = v63
						if v46 then
							local v64 = v45.part
							local v65 = v45.part
							local v66 = v45.part
							local v67 = Enum.Material.Neon
							v64.Color = v46
							v65.Material = v67
							v66.MaterialVariant = ""
						else
							local v68 = v45.part
							local v69 = v45.part
							local v70 = v45.part
							local v71 = v45.color
							local v72 = v45.material
							local v73 = v45.variant
							v68.Color = v71
							v69.Material = v72
							v70.MaterialVariant = v73
						end
					end
				end
				for _, v74 in v35.rear[v43] do
					local v75 = nil
					if v37 then
						local v76 = v74.u
						if v39 == "Mode" then
							v75 = v_u_5.modeColor(v34, v76, v43, v29)
						else
							v75 = v_u_5.lightColor(v34, 1 + v76 * 1000, 1001, v30)
						end
					elseif v41 then
						v75 = v_u_8
					elseif v42 then
						if v74.gate then
							v75 = v_u_10
						else
							v75 = v_u_8
						end
					elseif v36 then
						v75 = v_u_9
					end
					local v77
					if v44 and v32 then
						local v78 = (v33 - v74.u) / 0.08
						local v79 = math.clamp(v78, 0, 1) * 8 + 0.5
						v77 = math.floor(v79) / 8
					else
						v77 = 0
					end
					if v77 > 0 then
						local v80 = (v75 or v74.color):Lerp(v_u_7, v77)
						local v81 = v80 or false
						if v74.key == v81 then
							continue
						end
						v74.key = v81
						if v80 then
							local v82 = v74.part
							local v83 = v74.part
							local v84 = v74.part
							local v85 = Enum.Material.Neon
							v82.Color = v80
							v83.Material = v85
							v84.MaterialVariant = ""
						else
							local v86 = v74.part
							local v87 = v74.part
							local v88 = v74.part
							local v89 = v74.color
							local v90 = v74.material
							local v91 = v74.variant
							v86.Color = v89
							v87.Material = v90
							v88.MaterialVariant = v91
						end
					else
						local v92 = v75 or false
						if v74.key == v92 then
							continue
						end
						v74.key = v92
						if v75 then
							local v93 = v74.part
							local v94 = v74.part
							local v95 = v74.part
							local v96 = Enum.Material.Neon
							v93.Color = v75
							v94.Material = v96
							v95.MaterialVariant = ""
						else
							local v97 = v74.part
							local v98 = v74.part
							local v99 = v74.part
							local v100 = v74.color
							local v101 = v74.material
							local v102 = v74.variant
							v97.Color = v100
							v98.Material = v101
							v99.MaterialVariant = v102
						end
					end
				end
			end
		else
			v_u_12[v34] = nil
		end
	end
end)