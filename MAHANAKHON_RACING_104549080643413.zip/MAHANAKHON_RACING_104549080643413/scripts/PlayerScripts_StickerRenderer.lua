-- Path: Players/ygggggg55551/PlayerScripts/StickerRenderer
-- Class: LocalScript  true/Enum.RunContext.Legacy
-- Decompiled by BALL KUN Universal Map Dump

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = require(v1:WaitForChild("StickerBuilder"))
local v3 = require(v1:WaitForChild("StickerCatalog"))
local v_u_4 = {}
local v_u_5 = {}
local function v_u_16(p6) -- name: draw
	-- upvalues: (copy) v_u_2, (copy) v_u_4
	local v7 = p6:GetAttribute(v_u_2.ATTR)
	local v8 = type(v7) ~= "string" and "" or v7
	local v9 = v_u_4[p6]
	if v9 and (v9.text == v8 and (v9.folder and v9.folder.Parent)) then
		return
	else
		local v10 = v_u_4[p6]
		if v10 then
			v_u_4[p6] = nil
			if v10.folder then
				v10.folder:Destroy()
			end
		end
		if v8 == "" then
			v_u_4[p6] = {
				["text"] = ""
			}
		else
			local v11 = Instance.new("Folder")
			v11.Name = "StickerVisuals"
			local v12 = v_u_2.build
			local v13 = v_u_2.decode(v8)
			local v14, v15 = pcall(v12, p6, v13, v11, {})
			if not v14 then
				warn("StickerRenderer:", v15)
			end
			v11.Parent = p6
			v_u_4[p6] = {
				["folder"] = v11,
				["text"] = v8
			}
		end
	end
end
local function v_u_23(p_u_17) -- name: watch
	-- upvalues: (copy) v_u_5, (copy) v_u_2, (copy) v_u_16, (copy) v_u_4
	if not v_u_5[p_u_17] then
		v_u_5[p_u_17] = p_u_17:GetAttributeChangedSignal(v_u_2.ATTR):Connect(function()
			-- upvalues: (copy) p_u_17, (ref) v_u_16, (ref) v_u_4
			local v18 = p_u_17
			local v19 = workspace.CurrentCamera
			local v20
			if v19 == nil then
				v20 = false
			else
				v20 = (v18:GetPivot().Position - v19.CFrame.Position).Magnitude
			end
			if v20 and v20 < 360 then
				v_u_16(p_u_17)
			else
				local v21 = p_u_17
				local v22 = v_u_4[v21]
				if v22 then
					v_u_4[v21] = nil
					if v22.folder then
						v22.folder:Destroy()
					end
				end
			end
		end)
	end
end
local v_u_24 = {}
local function v_u_35(p25) -- name: follow
	-- upvalues: (copy) v_u_24, (copy) v_u_23, (copy) v_u_4, (copy) v_u_5, (copy) v_u_2, (copy) v_u_16
	local v26 = v_u_24
	table.insert(v26, p25)
	p25.ChildAdded:Connect(v_u_23)
	p25.ChildRemoved:Connect(function(p27)
		-- upvalues: (ref) v_u_4, (ref) v_u_5
		local v28 = v_u_4[p27]
		if v28 then
			v_u_4[p27] = nil
			if v28.folder then
				v28.folder:Destroy()
			end
		end
		if v_u_5[p27] then
			v_u_5[p27]:Disconnect()
			v_u_5[p27] = nil
		end
	end)
	for _, v_u_29 in p25:GetChildren() do
		if v_u_5[v_u_29] then
			continue
		end
		v_u_5[v_u_29] = v_u_29:GetAttributeChangedSignal(v_u_2.ATTR):Connect(function()
			-- upvalues: (copy) v_u_29, (ref) v_u_16, (ref) v_u_4
			local v30 = v_u_29
			local v31 = workspace.CurrentCamera
			local v32
			if v31 == nil then
				v32 = false
			else
				v32 = (v30:GetPivot().Position - v31.CFrame.Position).Magnitude
			end
			if v32 and v32 < 360 then
				v_u_16(v_u_29)
			else
				local v33 = v_u_29
				local v34 = v_u_4[v33]
				if v34 then
					v_u_4[v33] = nil
					if v34.folder then
						v34.folder:Destroy()
					end
				end
			end
		end)
	end
end
v_u_35(workspace:WaitForChild("SpawnedVehicles"))
task.spawn(function()
	-- upvalues: (copy) v_u_35
	v_u_35(workspace:WaitForChild("VehicleCargo"))
end)
v3.changed:Connect(function()
	-- upvalues: (copy) v_u_4
	for v36 in v_u_4 do
		local v37 = v_u_4[v36]
		if not v37 then
			continue
		end
		v_u_4[v36] = nil
		if not v37.folder then
			continue
		end
		v37.folder:Destroy()
	end
end)
while true do
	task.wait(0.5)
	for _, v38 in v_u_24 do
		for _, v39 in v38:GetChildren() do
			local v40 = workspace.CurrentCamera
			local v41
			if v40 == nil then
				v41 = false
			else
				v41 = (v39:GetPivot().Position - v40.CFrame.Position).Magnitude
			end
			if v41 and v41 < 300 then
				v_u_16(v39)
			else
				if not v41 or (v41 <= 360 or not v_u_4[v39]) then
					continue
				end
				local v42 = v_u_4[v39]
				if not v42 then
					continue
				end
				v_u_4[v39] = nil
				if not v42.folder then
					continue
				end
				v42.folder:Destroy()
			end
		end
	end
end