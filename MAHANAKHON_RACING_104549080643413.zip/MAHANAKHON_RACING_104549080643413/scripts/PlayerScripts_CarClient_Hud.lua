-- Path: Players/ygggggg55551/PlayerScripts/CarClient/Hud
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = require(v1:WaitForChild("CarShared"))
local v_u_3 = require(v1:WaitForChild("GameUI"):WaitForChild("Dash"))
local v_u_4 = {
	{ "R", "Start" },
	{ "Z / C", "Signals" },
	{ "X", "Hazards" },
	{ "L", "Headlights" },
	{ "H", "Horn" },
	{ "Shift", "Handbrake" },
	{ "V", "Camera" },
	{ "G", "RGB lights" },
	{ "P", "Tune" },
	{ "Space", "Get off" }
}
return {
	["start"] = function(p_u_5) -- name: start
		-- upvalues: (copy) v_u_4, (copy) v_u_3
		if p_u_5.model then
			local v6 = {
				{
					["id"] = "view",
					["label"] = "Camera",
					["slot"] = "left",
					["press"] = nil,
					["press"] = p_u_5.onView
				},
				{
					["id"] = "horn",
					["label"] = "Horn",
					["slot"] = "center",
					["hold"] = true,
					["press"] = nil,
					["release"] = nil,
					["press"] = function() -- name: press
						-- upvalues: (copy) p_u_5
						p_u_5.onHorn(true)
					end,
					["release"] = function() -- name: release
						-- upvalues: (copy) p_u_5
						p_u_5.onHorn(false)
					end
				},
				{
					["id"] = "left",
					["label"] = "\226\151\128",
					["slot"] = "center",
					["press"] = nil,
					["press"] = function() -- name: press
						-- upvalues: (copy) p_u_5
						p_u_5.onIndicator("Left")
					end
				},
				{
					["id"] = "hazard",
					["label"] = "\226\154\160",
					["slot"] = "center",
					["press"] = nil,
					["press"] = function() -- name: press
						-- upvalues: (copy) p_u_5
						p_u_5.onIndicator("Hazard")
					end
				},
				{
					["id"] = "right",
					["label"] = "\226\150\182",
					["slot"] = "center",
					["press"] = nil,
					["press"] = function() -- name: press
						-- upvalues: (copy) p_u_5
						p_u_5.onIndicator("Right")
					end
				},
				{
					["id"] = "lights",
					["label"] = "Headlights",
					["slot"] = "center",
					["press"] = nil,
					["press"] = p_u_5.onLights
				},
				{
					["id"] = "engine",
					["label"] = "Engine",
					["slot"] = "center",
					["press"] = nil,
					["press"] = p_u_5.onEngine
				}
			}
			if p_u_5.onRainbow then
				local v7 = {
					["id"] = "rainbow",
					["label"] = "RGB lights",
					["press"] = nil,
					["press"] = p_u_5.onRainbow
				}
				table.insert(v6, v7)
			end
			if p_u_5.onTune then
				local v8 = {
					["id"] = "tune",
					["label"] = "Tune",
					["press"] = nil,
					["press"] = p_u_5.onTune
				}
				table.insert(v6, v8)
			end
			local v9 = v_u_4
			if p_u_5.gears then
				v9 = table.clone(v_u_4)
				local v10 = { "E / Q", ("Gear up / down (%d-speed)"):format(p_u_5.gears) }
				table.insert(v9, 2, v10)
				local v11 = {
					["id"] = "gearDown",
					["label"] = "Gear -",
					["press"] = nil,
					["press"] = p_u_5.onGearDown
				}
				table.insert(v6, v11)
				local v12 = {
					["id"] = "gearUp",
					["label"] = "Gear +",
					["press"] = nil,
					["press"] = p_u_5.onGearUp
				}
				table.insert(v6, v12)
			end
			v_u_3.show(p_u_5.model, {
				["gear"] = true,
				["lights"] = true,
				["legend"] = nil,
				["controls"] = nil,
				["legend"] = v9,
				["controls"] = v6
			})
		end
	end,
	["update"] = function(p13) -- name: update
		-- upvalues: (copy) v_u_3, (copy) v_u_2
		if v_u_3.isShown() then
			local v14 = (p13.rpm - v_u_2.IDLE_RPM) / (v_u_2.REDLINE_RPM - v_u_2.IDLE_RPM)
			local v15 = math.clamp(v14, 0, 1)
			v_u_3.update({
				["kmh"] = p13.kmh,
				["rpm"] = p13.rpm <= 0 and 0 or v15 * 0.95 + 0.05,
				["gear"] = p13.gear,
				["engine"] = p13.engine == true,
				["lights"] = p13.lights == true,
				["indicator"] = p13.indicator
			})
			v_u_3.setActive("engine", p13.engine == true)
			v_u_3.setActive("left", p13.indicator == "Left")
			v_u_3.setActive("right", p13.indicator == "Right")
			v_u_3.setActive("hazard", p13.indicator == "Hazard")
			v_u_3.setActive("lights", p13.lights == true)
			v_u_3.setActive("view", p13.inside == true)
			v_u_3.setActive("rainbow", p13.rainbow == true)
			v_u_3.setActive("tune", p13.tuning == true)
		end
	end,
	["stop"] = function() -- name: stop
		-- upvalues: (copy) v_u_3
		v_u_3.hide()
	end
}