-- Path: ReplicatedStorage/HelmetShared
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = {
	["REMOTE"] = "Helmet",
	["SHOP_REACH"] = 30,
	["PROMPT"] = "HelmetShop",
	["FULL"] = {
		{
			["name"] = "Helmet1",
			["label"] = "\224\184\165\224\184\178\224\184\162 1"
		},
		{
			["name"] = "Helmet2",
			["label"] = "\224\184\165\224\184\178\224\184\162 2"
		},
		{
			["name"] = "Helmet3",
			["label"] = "\224\184\165\224\184\178\224\184\162 3"
		},
		{
			["name"] = "Helmet4",
			["label"] = "\224\184\165\224\184\178\224\184\162 4"
		}
	},
	["INDEX_SHELLS"] = {
		{
			["key"] = "White",
			["label"] = "\224\184\130\224\184\178\224\184\167",
			["color"] = nil,
			["color"] = Color3.fromRGB(240, 242, 246)
		},
		{
			["key"] = "Black",
			["label"] = "\224\184\148\224\184\179",
			["color"] = nil,
			["color"] = Color3.fromRGB(34, 36, 42)
		},
		{
			["key"] = "Pink",
			["label"] = "\224\184\138\224\184\161\224\184\158\224\184\185",
			["color"] = nil,
			["color"] = Color3.fromRGB(236, 72, 200)
		},
		{
			["key"] = "Green",
			["label"] = "\224\185\128\224\184\130\224\184\181\224\184\162\224\184\167",
			["color"] = nil,
			["color"] = Color3.fromRGB(170, 236, 40)
		}
	},
	["INDEX_VISORS"] = {
		{
			["n"] = 1,
			["label"] = "\224\184\138\224\184\180\224\184\165\224\184\163\224\184\184\224\185\137\224\184\135",
			["colors"] = nil,
			["colors"] = { Color3.fromRGB(255, 120, 220), Color3.fromRGB(80, 230, 140) }
		},
		{
			["n"] = 2,
			["label"] = "\224\184\138\224\184\180\224\184\165\224\184\159\224\185\137\224\184\178",
			["colors"] = nil,
			["colors"] = { Color3.fromRGB(150, 220, 255), Color3.fromRGB(70, 160, 230) }
		},
		{
			["n"] = 3,
			["label"] = "\224\184\138\224\184\180\224\184\165\224\185\131\224\184\170",
			["colors"] = nil,
			["colors"] = { Color3.fromRGB(235, 240, 248), Color3.fromRGB(190, 198, 212) }
		}
	},
	["FULL_VISORS"] = {
		{
			["n"] = 0,
			["label"] = "\224\184\138\224\184\180\224\184\165\224\184\170\224\185\130\224\184\161\224\185\138\224\184\132",
			["colors"] = nil,
			["colors"] = { Color3.fromRGB(120, 124, 136), Color3.fromRGB(36, 38, 46) }
		}
	}
}
for _, v2 in v_u_1.INDEX_VISORS do
	local v3 = v_u_1.FULL_VISORS
	table.insert(v3, v2)
end
function v_u_1.fullName(p4, p5) -- name: fullName
	if p5 and p5 > 0 then
		return ("%sV%d"):format(p4, p5)
	else
		return p4
	end
end
function v_u_1.indexName(p6, p7) -- name: indexName
	return ("Index%s%d"):format(p6, p7)
end
function v_u_1.info(p8) -- name: info
	-- upvalues: (copy) v_u_1
	if type(p8) ~= "string" then
		return nil
	end
	local v9, v10 = p8:match("^(Helmet%d+)V(%d)$")
	local v11 = tonumber(v10) or 0
	local v12 = v9 or p8
	for _, v13 in v_u_1.FULL do
		if v13.name ~= v12 then
			continue
		end
		for _, v14 in v_u_1.FULL_VISORS do
			if v14.n ~= v11 then
				continue
			end
			return {
				["full"] = true,
				["design"] = nil,
				["visor"] = nil,
				["label"] = nil,
				["design"] = v13.name,
				["visor"] = v14.n,
				["label"] = ("\224\185\128\224\184\149\224\185\135\224\184\161\224\185\131\224\184\154 %s \194\183 %s"):format(v13.label, v14.label)
			}
		end
	end
	local v15, v16 = p8:match("^Index(%a+)(%d)$")
	for _, v17 in v_u_1.INDEX_SHELLS do
		for _, v18 in v_u_1.INDEX_VISORS do
			if v17.key ~= v15 or v18.n ~= tonumber(v16) then
				continue
			end
			return {
				["full"] = false,
				["shell"] = nil,
				["visor"] = nil,
				["label"] = nil,
				["shell"] = v15,
				["visor"] = v18.n,
				["label"] = ("INDEX \224\184\132\224\184\163\224\184\182\224\185\136\224\184\135\224\185\131\224\184\154 %s \194\183 %s"):format(v17.label, v18.label)
			}
		end
	end
	return nil
end
return v_u_1