-- Path: ReplicatedStorage/GameUI/Menu
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_2 = {
	["changed"] = Instance.new("BindableEvent"),
	["isOpen"] = false,
	["open"] = function(p1) -- name: open
		-- upvalues: (copy) v_u_2
		v_u_2.changed:Fire("open", p1)
	end,
	["close"] = function() -- name: close
		-- upvalues: (copy) v_u_2
		v_u_2.changed:Fire("close")
	end,
	["toggle"] = function() -- name: toggle
		-- upvalues: (copy) v_u_2
		v_u_2.changed:Fire("toggle")
	end
}
return v_u_2