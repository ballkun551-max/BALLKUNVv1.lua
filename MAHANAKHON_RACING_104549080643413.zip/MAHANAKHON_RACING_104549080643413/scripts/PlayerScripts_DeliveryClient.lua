-- Path: Players/ygggggg55551/PlayerScripts/DeliveryClient
-- Class: LocalScript  true/Enum.RunContext.Legacy
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = game:GetService("Lighting")
local v_u_2 = game:GetService("Players")
local v3 = game:GetService("ReplicatedStorage")
local v4 = game:GetService("RunService")
local v5 = game:GetService("SoundService")
local v_u_6 = game:GetService("TweenService")
local v_u_7 = game:GetService("UserInputService")
local v_u_8 = require(v3:WaitForChild("GameShared"))
local v_u_9 = require(v3:WaitForChild("DeliveryShared"))
local v_u_10 = require(v3:WaitForChild("NetSeal"))
local v11 = v3:WaitForChild("GameUI")
local v_u_12 = require(v11:WaitForChild("Theme"))
local v_u_13 = require(v11:WaitForChild("Icons"))
local v_u_14 = require(v11:WaitForChild("Toast"))
local v_u_15 = require(v11:WaitForChild("Phone"))
local v_u_16 = require(v11:WaitForChild("Dash"))
local v_u_17 = require(v11:WaitForChild("Menu"))
local v18 = require(v11:WaitForChild("ControlLayout"))
local v_u_19 = v_u_2.LocalPlayer
local v_u_20 = v3:WaitForChild(v_u_8.REMOTES):WaitForChild(v_u_9.REMOTE)
local v_u_21 = v_u_12.isTouch()
local v_u_22 = v_u_21 and 176 or 264
local v_u_23 = TweenInfo.new(0.35, Enum.EasingStyle.Quint, Enum.EasingDirection.Out)
local v_u_24 = TweenInfo.new(0.35, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
local v_u_25 = TweenInfo.new(0.3, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
local v_u_26 = TweenInfo.new(0.1)
local v_u_27 = UDim2.fromOffset(0, 900)
local v_u_28 = Color3.new(1, 1, 1)
local v_u_29 = {
	["brand1"] = Color3.fromRGB(255, 146, 0),
	["brand2"] = Color3.fromRGB(255, 70, 90),
	["bg"] = Color3.fromRGB(243, 244, 247),
	["card"] = v_u_28,
	["ink"] = Color3.fromRGB(28, 30, 36),
	["dim"] = Color3.fromRGB(112, 116, 128),
	["line"] = Color3.fromRGB(226, 228, 234),
	["off"] = Color3.fromRGB(206, 209, 216),
	["green1"] = Color3.fromRGB(52, 211, 120),
	["green2"] = Color3.fromRGB(18, 158, 90),
	["red"] = Color3.fromRGB(232, 64, 64),
	["shop"] = Color3.fromRGB(255, 136, 0),
	["home"] = Color3.fromRGB(28, 176, 116),
	["ride"] = Color3.fromRGB(60, 128, 250),
	["parcel"] = Color3.fromRGB(176, 112, 50),
	["yellow"] = Color3.fromRGB(255, 190, 0),
	["wall1"] = Color3.fromRGB(20, 21, 27),
	["wall2"] = Color3.fromRGB(92, 82, 14)
}
local v_u_30 = {
	{
		["id"] = "delivery",
		["name"] = "Rider",
		["icon"] = "scooter",
		["colors"] = nil,
		["colors"] = { v_u_29.brand1, v_u_29.brand2 }
	},
	{
		["id"] = "jobs",
		["name"] = "Jobs",
		["icon"] = "people",
		["colors"] = nil,
		["colors"] = { Color3.fromRGB(96, 136, 255), Color3.fromRGB(116, 62, 224) }
	},
	{
		["id"] = "race",
		["name"] = "Race",
		["icon"] = "trophy",
		["colors"] = nil,
		["colors"] = { Color3.fromRGB(255, 70, 80), Color3.fromRGB(150, 20, 40) }
	},
	{
		["id"] = "shop",
		["name"] = "Shop",
		["icon"] = "store",
		["colors"] = nil,
		["colors"] = { Color3.fromRGB(255, 170, 40), Color3.fromRGB(200, 90, 10) }
	},
	{
		["id"] = "warp",
		["name"] = "Weather",
		["icon"] = "sun",
		["colors"] = nil,
		["colors"] = { Color3.fromRGB(70, 150, 250), Color3.fromRGB(30, 96, 214) }
	},
	{
		["id"] = "garage",
		["name"] = "My Rides",
		["icon"] = "key",
		["colors"] = nil,
		["colors"] = { Color3.fromRGB(40, 204, 182), Color3.fromRGB(12, 138, 126) }
	},
	{
		["id"] = "store",
		["name"] = "Store",
		["icon"] = "bag",
		["colors"] = nil,
		["colors"] = { Color3.fromRGB(255, 192, 56), Color3.fromRGB(238, 124, 14) }
	},
	{
		["id"] = "quests",
		["name"] = "Quests",
		["icon"] = "gift",
		["colors"] = nil,
		["colors"] = { Color3.fromRGB(255, 176, 30), Color3.fromRGB(236, 72, 120) }
	},
	{
		["id"] = "map",
		["name"] = "Map",
		["icon"] = "pin",
		["colors"] = nil,
		["colors"] = { Color3.fromRGB(32, 196, 168), Color3.fromRGB(24, 112, 226) }
	}
}
local v_u_31 = Instance.new("Sound")
v_u_31.Name = "DeliveryPing"
v_u_31.SoundId = "rbxasset://sounds/electronicpingshort.wav"
v_u_31.Volume = 0.6
v_u_31.Parent = v5
local v32 = false
local v_u_33 = "Off"
local v_u_34 = nil
local v35 = false
local function v_u_43() -- name: distanceLeft
	-- upvalues: (copy) v_u_15, (copy) v_u_9, (ref) v_u_33, (ref) v_u_34, (copy) v_u_19
	if v_u_15.routeLength then
		return v_u_15.routeLength
	end
	local v36 = v_u_9.target(v_u_33, v_u_34)
	local v37 = v_u_19.Character
	if v37 then
		v37 = v_u_19.Character:FindFirstChild("HumanoidRootPart")
	end
	if not (v36 and v37) then
		return 0
	end
	local v38 = v36.X
	local v39 = v36.Z
	local v40 = Vector3.new(v38, 0, v39)
	local v41 = v37.Position.X
	local v42 = v37.Position.Z
	return (v40 - Vector3.new(v41, 0, v42)).Magnitude
end
local function v_u_61(p44, p45, p46, p47, p48, p49, p50, p51, p52, p53) -- name: label
	-- upvalues: (copy) v_u_12, (copy) v_u_29
	local v54 = v_u_12.text
	local v55 = {
		["Text"] = p45
	}
	local v56
	if p52 then
		v56 = v_u_12.FONT_BOLD
	else
		v56 = v_u_12.FONT
	end
	v55.FontFace = v56
	v55.TextSize = p50 or 15
	v55.TextColor3 = p51 or v_u_29.ink
	v55.TextXAlignment = Enum.TextXAlignment.Left
	v55.TextTruncate = Enum.TextTruncate.AtEnd
	v55.Position = UDim2.new(0, p46, 0, p47)
	local v57
	if p48 then
		v57 = UDim2.new(0, p48, 0, p49 or (p50 or 15) + 6)
	else
		v57 = UDim2.new(1, -p46, 0, p49 or (p50 or 15) + 6)
	end
	v55.Size = v57
	v55.Parent = p44
	local v58 = v54(v55)
	for v59, v60 in p53 or {} do
		v58[v59] = v60
	end
	return v58
end
local function v_u_70(p62, p63, p64, p65, p66, p67) -- name: iconIn
	-- upvalues: (copy) v_u_13
	local v68 = v_u_13.make(p63, p64, p65)
	v68.AnchorPoint = Vector2.new(0.5, 0.5)
	local v69
	if p66 then
		v69 = UDim2.fromOffset(p66, p67)
	else
		v69 = UDim2.fromScale(0.5, 0.5)
	end
	v68.Position = v69
	v68.Parent = p62
	return v68
end
local v_u_71 = Color3.fromRGB(246, 236, 110)
local v_u_72 = Color3.fromRGB(255, 150, 30)
local function v_u_77(p73, p_u_74, p_u_75) -- name: pressable
	-- upvalues: (copy) v_u_6, (copy) v_u_26
	p73.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_6, (copy) p_u_74, (ref) v_u_26, (copy) p_u_75
		v_u_6:Create(p_u_74, v_u_26, {
			["Scale"] = p_u_75 or 0.95
		}):Play()
	end)
	for _, v76 in { p73.MouseButton1Up, p73.MouseLeave } do
		v76:Connect(function()
			-- upvalues: (ref) v_u_6, (copy) p_u_74, (ref) v_u_26
			v_u_6:Create(p_u_74, v_u_26, {
				["Scale"] = 1
			}):Play()
		end)
	end
end
local v_u_78 = v_u_12.screen("Phone", 12, v_u_19:WaitForChild("PlayerGui"))
local v79 = {
	["Name"] = "Dock",
	["BackgroundTransparency"] = 1,
	["AnchorPoint"] = nil,
	["Size"] = nil,
	["Visible"] = false,
	["Parent"] = nil,
	["AnchorPoint"] = Vector2.new(1, 1),
	["Size"] = UDim2.fromOffset(300, 580),
	["Parent"] = v_u_78
}
local v_u_80 = v_u_12.new("Frame", v79)
local v_u_81 = v_u_12.new("UIScale", {
	["Parent"] = v_u_80
})
local v82 = {
	["Name"] = "Phone",
	["BackgroundColor3"] = nil,
	["BorderSizePixel"] = 0,
	["Size"] = nil,
	["Parent"] = nil,
	["BackgroundColor3"] = Color3.fromRGB(12, 12, 15),
	["Size"] = UDim2.fromScale(1, 1),
	["Parent"] = v_u_80
}
local v83 = v_u_12.new("Frame", v82)
v_u_12.corner(v83, 38)
local v84 = {
	["ApplyStrokeMode"] = nil,
	["Color"] = nil,
	["Thickness"] = 3,
	["Parent"] = nil,
	["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
	["Color"] = v_u_28,
	["Parent"] = v83
}
local v85 = v_u_12.new("UIStroke", v84)
local v86 = {
	["Color"] = nil,
	["Rotation"] = 60,
	["Parent"] = nil,
	["Color"] = ColorSequence.new({
		ColorSequenceKeypoint.new(0, v_u_71),
		ColorSequenceKeypoint.new(0.35, Color3.fromRGB(140, 110, 18)),
		ColorSequenceKeypoint.new(0.65, v_u_72),
		ColorSequenceKeypoint.new(1, v_u_71)
	}),
	["Parent"] = v85
}
v_u_12.new("UIGradient", v86)
local v_u_87 = v32
local v_u_88 = v_u_33
local v_u_89 = v_u_34
local v_u_90 = v35
local function v102(p91, p92, p93) -- name: glass
	-- upvalues: (copy) v_u_12, (copy) v_u_28, (copy) v_u_71, (copy) v_u_72
	local v94 = {
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.38,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = Color3.fromRGB(8, 8, 12),
		["Position"] = UDim2.fromOffset(14, p92),
		["Size"] = UDim2.new(1, -28, 0, p93),
		["Parent"] = p91
	}
	local v95 = v_u_12.new("Frame", v94)
	v_u_12.corner(v95, 20)
	local v96 = {
		["ApplyStrokeMode"] = nil,
		["Color"] = nil,
		["Thickness"] = 1.5,
		["Parent"] = nil,
		["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
		["Color"] = v_u_28,
		["Parent"] = v95
	}
	local v97 = v_u_12.new("UIStroke", v96)
	local v98 = {
		["Color"] = nil,
		["Transparency"] = nil,
		["Rotation"] = 20,
		["Parent"] = nil,
		["Color"] = ColorSequence.new(v_u_71, v_u_72),
		["Transparency"] = NumberSequence.new(0.1, 0.7),
		["Parent"] = v97
	}
	v_u_12.new("UIGradient", v98)
	local v99 = {
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_28,
		["Size"] = UDim2.fromScale(1, 0.55),
		["Parent"] = v95
	}
	local v100 = v_u_12.new("Frame", v99)
	v_u_12.corner(v100, 20)
	local v101 = {
		["Transparency"] = nil,
		["Rotation"] = 90,
		["Parent"] = nil,
		["Transparency"] = NumberSequence.new(0.86, 1),
		["Parent"] = v100
	}
	v_u_12.new("UIGradient", v101)
	return v95
end
local function v_u_117(p103, p104, p105, p106, p107, p108) -- name: badge
	-- upvalues: (copy) v_u_28, (copy) v_u_12, (copy) v_u_70
	local v109 = {
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_28,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromOffset(p107, p108),
		["Size"] = UDim2.fromOffset(p106, p106),
		["Parent"] = p103
	}
	local v110 = v_u_12.new("Frame", v109)
	v_u_12.corner(v110, p106 / 2)
	local v111 = p105:Lerp(v_u_28, 0.15)
	local v112 = p105:Lerp(Color3.new(0, 0, 0), 0.12)
	local v113 = {
		["Color"] = nil,
		["Rotation"] = 135,
		["Parent"] = nil,
		["Color"] = ColorSequence.new(v111, v112),
		["Parent"] = v110
	}
	v_u_12.new("UIGradient", v113)
	local v114 = v_u_70
	local v115 = v_u_28
	local v116 = p106 * 0.6
	v114(v110, p104, v115, (math.floor(v116)))
	return v110
end
local function v_u_129(p118, p119, p120, p121, p122) -- name: card
	-- upvalues: (copy) v_u_12, (copy) v_u_29
	local v123 = {
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.92,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = Color3.new(0, 0, 0),
		["Position"] = UDim2.new(0, p121 or 0, 0, p119 + 3)
	}
	local v124
	if p122 then
		v124 = UDim2.fromOffset(p122, p120)
	else
		v124 = UDim2.new(1, -(p121 or 0) * 2, 0, p120)
	end
	v123.Size = v124
	v123.Parent = p118
	local v125 = v_u_12.new("Frame", v123)
	v_u_12.corner(v125, 14)
	local v126 = {
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_29.card,
		["Position"] = UDim2.new(0, p121 or 0, 0, p119)
	}
	local v127
	if p122 then
		v127 = UDim2.fromOffset(p122, p120)
	else
		v127 = UDim2.new(1, -(p121 or 0) * 2, 0, p120)
	end
	v126.Size = v127
	v126.Parent = p118
	local v128 = v_u_12.new("Frame", v126)
	v_u_12.corner(v128, 14)
	return v128
end
local function v132(p130, p131) -- name: new
	-- upvalues: (copy) v_u_12
	return v_u_12.new(p130, p131)
end
local function v_u_149(p133, p134, p135, p136, p137, p138) -- name: button
	-- upvalues: (copy) v_u_12, (copy) v_u_28, (copy) v_u_29, (copy) v_u_61, (copy) v_u_77
	local v139 = {
		["Text"] = "",
		["AutoButtonColor"] = false,
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 1),
		["Position"] = UDim2.new(0.5, 0, 1, -p135),
		["Size"] = UDim2.new(1, -28, 0, p136),
		["Parent"] = p133
	}
	local v140 = v_u_12.new("TextButton", v139)
	local v141 = {
		["Name"] = "Fill",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_28,
		["Size"] = UDim2.fromScale(1, 1),
		["Parent"] = v140
	}
	local v142 = v_u_12.new("Frame", v141)
	v_u_12.corner(v142, p136 / 2)
	if p137 then
		local v143 = p137[1]
		local v144 = p137[2]
		local v145 = {
			["Color"] = nil,
			["Rotation"] = 0,
			["Parent"] = nil,
			["Color"] = ColorSequence.new(v143, v144),
			["Parent"] = v142
		}
		v_u_12.new("UIGradient", v145)
	else
		local v146 = {
			["ApplyStrokeMode"] = nil,
			["Color"] = nil,
			["Thickness"] = 1.5,
			["Parent"] = nil,
			["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
			["Color"] = v_u_29.line,
			["Parent"] = v142
		}
		v_u_12.new("UIStroke", v146)
	end
	local v147 = v_u_61(v140, p134, 0, 0, nil, p136, 17, p138 or v_u_28, true, {
		["Name"] = "Caption",
		["TextXAlignment"] = nil,
		["Size"] = nil,
		["ZIndex"] = 2,
		["TextXAlignment"] = Enum.TextXAlignment.Center,
		["Size"] = UDim2.fromScale(1, 1)
	})
	local v148 = v_u_12.new("UIScale", {
		["Parent"] = v140
	})
	v_u_77(v140, v148)
	return v140, v148, v147
end
for _, v150 in {
	{ 1, 120, 52 },
	{ 0, 104, 34 },
	{ 0, 146, 34 }
} do
	local v151 = {
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 0,
		["Parent"] = nil,
		["BackgroundColor3"] = Color3.fromRGB(200, 168, 40),
		["AnchorPoint"] = Vector2.new(0.5, 0),
		["Position"] = UDim2.new(v150[1], v150[1] == 1 and 1 or -1, 0, v150[2]),
		["Size"] = UDim2.fromOffset(4, v150[3]),
		["Parent"] = v_u_80
	}
	local v152 = v_u_12.new("Frame", v151)
	v_u_12.corner(v152, 2)
end
local v153 = {
	["BackgroundColor3"] = nil,
	["BackgroundTransparency"] = 0.7,
	["BorderSizePixel"] = 0,
	["Position"] = nil,
	["Size"] = nil,
	["ZIndex"] = 0,
	["Parent"] = nil,
	["BackgroundColor3"] = Color3.new(0, 0, 0),
	["Position"] = UDim2.fromOffset(-6, 8),
	["Size"] = UDim2.fromScale(1, 1),
	["Parent"] = v_u_80
}
local v154 = v_u_12.new("Frame", v153)
v_u_12.corner(v154, 38)
local v155 = {
	["Name"] = "Screen",
	["BackgroundColor3"] = nil,
	["BorderSizePixel"] = 0,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["BackgroundColor3"] = v_u_29.bg,
	["Position"] = UDim2.fromOffset(9, 9),
	["Size"] = UDim2.new(1, -18, 1, -18),
	["Parent"] = v83
}
local v156 = v_u_12.new("CanvasGroup", v155)
v_u_12.corner(v156, 30)
local v157 = {
	["Name"] = "Close",
	["Text"] = "",
	["AutoButtonColor"] = false,
	["BackgroundColor3"] = nil,
	["BorderSizePixel"] = 0,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["ZIndex"] = 3,
	["Parent"] = nil,
	["BackgroundColor3"] = Color3.fromRGB(28, 30, 36),
	["AnchorPoint"] = Vector2.new(0.5, 0.5),
	["Position"] = UDim2.fromOffset(8, 8),
	["Size"] = UDim2.fromOffset(30, 30),
	["Parent"] = v_u_80
}
local v158 = v_u_12.new("TextButton", v157)
v_u_12.corner(v158, 15)
local v159 = {
	["ApplyStrokeMode"] = nil,
	["Color"] = nil,
	["Transparency"] = 0.25,
	["Thickness"] = 1.5,
	["Parent"] = nil,
	["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
	["Color"] = v_u_71,
	["Parent"] = v158
}
v_u_12.new("UIStroke", v159)
v_u_70(v158, "close", v_u_28, 14)
local v160 = {
	["Name"] = "Home",
	["BackgroundColor3"] = nil,
	["BorderSizePixel"] = 0,
	["Size"] = nil,
	["Parent"] = nil,
	["BackgroundColor3"] = v_u_28,
	["Size"] = UDim2.fromScale(1, 1),
	["Parent"] = v156
}
local v_u_161 = v_u_12.new("Frame", v160)
local v162 = {
	["Color"] = nil,
	["Rotation"] = 115,
	["Parent"] = nil,
	["Color"] = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(10, 10, 14)), ColorSequenceKeypoint.new(0.55, Color3.fromRGB(30, 26, 12)), ColorSequenceKeypoint.new(1, Color3.fromRGB(112, 86, 8)) }),
	["Parent"] = v_u_161
}
v_u_12.new("UIGradient", v162)
for _, v163 in {
	{
		0.5,
		0.21,
		2,
		0.35
	},
	{
		0.62,
		0.35,
		4,
		0.55
	},
	{
		0.42,
		0.88,
		3,
		0.45
	}
} do
	local v164 = {
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Rotation"] = -24,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_71,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(v163[1], v163[2]),
		["Size"] = UDim2.fromOffset(420, v163[3]),
		["Parent"] = v_u_161
	}
	local v165 = v_u_12.new("Frame", v164)
	local v166 = {
		["Transparency"] = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(0.5, v163[4]), NumberSequenceKeypoint.new(1, 1) }),
		["Parent"] = v165
	}
	v_u_12.new("UIGradient", v166)
end
v_u_12.text({
	["Name"] = "Mark",
	["Text"] = "MHNK",
	["FontFace"] = nil,
	["TextSize"] = 120,
	["TextColor3"] = nil,
	["TextTransparency"] = 0.93,
	["Rotation"] = -90,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["FontFace"] = v_u_12.FONT_HEAVY,
	["TextColor3"] = v_u_28,
	["AnchorPoint"] = Vector2.new(0.5, 0.5),
	["Position"] = UDim2.new(1, -16, 0.52, 0),
	["Size"] = UDim2.fromOffset(393, 120),
	["Parent"] = v_u_161
})
for _, v167 in {
	{
		0.08,
		0.16,
		250,
		Color3.fromRGB(232, 220, 56),
		0.8
	},
	{
		1,
		0.62,
		280,
		Color3.fromRGB(255, 128, 20),
		0.78
	},
	{
		0.2,
		1,
		230,
		Color3.fromRGB(255, 60, 70),
		0.84
	}
} do
	local v168 = {
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = v167[4],
		["BackgroundTransparency"] = v167[5],
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(v167[1], v167[2]),
		["Size"] = UDim2.fromOffset(v167[3], v167[3]),
		["Parent"] = v_u_161
	}
	local v169 = v_u_12.new("Frame", v168)
	v_u_12.corner(v169, v167[3] / 2)
end
local v_u_170 = v_u_61(v_u_161, "12:00", 0, 38, nil, 64, 60, v_u_28, true, nil)
v_u_170.TextXAlignment = Enum.TextXAlignment.Center
v_u_170.Size = UDim2.new(1, 0, 0, 64)
v_u_170.FontFace = v_u_12.FONT_HEAVY
local v171 = {
	["Color"] = nil,
	["Rotation"] = 90,
	["Parent"] = nil,
	["Color"] = ColorSequence.new(v_u_28, v_u_71),
	["Parent"] = v_u_170
}
v_u_12.new("UIGradient", v171)
local v_u_172 = v_u_61(v_u_161, "", 0, 98, nil, 20, 14, v_u_28, false, {
	["TextTransparency"] = 0.1
})
v_u_172.TextXAlignment = Enum.TextXAlignment.Center
v_u_172.Size = UDim2.new(1, 0, 0, 20)
local v173 = v102(v_u_161, 126, 104)
v_u_117(v173, "scooter", v_u_29.brand1, 44, 36, 38)
local v174 = v_u_61(v173, v_u_9.APP_NAME, 68, 14, nil, 22, 16, v_u_28, true)
local v_u_175 = v_u_61(v173, "", 68, 37, nil, 20, 14, v_u_28, false, {
	["Size"] = UDim2.new(1, -80, 0, 20)
})
local v_u_176 = v_u_61(v173, "", 16, 72, nil, 20, 13, v_u_28, false, {
	["TextTransparency"] = 0.2,
	["Size"] = nil,
	["Size"] = UDim2.new(1, -32, 0, 20)
})
local v177 = {
	["Text"] = "",
	["BackgroundTransparency"] = 1,
	["Size"] = nil,
	["ZIndex"] = 5,
	["Parent"] = nil,
	["Size"] = UDim2.fromScale(1, 1),
	["Parent"] = v173
}
local v178 = v_u_12.new("TextButton", v177)
local v179 = v102(v_u_161, 238, 70)
v_u_117(v179, "money", v_u_29.green2, 40, 34, 35)
local v180 = v_u_61(v179, "Wallet", 64, 12, nil, 18, 13, v_u_28, false, {
	["TextTransparency"] = 0.15
})
local v_u_181 = v_u_61(v179, "", 64, 30, nil, 30, 24, v_u_28, true)
local v182 = {
	["Color"] = nil,
	["Rotation"] = 90,
	["Parent"] = nil,
	["Color"] = ColorSequence.new(Color3.fromRGB(255, 242, 150), v_u_72),
	["Parent"] = v_u_181
}
v_u_12.new("UIGradient", v182)
local v183 = #v_u_30 / 4
local v184 = math.ceil(v183)
local v185 = {
	["Name"] = "AppPlate",
	["BackgroundColor3"] = nil,
	["BackgroundTransparency"] = 0.5,
	["BorderSizePixel"] = 0,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["BackgroundColor3"] = Color3.fromRGB(8, 8, 12),
	["Position"] = UDim2.fromOffset(8, 314),
	["Size"] = UDim2.new(1, -16, 0, v184 * (#v_u_30 > 8 and 72 or 96) + 14),
	["Parent"] = v_u_161
}
local v186 = v_u_12.new("Frame", v185)
v_u_12.corner(v186, 24)
local v187 = {
	["ApplyStrokeMode"] = nil,
	["Color"] = nil,
	["Transparency"] = 0.7,
	["Thickness"] = 1,
	["Parent"] = nil,
	["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
	["Color"] = v_u_71,
	["Parent"] = v186
}
v_u_12.new("UIStroke", v187)
local v188 = {
	["Name"] = "Apps",
	["BackgroundTransparency"] = 1,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["Position"] = UDim2.fromOffset(14, 322),
	["Size"] = UDim2.new(1, -28, 0, 210),
	["Parent"] = v_u_161
}
local v_u_189 = v_u_12.new("Frame", v188)
local v190 = #v_u_30 > 8 and 52 or 58
local v191 = #v_u_30 > 8 and 72 or 96
local v192 = #v_u_30 > 8 and 2 or 5
local v193 = #v_u_30 > 8 and 16 or 18
local v194 = #v_u_30 > 8 and 11 or 12
local v_u_195 = {}
local v196 = {}
local v_u_197 = nil
local v_u_198 = nil
local v_u_199 = nil
for v200, v201 in v_u_30 do
	local v202 = (v200 - 1) % 4
	local v203 = (v200 - 1) // 4
	local v204 = 63.5 * (v202 + 0.5)
	local v205 = v203 * v191 + 4
	local v206 = {
		["Name"] = nil,
		["Text"] = "",
		["AutoButtonColor"] = false,
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Name"] = v201.id,
		["BackgroundColor3"] = v_u_28,
		["AnchorPoint"] = Vector2.new(0.5, 0),
		["Position"] = UDim2.fromOffset(v204, v205),
		["Size"] = UDim2.fromOffset(v190, v190),
		["Parent"] = v_u_189
	}
	local v207 = v_u_12.new("TextButton", v206)
	local v208 = v_u_12.corner
	local v209 = v190 * 0.28
	v208(v207, (math.floor(v209)))
	local v210 = v201.colors[1]:Lerp(v_u_28, 0.12)
	local v211 = v201.colors[2]
	local v212 = {
		["Color"] = nil,
		["Rotation"] = 120,
		["Parent"] = nil,
		["Color"] = ColorSequence.new(v210, v211),
		["Parent"] = v207
	}
	v_u_12.new("UIGradient", v212)
	local v213 = {
		["ApplyStrokeMode"] = nil,
		["Color"] = nil,
		["Transparency"] = 0.55,
		["Thickness"] = 1.2,
		["Parent"] = nil,
		["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
		["Color"] = v_u_28,
		["Parent"] = v207
	}
	v_u_12.new("UIStroke", v213)
	local v214 = {
		["Name"] = nil,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.7,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 0,
		["Parent"] = nil,
		["Name"] = v201.id .. "Glow",
		["BackgroundColor3"] = v201.colors[1],
		["AnchorPoint"] = Vector2.new(0.5, 0),
		["Position"] = UDim2.fromOffset(v204, v205 + 5),
		["Size"] = UDim2.fromOffset(v190 + 6, v190 + 2),
		["Parent"] = v_u_189
	}
	local v215 = v_u_12.new("Frame", v214)
	local v216 = v_u_12.corner
	local v217 = v190 * 0.32
	v216(v215, (math.floor(v217)))
	local v218 = {
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_28,
		["Size"] = UDim2.fromScale(1, 0.5),
		["Parent"] = v207
	}
	local v219 = v_u_12.new("Frame", v218)
	local v220 = v_u_12.corner
	local v221 = v190 * 0.28
	v220(v219, (math.floor(v221)))
	local v222 = {
		["Transparency"] = nil,
		["Rotation"] = 90,
		["Parent"] = nil,
		["Transparency"] = NumberSequence.new(0.6, 1),
		["Parent"] = v219
	}
	v_u_12.new("UIGradient", v222)
	local v223 = v201.icon
	local v224 = v190 * 0.55
	v_u_70(v207, v223, v_u_28, (math.floor(v224)))
	v_u_77(v207, v_u_12.new("UIScale", {
		["Parent"] = v207
	}), 0.88)
	v196[v201.id] = v_u_61(v_u_189, v201.name, v204 - 31.75, v205 + v190 + v192, 63.5, v193, v194, v_u_28, true, {
		["TextXAlignment"] = nil,
		["TextStrokeTransparency"] = 0.55,
		["TextStrokeColor3"] = nil,
		["TextXAlignment"] = Enum.TextXAlignment.Center,
		["TextStrokeColor3"] = Color3.new(0, 0, 0)
	})
	v_u_195[v201.id] = v207
	if v201.id == "delivery" then
		local v225 = {
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Visible"] = false,
			["ZIndex"] = 3,
			["Parent"] = nil,
			["BackgroundColor3"] = v_u_29.red,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.new(1, -4, 0, 4),
			["Size"] = UDim2.fromOffset(22, 22),
			["Parent"] = v207
		}
		v_u_197 = v_u_12.new("Frame", v225)
		v_u_12.corner(v_u_197, 11)
		v_u_12.new("UIStroke", {
			["Color"] = nil,
			["Thickness"] = 2,
			["Parent"] = nil,
			["Color"] = v_u_28,
			["Parent"] = v_u_197
		})
		local v226 = v_u_61(v_u_197, "1", 0, 0, nil, 22, 12, v_u_28, true, nil)
		v226.TextXAlignment = Enum.TextXAlignment.Center
		v226.Size = UDim2.new(1, 0, 0, 22)
	else
		if v201.id ~= "quests" then
			continue
		end
		local v227 = {
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Visible"] = false,
			["ZIndex"] = 3,
			["Parent"] = nil,
			["BackgroundColor3"] = v_u_29.red,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.new(1, -4, 0, 4),
			["Size"] = UDim2.fromOffset(22, 22),
			["Parent"] = v207
		}
		v_u_199 = v_u_12.new("Frame", v227)
		v_u_12.corner(v_u_199, 11)
		v_u_12.new("UIStroke", {
			["Color"] = nil,
			["Thickness"] = 2,
			["Parent"] = nil,
			["Color"] = v_u_28,
			["Parent"] = v_u_199
		})
		v_u_198 = v_u_61(v_u_199, "", 0, 0, nil, 22, 12, v_u_28, true, nil)
		v_u_198.TextXAlignment = Enum.TextXAlignment.Center
		v_u_198.Size = UDim2.new(1, 0, 0, 22)
	end
end
local v228 = {
	["Name"] = "StatusBar",
	["BackgroundTransparency"] = 1,
	["Size"] = nil,
	["ZIndex"] = 10,
	["Parent"] = nil,
	["Size"] = UDim2.new(1, 0, 0, 32),
	["Parent"] = v156
}
local v229 = v_u_12.new("Frame", v228)
local v_u_230 = v_u_61(v229, "12:00", 22, 8, 60, 18, 14, v_u_28, true)
local v231 = {
	["BackgroundColor3"] = nil,
	["BorderSizePixel"] = 0,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["BackgroundColor3"] = Color3.fromRGB(16, 16, 18),
	["AnchorPoint"] = Vector2.new(0.5, 0),
	["Position"] = UDim2.new(0.5, 0, 0, 7),
	["Size"] = UDim2.fromOffset(78, 20),
	["Parent"] = v229
}
local v232 = v_u_12.new("Frame", v231)
v_u_12.corner(v232, 10)
local v233 = {
	["BackgroundColor3"] = nil,
	["BorderSizePixel"] = 0,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["BackgroundColor3"] = Color3.fromRGB(36, 40, 66),
	["AnchorPoint"] = Vector2.new(0.5, 0.5),
	["Position"] = UDim2.new(1, -12, 0.5, 0),
	["Size"] = UDim2.fromOffset(8, 8),
	["Parent"] = v232
}
local v234 = v_u_12.new("Frame", v233)
v_u_12.corner(v234, 4)
for v235 = 1, 4 do
	local v236 = {
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_28,
		["AnchorPoint"] = Vector2.new(0, 1),
		["Position"] = UDim2.new(1, -72 + v235 * 5, 0, 22),
		["Size"] = UDim2.fromOffset(3, v235 * 2.5 + 3),
		["Parent"] = v229
	}
	local v237 = v_u_12.new("Frame", v236)
	v_u_12.corner(v237, 1)
end
local v238 = {
	["BackgroundTransparency"] = 1,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["Position"] = UDim2.new(1, -44, 0, 11),
	["Size"] = UDim2.fromOffset(24, 11),
	["Parent"] = v229
}
local v239 = v_u_12.new("Frame", v238)
v_u_12.corner(v239, 3)
local v240 = {
	["ApplyStrokeMode"] = nil,
	["Color"] = nil,
	["Thickness"] = 1.5,
	["Parent"] = nil,
	["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
	["Color"] = v_u_28,
	["Parent"] = v239
}
v_u_12.new("UIStroke", v240)
local v241 = {
	["BackgroundColor3"] = nil,
	["BorderSizePixel"] = 0,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["BackgroundColor3"] = v_u_28,
	["Position"] = UDim2.fromOffset(2, 2),
	["Size"] = UDim2.new(0.8, -2, 1, -4),
	["Parent"] = v239
}
local v242 = v_u_12.new("Frame", v241)
v_u_12.corner(v242, 2)
local v243 = {
	["Name"] = "HomeBar",
	["Text"] = "",
	["AutoButtonColor"] = false,
	["BackgroundTransparency"] = 1,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["ZIndex"] = 10,
	["Parent"] = nil,
	["AnchorPoint"] = Vector2.new(0.5, 1),
	["Position"] = UDim2.fromScale(0.5, 1),
	["Size"] = UDim2.fromOffset(140, 22),
	["Parent"] = v156
}
local v244 = v_u_12.new("TextButton", v243)
local v245 = {
	["BackgroundColor3"] = nil,
	["BackgroundTransparency"] = 0.3,
	["BorderSizePixel"] = 0,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["BackgroundColor3"] = v_u_28,
	["AnchorPoint"] = Vector2.new(0.5, 1),
	["Position"] = UDim2.new(0.5, 0, 1, -6),
	["Size"] = UDim2.fromOffset(96, 4),
	["Parent"] = v244
}
local v_u_246 = v_u_12.new("Frame", v245)
v_u_12.corner(v_u_246, 2)
local v247 = {
	["Name"] = "App",
	["BackgroundColor3"] = nil,
	["BorderSizePixel"] = 0,
	["Size"] = nil,
	["Visible"] = false,
	["Parent"] = nil,
	["BackgroundColor3"] = v_u_29.bg,
	["Size"] = UDim2.fromScale(1, 1),
	["Parent"] = v156
}
local v_u_248 = v_u_12.new("Frame", v247)
local v_u_249 = v_u_12.new("UIScale", {
	["Parent"] = v_u_248
})
local v250 = {
	["Name"] = "Header",
	["BackgroundColor3"] = nil,
	["BorderSizePixel"] = 0,
	["Size"] = nil,
	["Parent"] = nil,
	["BackgroundColor3"] = v_u_28,
	["Size"] = UDim2.new(1, 0, 0, 92),
	["Parent"] = v_u_248
}
local v251 = v_u_12.new("Frame", v250)
local v252 = v_u_29.brand1
local v253 = v_u_29.brand2
local v254 = {
	["Color"] = nil,
	["Rotation"] = 25,
	["Parent"] = nil,
	["Color"] = ColorSequence.new(v252, v253),
	["Parent"] = v251
}
v_u_12.new("UIGradient", v254)
local v255 = {
	["Name"] = "Back",
	["Text"] = "",
	["BackgroundTransparency"] = 1,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["Position"] = UDim2.fromOffset(4, 42),
	["Size"] = UDim2.fromOffset(30, 44),
	["Parent"] = v251
}
local v256 = v_u_12.new("TextButton", v255)
v_u_70(v256, "arrow", v_u_28, 20)
local v257 = {
	["BackgroundColor3"] = nil,
	["BorderSizePixel"] = 0,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["BackgroundColor3"] = v_u_28,
	["Position"] = UDim2.fromOffset(36, 40),
	["Size"] = UDim2.fromOffset(44, 44),
	["Parent"] = v251
}
local v258 = v_u_12.new("Frame", v257)
v_u_12.corner(v258, 13)
v_u_70(v258, "scooter", v_u_29.brand1, 30)
local v259 = v_u_61(v251, v_u_9.APP_NAME, 90, 42, 180, 24, 20, v_u_28, true)
local v_u_260 = v_u_61(v251, "", 90, 66, 180, 18, 13, v_u_28, false, {
	["TextTransparency"] = 0.1
})
local v_u_261 = v_u_61(v251, "", 16, 94, 250, 18, 13, v_u_28, true, {
	["TextTransparency"] = 0.05
})
local v262 = {
	["Name"] = "View",
	["BackgroundTransparency"] = 1,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["Position"] = UDim2.fromOffset(0, 92),
	["Size"] = UDim2.new(1, 0, 1, -158),
	["Parent"] = v_u_248
}
local v_u_263 = v_u_12.new("Frame", v262)
v_u_261.Visible = false
local v_u_264 = UDim2.new(0.5, 0, 0, 40)
local v_u_265 = UDim2.new(0.5, 0, 0, -130)
local v266 = {
	["Name"] = "CancelAlert",
	["BackgroundColor3"] = nil,
	["BorderSizePixel"] = 0,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Visible"] = false,
	["ZIndex"] = 11,
	["Parent"] = nil,
	["BackgroundColor3"] = v_u_28,
	["AnchorPoint"] = Vector2.new(0.5, 0),
	["Position"] = v_u_265,
	["Size"] = UDim2.new(1, -20, 0, 108),
	["Parent"] = v156
}
local v_u_267 = v_u_12.new("Frame", v266)
v_u_12.corner(v_u_267, 18)
local v268 = {
	["ApplyStrokeMode"] = nil,
	["Color"] = nil,
	["Transparency"] = 0.3,
	["Thickness"] = 2,
	["Parent"] = nil,
	["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
	["Color"] = v_u_29.red,
	["Parent"] = v_u_267
}
v_u_12.new("UIStroke", v268)
local v269 = {
	["Parent"] = v_u_117(v_u_267, "close", v_u_29.red, 40, 32, 34)
}
local v_u_270 = v_u_12.new("UIScale", v269)
local v_u_271 = v_u_61(v_u_267, "\224\184\132\224\184\184\224\184\147\224\185\132\224\184\148\224\185\137\224\184\162\224\184\129\224\185\128\224\184\165\224\184\180\224\184\129\224\184\135\224\184\178\224\184\153", 62, 13, nil, 22, 17, v_u_29.red, true, {
	["Size"] = UDim2.new(1, -72, 0, 22)
})
local v_u_272 = v_u_61(v_u_267, "", 62, 37, nil, 18, 14, v_u_29.ink, true, {
	["Size"] = UDim2.new(1, -72, 0, 18)
})
local v_u_273 = v_u_61(v_u_267, "", 14, 62, nil, 16, 12, v_u_29.dim, false, {
	["Size"] = UDim2.new(1, -28, 0, 16)
})
local v274 = {
	["BackgroundColor3"] = nil,
	["BorderSizePixel"] = 0,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["BackgroundColor3"] = v_u_29.line,
	["Position"] = UDim2.new(0, 14, 1, -18),
	["Size"] = UDim2.new(1, -28, 0, 6),
	["Parent"] = v_u_267
}
local v275 = v_u_12.new("Frame", v274)
v_u_12.corner(v275, 3)
local v276 = {
	["BackgroundColor3"] = nil,
	["BorderSizePixel"] = 0,
	["Size"] = nil,
	["Parent"] = nil,
	["BackgroundColor3"] = v_u_29.red,
	["Size"] = UDim2.fromScale(1, 1),
	["Parent"] = v275
}
local v_u_277 = v_u_12.new("Frame", v276)
v_u_12.corner(v_u_277, 3)
local v278 = {
	{
		["id"] = "home",
		["label"] = "Home",
		["icon"] = "home"
	},
	{
		["id"] = "jobs",
		["label"] = "Jobs",
		["icon"] = "scooter"
	},
	{
		["id"] = "reviews",
		["label"] = "Reviews",
		["icon"] = "star"
	},
	{
		["id"] = "stats",
		["label"] = "Stats",
		["icon"] = "gauge"
	}
}
local v279 = {
	["Name"] = "Tabs",
	["BackgroundColor3"] = nil,
	["BorderSizePixel"] = 0,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["BackgroundColor3"] = v_u_28,
	["AnchorPoint"] = Vector2.new(0.5, 1),
	["Position"] = UDim2.new(0.5, 0, 1, -14),
	["Size"] = UDim2.new(1, -20, 0, 52),
	["Parent"] = v_u_248
}
local v280 = v_u_12.new("Frame", v279)
v_u_12.corner(v280, 16)
local v281 = {
	["ApplyStrokeMode"] = nil,
	["Color"] = nil,
	["Thickness"] = 1,
	["Parent"] = nil,
	["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
	["Color"] = Color3.fromRGB(226, 228, 234),
	["Parent"] = v280
}
v_u_12.new("UIStroke", v281)
local v_u_282 = nil
local v_u_283 = {}
local v_u_284 = "home"
local v_u_285 = {
	{ 0, "Rookie Rider" },
	{ 20, "Silver Rider" },
	{ 50, "Gold Rider" },
	{ 100, "Platinum Rider" },
	{ 500, "Legend Rider" }
}
for v286, v_u_287 in v278 do
	local v288 = {
		["Name"] = nil,
		["Text"] = "",
		["AutoButtonColor"] = false,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Name"] = v_u_287.id,
		["BackgroundColor3"] = Color3.fromRGB(255, 146, 0),
		["Position"] = UDim2.new((v286 - 1) / #v278, 3, 0, 4),
		["Size"] = UDim2.new(1 / #v278, -6, 1, -8),
		["Parent"] = v280
	}
	local v289 = v_u_12.new("TextButton", v288)
	v_u_12.corner(v289, 12)
	local v290 = v_u_70(v289, v_u_287.icon, Color3.fromRGB(112, 116, 128), 20, 0, 0)
	v290.Position = UDim2.new(0.5, 0, 0, 14)
	local v291 = {
		["button"] = v289,
		["icon"] = v290,
		["caption"] = v_u_61(v289, v_u_287.label, 0, 25, nil, 14, 11, Color3.fromRGB(112, 116, 128), true, {
			["TextXAlignment"] = Enum.TextXAlignment.Center,
			["Size"] = UDim2.new(1, 0, 0, 14)
		})
	}
	v_u_283[v_u_287.id] = v291
	v289.Activated:Connect(function()
		-- upvalues: (ref) v_u_282, (copy) v_u_287
		v_u_282(v_u_287.id)
	end)
end
local function v_u_296() -- name: paintTabs
	-- upvalues: (copy) v_u_283, (ref) v_u_284, (copy) v_u_13
	for v292, v293 in v_u_283 do
		local v294 = v292 == v_u_284
		v293.button.BackgroundTransparency = v294 and 0.86 or 1
		local v295
		if v294 then
			v295 = Color3.fromRGB(235, 110, 0)
		else
			v295 = Color3.fromRGB(112, 116, 128)
		end
		v_u_13.tint(v293.icon, v295)
		v293.caption.TextColor3 = v295
	end
end
local v_u_297 = nil
task.spawn(function()
	-- upvalues: (copy) v_u_2, (copy) v_u_19, (ref) v_u_297
	local v298 = v_u_2.GetUserThumbnailAsync
	local v299 = v_u_2
	local v300 = v_u_19.UserId
	local v301 = Enum.ThumbnailType.HeadShot
	local v302 = Enum.ThumbnailSize.Size150x150
	local v303, v304 = pcall(v298, v299, v300, v301, v302)
	if v303 then
		v_u_297 = v304
	end
end)
local function v_u_308() -- name: historyList
	-- upvalues: (copy) v_u_19
	local function v305()
		-- upvalues: (ref) v_u_19
		return game:GetService("HttpService"):JSONDecode(v_u_19:GetAttribute("DeliveryHistory") or "[]")
	end
	local v306, v307 = pcall(v305)
	return (not v306 or type(v307) ~= "table") and {} or v307
end
local v309 = {
	["Name"] = "History",
	["Text"] = "",
	["AutoButtonColor"] = false,
	["BackgroundColor3"] = nil,
	["BackgroundTransparency"] = 0.75,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["BackgroundColor3"] = v_u_28,
	["AnchorPoint"] = Vector2.new(1, 0),
	["Position"] = UDim2.new(1, -12, 0, 46),
	["Size"] = UDim2.fromOffset(36, 36),
	["Parent"] = v251
}
local v_u_310 = v_u_12.new("TextButton", v309)
v_u_12.corner(v_u_310, 18)
v_u_70(v_u_310, "clock", v_u_28, 22)
local function v_u_315() -- name: ratingLine
	-- upvalues: (copy) v_u_19, (copy) v_u_9
	local v311 = v_u_19:GetAttribute("DeliveryRating") or 5
	local v312 = v_u_9.ratingBonus(v311)
	local v313 = "\226\152\133 %.2f%s"
	local v314
	if v312 > 0 then
		v314 = ("  bonus +%d%%"):format(v312 * 100)
	else
		v314 = v312 >= 0 and "" or ("  cut %d%%"):format(-v312 * 100)
	end
	return v313:format(v311, v314)
end
local function v_u_319(p316) -- name: ago
	local v317 = os.time() - (p316 or os.time())
	local v318 = math.max(0, v317)
	if v318 < 60 then
		return "just now"
	elseif v318 < 3600 then
		return ("%d min ago"):format(v318 // 60)
	elseif v318 < 86400 then
		return ("%d hr ago"):format(v318 // 3600)
	else
		return ("%d d ago"):format(v318 // 86400)
	end
end
local v_u_320 = {}
local v_u_321 = {}
local v_u_322 = (-1 / 0)
local v_u_323 = nil
local v_u_324 = nil
local v_u_325 = nil
local v_u_326 = false
local v_u_327 = false
local function v_u_330() -- name: clearView
	-- upvalues: (ref) v_u_323, (copy) v_u_321, (copy) v_u_320, (copy) v_u_263, (copy) v_u_12, (copy) v_u_6, (copy) v_u_23
	if v_u_323 then
		v_u_323:Destroy()
	end
	for _, v328 in v_u_321 do
		v328:Disconnect()
	end
	table.clear(v_u_321)
	table.clear(v_u_320)
	local v329 = {
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Parent"] = nil,
		["Size"] = UDim2.fromScale(1, 1),
		["Parent"] = v_u_263
	}
	v_u_323 = v_u_12.new("Frame", v329)
	v_u_323.Position = UDim2.fromOffset(0, 14)
	v_u_6:Create(v_u_323, v_u_23, {
		["Position"] = UDim2.new()
	}):Play()
	return v_u_323
end
local function v_u_348(p331, p332, p333, p334, p335, p336, p337) -- name: stop
	-- upvalues: (copy) v_u_117, (copy) v_u_61, (copy) v_u_29
	local v338 = v_u_117
	local v339 = p337 and "check" or p334
	if p337 then
		p333 = Color3.fromRGB(170, 174, 182)
	end
	local v340 = v338(p331, v339, p333, 34, 30, p332 + 20)
	local v341 = v_u_61
	local v342 = 56
	local v343 = p332 + 2
	local v344 = nil
	local v345 = 22
	local v346 = 16
	local v347
	if p337 then
		v347 = v_u_29.dim
	else
		v347 = v_u_29.ink
	end
	v341(p331, p335, v342, v343, v344, v345, v346, v347, true)
	v_u_61(p331, p336, 56, p332 + 23, nil, 18, 13, v_u_29.dim)
	return v340
end
local function v_u_403(p349, p350, p351, p_u_352) -- name: slider
	-- upvalues: (copy) v_u_29, (copy) v_u_12, (copy) v_u_61, (copy) v_u_28, (copy) v_u_6, (copy) v_u_70, (copy) v_u_25, (copy) v_u_321, (copy) v_u_7, (copy) v_u_13
	local v_u_353 = {
		["enabled"] = false,
		["done"] = false,
		["offset"] = 0,
		["key"] = nil
	}
	local v354 = {
		["Name"] = "Slider",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_29.off,
		["AnchorPoint"] = Vector2.new(0.5, 1),
		["Position"] = UDim2.new(0.5, 0, 1, -p350),
		["Size"] = UDim2.fromOffset(254, p351),
		["Parent"] = p349
	}
	local v_u_355 = v_u_12.new("Frame", v354)
	v_u_12.corner(v_u_355, p351 / 2)
	local v356 = v_u_29.green1
	local v357 = v_u_29.green2
	local v358 = {
		["Color"] = nil,
		["Rotation"] = 0,
		["Parent"] = nil,
		["Color"] = ColorSequence.new(v356, v357),
		["Parent"] = v_u_355
	}
	local v_u_359 = v_u_12.new("UIGradient", v358)
	local v_u_360 = v_u_61(v_u_355, "", p351, 0, nil, p351, 16, v_u_28, true, {
		["TextXAlignment"] = nil,
		["Size"] = nil,
		["ZIndex"] = 2,
		["TextXAlignment"] = Enum.TextXAlignment.Center,
		["Size"] = UDim2.new(1, -p351 - 8, 1, 0)
	})
	local v361 = {
		["Transparency"] = NumberSequence.new({
			NumberSequenceKeypoint.new(0, 0.3),
			NumberSequenceKeypoint.new(0.4, 0.3),
			NumberSequenceKeypoint.new(0.5, 0),
			NumberSequenceKeypoint.new(0.6, 0.3),
			NumberSequenceKeypoint.new(1, 0.3)
		}),
		["Offset"] = Vector2.new(-1, 0),
		["Parent"] = v_u_360
	}
	local v_u_362 = v_u_12.new("UIGradient", v361)
	v_u_6:Create(v_u_362, TweenInfo.new(1.6, Enum.EasingStyle.Linear, Enum.EasingDirection.In, -1), {
		["Offset"] = Vector2.new(1, 0)
	}):Play()
	local v363 = {
		["Name"] = "Knob",
		["Text"] = "",
		["AutoButtonColor"] = false,
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 3,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_28,
		["Position"] = UDim2.fromOffset(4, 4),
		["Size"] = UDim2.fromOffset(p351 - 8, p351 - 8),
		["Parent"] = v_u_355
	}
	local v_u_364 = v_u_12.new("TextButton", v363)
	v_u_12.corner(v_u_364, (p351 - 8) / 2)
	local v365 = v_u_70
	local v366 = v_u_29.green2
	local v367 = p351 * 0.42
	local v_u_368 = v365(v_u_364, "arrow", v366, (math.floor(v367)))
	v_u_368.Rotation = 180
	local v_u_369 = 254 - p351
	local v_u_370 = false
	local v_u_371 = 0
	local v_u_372 = 0
	local function v_u_373() -- name: springBack
		-- upvalues: (copy) v_u_353, (copy) v_u_360, (ref) v_u_6, (copy) v_u_364, (ref) v_u_25
		v_u_353.done = false
		v_u_353.offset = 0
		v_u_360.TextTransparency = 0
		v_u_6:Create(v_u_364, v_u_25, {
			["Position"] = UDim2.fromOffset(4, 4)
		}):Play()
	end
	v_u_364.InputBegan:Connect(function(p374)
		-- upvalues: (copy) v_u_353, (ref) v_u_370, (ref) v_u_371, (ref) v_u_372
		if v_u_353.enabled and not v_u_353.done and (p374.UserInputType == Enum.UserInputType.MouseButton1 or p374.UserInputType == Enum.UserInputType.Touch) then
			local v375 = p374.Position.X
			local v376 = v_u_353.offset
			v_u_370 = true
			v_u_371 = v375
			v_u_372 = v376
		end
	end)
	local v377 = v_u_321
	local v378 = v_u_7.InputChanged
	local function v387(p379)
		-- upvalues: (ref) v_u_370, (copy) v_u_355, (ref) v_u_372, (ref) v_u_371, (copy) v_u_369, (copy) v_u_353, (copy) v_u_364, (copy) v_u_360
		if v_u_370 and (p379.UserInputType == Enum.UserInputType.MouseMovement or p379.UserInputType == Enum.UserInputType.Touch) then
			local v380 = v_u_355.AbsoluteSize.X
			local v381 = 254 / math.max(1, v380)
			local v382 = v_u_372 + (p379.Position.X - v_u_371) * v381
			local v383 = v_u_369
			local v384 = math.clamp(v382, 0, v383)
			v_u_353.offset = v384
			v_u_364.Position = UDim2.fromOffset(4 + v384, 4)
			local v385 = v_u_360
			local v386 = v384 / v_u_369 * 1.6
			v385.TextTransparency = math.clamp(v386, 0, 1)
		end
	end
	table.insert(v377, v378:Connect(v387))
	local v388 = v_u_321
	local v389 = v_u_7.InputEnded
	local function v394(p390)
		-- upvalues: (ref) v_u_370, (copy) v_u_353, (copy) v_u_369, (copy) v_u_373, (copy) v_u_364, (copy) v_u_360, (copy) p_u_352, (copy) v_u_355
		if v_u_370 and (p390.UserInputType == Enum.UserInputType.MouseButton1 or p390.UserInputType == Enum.UserInputType.Touch) then
			v_u_370 = false
			if v_u_353.offset < v_u_369 * 0.86 then
				v_u_373()
			else
				v_u_353.done = true
				local v391 = v_u_369
				v_u_353.offset = v391
				v_u_364.Position = UDim2.fromOffset(4 + v391, 4)
				local v392 = v_u_360
				local v393 = v391 / v_u_369 * 1.6
				v392.TextTransparency = math.clamp(v393, 0, 1)
				task.spawn(function()
					-- upvalues: (ref) p_u_352, (ref) v_u_355, (ref) v_u_373
					if not p_u_352() then
						task.wait(0.3)
						if v_u_355.Parent then
							v_u_373()
						end
					end
				end)
			end
		else
			return
		end
	end
	table.insert(v388, v389:Connect(v394))
	function v_u_353.set(p395, p396, p397) -- name: set
		-- upvalues: (copy) v_u_353, (copy) v_u_360, (copy) v_u_359, (copy) v_u_355, (ref) v_u_28, (ref) v_u_29, (copy) v_u_362, (ref) v_u_13, (copy) v_u_368, (ref) v_u_370, (copy) v_u_373
		local v398 = tostring(p395) .. p396
		if v_u_353.done or v398 == v_u_353.key then
			return
		else
			v_u_353.key = v398
			v_u_353.enabled = p395
			v_u_360.Text = p396
			v_u_359.Enabled = p395
			local v399 = v_u_355
			local v400
			if p395 then
				v400 = v_u_28
			else
				v400 = v_u_29.off
			end
			v399.BackgroundColor3 = v400
			local v401 = v_u_360
			local v402
			if p395 then
				v402 = v_u_28
			else
				v402 = v_u_29.dim
			end
			v401.TextColor3 = v402
			v_u_362.Enabled = p395
			if p395 then
				v_u_359.Color = ColorSequence.new(p397[1], p397[2])
				v_u_13.tint(v_u_368, p397[2])
			else
				v_u_13.tint(v_u_368, v_u_29.off)
				if v_u_370 or v_u_353.offset > 0 then
					v_u_370 = false
					v_u_373()
				end
			end
		end
	end
	return v_u_353
end
local function v_u_443(p404, p405, p_u_406) -- name: powerCard
	-- upvalues: (copy) v_u_129, (copy) v_u_117, (copy) v_u_29, (copy) v_u_61, (copy) v_u_12, (copy) v_u_28, (copy) v_u_6, (copy) v_u_26, (ref) v_u_87, (copy) v_u_10, (copy) v_u_20, (copy) v_u_14, (ref) v_u_324
	local v407 = v_u_129(p404, p405, 74, 14)
	local v408 = v_u_117
	local v409 = "scooter"
	local v410
	if p_u_406 then
		v410 = v_u_29.green2
	else
		v410 = Color3.fromRGB(150, 154, 162)
	end
	v408(v407, v409, v410, 42, 35, 37)
	v_u_61(v407, "Take jobs", 66, 13, 110, 24, 18, v_u_29.ink, true)
	local v411 = v_u_61
	local v412 = p_u_406 and "On \194\183 finding jobs" or "Off \194\183 tap to turn on"
	local v413 = 66
	local v414 = 38
	local v415 = 110
	local v416 = 18
	local v417 = 13
	local v418
	if p_u_406 then
		v418 = v_u_29.green2
	else
		v418 = v_u_29.dim
	end
	v411(v407, v412, v413, v414, v415, v416, v417, v418)
	local v419 = {
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil
	}
	local v420
	if p_u_406 then
		v420 = v_u_29.green1
	else
		v420 = v_u_29.off
	end
	v419.BackgroundColor3 = v420
	v419.AnchorPoint = Vector2.new(1, 0.5)
	v419.Position = UDim2.new(1, -14, 0.5, 0)
	v419.Size = UDim2.fromOffset(64, 36)
	v419.Parent = v407
	local v_u_421 = v_u_12.new("Frame", v419)
	v_u_12.corner(v_u_421, 18)
	v_u_61(v_u_421, p_u_406 and "On" or "Off", p_u_406 and 6 or 32, 0, 26, 36, 12, v_u_28, true, {
		["TextXAlignment"] = Enum.TextXAlignment.Center
	})
	local v422 = {
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_28,
		["AnchorPoint"] = Vector2.new(0, 0.5)
	}
	local v423
	if p_u_406 then
		v423 = UDim2.new(1, -33, 0.5, 0)
	else
		v423 = UDim2.new(0, 3, 0.5, 0)
	end
	v422.Position = v423
	v422.Size = UDim2.fromOffset(30, 30)
	v422.Parent = v_u_421
	local v_u_424 = v_u_12.new("Frame", v422)
	v_u_12.corner(v_u_424, 15)
	local v425 = {
		["Text"] = "",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 5,
		["Parent"] = nil,
		["Size"] = UDim2.fromScale(1, 1),
		["Parent"] = v407
	}
	v_u_12.new("TextButton", v425).Activated:Connect(function()
		-- upvalues: (ref) v_u_6, (copy) v_u_424, (ref) v_u_26, (copy) p_u_406, (copy) v_u_421, (ref) v_u_29, (ref) v_u_87, (ref) v_u_10, (ref) v_u_20, (ref) v_u_14, (ref) v_u_324
		local v426 = v_u_6
		local v427 = v_u_424
		local v428 = v_u_26
		local v429 = {}
		local v430
		if p_u_406 then
			v430 = UDim2.new(0, 3, 0.5, 0)
		else
			v430 = UDim2.new(1, -33, 0.5, 0)
		end
		v429.Position = v430
		v426:Create(v427, v428, v429):Play()
		local v431 = v_u_6
		local v432 = v_u_421
		local v433 = v_u_26
		local v434 = {}
		local v435
		if p_u_406 then
			v435 = v_u_29.off
		else
			v435 = v_u_29.green1
		end
		v434.BackgroundColor3 = v435
		v431:Create(v432, v433, v434):Play()
		local v436 = p_u_406 and "Stop" or "Start"
		local v437
		if v_u_87 then
			v437 = false
		else
			v_u_87 = true
			local v438 = v_u_10.invoke
			local v439 = v_u_20
			local v440, v441, v442 = pcall(v438, v439, v436, nil)
			v_u_87 = false
			if v440 and v442 then
				v_u_14.show(v442, v441 and "ok" or "error")
				v437 = v440 and v441
			else
				v437 = v440 and v441
			end
		end
		if not v437 then
			v_u_324()
		end
	end)
	return v407
end
local v_u_444 = {
	{
		["mode"] = "food",
		["name"] = "Food",
		["detail"] = "Box on the back",
		["icon"] = "bowl",
		["color"] = nil,
		["color"] = v_u_29.shop
	},
	{
		["mode"] = "ride",
		["name"] = "Rides",
		["detail"] = "Customer on the back seat",
		["icon"] = "person",
		["color"] = nil,
		["color"] = v_u_29.ride
	},
	{
		["mode"] = "parcel",
		["name"] = "Parcels",
		["detail"] = "One box at a time from the depot to homes",
		["icon"] = "bag",
		["color"] = nil,
		["color"] = v_u_29.parcel
	},
	{
		["mode"] = "grab",
		["name"] = "Rider",
		["detail"] = "Passengers pay ~1,000-2,500 by distance",
		["icon"] = "person",
		["color"] = nil,
		["color"] = v_u_29.ride
	}
}
local function v_u_446(p445) -- name: kindLook
	-- upvalues: (copy) v_u_29
	if p445 == "ride" then
		return v_u_29.ride, "person", "Customer", "Ride"
	elseif p445 == "parcel" then
		return v_u_29.parcel, "bag", "Parcel", "Parcels"
	else
		return v_u_29.shop, "bowl", "Food", "Food"
	end
end
local function v_u_467(p447, p448) -- name: modeChooser
	-- upvalues: (copy) v_u_129, (copy) v_u_19, (copy) v_u_444, (copy) v_u_61, (copy) v_u_29, (copy) v_u_12, (copy) v_u_28, (copy) v_u_17, (copy) v_u_77, (copy) v_u_117, (ref) v_u_87, (copy) v_u_10, (copy) v_u_20, (copy) v_u_14
	local v449 = v_u_129(p447, p448, 112, 14)
	local v450 = v_u_19:GetAttribute("Job")
	local v451
	if v450 == "Courier" then
		v451 = { v_u_444[3] }
	elseif v450 == "Delivery" then
		v451 = { v_u_444[1], v_u_444[2] }
	else
		v451 = v450 == "Grab" and { v_u_444[4] } or {}
	end
	if #v451 ~= 0 then
		v_u_61(v449, "Pick a job type and start", 14, 8, nil, 18, 13, v_u_29.dim, true)
		local v452 = 1 / #v451
		for v453, v_u_454 in v451 do
			local v455 = {
				["Text"] = "",
				["AutoButtonColor"] = false,
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.88,
				["BorderSizePixel"] = 0,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["BackgroundColor3"] = v_u_454.color,
				["Position"] = UDim2.new((v453 - 1) * v452, v453 == 1 and 10 or 4, 0, 30),
				["Size"] = UDim2.new(v452, #v451 == 1 and -20 or -14, 0, 72),
				["Parent"] = v449
			}
			local v456 = v_u_12.new("TextButton", v455)
			v_u_12.corner(v456, 12)
			local v457 = {
				["ApplyStrokeMode"] = nil,
				["Color"] = nil,
				["Transparency"] = 0.4,
				["Thickness"] = 1.5,
				["Parent"] = nil,
				["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
				["Color"] = v_u_454.color,
				["Parent"] = v456
			}
			v_u_12.new("UIStroke", v457)
			v_u_77(v456, (v_u_12.new("UIScale", {
				["Parent"] = v456
			})))
			v_u_117(v456, v_u_454.icon, v_u_454.color, 36, 28, 36)
			v_u_61(v456, v_u_454.name, 52, 14, nil, 22, 17, v_u_29.ink, true)
			v_u_61(v456, v_u_454.detail, 52, 38, nil, 16, 12, v_u_29.dim)
			v456.Activated:Connect(function()
				-- upvalues: (copy) v_u_454, (ref) v_u_87, (ref) v_u_10, (ref) v_u_20, (ref) v_u_14
				local v458 = v_u_454.mode
				if not v_u_87 then
					v_u_87 = true
					local v459 = v_u_10.invoke
					local v460 = v_u_20
					local v461, v462, v463 = pcall(v459, v460, "Start", v458)
					v_u_87 = false
					if v461 and v463 then
						v_u_14.show(v463, v462 and "ok" or "error")
					end
				end
			end)
		end
		return v449
	end
	v_u_61(v449, "This job can\'t take deliveries", 14, 10, nil, 22, 16, v_u_29.ink, true)
	v_u_61(v449, "Pick the Food Delivery, Courier or Rider job first", 14, 34, nil, 18, 13, v_u_29.dim)
	local v464 = {
		["Text"] = "",
		["AutoButtonColor"] = false,
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_29.brand1,
		["Position"] = UDim2.fromOffset(14, 64),
		["Size"] = UDim2.new(1, -28, 0, 36),
		["Parent"] = v449
	}
	local v465 = v_u_12.new("TextButton", v464)
	v_u_12.corner(v465, 18)
	local v466 = v_u_61(v465, "Pick a job", 0, 0, nil, 36, 14, v_u_28, true, nil)
	v466.TextXAlignment = Enum.TextXAlignment.Center
	v466.Size = UDim2.new(1, 0, 0, 36)
	v465.Activated:Connect(function()
		-- upvalues: (ref) v_u_17
		v_u_17.open("Play")
	end)
	return v449
end
local function v_u_487(p468, p469) -- name: modeRow
	-- upvalues: (copy) v_u_19, (copy) v_u_444, (copy) v_u_12, (copy) v_u_70, (copy) v_u_61, (copy) v_u_29, (copy) v_u_77, (copy) v_u_28, (ref) v_u_87, (copy) v_u_10, (copy) v_u_20, (copy) v_u_14
	local v470 = v_u_19:GetAttribute("DeliveryMode")
	local v471
	if v470 == "ride" then
		v471 = v_u_444[2]
	elseif v470 == "parcel" then
		v471 = v_u_444[3]
	elseif v470 == "grab" then
		v471 = v_u_444[4]
	else
		v471 = v_u_444[1]
	end
	local v472 = {
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.85,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = v471.color,
		["Position"] = UDim2.fromOffset(14, p469),
		["Size"] = UDim2.fromOffset(118, 32),
		["Parent"] = p468
	}
	local v473 = v_u_12.new("Frame", v472)
	v_u_12.corner(v473, 16)
	v_u_70(v473, v471.icon, v471.color, 18, 20, 16)
	v_u_61(v473, "Jobs" .. v471.name, 34, 0, 80, 32, 14, v471.color, true)
	if v470 ~= "ride" and v470 ~= "grab" then
		local v474 = v_u_19:GetAttribute("DeliveryBox") ~= false
		local v475 = {
			["Text"] = "",
			["AutoButtonColor"] = false,
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil
		}
		local v476
		if v474 then
			v476 = v_u_29.card
		else
			v476 = v_u_29.shop
		end
		v475.BackgroundColor3 = v476
		v475.AnchorPoint = Vector2.new(1, 0)
		v475.Position = UDim2.new(1, -14, 0, p469)
		v475.Size = UDim2.fromOffset(118, 32)
		v475.Parent = p468
		local v477 = v_u_12.new("TextButton", v475)
		v_u_12.corner(v477, 16)
		local v478 = {
			["ApplyStrokeMode"] = nil,
			["Color"] = nil,
			["Thickness"] = 1.5,
			["Parent"] = nil,
			["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
			["Color"] = v_u_29.shop,
			["Parent"] = v477
		}
		v_u_12.new("UIStroke", v478)
		v_u_77(v477, (v_u_12.new("UIScale", {
			["Parent"] = v477
		})))
		local v479 = (v474 and "Remove " or "Add ") .. (v470 == "parcel" and "parcel box" or "food box")
		local v480
		if v474 then
			v480 = v_u_29.shop
		else
			v480 = v_u_28
		end
		local v481 = v_u_61(v477, v479, 0, 0, nil, 32, 13, v480, true, nil)
		v481.TextXAlignment = Enum.TextXAlignment.Center
		v481.Size = UDim2.new(1, 0, 0, 32)
		v477.Activated:Connect(function()
			-- upvalues: (ref) v_u_87, (ref) v_u_10, (ref) v_u_20, (ref) v_u_14
			if not v_u_87 then
				v_u_87 = true
				local v482 = v_u_10.invoke
				local v483 = v_u_20
				local v484, v485, v486 = pcall(v482, v483, "Box", nil)
				v_u_87 = false
				if v484 and v486 then
					v_u_14.show(v486, v485 and "ok" or "error")
				end
			end
		end)
	end
end
v_u_324 = function() -- name: buildView
	-- upvalues: (copy) v_u_330, (ref) v_u_88, (copy) v_u_260, (copy) v_u_315, (copy) v_u_310, (copy) v_u_296, (copy) v_u_19, (ref) v_u_284, (copy) v_u_129, (copy) v_u_28, (copy) v_u_12, (copy) v_u_29, (ref) v_u_297, (copy) v_u_61, (copy) v_u_285, (copy) v_u_8, (copy) v_u_467, (copy) v_u_443, (copy) v_u_487, (ref) v_u_282, (copy) v_u_308, (copy) v_u_9, (copy) v_u_117, (copy) v_u_319, (copy) v_u_261, (copy) v_u_6, (copy) v_u_320, (ref) v_u_89, (copy) v_u_24, (ref) v_u_87, (copy) v_u_10, (copy) v_u_20, (copy) v_u_14, (copy) v_u_348, (copy) v_u_403, (copy) v_u_70, (copy) v_u_77, (ref) v_u_326, (ref) v_u_327, (ref) v_u_325, (copy) v_u_149, (ref) v_u_322
	local v488 = v_u_330()
	v_u_260.Text = (v_u_88 ~= "Off" and "\226\151\143 Online \194\183 " or "Offline \194\183 ") .. v_u_315()
	v_u_310.Visible = false
	v_u_296()
	local v489 = v_u_19:GetAttribute("DeliveryJobs") or 0
	local v490 = v_u_19:GetAttribute("DeliveryEarned") or 0
	local v491 = v_u_19:GetAttribute("DeliveryRating") or 5
	if v_u_284 == "home" then
		local v492 = v_u_129(v488, 12, 156, 14)
		local v493 = {
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["Parent"] = nil,
			["BackgroundColor3"] = v_u_28,
			["Size"] = UDim2.new(1, 0, 0, 46),
			["Parent"] = v492
		}
		local v494 = v_u_12.new("Frame", v493)
		v_u_12.corner(v494, 14)
		local v495 = v_u_29.brand1
		local v496 = v_u_29.brand2
		local v497 = {
			["Color"] = nil,
			["Rotation"] = 0,
			["Parent"] = nil,
			["Color"] = ColorSequence.new(v495, v496),
			["Parent"] = v494
		}
		v_u_12.new("UIGradient", v497)
		local v498 = {
			["BackgroundColor3"] = Color3.fromRGB(230, 232, 236),
			["Image"] = v_u_297 or "",
			["AnchorPoint"] = Vector2.new(0.5, 0),
			["Position"] = UDim2.new(0.5, 0, 0, 12),
			["Size"] = UDim2.fromOffset(62, 62),
			["Parent"] = v492
		}
		local v499 = v_u_12.new("ImageLabel", v498)
		v_u_12.corner(v499, 31)
		local v500 = {
			["Color"] = nil,
			["Thickness"] = 3,
			["Parent"] = nil,
			["Color"] = v_u_28,
			["Parent"] = v499
		}
		v_u_12.new("UIStroke", v500)
		local v501 = v_u_61(v492, v_u_19.DisplayName, 0, 78, nil, 22, 17, v_u_29.ink, true, nil)
		v501.TextXAlignment = Enum.TextXAlignment.Center
		v501.Size = UDim2.new(1, 0, 0, 22)
		local v502 = 1
		for v503, v504 in v_u_285 do
			if v504[1] > v489 then
				continue
			end
			v502 = v503
		end
		local v505 = v_u_285[v502]
		local _ = v_u_285[v502 + 1]
		local v506 = {
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["BackgroundColor3"] = v_u_29.line,
			["AnchorPoint"] = Vector2.new(0.5, 0),
			["Position"] = UDim2.new(0.5, 0, 0, 100),
			["Size"] = UDim2.fromOffset(130, 20),
			["Parent"] = v492
		}
		local v507 = v_u_12.new("Frame", v506)
		v_u_12.corner(v507, 10)
		local v508 = v_u_61(v507, v505[2], 0, 0, nil, 20, 12, v_u_29.dim, true, nil)
		v508.TextXAlignment = Enum.TextXAlignment.Center
		v508.Size = UDim2.new(1, 0, 0, 20)
		for v509, v510 in {
			{ tostring(v489), "Jobs" },
			{ ("\226\152\133 %.1f"):format(v491), "Stars" },
			{ v_u_8.formatCash(v490), "Earnings" }
		} do
			local v511 = {
				["BackgroundTransparency"] = 1,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["Position"] = UDim2.new((v509 - 1) / 3, 0, 0, 124),
				["Size"] = UDim2.new(0.3333333333333333, 0, 0, 30),
				["Parent"] = v492
			}
			local v512 = v_u_12.new("Frame", v511)
			local v513 = v510[1]
			local v514
			if v509 == 2 then
				v514 = v_u_29.yellow
			else
				v514 = v_u_29.ink
			end
			local v515 = v_u_61(v512, v513, 0, 0, nil, 18, 15, v514, true, nil)
			v515.TextXAlignment = Enum.TextXAlignment.Center
			v515.Size = UDim2.new(1, 0, 0, 18)
			local v516 = v_u_61(v512, v510[2], 0, 17, nil, 12, 11, v_u_29.dim, nil, nil)
			v516.TextXAlignment = Enum.TextXAlignment.Center
			v516.Size = UDim2.new(1, 0, 0, 12)
		end
		if v_u_88 == "Off" then
			v_u_467(v488, 180)
		else
			v_u_443(v488, 180, true)
			v_u_487(v488, 266)
			local v517 = {
				["Text"] = "",
				["AutoButtonColor"] = false,
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["BackgroundColor3"] = v_u_29.card,
				["Position"] = UDim2.fromOffset(14, 310),
				["Size"] = UDim2.new(1, -28, 0, 44),
				["Parent"] = v488
			}
			local v518 = v_u_12.new("TextButton", v517)
			v_u_12.corner(v518, 12)
			local v519 = v_u_61(v518, v_u_88 == "Searching" and "Finding jobs  \226\128\186  see the Jobs tab" or "On a job  \226\128\186  go to the Jobs tab", 0, 0, nil, 44, 14, v_u_29.brand2, true, nil)
			v519.TextXAlignment = Enum.TextXAlignment.Center
			v519.Size = UDim2.new(1, 0, 0, 44)
			v518.Activated:Connect(function()
				-- upvalues: (ref) v_u_282
				v_u_282("jobs")
			end)
		end
	elseif v_u_284 == "stats" then
		local v520 = 1
		for v521, v522 in v_u_285 do
			if v522[1] > v489 then
				continue
			end
			v520 = v521
		end
		local v523 = v_u_285[v520]
		local v524 = v_u_285[v520 + 1]
		local v525 = v_u_129(v488, 12, 92, 14)
		v_u_61(v525, "Rank", 16, 10, nil, 16, 12, v_u_29.dim, true)
		v_u_61(v525, v523[2], 16, 26, nil, 28, 22, v_u_29.ink, true)
		local v526 = {
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["BackgroundColor3"] = v_u_29.line,
			["Position"] = UDim2.fromOffset(16, 62),
			["Size"] = UDim2.new(1, -32, 0, 8),
			["Parent"] = v525
		}
		local v527 = v_u_12.new("Frame", v526)
		v_u_12.corner(v527, 4)
		local v528 = not v524 and 1 or (v489 - v523[1]) / (v524[1] - v523[1])
		local v529 = {
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["Parent"] = nil,
			["BackgroundColor3"] = v_u_29.green1,
			["Size"] = UDim2.fromScale(math.clamp(v528, 0.02, 1), 1),
			["Parent"] = v527
		}
		local v530 = v_u_12.new("Frame", v529)
		v_u_12.corner(v530, 4)
		v_u_61(v525, not v524 and "Top rank reached!" or ("%d / %d jobs to %s"):format(v489, v524[1], v524[2]), 16, 72, nil, 16, 12, v_u_29.dim)
		local v531 = 0
		local v532 = 0
		for _, v533 in v_u_308() do
			if v533.s == 5 then
				v532 = v532 + 1
			else
				if (v533.p or 0) ~= 0 then
					continue
				end
				v531 = v531 + 1
			end
		end
		local v534 = v_u_9.ratingBonus(v491)
		local v535 = {}
		local v536 = { "Rider stars", ("\226\152\133 %.1f"):format(v491), v_u_29.yellow }
		local v537 = {}
		local v538 = "Fare bonus"
		local v539 = v534 >= 0 and "+" or ""
		local v540 = v534 * 100
		local v541 = v539 .. math.floor(v540) .. "%"
		local v542
		if v534 < 0 then
			v542 = v_u_29.red
		else
			v542 = v_u_29.green2
		end
		__set_list(v537, 1, {v538, v541, v542})
		local v543 = { "Jobs done", v_u_8.formatNumber(v489), v_u_29.ink }
		local v544 = { "Total earnings", v_u_8.formatCash(v490), v_u_29.green2 }
		local v545 = { "5 stars (recent)", tostring(v532), v_u_29.ink }
		local v546 = {}
		local v547 = "Cancelled / fell off"
		local v548 = tostring(v531)
		local v549
		if v531 > 0 then
			v549 = v_u_29.red
		else
			v549 = v_u_29.ink
		end
		__set_list(v546, 1, {v547, v548, v549})
		__set_list(v535, 1, {v536, v537, v543, v544, v545, v546})
		for v550, v551 in v535 do
			local v552 = (v550 - 1) % 2
			local v553 = (v550 - 1) // 2
			local v554 = {
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["BackgroundColor3"] = v_u_29.card,
				["Position"] = UDim2.new(v552 * 0.5, v552 == 0 and 14 or 5, 0, 116 + v553 * 80),
				["Size"] = UDim2.new(0.5, -19, 0, 70),
				["Parent"] = v488
			}
			local v555 = v_u_12.new("Frame", v554)
			v_u_12.corner(v555, 14)
			v_u_61(v555, v551[1], 12, 10, nil, 16, 12, v_u_29.dim, true)
			v_u_61(v555, v551[2], 12, 30, nil, 30, 24, v551[3], true)
		end
		return
	elseif v_u_284 == "reviews" then
		local v556 = v_u_129(v488, 12, 92, 14)
		local v557 = v_u_19:GetAttribute("DeliveryRating") or 5
		v_u_61(v556, ("\226\152\133 %.1f"):format(v557), 16, 12, 130, 44, 38, v_u_29.yellow, true)
		v_u_61(v556, "Your rider rating", 150, 16, nil, 18, 13, v_u_29.dim)
		local v558 = v_u_9.ratingBonus(v557)
		local v559 = v_u_61
		local v560
		if v558 > 0 then
			v560 = ("+%d%% on every job"):format(v558 * 100)
		else
			v560 = v558 >= 0 and "4.0 stars or more earns a bonus" or ("Fares cut %d%% (ride well and your stars come back)"):format(-v558 * 100)
		end
		local v561 = 150
		local v562 = 36
		local v563 = nil
		local v564 = 20
		local v565 = 15
		local v566
		if v558 < 0 then
			v566 = v_u_29.red
		else
			v566 = v_u_29.green2
		end
		v559(v556, v560, v561, v562, v563, v564, v565, v566, true)
		v_u_61(v556, "Ride well, no crashes, no cancels = more stars, more money", 16, 64, nil, 18, 12, v_u_29.dim)
		local v567 = v_u_308()
		local v568 = {
			["BackgroundTransparency"] = 1,
			["BorderSizePixel"] = 0,
			["Position"] = nil,
			["Size"] = nil,
			["CanvasSize"] = nil,
			["AutomaticCanvasSize"] = nil,
			["ScrollBarThickness"] = 4,
			["ScrollBarImageColor3"] = nil,
			["Parent"] = nil,
			["Position"] = UDim2.fromOffset(0, 114),
			["Size"] = UDim2.new(1, 0, 1, -124),
			["CanvasSize"] = UDim2.new(),
			["AutomaticCanvasSize"] = Enum.AutomaticSize.Y,
			["ScrollBarImageColor3"] = v_u_29.dim,
			["Parent"] = v488
		}
		local v569 = v_u_12.new("ScrollingFrame", v568)
		local v570 = {
			["Padding"] = UDim.new(0, 8),
			["SortOrder"] = Enum.SortOrder.LayoutOrder,
			["Parent"] = v569
		}
		v_u_12.new("UIListLayout", v570)
		local v571 = {
			["PaddingLeft"] = UDim.new(0, 14),
			["PaddingRight"] = UDim.new(0, 14),
			["Parent"] = v569
		}
		v_u_12.new("UIPadding", v571)
		if #v567 == 0 then
			local v572 = v_u_61(v569, "No reviews yet. Go take your first job!", 0, 0, nil, 40, 14, v_u_29.dim, nil, nil)
			v572.TextXAlignment = Enum.TextXAlignment.Center
			v572.Size = UDim2.new(1, 0, 0, 40)
		end
		for v573, v574 in v567 do
			local v575 = {
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["LayoutOrder"] = nil,
				["Parent"] = nil,
				["BackgroundColor3"] = v_u_29.card,
				["Size"] = UDim2.new(1, 0, 0, 74),
				["LayoutOrder"] = v573,
				["Parent"] = v569
			}
			local v576 = v_u_12.new("Frame", v575)
			v_u_12.corner(v576, 12)
			local v577 = (v574.s or 0) >= 4
			local v578 = v574.k
			local v579, v580
			if v578 == "ride" then
				v579 = v_u_29.ride
				v580 = "person"
			elseif v578 == "parcel" then
				v579 = v_u_29.parcel
				v580 = "bag"
			else
				v579 = v_u_29.shop
				v580 = "bowl"
			end
			v_u_117(v576, v580, v579, 34, 28, 26)
			v_u_61(v576, v574.c or "Customer", 52, 8, 120, 20, 15, v_u_29.ink, true)
			local v581 = v_u_61
			local v582
			if v574.x then
				local v583 = v_u_9.CANCEL_RATING_CUT * 100
				v582 = ("\224\184\162\224\184\129\224\185\128\224\184\165\224\184\180\224\184\129\224\184\135\224\184\178\224\184\153 \194\183 \224\184\148\224\184\178\224\184\167 -%d%%"):format((math.round(v583)))
			else
				local v584 = v_u_9.starsText
				local v585 = v574.s or 1
				v582 = v584((math.clamp(v585, 1, 5)))
			end
			local v586 = 52
			local v587 = 27
			local v588 = 140
			local v589 = 18
			local v590 = 14
			local v591
			if v577 and not v574.x then
				v591 = v_u_29.yellow
			else
				v591 = v_u_29.red
			end
			v581(v576, v582, v586, v587, v588, v589, v590, v591, true)
			v_u_61(v576, ("\"%s\""):format(v574.m or ""), 12, 50, nil, 18, 13, v_u_29.dim, false, {
				["Size"] = UDim2.new(1, -24, 0, 18)
			})
			local v592 = v_u_61
			local v593 = (v574.p or 0) <= 0 and "No pay" or "+" .. v_u_8.formatCash(v574.p)
			local v594 = 0
			local v595 = 8
			local v596 = nil
			local v597 = 20
			local v598 = 15
			local v599
			if (v574.p or 0) > 0 then
				v599 = v_u_29.green2
			else
				v599 = v_u_29.red
			end
			v592(v576, v593, v594, v595, v596, v597, v598, v599, true, {
				["TextXAlignment"] = Enum.TextXAlignment.Right,
				["Size"] = UDim2.new(1, -12, 0, 20)
			})
			v_u_61(v576, v_u_319(v574.t), 0, 28, nil, 16, 12, v_u_29.dim, false, {
				["TextXAlignment"] = Enum.TextXAlignment.Right,
				["Size"] = UDim2.new(1, -12, 0, 16)
			})
		end
		return
	else
		v_u_261.Text = ("%s jobs done \194\183 earned %s"):format(v_u_8.formatNumber(v_u_19:GetAttribute("DeliveryJobs") or 0), v_u_8.formatCash(v_u_19:GetAttribute("DeliveryEarned") or 0))
		if v_u_88 == "Off" then
			local v600 = v_u_129(v488, 14, 120, 14)
			local v601 = v_u_61(v600, "Not taking jobs yet", 0, 20, nil, 26, 19, v_u_29.ink, true, nil)
			v601.TextXAlignment = Enum.TextXAlignment.Center
			v601.Size = UDim2.new(1, 0, 0, 26)
			local v602 = v_u_61(v600, "Turn on jobs in the Home tab", 0, 48, nil, 18, 13, v_u_29.dim, nil, nil)
			v602.TextXAlignment = Enum.TextXAlignment.Center
			v602.Size = UDim2.new(1, 0, 0, 18)
			local v603 = {
				["Text"] = "",
				["AutoButtonColor"] = false,
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["BackgroundColor3"] = v_u_29.brand1,
				["AnchorPoint"] = Vector2.new(0.5, 0),
				["Position"] = UDim2.new(0.5, 0, 0, 74),
				["Size"] = UDim2.fromOffset(170, 34),
				["Parent"] = v600
			}
			local v604 = v_u_12.new("TextButton", v603)
			v_u_12.corner(v604, 17)
			local v605 = v_u_61(v604, "Go to Home", 0, 0, nil, 34, 14, v_u_28, true, nil)
			v605.TextXAlignment = Enum.TextXAlignment.Center
			v605.Size = UDim2.new(1, 0, 0, 34)
			v604.Activated:Connect(function()
				-- upvalues: (ref) v_u_282
				v_u_282("home")
			end)
			return
		elseif v_u_88 == "Searching" then
			local v606 = {
				["BackgroundTransparency"] = 1,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.new(0.5, 0, 0, 130),
				["Size"] = UDim2.fromOffset(180, 180),
				["Parent"] = v488
			}
			local v607 = v_u_12.new("Frame", v606)
			for v608 = 1, 3 do
				local v609 = {
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = 0.6,
					["BorderSizePixel"] = 0,
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["Parent"] = nil,
					["BackgroundColor3"] = v_u_29.brand1,
					["AnchorPoint"] = Vector2.new(0.5, 0.5),
					["Position"] = UDim2.fromScale(0.5, 0.5),
					["Size"] = UDim2.fromOffset(60, 60),
					["Parent"] = v607
				}
				local v610 = v_u_12.new("Frame", v609)
				v_u_12.corner(v610, 100)
				v_u_6:Create(v610, TweenInfo.new(2.1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out, -1, false, (v608 - 1) * 0.7), {
					["Size"] = nil,
					["BackgroundTransparency"] = 1,
					["Size"] = UDim2.fromOffset(180, 180)
				}):Play()
			end
			v_u_117(v607, "scooter", v_u_29.brand1, 64, 90, 90)
			local v611 = v_u_320
			local v612 = v_u_61(v488, "Finding jobs near you", 0, 226, nil, 26, 19, v_u_29.ink, true, nil)
			v612.TextXAlignment = Enum.TextXAlignment.Center
			v612.Size = UDim2.new(1, 0, 0, 26)
			v611.searching = v612
			local v613 = v_u_19:GetAttribute("DeliveryMode")
			local v614 = v_u_61(v488, (v613 == "ride" or v613 == "grab") and "Ride with a free back seat; customers will pop up to accept" or (v613 == "parcel" and "Every order starts at the depot: pick up the parcel there" or "Ride around for now; new jobs will pop up to accept"), 0, 254, nil, 18, 13, v_u_29.dim, nil, nil)
			v614.TextXAlignment = Enum.TextXAlignment.Center
			v614.Size = UDim2.new(1, 0, 0, 18)
			return
		elseif v_u_88 == "Offer" and v_u_89 then
			local v615 = v_u_89.kind == "ride"
			local v616 = v_u_89.kind
			local v617, v618, v619
			if v616 == "ride" then
				v617 = v_u_29.ride
				v618 = "Ride"
				v619 = "person"
			elseif v616 == "parcel" then
				v617 = v_u_29.parcel
				v618 = "Parcels"
				v619 = "bag"
			else
				v617 = v_u_29.shop
				v618 = "Food"
				v619 = "bowl"
			end
			local v620 = v_u_129(v488, 12, 300, 14)
			v_u_6:Create(v_u_12.new("UIScale", {
				["Scale"] = 0.85,
				["Parent"] = nil,
				["Parent"] = v620
			}), v_u_24, {
				["Scale"] = 1
			}):Play()
			local v621 = {
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["BackgroundColor3"] = v_u_29.yellow,
				["Position"] = UDim2.fromOffset(14, 14),
				["Size"] = UDim2.fromOffset(76, 24),
				["Parent"] = v620
			}
			local v622 = v_u_12.new("Frame", v621)
			v_u_12.corner(v622, 12)
			local v623 = v_u_61(v622, "New job!", 0, 0, nil, 24, 14, v_u_29.ink, true, nil)
			v623.TextXAlignment = Enum.TextXAlignment.Center
			v623.Size = UDim2.new(1, 0, 0, 24)
			local v624 = {
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.85,
				["BorderSizePixel"] = 0,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["BackgroundColor3"] = v617,
				["Position"] = UDim2.fromOffset(96, 14),
				["Size"] = UDim2.fromOffset(84, 24),
				["Parent"] = v620
			}
			local v625 = v_u_12.new("Frame", v624)
			v_u_12.corner(v625, 12)
			local v626 = v_u_61(v625, v618, 0, 0, nil, 24, 13, v617, true, nil)
			v626.TextXAlignment = Enum.TextXAlignment.Center
			v626.Size = UDim2.new(1, 0, 0, 24)
			local v627 = {
				["Text"] = "",
				["AutoButtonColor"] = false,
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["BackgroundColor3"] = v_u_29.bg,
				["AnchorPoint"] = Vector2.new(1, 0),
				["Position"] = UDim2.new(1, -14, 0, 13),
				["Size"] = UDim2.fromOffset(54, 26),
				["Parent"] = v620
			}
			local v628 = v_u_12.new("TextButton", v627)
			v_u_12.corner(v628, 13)
			local v629 = v_u_61(v628, "Skip", 0, 0, nil, 26, 13, v_u_29.dim, true, nil)
			v629.TextXAlignment = Enum.TextXAlignment.Center
			v629.Size = UDim2.new(1, 0, 0, 26)
			v628.Activated:Connect(function()
				-- upvalues: (ref) v_u_87, (ref) v_u_10, (ref) v_u_20, (ref) v_u_14
				if not v_u_87 then
					v_u_87 = true
					local v630 = v_u_10.invoke
					local v631 = v_u_20
					local v632, v633, v634 = pcall(v630, v631, "Skip", nil)
					v_u_87 = false
					if v632 and v634 then
						v_u_14.show(v634, v633 and "ok" or "error")
					end
				end
			end)
			local v635 = {
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["BackgroundColor3"] = v_u_29.line,
				["Position"] = UDim2.new(0, 14, 0, 46),
				["Size"] = UDim2.new(1, -28, 0, 5),
				["Parent"] = v620
			}
			local v636 = v_u_12.new("Frame", v635)
			v_u_12.corner(v636, 3)
			local v637 = v_u_320
			local v638 = {
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["Parent"] = nil,
				["BackgroundColor3"] = v_u_29.yellow,
				["Size"] = UDim2.fromScale(1, 1),
				["Parent"] = v636
			}
			v637.offerBar = v_u_12.new("Frame", v638)
			v_u_12.corner(v_u_320.offerBar, 3)
			for v639 = 0, 4 do
				local v640 = {
					["BackgroundColor3"] = nil,
					["BorderSizePixel"] = 0,
					["Position"] = nil,
					["Size"] = nil,
					["Parent"] = nil,
					["BackgroundColor3"] = v_u_29.line,
					["Position"] = UDim2.fromOffset(28, v639 * 7 + 96),
					["Size"] = UDim2.fromOffset(4, 4),
					["Parent"] = v620
				}
				local v641 = v_u_12.new("Frame", v640)
				v_u_12.corner(v641, 2)
			end
			if v615 then
				v_u_348(v620, 62, v_u_29.ride, "person", "Pick up " .. v_u_89.customer, v_u_89.shop.name)
				v_u_348(v620, 128, v_u_29.home, "pin", v_u_89.home.name, v_u_89.home.area)
			else
				v_u_348(v620, 62, v617, v619, v_u_89.shop.name, v_u_89.menu)
				v_u_348(v620, 128, v_u_29.home, "home", "Deliver to " .. v_u_89.customer, v_u_89.home.area)
			end
			v_u_61(v620, ("Pick up %s  \194\183  Drop off %s"):format(v_u_9.distanceText(v_u_89.toShop), v_u_9.distanceText(v_u_89.toHome)), 14, 184, nil, 18, 13, v_u_29.dim)
			local v642 = {
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["BackgroundColor3"] = v_u_29.line,
				["Position"] = UDim2.new(0, 14, 0, 210),
				["Size"] = UDim2.new(1, -28, 0, 1),
				["Parent"] = v620
			}
			v_u_12.new("Frame", v642)
			v_u_61(v620, "Fare", 14, 220, nil, 18, 13, v_u_29.dim)
			v_u_61(v620, v_u_8.formatCash(v_u_89.fee), 14, 238, nil, 40, 34, v_u_29.green2, true)
			local v643 = v_u_89.bonus or 0
			local v644 = v_u_61
			local v645
			if v643 > 0 then
				v645 = ("Incl. star bonus +%s \194\183 ride well for tips"):format(v_u_8.formatCash(v643))
			else
				v645 = v643 >= 0 and "No time limit \194\183 ride well, no crashes, get tips" or ("Low stars, cut %s"):format(v_u_8.formatCash(-v643))
			end
			local v646 = 14
			local v647 = 274
			local v648 = nil
			local v649 = 18
			local v650 = 12
			local v651
			if v643 < 0 then
				v651 = v_u_29.red
			else
				v651 = v_u_29.green2
			end
			v644(v620, v645, v646, v647, v648, v649, v650, v651, v643 ~= 0)
			v_u_403(v488, 24, 58, function()
				-- upvalues: (ref) v_u_87, (ref) v_u_10, (ref) v_u_20, (ref) v_u_14
				if v_u_87 then
					return false
				end
				v_u_87 = true
				local v652 = v_u_10.invoke
				local v653 = v_u_20
				local v654, v655, v656 = pcall(v652, v653, "Accept", nil)
				v_u_87 = false
				if v654 and v656 then
					v_u_14.show(v656, v655 and "ok" or "error")
				end
				return v654 and v655
			end).set(true, "Slide to accept the order", { v_u_29.green1, v_u_29.green2 })
		elseif (v_u_88 == "ToShop" or v_u_88 == "ToHome") and v_u_89 then
			local v657 = v_u_89.kind == "ride"
			local v658 = v_u_88 == "ToHome"
			local v659 = v_u_89.kind
			local v660, v661, v662
			if v659 == "ride" then
				v660 = v_u_29.ride
				v661 = "person"
				v662 = "Customer"
			elseif v659 == "parcel" then
				v660 = v_u_29.parcel
				v661 = "bag"
				v662 = "Parcel"
			else
				v660 = v_u_29.shop
				v661 = "bowl"
				v662 = "Food"
			end
			local v663
			if v658 then
				v663 = v_u_29.home
			else
				v663 = v660
			end
			local v664 = (v658 and "Drop off " or "Pick up ") .. v662:lower()
			local v665 = v_u_129(v488, 12, 112, 14)
			local v666 = {
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["Parent"] = nil,
				["BackgroundColor3"] = v663,
				["Size"] = UDim2.new(1, 0, 0, 6),
				["Parent"] = v665
			}
			local v667 = v_u_12.new("Frame", v666)
			v_u_12.corner(v667, 3)
			v_u_61(v665, v664, 14, 16, 150, 24, 18, v663, true)
			v_u_61(v665, v_u_8.formatCash(v_u_89.fee), 0, 17, nil, 22, 16, v_u_29.green2, true, {
				["TextXAlignment"] = Enum.TextXAlignment.Right,
				["Size"] = UDim2.new(1, -14, 0, 22)
			})
			v_u_320.distance = v_u_61(v665, "", 14, 42, nil, 40, 34, v_u_29.ink, true, {
				["Size"] = nil,
				["TextScaled"] = true,
				["Size"] = UDim2.new(1, -108, 0, 40)
			})
			local v668 = {
				["MaxTextSize"] = 34,
				["Parent"] = nil,
				["Parent"] = v_u_320.distance
			}
			v_u_12.new("UITextSizeConstraint", v668)
			v_u_320.time = v_u_61(v665, "", 14, 82, nil, 18, 13, v_u_29.dim, false, {
				["Size"] = UDim2.new(1, -108, 0, 18)
			})
			local v669 = {
				["Name"] = "MapButton",
				["Text"] = "",
				["AutoButtonColor"] = false,
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["BackgroundColor3"] = v_u_28,
				["AnchorPoint"] = Vector2.new(1, 0),
				["Position"] = UDim2.new(1, -12, 0, 40),
				["Size"] = UDim2.fromOffset(80, 62),
				["Parent"] = v665
			}
			local v670 = v_u_12.new("TextButton", v669)
			v_u_12.corner(v670, 14)
			local v671 = Color3.fromRGB(70, 160, 255)
			local v672 = Color3.fromRGB(18, 108, 232)
			local v673 = {
				["Color"] = nil,
				["Rotation"] = 90,
				["Parent"] = nil,
				["Color"] = ColorSequence.new(v671, v672),
				["Parent"] = v670
			}
			v_u_12.new("UIGradient", v673)
			v_u_70(v670, "pin", v_u_28, 26, 40, 22)
			local v674 = v_u_61(v670, "\224\185\129\224\184\156\224\184\153\224\184\151\224\184\181\224\185\136", 0, 38, nil, 18, 15, v_u_28, true, nil)
			v674.TextXAlignment = Enum.TextXAlignment.Center
			v674.Size = UDim2.new(1, 0, 0, 18)
			v_u_77(v670, (v_u_12.new("UIScale", {
				["Parent"] = v670
			})))
			v670.Activated:Connect(function()
				-- upvalues: (ref) v_u_326, (ref) v_u_327, (ref) v_u_325
				v_u_326 = false
				v_u_327 = true
				v_u_325(true)
			end)
			local v675 = v_u_129(v488, 136, 138, 14)
			for v676 = 0, 3 do
				local v677 = {
					["BackgroundColor3"] = nil,
					["BorderSizePixel"] = 0,
					["Position"] = nil,
					["Size"] = nil,
					["Parent"] = nil,
					["BackgroundColor3"] = v_u_29.line,
					["Position"] = UDim2.fromOffset(28, v676 * 7 + 48),
					["Size"] = UDim2.fromOffset(4, 4),
					["Parent"] = v675
				}
				local v678 = v_u_12.new("Frame", v677)
				v_u_12.corner(v678, 2)
			end
			if v657 then
				v_u_348(v675, 12, v_u_29.ride, "person", (v658 and "Picked up: " or "Pick up ") .. v_u_89.customer, v_u_89.shop.name, v658)
				v_u_348(v675, 76, v_u_29.home, "pin", v_u_89.home.name, v_u_89.home.area)
			else
				v_u_348(v675, 12, v660, v661, (v658 and "Picked up: " or "") .. v_u_89.shop.name, v_u_89.menu or "", v658)
				v_u_348(v675, 76, v_u_29.home, "home", "Deliver to " .. v_u_89.customer, v_u_89.home.area)
			end
			v_u_320.hint = v_u_61(v488, "", 14, 278, nil, 20, 14, v663, true, {
				["Size"] = UDim2.new(1, -28, 0, 20),
				["TextXAlignment"] = Enum.TextXAlignment.Center
			})
			v_u_320.slider = v_u_403(v488, 56, 48, function()
				-- upvalues: (ref) v_u_87, (ref) v_u_10, (ref) v_u_20, (ref) v_u_14
				if v_u_87 then
					return false
				end
				v_u_87 = true
				local v679 = v_u_10.invoke
				local v680 = v_u_20
				local v681, v682, v683 = pcall(v679, v680, "Confirm", nil)
				v_u_87 = false
				if v681 and v683 then
					v_u_14.show(v683, v682 and "ok" or "error")
				end
				return v681 and v682
			end)
			local v684 = v_u_320
			local v685 = v_u_89.kind
			local v686
			if v685 == "ride" then
				local _ = v_u_29.ride
				v686 = "Customer"
			elseif v685 == "parcel" then
				local _ = v_u_29.parcel
				v686 = "Parcel"
			else
				local _ = v_u_29.shop
				v686 = "Food"
			end
			v684.confirmText = (v658 and "Slide to confirm drop-off: " or "Slide to confirm pick-up: ") .. v686:lower()
			v_u_320.sliderColors = { v663:Lerp(v_u_28, 0.1), v663:Lerp(Color3.new(0, 0, 0), 0.18) }
			local v687, _, v_u_688 = v_u_149(v488, "Cancel job", 10, 38, nil, v_u_29.red)
			v_u_320.cancel = v_u_688
			v687.Activated:Connect(function()
				-- upvalues: (ref) v_u_322, (ref) v_u_87, (ref) v_u_10, (ref) v_u_20, (ref) v_u_14, (copy) v_u_688
				if os.clock() - v_u_322 < 3 then
					v_u_322 = (-1 / 0)
					if not v_u_87 then
						v_u_87 = true
						local v689 = v_u_10.invoke
						local v690 = v_u_20
						local v691, v692, v693 = pcall(v689, v690, "Cancel", nil)
						v_u_87 = false
						if v691 and v693 then
							v_u_14.show(v693, v692 and "ok" or "error")
						end
					end
				else
					v_u_322 = os.clock()
					v_u_688.Text = "Press again to cancel"
					return
				end
			end)
		end
	end
end
local v694 = v_u_12.panel
local v695 = {
	["Name"] = "DeliveryCard",
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Visible"] = false,
	["Parent"] = nil
}
local v696
if v_u_21 then
	v696 = Vector2.new(0.5, 0)
else
	v696 = Vector2.new(1, 0)
end
v695.AnchorPoint = v696
local v697
if v_u_21 then
	v697 = UDim2.new(0.5, 0, 0, 8)
else
	v697 = UDim2.new(1, -v_u_12.EDGE, 0, v_u_12.EDGE + v_u_22 + 8)
end
v695.Position = v697
v695.Size = UDim2.fromOffset(v_u_22, 62)
v695.Parent = v_u_78
local v_u_698 = v694(v695)
v_u_12.autoScale(v_u_698)
local v_u_699 = v132("UIScale", {
	["Parent"] = v_u_698
})
local v_u_700 = nil
local v_u_701 = v_u_12.text({
	["FontFace"] = nil,
	["TextSize"] = 15,
	["TextXAlignment"] = nil,
	["TextTruncate"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["FontFace"] = v_u_12.FONT_BOLD,
	["TextXAlignment"] = Enum.TextXAlignment.Left,
	["TextTruncate"] = Enum.TextTruncate.AtEnd,
	["Position"] = UDim2.fromOffset(54, 9),
	["Size"] = UDim2.new(1, -62, 0, 20),
	["Parent"] = v_u_698
})
local v_u_702 = v_u_12.text({
	["TextSize"] = 13,
	["TextColor3"] = nil,
	["TextXAlignment"] = nil,
	["TextTruncate"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["TextColor3"] = v_u_12.TEXT_DIM,
	["TextXAlignment"] = Enum.TextXAlignment.Left,
	["TextTruncate"] = Enum.TextTruncate.AtEnd,
	["Position"] = UDim2.fromOffset(54, 30),
	["Size"] = UDim2.new(1, -62, 0, 18),
	["Parent"] = v_u_698
})
local v_u_703 = v132("Frame", {
	["BackgroundColor3"] = nil,
	["BorderSizePixel"] = 0,
	["Position"] = nil,
	["Size"] = nil,
	["Visible"] = false,
	["Parent"] = nil,
	["BackgroundColor3"] = Color3.fromRGB(24, 26, 28),
	["Position"] = UDim2.new(0, 54, 1, -10),
	["Size"] = UDim2.new(1, -62, 0, 4),
	["Parent"] = v_u_698
})
v_u_12.corner(v_u_703, 2)
local v_u_704 = v132("Frame", {
	["BorderSizePixel"] = 0,
	["Size"] = nil,
	["Parent"] = nil,
	["Size"] = UDim2.fromScale(0, 1),
	["Parent"] = v_u_703
})
v_u_12.corner(v_u_704, 2)
local v705 = v132("TextButton", {
	["Text"] = "",
	["BackgroundTransparency"] = 1,
	["Size"] = nil,
	["ZIndex"] = 5,
	["Parent"] = nil,
	["Size"] = UDim2.fromScale(1, 1),
	["Parent"] = v_u_698
})
local function v_u_710() -- name: cardLook
	-- upvalues: (ref) v_u_89, (ref) v_u_88, (copy) v_u_29, (ref) v_u_700, (copy) v_u_117, (copy) v_u_698, (copy) v_u_704
	local v706 = v_u_89
	if v706 then
		v706 = v_u_89.kind == "ride"
	end
	local v707, v708
	if v_u_88 == "Offer" then
		v707 = v_u_29.yellow
		v708 = "star"
	elseif v_u_88 == "ToShop" then
		local v709 = v_u_89
		if v709 then
			v709 = v_u_89.kind
		end
		if v709 == "ride" then
			v707 = v_u_29.ride
			v708 = "person"
		elseif v709 == "parcel" then
			v707 = v_u_29.parcel
			v708 = "bag"
		else
			v707 = v_u_29.shop
			v708 = "bowl"
		end
	elseif v_u_88 == "ToHome" then
		v707 = v_u_29.home
		if v706 then
			v708 = "pin"
		else
			v708 = "home"
		end
	else
		v707 = v_u_29.brand1
		v708 = "scooter"
	end
	if v_u_700 then
		v_u_700:Destroy()
	end
	v_u_700 = v_u_117(v_u_698, v708, v707, 36, 27, 31)
	v_u_704.BackgroundColor3 = v707
end
local v_u_711 = false
local v_u_712 = false
local v_u_713 = UDim2.new()
local v_u_715 = require(v11:WaitForChild("NavMap")).new(v_u_248, Vector2.new(282, 562), function()
	-- upvalues: (ref) v_u_711, (ref) v_u_712
	local v714 = v_u_711
	if v714 then
		v714 = v_u_712
	end
	return v714
end)
local v_u_716 = nil
v_u_325 = function(p717) -- name: syncNav
	-- upvalues: (ref) v_u_88, (ref) v_u_89, (ref) v_u_716, (ref) v_u_326, (ref) v_u_327, (copy) v_u_715, (copy) v_u_9, (ref) v_u_712, (ref) v_u_284, (ref) v_u_90
	local v718
	if v_u_88 == "ToShop" or v_u_88 == "ToHome" then
		v718 = v_u_89 ~= nil
	else
		v718 = false
	end
	local v719 = v_u_89 and v_u_89.shop or {}
	local v720 = v_u_89 and v_u_89.home or {}
	local v721
	if v718 then
		local v722 = v_u_88
		local v723 = v_u_89.customer
		local v724 = tostring(v723)
		local v725 = v719.x
		local v726 = tostring(v725)
		local v727 = v720.x
		v721 = ("%s|%s|%s|%s"):format(v722, v724, v726, (tostring(v727)))
	else
		v721 = nil
	end
	if v721 ~= v_u_716 then
		v_u_716 = v721
		v_u_326 = false
		v_u_327 = false
		if v718 then
			local v728 = v_u_88 == "ToShop"
			local v729 = v_u_89.kind == "ride"
			local v730 = v_u_715.setTarget
			local v731 = v_u_9.target(v_u_88, v_u_89)
			local v732 = {
				["step"] = v728 and 1 or 2,
				["verb"] = v728 and "\224\184\163\224\184\177\224\184\154\224\184\151\224\184\181\224\185\136" or "\224\184\170\224\185\136\224\184\135\224\184\151\224\184\181\224\185\136"
			}
			local v733
			if v729 then
				if v728 then
					v733 = v_u_89.customer
				else
					v733 = v720.name
				end
			elseif v728 then
				v733 = v719.name
			else
				v733 = v_u_89.customer
			end
			v732.who = v733
			local v734
			if v728 then
				if v729 then
					v734 = v719.name
				else
					v734 = v_u_89.menu
				end
			else
				v734 = v720.area or v720.name
			end
			v732.where = v734
			v730(v731, v732)
		else
			v_u_715.setTarget(nil)
		end
	end
	if v718 and (v_u_712 and (v_u_284 == "jobs" and (not v_u_326 and (v_u_327 or not v_u_90)))) then
		v_u_715.show(p717)
	else
		v_u_715.hide(p717)
	end
end
v_u_715.dismissed.Event:Connect(function()
	-- upvalues: (ref) v_u_326, (ref) v_u_327, (ref) v_u_325
	v_u_326 = true
	v_u_327 = false
	v_u_325(true)
end)
local v_u_735 = 0
local v_u_736 = 0
local v_u_737 = 1
local function v_u_766(p738) -- name: layoutTouch
	-- upvalues: (copy) v_u_19, (copy) v_u_12, (copy) v_u_78, (copy) v_u_80, (ref) v_u_737, (copy) v_u_81, (ref) v_u_735, (ref) v_u_736, (ref) v_u_713
	local v739 = p738.ViewportSize
	local v740 = v_u_19.Character
	if v740 then
		v740 = v_u_19.Character:FindFirstChildOfClass("Humanoid")
	end
	local v741
	if v740 == nil or v740.SeatPart == nil then
		v741 = false
	else
		v741 = v740.SeatPart:IsA("VehicleSeat")
	end
	local v742, v743
	if v741 then
		local v744, v745 = v_u_12.driveScale(v739)
		v742 = (v739.X - v745) / 2 + (v_u_12.DRIVE_SIDE_W + 22) * v744
		v743 = v_u_78.AbsoluteSize.Y - 10 - (v_u_12.DRIVE_PAD_H + 8) * v744
	else
		v742 = v_u_12.touchLeft(v_u_78)
		v743 = v_u_78.AbsoluteSize.Y - 12
	end
	v_u_80.AnchorPoint = Vector2.new(0, 1)
	local v746 = v_u_78.AbsoluteSize
	local v747 = v_u_12.scaleFor(v739)
	local v748 = (v743 - 8) / 580
	local v749 = math.min(v747, v748)
	local v750 = math.max(0.4, v749) * v_u_737
	local v751 = (v746.Y - 16) / 580
	local v752 = math.max(0.25, v751)
	local v753 = math.clamp(v750, 0.25, v752)
	v_u_81.Scale = v753
	local v754 = v753 * 300
	local v755 = v753 * 580
	local v756 = v742 + v_u_735
	local v757 = v746.X - v754 - 6
	local v758 = math.max(8, v757)
	local v759 = math.clamp(v756, 8, v758)
	local v760 = v743 + v_u_736
	local v761 = v755 + 8
	local v762 = v755 + 8
	local v763 = v746.Y - 6
	local v764 = math.max(v762, v763)
	local v765 = math.clamp(v760, v761, v764)
	v_u_713 = UDim2.fromOffset(v759, v765)
end
local function v_u_776() -- name: layoutDock
	-- upvalues: (copy) v_u_21, (copy) v_u_766, (copy) v_u_12, (copy) v_u_16, (copy) v_u_78, (copy) v_u_22, (copy) v_u_81, (ref) v_u_713
	local v767 = workspace.CurrentCamera
	if v_u_21 and v767 then
		v_u_766(v767)
	else
		local v768 = v_u_12.scaleFor
		local v769
		if v767 then
			v769 = v767.ViewportSize
		else
			v769 = Vector2.new(1920, 1080)
		end
		local v770 = v768(v769)
		local v771 = not v_u_21
		if v771 then
			v771 = v_u_16.isShown()
		end
		local v772 = v_u_78.AbsoluteSize.Y - v_u_12.EDGE * 2
		if not (v_u_21 or v771) then
			v772 = v772 - (v_u_22 * v770 + 8)
		end
		local v773 = v_u_81
		local v774 = v772 / 580
		local v775 = math.min(v770, v774)
		v773.Scale = math.max(0.4, v775)
		v_u_713 = UDim2.new(1, -(v_u_12.EDGE + (not v771 and 0 or 272 * v770)), 1, -v_u_12.EDGE)
	end
end
local v_u_777 = nil
local v_u_778 = nil
local v_u_779 = nil
local v_u_780 = nil
local v_u_781 = nil
local function v_u_785() -- name: showHome
	-- upvalues: (ref) v_u_712, (copy) v_u_248, (ref) v_u_777, (ref) v_u_780, (ref) v_u_778, (ref) v_u_779, (ref) v_u_781, (copy) v_u_161, (copy) v_u_246, (copy) v_u_28, (copy) v_u_30, (copy) v_u_195, (copy) v_u_6, (copy) v_u_330, (ref) v_u_325
	v_u_712 = false
	v_u_248.Visible = false
	if v_u_777 then
		v_u_777.hide()
	end
	if v_u_780 then
		v_u_780.hide()
	end
	if v_u_778 then
		v_u_778.hide()
	end
	if v_u_779 then
		v_u_779.hide()
	end
	if v_u_781 then
		v_u_781.hide()
	end
	v_u_161.Visible = true
	v_u_246.BackgroundColor3 = v_u_28
	for v782, v783 in v_u_30 do
		local v784 = v_u_195[v783.id]
		if v784 then
			v784 = v_u_195[v783.id]:FindFirstChildOfClass("UIScale")
		end
		if not v784 then
			continue
		end
		v784.Scale = 0.6
		v_u_6:Create(v784, TweenInfo.new(0.34, Enum.EasingStyle.Back, Enum.EasingDirection.Out, 0, false, (v782 - 1) * 0.025), {
			["Scale"] = 1
		}):Play()
	end
	v_u_330()
	v_u_325(false)
end
local function v_u_787(p786) -- name: showApp
	-- upvalues: (ref) v_u_712, (copy) v_u_161, (ref) v_u_777, (ref) v_u_778, (ref) v_u_780, (ref) v_u_781, (copy) v_u_248, (copy) v_u_246, (copy) v_u_29, (ref) v_u_324, (ref) v_u_325, (copy) v_u_249, (copy) v_u_6, (copy) v_u_24
	v_u_712 = true
	v_u_161.Visible = false
	if v_u_777 then
		v_u_777.hide()
	end
	if v_u_778 then
		v_u_778.hide()
	end
	if v_u_780 then
		v_u_780.hide()
	end
	if v_u_781 then
		v_u_781.hide()
	end
	v_u_248.Visible = true
	v_u_246.BackgroundColor3 = v_u_29.ink
	v_u_324()
	v_u_325(true)
	if not p786 then
		v_u_249.Scale = 0.9
		v_u_6:Create(v_u_249, v_u_24, {
			["Scale"] = 1
		}):Play()
	end
end
local function v_u_793(p788, p789) -- name: setOpen
	-- upvalues: (ref) v_u_711, (copy) v_u_787, (ref) v_u_712, (copy) v_u_19, (copy) v_u_698, (copy) v_u_21, (ref) v_u_88, (copy) v_u_776, (copy) v_u_80, (copy) v_u_161, (ref) v_u_777, (ref) v_u_778, (ref) v_u_780, (ref) v_u_781, (copy) v_u_248, (copy) v_u_246, (copy) v_u_29, (ref) v_u_324, (ref) v_u_325, (copy) v_u_785, (ref) v_u_713, (copy) v_u_27, (copy) v_u_6, (copy) v_u_23
	if p788 == v_u_711 then
		if p788 and p789 then
			v_u_787(v_u_712)
		end
		return
	else
		v_u_711 = p788
		v_u_19:SetAttribute("PhoneOpen", p788)
		local v790 = v_u_698
		local v791 = not v_u_21
		if v791 then
			if v_u_88 == "Off" then
				v791 = false
			else
				v791 = not v_u_711
			end
		end
		v790.Visible = v791
		if p788 then
			v_u_776()
			v_u_80.Visible = true
			if p789 or v_u_712 then
				v_u_712 = true
				v_u_161.Visible = false
				if v_u_777 then
					v_u_777.hide()
				end
				if v_u_778 then
					v_u_778.hide()
				end
				if v_u_780 then
					v_u_780.hide()
				end
				if v_u_781 then
					v_u_781.hide()
				end
				v_u_248.Visible = true
				v_u_246.BackgroundColor3 = v_u_29.ink
				v_u_324()
				v_u_325(true)
			else
				v_u_785()
			end
			v_u_80.Position = v_u_713 + v_u_27
			v_u_6:Create(v_u_80, v_u_23, {
				["Position"] = v_u_713
			}):Play()
		else
			local v792 = v_u_6:Create(v_u_80, TweenInfo.new(0.22, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
				["Position"] = v_u_713 + v_u_27
			})
			v792.Completed:Connect(function()
				-- upvalues: (ref) v_u_711, (ref) v_u_80
				if not v_u_711 then
					v_u_80.Visible = false
				end
			end)
			v792:Play()
		end
	end
end
local function v_u_794() -- name: relayout
	-- upvalues: (ref) v_u_711, (copy) v_u_776, (copy) v_u_80, (ref) v_u_713
	if v_u_711 then
		v_u_776()
		v_u_80.Position = v_u_713
	end
end
local function v797(p795) -- name: watchSeat
	-- upvalues: (copy) v_u_794
	local v796 = p795:WaitForChild("Humanoid", 10)
	if v796 then
		v796:GetPropertyChangedSignal("SeatPart"):Connect(v_u_794)
	end
end
v_u_19.CharacterAdded:Connect(v797)
if v_u_19.Character then
	task.spawn(v797, v_u_19.Character)
end
if v_u_21 then
	local v802 = {
		["min"] = 0.5,
		["max"] = 1.5,
		["apply"] = nil,
		["apply"] = function(p798, p799, p800) -- name: apply
			-- upvalues: (ref) v_u_735, (ref) v_u_736, (ref) v_u_737, (ref) v_u_711, (copy) v_u_776, (copy) v_u_6, (copy) v_u_80, (ref) v_u_713
			v_u_735 = p798
			v_u_736 = p799
			v_u_737 = p800
			if v_u_711 then
				v_u_776()
				local v801 = {
					["Position"] = v_u_713
				}
				v_u_6:Create(v_u_80, TweenInfo.new(0), v801):Play()
			end
		end
	}
	v18.register("phone.main", v_u_80, "\224\184\161\224\184\183\224\184\173\224\184\150\224\184\183\224\184\173", false, v802)
	local v_u_803 = false
	v18.changed.Event:Connect(function(p804)
		-- upvalues: (ref) v_u_711, (ref) v_u_803, (copy) v_u_19, (copy) v_u_698, (copy) v_u_21, (ref) v_u_88, (copy) v_u_776, (copy) v_u_80, (ref) v_u_712, (copy) v_u_161, (ref) v_u_777, (ref) v_u_778, (ref) v_u_780, (ref) v_u_781, (copy) v_u_248, (copy) v_u_246, (copy) v_u_29, (ref) v_u_324, (ref) v_u_325, (copy) v_u_785, (ref) v_u_713, (copy) v_u_27, (copy) v_u_6, (copy) v_u_23, (copy) v_u_793
		if p804 and not v_u_711 then
			v_u_803 = true
			if v_u_711 ~= true then
				v_u_711 = true
				v_u_19:SetAttribute("PhoneOpen", true)
				local v805 = v_u_698
				local v806 = not v_u_21
				if v806 then
					if v_u_88 == "Off" then
						v806 = false
					else
						v806 = not v_u_711
					end
				end
				v805.Visible = v806
				v_u_776()
				v_u_80.Visible = true
				if v_u_712 then
					v_u_712 = true
					v_u_161.Visible = false
					if v_u_777 then
						v_u_777.hide()
					end
					if v_u_778 then
						v_u_778.hide()
					end
					if v_u_780 then
						v_u_780.hide()
					end
					if v_u_781 then
						v_u_781.hide()
					end
					v_u_248.Visible = true
					v_u_246.BackgroundColor3 = v_u_29.ink
					v_u_324()
					v_u_325(true)
				else
					v_u_785()
				end
				v_u_80.Position = v_u_713 + v_u_27
				v_u_6:Create(v_u_80, v_u_23, {
					["Position"] = v_u_713
				}):Play()
			end
		else
			if not p804 and v_u_803 then
				v_u_803 = false
				v_u_793(false)
			end
			return
		end
	end)
end
v_u_777 = require(v11:WaitForChild("JobsApp")).build(v156, v_u_785)
v_u_778 = require(v11:WaitForChild("RaceApp")).build(v156, v_u_785)
v_u_779 = require(v11:WaitForChild("ShopApp")).build(v156, v_u_785, function()
	-- upvalues: (copy) v_u_785, (copy) v_u_793
	v_u_785()
	v_u_793(false)
end)
v_u_780 = require(v11:WaitForChild("QuestApp")).build(v156, v_u_785, function(p807)
	-- upvalues: (ref) v_u_199, (ref) v_u_198
	v_u_199.Visible = p807 > 0
	v_u_198.Text = tostring(p807)
end)
v_u_781 = require(v11:WaitForChild("MapApp")).build(v156, v_u_785, function()
	-- upvalues: (ref) v_u_711
	return v_u_711
end, Vector2.new(282, 562))
local function v_u_809(p808) -- name: openApp
	-- upvalues: (copy) v_u_787, (ref) v_u_712, (copy) v_u_161, (copy) v_u_248, (copy) v_u_246, (copy) v_u_29, (ref) v_u_777, (ref) v_u_778, (ref) v_u_779, (ref) v_u_780, (ref) v_u_781, (ref) v_u_325, (copy) v_u_793, (copy) v_u_15
	if p808 == "delivery" then
		v_u_787()
		return
	elseif p808 == "jobs" or (p808 == "race" or (p808 == "shop" or (p808 == "quests" or p808 == "map"))) then
		v_u_712 = false
		v_u_161.Visible = false
		v_u_248.Visible = false
		v_u_246.BackgroundColor3 = v_u_29.ink
		v_u_777.hide()
		v_u_778.hide()
		v_u_779.hide()
		v_u_780.hide()
		v_u_781.hide()
		v_u_325(false)
		if p808 == "jobs" then
			v_u_777.show()
			return
		elseif p808 == "race" then
			v_u_778.show()
			return
		elseif p808 == "quests" then
			v_u_780.show()
			return
		elseif p808 == "map" then
			v_u_781.show()
		else
			v_u_779.show()
		end
	else
		v_u_793(false)
		v_u_15.launch(p808)
		return
	end
end
local v_u_810 = v_u_322
local v_u_811 = v_u_713
local v_u_812 = v_u_324
local v_u_813 = v_u_780
local v_u_814 = v_u_777
local v_u_815 = v_u_711
local v_u_816 = v_u_781
local v_u_817 = v_u_325
local v_u_818 = v_u_778
local v_u_819 = v_u_712
for v_u_820, v821 in v_u_195 do
	v821.Activated:Connect(function()
		-- upvalues: (copy) v_u_809, (copy) v_u_820
		v_u_809(v_u_820)
	end)
end
v178.Activated:Connect(function()
	-- upvalues: (copy) v_u_787
	v_u_787()
end)
v256.Activated:Connect(v_u_785)
v244.Activated:Connect(function()
	-- upvalues: (ref) v_u_819, (ref) v_u_814, (ref) v_u_818, (ref) v_u_813, (ref) v_u_816, (copy) v_u_785
	if v_u_819 or (v_u_814.isShown() or (v_u_818.isShown() or (v_u_813.isShown() or v_u_816.isShown()))) then
		v_u_785()
	end
end)
v158.Activated:Connect(function()
	-- upvalues: (copy) v_u_793
	v_u_793(false)
end)
v705.Activated:Connect(function()
	-- upvalues: (ref) v_u_815, (copy) v_u_787, (ref) v_u_819, (copy) v_u_19, (copy) v_u_698, (copy) v_u_21, (ref) v_u_88, (copy) v_u_776, (copy) v_u_80, (copy) v_u_161, (ref) v_u_814, (ref) v_u_818, (ref) v_u_813, (ref) v_u_816, (copy) v_u_248, (copy) v_u_246, (copy) v_u_29, (ref) v_u_812, (ref) v_u_817, (ref) v_u_811, (copy) v_u_27, (copy) v_u_6, (copy) v_u_23
	if v_u_815 == true then
		v_u_787(v_u_819)
	else
		v_u_815 = true
		v_u_19:SetAttribute("PhoneOpen", true)
		local v822 = v_u_698
		local v823 = not v_u_21
		if v823 then
			if v_u_88 == "Off" then
				v823 = false
			else
				v823 = not v_u_815
			end
		end
		v822.Visible = v823
		v_u_776()
		v_u_80.Visible = true
		v_u_819 = true
		v_u_161.Visible = false
		if v_u_814 then
			v_u_814.hide()
		end
		if v_u_818 then
			v_u_818.hide()
		end
		if v_u_813 then
			v_u_813.hide()
		end
		if v_u_816 then
			v_u_816.hide()
		end
		v_u_248.Visible = true
		v_u_246.BackgroundColor3 = v_u_29.ink
		v_u_812()
		v_u_817(true)
		v_u_80.Position = v_u_811 + v_u_27
		v_u_6:Create(v_u_80, v_u_23, {
			["Position"] = v_u_811
		}):Play()
	end
end)
v_u_15.changed.Event:Connect(function(p824)
	-- upvalues: (ref) v_u_815, (copy) v_u_19, (copy) v_u_698, (copy) v_u_21, (ref) v_u_88, (copy) v_u_776, (copy) v_u_80, (ref) v_u_819, (copy) v_u_161, (ref) v_u_814, (ref) v_u_818, (ref) v_u_813, (ref) v_u_816, (copy) v_u_248, (copy) v_u_246, (copy) v_u_29, (ref) v_u_812, (ref) v_u_817, (copy) v_u_785, (ref) v_u_811, (copy) v_u_27, (copy) v_u_6, (copy) v_u_23, (copy) v_u_793
	if p824 == "open" then
		if v_u_815 ~= true then
			v_u_815 = true
			v_u_19:SetAttribute("PhoneOpen", true)
			local v825 = v_u_698
			local v826 = not v_u_21
			if v826 then
				if v_u_88 == "Off" then
					v826 = false
				else
					v826 = not v_u_815
				end
			end
			v825.Visible = v826
			v_u_776()
			v_u_80.Visible = true
			if v_u_819 then
				v_u_819 = true
				v_u_161.Visible = false
				if v_u_814 then
					v_u_814.hide()
				end
				if v_u_818 then
					v_u_818.hide()
				end
				if v_u_813 then
					v_u_813.hide()
				end
				if v_u_816 then
					v_u_816.hide()
				end
				v_u_248.Visible = true
				v_u_246.BackgroundColor3 = v_u_29.ink
				v_u_812()
				v_u_817(true)
			else
				v_u_785()
			end
			v_u_80.Position = v_u_811 + v_u_27
			v_u_6:Create(v_u_80, v_u_23, {
				["Position"] = v_u_811
			}):Play()
		end
	elseif p824 == "close" then
		v_u_793(false)
	else
		v_u_793(not v_u_815)
	end
end)
v_u_7.InputBegan:Connect(function(p827, p828)
	-- upvalues: (ref) v_u_815, (copy) v_u_793
	if not p828 and (p827.KeyCode == Enum.KeyCode.Escape and v_u_815) then
		v_u_793(false)
	end
end)
local function v834() -- name: onChanged
	-- upvalues: (ref) v_u_88, (copy) v_u_19, (ref) v_u_89, (copy) v_u_9, (ref) v_u_90, (copy) v_u_698, (copy) v_u_21, (ref) v_u_815, (copy) v_u_710, (copy) v_u_699, (copy) v_u_6, (copy) v_u_24, (copy) v_u_31, (ref) v_u_284, (copy) v_u_787, (ref) v_u_819, (copy) v_u_776, (copy) v_u_80, (copy) v_u_161, (ref) v_u_814, (ref) v_u_818, (ref) v_u_813, (ref) v_u_816, (copy) v_u_248, (copy) v_u_246, (copy) v_u_29, (ref) v_u_812, (ref) v_u_817, (ref) v_u_811, (copy) v_u_27, (copy) v_u_23
	local v829 = v_u_88
	v_u_88 = v_u_19:GetAttribute("DeliveryState") or "Off"
	v_u_89 = v_u_9.decode(v_u_19:GetAttribute("DeliveryJob"))
	v_u_90 = v_u_19:GetAttribute("DeliveryArrived") == true
	local v830 = v_u_698
	local v831 = not v_u_21
	if v831 then
		if v_u_88 == "Off" then
			v831 = false
		else
			v831 = not v_u_815
		end
	end
	v830.Visible = v831
	v_u_710()
	if v_u_88 ~= v829 and v_u_88 ~= "Off" then
		v_u_699.Scale = 0.85
		v_u_6:Create(v_u_699, v_u_24, {
			["Scale"] = 1
		}):Play()
	end
	if v_u_88 == "Offer" and v829 ~= "Offer" then
		v_u_31:Play()
		v_u_284 = "jobs"
		if v_u_815 == true then
			v_u_787(v_u_819)
		else
			v_u_815 = true
			v_u_19:SetAttribute("PhoneOpen", true)
			local v832 = v_u_698
			local v833 = not v_u_21
			if v833 then
				if v_u_88 == "Off" then
					v833 = false
				else
					v833 = not v_u_815
				end
			end
			v832.Visible = v833
			v_u_776()
			v_u_80.Visible = true
			v_u_819 = true
			v_u_161.Visible = false
			if v_u_814 then
				v_u_814.hide()
			end
			if v_u_818 then
				v_u_818.hide()
			end
			if v_u_813 then
				v_u_813.hide()
			end
			if v_u_816 then
				v_u_816.hide()
			end
			v_u_248.Visible = true
			v_u_246.BackgroundColor3 = v_u_29.ink
			v_u_812()
			v_u_817(true)
			v_u_80.Position = v_u_811 + v_u_27
			v_u_6:Create(v_u_80, v_u_23, {
				["Position"] = v_u_811
			}):Play()
		end
	else
		if v_u_88 == "ToHome" and v829 == "ToShop" or v829 == "ToHome" and v_u_88 == "Searching" then
			v_u_31:Play()
		end
		if v_u_815 and v_u_819 then
			v_u_812()
		end
		v_u_817(true)
		return
	end
end
local function _(p835) -- name: selectAppTab
	-- upvalues: (ref) v_u_284, (ref) v_u_812, (ref) v_u_817
	v_u_284 = p835
	v_u_812()
	v_u_817(true)
end
for _, v836 in {
	"DeliveryState",
	"DeliveryJob",
	"DeliveryJobs",
	"DeliveryEarned",
	"DeliveryMode",
	"DeliveryBox",
	"DeliveryRating",
	"DeliveryHistory",
	"Job"
} do
	v_u_19:GetAttributeChangedSignal(v836):Connect(v834)
end
v_u_19:GetAttributeChangedSignal("DeliveryArrived"):Connect(function()
	-- upvalues: (ref) v_u_90, (ref) v_u_88, (copy) v_u_19, (ref) v_u_89, (copy) v_u_9, (copy) v_u_31, (ref) v_u_284, (ref) v_u_815, (copy) v_u_787, (ref) v_u_819, (copy) v_u_698, (copy) v_u_21, (copy) v_u_776, (copy) v_u_80, (copy) v_u_161, (ref) v_u_814, (ref) v_u_818, (ref) v_u_813, (ref) v_u_816, (copy) v_u_248, (copy) v_u_246, (copy) v_u_29, (ref) v_u_812, (ref) v_u_817, (ref) v_u_811, (copy) v_u_27, (copy) v_u_6, (copy) v_u_23
	local v837 = v_u_90
	v_u_88 = v_u_19:GetAttribute("DeliveryState") or "Off"
	v_u_89 = v_u_9.decode(v_u_19:GetAttribute("DeliveryJob"))
	v_u_90 = v_u_19:GetAttribute("DeliveryArrived") == true
	if v_u_90 and not v837 then
		v_u_31:Play()
		v_u_284 = "jobs"
		if v_u_815 == true then
			v_u_787(v_u_819)
		else
			v_u_815 = true
			v_u_19:SetAttribute("PhoneOpen", true)
			local v838 = v_u_698
			local v839 = not v_u_21
			if v839 then
				if v_u_88 == "Off" then
					v839 = false
				else
					v839 = not v_u_815
				end
			end
			v838.Visible = v839
			v_u_776()
			v_u_80.Visible = true
			v_u_819 = true
			v_u_161.Visible = false
			if v_u_814 then
				v_u_814.hide()
			end
			if v_u_818 then
				v_u_818.hide()
			end
			if v_u_813 then
				v_u_813.hide()
			end
			if v_u_816 then
				v_u_816.hide()
			end
			v_u_248.Visible = true
			v_u_246.BackgroundColor3 = v_u_29.ink
			v_u_812()
			v_u_817(true)
			v_u_80.Position = v_u_811 + v_u_27
			v_u_6:Create(v_u_80, v_u_23, {
				["Position"] = v_u_811
			}):Play()
		end
	elseif v_u_90 ~= v837 and (v_u_815 and v_u_819) then
		v_u_812()
	end
	v_u_817(true)
end)
v834()
local v_u_840 = Instance.new("Sound")
v_u_840.Name = "DeliveryCancel"
v_u_840.SoundId = "rbxasset://sounds/electronicpingshort.wav"
v_u_840.PlaybackSpeed = 0.55
v_u_840.Volume = 0.7
v_u_840.Parent = v5
local v_u_841 = false
local function v_u_853() -- name: showAlert
	-- upvalues: (copy) v_u_19, (copy) v_u_9, (copy) v_u_271, (copy) v_u_273, (copy) v_u_29, (copy) v_u_272, (copy) v_u_277, (ref) v_u_841, (copy) v_u_840, (ref) v_u_284, (ref) v_u_815, (copy) v_u_787, (ref) v_u_819, (copy) v_u_698, (copy) v_u_21, (ref) v_u_88, (copy) v_u_776, (copy) v_u_80, (copy) v_u_161, (ref) v_u_814, (ref) v_u_818, (ref) v_u_813, (ref) v_u_816, (copy) v_u_248, (copy) v_u_246, (ref) v_u_812, (ref) v_u_817, (ref) v_u_811, (copy) v_u_27, (copy) v_u_6, (copy) v_u_23, (copy) v_u_267, (copy) v_u_265, (copy) v_u_264, (copy) v_u_270
	local v842 = v_u_19:GetAttribute("DeliveryCooldownSecs") or v_u_9.CANCEL_COOLDOWN[1]
	local v843 = v_u_19:GetAttribute("DeliveryCooldownWhy") == "skip"
	v_u_271.Text = v843 and "\224\184\132\224\184\184\224\184\147\224\184\130\224\185\137\224\184\178\224\184\161\224\184\135\224\184\178\224\184\153\224\184\153\224\184\181\224\185\137" or "\224\184\132\224\184\184\224\184\147\224\185\132\224\184\148\224\185\137\224\184\162\224\184\129\224\185\128\224\184\165\224\184\180\224\184\129\224\184\135\224\184\178\224\184\153"
	local v844 = v_u_19:GetAttribute(v843 and "DeliverySkipStreak" or "DeliveryCancelStreak") or 1
	if v844 >= 2 then
		v_u_273.Text = ((v843 and "\224\184\130\224\185\137\224\184\178\224\184\161\224\184\135\224\184\178\224\184\153\224\184\149\224\184\180\224\184\148\224\184\129\224\184\177\224\184\153" or "\224\184\162\224\184\129\224\185\128\224\184\165\224\184\180\224\184\129\224\184\149\224\184\180\224\184\148\224\184\129\224\184\177\224\184\153") .. " %d \224\184\132\224\184\163\224\184\177\224\185\137\224\184\135: \224\184\158\224\184\177\224\184\129\224\184\163\224\184\177\224\184\154\224\184\135\224\184\178\224\184\153\224\184\153\224\184\178\224\184\153\224\184\130\224\184\182\224\185\137\224\184\153\224\185\128\224\184\155\224\185\135\224\184\153 %d \224\184\167\224\184\180\224\184\153\224\184\178\224\184\151\224\184\181"):format(v844, v842)
		v_u_273.TextColor3 = v_u_29.red
	elseif v843 then
		v_u_273.Text = ("\224\185\132\224\184\161\224\185\136\224\184\165\224\184\148\224\184\148\224\184\178\224\184\167 \194\183 \224\184\130\224\185\137\224\184\178\224\184\161\224\184\173\224\184\181\224\184\129\224\184\132\224\184\163\224\184\177\224\185\137\224\184\135\224\184\149\224\184\180\224\184\148\224\184\129\224\184\177\224\184\153\224\184\136\224\184\176\224\184\158\224\184\177\224\184\129 %d \224\184\167\224\184\180\224\184\153\224\184\178\224\184\151\224\184\181"):format(v_u_9.SKIP_COOLDOWN[2])
		v_u_273.TextColor3 = v_u_29.dim
	else
		local v845 = v_u_273
		local v846 = v_u_9.CANCEL_RATING_CUT * 100
		v845.Text = ("\224\184\148\224\184\178\224\184\167\224\184\165\224\184\148 %d%% \194\183 \224\184\162\224\184\129\224\185\128\224\184\165\224\184\180\224\184\129\224\184\173\224\184\181\224\184\129\224\184\132\224\184\163\224\184\177\224\185\137\224\184\135\224\184\149\224\184\180\224\184\148\224\184\129\224\184\177\224\184\153\224\184\136\224\184\176\224\184\158\224\184\177\224\184\129 %d \224\184\167\224\184\180\224\184\153\224\184\178\224\184\151\224\184\181"):format(math.round(v846), v_u_9.CANCEL_COOLDOWN[2])
		v_u_273.TextColor3 = v_u_29.dim
	end
	local v847 = v_u_272
	local v848 = (v_u_19:GetAttribute("DeliveryCooldownEnd") or 0) - workspace:GetServerTimeNow()
	v847.Text = ("\224\184\163\224\184\177\224\184\154\224\184\135\224\184\178\224\184\153\224\185\131\224\184\171\224\184\161\224\185\136\224\185\132\224\184\148\224\185\137\224\185\131\224\184\153\224\184\173\224\184\181\224\184\129 %d \224\184\167\224\184\180\224\184\153\224\184\178\224\184\151\224\184\181"):format((math.ceil(v848)))
	v_u_277.Size = UDim2.fromScale(1, 1)
	v_u_841 = true
	v_u_840:Play()
	v_u_284 = "jobs"
	if v_u_815 == true then
		v_u_787(v_u_819)
	else
		v_u_815 = true
		v_u_19:SetAttribute("PhoneOpen", true)
		local v849 = v_u_698
		local v850 = not v_u_21
		if v850 then
			if v_u_88 == "Off" then
				v850 = false
			else
				v850 = not v_u_815
			end
		end
		v849.Visible = v850
		v_u_776()
		v_u_80.Visible = true
		v_u_819 = true
		v_u_161.Visible = false
		if v_u_814 then
			v_u_814.hide()
		end
		if v_u_818 then
			v_u_818.hide()
		end
		if v_u_813 then
			v_u_813.hide()
		end
		if v_u_816 then
			v_u_816.hide()
		end
		v_u_248.Visible = true
		v_u_246.BackgroundColor3 = v_u_29.ink
		v_u_812()
		v_u_817(true)
		v_u_80.Position = v_u_811 + v_u_27
		v_u_6:Create(v_u_80, v_u_23, {
			["Position"] = v_u_811
		}):Play()
	end
	v_u_267.Visible = true
	v_u_267.Position = v_u_265
	v_u_267.Rotation = 0
	local v851 = {
		["Position"] = v_u_264
	}
	v_u_6:Create(v_u_267, TweenInfo.new(0.45, Enum.EasingStyle.Back, Enum.EasingDirection.Out), v851):Play()
	task.delay(0.45, function()
		-- upvalues: (ref) v_u_841, (ref) v_u_6, (ref) v_u_267
		for _, v852 in {
			-4,
			4,
			-3,
			3,
			-1.5,
			1.5,
			0
		} do
			if not v_u_841 then
				break
			end
			v_u_6:Create(v_u_267, TweenInfo.new(0.05), {
				["Rotation"] = v852
			}):Play()
			task.wait(0.05)
		end
	end)
	v_u_270.Scale = 1
	v_u_6:Create(v_u_270, TweenInfo.new(0.45, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, 5, true), {
		["Scale"] = 1.18
	}):Play()
end
local function v_u_856() -- name: hideAlert
	-- upvalues: (ref) v_u_841, (copy) v_u_6, (copy) v_u_267, (copy) v_u_265
	v_u_841 = false
	local v854 = {
		["Position"] = v_u_265
	}
	local v855 = v_u_6:Create(v_u_267, TweenInfo.new(0.3, Enum.EasingStyle.Quad, Enum.EasingDirection.In), v854)
	v855.Completed:Connect(function()
		-- upvalues: (ref) v_u_841, (ref) v_u_267
		if not v_u_841 then
			v_u_267.Visible = false
		end
	end)
	v855:Play()
end
v_u_19:GetAttributeChangedSignal("DeliveryCooldownEnd"):Connect(function()
	-- upvalues: (copy) v_u_19, (copy) v_u_853
	if (v_u_19:GetAttribute("DeliveryCooldownEnd") or 0) - workspace:GetServerTimeNow() > 0.5 then
		v_u_853()
	end
end)
local v_u_857 = 0
v4.Heartbeat:Connect(function()
	-- upvalues: (ref) v_u_841, (ref) v_u_857, (copy) v_u_19, (copy) v_u_856, (copy) v_u_9, (copy) v_u_272, (copy) v_u_277
	local v858 = os.clock()
	if v_u_841 and v858 >= v_u_857 then
		v_u_857 = v858 + 0.05
		local v859 = (v_u_19:GetAttribute("DeliveryCooldownEnd") or 0) - workspace:GetServerTimeNow()
		if v859 <= 0 then
			v_u_856()
		else
			local v860 = v_u_19:GetAttribute("DeliveryCooldownSecs") or v_u_9.CANCEL_COOLDOWN[1]
			v_u_272.Text = ("\224\184\163\224\184\177\224\184\154\224\184\135\224\184\178\224\184\153\224\185\131\224\184\171\224\184\161\224\185\136\224\185\132\224\184\148\224\185\137\224\185\131\224\184\153\224\184\173\224\184\181\224\184\129 %d \224\184\167\224\184\180\224\184\153\224\184\178\224\184\151\224\184\181"):format((math.ceil(v859)))
			local v861 = v_u_277
			local v862 = UDim2.fromScale
			local v863 = v859 / v860
			v861.Size = v862(math.clamp(v863, 0, 1), 1)
		end
	else
		return
	end
end)
local function v_u_868(p864) -- name: widgetLine
	-- upvalues: (ref) v_u_88, (copy) v_u_19, (ref) v_u_89, (copy) v_u_8, (ref) v_u_90, (copy) v_u_29, (copy) v_u_9, (copy) v_u_43
	if v_u_88 == "Searching" and (v_u_19:GetAttribute("DeliveryCooldownEnd") or 0) - workspace:GetServerTimeNow() > 0 then
		local v865 = (v_u_19:GetAttribute("DeliveryCooldownEnd") or 0) - workspace:GetServerTimeNow()
		return ("\224\184\158\224\184\177\224\184\129\224\184\163\224\184\177\224\184\154\224\184\135\224\184\178\224\184\153 %d \224\184\167\224\184\180\224\184\153\224\184\178\224\184\151\224\184\181"):format((math.ceil(v865)))
	end
	if v_u_88 == "Searching" then
		return "Finding jobs" .. p864
	end
	if v_u_88 == "Offer" and v_u_89 then
		return ("New job! %s"):format(v_u_8.formatCash(v_u_89.fee))
	end
	if v_u_88 ~= "ToShop" and v_u_88 ~= "ToHome" or not v_u_89 then
		return "Offline \194\183 tap to open the app"
	end
	if v_u_90 then
		return "You\'re here! Tap to confirm"
	end
	local v866 = v_u_89.kind
	local v867
	if v866 == "ride" then
		local _ = v_u_29.ride
		v867 = "Customer"
	elseif v866 == "parcel" then
		local _ = v_u_29.parcel
		v867 = "Parcel"
	else
		local _ = v_u_29.shop
		v867 = "Food"
	end
	return ("%s \194\183 %s to go"):format((v_u_88 == "ToShop" and "Pick up " or "Drop off ") .. v867:lower(), v_u_9.distanceText((v_u_43())))
end
local v_u_869 = 0
local v_u_870 = 0
v4.Heartbeat:Connect(function()
	-- upvalues: (ref) v_u_870, (copy) v_u_1, (copy) v_u_19, (ref) v_u_869, (copy) v_u_703, (copy) v_u_704, (ref) v_u_197, (ref) v_u_88, (ref) v_u_90, (ref) v_u_815, (ref) v_u_811, (copy) v_u_776, (copy) v_u_6, (copy) v_u_80, (copy) v_u_23, (copy) v_u_230, (ref) v_u_819, (copy) v_u_170, (copy) v_u_172, (copy) v_u_175, (copy) v_u_868, (copy) v_u_176, (copy) v_u_8, (copy) v_u_181, (copy) v_u_701, (copy) v_u_9, (copy) v_u_702, (copy) v_u_320, (ref) v_u_89, (copy) v_u_43, (copy) v_u_446, (copy) v_u_12, (copy) v_u_29, (ref) v_u_810
	local v871 = os.clock()
	if v871 >= v_u_870 then
		v_u_870 = v871 + 0.1
		local v872 = workspace:GetServerTimeNow()
		local v873 = v_u_1.ClockTime
		local v874 = math.floor(v873)
		local v875 = v873 % 1 * 60
		local v876 = ("%02d:%02d"):format(v874, (math.floor(v875)))
		local v877 = v_u_19:GetAttribute("DeliveryProgress") or 0
		local v878 = v_u_19:GetAttribute("DeliveryHint")
		v_u_869 = (v_u_869 + 0.25) % 4
		local v879 = v_u_869
		local v880 = string.rep(".", (math.floor(v879)))
		v_u_703.Visible = v877 > 0
		v_u_704.Size = UDim2.fromScale(v877, 1)
		v_u_197.Visible = v_u_88 == "Offer" and true or v_u_90
		if v_u_815 then
			local v881 = v_u_811
			v_u_776()
			if v_u_811 ~= v881 then
				v_u_6:Create(v_u_80, v_u_23, {
					["Position"] = v_u_811
				}):Play()
			end
			v_u_230.Text = v876
			if not v_u_819 then
				v_u_170.Text = v876
				local v882 = v_u_172
				local v883
				if v873 >= 5 and v873 < 11 then
					v883 = "Good morning"
				elseif v873 >= 11 and v873 < 13 or v873 >= 13 and v873 < 17 then
					v883 = "Good afternoon"
				else
					local _ = v873 >= 17 and v873 < 19
					v883 = "Good evening"
				end
				v882.Text = v883 .. "  " .. v_u_19.DisplayName
				v_u_175.Text = v_u_868(v880)
				v_u_176.Text = ("%s jobs done \194\183 total %s"):format(v_u_8.formatNumber(v_u_19:GetAttribute("DeliveryJobs") or 0), v_u_8.formatCash(v_u_19:GetAttribute("DeliveryEarned") or 0))
				v_u_181.Text = v_u_8.formatCash(v_u_19:GetAttribute("Cash") or 0)
			end
		end
		if v_u_88 == "Searching" then
			v_u_701.Text = v_u_9.APP_NAME
			local v884 = (v_u_19:GetAttribute("DeliveryCooldownEnd") or 0) - v872
			if v884 > 0 then
				v_u_702.Text = ("\224\184\158\224\184\177\224\184\129\224\184\163\224\184\177\224\184\154\224\184\135\224\184\178\224\184\153 %d \224\184\167\224\184\180\224\184\153\224\184\178\224\184\151\224\184\181"):format((math.ceil(v884)))
				if v_u_320.searching then
					v_u_320.searching.Text = ("\224\184\158\224\184\177\224\184\129\224\184\163\224\184\177\224\184\154\224\184\135\224\184\178\224\184\153 %d \224\184\167\224\184\180\224\184\153\224\184\178\224\184\151\224\184\181"):format((math.ceil(v884)))
					return
				end
			else
				v_u_702.Text = "Finding jobs" .. v880
				if v_u_320.searching then
					v_u_320.searching.Text = "Finding jobs near you" .. v880
					return
				end
			end
		elseif v_u_88 == "Offer" and v_u_89 then
			local v885 = (v_u_89.offerEnds or v872) - v872
			v_u_701.Text = ("New job %s"):format(v_u_8.formatCash(v_u_89.fee))
			local v886 = v_u_702
			local v887 = v_u_89.kind == "ride" and "Ride" or v_u_89.shop.name
			local v888 = math.ceil(v885)
			v886.Text = ("%s \194\183 %d s left"):format(v887, (math.max(0, v888)))
			if v_u_320.offerBar then
				local v889 = v_u_320.offerBar
				local v890 = UDim2.fromScale
				local v891 = v885 / v_u_9.OFFER_TIME
				v889.Size = v890(math.clamp(v891, 0, 1), 1)
				return
			end
		elseif (v_u_88 == "ToShop" or v_u_88 == "ToHome") and v_u_89 then
			local v892 = v_u_89.kind == "ride"
			local v893 = v_u_9.distanceText((v_u_43()))
			if v_u_88 == "ToShop" then
				local v894 = v_u_701
				local v895
				if v892 then
					v895 = ("Pick up %s"):format(v_u_89.customer)
				else
					v895 = ("Pick up %s: %s"):format(select(3, v_u_446(v_u_89.kind)), v_u_89.shop.name)
				end
				v894.Text = v895
			else
				local v896 = v_u_701
				local v897
				if v892 then
					v897 = ("Deliver %s \194\183 %s"):format(v_u_89.customer, v_u_89.home.name)
				else
					v897 = ("Drop off: %s \194\183 %s"):format(v_u_89.customer, v_u_89.home.area)
				end
				v896.Text = v897
			end
			local v898 = v_u_702
			local v899
			if v878 then
				v899 = v878 .. (v_u_90 and "" or v880)
			else
				v899 = ("%s \194\183 %s"):format(v893, "No time limit")
			end
			v898.Text = v899
			v_u_702.TextColor3 = v_u_12.TEXT_DIM
			if v_u_320.distance then
				v_u_320.distance.Text = v_u_90 and "You\'re here!" or "Distance " .. v893
				v_u_320.time.Text = "No time limit"
				v_u_320.time.TextColor3 = v_u_29.dim
				v_u_320.hint.Text = (not v878 or v_u_90) and "" or v878 .. v880
			end
			if v_u_320.slider then
				local v900 = v877 > 0
				local v901 = v_u_90
				if v901 then
					v901 = not v900
				end
				local v902 = v_u_320.slider.set
				local v903
				if v901 then
					v903 = v_u_320.confirmText
				else
					v903 = not v900 and "Park in the circle at the destination first" or "One moment" .. v880
				end
				v902(v901, v903, v_u_320.sliderColors)
			end
			if v_u_320.cancel and (v871 - v_u_810 > 3 and v_u_320.cancel.Text ~= "Cancel job") then
				v_u_320.cancel.Text = "Cancel job"
			end
		end
	end
end)
local v_u_904 = require(v3:WaitForChild("UiGuardShared"))
local v_u_905 = v3:WaitForChild(v_u_8.REMOTES):WaitForChild(v_u_904.REMOTE)
local v906 = {
	["Phone"] = v_u_78,
	["Dock"] = v_u_80,
	["Body"] = v83,
	["Screen"] = v156,
	["Home"] = v_u_161,
	["Widget"] = v173,
	["Wallet"] = v179,
	["Apps"] = v_u_189,
	["StatusBar"] = v229,
	["App"] = v_u_248,
	["Header"] = v251,
	["Tabs"] = v280
}
local v_u_907 = {}
for _, v908 in v906 do
	for _, v909 in v908:GetChildren() do
		v_u_907[v909] = true
	end
end
local v_u_910 = {}
local v_u_911 = 0
local function v_u_918(p912, p913, p914) -- name: report
	-- upvalues: (copy) v_u_910, (ref) v_u_911, (copy) v_u_904, (copy) v_u_10, (copy) v_u_905
	if not v_u_910[p913] and (v_u_911 < v_u_904.MAX_INSIDE and p913.Parent) then
		v_u_910[p913] = true
		v_u_911 = v_u_911 + 1
		local v915 = v_u_904.describe(p913)
		v915.name = v_u_904.cut(("Phone/%s/%s"):format(p912, p913.Name))
		if p914 then
			v915.texts = { v_u_904.cut(p914) }
		end
		v915.soft = true
		v915.phone = true
		v915.shown = v_u_904.onScreen(p913)
		local v916 = v_u_10.fire
		local v917 = v_u_905
		pcall(v916, v917, "Found", v915)
	end
end
for v_u_919, v920 in v906 do
	v920.ChildAdded:Connect(function(p921)
		-- upvalues: (copy) v_u_907, (copy) v_u_918, (copy) v_u_919
		if not v_u_907[p921] and p921:IsA("GuiBase2d") then
			task.delay(1, v_u_918, v_u_919, p921)
		end
	end)
end
local v922 = {
	[v259] = v_u_9.APP_NAME,
	[v174] = v_u_9.APP_NAME,
	[v180] = "Wallet"
}
for _, v923 in v196 do
	v922[v923] = v923.Text
end
for v_u_924, v_u_925 in v922 do
	v_u_924:GetPropertyChangedSignal("Text"):Connect(function()
		-- upvalues: (copy) v_u_924, (copy) v_u_925, (copy) v_u_918
		if v_u_924.Text ~= v_u_925 then
			v_u_918("Text", v_u_924, v_u_924.Text)
		end
	end)
end
local v_u_926 = v_u_189.Position
v_u_189:GetPropertyChangedSignal("Position"):Connect(function()
	-- upvalues: (copy) v_u_189, (copy) v_u_926, (copy) v_u_918
	if v_u_189.Position ~= v_u_926 then
		local v927 = v_u_918
		local v928 = v_u_189
		local v929 = v_u_926
		local v930 = tostring(v929)
		local v931 = v_u_189.Position
		v927("Moved", v928, ("Apps moved: %s -> %s"):format(v930, (tostring(v931))))
	end
end)