-- Path: ReplicatedStorage/GameUI/TuneDock
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

return {
	["set"] = false,
	["top"] = 16,
	["bottom"] = 16,
	["right"] = 16,
	["left"] = 0,
	["anchor"] = "right",
	["max"] = 1,
	["insets"] = nil,
	["ecu"] = nil,
	["short"] = false,
	["size"] = nil
}