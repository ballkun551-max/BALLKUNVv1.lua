-- Path: StarterPlayer/PlayerModule/ControlModule/TouchAbilities
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v1 = game:GetService("Players")
local v2 = require(script.Parent.Parent:WaitForChild("CommonUtils"))
local v_u_3 = require(script.Parent:WaitForChild("AvatarAbilitiesInterface")).get(v1.LocalPlayer)
local v_u_4 = require(script.Parent:WaitForChild("InputSlots"))
local v_u_5 = require(script.Parent:WaitForChild("AbilityButton"))
local v_u_6 = v2.get("FlagUtil").getUserFlag("UserAbilitiesUserInterfaceA")
local v_u_7 = {
	{
		["small"] = { 72, 60, 60 },
		["large"] = { 92, 112, 112 }
	},
	{
		["small"] = { 44, 132, 132 },
		["large"] = { 56, 200, 200 }
	},
	{
		["small"] = { 44, 132, 16 },
		["large"] = { 56, 200, 60 }
	},
	{
		["small"] = { 44, 16, 132 },
		["large"] = { 56, 60, 200 }
	},
	{
		["small"] = { 44, 156, 74 },
		["large"] = { 56, 228, 130 }
	},
	{
		["small"] = { 44, 74, 156 },
		["large"] = { 56, 130, 228 }
	},
	{
		["small"] = { 44, 16, 16 },
		["large"] = { 56, 60, 60 }
	}
}
local v_u_8 = {}
v_u_8.__index = v_u_8
function v_u_8.new(p9) -- name: new
	-- upvalues: (copy) v_u_8
	local v10 = v_u_8
	local v11 = setmetatable({}, v10)
	v11.parentUIFrame = p9
	v11.managedButtons = {}
	v11.connections = {}
	v11.created = false
	v11.enabled = false
	v11.enabledChangedEvent = Instance.new("BindableEvent")
	return v11
end
function v_u_8.Enable(p12, p13) -- name: Enable
	if p12.enabled ~= p13 then
		p12.enabled = p13
		if p13 and not p12.created then
			p12:Create()
			p12.created = true
		end
		p12.enabledChangedEvent:Fire()
	end
end
function v_u_8.Create(p_u_14) -- name: Create
	-- upvalues: (copy) v_u_3, (copy) v_u_4, (copy) v_u_7, (copy) v_u_6, (copy) v_u_5
	if p_u_14.parentUIFrame then
		local function v24() -- name: CreateButtons
			-- upvalues: (copy) p_u_14, (ref) v_u_3, (ref) v_u_4, (ref) v_u_7, (ref) v_u_6, (ref) v_u_5
			for _, v15 in p_u_14.managedButtons do
				v15:Destroy()
			end
			p_u_14.managedButtons = {}
			if v_u_3:isEnabled() then
				for v16, v17 in v_u_4.GetSlotMap() do
					local v18 = v_u_4.GetActionInSlot(v16)
					if not v17 or (not v18 or (v16 > #v_u_7 or not v_u_6 and v16 ~= 1)) then
						continue
					end
					local v19 = v_u_3:GetAbilityConfig(v17)
					local v20 = p_u_14.managedButtons
					local v21 = v_u_5.create
					local v22 = p_u_14
					local v23 = v_u_7[v16]
					table.insert(v20, v21(v22, v17, v19, v18, v23, false))
				end
			end
		end
		v24()
		local v25 = p_u_14.connections
		local v26 = v_u_4.GetSlotMapChangedSignal()
		table.insert(v25, v26:Connect(v24))
		local v27 = p_u_14.connections
		local v28 = v_u_3:GetEnabledChangedSignal()
		table.insert(v27, v28:Connect(v24))
	end
end
function v_u_8.Destroy(p29) -- name: Destroy
	for _, v30 in p29.connections do
		v30:Disconnect()
	end
	p29.connections = {}
	for _, v31 in p29.managedButtons do
		v31:Destroy()
	end
	p29.managedButtons = {}
	p29.enabledChangedEvent:Destroy()
	p29.created = false
	p29.enabled = false
end
return v_u_8