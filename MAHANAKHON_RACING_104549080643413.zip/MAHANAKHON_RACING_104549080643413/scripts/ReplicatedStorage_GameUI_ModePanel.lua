-- Path: ReplicatedStorage/GameUI/ModePanel
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = require(game:GetService("ReplicatedStorage"):WaitForChild("UiOwn")).Instance
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("RunService")
local v4 = v2:WaitForChild("GameUI")
local v_u_5 = require(v4:WaitForChild("Skin"))
local v_u_6 = require(v2:WaitForChild("LightModes"))
local v_u_7 = Color3.fromRGB(70, 140, 255)
local v_u_8 = Color3.fromRGB(255, 70, 200)
local v_u_9 = Color3.fromRGB(14, 15, 22)
local v_u_10 = Color3.fromRGB(8, 8, 10)
local v_u_11 = Color3.fromRGB(90, 220, 255)
local v_u_12 = {}
v_u_12.__index = v_u_12
local function v_u_20(p13, p14, p15, p16, p17) -- name: button
	-- upvalues: (copy) v_u_1, (copy) v_u_5
	local v18 = v_u_1.new("TextButton")
	v18.Name = p13
	v18.Text = p14
	v18.Position = p15
	v18.Size = p16
	v18.BackgroundColor3 = v_u_5.IDLE
	v18.TextColor3 = Color3.new(1, 1, 1)
	v18.Font = Enum.Font.GothamBold
	v18.TextSize = 16
	v18.Parent = p17
	local v19 = v_u_1.new("UICorner")
	v19.CornerRadius = UDim.new(0, 10)
	v19.Parent = v18
	return v18
end
local function v_u_35(p21, p22, p23, p24) -- name: previewStrip
	-- upvalues: (copy) v_u_1
	local v25 = math.min(p22, 20)
	local v26 = v_u_1.new("Frame")
	v26.Name = "Preview"
	v26.BackgroundColor3 = Color3.new(1, 1, 1)
	v26.BorderSizePixel = 0
	v26.Position = p23
	v26.Size = p24
	v26.Parent = p21
	local v27 = v_u_1.new("UICorner")
	v27.CornerRadius = UDim.new(0, 6)
	v27.Parent = v26
	local v28 = v_u_1.new("UIGradient")
	v28.Parent = v26
	local v29 = {}
	for v30 = 1, v25 do
		local v31 = (v30 - 1) / (v25 - 1)
		local v32 = {
			["at"] = v31,
			["side"] = v31 < 0.5 and "Left" or "Right"
		}
		local v33 = v31 - 0.5
		local v34 = math.abs(v33) * 2
		v32.u = math.clamp(v34, 0, 1)
		v29[v30] = v32
	end
	return {
		["gradient"] = v28,
		["points"] = v29
	}
end
function v_u_12.new(p36, p37, p38, p39) -- name: new
	-- upvalues: (copy) v_u_12, (copy) v_u_6, (copy) v_u_1, (copy) v_u_20, (copy) v_u_11, (copy) v_u_9, (copy) v_u_35, (copy) v_u_3
	local v40 = v_u_12
	local v_u_41 = setmetatable({}, v40)
	v_u_41.onSend = p39
	local v42 = v_u_6.RECOMMENDED[1].speed
	v_u_41.mode = 1
	v_u_41.modeRight = 1
	v_u_41.speed = v42
	v_u_41.split = false
	v_u_41.side = "Left"
	v_u_41.modeRear = nil
	v_u_41.target = "Front"
	v_u_41.page = "Recommended"
	local v_u_43 = v_u_1.new("Frame")
	v_u_43.Name = "ModePanel"
	v_u_43.BackgroundTransparency = 1
	v_u_43.Position = p37
	v_u_43.Size = UDim2.fromOffset(p38, 206)
	v_u_43.Parent = p36
	v_u_41.frame = v_u_43
	v_u_41.tabs = {}
	for v44, v_u_45 in {
		{
			["id"] = "Recommended",
			["label"] = "\226\152\133 Recommended"
		},
		{
			["id"] = "All",
			["label"] = nil,
			["label"] = "All " .. v_u_6.COUNT .. " modes"
		}
	} do
		local v46 = v_u_20("Tab" .. v_u_45.id, v_u_45.label, UDim2.fromOffset((v44 - 1) * 118, 0), UDim2.fromOffset(112, 30), v_u_43)
		v46.TextSize = 12
		v46.Activated:Connect(function()
			-- upvalues: (copy) v_u_41, (copy) v_u_45
			v_u_41.page = v_u_45.id
			v_u_41:redraw()
		end)
		v_u_41.tabs[v_u_45.id] = v46
	end
	v_u_41.targetButtons = {}
	for v47, v_u_48 in { "Front", "Rear" } do
		local v49 = v_u_20("Target" .. v_u_48, v_u_48, UDim2.fromOffset(240 + (v47 - 1) * 56, 0), UDim2.fromOffset(52, 30), v_u_43)
		v49.TextSize = 13
		v49.Activated:Connect(function()
			-- upvalues: (copy) v_u_41, (copy) v_u_48
			v_u_41.target = v_u_48
			v_u_41:redraw()
		end)
		v_u_41.targetButtons[v_u_48] = v49
	end
	v_u_20("Slower", "-", UDim2.new(1, -154, 0, 0), UDim2.fromOffset(34, 30), v_u_43).Activated:Connect(function()
		-- upvalues: (copy) v_u_41
		local v50 = v_u_41
		local v51 = v_u_41.speed - 1
		v50.speed = math.max(1, v51)
		v_u_41:changed()
	end)
	local v52 = UDim2.new(1, -118, 0, 0)
	local v53 = UDim2.fromOffset(82, 30)
	local v54 = v_u_1.new("TextLabel")
	v54.Name = "Speed"
	v54.BackgroundTransparency = 1
	v54.Position = v52
	v54.Size = v53
	v54.Font = Enum.Font.GothamBold
	v54.TextSize = 13
	v54.TextColor3 = Color3.new(1, 1, 1)
	v54.Text = ""
	v54.Parent = v_u_43
	v_u_41.speedText = v54
	v_u_20("Faster", "+", UDim2.new(1, -34, 0, 0), UDim2.fromOffset(34, 30), v_u_43).Activated:Connect(function()
		-- upvalues: (copy) v_u_41, (ref) v_u_6
		local v55 = v_u_41
		local v56 = v_u_6.SPEED_LEVELS
		local v57 = v_u_41.speed + 1
		v55.speed = math.min(v56, v57)
		v_u_41:changed()
	end)
	local v58 = v_u_1.new("ScrollingFrame")
	v58.Name = "Recommended"
	v58.BackgroundTransparency = 1
	v58.BorderSizePixel = 0
	v58.Position = UDim2.fromOffset(0, 36)
	v58.Size = UDim2.new(1, 0, 0, 170)
	v58.ScrollBarThickness = 6
	v58.ScrollBarImageColor3 = v_u_11
	v58.ScrollingDirection = Enum.ScrollingDirection.Y
	v58.AutomaticCanvasSize = Enum.AutomaticSize.Y
	v58.CanvasSize = UDim2.new()
	v58.Parent = v_u_43
	v_u_41.cardsFrame = v58
	local v59 = v_u_1.new("UIGridLayout")
	v59.CellSize = UDim2.new(0.3333333333333333, -8, 0, 52)
	v59.CellPadding = UDim2.fromOffset(6, 6)
	v59.SortOrder = Enum.SortOrder.LayoutOrder
	v59.Parent = v58
	v_u_41.cards = {}
	for v60, v_u_61 in v_u_6.RECOMMENDED do
		local v62 = v_u_1.new("TextButton")
		v62.Name = "Card" .. v60
		v62.LayoutOrder = v60
		v62.Text = ""
		v62.BackgroundColor3 = v_u_9
		v62.Parent = v58
		local v63 = v_u_1.new("UICorner")
		v63.CornerRadius = UDim.new(0, 10)
		v63.Parent = v62
		local v64 = v_u_1.new("UIStroke")
		v64.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
		v64.Color = v_u_11
		v64.Transparency = 0.8
		v64.Thickness = 1.5
		v64.Parent = v62
		local v65 = v_u_61.name
		local v66 = UDim2.fromOffset(8, 4)
		local v67 = UDim2.new(1, -40, 0, 20)
		local v68 = v_u_1.new("TextLabel")
		v68.Name = "Title"
		v68.BackgroundTransparency = 1
		v68.Position = v66
		v68.Size = v67
		v68.Font = Enum.Font.GothamBold
		v68.TextSize = 13
		v68.TextColor3 = Color3.new(1, 1, 1)
		v68.Text = v65
		v68.Parent = v62
		v68.TextXAlignment = Enum.TextXAlignment.Left
		v68.TextTruncate = Enum.TextTruncate.AtEnd
		local v69 = v_u_61.mode
		local v70 = tostring(v69)
		local v71 = UDim2.new(1, -34, 0, 4)
		local v72 = UDim2.fromOffset(28, 20)
		local v73 = Color3.fromRGB(150, 160, 180)
		local v74 = v_u_1.new("TextLabel")
		v74.Name = "No"
		v74.BackgroundTransparency = 1
		v74.Position = v71
		v74.Size = v72
		v74.Font = Enum.Font.GothamBold
		v74.TextSize = 11
		v74.TextColor3 = v73 or Color3.new(1, 1, 1)
		v74.Text = v70
		v74.Parent = v62
		v74.TextXAlignment = Enum.TextXAlignment.Right
		local v75 = v_u_35(v62, 20, UDim2.fromOffset(8, 28), UDim2.new(1, -16, 0, 16))
		v62.Activated:Connect(function()
			-- upvalues: (copy) v_u_41, (copy) v_u_61
			v_u_41.speed = v_u_61.speed
			if v_u_41.target == "Rear" then
				v_u_41.modeRear = v_u_61.mode
			else
				v_u_41.mode = v_u_61.mode
				if v_u_41.split then
					v_u_41.modeRight = v_u_61.mode
				end
			end
			v_u_41:changed()
		end)
		v_u_41.cards[v60] = {
			["button"] = v62,
			["stroke"] = v64,
			["cells"] = v75,
			["rec"] = v_u_61
		}
	end
	local v76 = v_u_1.new("Frame")
	v76.Name = "AllModes"
	v76.BackgroundTransparency = 1
	v76.Position = UDim2.fromOffset(0, 36)
	v76.Size = UDim2.new(1, 0, 0, 170)
	v76.Parent = v_u_43
	v_u_41.allFrame = v76
	local v77 = v_u_1.new("Frame")
	v77.Name = "Screen"
	v77.BackgroundColor3 = v_u_9
	v77.Position = UDim2.fromOffset(112, 0)
	v77.Size = UDim2.new(1, -224, 0, 78)
	v77.Parent = v76
	local v78 = v_u_1.new("UICorner")
	v78.CornerRadius = UDim.new(0, 12)
	v78.Parent = v77
	local v79 = v_u_1.new("UIStroke")
	v79.Color = v_u_11
	v79.Transparency = 0.55
	v79.Thickness = 1.5
	v79.Parent = v77
	local v80 = UDim2.fromOffset(0, 3)
	local v81 = UDim2.new(1, 0, 0, 28)
	local v82 = v_u_1.new("TextLabel")
	v82.Name = "Number"
	v82.BackgroundTransparency = 1
	v82.Position = v80
	v82.Size = v81
	v82.Font = Enum.Font.GothamBold
	v82.TextSize = 22
	v82.TextColor3 = Color3.new(1, 1, 1)
	v82.Text = ""
	v82.Parent = v77
	v_u_41.number = v82
	v_u_41.number.Font = Enum.Font.GothamBlack
	local v83 = UDim2.fromOffset(6, 31)
	local v84 = UDim2.new(1, -12, 0, 18)
	local v85 = Color3.fromRGB(170, 230, 255)
	local v86 = v_u_1.new("TextLabel")
	v86.Name = "ModeName"
	v86.BackgroundTransparency = 1
	v86.Position = v83
	v86.Size = v84
	v86.Font = Enum.Font.GothamBold
	v86.TextSize = 13
	v86.TextColor3 = v85 or Color3.new(1, 1, 1)
	v86.Text = ""
	v86.Parent = v77
	v_u_41.name = v86
	v_u_41.name.TextTruncate = Enum.TextTruncate.AtEnd
	v_u_41.cells = v_u_35(v77, 20, UDim2.new(0, 10, 0, 54), UDim2.new(1, -20, 0, 16))
	v_u_20("Back10", "-10", UDim2.fromOffset(0, 0), UDim2.fromOffset(52, 78), v76).Activated:Connect(function()
		-- upvalues: (copy) v_u_41
		v_u_41:setCurrent(v_u_41:current() + -10)
	end)
	v_u_20("Back", "<", UDim2.fromOffset(58, 0), UDim2.fromOffset(48, 78), v76).Activated:Connect(function()
		-- upvalues: (copy) v_u_41
		v_u_41:setCurrent(v_u_41:current() + -1)
	end)
	v_u_20("Next", ">", UDim2.new(1, -106, 0, 0), UDim2.fromOffset(48, 78), v76).Activated:Connect(function()
		-- upvalues: (copy) v_u_41
		v_u_41:setCurrent(v_u_41:current() + 1)
	end)
	v_u_20("Next10", "+10", UDim2.new(1, -52, 0, 0), UDim2.fromOffset(52, 78), v76).Activated:Connect(function()
		-- upvalues: (copy) v_u_41
		v_u_41:setCurrent(v_u_41:current() + 10)
	end)
	local v_u_87 = v_u_1.new("TextBox")
	v_u_87.Name = "Search"
	v_u_87.PlaceholderText = "Mode no. 1-" .. v_u_6.COUNT
	v_u_87.Text = ""
	v_u_87.ClearTextOnFocus = true
	v_u_87.Font = Enum.Font.GothamBold
	v_u_87.TextSize = 15
	v_u_87.TextColor3 = Color3.new(1, 1, 1)
	v_u_87.PlaceholderColor3 = Color3.fromRGB(150, 150, 160)
	v_u_87.BackgroundColor3 = v_u_9
	v_u_87.Position = UDim2.fromOffset(0, 86)
	v_u_87.Size = UDim2.fromOffset(150, 36)
	v_u_87.Parent = v76
	local v88 = v_u_1.new("UICorner")
	v88.CornerRadius = UDim.new(0, 10)
	v88.Parent = v_u_87
	v_u_87.FocusLost:Connect(function(p89)
		-- upvalues: (copy) v_u_87, (copy) v_u_41
		if p89 then
			local v90 = v_u_87.Text
			local v91 = tonumber(v90)
			if v91 then
				v_u_41:setCurrent(v91)
			end
			v_u_87.Text = ""
		end
	end)
	v_u_20("Go", "GO", UDim2.fromOffset(156, 86), UDim2.fromOffset(52, 36), v76).Activated:Connect(function() -- name: go
		-- upvalues: (copy) v_u_87, (copy) v_u_41
		local v92 = v_u_87.Text
		local v93 = tonumber(v92)
		if v93 then
			v_u_41:setCurrent(v93)
		end
		v_u_87.Text = ""
	end)
	v_u_20("Random", "Random", UDim2.new(1, -110, 0, 86), UDim2.fromOffset(110, 36), v76).Activated:Connect(function()
		-- upvalues: (copy) v_u_41, (ref) v_u_6
		v_u_41:setCurrent(math.random(1, v_u_6.COUNT))
	end)
	v_u_41.splitButton = v_u_20("Split", "", UDim2.fromOffset(0, 128), UDim2.fromOffset(150, 36), v76)
	v_u_41.splitButton.TextSize = 14
	v_u_41.splitButton.Activated:Connect(function()
		-- upvalues: (copy) v_u_41
		v_u_41.split = not v_u_41.split
		if v_u_41.split then
			v_u_41.modeRight = v_u_41.mode
			v_u_41.side = "Right"
		else
			v_u_41.side = "Left"
		end
		v_u_41:changed()
	end)
	v_u_41.sideButtons = {}
	for v94, v_u_95 in { "Left", "Right" } do
		local v96 = v_u_20("Edit" .. v_u_95, v_u_95, UDim2.fromOffset(156 + (v94 - 1) * 80, 128), UDim2.fromOffset(74, 36), v76)
		v96.TextSize = 14
		v96.Activated:Connect(function()
			-- upvalues: (copy) v_u_41, (copy) v_u_95
			v_u_41.side = v_u_95
			v_u_41:redraw()
		end)
		v_u_41.sideButtons[v_u_95] = v96
	end
	v_u_41.connection = v_u_3.RenderStepped:Connect(function()
		-- upvalues: (copy) v_u_43, (copy) v_u_41
		local v97 = v_u_43:FindFirstAncestorWhichIsA("ScreenGui")
		if v_u_43.Visible and (v97 and v97.Enabled) then
			v_u_41:drawPreview()
		end
	end)
	v_u_41:redraw()
	return v_u_41
end
function v_u_12.current(p98) -- name: current
	if p98.target == "Rear" then
		return p98.modeRear or p98.mode
	elseif p98.split and p98.side == "Right" then
		return p98.modeRight
	else
		return p98.mode
	end
end
function v_u_12.setCurrent(p99, p100) -- name: setCurrent
	-- upvalues: (copy) v_u_6
	local v101 = tonumber(p100) or 1
	local v102 = (math.floor(v101) - 1) % v_u_6.COUNT + 1
	if p99.target == "Rear" then
		p99.modeRear = v102
	elseif p99.split and p99.side == "Right" then
		p99.modeRight = v102
	else
		p99.mode = v102
	end
	p99:changed()
end
function v_u_12.changed(p_u_103) -- name: changed
	p_u_103.editedAt = os.clock()
	p_u_103:redraw()
	p_u_103.sendToken = (p_u_103.sendToken or 0) + 1
	local v_u_104 = p_u_103.sendToken
	task.delay(0.25, function()
		-- upvalues: (copy) v_u_104, (copy) p_u_103
		if v_u_104 == p_u_103.sendToken and p_u_103.onSend then
			local v105 = p_u_103.onSend
			local v106 = p_u_103.mode
			local v107 = p_u_103.speed
			local v108 = p_u_103.split
			local v109
			if p_u_103.split then
				v109 = p_u_103.modeRight
			else
				v109 = nil
			end
			v105(v106, v107, v108, v109, p_u_103.modeRear)
		end
	end)
end
function v_u_12.redraw(p110) -- name: redraw
	-- upvalues: (copy) v_u_5, (copy) v_u_6, (copy) v_u_11
	local v111 = p110.page == "Recommended"
	p110.cardsFrame.Visible = v111
	p110.allFrame.Visible = not v111
	for v112, v113 in p110.tabs do
		local v114
		if v112 == p110.page then
			v114 = v_u_5.SELECTED
		else
			v114 = v_u_5.IDLE
		end
		v113.BackgroundColor3 = v114
	end
	local v115 = p110:current()
	local v116 = p110.target == "Rear"
	p110.number.Text = ("MODE %04d / %d"):format(v115, v_u_6.COUNT)
	local v117 = p110.name
	local v118 = v_u_6.name(v115)
	local v119
	if v116 then
		v119 = p110.modeRear and "  (rear light)" or "  (rear: same as front)"
	else
		v119 = not p110.split and "" or "  (" .. p110.side:lower() .. " side)"
	end
	v117.Text = v118 .. v119
	p110.speedText.Text = ("SPEED %d/%d"):format(p110.speed, v_u_6.SPEED_LEVELS)
	p110.splitButton.Text = p110.split and "Split L/R: ON" or "Split L/R: OFF"
	local v120 = p110.splitButton
	local v121
	if p110.split then
		v121 = v_u_5.SELECTED
	else
		v121 = v_u_5.IDLE
	end
	v120.BackgroundColor3 = v121
	p110.splitButton.Visible = not v116
	for v122, v123 in p110.sideButtons do
		local v124 = p110.split
		if v124 then
			v124 = not v116
		end
		v123.Visible = v124
		local v125
		if v122 == p110.side then
			v125 = v_u_5.SELECTED
		else
			v125 = v_u_5.IDLE
		end
		v123.BackgroundColor3 = v125
	end
	for v126, v127 in p110.targetButtons do
		local v128
		if v126 == p110.target then
			v128 = v_u_5.SELECTED
		else
			v128 = v_u_5.IDLE
		end
		v127.BackgroundColor3 = v128
	end
	for _, v129 in p110.cards do
		local v130 = v129.rec.mode == v115
		local v131 = v129.stroke
		local v132
		if v130 then
			v132 = v_u_5.SELECTED
		else
			v132 = v_u_11
		end
		v131.Color = v132
		v129.stroke.Transparency = v130 and 0 or 0.8
		v129.stroke.Thickness = v130 and 2.5 or 1.5
	end
end
local function v_u_143(p133, p134, p135, p136, p137, p138) -- name: paintCells
	-- upvalues: (copy) v_u_6, (copy) v_u_10
	local v139 = {}
	for v140, v141 in p133.points do
		local v142 = v_u_6.sample(p135(v141.side), v141.u, v141.side, p134, p136, p137, p138)
		v139[v140] = ColorSequenceKeypoint.new(v141.at, v142 or v_u_10)
	end
	p133.gradient.Color = ColorSequence.new(v139)
end
function v_u_12.drawPreview(p_u_144) -- name: drawPreview
	-- upvalues: (copy) v_u_7, (copy) v_u_8, (copy) v_u_143
	local v145 = workspace:GetServerTimeNow()
	local v146 = p_u_144.c1 or v_u_7
	local v147 = p_u_144.c2 or v_u_8
	if p_u_144.page == "Recommended" then
		for _, v148 in p_u_144.cards do
			local v_u_149 = v148.rec.mode
			local v150 = v_u_143
			local v151 = v148.cells
			local function v152()
				-- upvalues: (copy) v_u_149
				return v_u_149
			end
			local v153
			if v_u_149 == p_u_144:current() then
				v153 = p_u_144.speed
			else
				v153 = v148.rec.speed
			end
			v150(v151, v145, v152, v153, v146, v147)
		end
		return
	elseif p_u_144.target == "Rear" then
		v_u_143(p_u_144.cells, v145, function()
			-- upvalues: (copy) p_u_144
			return p_u_144.modeRear or p_u_144.mode
		end, p_u_144.speed, v146, v147)
	else
		v_u_143(p_u_144.cells, v145, function(p154)
			-- upvalues: (copy) p_u_144
			if p_u_144.split and p154 == "Right" then
				return p_u_144.modeRight
			else
				return p_u_144.mode
			end
		end, p_u_144.speed, v146, v147)
	end
end
function v_u_12.refresh(p155, p156) -- name: refresh
	-- upvalues: (copy) v_u_7, (copy) v_u_8, (copy) v_u_6
	if p156 then
		p155.c1 = p156:GetAttribute("DRLColor") or v_u_7
		p155.c2 = p156:GetAttribute("DRLColor2") or v_u_8
		local v157 = p155.editedAt
		if v157 then
			v157 = os.clock() - p155.editedAt < 1.2
		end
		if p156:GetAttribute("DRLStyle") == "Mode" and not v157 then
			p155.mode = v_u_6.clampMode(p156:GetAttribute("DRLMode") or p155.mode)
			local v158 = tonumber(p156:GetAttribute("DRLSpeed")) or p155.speed
			local v159 = v_u_6.SPEED_LEVELS
			p155.speed = math.clamp(v158, 1, v159)
			p155.split = p156:GetAttribute("DRLSplit") == true
			p155.modeRight = v_u_6.clampMode(p156:GetAttribute("DRLModeR") or p155.mode)
			local v160 = p156:GetAttribute("DRLModeRear")
			local v161
			if typeof(v160) == "number" then
				v161 = v_u_6.clampMode(v160)
			else
				v161 = nil
			end
			p155.modeRear = v161
		end
		if not p155.split then
			p155.side = "Left"
		end
		p155:redraw()
	end
end
function v_u_12.setVisible(p162, p163) -- name: setVisible
	p162.frame.Visible = p163
end
function v_u_12.destroy(p164) -- name: destroy
	if p164.connection then
		p164.connection:Disconnect()
	end
	p164.frame:Destroy()
end
return v_u_12