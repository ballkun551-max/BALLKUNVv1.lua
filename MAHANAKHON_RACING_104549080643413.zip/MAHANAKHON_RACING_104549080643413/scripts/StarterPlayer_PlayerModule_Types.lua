-- Path: StarterPlayer/PlayerModule/Types
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

require(script.ControlModuleData)
require(script.PlayerModuleInternalData)
return {}