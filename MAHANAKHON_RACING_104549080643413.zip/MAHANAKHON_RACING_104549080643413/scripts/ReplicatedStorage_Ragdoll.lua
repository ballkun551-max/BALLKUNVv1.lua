-- Path: ReplicatedStorage/Ragdoll
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("RunService")
local v_u_3 = {
	["ATTRIBUTE"] = "Ragdolled",
	["LAUNCH_ATTRIBUTE"] = "RagdollLaunch",
	["DEFAULT_TIME"] = 3.5,
	["LAUNCH_FLAT"] = 10,
	["LAUNCH_UP"] = 12,
	["KNOCK_HOLD"] = 1.2
}
local v_u_4 = {
	["Neck"] = { 30, 40 },
	["Waist"] = { 20, 30 },
	["LeftShoulder"] = { 80, 90 },
	["RightShoulder"] = { 80, 90 },
	["Left Shoulder"] = { 80, 90 },
	["Right Shoulder"] = { 80, 90 },
	["LeftElbow"] = { 15, 70 },
	["RightElbow"] = { 15, 70 },
	["LeftWrist"] = { 20, 30 },
	["RightWrist"] = { 20, 30 },
	["LeftHip"] = { 45, 70 },
	["RightHip"] = { 45, 70 },
	["Left Hip"] = { 45, 70 },
	["Right Hip"] = { 45, 70 },
	["LeftKnee"] = { 10, 75 },
	["RightKnee"] = { 10, 75 },
	["LeftAnkle"] = { 20, 30 },
	["RightAnkle"] = { 20, 30 }
}
local v_u_5 = { 30, 30 }
local v_u_6 = setmetatable({}, {
	["__mode"] = "k"
})
function v_u_3.isRagdolled(p7) -- name: isRagdolled
	-- upvalues: (copy) v_u_3
	local v8
	if p7 == nil then
		v8 = false
	else
		v8 = p7:GetAttribute(v_u_3.ATTRIBUTE) == true
	end
	return v8
end
function v_u_3.capLaunch(p9) -- name: capLaunch
	-- upvalues: (copy) v_u_3
	if typeof(p9) ~= "Vector3" or p9 ~= p9 then
		return Vector3.new(0, 0, 0)
	end
	local v10 = p9.X
	local v11 = p9.Z
	local v12 = Vector3.new(v10, 0, v11)
	if v12.Magnitude > v_u_3.LAUNCH_FLAT then
		v12 = v12.Unit * v_u_3.LAUNCH_FLAT
	end
	local v13 = v12.X
	local v14 = p9.Y
	local v15 = v_u_3.LAUNCH_UP
	local v16 = math.min(v14, v15)
	local v17 = v12.Z
	return Vector3.new(v13, v16, v17)
end
function v_u_3.enable(p18, p19) -- name: enable
	-- upvalues: (copy) v_u_3, (copy) v_u_4, (copy) v_u_5, (copy) v_u_2, (copy) v_u_1
	if not p18 or v_u_3.isRagdolled(p18) then
		return false
	end
	local v20 = p18:FindFirstChildOfClass("Humanoid")
	if not v20 or v20.Health <= 0 then
		return false
	end
	v20.BreakJointsOnDeath = false
	local v21 = Instance.new("Folder")
	v21.Name = "RagdollJoints"
	for _, v22 in p18:GetDescendants() do
		if not v22:IsA("Motor6D") or (not v22.Enabled or (not v22.Part0 or (not v22.Part1 or (v22.Part0.Name == "HumanoidRootPart" or v22:FindFirstAncestorWhichIsA("Accessory"))))) then
			continue
		end
		local v23 = v_u_4[v22.Name] or v_u_5
		local v24 = Instance.new("Attachment")
		v24.Name = "RagdollAttachment"
		v24.CFrame = v22.C0
		v24.Parent = v22.Part0
		local v25 = Instance.new("Attachment")
		v25.Name = "RagdollAttachment"
		v25.CFrame = v22.C1
		v25.Parent = v22.Part1
		local v26 = Instance.new("BallSocketConstraint")
		v26.Name = v22.Name
		v26.Attachment0 = v24
		v26.Attachment1 = v25
		v26.LimitsEnabled = true
		v26.UpperAngle = v23[1]
		v26.TwistLimitsEnabled = true
		v26.TwistLowerAngle = -v23[2]
		v26.TwistUpperAngle = v23[2]
		v26.MaxFrictionTorque = 4
		v26.Restitution = 0
		v26.Parent = v21
		local v27 = Instance.new("NoCollisionConstraint")
		v27.Part0 = v22.Part0
		v27.Part1 = v22.Part1
		v27.Parent = v21
		v22:SetAttribute("RagdollOff", true)
		v22.Enabled = false
	end
	v21.Parent = p18
	local v28 = v_u_3.capLaunch(p19)
	p18:SetAttribute(v_u_3.LAUNCH_ATTRIBUTE, v28)
	p18:SetAttribute(v_u_3.ATTRIBUTE, true)
	if v_u_2:IsServer() and not v_u_1:GetPlayerFromCharacter(p18) then
		v20:SetStateEnabled(Enum.HumanoidStateType.GettingUp, false)
		v20:ChangeState(Enum.HumanoidStateType.Physics)
		local v29 = p18:FindFirstChild("HumanoidRootPart")
		if v29 then
			v29.AssemblyLinearVelocity = v28
		end
	end
	return true
end
function v_u_3.disable(p30) -- name: disable
	-- upvalues: (copy) v_u_3, (copy) v_u_2, (copy) v_u_1
	if p30 then
		local v31 = p30:FindFirstChild("RagdollJoints")
		if v31 then
			v31:Destroy()
		end
		for _, v32 in p30:GetDescendants() do
			if v32:IsA("Motor6D") and v32:GetAttribute("RagdollOff") then
				v32.Enabled = true
				v32:SetAttribute("RagdollOff", nil)
			else
				if not v32:IsA("Attachment") or v32.Name ~= "RagdollAttachment" then
					continue
				end
				v32:Destroy()
			end
		end
		p30:SetAttribute(v_u_3.LAUNCH_ATTRIBUTE, nil)
		p30:SetAttribute(v_u_3.ATTRIBUTE, nil)
		local v33 = v_u_2:IsServer() and (not v_u_1:GetPlayerFromCharacter(p30) and p30:FindFirstChildOfClass("Humanoid"))
		if v33 then
			v33:SetStateEnabled(Enum.HumanoidStateType.GettingUp, true)
			v33:ChangeState(Enum.HumanoidStateType.GettingUp)
		end
	end
end
function v_u_3.knockDown(p_u_34, p35, p36) -- name: knockDown
	-- upvalues: (copy) v_u_3, (copy) v_u_6
	if not v_u_3.enable(p_u_34, p35) then
		return false
	end
	local v_u_37 = {}
	v_u_6[p_u_34] = v_u_37
	task.delay(p36 or v_u_3.DEFAULT_TIME, function()
		-- upvalues: (ref) v_u_6, (copy) p_u_34, (copy) v_u_37, (ref) v_u_3
		if v_u_6[p_u_34] == v_u_37 then
			v_u_6[p_u_34] = nil
			if p_u_34.Parent then
				v_u_3.disable(p_u_34)
			end
		end
	end)
	return true
end
return v_u_3