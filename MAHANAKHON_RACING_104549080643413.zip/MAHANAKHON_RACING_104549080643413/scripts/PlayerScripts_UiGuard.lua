-- Path: Players/ygggggg55551/PlayerScripts/UiGuard
-- Class: LocalScript  true/Enum.RunContext.Legacy
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = require(game:GetService("ReplicatedStorage"):WaitForChild("NetSeal"))
local v_u_2 = v_u_1.fire
local v3 = v_u_1.invoke
local v_u_4 = v_u_1.sealed
local v5 = false
local v6 = false
local v7 = false
local v_u_8 = game:GetService("Players")
local v_u_9 = game:GetService("ReplicatedStorage")
local v10 = require(v_u_9:WaitForChild("GameShared"))
local v_u_11 = require(v_u_9:WaitForChild("UiGuardShared"))
local v_u_12 = v_u_11.drift
local v_u_13 = v_u_11.isChunk
local v_u_14 = require(v_u_9:WaitForChild("UiOwn"))
local v_u_15 = require(v_u_9:WaitForChild("RankShared"))
local v_u_16 = v_u_8.LocalPlayer
local v_u_17 = v_u_16:WaitForChild("PlayerGui")
local v_u_18 = v_u_9:WaitForChild(v10.REMOTES):WaitForChild(v_u_11.REMOTE)
local function v_u_52(p19) -- name: tagPrint
	local v20 = {}
	local function v22(p21) -- name: n
		return string.format("%.2f", p21)
	end
	local v23 = p19.Size.X.Scale
	local v24 = string.format("%.2f", v23)
	local v25 = p19.Size.Y.Scale
	local v26 = v24 .. "," .. string.format("%.2f", v25) .. "," .. p19.Size.X.Offset .. "," .. p19.Size.Y.Offset
	table.insert(v20, v26)
	local v27 = p19.StudsOffset.X
	local v28 = string.format("%.2f", v27)
	local v29 = p19.StudsOffset.Y
	local v30 = string.format("%.2f", v29)
	local v31 = p19.StudsOffset.Z
	local v32 = v28 .. "," .. v30 .. "," .. string.format("%.2f", v31)
	table.insert(v20, v32)
	local v33 = p19.MaxDistance
	table.insert(v20, v22(v33))
	local v34 = p19.AlwaysOnTop
	local v35 = tostring(v34)
	table.insert(v20, v35)
	local v36 = p19.Adornee == nil
	local v37 = tostring(v36)
	table.insert(v20, v37)
	for _, v38 in { "PlayerName", "Rank" } do
		local v39 = p19:FindFirstChild(v38)
		if v39 and v39:IsA("TextLabel") then
			local v40 = v39.Text
			if #v40 > 160 then
				local v41 = 160
				while v41 > 0 do
					local v42 = v41 + 1
					local v43 = string.byte(v40, v42) or 0
					if bit32.band(v43, 192) ~= 128 then
						break
					end
					v41 = v41 - 1
				end
				v40 = string.sub(v40, 1, v41)
			end
			local v44 = v40:gsub("|", "/")
			table.insert(v20, v44)
			local v45 = v39.Visible
			local v46 = tostring(v45)
			table.insert(v20, v46)
			local v47 = v39.TextTransparency
			table.insert(v20, v22(v47))
			local v48 = v39.Size.X.Scale
			local v49 = string.format("%.2f", v48)
			local v50 = v39.Size.Y.Scale
			local v51 = v49 .. "," .. string.format("%.2f", v50)
			table.insert(v20, v51)
		else
			table.insert(v20, "none")
			table.insert(v20, "none")
			table.insert(v20, "none")
			table.insert(v20, "none")
		end
	end
	return table.concat(v20, "|")
end
local function v_u_56(p53) -- name: isKnown
	-- upvalues: (copy) v_u_17, (copy) v_u_11, (copy) v_u_14
	if p53.Parent == v_u_17 then
		if v_u_11.KNOWN[p53.Name] then
			if p53.Name == "Freecam" then
				for _, v54 in p53:GetDescendants() do
					if v54:IsA("LocalScript") and v54.Name == "FreecamScript" then
						continue
					end
					return false
				end
			end
			if v_u_11.NO_BUTTONS[p53.Name] then
				for _, v55 in p53:GetDescendants() do
					if not v55:IsA("GuiButton") then
						continue
					end
					return false
				end
			end
			return v_u_14.mine(p53) or not v_u_11.isMarked(p53.Name)
		elseif v_u_11.EMPTY_ONLY[p53.Name] then
			return #p53:GetDescendants() == 0
		else
			return false
		end
	else
		return false
	end
end
local v_u_57 = v_u_11.cut
local v_u_58 = v_u_11.describe
local function v_u_64(p59) -- name: origin
	-- upvalues: (copy) v_u_14, (copy) v_u_57
	local v60 = v_u_14.madeBy(p59)
	local v61 = v_u_14.copied(p59)
	for _, v62 in p59:GetDescendants() do
		if v60 and v61 then
			break
		end
		v60 = v60 or v_u_14.madeBy(v62)
		v61 = v61 or v_u_14.copied(v62)
	end
	local v63
	if v60 then
		v63 = v_u_57(v60)
	else
		v63 = nil
	end
	return v63, v61
end
local v_u_65 = {}
local v_u_66 = {}
local function v_u_74(p_u_67, p68) -- name: reportTool
	-- upvalues: (copy) v_u_66, (copy) v_u_11, (copy) v_u_65, (copy) v_u_2, (copy) v_u_18
	if v_u_66[p_u_67] then
		return true
	end
	if not v_u_11.tool(p68, p_u_67) then
		return false
	end
	v_u_66[p_u_67] = true
	v_u_65[p_u_67] = p_u_67.Name
	if not game:GetService("RunService"):IsStudio() or workspace:GetAttribute("ZZPretendDrop") ~= true then
		local v69 = v_u_2
		local v70 = v_u_18
		local v71 = {
			["kind"] = "mark",
			["id"] = nil,
			["class"] = nil,
			["where"] = nil,
			["id"] = p_u_67.Name,
			["class"] = p_u_67.ClassName,
			["where"] = p68
		}
		pcall(v69, v70, "Tool", v71)
	end
	task.delay(p_u_67:IsA("ScreenGui") and 20 or 3, function()
		-- upvalues: (copy) p_u_67
		if p_u_67.Parent then
			local v72 = p_u_67.Destroy
			local v73 = p_u_67
			pcall(v72, v73)
		end
	end)
	return true
end
local function v_u_82(p75) -- name: check
	-- upvalues: (copy) v_u_17, (copy) v_u_74, (copy) v_u_56, (copy) v_u_65, (copy) v_u_58, (copy) v_u_11, (copy) v_u_64, (copy) v_u_2, (copy) v_u_18
	if p75:IsA("ScreenGui") and p75:IsDescendantOf(v_u_17) then
		if p75.Parent == v_u_17 and v_u_74(p75, "PlayerGui") then
			return
		elseif not v_u_56(p75) and v_u_65[p75] ~= p75.Name then
			v_u_65[p75] = p75.Name
			local v76 = v_u_58(p75)
			local v77
			if p75.Parent == v_u_17 then
				if v_u_11.KNOWN[p75.Name] == true then
					v77 = p75.Name ~= "Freecam"
				else
					v77 = false
				end
			else
				v77 = true
			end
			v76.soft = v77
			local v78, v79 = v_u_64(p75)
			v76.by = v78
			v76.copy = v79
			v76.shown = v_u_11.onScreen(p75)
			local v80 = v_u_2
			local v81 = v_u_18
			pcall(v80, v81, "Found", v76)
		end
	else
		return
	end
end
local function v_u_84(p83) -- name: ownWindow
	-- upvalues: (copy) v_u_17, (copy) v_u_11, (copy) v_u_14
	while p83.Parent and p83.Parent ~= v_u_17 do
		p83 = p83.Parent
	end
	if p83.Parent == v_u_17 and (p83:IsA("ScreenGui") and (v_u_11.isMarked(p83.Name) and v_u_14.mine(p83))) then
		return p83
	else
		return nil
	end
end
local v_u_85 = 0
local function v_u_93(p86) -- name: checkInside
	-- upvalues: (copy) v_u_17, (copy) v_u_14, (copy) v_u_84, (copy) v_u_65, (ref) v_u_85, (copy) v_u_11, (copy) v_u_58, (copy) v_u_57, (copy) v_u_64, (copy) v_u_2, (copy) v_u_18
	if p86:IsDescendantOf(v_u_17) and not v_u_14.mine(p86) then
		local v87 = v_u_84(p86)
		if v87 then
			while p86.Parent ~= v87 and (p86.Parent:IsA("GuiObject") and not v_u_14.mine(p86.Parent)) do
				p86 = p86.Parent
			end
			if not v_u_65[p86] and v_u_85 < v_u_11.MAX_INSIDE then
				v_u_65[p86] = p86.Name
				v_u_85 = v_u_85 + 1
				local v88 = v_u_58(p86)
				v88.name = v_u_57(v87.Name .. "/" .. p86.Name)
				v88.soft = true
				v88.injected = true
				local v89, v90 = v_u_64(p86)
				v88.by = v89
				v88.copy = v90
				v88.shown = v_u_11.onScreen(p86)
				local v91 = v_u_2
				local v92 = v_u_18
				pcall(v91, v92, "Found", v88)
			end
		else
			return
		end
	else
		return
	end
end
local function v_u_103(p94, p95, p96, p97) -- name: tell
	-- upvalues: (copy) v_u_65, (ref) v_u_85, (copy) v_u_11, (copy) v_u_58, (copy) v_u_57, (copy) v_u_64, (copy) v_u_2, (copy) v_u_18
	if not v_u_65[p94] and (v_u_85 < v_u_11.MAX_INSIDE or p97) then
		v_u_65[p94] = p95
		v_u_85 = v_u_85 + 1
		local v98 = v_u_58(p94)
		v98.name = v_u_57(p95)
		v98.soft = true
		v98.injected = p97
		if p96 then
			v98.texts = p96
		end
		local v99, v100 = v_u_64(p94)
		v98.by = v99
		v98.copy = v100
		v98.shown = v_u_11.onScreen(p94)
		local v101 = v_u_2
		local v102 = v_u_18
		pcall(v101, v102, "Found", v98)
	end
end
local function v_u_105(p104) -- name: checkLayer
	-- upvalues: (copy) v_u_17, (copy) v_u_14, (copy) v_u_11, (copy) v_u_103
	if p104.Parent == v_u_17 and not (v_u_14.mine(p104) or p104.Name:match(v_u_11.LAYER_OK)) then
		v_u_103(p104, "Layer/" .. p104.Name)
	end
end
local v_u_106 = v_u_16:WaitForChild("PlayerScripts", 30)
local function v_u_108(p107) -- name: checkScripts
	-- upvalues: (copy) v_u_106, (copy) v_u_65, (copy) v_u_74, (copy) v_u_103
	if v_u_106 and (p107.Parent == v_u_106 and not v_u_65[p107]) then
		if not v_u_74(p107, "PlayerScripts") then
			if not p107:IsA("LuaSourceContainer") then
				v_u_103(p107, ("PlayerScripts/%s (%s)"):format(p107.Name, p107.ClassName))
			end
		end
	else
		return
	end
end
local v_u_109, v_u_110, v_u_111
if v_u_106 then
	v_u_106.ChildAdded:Connect(function(p112)
		-- upvalues: (copy) v_u_108
		task.defer(v_u_108, p112)
	end)
	v_u_109 = v6
	v_u_110 = v5
	v_u_111 = v7
	for _, v113 in v_u_106:GetChildren() do
		task.defer(v_u_108, v113)
	end
else
	v_u_109 = v6
	v_u_110 = v5
	v_u_111 = v7
end
local v_u_114 = false
local function v_u_118(p115) -- name: baitGone
	-- upvalues: (ref) v_u_114, (copy) v_u_16, (copy) v_u_8, (copy) v_u_106, (copy) v_u_17, (copy) v_u_2, (copy) v_u_18
	if v_u_114 then
		return
	else
		v_u_114 = true
		task.wait(2)
		if v_u_16.Parent == v_u_8 and (v_u_106.Parent == v_u_16 and (script.Parent == v_u_106 and v_u_17.Parent == v_u_16)) then
			local v116 = v_u_2
			local v117 = v_u_18
			pcall(v116, v117, "Tool", {
				["kind"] = "decoy",
				["id"] = "MahanakhonTunerRun",
				["how"] = nil,
				["how"] = p115
			})
		end
	end
end
if v_u_106 and not v_u_106:FindFirstChild("MahanakhonTunerRun") then
	local v_u_119 = Instance.new("BindableEvent")
	v_u_119.Name = "MahanakhonTunerRun"
	v_u_66[v_u_119] = true
	v_u_65[v_u_119] = "MahanakhonTunerRun"
	v_u_119.Parent = v_u_106
	v_u_119.Event:Connect(function()
		-- upvalues: (copy) v_u_118
		task.spawn(v_u_118, "fired")
	end)
	v_u_119.AncestryChanged:Connect(function()
		-- upvalues: (copy) v_u_119, (copy) v_u_106, (copy) v_u_118
		if v_u_119.Parent ~= v_u_106 then
			task.spawn(v_u_118, "removed")
		end
	end)
end
local v120 = game:GetService("Lighting")
v120.ChildAdded:Connect(function(p121)
	-- upvalues: (copy) v_u_74
	task.defer(v_u_74, p121, "Lighting")
end)
for _, v122 in v120:GetChildren() do
	task.defer(v_u_74, v122, "Lighting")
end
local v_u_123 = {
	["LinearVelocity"] = true,
	["AngularVelocity"] = true,
	["AlignPosition"] = true,
	["AlignOrientation"] = true,
	["VectorForce"] = true,
	["Torque"] = true,
	["LineForce"] = true
}
local v_u_124 = {}
local v_u_125 = 0
local function v_u_132(p126, p127) -- name: odd
	-- upvalues: (ref) v_u_125, (copy) v_u_66, (copy) v_u_11, (copy) v_u_124, (copy) v_u_2, (copy) v_u_18, (copy) v_u_57
	if v_u_125 >= 40 or (v_u_66[p126] or (not p126.Parent or v_u_11.oddOk(p127, p126))) then
		return
	else
		local v128 = p127 .. "/" .. p126.Name .. "/" .. p126.ClassName
		if not v_u_124[v128] then
			v_u_124[v128] = true
			v_u_125 = v_u_125 + 1
			local v129 = v_u_2
			local v130 = v_u_18
			local v131 = {
				["where"] = p127,
				["name"] = v_u_57(p126.Name),
				["class"] = p126.ClassName
			}
			pcall(v129, v130, "Odd", v131)
		end
	end
end
local function v_u_138(p133, p_u_134, p135) -- name: watchOdd
	-- upvalues: (copy) v_u_132
	p133.ChildAdded:Connect(function(p136)
		-- upvalues: (ref) v_u_132, (copy) p_u_134
		task.delay(2, v_u_132, p136, p_u_134)
	end)
	if p135 then
		for _, v137 in p133:GetChildren() do
			task.delay(5, v_u_132, v137, p_u_134)
		end
	end
end
v_u_138(v120, "Lighting", true)
local v_u_139 = "ReplicatedStorage"
v_u_9.ChildAdded:Connect(function(p140)
	-- upvalues: (copy) v_u_132, (copy) v_u_139
	task.delay(2, v_u_132, p140, v_u_139)
end)
local v_u_141 = "Player"
v_u_16.ChildAdded:Connect(function(p142)
	-- upvalues: (copy) v_u_132, (copy) v_u_141
	task.delay(2, v_u_132, p142, v_u_141)
end)
local v_u_143 = nil
local function v156() -- name: watchCamera
	-- upvalues: (ref) v_u_143, (copy) v_u_138, (copy) v_u_74
	local v_u_144 = workspace.CurrentCamera
	if v_u_144 and v_u_144 ~= v_u_143 then
		v_u_143 = v_u_144
		v_u_138(v_u_144, "Camera", true)
		v_u_144.ChildAdded:Connect(function(p145)
			-- upvalues: (ref) v_u_74
			task.defer(v_u_74, p145, "Camera")
		end)
		for _, v146 in v_u_144:GetChildren() do
			task.defer(v_u_74, v146, "Camera")
		end
		local function v_u_149(p_u_147) -- name: plate
			-- upvalues: (copy) v_u_144, (ref) v_u_74
			task.delay(1, function()
				-- upvalues: (copy) p_u_147, (ref) v_u_144, (ref) v_u_74
				local v148 = p_u_147.Parent
				if v148 then
					v148 = p_u_147:FindFirstChildOfClass("SpecialMesh")
				end
				if p_u_147.Parent and (p_u_147:IsA("Part") and (p_u_147.Name == "Body" or p_u_147.Name == "Part")) and (p_u_147.Material == Enum.Material.Glass and (v148 and (v148.MeshType == Enum.MeshType.Brick and (p_u_147.Parent.Name == "Folder" and p_u_147.Parent.Parent == v_u_144)))) then
					v_u_74(p_u_147, "CameraFolder")
				end
			end)
		end
		local function v_u_153(p150) -- name: bare
			-- upvalues: (copy) v_u_149, (copy) v_u_144, (ref) v_u_74
			if p150:IsA("Folder") and p150.Name == "Folder" then
				p150.ChildAdded:Connect(v_u_149)
				for _, v_u_151 in p150:GetChildren() do
					task.delay(1, function()
						-- upvalues: (copy) v_u_151, (ref) v_u_144, (ref) v_u_74
						local v152 = v_u_151.Parent
						if v152 then
							v152 = v_u_151:FindFirstChildOfClass("SpecialMesh")
						end
						if v_u_151.Parent and (v_u_151:IsA("Part") and (v_u_151.Name == "Body" or v_u_151.Name == "Part")) and (v_u_151.Material == Enum.Material.Glass and (v152 and (v152.MeshType == Enum.MeshType.Brick and (v_u_151.Parent.Name == "Folder" and v_u_151.Parent.Parent == v_u_144)))) then
							v_u_74(v_u_151, "CameraFolder")
						end
					end)
				end
			end
		end
		v_u_144.ChildAdded:Connect(function(p154)
			-- upvalues: (copy) v_u_153
			task.defer(v_u_153, p154)
		end)
		for _, v155 in v_u_144:GetChildren() do
			v_u_153(v155)
		end
	end
end
workspace:GetPropertyChangedSignal("CurrentCamera"):Connect(v156)
v156()
workspace.ChildAdded:Connect(function(p157) -- name: workspaceMark
	-- upvalues: (copy) v_u_11, (copy) v_u_74
	local v158 = v_u_11.TOOLS[p157.Name]
	if v158 and v158.where == "Workspace" then
		task.defer(v_u_74, p157, "Workspace")
	end
end)
for _, v159 in workspace:GetChildren() do
	local v160 = v_u_11.TOOLS[v159.Name]
	if not v160 or v160.where ~= "Workspace" then
		continue
	end
	task.defer(v_u_74, v159, "Workspace")
end
local function v_u_172(p_u_161, p_u_162) -- name: watchMovers
	-- upvalues: (copy) v_u_11, (copy) v_u_74, (copy) v_u_123, (copy) v_u_66, (copy) v_u_2, (copy) v_u_18, (copy) v_u_132
	local function v169(p_u_163) -- name: look
		-- upvalues: (ref) v_u_11, (copy) p_u_162, (copy) p_u_161, (ref) v_u_74, (ref) v_u_123, (ref) v_u_66, (ref) v_u_2, (ref) v_u_18, (ref) v_u_132
		local v164 = v_u_11.TOOLS[p_u_163.Name]
		if v164 and v164.where == p_u_162 then
			task.delay(1, function()
				-- upvalues: (copy) p_u_163, (ref) p_u_161, (ref) v_u_74, (ref) p_u_162
				if p_u_163.Parent and p_u_163:IsDescendantOf(p_u_161) then
					v_u_74(p_u_163, p_u_162)
				end
			end)
			return
		elseif p_u_163:IsA("BodyMover") or v_u_123[p_u_163.ClassName] == true then
			task.delay(2, function()
				-- upvalues: (copy) p_u_163, (ref) p_u_161, (ref) v_u_11, (ref) v_u_66, (ref) v_u_2, (ref) v_u_18, (ref) p_u_162, (ref) v_u_132
				if p_u_163.Parent and (p_u_163:IsDescendantOf(p_u_161) and (v_u_11.MOVERS[p_u_163.ClassName] and not v_u_66[p_u_163])) then
					v_u_66[p_u_163] = true
					local v165 = v_u_2
					local v166 = v_u_18
					local v167 = {
						["kind"] = "mover",
						["id"] = nil,
						["where"] = nil,
						["on"] = nil,
						["id"] = p_u_163.ClassName,
						["where"] = p_u_162
					}
					local v168 = p_u_163.Parent.Name
					v167.on = string.sub(v168, 1, 40)
					pcall(v165, v166, "Tool", v167)
				else
					v_u_132(p_u_163, p_u_162)
				end
			end)
		end
	end
	local v170 = p_u_161.DescendantAdded:Connect(v169)
	for _, v171 in p_u_161:GetDescendants() do
		v169(v171)
	end
	return v170
end
local v_u_173 = nil
local function v_u_178(p174) -- name: watchBody
	-- upvalues: (copy) v_u_172, (ref) v_u_173
	v_u_172(p174, "Body")
	local v_u_175 = p174:WaitForChild("Humanoid", 10)
	if v_u_175 then
		v_u_175:GetPropertyChangedSignal("SeatPart"):Connect(function()
			-- upvalues: (ref) v_u_173, (copy) v_u_175, (ref) v_u_172
			if v_u_173 then
				v_u_173:Disconnect()
				v_u_173 = nil
			end
			local v176 = v_u_175.SeatPart
			local v177 = workspace:FindFirstChild("SpawnedVehicles")
			if v176 and (v177 and v176:IsDescendantOf(v177)) then
				while v176.Parent ~= v177 do
					v176 = v176.Parent
				end
				v_u_173 = v_u_172(v176, "Vehicle")
			end
		end)
	end
end
v_u_16.CharacterAdded:Connect(function(p179)
	-- upvalues: (copy) v_u_178
	task.spawn(v_u_178, p179)
end)
if v_u_16.Character then
	task.spawn(v_u_178, v_u_16.Character)
end
for _, v180 in v_u_11.ODD_SERVICES do
	local v181 = game.FindService
	local v182 = game
	local v183, v184 = pcall(v181, v182, v180)
	if not (v183 and v184) then
		continue
	end
	local v_u_185 = "S:" .. v180
	v184.ChildAdded:Connect(function(p186)
		-- upvalues: (copy) v_u_132, (copy) v_u_185
		task.delay(2, v_u_132, p186, v_u_185)
	end)
end
local v_u_187 = game:GetService("UserInputService")
local v_u_188 = game:GetService("GuiService")
local v_u_189 = game:GetService("LogService")
local v_u_190 = game:GetService("StarterGui")
local v191 = game:GetService("MarketplaceService")
local v_u_192 = 0
local v_u_193 = 0
local v_u_194 = true
v_u_187.TouchStarted:Connect(function()
	-- upvalues: (ref) v_u_192, (ref) v_u_193
	v_u_192 = v_u_192 + 1
	v_u_193 = os.clock()
end)
v_u_187.TouchEnded:Connect(function()
	-- upvalues: (ref) v_u_192
	local v195 = v_u_192 - 1
	v_u_192 = math.max(0, v195)
end)
v_u_187.InputBegan:Connect(function(p196)
	-- upvalues: (ref) v_u_193
	if p196.UserInputType ~= Enum.UserInputType.Focus then
		v_u_193 = os.clock()
	end
end)
v_u_187.InputChanged:Connect(function(p197)
	-- upvalues: (ref) v_u_193
	if p197.UserInputType ~= Enum.UserInputType.Accelerometer and (p197.UserInputType ~= Enum.UserInputType.Gyro and p197.UserInputType ~= Enum.UserInputType.Focus) then
		v_u_193 = os.clock()
	end
end)
v_u_187.WindowFocused:Connect(function()
	-- upvalues: (ref) v_u_194
	v_u_194 = true
end)
v_u_187.WindowFocusReleased:Connect(function()
	-- upvalues: (ref) v_u_194, (ref) v_u_192
	v_u_194 = false
	v_u_192 = 0
end)
local function v_u_204() -- name: handsOn
	-- upvalues: (ref) v_u_192, (ref) v_u_194, (ref) v_u_193, (copy) v_u_187
	if v_u_192 > 0 or v_u_194 and os.clock() - v_u_193 < 1.5 then
		return true
	end
	if #v_u_187:GetKeysPressed() > 0 or #v_u_187:GetMouseButtonsPressed() > 0 then
		return true
	end
	for _, v198 in v_u_187:GetConnectedGamepads() do
		for _, v199 in v_u_187:GetGamepadState(v198) do
			local v200 = v199.Position
			if v199.UserInputState ~= Enum.UserInputState.Begin then
				local v201 = v200.X
				if math.abs(v201) <= 0.15 then
					local v202 = v200.Y
					if math.abs(v202) <= 0.15 then
						local v203 = v200.Z
						if math.abs(v203) <= 0.15 then
							continue
						end
					end
				end
			end
			return true
		end
	end
	return false
end
task.spawn(function()
	-- upvalues: (copy) v_u_16, (copy) v_u_204, (ref) v_u_194, (copy) v_u_2, (copy) v_u_18
	local v205 = os.clock()
	local v206 = 0
	local v207 = 0
	local v208 = 0
	while true do
		task.wait(0.5)
		local v209 = os.clock()
		local v210 = v209 - v205
		local v211 = math.min(v210, 1)
		local v212 = v_u_16.Character
		local v213
		if v212 then
			v213 = v212:FindFirstChildOfClass("Humanoid")
		else
			v213 = v212
		end
		if v213 then
			v213 = v213.SeatPart
		end
		if v212 then
			v212 = v212:FindFirstChild("HumanoidRootPart")
		end
		if v213 and (v212 and (v213:IsA("VehicleSeat") or v213.Name == "DriverSeat")) then
			local v214 = v212.AssemblyLinearVelocity
			local v215 = v214.X
			local v216 = v214.Z
			if Vector3.new(v215, 0, v216).Magnitude >= 25 then
				local v217 = v_u_204
				local v218, v219 = pcall(v217)
				v206 = v206 + v211
				if not v218 or v219 then
					v207 = v207 + v211
				end
				if not v_u_194 then
					v208 = v208 + v211
				end
				if v206 >= 30 then
					local v220 = v_u_2
					local v221 = v_u_18
					pcall(v220, v221, "Hands", {
						["ride"] = v206,
						["hands"] = v207,
						["away"] = v208
					})
					v206 = 0
					v207 = 0
					v208 = 0
				end
			end
		end
		v205 = v209
	end
end)
local v_u_222 = {}
local v_u_223 = v_u_16:GetMouse()
local function v_u_227(p224) -- name: forgetSunk
	-- upvalues: (copy) v_u_222
	local v225 = os.time()
	for v226 = #v_u_222, 1, -1 do
		if v225 - v_u_222[v226].t > p224 then
			continue
		end
		table.remove(v_u_222, v226)
	end
end
local v_u_228 = false
local function v_u_241(p229, p230, p231) -- name: robloxOwn
	-- upvalues: (copy) v_u_188, (copy) v_u_190
	if v_u_188.MenuIsOpen then
		return true
	end
	local v232 = v_u_190.GetCore
	local v233 = v_u_190
	local v234, v235 = pcall(v232, v233, "DevConsoleVisible")
	if v234 and v235 == true then
		return true
	end
	local v236 = v_u_188.GetEmotesMenuOpen
	local v237 = v_u_188
	local v238, v239 = pcall(v236, v237)
	if v238 and v239 == true then
		return true
	end
	local v240
	if p230 < 0.14 * p231.Y or (p231.Y - 90 < p230 or p229 < 0.3 * p231.X and p230 < 0.5 * p231.Y) or 0.78 * p231.X < p229 and p230 < 0.6 * p231.Y then
		v240 = true
	elseif p231.X - 420 < p229 then
		v240 = p231.Y - 320 < p230
	else
		v240 = false
	end
	return v240
end
local v_u_242 = 0
local function v_u_246(p243, p244) -- name: takesClicks
	-- upvalues: (copy) v_u_17
	for _, v245 in v_u_17:GetGuiObjectsAtPosition(p243, p244) do
		if not (v245:IsA("GuiButton") or (v245:IsA("TextBox") or (v245:IsA("ScrollingFrame") or v245.Active))) then
			continue
		end
		return true
	end
	return false
end
for _, v247 in { v191.PromptPurchaseFinished, v191.PromptProductPurchaseFinished, v191.PromptGamePassPurchaseFinished } do
	v247:Connect(function()
		-- upvalues: (copy) v_u_227
		v_u_227(120)
	end)
end
v_u_187.InputBegan:Connect(function(p248, p249)
	-- upvalues: (ref) v_u_228, (copy) v_u_188, (copy) v_u_241, (ref) v_u_242, (copy) v_u_223, (copy) v_u_246, (copy) v_u_187, (copy) v_u_222, (copy) v_u_2, (copy) v_u_18
	if v_u_228 or p248.UserInputType ~= Enum.UserInputType.MouseButton1 then
		return
	else
		local v250 = workspace.CurrentCamera
		if v250 then
			v250 = v250.ViewportSize
		end
		if v250 then
			local v251 = p248.Position.X
			local v252 = p248.Position.Y
			local v253 = v_u_188:GetGuiInset()
			if v_u_241(v251, v252 + v253.Y, v250) then
				return
			elseif p249 then
				local v254 = v_u_223.Target
				if v_u_246(v251, v252) or (v_u_246(v251, v252 + v253.Y) or (v_u_187:GetFocusedTextBox() or v254 and v254:FindFirstChildWhichIsA("SurfaceGui"))) then
					return
				else
					local v255 = v_u_222
					local v256 = {
						["t"] = os.time(),
						["x"] = v251,
						["y"] = v252
					}
					table.insert(v255, v256)
					if #v_u_222 >= 12 and v_u_242 >= 5 then
						local v257 = {}
						local v258 = (1 / 0)
						local v259 = (-1 / 0)
						local v260 = (1 / 0)
						local v261 = (-1 / 0)
						local v262 = 0
						for _, v263 in v_u_222 do
							if not v257[v263.t // 60] then
								v257[v263.t // 60] = true
								v262 = v262 + 1
							end
							local v264 = v263.x
							v258 = math.min(v258, v264)
							local v265 = v263.x
							v259 = math.max(v259, v265)
							local v266 = v263.y
							v260 = math.min(v260, v266)
							local v267 = v263.y
							v261 = math.max(v261, v267)
						end
						if v262 >= 2 then
							v_u_228 = true
							local v268 = v_u_2
							local v269 = v_u_18
							local v270 = {
								["n"] = #v_u_222,
								["minutes"] = v262,
								["free"] = v_u_242,
								["x0"] = v258,
								["x1"] = v259,
								["y0"] = v260,
								["y1"] = v261
							}
							pcall(v268, v269, "Sink", v270)
						end
					end
				end
			else
				v_u_242 = v_u_242 + 1
				return
			end
		else
			return
		end
	end
end)
local v_u_271 = {}
local v_u_272 = {
	"^ContentId: ",
	"^Failed to load ",
	"failed due to: ",
	"^%[Roblox%]",
	"^Infinite yield possible"
}
local function v_u_278(p273) -- name: toolish
	-- upvalues: (copy) v_u_11
	if string.sub(p273, 1, 1) == "[" then
		return true
	end
	for _, v274 in v_u_11.LOG_MARKS do
		local v275 = #v274
		if string.sub(p273, 1, v275) ~= v274 then
			continue
		end
		return true
	end
	local v276 = string.lower(p273)
	for _, v277 in v_u_11.LOG_WORDS do
		if not string.find(v276, v277, 1, true) then
			continue
		end
		return true
	end
	return false
end
local function v_u_293(p279, p280) -- name: keepLine
	-- upvalues: (copy) v_u_272, (copy) v_u_271, (copy) v_u_278
	for _, v281 in v_u_272 do
		if not string.find(p279, v281) then
			continue
		end
		v282 = true
	end
	local v282 = false
	if v282 then
		return
	end
	local v283 = p280 == Enum.MessageType.MessageWarning and "W " or (p280 == Enum.MessageType.MessageError and "E " or "")
	local v284 = v_u_271
	local v285 = {}
	local v286 = 160
	local v287
	if #p279 <= v286 then
		v287 = p279
	else
		while v286 > 0 do
			local v288 = v286 + 1
			local v289 = string.byte(p279, v288)
			if bit32.band(v289, 192) ~= 128 then
				break
			end
			v286 = v286 - 1
		end
		v287 = string.sub(p279, 1, v286)
	end
	v285.text = v283 .. v287
	v285.tool = v_u_278(p279)
	table.insert(v284, v285)
	if #v_u_271 > 40 then
		local v290 = 1
		for v291, v292 in v_u_271 do
			if v292.tool then
				continue
			end
			v290 = v291
		end
		table.remove(v_u_271, v290)
	end
end
local function v_u_309() -- name: pickLogs
	-- upvalues: (copy) v_u_271
	local v294 = 0
	for _, v295 in v_u_271 do
		if not v295.tool then
			continue
		end
		v294 = v294 + 1
	end
	local v296 = 24 - math.min(v294, 16)
	local v297 = math.max(0, v296)
	local v298 = 0
	for _, v299 in v_u_271 do
		if v299.tool then
			continue
		end
		v298 = v298 + 1
	end
	local v300 = v298 - v297
	local v301 = math.max(0, v300)
	local v302 = 0
	local v303 = {}
	local v304 = {}
	for _, v305 in v_u_271 do
		if v305.tool then
			v302 = v302 + 1
			if v302 > 16 then
				continue
			end
			local v306 = v305.text
			table.insert(v303, v306)
		elseif v301 > 0 then
			v301 = v301 - 1
		else
			local v307 = v305.text
			table.insert(v304, v307)
		end
	end
	if #v303 > 0 and #v304 > 0 then
		table.insert(v303, "-- \224\184\173\224\184\183\224\185\136\224\184\153\224\185\134 --")
	end
	for _, v308 in v304 do
		table.insert(v303, v308)
	end
	return v303
end
local v_u_310 = 0
local v_u_311 = game:GetService("RunService"):IsStudio()
local v_u_312 = nil
local v_u_313 = false
local function v_u_326(p314, p315) -- name: onLine
	-- upvalues: (ref) v_u_312, (copy) v_u_311, (ref) v_u_313, (copy) v_u_293, (ref) v_u_310, (copy) v_u_11, (copy) v_u_2, (copy) v_u_18
	if type(p314) == "string" then
		if v_u_312 and p314 == v_u_312 then
			if not v_u_311 or workspace:GetAttribute("ZZPretendDeaf") ~= true then
				v_u_313 = true
			end
			return
		else
			v_u_293(p314, p315)
			if v_u_310 < 4 then
				for _, v316 in v_u_11.LOG_MARKS do
					local v317 = #v316
					if string.sub(p314, 1, v317) ~= v316 then
						continue
					end
					v_u_310 = 99
					local v318 = v_u_2
					local v319 = v_u_18
					local v320 = {
						["kind"] = "logmark",
						["id"] = nil,
						["text"] = nil,
						["id"] = v316,
						["text"] = string.sub(p314, 1, 120)
					}
					pcall(v318, v319, "Tool", v320)
					return
				end
				local v321 = string.lower(p314)
				for _, v322 in v_u_11.LOG_WORDS do
					if not string.find(v321, v322, 1, true) then
						continue
					end
					v_u_310 = v_u_310 + 1
					local v323 = v_u_2
					local v324 = v_u_18
					local v325 = {
						["word"] = v322,
						["text"] = string.sub(p314, 1, 140)
					}
					pcall(v323, v324, "Log", v325)
					return
				end
			end
		end
	else
		return
	end
end
pcall(function()
	-- upvalues: (copy) v_u_189, (copy) v_u_326
	local v327 = v_u_189:GetLogHistory()
	local v328 = #v327 - 40 + 1
	for v329 = math.max(1, v328), #v327 do
		v_u_326(v327[v329].message, v327[v329].messageType)
	end
end)
v_u_189.MessageOut:Connect(v_u_326)
task.spawn(function()
	-- upvalues: (copy) v_u_311, (ref) v_u_312, (ref) v_u_313, (copy) v_u_189, (copy) v_u_2, (copy) v_u_18
	local v330 = task.wait
	local v331 = v_u_311
	if v331 then
		v331 = workspace:GetAttribute("ZZTapFast") == true
	end
	v330(v331 and 4 or 45)
	local v332 = 0
	while true do
		v_u_312 = ("[MR] ok %06x"):format(math.random(0, 16777215))
		v_u_313 = false
		print(v_u_312)
		task.wait(3)
		if not v_u_313 then
			task.wait(2)
		end
		if v_u_313 then
			v332 = 0
		else
			v332 = v332 + 1
			if v332 >= 2 then
				local v_u_333 = v_u_312
				local v_u_334 = false
				local function v339()
					-- upvalues: (ref) v_u_189, (copy) v_u_333, (ref) v_u_334
					local v335 = v_u_189:GetLogHistory()
					local v336 = #v335
					local v337 = #v335 - 400
					for v338 = v336, math.max(1, v337), -1 do
						if v335[v338].message ~= v_u_333 then
							continue
						end
						v_u_334 = true
						return
					end
				end
				pcall(v339)
				local v340 = v_u_2
				local v341 = v_u_18
				local v342 = {
					["kind"] = "logtap",
					["history"] = nil,
					["history"] = v_u_334
				}
				pcall(v340, v341, "Tool", v342)
				return
			end
		end
		local v343 = task.wait
		local v344
		if v332 > 0 then
			v344 = 12
		else
			local v345 = v_u_311
			if v345 then
				v345 = workspace:GetAttribute("ZZTapFast") == true
			end
			v344 = v345 and 5 or 240
		end
		v343(v344)
	end
end)
local v_u_346 = {}
local v_u_347 = {}
for v_u_348, v349 in v_u_11.TAMPER do
	local v350 = v_u_9
	for v351 in string.gmatch(v_u_348, "[^%.]+") do
		if not v_u_9 then
			continue
		end
		v_u_9 = v_u_9:FindFirstChild(v351)
	end
	local v352, v353 = pcall(function()
		-- upvalues: (copy) v_u_348, (copy) v_u_1, (ref) v_u_9
		if v_u_348 == "NetSeal" then
			return v_u_1
		else
			return require(v_u_9)
		end
	end)
	if v352 and type(v353) == "table" then
		for _, v354 in v349 do
			local v355 = {
				["id"] = v_u_348 .. "." .. v354,
				["tbl"] = v353,
				["field"] = v354,
				["was"] = rawget(v353, v354)
			}
			table.insert(v_u_346, v355)
		end
	end
	v_u_9 = v350
end
local v_u_356 = game:GetService("RunService"):IsStudio()
local v_u_357 = {}
local v_u_358 = {}
local function v365(p359, p360) -- name: watchFn
	-- upvalues: (copy) v_u_358, (copy) v_u_13, (copy) v_u_357
	if type(p360) == "function" and not v_u_358[p359] then
		local v361 = debug.info
		local v362, v363 = pcall(v361, p360, "s")
		if v362 and (type(v363) == "string" and (v363 ~= "[C]" and not v_u_13(v363))) then
			v_u_358[p359] = true
			local v364 = v_u_357
			table.insert(v364, {
				["id"] = p359,
				["f"] = p360,
				["was"] = v363
			})
		end
	end
end
v365("NetSeal.fire", v_u_2)
v365("NetSeal.invoke", v3)
for _, v366 in v_u_346 do
	v365(v366.id, v366.was)
end
for v367, v368 in v_u_11 do
	if type(v367) ~= "string" then
		continue
	end
	v365("UiGuardShared." .. v367, v368)
end
if v_u_356 then
	script:SetAttribute("HookWatch", #v_u_357)
end
task.spawn(function()
	-- upvalues: (copy) v_u_346, (copy) v_u_347, (copy) v_u_2, (copy) v_u_18, (copy) v_u_12, (copy) v_u_356, (copy) v_u_357, (copy) v_u_13, (copy) v_u_11
	-- control flow flattened: this region could not be structured without a goto (unsupported in Luau), so it was lowered to the state-machine dispatch loop below to keep the output runnable.
	local v369, v370, v371, v372, v373, v374, v375, v376, v377, v378, v379, v380, v381, v382, v383, v384, v385, v386, v387, v388, v389, v390, v391, v392, v393, v394, v395, v396, v397, v398, v399, v400, v401, v402, v403, v404
	local v405 = 3
	while true do
		if v405 == 1 then
			::l0::
			while true do
				while true do
					v401 = nil
					v385 = {}
					for _, v406 in v_u_346 do
						v372 = v406.tbl
						v390 = v406.field
						v386 = rawget(v372, v390)
						if v386 == v406.was or v_u_347[v406.id] then
							continue
						end
						v_u_347[v406.id] = true
						if not v401 then
							v401 = {
								["id"] = v406.id
							}
							v373 = v406.was
							v374 = tostring(v373)
							v401.was = string.sub(v374, 1, 24)
							v402 = tostring(v386)
							v401.now = string.sub(v402, 1, 24)
						end
						if type(v386) == "number" then
							v388 = ("%s=%s"):format(v406.id, (tostring(v386)))
						else
							v388 = v406.id
						end
						table.insert(v385, v388)
					end
					if v401 then
						v383 = v_u_2
						v371 = v_u_18
						v389 = {
							["kind"] = "tamper",
							["id"] = nil,
							["was"] = nil,
							["now"] = nil,
							["all"] = nil,
							["id"] = v401.id,
							["was"] = v401.was,
							["now"] = v401.now
						}
						v384 = table.concat(v385, ", ")
						v389.all = string.sub(v384, 1, 400)
						pcall(v383, v371, "Tool", v389)
					end
					if v_u_12 and not v_u_347.listtamper then
						break
					end
					if not v_u_347.hook then
						if v_u_356 then
							v400 = workspace:GetAttribute("ZZPretendHook")
						else
							v400 = nil
						end
						for v421, v422 in v_u_357 do
							v387 = debug.info
							v391 = v422.f
							v392, v379 = pcall(v387, v391, "s")
							if v400 == v422.id then
								v392 = true
								v379 = "[C]"
							end
							if not v392 or (type(v379) ~= "string" or (v379 == v422.was or v379 ~= "[C]" and not v_u_13(v379))) then
								continue
							end
							v_u_347.hook = true
							v375 = v_u_2
							v397 = v_u_18
							v380 = {
								["kind"] = "hook",
								["id"] = nil,
								["was"] = nil,
								["now"] = nil,
								["id"] = v422.id
							}
							v398 = v422.was
							v380.was = string.sub(v398, 1, 60)
							v380.now = string.sub(v379, 1, 60)
							pcall(v375, v397, "Tool", v380)
						end
					end
					for v423, v424 in v_u_11.GLOBALS do
						v393 = _G
						if rawget(v393, v424) == nil or v_u_347["_G." .. v424] then
							continue
						end
						v_u_347["_G." .. v424] = true
						v399 = v_u_2
						v376 = v_u_18
						pcall(v399, v376, "Tool", {
							["kind"] = "global",
							["id"] = nil,
							["id"] = v424
						})
					end
					task.wait(4)
				end
				v381 = v_u_12
				v377, v382 = pcall(v381)
				if v377 and (type(v382) == "table" and #v382 > 0) then
					break
				end
				if not v_u_347.hook then
					if v_u_356 then
						v400 = workspace:GetAttribute("ZZPretendHook")
					else
						v400 = nil
					end
					for v421, v422 in v_u_357 do
						v387 = debug.info
						v391 = v422.f
						v392, v379 = pcall(v387, v391, "s")
						if v400 == v422.id then
							v392 = true
							v379 = "[C]"
						end
						if not v392 or (type(v379) ~= "string" or (v379 == v422.was or v379 ~= "[C]" and not v_u_13(v379))) then
							continue
						end
						v_u_347.hook = true
						v375 = v_u_2
						v397 = v_u_18
						v380 = {
							["kind"] = "hook",
							["id"] = nil,
							["was"] = nil,
							["now"] = nil,
							["id"] = v422.id
						}
						v398 = v422.was
						v380.was = string.sub(v398, 1, 60)
						v380.now = string.sub(v379, 1, 60)
						pcall(v375, v397, "Tool", v380)
					end
				end
				for v423, v424 in v_u_11.GLOBALS do
					v393 = _G
					if rawget(v393, v424) == nil or v_u_347["_G." .. v424] then
						continue
					end
					v_u_347["_G." .. v424] = true
					v399 = v_u_2
					v376 = v_u_18
					pcall(v399, v376, "Tool", {
						["kind"] = "global",
						["id"] = nil,
						["id"] = v424
					})
				end
				task.wait(4)
			end
			v_u_347.listtamper = true
			v403 = {}
			for v415, v416 in v382 do
				goto l19
			end
			v394 = v_u_2
			v395 = v_u_18
			pcall(v394, v395, "Tool", {
				["kind"] = "listtamper",
				["list"] = nil,
				["list"] = v403
			})
			if not v_u_347.hook then
				if v_u_356 then
					v400 = workspace:GetAttribute("ZZPretendHook")
				else
					v400 = nil
				end
				for v421, v422 in v_u_357 do
					v387 = debug.info
					v391 = v422.f
					v392, v379 = pcall(v387, v391, "s")
					if v400 == v422.id then
						v392 = true
						v379 = "[C]"
					end
					if not v392 or (type(v379) ~= "string" or (v379 == v422.was or v379 ~= "[C]" and not v_u_13(v379))) then
						continue
					end
					v_u_347.hook = true
					v375 = v_u_2
					v397 = v_u_18
					v380 = {
						["kind"] = "hook",
						["id"] = nil,
						["was"] = nil,
						["now"] = nil,
						["id"] = v422.id
					}
					v398 = v422.was
					v380.was = string.sub(v398, 1, 60)
					v380.now = string.sub(v379, 1, 60)
					pcall(v375, v397, "Tool", v380)
				end
			end
			for v423, v424 in v_u_11.GLOBALS do
				v393 = _G
				if rawget(v393, v424) == nil or v_u_347["_G." .. v424] then
					continue
				end
				v_u_347["_G." .. v424] = true
				v399 = v_u_2
				v376 = v_u_18
				pcall(v399, v376, "Tool", {
					["kind"] = "global",
					["id"] = nil,
					["id"] = v424
				})
			end
			task.wait(4)
			goto l0
			break
		elseif v405 == 2 then
			::l19::
			if v415 <= 6 then
				v378 = {}
				v404 = v416.name
				v369 = tostring(v404)
				v378.name = string.sub(v369, 1, 32)
				v378.added = v416.added
				v378.removed = v416.removed
				v378.fn = v416.fn
				if v416.value then
					v370 = v416.value
					v396 = string.sub(v370, 1, 40)
				else
					v396 = nil
				end
				v378.value = v396
				v378.newField = v416.newField
				table.insert(v403, v378)
			end
			v394 = v_u_2
			v395 = v_u_18
			pcall(v394, v395, "Tool", {
				["kind"] = "listtamper",
				["list"] = nil,
				["list"] = v403
			})
			if not v_u_347.hook then
				if v_u_356 then
					v400 = workspace:GetAttribute("ZZPretendHook")
				else
					v400 = nil
				end
				for v421, v422 in v_u_357 do
					v387 = debug.info
					v391 = v422.f
					v392, v379 = pcall(v387, v391, "s")
					if v400 == v422.id then
						v392 = true
						v379 = "[C]"
					end
					if not v392 or (type(v379) ~= "string" or (v379 == v422.was or v379 ~= "[C]" and not v_u_13(v379))) then
						continue
					end
					v_u_347.hook = true
					v375 = v_u_2
					v397 = v_u_18
					v380 = {
						["kind"] = "hook",
						["id"] = nil,
						["was"] = nil,
						["now"] = nil,
						["id"] = v422.id
					}
					v398 = v422.was
					v380.was = string.sub(v398, 1, 60)
					v380.now = string.sub(v379, 1, 60)
					pcall(v375, v397, "Tool", v380)
				end
			end
			for v423, v424 in v_u_11.GLOBALS do
				v393 = _G
				if rawget(v393, v424) == nil or v_u_347["_G." .. v424] then
					continue
				end
				v_u_347["_G." .. v424] = true
				v399 = v_u_2
				v376 = v_u_18
				pcall(v399, v376, "Tool", {
					["kind"] = "global",
					["id"] = nil,
					["id"] = v424
				})
			end
			task.wait(4)
			v405 = 1
		else
			v405 = 1
		end
	end
end)
local function v426(p425) -- name: added
	-- upvalues: (copy) v_u_17, (copy) v_u_74, (copy) v_u_82, (copy) v_u_14, (copy) v_u_93, (copy) v_u_105
	if p425.Parent == v_u_17 and (not p425:IsA("ScreenGui") and v_u_74(p425, "PlayerGui")) then
		return
	elseif p425:IsA("ScreenGui") then
		task.delay(1, v_u_82, p425)
		return
	elseif p425:IsA("GuiObject") and not v_u_14.mine(p425) then
		task.delay(1, v_u_93, p425)
	elseif p425:IsA("LayerCollector") and not v_u_14.mine(p425) then
		task.delay(1, v_u_105, p425)
	end
end
v_u_17.DescendantAdded:Connect(v426)
for _, v427 in v_u_17:GetDescendants() do
	task.defer(v426, v427)
end
local function v_u_431(p428) -- name: namesSomeone
	-- upvalues: (copy) v_u_8
	local v429 = string.lower(p428)
	for _, v430 in v_u_8:GetPlayers() do
		if not (string.find(v429, string.lower(v430.Name), 1, true) or string.find(v429, string.lower(v430.DisplayName), 1, true)) then
			continue
		end
		return true
	end
	return false
end
local function v_u_444() -- name: sweep
	-- upvalues: (copy) v_u_17, (copy) v_u_11, (copy) v_u_56, (copy) v_u_431, (copy) v_u_103, (copy) v_u_57, (copy) v_u_14
	for _, v432 in v_u_17:GetChildren() do
		if not v432:IsA("ScreenGui") or (v_u_11.SWEEP_SKIP[v432.Name] or not v_u_56(v432)) then
			continue
		end
		local v433 = {}
		local v434 = {}
		for _, v435 in v432:GetDescendants() do
			if not (v435:IsA("TextLabel") or v435:IsA("TextButton")) or v435.Text == "" then
				continue
			end
			table.insert(v433, v435)
			local v436 = v435.Text
			table.insert(v434, v436)
		end
		local v437 = v_u_11.judge("", { table.concat(v434, "\n") })
		if v437.hub or v437.strong then
			for _, v438 in v433 do
				local v439 = v_u_11.judge("", { v438.Text })
				if not (v439.hub or v439.strong) or v_u_431(v438.Text) then
					continue
				end
				local v440 = v_u_103
				local v441 = ("%s/Text/%s"):format(v432.Name, v438.Name)
				local v442 = { v_u_57(v438.Text) }
				local v443 = v_u_11.isMarked(v432.Name)
				if v443 then
					v443 = not v_u_14.mine(v438)
				end
				v440(v438, v441, v442, v443)
			end
		end
		task.wait()
	end
end
local function v_u_448() -- name: staffWindows
	-- upvalues: (copy) v_u_15, (copy) v_u_16, (copy) v_u_11, (copy) v_u_17, (copy) v_u_103
	if not v_u_15.isStaff(v_u_16) then
		for v445, v446 in v_u_11.STAFF_ONLY do
			if v445 == "BanMenu" and v_u_16:GetAttribute("BanMenu") == true then
				continue
			end
			local v447 = v_u_17:FindFirstChild(v445)
			if v447 and type(v446) == "string" then
				v447 = v447:FindFirstChild(v446)
			end
			if not (v447 and v_u_11.onScreen(v447)) then
				continue
			end
			v_u_103(v447, v445 .. " (not staff)")
		end
	end
end
task.spawn(function()
	-- upvalues: (copy) v_u_444, (copy) v_u_448, (copy) v_u_106, (copy) v_u_108, (copy) v_u_17, (copy) v_u_56, (copy) v_u_82, (copy) v_u_4, (copy) v_u_16, (copy) v_u_52, (copy) v_u_2, (copy) v_u_18, (ref) v_u_110, (ref) v_u_109, (ref) v_u_111, (copy) v_u_11
	while true do
		local v449 = v_u_444
		pcall(v449)
		local v450 = v_u_448
		pcall(v450)
		if v_u_106 then
			for _, v451 in v_u_106:GetChildren() do
				local v452 = v_u_108
				pcall(v452, v451)
			end
		end
		local v453 = 0
		for _, v454 in v_u_17:GetChildren() do
			if not v454:IsA("ScreenGui") or v_u_56(v454) then
				continue
			end
			v453 = v453 + 1
			v_u_82(v454)
		end
		local v455 = v_u_4 or function()
			return 0
		end
		local v456, v457 = pcall(v455)
		local function v459()
			-- upvalues: (ref) v_u_16
			local v458 = game:GetService("RunService"):IsStudio()
			if v458 then
				v458 = workspace:GetAttribute("ZZPretendName")
			end
			if type(v458) == "string" and v458 ~= "" then
				return v458
			else
				return v_u_16.Name
			end
		end
		local v460, v461 = pcall(v459)
		local function v466()
			-- upvalues: (ref) v_u_16, (ref) v_u_52
			local v462 = v_u_16.Character
			if v462 then
				v462 = v_u_16.Character:FindFirstChild("Head")
			end
			if not v462 then
				return nil
			end
			local v463 = v462:FindFirstChild("Nametag")
			if not (v463 and v463:IsA("BillboardGui")) then
				return {
					["gone"] = true
				}
			end
			local v464 = {
				["fp"] = v_u_52(v463)
			}
			local v465
			if v463.Enabled == false then
				v465 = v463:GetAttribute("GameHid") ~= true
			else
				v465 = false
			end
			v464.off = v465
			return v464
		end
		local v467, v468 = pcall(v466)
		local v469 = v_u_2
		local v470 = v_u_18
		local v471 = "Beat"
		local v472 = (not v456 or type(v457) ~= "number") and 0 or v457
		if v_u_110 then
			v472 = bit32.bor(v472, 8)
		end
		if v_u_109 then
			v472 = bit32.bor(v472, 16)
		end
		if v_u_111 then
			v472 = bit32.bor(v472, 32)
		end
		local v473
		if v460 and type(v461) == "string" then
			v473 = string.sub(v461, 1, 40)
		else
			v473 = nil
		end
		if not v467 then
			v468 = nil
		end
		pcall(v469, v470, v471, v453, v472, v473, v468)
		task.wait(v_u_11.BEAT_EVERY)
	end
end)
local function v_u_475(p474) -- name: visible
	-- upvalues: (copy) v_u_17
	while p474 and p474 ~= v_u_17 do
		if p474:IsA("GuiObject") and not p474.Visible then
			return false
		end
		if p474:IsA("ScreenGui") and not p474.Enabled then
			return false
		end
		p474 = p474.Parent
	end
	return true
end
local function v_u_521() -- name: snapshot
	-- upvalues: (copy) v_u_17, (copy) v_u_56, (copy) v_u_57, (copy) v_u_11, (copy) v_u_14, (copy) v_u_475, (copy) v_u_309
	local v476 = workspace.CurrentCamera
	local v477 = v476 and v476.ViewportSize or Vector2.new(1280, 720)
	local v478 = {}
	local v_u_479 = {}
	local v480 = {}
	for _, v481 in v_u_17:GetDescendants() do
		if not v481:IsA("ScreenGui") then
			continue
		end
		table.insert(v478, v481)
	end
	table.sort(v478, function(p482, p483)
		-- upvalues: (ref) v_u_56
		local v484 = v_u_56(p482)
		if v484 == v_u_56(p483) then
			return p482.DisplayOrder < p483.DisplayOrder
		else
			return not v484
		end
	end)
	local function v505(p485, p486, p487) -- name: addBox
		-- upvalues: (ref) v_u_57, (copy) v_u_479
		local v488 = p485:IsA("TextLabel") or (p485:IsA("TextButton") or p485:IsA("TextBox"))
		local v489 = p485:IsA("ImageLabel") or p485:IsA("ImageButton")
		local v490 = p485.BackgroundTransparency
		if v490 >= 0.98 and not (v488 or v489) then
			return 0
		end
		local v491 = p485.BackgroundColor3
		local v492 = v491.R * 255
		local v493 = math.floor(v492) * 65536
		local v494 = v491.G * 255
		local v495 = v493 + math.floor(v494) * 256
		local v496 = v491.B * 255
		local v497 = v495 + math.floor(v496)
		local v498 = p485:IsA("GuiButton") and 4 or (v488 and 2 or (v489 and 3 or 1))
		local v499 = not (v488 and p487) and "" or v_u_57(p485.Text):gsub("[|\n]", " ")
		local v500 = v_u_479
		local v501 = p485.AbsolutePosition.X
		local v502 = p485.AbsolutePosition.Y
		local v503 = p485.AbsoluteSize.X
		local v504 = p485.AbsoluteSize.Y
		table.insert(v500, ("%d,%d,%d,%d,%d,%.2f,%d,%d|%s"):format(v501, v502, v503, v504, v497, v490, v498, p486, v499))
		return 1
	end
	local v506 = {}
	for _, v507 in v478 do
		if not (v_u_56(v507) and v_u_11.isMarked(v507.Name)) then
			continue
		end
		local v508 = 0
		for _, v509 in v507:GetDescendants() do
			if #v_u_479 >= v_u_11.MAX_BOXES then
				break
			end
			if not v509:IsA("GuiObject") or v_u_14.mine(v509) then
				continue
			end
			v508 = v508 + v505(v509, #v478 + #v506 + 1, true)
		end
		if v508 <= 0 then
			break
		end
		local v510 = {
			["name"] = nil,
			["known"] = false,
			["enabled"] = true,
			["shown"] = nil,
			["name"] = v_u_57(v507.Name .. " (put inside)"),
			["shown"] = v508
		}
		table.insert(v506, v510)
	end
	for v511, v512 in v478 do
		local v513 = v_u_56(v512)
		local v514 = 0
		if v512.Enabled then
			for _, v515 in v512:GetDescendants() do
				if #v_u_479 >= v_u_11.MAX_BOXES then
					break
				end
				if not v515:IsA("GuiObject") or (v515.AbsoluteSize.X < 3 or (v515.AbsoluteSize.Y < 3 or (not v_u_475(v515) or v513 and (v_u_11.isMarked(v512.Name) and not v_u_14.mine(v515))))) then
					continue
				end
				v514 = v514 + v505(v515, v511, not v513)
			end
		end
		local v516 = {
			["name"] = v_u_57(v512.Name),
			["known"] = v513,
			["enabled"] = v512.Enabled,
			["shown"] = v514
		}
		table.insert(v480, v516)
	end
	for _, v517 in v506 do
		table.insert(v480, v517)
	end
	local v518 = {}
	local v519 = v477.X
	v518.w = math.floor(v519)
	local v520 = v477.Y
	v518.h = math.floor(v520)
	v518.guis = v480
	v518.boxes = v_u_479
	v518.logs = v_u_309()
	return v518
end
local v_u_522 = table.freeze({ v_u_2, v_u_18, v_u_521 })
local function v_u_534(p523, p524, p525) -- name: onGuard
	-- upvalues: (copy) v_u_2, (copy) v_u_18, (copy) v_u_521, (copy) v_u_522, (ref) v_u_110
	local v526 = v_u_18
	local v527 = v_u_521
	if v_u_2 ~= v_u_522[1] or (v526 ~= v_u_522[2] or (v527 ~= v_u_522[3] or workspace:GetAttribute("ZZPretendSnapHook") == true and game:GetService("RunService"):IsStudio())) then
		v_u_110 = true
	end
	if p523 == "Snap" and type(p524) == "number" then
		local v528 = v_u_2
		local v529 = v_u_18
		local v530 = v_u_521()
		pcall(v528, v529, "Snap", p524, v530)
	elseif p523 == "Ack" and type(p524) == "number" then
		local v531 = v_u_2
		local v532 = v_u_18
		local v533 = typeof(p525) == "Instance"
		pcall(v531, v532, "Ack", p524, v533)
	end
end
v_u_18.OnClientEvent:Connect(v_u_534)
task.spawn(function()
	-- upvalues: (copy) v_u_534
	while true do
		task.wait(4)
		local v535 = v_u_534
		pcall(v535, "Self")
	end
end)
task.spawn(function()
	-- upvalues: (ref) v_u_109
	while true do
		local v_u_536 = workspace.CurrentCamera
		if v_u_536 and (v_u_536.Parent == workspace and not v_u_536:FindFirstChild("CamFxCache")) then
			local v537 = Instance.new("Folder")
			v537.Name = "CamFxCache"
			v537.AncestryChanged:Connect(function(_, p538)
				-- upvalues: (copy) v_u_536, (ref) v_u_109
				if p538 == nil and (v_u_536 == workspace.CurrentCamera and v_u_536.Parent == workspace) then
					v_u_109 = true
				end
			end)
			v537.Parent = v_u_536
		end
		task.wait(2)
	end
end)
local function v_u_540(p539) -- name: plateCheck
	-- upvalues: (ref) v_u_111
	if p539:IsA("ScreenGui") and (p539.Name == "PlateUI" and p539.DisplayOrder == 21) then
		v_u_111 = true
	end
end
v_u_17.ChildAdded:Connect(function(p_u_541)
	-- upvalues: (copy) v_u_540
	task.delay(0.5, function()
		-- upvalues: (ref) v_u_540, (copy) p_u_541
		local v542 = v_u_540
		local v543 = p_u_541
		pcall(v542, v543)
	end)
end)
for _, v544 in v_u_17:GetChildren() do
	pcall(v_u_540, v544)
end