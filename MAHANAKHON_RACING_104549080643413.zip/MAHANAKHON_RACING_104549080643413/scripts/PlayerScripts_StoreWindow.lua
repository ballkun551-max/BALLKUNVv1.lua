-- Path: Players/ygggggg55551/PlayerScripts/StoreWindow
-- Class: LocalScript  true/Enum.RunContext.Legacy
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = require(game:GetService("ReplicatedStorage"):WaitForChild("NetSeal"))
local v_u_2 = game:GetService("MarketplaceService")
local v_u_3 = game:GetService("Players")
local v4 = game:GetService("ReplicatedStorage")
local v_u_5 = game:GetService("SocialService")
local v_u_6 = game:GetService("TweenService")
local v_u_7 = require(v4:WaitForChild("GameShared"))
local v8 = v4:WaitForChild("GameUI")
local v_u_9 = require(v8:WaitForChild("Theme"))
local v_u_10 = require(v8:WaitForChild("Icons"))
local v_u_11 = require(v8:WaitForChild("Money"))
local v_u_12 = require(v8:WaitForChild("Toast"))
local v_u_13 = require(v8:WaitForChild("Store"))
local v_u_14 = require(v8:WaitForChild("StoreConfig"))
local v_u_15 = require(v8:WaitForChild("VehicleArt"))
local v_u_16 = v_u_3.LocalPlayer
local v_u_17 = v4:WaitForChild(v_u_7.REMOTES)
local v_u_18 = v_u_9.isTouch()
local v_u_19 = Color3.new(1, 1, 1)
local v_u_20 = {
	["gold"] = { Color3.fromRGB(255, 178, 36), Color3.fromRGB(134, 58, 0) },
	["pink"] = { Color3.fromRGB(240, 84, 172), Color3.fromRGB(112, 16, 80) },
	["purple"] = { Color3.fromRGB(150, 92, 255), Color3.fromRGB(62, 20, 156) },
	["orange"] = { Color3.fromRGB(255, 132, 52), Color3.fromRGB(146, 38, 10) },
	["green"] = { Color3.fromRGB(46, 204, 113), Color3.fromRGB(8, 86, 58) },
	["red"] = { Color3.fromRGB(244, 68, 86), Color3.fromRGB(116, 12, 34) },
	["blue"] = { Color3.fromRGB(66, 142, 255), Color3.fromRGB(20, 48, 146) },
	["teal"] = { Color3.fromRGB(26, 200, 180), Color3.fromRGB(6, 86, 94) }
}
local v_u_21 = {}
local v_u_22 = {
	"teal",
	"blue",
	"purple",
	"orange",
	"gold"
}
local v_u_23 = v_u_18 and 196 or 214
local v24 = v_u_18 and 38 or 44
local v_u_25 = v_u_18 and 236 or 262
local v_u_26 = v_u_18 and 170 or 200
local v27 = {
	{
		["id"] = "Passes",
		["label"] = nil,
		["icon"] = "gem",
		["grad"] = "gold",
		["label"] = v_u_18 and "Passes" or "Game Passes"
	},
	{
		["id"] = "Gifts",
		["label"] = "Gifts",
		["icon"] = "gift",
		["grad"] = "gold"
	},
	{
		["id"] = "Money",
		["label"] = "Money",
		["icon"] = "coin",
		["grad"] = "gold"
	},
	{
		["id"] = "Codes",
		["label"] = "Codes",
		["icon"] = "ticket",
		["grad"] = "gold"
	}
}
local v_u_28 = v_u_18 and 112 or 150
local v_u_29 = v_u_18 and 250 or 300
for _, v30 in v_u_7.VEHICLES do
	if not v30.pass then
		continue
	end
	v_u_21[v30.pass] = v_u_21[v30.pass] or {}
	local v31 = v_u_21[v30.pass]
	local v32 = v30.id
	table.insert(v31, v32)
end
local v33 = v_u_9.screen("StoreWindow", 55, v_u_16:WaitForChild("PlayerGui"))
local v_u_34 = v_u_9.window({
	["name"] = "StorePanel",
	["gui"] = nil,
	["icon"] = "crown",
	["grad"] = "gold",
	["title"] = "MHNK Store",
	["sub"] = "Game passes, gifts, cash and codes",
	["max"] = nil,
	["gui"] = v33,
	["max"] = Vector2.new(1180, 800)
})
local v35 = v_u_9.new("Frame", {
	["Name"] = "Pages",
	["BackgroundTransparency"] = 1,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["Position"] = UDim2.fromOffset(0, v24 + 10),
	["Size"] = UDim2.new(1, 0, 1, -(v24 + 10)),
	["Parent"] = v_u_34.body
})
local v_u_36 = {
	["owned"] = {},
	["codes"] = {}
}
local v_u_37 = {}
local function v40(p38) -- name: scroller
	-- upvalues: (copy) v_u_9
	local v39 = v_u_9.new("ScrollingFrame", {
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["CanvasSize"] = nil,
		["AutomaticCanvasSize"] = nil,
		["ScrollingDirection"] = nil,
		["ScrollBarThickness"] = 4,
		["ScrollBarImageColor3"] = nil,
		["ScrollBarImageTransparency"] = 0.3,
		["Parent"] = nil,
		["Size"] = UDim2.fromScale(1, 1),
		["CanvasSize"] = UDim2.new(),
		["AutomaticCanvasSize"] = Enum.AutomaticSize.Y,
		["ScrollingDirection"] = Enum.ScrollingDirection.Y,
		["ScrollBarImageColor3"] = v_u_9.TEXT_DIM,
		["Parent"] = p38
	})
	v_u_9.new("UIPadding", {
		["PaddingTop"] = UDim.new(0, 2),
		["PaddingRight"] = UDim.new(0, 10),
		["PaddingBottom"] = UDim.new(0, 12),
		["Parent"] = v39
	})
	v_u_9.new("UIListLayout", {
		["Padding"] = UDim.new(0, 14),
		["SortOrder"] = Enum.SortOrder.LayoutOrder,
		["Parent"] = v39
	})
	return v39
end
local function v_u_56(p41, p42, p_u_43, p_u_44) -- name: grid
	-- upvalues: (copy) v_u_9
	local v_u_45 = v_u_9.new("Frame", {
		["Name"] = "Grid",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = nil,
		["Parent"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y,
		["LayoutOrder"] = p42,
		["Parent"] = p41
	})
	local v_u_46 = v_u_9.new("UIGridLayout", {
		["CellPadding"] = UDim2.fromOffset(14, 14),
		["SortOrder"] = Enum.SortOrder.LayoutOrder,
		["Parent"] = v_u_45
	})
	local v_u_47 = -1
	local function v55() -- name: layout
		-- upvalues: (ref) v_u_9, (copy) v_u_45, (ref) v_u_47, (copy) p_u_43, (copy) v_u_46, (copy) p_u_44
		local v48 = v_u_9.unscaledSize(v_u_45).X
		local v49 = math.floor(v48)
		if v49 > 0 and v49 ~= v_u_47 then
			v_u_47 = v49
			local v50 = (v49 + 14) / (p_u_43 + 14)
			local v51 = math.floor(v50)
			local v52 = math.clamp(v51, 1, 4)
			local v53 = (v49 - (v52 - 1) * 14) / v52
			local v54 = math.floor(v53)
			v_u_46.CellSize = UDim2.fromOffset(v54, p_u_44(v54))
		end
	end
	v_u_45:GetPropertyChangedSignal("AbsoluteSize"):Connect(v55)
	task.defer(v55)
	return v_u_45
end
local function v_u_64(p57, p58) -- name: vehiclePicture
	-- upvalues: (copy) v_u_15, (copy) v_u_9
	local v59, v60 = v_u_15.of(p57)
	if not v59 then
		return nil
	end
	local v61 = v_u_9.new("ImageLabel", {
		["Name"] = "Vehicle",
		["BackgroundTransparency"] = 1,
		["Image"] = nil,
		["ScaleType"] = nil,
		["Image"] = v59,
		["ScaleType"] = Enum.ScaleType.Fit
	})
	for v62, v63 in p58 do
		v61[v62] = v63
	end
	v61:SetAttribute("Aspect", v60)
	return v61
end
local function v_u_72(p65, p66, p67, p68, p69, p70) -- name: banner
	-- upvalues: (copy) v_u_9, (copy) v_u_19, (copy) v_u_28, (copy) v_u_18
	local v71 = v_u_9.new("Frame", {
		["Name"] = "Banner",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["ClipsDescendants"] = true,
		["LayoutOrder"] = 0,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_19,
		["Size"] = UDim2.new(1, 0, 0, v_u_28),
		["Parent"] = p65
	})
	v_u_9.corner(v71, 10)
	v_u_9.new("UIGradient", {
		["Rotation"] = 20,
		["Color"] = nil,
		["Parent"] = nil,
		["Color"] = ColorSequence.new(p66[1], p66[2]),
		["Parent"] = v71
	})
	v_u_9.text({
		["Name"] = "Word",
		["Text"] = nil,
		["FontFace"] = nil,
		["TextScaled"] = true,
		["TextColor3"] = nil,
		["TextTransparency"] = 0.91,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Text"] = string.upper(p67),
		["FontFace"] = v_u_9.FONT_DISPLAY,
		["TextColor3"] = v_u_19,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.78),
		["Size"] = UDim2.fromScale(1.25, 1.35),
		["Parent"] = v71
	}).ZIndex = 1
	if p70 then
		p70(v71)
	end
	v_u_9.text({
		["Name"] = "Title",
		["Text"] = nil,
		["FontFace"] = nil,
		["TextSize"] = nil,
		["TextColor3"] = nil,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 3,
		["Parent"] = nil,
		["Text"] = string.upper(p68),
		["FontFace"] = v_u_9.FONT_DISPLAY,
		["TextSize"] = v_u_18 and 22 or 28,
		["TextColor3"] = v_u_19,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.new(0.5, 0, 0.5, v_u_18 and -14 or -17),
		["Size"] = UDim2.new(0.56, 0, 0, 32),
		["Parent"] = v71
	})
	v_u_9.text({
		["Name"] = "Line",
		["Text"] = nil,
		["TextSize"] = nil,
		["TextColor3"] = nil,
		["TextTransparency"] = 0.12,
		["TextWrapped"] = true,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 3,
		["Parent"] = nil,
		["Text"] = p69,
		["TextSize"] = v_u_18 and 12 or 14,
		["TextColor3"] = v_u_19,
		["AnchorPoint"] = Vector2.new(0.5, 0),
		["Position"] = UDim2.new(0.5, 0, 0.5, v_u_18 and 2 or 4),
		["Size"] = UDim2.new(0.5, 0, 0, 36),
		["Parent"] = v71
	})
	return v71
end
local function v_u_75(p73) -- name: clear
	for _, v74 in p73:GetChildren() do
		if not v74:IsA("GuiObject") then
			continue
		end
		v74:Destroy()
	end
end
local function v_u_82(p76, p77, p78, p79) -- name: sectionTitle
	-- upvalues: (copy) v_u_9
	local v80 = v_u_9.new("Frame", {
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["LayoutOrder"] = nil,
		["Parent"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 28),
		["LayoutOrder"] = p79,
		["Parent"] = p76
	})
	local v81 = v_u_9.new("Frame", {
		["BackgroundColor3"] = v_u_9.ACCENT,
		["Size"] = UDim2.fromOffset(26, 26),
		["Position"] = UDim2.fromOffset(0, 1),
		["Parent"] = v80
	})
	v_u_9.corner(v81, 6)
	v_u_9.text({
		["Text"] = nil,
		["TextSize"] = 14,
		["FontFace"] = nil,
		["TextColor3"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Text"] = tostring(p77),
		["FontFace"] = v_u_9.FONT_HEAVY,
		["TextColor3"] = v_u_9.inkOn(v_u_9.ACCENT),
		["Size"] = UDim2.fromScale(1, 1),
		["Parent"] = v81
	})
	v_u_9.text({
		["Text"] = nil,
		["TextSize"] = 16,
		["FontFace"] = nil,
		["TextXAlignment"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Text"] = string.upper(p78),
		["FontFace"] = v_u_9.FONT_TITLE,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["Position"] = UDim2.fromOffset(38, 0),
		["Size"] = UDim2.new(1, -38, 1, 0),
		["Parent"] = v80
	})
	return v80
end
local function v_u_90(p83, p84, p85, p86) -- name: colourCard
	-- upvalues: (copy) v_u_9, (copy) v_u_19
	local v87 = {
		["Name"] = nil,
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["LayoutOrder"] = nil,
		["ClipsDescendants"] = true,
		["Parent"] = nil,
		["Name"] = p86 or "Card",
		["BackgroundColor3"] = v_u_19,
		["LayoutOrder"] = p85 or 0,
		["Parent"] = p83
	}
	local v88 = v_u_9.new("Frame", v87)
	v_u_9.corner(v88, 10)
	v_u_9.new("UIGradient", {
		["Rotation"] = 125,
		["Color"] = nil,
		["Parent"] = nil,
		["Color"] = ColorSequence.new(p84[1], p84[2]),
		["Parent"] = v88
	})
	local v89 = v_u_9.new("Frame", {
		["Name"] = "Foot",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = Color3.new(0, 0, 0),
		["AnchorPoint"] = Vector2.new(0, 1),
		["Position"] = UDim2.fromScale(0, 1),
		["Size"] = UDim2.fromScale(1, 0.45),
		["Parent"] = v88
	})
	v_u_9.new("UIGradient", {
		["Rotation"] = 90,
		["Transparency"] = nil,
		["Parent"] = nil,
		["Transparency"] = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(1, 0.55) }),
		["Parent"] = v89
	})
	return v88
end
local v91 = v_u_9.new("Frame", {
	["Name"] = "Passes",
	["BackgroundTransparency"] = 1,
	["Size"] = nil,
	["Visible"] = false,
	["Parent"] = nil,
	["Size"] = UDim2.fromScale(1, 1),
	["Parent"] = v35
})
local v_u_92 = v40(v91)
local function v_u_148(p93, p_u_94) -- name: passButton
	-- upvalues: (copy) v_u_9, (copy) v_u_7, (copy) v_u_16, (copy) v_u_36, (copy) v_u_19, (copy) v_u_37, (copy) v_u_2, (copy) v_u_12, (copy) v_u_17, (copy) v_u_1
	local v_u_95 = v_u_9.button({
		["name"] = "Buy",
		["text"] = "\226\128\166",
		["grad"] = "dark",
		["textSize"] = 16,
		["anchor"] = nil,
		["position"] = nil,
		["size"] = nil,
		["zindex"] = 4,
		["parent"] = nil,
		["anchor"] = Vector2.new(0, 1),
		["position"] = UDim2.new(0, 16, 1, -14),
		["size"] = UDim2.new(0.5, -16, 0, 38),
		["parent"] = p93
	})
	local function v137() -- name: paint
		-- upvalues: (copy) p_u_94, (ref) v_u_7, (ref) v_u_16, (ref) v_u_36, (ref) v_u_9, (copy) v_u_95, (ref) v_u_19, (ref) v_u_37, (ref) v_u_2
		local v96 = p_u_94.key
		if v_u_7.hasPass(v_u_16, v96) or v_u_36.owned[v96] == true then
			v_u_9.setButton(v_u_95, "dark", "Owned", v_u_9.LIME)
		else
			local v97 = p_u_94.product
			if type(v97) == "number" then
				v_u_9.setButton(v_u_95, "dark", "\226\128\166", v_u_19)
				local v_u_98 = p_u_94.product
				local function v_u_101(p99)
					-- upvalues: (ref) v_u_95, (ref) p_u_94, (ref) v_u_7, (ref) v_u_16, (ref) v_u_36, (ref) v_u_9, (ref) v_u_19
					if v_u_95.Parent then
						local v100 = p_u_94.key
						if not v_u_7.hasPass(v_u_16, v100) and v_u_36.owned[v100] ~= true then
							v_u_9.setButton(v_u_95, "gold", not p99 and "Buy" or "\238\128\130 " .. v_u_7.formatNumber(p99), v_u_19)
						end
					end
				end
				local v_u_102 = "product" .. ":" .. tostring(v_u_98)
				if v_u_37[v_u_102] == nil then
					local v_u_103 = "product"
					task.spawn(function()
						-- upvalues: (ref) v_u_2, (copy) v_u_98, (copy) v_u_103, (ref) v_u_37, (copy) v_u_102, (copy) v_u_101
						local v104 = v_u_2.GetProductInfo
						local v105 = v_u_2
						local v106 = v_u_98
						local v107
						if v_u_103 == "pass" then
							v107 = Enum.InfoType.GamePass
						else
							v107 = Enum.InfoType.Product
						end
						local v108, v109 = pcall(v104, v105, v106, v107)
						local v110 = v_u_37
						local v111 = v_u_102
						local v112
						if v108 and (v109 and v109.PriceInRobux) then
							v112 = v109.PriceInRobux
						else
							v112 = false
						end
						v110[v111] = v112
						local v113 = v_u_101
						local v114 = v_u_37[v_u_102]
						if not v108 then
							v109 = nil
						end
						v113(v114, v109)
					end)
					return
				end
				local v115 = v_u_37[v_u_102]
				if v_u_95.Parent then
					local v116 = p_u_94.key
					if not v_u_7.hasPass(v_u_16, v116) and v_u_36.owned[v116] ~= true then
						v_u_9.setButton(v_u_95, "gold", not v115 and "Buy" or "\238\128\130 " .. v_u_7.formatNumber(v115), v_u_19)
						return
					end
				end
			else
				local v117 = p_u_94.id
				if type(v117) ~= "number" then
					v_u_9.setButton(v_u_95, "dark", "Coming soon", v_u_9.TEXT_DIM)
					return
				end
				v_u_9.setButton(v_u_95, "dark", "\226\128\166", v_u_19)
				local v_u_118 = p_u_94.id
				local function v_u_121(p119)
					-- upvalues: (ref) v_u_95, (ref) p_u_94, (ref) v_u_7, (ref) v_u_16, (ref) v_u_36, (ref) v_u_9, (ref) v_u_19
					if v_u_95.Parent then
						local v120 = p_u_94.key
						if not v_u_7.hasPass(v_u_16, v120) and v_u_36.owned[v120] ~= true then
							v_u_9.setButton(v_u_95, "gold", not p119 and "Buy" or "\238\128\130 " .. v_u_7.formatNumber(p119), v_u_19)
						end
					end
				end
				local v_u_122 = "pass" .. ":" .. tostring(v_u_118)
				if v_u_37[v_u_122] == nil then
					local v_u_123 = "pass"
					task.spawn(function()
						-- upvalues: (ref) v_u_2, (copy) v_u_118, (copy) v_u_123, (ref) v_u_37, (copy) v_u_122, (copy) v_u_121
						local v124 = v_u_2.GetProductInfo
						local v125 = v_u_2
						local v126 = v_u_118
						local v127
						if v_u_123 == "pass" then
							v127 = Enum.InfoType.GamePass
						else
							v127 = Enum.InfoType.Product
						end
						local v128, v129 = pcall(v124, v125, v126, v127)
						local v130 = v_u_37
						local v131 = v_u_122
						local v132
						if v128 and (v129 and v129.PriceInRobux) then
							v132 = v129.PriceInRobux
						else
							v132 = false
						end
						v130[v131] = v132
						local v133 = v_u_121
						local v134 = v_u_37[v_u_122]
						if not v128 then
							v129 = nil
						end
						v133(v134, v129)
					end)
				else
					local v135 = v_u_37[v_u_122]
					if v_u_95.Parent then
						local v136 = p_u_94.key
						if not v_u_7.hasPass(v_u_16, v136) and v_u_36.owned[v136] ~= true then
							v_u_9.setButton(v_u_95, "gold", not v135 and "Buy" or "\238\128\130 " .. v_u_7.formatNumber(v135), v_u_19)
							return
						end
					end
				end
			end
		end
	end
	v137()
	v_u_95.Activated:Connect(function()
		-- upvalues: (copy) p_u_94, (ref) v_u_7, (ref) v_u_16, (ref) v_u_36, (ref) v_u_12, (ref) v_u_17, (ref) v_u_1, (ref) v_u_2
		local v138 = p_u_94.key
		if v_u_7.hasPass(v_u_16, v138) or v_u_36.owned[v138] == true then
			v_u_12.show("You already have " .. p_u_94.name, "info")
			return
		else
			local v139 = p_u_94.product
			if type(v139) == "number" then
				local v140 = v_u_17:FindFirstChild("Store")
				local v141 = v_u_1.invoke
				local v142 = p_u_94.key
				local v143, v144, v145, v146 = pcall(v141, v140, "BuyStart", v142)
				if v143 and (v144 and v146) then
					v_u_2:PromptProductPurchase(v_u_16, v146)
				else
					v_u_12.show(v143 and v145 and v145 or "Couldn\'t start the purchase", "error")
				end
			else
				local v147 = p_u_94.id
				if type(v147) == "number" then
					v_u_2:PromptGamePassPurchase(v_u_16, p_u_94.id)
				else
					v_u_12.show(p_u_94.name .. ": Coming soon", "info")
				end
			end
		end
	end)
	return v_u_95, v137
end
local function v_u_160(p149, p150) -- name: passPicture
	-- upvalues: (copy) v_u_21, (copy) v_u_64, (copy) v_u_11, (copy) v_u_18, (copy) v_u_9, (copy) v_u_19, (copy) v_u_10
	local v151 = v_u_21[p150.key]
	if v151 and #v151 > 0 then
		local v152 = #v151 >= 2 and v_u_64(v151[2], {
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = 2,
			["AnchorPoint"] = Vector2.new(1, 1),
			["Position"] = UDim2.new(1, -4, 1, -34),
			["Size"] = UDim2.fromScale(0.42, 0.4)
		})
		if v152 then
			v152.Parent = p149
		end
		local v153 = v_u_64(v151[1], {
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = 3,
			["AnchorPoint"] = Vector2.new(1, 1),
			["Position"] = UDim2.new(1, #v151 >= 2 and -56 or -8, 1, -6),
			["Size"] = UDim2.fromScale(0.52, 0.5)
		})
		if v153 then
			v153.Parent = p149
			return
		end
	end
	if p150.icon == "coin" then
		local v154 = v_u_11.pile(5, Vector2.new(170, 120))
		v154.AnchorPoint = Vector2.new(1, 1)
		v154.Position = UDim2.new(1, -10, 1, -14)
		v154.ZIndex = 2
		v154.Parent = p149
	else
		local v155 = v_u_18 and 76 or 92
		for v156, v157 in {
			{ 1.9, 0.93 },
			{ 1.4, 0.88 }
		} do
			local v158 = v_u_9.new("Frame", {
				["Name"] = nil,
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = nil,
				["BorderSizePixel"] = 0,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["ZIndex"] = 2,
				["Parent"] = nil,
				["Name"] = "Disc" .. v156,
				["BackgroundColor3"] = v_u_19,
				["BackgroundTransparency"] = v157[2],
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.new(1, -22 - v155 / 2, 1, -26 - v155 / 2),
				["Size"] = UDim2.fromOffset(v155 * v157[1], v155 * v157[1]),
				["Parent"] = p149
			})
			v_u_9.corner(v158, 999)
		end
		local v159 = v_u_10.make(p150.icon or "gem", v_u_19, v155)
		v159.AnchorPoint = Vector2.new(1, 1)
		v159.Position = UDim2.new(1, -22, 1, -26)
		v159.Rotation = -10
		v159.ZIndex = 3
		v159.Parent = p149
	end
end
local v_u_161 = v_u_9.new("Frame", {
	["Name"] = "Gifts",
	["BackgroundTransparency"] = 1,
	["Size"] = nil,
	["Visible"] = false,
	["Parent"] = nil,
	["Size"] = UDim2.fromScale(1, 1),
	["Parent"] = v35
})
local v_u_162 = v40(v_u_161)
local v_u_163 = nil
local v_u_164 = {}
local function v_u_172(p165, p166) -- name: giftTile
	-- upvalues: (copy) v_u_20, (copy) v_u_9, (copy) v_u_19, (copy) v_u_21, (copy) v_u_64, (copy) v_u_11, (copy) v_u_10
	local v167 = v_u_20[p166.grad or "gold"] or v_u_20.gold
	local v168 = v_u_9.new("Frame", {
		["Name"] = "Tile",
		["BackgroundColor3"] = nil,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ClipsDescendants"] = true,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_19,
		["AnchorPoint"] = Vector2.new(0, 0.5),
		["Position"] = UDim2.fromScale(0, 0.5),
		["Size"] = UDim2.fromOffset(84, 56),
		["Parent"] = p165
	})
	v_u_9.corner(v168, 8)
	v_u_9.new("UIGradient", {
		["Rotation"] = 125,
		["Color"] = nil,
		["Parent"] = nil,
		["Color"] = ColorSequence.new(v167[1], v167[2]),
		["Parent"] = v168
	})
	local v169 = v_u_21[p166.key]
	if v169 then
		v169 = v_u_64(v169[1], {
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5, 0.55),
			["Size"] = UDim2.fromScale(0.95, 0.95)
		})
	end
	if v169 then
		v169.Parent = v168
		return
	elseif p166.icon == "coin" then
		local v170 = v_u_11.coin(30, {
			["glow"] = false,
			["sweep"] = false
		})
		v170.AnchorPoint = Vector2.new(0.5, 0.5)
		v170.Position = UDim2.fromScale(0.5, 0.5)
		v170.Parent = v168
	else
		local v171 = v_u_10.make(p166.icon or "gift", v_u_19, 30)
		v171.AnchorPoint = Vector2.new(0.5, 0.5)
		v171.Position = UDim2.fromScale(0.5, 0.5)
		v171.Parent = v168
	end
end
local function v_u_210(p173, p_u_174, p_u_175, p176) -- name: giftRow
	-- upvalues: (copy) v_u_9, (copy) v_u_19, (copy) v_u_172, (copy) v_u_18, (copy) v_u_7, (copy) v_u_37, (copy) v_u_2, (copy) v_u_12, (copy) v_u_17, (copy) v_u_1, (copy) v_u_16
	local v177 = v_u_9.new("Frame", {
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["LayoutOrder"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_9.CARD,
		["Size"] = UDim2.new(1, 0, 0, 76),
		["LayoutOrder"] = p176,
		["Parent"] = p173
	})
	v_u_9.corner(v177, 10)
	v_u_9.border(v177, v_u_19, 0.94, 1)
	v_u_9.padding(v177, 10)
	v_u_172(v177, p_u_174)
	v_u_9.text({
		["Text"] = nil,
		["TextSize"] = 16,
		["FontFace"] = nil,
		["TextXAlignment"] = nil,
		["TextTruncate"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Text"] = string.upper(p_u_174.name),
		["FontFace"] = v_u_9.FONT_TITLE,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["TextTruncate"] = Enum.TextTruncate.AtEnd,
		["Position"] = UDim2.fromOffset(98, 4),
		["Size"] = UDim2.new(1, -280, 0, 22),
		["Parent"] = v177
	})
	local v178 = v_u_9.text
	local v179 = {
		["Text"] = nil,
		["TextSize"] = 13,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["TextTruncate"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil
	}
	local v180
	if p_u_175 then
		v180 = "for " .. p_u_175.DisplayName
	else
		v180 = p_u_174.description or ""
	end
	v179.Text = v180
	v179.TextColor3 = v_u_9.TEXT_DIM
	v179.TextXAlignment = Enum.TextXAlignment.Left
	v179.TextTruncate = Enum.TextTruncate.AtEnd
	v179.Position = UDim2.fromOffset(98, 29)
	v179.Size = UDim2.new(1, -280, 0, 18)
	v179.Parent = v177
	v178(v179)
	local v_u_181 = v_u_9.button({
		["name"] = "Gift",
		["text"] = "\226\128\166",
		["icon"] = "gift",
		["grad"] = "gold",
		["textSize"] = 16,
		["anchor"] = nil,
		["position"] = nil,
		["size"] = nil,
		["parent"] = nil,
		["anchor"] = Vector2.new(1, 0.5),
		["position"] = UDim2.fromScale(1, 0.5),
		["size"] = UDim2.fromOffset(v_u_18 and 150 or 172, 42),
		["parent"] = v177
	})
	local v_u_182 = p_u_175 and not p_u_174.cash
	if v_u_182 then
		v_u_182 = v_u_7.hasPass(p_u_175, p_u_174.key)
	end
	if v_u_182 then
		v_u_9.setButton(v_u_181, "dark", "Has it", v_u_9.TEXT_DIM)
	else
		local v183 = p_u_174.gift
		if type(v183) == "number" then
			if p_u_175 then
				local v_u_184 = p_u_174.gift
				local function v_u_186(p185)
					-- upvalues: (copy) v_u_181, (ref) v_u_9, (ref) v_u_7, (ref) v_u_19
					if v_u_181.Parent then
						v_u_9.setButton(v_u_181, "gold", not p185 and "Gift" or "\238\128\130 " .. v_u_7.formatNumber(p185), v_u_19)
					end
				end
				local v_u_187 = "product" .. ":" .. tostring(v_u_184)
				if v_u_37[v_u_187] == nil then
					local v_u_188 = "product"
					task.spawn(function()
						-- upvalues: (ref) v_u_2, (copy) v_u_184, (copy) v_u_188, (ref) v_u_37, (copy) v_u_187, (copy) v_u_186
						local v189 = v_u_2.GetProductInfo
						local v190 = v_u_2
						local v191 = v_u_184
						local v192
						if v_u_188 == "pass" then
							v192 = Enum.InfoType.GamePass
						else
							v192 = Enum.InfoType.Product
						end
						local v193, v194 = pcall(v189, v190, v191, v192)
						local v195 = v_u_37
						local v196 = v_u_187
						local v197
						if v193 and (v194 and v194.PriceInRobux) then
							v197 = v194.PriceInRobux
						else
							v197 = false
						end
						v195[v196] = v197
						local v198 = v_u_186
						local v199 = v_u_37[v_u_187]
						if not v193 then
							v194 = nil
						end
						v198(v199, v194)
					end)
				else
					local v200 = v_u_37[v_u_187]
					if v_u_181.Parent then
						v_u_9.setButton(v_u_181, "gold", not v200 and "Gift" or "\238\128\130 " .. v_u_7.formatNumber(v200), v_u_19)
					end
				end
			else
				v_u_9.setButton(v_u_181, "grey", "Pick a player", v_u_9.TEXT_DIM)
			end
		else
			v_u_9.setButton(v_u_181, "grey", "Coming soon", v_u_9.TEXT_DIM)
		end
	end
	v_u_181.Activated:Connect(function()
		-- upvalues: (copy) v_u_182, (copy) p_u_175, (copy) p_u_174, (ref) v_u_12, (ref) v_u_17, (ref) v_u_1, (ref) v_u_2, (ref) v_u_16
		if v_u_182 or not p_u_175 then
			return
		else
			local v201 = p_u_174.gift
			if type(v201) == "number" then
				local v202 = v_u_17:FindFirstChild("Store")
				if v202 then
					local v203 = v_u_1.invoke
					local v204 = p_u_175.UserId
					local v205 = p_u_174.key
					local v206, v207, v208, v209 = pcall(v203, v202, "GiftStart", v204, v205)
					if v206 and (v207 and v209) then
						v_u_2:PromptProductPurchase(v_u_16, v209)
					else
						v_u_12.show(v206 and v208 and v208 or "Couldn\'t start the gift", "error")
					end
				else
					return
				end
			else
				v_u_12.show("Gifting " .. p_u_174.name .. ": Coming soon", "info")
				return
			end
		end
	end)
end
local function v_u_252() -- name: buildGifts
	-- upvalues: (copy) v_u_75, (copy) v_u_162, (copy) v_u_72, (copy) v_u_64, (copy) v_u_82, (copy) v_u_3, (copy) v_u_16, (ref) v_u_163, (copy) v_u_9, (copy) v_u_19, (copy) v_u_5, (copy) v_u_164, (ref) v_u_252, (copy) v_u_14, (copy) v_u_210, (copy) v_u_7, (copy) v_u_22
	v_u_75(v_u_162)
	local v_u_211 = "STYLO160G"
	local v_u_212 = "GIORNO22"
	v_u_72(v_u_162, { Color3.fromRGB(240, 84, 172), Color3.fromRGB(104, 14, 120) }, "GIFTS", "Send a gift", "Pick someone in this server, then a pass or a cash pack for them.", function(p213)
		-- upvalues: (ref) v_u_64, (copy) v_u_211, (copy) v_u_212
		local v214 = v_u_64(v_u_211, {
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = 2,
			["AnchorPoint"] = Vector2.new(0, 1),
			["Position"] = UDim2.new(0.02, 0, 1, 2),
			["Size"] = UDim2.fromScale(0.25, 0.92)
		})
		if v214 then
			v214.Parent = p213
		end
		local v215 = v_u_64(v_u_212, {
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = 2,
			["AnchorPoint"] = Vector2.new(1, 1),
			["Position"] = UDim2.new(0.98, 0, 1, 2),
			["Size"] = UDim2.fromScale(0.25, 0.92)
		})
		if v215 then
			v215.Parent = p213
		end
	end)
	v_u_82(v_u_162, 1, "Choose a player", 1)
	local v216 = {}
	for _, v217 in v_u_3:GetPlayers() do
		if v217 == v_u_16 then
			continue
		end
		table.insert(v216, v217)
	end
	table.sort(v216, function(p218, p219)
		return p218.DisplayName:lower() < p219.DisplayName:lower()
	end)
	if v_u_163 and not v_u_3:GetPlayerByUserId(v_u_163) then
		v_u_163 = nil
	end
	if #v216 == 0 then
		local v220 = v_u_9.new("Frame", {
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["LayoutOrder"] = 2,
			["Parent"] = nil,
			["BackgroundColor3"] = v_u_9.CARD,
			["Size"] = UDim2.new(1, 0, 0, 150),
			["Parent"] = v_u_162
		})
		v_u_9.corner(v220, 10)
		v_u_9.border(v220, v_u_19, 0.94, 1)
		local v221 = v_u_9.badge(v220, "gift", "gold", 52)
		v221.AnchorPoint = Vector2.new(0.5, 0)
		v221.Position = UDim2.new(0.5, 0, 0, 16)
		v_u_9.text({
			["Text"] = "Nobody else is here yet",
			["TextSize"] = 17,
			["FontFace"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["FontFace"] = v_u_9.FONT_TITLE,
			["Position"] = UDim2.fromOffset(0, 76),
			["Size"] = UDim2.new(1, 0, 0, 22),
			["Parent"] = v220
		})
		v_u_9.button({
			["text"] = "Invite friends",
			["icon"] = "people",
			["grad"] = "gold",
			["textSize"] = 15,
			["anchor"] = nil,
			["position"] = nil,
			["size"] = nil,
			["parent"] = nil,
			["anchor"] = Vector2.new(0.5, 0),
			["position"] = UDim2.new(0.5, 0, 0, 104),
			["size"] = UDim2.fromOffset(200, 34),
			["parent"] = v220
		}).Activated:Connect(function()
			-- upvalues: (ref) v_u_5, (ref) v_u_16
			local v222 = v_u_5.PromptGameInvite
			local v223 = v_u_5
			local v224 = v_u_16
			pcall(v222, v223, v224)
		end)
	else
		local v225 = v_u_9.new("ScrollingFrame", {
			["BackgroundTransparency"] = 1,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["CanvasSize"] = nil,
			["AutomaticCanvasSize"] = nil,
			["ScrollingDirection"] = nil,
			["ScrollBarThickness"] = 3,
			["LayoutOrder"] = 2,
			["Parent"] = nil,
			["Size"] = UDim2.new(1, 0, 0, 120),
			["CanvasSize"] = UDim2.new(),
			["AutomaticCanvasSize"] = Enum.AutomaticSize.X,
			["ScrollingDirection"] = Enum.ScrollingDirection.X,
			["Parent"] = v_u_162
		})
		v_u_9.new("UIListLayout", {
			["FillDirection"] = Enum.FillDirection.Horizontal,
			["Padding"] = UDim.new(0, 10),
			["SortOrder"] = Enum.SortOrder.LayoutOrder,
			["Parent"] = v225
		})
		v_u_9.new("UIPadding", {
			["PaddingLeft"] = UDim.new(0, 2),
			["PaddingTop"] = UDim.new(0, 2),
			["Parent"] = v225
		})
		for v226, v_u_227 in v216 do
			local v228 = v_u_227.UserId == v_u_163
			local v229 = v_u_9.new
			local v230 = "TextButton"
			local v231 = {
				["Text"] = "",
				["AutoButtonColor"] = false,
				["BackgroundColor3"] = nil,
				["Size"] = nil,
				["LayoutOrder"] = nil,
				["Parent"] = nil
			}
			local v232
			if v228 then
				v232 = Color3.fromRGB(54, 50, 18)
			else
				v232 = v_u_9.CARD
			end
			v231.BackgroundColor3 = v232
			v231.Size = UDim2.fromOffset(100, 108)
			v231.LayoutOrder = v226
			v231.Parent = v225
			local v233 = v229(v230, v231)
			v_u_9.corner(v233, 10)
			local v234 = v_u_9.border
			local v235
			if v228 then
				v235 = v_u_9.ACCENT_LIGHT
			else
				v235 = v_u_19
			end
			v234(v233, v235, v228 and 0 or 0.92, v228 and 2 or 1)
			local v_u_236 = v_u_9.new("ImageLabel", {
				["BackgroundColor3"] = v_u_9.CARD_DARK,
				["Size"] = UDim2.fromOffset(60, 60),
				["AnchorPoint"] = Vector2.new(0.5, 0),
				["Position"] = UDim2.new(0.5, 0, 0, 10),
				["Parent"] = v233
			})
			v_u_9.corner(v_u_236, 30)
			local v_u_237 = v_u_227.UserId
			local function v_u_239(p238)
				-- upvalues: (copy) v_u_236
				v_u_236.Image = p238
			end
			if v_u_164[v_u_237] then
				v_u_236.Image = v_u_164[v_u_237]
			else
				task.spawn(function()
					-- upvalues: (ref) v_u_3, (copy) v_u_237, (ref) v_u_164, (copy) v_u_239
					local v240 = v_u_3.GetUserThumbnailAsync
					local v241 = v_u_3
					local v242 = v_u_237
					local v243 = Enum.ThumbnailType.HeadShot
					local v244 = Enum.ThumbnailSize.Size150x150
					local v245, v246 = pcall(v240, v241, v242, v243, v244)
					if v245 then
						v_u_164[v_u_237] = v246
						v_u_239(v246)
					end
				end)
			end
			v_u_9.text({
				["Text"] = nil,
				["TextSize"] = 13,
				["FontFace"] = nil,
				["TextTruncate"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["Text"] = v_u_227.DisplayName,
				["FontFace"] = v_u_9.FONT_BOLD,
				["TextTruncate"] = Enum.TextTruncate.AtEnd,
				["Position"] = UDim2.fromOffset(4, 78),
				["Size"] = UDim2.new(1, -8, 0, 18),
				["Parent"] = v233
			})
			v233.Activated:Connect(function()
				-- upvalues: (ref) v_u_163, (copy) v_u_227, (ref) v_u_252
				v_u_163 = v_u_227.UserId
				v_u_252()
			end)
		end
	end
	v_u_82(v_u_162, 2, "Choose a gift", 3)
	local v247 = v_u_163
	if v247 then
		v247 = v_u_3:GetPlayerByUserId(v_u_163)
	end
	for v248, v249 in v_u_14.GAMEPASSES do
		v_u_210(v_u_162, v249, v247, 3 + v248)
	end
	for v250, v251 in v_u_14.MONEY do
		v_u_210(v_u_162, {
			["key"] = nil,
			["name"] = nil,
			["icon"] = "coin",
			["grad"] = nil,
			["description"] = "In-game cash",
			["gift"] = nil,
			["cash"] = true,
			["key"] = "cash:" .. v250,
			["name"] = v_u_7.formatCash(v251.cash),
			["grad"] = v_u_22[v250] or "green",
			["gift"] = v251.id
		}, v247, #v_u_14.GAMEPASSES + 3 + v250)
	end
end
v_u_3.PlayerAdded:Connect(function()
	-- upvalues: (copy) v_u_161, (ref) v_u_252
	if v_u_161.Visible then
		v_u_252()
	end
end)
v_u_3.PlayerRemoving:Connect(function()
	-- upvalues: (copy) v_u_161, (ref) v_u_252
	if v_u_161.Visible then
		task.defer(v_u_252)
	end
end)
local v253 = v_u_9.new("Frame", {
	["Name"] = "Money",
	["BackgroundTransparency"] = 1,
	["Size"] = nil,
	["Visible"] = false,
	["Parent"] = nil,
	["Size"] = UDim2.fromScale(1, 1),
	["Parent"] = v35
})
local v_u_254 = v40(v253)
local v255 = v_u_9.new("Frame", {
	["Name"] = "Codes",
	["BackgroundTransparency"] = 1,
	["Size"] = nil,
	["Visible"] = false,
	["Parent"] = nil,
	["Size"] = UDim2.fromScale(1, 1),
	["Parent"] = v35
})
local v_u_256 = v40(v255)
local v_u_257 = nil
local v_u_258 = nil
local v_u_259 = nil
local function v_u_291() -- name: buildCodes
	-- upvalues: (copy) v_u_75, (copy) v_u_256, (copy) v_u_72, (copy) v_u_10, (copy) v_u_19, (copy) v_u_18, (copy) v_u_9, (ref) v_u_258, (ref) v_u_257, (copy) v_u_17, (copy) v_u_1, (copy) v_u_36, (copy) v_u_291, (ref) v_u_259
	v_u_75(v_u_256)
	v_u_72(v_u_256, { Color3.fromRGB(66, 142, 255), Color3.fromRGB(28, 26, 140) }, "CODES", "Redeem a code", "Codes come out in the community group and at events. Each one works once.", function(p260)
		-- upvalues: (ref) v_u_10, (ref) v_u_19, (ref) v_u_18
		for v261, v262 in { 0, 1 } do
			local v263 = v_u_10.make("ticket", v_u_19, v_u_18 and 56 or 76)
			v263.AnchorPoint = Vector2.new(v262, 0.5)
			v263.Position = UDim2.new(v262 == 0 and 0.06 or 0.94, 0, 0.5, 0)
			v263.Rotation = v261 == 1 and -14 or 12
			v263.ZIndex = 2
			v263.Parent = p260
		end
	end)
	local v264 = v_u_9.new("Frame", {
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = 1,
		["Parent"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y,
		["Parent"] = v_u_256
	})
	v_u_9.new("UIListLayout", {
		["Padding"] = UDim.new(0, 12),
		["HorizontalAlignment"] = Enum.HorizontalAlignment.Center,
		["SortOrder"] = Enum.SortOrder.LayoutOrder,
		["Parent"] = v264
	})
	local v265 = v_u_9.new("Frame", {
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["LayoutOrder"] = 1,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_9.CARD,
		["Size"] = UDim2.new(1, 0, 0, 132),
		["Parent"] = v264
	})
	v_u_9.new("UISizeConstraint", {
		["MaxSize"] = Vector2.new(640, (1 / 0)),
		["Parent"] = v265
	})
	v_u_9.corner(v265, 10)
	v_u_9.border(v265, v_u_19, 0.94, 1)
	v_u_9.padding(v265, 16)
	v_u_9.text({
		["Text"] = "ENTER YOUR CODE",
		["TextSize"] = 12,
		["FontFace"] = nil,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["FontFace"] = v_u_9.FONT_HEAVY,
		["TextColor3"] = v_u_9.ACCENT_LIGHT,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["Size"] = UDim2.new(1, 0, 0, 14),
		["Parent"] = v265
	})
	local v266 = v_u_9.new("Frame", {
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Position"] = UDim2.fromOffset(0, 24),
		["Size"] = UDim2.new(1, 0, 0, 50),
		["Parent"] = v265
	})
	local v267 = v_u_9.new("Frame", {
		["BackgroundColor3"] = v_u_9.CARD_DARK,
		["Size"] = UDim2.new(1, -164, 1, 0),
		["Parent"] = v266
	})
	v_u_9.corner(v267, 8)
	local v_u_268 = v_u_9.border(v267, v_u_19, 0.86, 1.5)
	v_u_258 = v_u_9.new("TextBox", {
		["BackgroundTransparency"] = 1,
		["Text"] = "",
		["PlaceholderText"] = "ENTER CODE",
		["PlaceholderColor3"] = nil,
		["ClearTextOnFocus"] = false,
		["FontFace"] = nil,
		["TextSize"] = 20,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["PlaceholderColor3"] = Color3.fromRGB(110, 114, 130),
		["FontFace"] = v_u_9.FONT_DISPLAY,
		["TextColor3"] = v_u_9.TEXT,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["Position"] = UDim2.fromOffset(16, 0),
		["Size"] = UDim2.new(1, -24, 1, 0),
		["Parent"] = v267
	})
	v_u_258.Focused:Connect(function()
		-- upvalues: (copy) v_u_268, (ref) v_u_9
		local v269 = v_u_268
		v_u_268.Color = v_u_9.ACCENT_LIGHT
		v269.Transparency = 0.1
	end)
	v_u_258.FocusLost:Connect(function()
		-- upvalues: (copy) v_u_268, (ref) v_u_19
		local v270 = v_u_268
		v_u_268.Color = v_u_19
		v270.Transparency = 0.86
	end)
	v_u_258:GetPropertyChangedSignal("Text"):Connect(function()
		-- upvalues: (ref) v_u_258
		local v271 = v_u_258.Text:upper()
		if v271 ~= v_u_258.Text then
			v_u_258.Text = v271
		end
	end)
	local v272 = v_u_9.button({
		["text"] = "Redeem",
		["icon"] = "check",
		["grad"] = "gold",
		["textSize"] = 17,
		["anchor"] = nil,
		["position"] = nil,
		["size"] = nil,
		["parent"] = nil,
		["anchor"] = Vector2.new(1, 0),
		["position"] = UDim2.fromScale(1, 0),
		["size"] = UDim2.new(0, 152, 1, 0),
		["parent"] = v266
	})
	v_u_257 = v_u_9.text({
		["Text"] = "",
		["TextSize"] = 14,
		["FontFace"] = nil,
		["TextXAlignment"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["FontFace"] = v_u_9.FONT_BOLD,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["Position"] = UDim2.fromOffset(0, 82),
		["Size"] = UDim2.new(1, 0, 0, 18),
		["Parent"] = v265
	})
	local v_u_273 = false
	local function v_u_284() -- name: redeem
		-- upvalues: (ref) v_u_273, (ref) v_u_258, (ref) v_u_257, (ref) v_u_9, (ref) v_u_17, (ref) v_u_1, (ref) v_u_36, (ref) v_u_291
		if v_u_273 then
			return
		else
			local v274 = v_u_258.Text
			if v274:gsub("%s", "") == "" then
				v_u_257.Text = "Type a code first"
				v_u_257.TextColor3 = Color3.fromRGB(255, 120, 110)
			else
				v_u_273 = true
				v_u_257.Text = "Checking\226\128\166"
				v_u_257.TextColor3 = v_u_9.TEXT_DIM
				local v275 = v_u_17:FindFirstChild("Store")
				local v276, v277, v278
				if v275 then
					local v279 = v_u_1.invoke
					v276, v277, v278 = pcall(v279, v275, "Redeem", v274)
				else
					v276 = false
					v278 = nil
					v277 = false
				end
				v_u_273 = false
				v_u_257.Text = v276 and v278 and v278 or "Couldn\'t reach the server"
				local v280 = v_u_257
				local v281
				if v276 and v277 then
					v281 = v_u_9.GREEN_TEXT
				else
					v281 = Color3.fromRGB(255, 120, 110)
				end
				v280.TextColor3 = v281
				if v276 and v277 then
					v_u_258.Text = ""
					local v282 = v_u_36.codes
					local v283 = v274:upper():gsub("%s", "")
					table.insert(v282, v283)
					v_u_291()
					v_u_257.Text = v278
					v_u_257.TextColor3 = v_u_9.GREEN_TEXT
				end
			end
		end
	end
	v272.Activated:Connect(v_u_284)
	v_u_258.FocusLost:Connect(function(p285)
		-- upvalues: (copy) v_u_284
		if p285 then
			v_u_284()
		end
	end)
	if #v_u_36.codes > 0 then
		local v286 = v_u_9.new("Frame", {
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["LayoutOrder"] = 2,
			["Parent"] = nil,
			["BackgroundColor3"] = v_u_9.CARD,
			["Size"] = UDim2.new(1, 0, 0, 0),
			["AutomaticSize"] = Enum.AutomaticSize.Y,
			["Parent"] = v264
		})
		v_u_9.new("UISizeConstraint", {
			["MaxSize"] = Vector2.new(640, (1 / 0)),
			["Parent"] = v286
		})
		v_u_9.corner(v286, 10)
		v_u_9.border(v286, v_u_19, 0.94, 1)
		v_u_9.padding(v286, 14)
		v_u_9.new("UIListLayout", {
			["Padding"] = UDim.new(0, 8),
			["SortOrder"] = Enum.SortOrder.LayoutOrder,
			["Parent"] = v286
		})
		v_u_9.text({
			["Text"] = "REDEEMED",
			["TextSize"] = 12,
			["FontFace"] = nil,
			["TextColor3"] = nil,
			["TextXAlignment"] = nil,
			["Size"] = nil,
			["LayoutOrder"] = 1,
			["Parent"] = nil,
			["FontFace"] = v_u_9.FONT_HEAVY,
			["TextColor3"] = v_u_9.TEXT_DIM,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["Size"] = UDim2.new(1, 0, 0, 14),
			["Parent"] = v286
		})
		v_u_259 = v_u_9.new("Frame", {
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["LayoutOrder"] = 2,
			["Parent"] = nil,
			["Size"] = UDim2.new(1, 0, 0, 0),
			["AutomaticSize"] = Enum.AutomaticSize.Y,
			["Parent"] = v286
		})
		v_u_9.new("UIGridLayout", {
			["CellSize"] = UDim2.fromOffset(150, 30),
			["CellPadding"] = UDim2.fromOffset(8, 8),
			["SortOrder"] = Enum.SortOrder.LayoutOrder,
			["Parent"] = v_u_259
		})
		for v287, v288 in v_u_36.codes do
			local v289 = v_u_9.new("Frame", {
				["BackgroundColor3"] = v_u_9.CARD_DARK,
				["LayoutOrder"] = v287,
				["Parent"] = v_u_259
			})
			v_u_9.corner(v289, 6)
			local v290 = v_u_10.make("check", v_u_9.LIME, 16)
			v290.Position = UDim2.fromOffset(8, 7)
			v290.Parent = v289
			v_u_9.text({
				["Text"] = nil,
				["TextSize"] = 13,
				["FontFace"] = nil,
				["TextXAlignment"] = nil,
				["TextTruncate"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["Text"] = v288,
				["FontFace"] = v_u_9.FONT_BOLD,
				["TextXAlignment"] = Enum.TextXAlignment.Left,
				["TextTruncate"] = Enum.TextTruncate.AtEnd,
				["Position"] = UDim2.fromOffset(30, 0),
				["Size"] = UDim2.new(1, -36, 1, 0),
				["Parent"] = v289
			})
		end
	end
end
local v_u_351 = {
	["Passes"] = { v91, function() -- name: buildPasses
			-- upvalues: (copy) v_u_75, (copy) v_u_92, (copy) v_u_72, (copy) v_u_64, (copy) v_u_56, (copy) v_u_29, (copy) v_u_25, (copy) v_u_14, (copy) v_u_90, (copy) v_u_20, (copy) v_u_160, (copy) v_u_9, (copy) v_u_18, (copy) v_u_10, (copy) v_u_19, (copy) v_u_36, (copy) v_u_7, (copy) v_u_16, (copy) v_u_148
			v_u_75(v_u_92)
			local v_u_292 = "LEAD25F"
			local v_u_293 = "GIORNO25D"
			v_u_72(v_u_92, { Color3.fromRGB(76, 186, 96), Color3.fromRGB(28, 110, 64) }, "PASSES", "Game passes", "Pass scooters, VIP and double pay. Every pass can be a gift too.", function(p294)
				-- upvalues: (ref) v_u_64, (copy) v_u_292, (copy) v_u_293
				local v295 = v_u_64(v_u_292, {
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["ZIndex"] = 2,
					["AnchorPoint"] = Vector2.new(0, 1),
					["Position"] = UDim2.new(0.02, 0, 1, 2),
					["Size"] = UDim2.fromScale(0.25, 0.92)
				})
				if v295 then
					v295.Parent = p294
				end
				local v296 = v_u_64(v_u_293, {
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["ZIndex"] = 2,
					["AnchorPoint"] = Vector2.new(1, 1),
					["Position"] = UDim2.new(0.98, 0, 1, 2),
					["Size"] = UDim2.fromScale(0.25, 0.92)
				})
				if v296 then
					v296.Parent = p294
				end
			end)
			local v297 = v_u_56(v_u_92, 1, v_u_29, function()
				-- upvalues: (ref) v_u_25
				return v_u_25
			end)
			for v298, v299 in v_u_14.GAMEPASSES do
				local v300 = v_u_90(v297, v_u_20[v299.grad or "gold"] or v_u_20.gold, v298, v299.key)
				v_u_160(v300, v299)
				v_u_9.text({
					["Name"] = "Title",
					["Text"] = nil,
					["TextSize"] = nil,
					["FontFace"] = nil,
					["TextXAlignment"] = nil,
					["TextTruncate"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["ZIndex"] = 4,
					["Parent"] = nil,
					["Text"] = string.upper(v299.name),
					["TextSize"] = v_u_18 and 15 or 17,
					["FontFace"] = v_u_9.FONT_TITLE,
					["TextXAlignment"] = Enum.TextXAlignment.Left,
					["TextTruncate"] = Enum.TextTruncate.AtEnd,
					["Position"] = UDim2.fromOffset(16, 14),
					["Size"] = UDim2.new(1, -96, 0, 22),
					["Parent"] = v300
				})
				v_u_9.text({
					["Name"] = "Line",
					["Text"] = nil,
					["TextSize"] = 13,
					["TextTransparency"] = 0.15,
					["TextXAlignment"] = nil,
					["TextTruncate"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["ZIndex"] = 4,
					["Parent"] = nil,
					["Text"] = v299.description or "",
					["TextXAlignment"] = Enum.TextXAlignment.Left,
					["TextTruncate"] = Enum.TextTruncate.AtEnd,
					["Position"] = UDim2.fromOffset(16, 37),
					["Size"] = UDim2.new(1, -32, 0, 18),
					["Parent"] = v300
				})
				local v301 = v_u_9.new("Frame", {
					["Name"] = "Perks",
					["BackgroundTransparency"] = 1,
					["Position"] = nil,
					["Size"] = nil,
					["ZIndex"] = 4,
					["Parent"] = nil,
					["Position"] = UDim2.fromOffset(16, 64),
					["Size"] = UDim2.new(0.54, -16, 0, 72),
					["Parent"] = v300
				})
				v_u_9.new("UIListLayout", {
					["Padding"] = UDim.new(0, 3),
					["SortOrder"] = Enum.SortOrder.LayoutOrder,
					["Parent"] = v301
				})
				for v302, v303 in v299.perks or {} do
					local v304 = v_u_9.new("Frame", {
						["BackgroundTransparency"] = 1,
						["Size"] = nil,
						["LayoutOrder"] = nil,
						["ZIndex"] = 4,
						["Parent"] = nil,
						["Size"] = UDim2.new(1, 0, 0, 20),
						["LayoutOrder"] = v302,
						["Parent"] = v301
					})
					local v305 = v_u_10.make("check", v_u_19, 13)
					v305.AnchorPoint = Vector2.new(0, 0.5)
					v305.Position = UDim2.fromScale(0, 0.5)
					v305.Parent = v304
					v_u_9.text({
						["Text"] = nil,
						["TextSize"] = 12,
						["FontFace"] = nil,
						["TextXAlignment"] = nil,
						["TextTruncate"] = nil,
						["Position"] = nil,
						["Size"] = nil,
						["ZIndex"] = 4,
						["Parent"] = nil,
						["Text"] = v303,
						["FontFace"] = v_u_9.FONT_BOLD,
						["TextXAlignment"] = Enum.TextXAlignment.Left,
						["TextTruncate"] = Enum.TextTruncate.AtEnd,
						["Position"] = UDim2.fromOffset(19, 0),
						["Size"] = UDim2.new(1, -19, 1, 0),
						["Parent"] = v304
					})
				end
				local v306 = v_u_9.new("Frame", {
					["Name"] = "Chips",
					["BackgroundTransparency"] = 1,
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["ZIndex"] = 4,
					["Parent"] = nil,
					["AnchorPoint"] = Vector2.new(1, 0),
					["Position"] = UDim2.new(1, -12, 0, 14),
					["Size"] = UDim2.fromOffset(80, 46),
					["Parent"] = v300
				})
				v_u_9.new("UIListLayout", {
					["Padding"] = UDim.new(0, 4),
					["HorizontalAlignment"] = Enum.HorizontalAlignment.Right,
					["SortOrder"] = Enum.SortOrder.LayoutOrder,
					["Parent"] = v306
				})
				if v_u_36.best and v_u_36.best.vehicle == v299.key then
					v_u_9.chip(v306, "BEST SELLER", v_u_9.LIME, {
						["LayoutOrder"] = 0
					})
				end
				local v307 = v299.key
				if v_u_7.hasPass(v_u_16, v307) or v_u_36.owned[v307] == true then
					v_u_9.chip(v306, "Owned", v_u_9.LIME, {
						["LayoutOrder"] = 1
					})
				end
				local v308 = v299.gift
				if type(v308) == "number" then
					v_u_9.chip(v306, "Giftable", v_u_19, {
						["LayoutOrder"] = 2
					})
				end
				v_u_148(v300, v299)
			end
		end },
	["Gifts"] = { v_u_161, v_u_252 },
	["Money"] = { v253, function() -- name: buildMoney
			-- upvalues: (copy) v_u_75, (copy) v_u_254, (copy) v_u_72, (copy) v_u_11, (copy) v_u_18, (copy) v_u_56, (copy) v_u_26, (copy) v_u_23, (copy) v_u_14, (copy) v_u_90, (copy) v_u_20, (copy) v_u_22, (copy) v_u_9, (copy) v_u_7, (copy) v_u_36, (copy) v_u_19, (copy) v_u_16, (copy) v_u_37, (copy) v_u_2, (copy) v_u_17, (copy) v_u_1, (copy) v_u_12
			v_u_75(v_u_254)
			v_u_72(v_u_254, { Color3.fromRGB(236, 176, 34), Color3.fromRGB(150, 84, 6) }, "CASH", "Cash packs", "In-game cash for vehicles, parts and tuning. Bigger packs give more.", function(p309)
				-- upvalues: (ref) v_u_11, (ref) v_u_18
				for v310, v311 in { 0, 1 } do
					local v312 = v_u_11.pile(v310 == 1 and 4 or 5, Vector2.new(v_u_18 and 120 or 170, v_u_18 and 90 or 120))
					v312.AnchorPoint = Vector2.new(v311, 1)
					v312.Position = UDim2.new(v311 == 0 and 0.03 or 0.97, 0, 1, -6)
					v312.ZIndex = 2
					v312.Parent = p309
				end
			end)
			local v313 = v_u_56(v_u_254, 1, v_u_26, function()
				-- upvalues: (ref) v_u_23
				return v_u_23
			end)
			for v_u_314, v_u_315 in v_u_14.MONEY do
				local v316 = v_u_90(v313, v_u_20[v_u_22[v_u_314] or "gold"], v_u_314, "Pack" .. v_u_314)
				local v317 = v_u_11.pile(v_u_315.tier or 1, Vector2.new(v_u_18 and 130 or 150, v_u_18 and 96 or 110))
				v317.AnchorPoint = Vector2.new(1, 1)
				v317.Position = UDim2.new(1, -6, 1, -50)
				v317.ZIndex = 2
				v317.Parent = v316
				v_u_9.text({
					["Text"] = nil,
					["TextSize"] = nil,
					["FontFace"] = nil,
					["TextXAlignment"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["ZIndex"] = 4,
					["Parent"] = nil,
					["Text"] = v_u_7.formatCash(v_u_315.cash),
					["TextSize"] = v_u_18 and 20 or 24,
					["FontFace"] = v_u_9.FONT_DISPLAY,
					["TextXAlignment"] = Enum.TextXAlignment.Left,
					["Position"] = UDim2.fromOffset(16, 14),
					["Size"] = UDim2.new(1, -32, 0, 28),
					["Parent"] = v316
				})
				v_u_9.text({
					["Text"] = "IN-GAME CASH",
					["TextSize"] = 11,
					["FontFace"] = nil,
					["TextTransparency"] = 0.2,
					["TextXAlignment"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["ZIndex"] = 4,
					["Parent"] = nil,
					["FontFace"] = v_u_9.FONT_HEAVY,
					["TextXAlignment"] = Enum.TextXAlignment.Left,
					["Position"] = UDim2.fromOffset(16, 42),
					["Size"] = UDim2.new(1, -32, 0, 14),
					["Parent"] = v316
				})
				local v318 = v_u_9.new("Frame", {
					["Name"] = "Ribbons",
					["BackgroundTransparency"] = 1,
					["Position"] = nil,
					["Size"] = nil,
					["ZIndex"] = 4,
					["Parent"] = nil,
					["Position"] = UDim2.fromOffset(16, 62),
					["Size"] = UDim2.new(1, -32, 0, 24),
					["Parent"] = v316
				})
				v_u_9.new("UIListLayout", {
					["FillDirection"] = Enum.FillDirection.Horizontal,
					["Padding"] = UDim.new(0, 6),
					["SortOrder"] = Enum.SortOrder.LayoutOrder,
					["Parent"] = v318
				})
				if v_u_36.best and v_u_36.best.money == v_u_315.id then
					v_u_9.chip(v318, "BEST SELLER", v_u_9.LIME, {
						["LayoutOrder"] = 0
					})
				end
				if v_u_315.tag and v_u_315.tag ~= "POPULAR" then
					local v319 = v_u_9.chip
					local v320 = v_u_315.tag
					local v321
					if v_u_315.tag == "BEST VALUE" then
						v321 = v_u_9.LIME
					else
						v321 = v_u_19
					end
					v319(v318, v320, v321, {
						["LayoutOrder"] = 1
					})
				end
				local v_u_322 = v_u_9.button({
					["text"] = "\226\128\166",
					["grad"] = "dark",
					["textSize"] = 16,
					["anchor"] = nil,
					["position"] = nil,
					["size"] = nil,
					["zindex"] = 4,
					["parent"] = nil,
					["anchor"] = Vector2.new(0, 1),
					["position"] = UDim2.new(0, 16, 1, -12),
					["size"] = UDim2.new(1, -32, 0, 38),
					["parent"] = v316
				})
				local v323 = v_u_315.id
				local v_u_324
				if type(v323) == "number" then
					v_u_324 = false
				else
					local v325 = v_u_315.pass
					if type(v325) == "number" then
						v_u_324 = v_u_16:GetAttribute("MoneyPass_" .. v_u_315.pass) == true
					else
						v_u_324 = false
					end
				end
				if v_u_324 then
					v_u_9.setButton(v_u_322, "dark", "Owned", v_u_9.LIME)
				else
					local v326 = v_u_315.id
					if type(v326) ~= "number" then
						local v327 = v_u_315.pass
						if type(v327) ~= "number" then
							v_u_9.setButton(v_u_322, "dark", "Coming soon", v_u_9.TEXT_DIM)
							goto l28
						end
					end
					local v328 = v_u_315.id
					local v_u_329 = type(v328) == "number" and "product" or "pass"
					local v_u_330 = v_u_315.id or v_u_315.pass
					local function v_u_332(p331)
						-- upvalues: (copy) v_u_322, (ref) v_u_9, (ref) v_u_7, (ref) v_u_19
						if v_u_322.Parent then
							v_u_9.setButton(v_u_322, "gold", not p331 and "Buy" or "\238\128\130 " .. v_u_7.formatNumber(p331), v_u_19)
						end
					end
					local v_u_333 = v_u_329 .. ":" .. tostring(v_u_330)
					if v_u_37[v_u_333] == nil then
						task.spawn(function()
							-- upvalues: (ref) v_u_2, (copy) v_u_330, (copy) v_u_329, (ref) v_u_37, (copy) v_u_333, (copy) v_u_332
							local v334 = v_u_2.GetProductInfo
							local v335 = v_u_2
							local v336 = v_u_330
							local v337
							if v_u_329 == "pass" then
								v337 = Enum.InfoType.GamePass
							else
								v337 = Enum.InfoType.Product
							end
							local v338, v339 = pcall(v334, v335, v336, v337)
							local v340 = v_u_37
							local v341 = v_u_333
							local v342
							if v338 and (v339 and v339.PriceInRobux) then
								v342 = v339.PriceInRobux
							else
								v342 = false
							end
							v340[v341] = v342
							local v343 = v_u_332
							local v344 = v_u_37[v_u_333]
							if not v338 then
								v339 = nil
							end
							v343(v344, v339)
						end)
					else
						local v345 = v_u_37[v_u_333]
						if v_u_322.Parent then
							v_u_9.setButton(v_u_322, "gold", not v345 and "Buy" or "\238\128\130 " .. v_u_7.formatNumber(v345), v_u_19)
						end
					end
				end
				::l28::
				v_u_322.Activated:Connect(function()
					-- upvalues: (copy) v_u_315, (ref) v_u_17, (ref) v_u_1, (copy) v_u_314, (ref) v_u_2, (ref) v_u_16, (copy) v_u_324, (ref) v_u_12
					local v346 = v_u_315.id
					if type(v346) == "number" then
						local v347 = v_u_17:FindFirstChild("Store")
						if v347 then
							local v348 = v_u_1.invoke
							local v349 = "cash:" .. v_u_314
							pcall(v348, v347, "BuyStart", v349)
						end
						v_u_2:PromptProductPurchase(v_u_16, v_u_315.id)
						return
					elseif v_u_324 then
						v_u_12.show("You already bought this pack", "info")
						return
					else
						local v350 = v_u_315.pass
						if type(v350) == "number" then
							v_u_2:PromptGamePassPurchase(v_u_16, v_u_315.pass)
						else
							v_u_12.show("Cash packs: Coming soon", "info")
						end
					end
				end)
			end
		end },
	["Codes"] = { v255, v_u_291 }
}
local v_u_352 = "Passes"
local v_u_353 = {}
local function v_u_358(p354) -- name: show
	-- upvalues: (ref) v_u_352, (copy) v_u_351, (ref) v_u_353, (copy) v_u_6
	v_u_352 = p354
	for v355, v356 in v_u_351 do
		v356[1].Visible = v355 == p354
	end
	if not v_u_353[p354] or p354 == "Gifts" then
		v_u_353[p354] = true
		v_u_351[p354][2]()
	end
	local v357 = v_u_351[p354][1]
	v357.Position = UDim2.fromOffset(16, 0)
	v_u_6:Create(v357, TweenInfo.new(0.22, Enum.EasingStyle.Quint, Enum.EasingDirection.Out), {
		["Position"] = UDim2.fromOffset(0, 0)
	}):Play()
end
local _, v_u_359 = v_u_9.tabs(v_u_34.body, v27, v_u_358, v24)
local v360 = v_u_34.body:FindFirstChild("PageTitle")
if v360 then
	v360.Visible = false
	v35.Position = UDim2.new()
	v35.Size = UDim2.fromScale(1, 1)
end
local function v_u_372() -- name: refreshInfo
	-- upvalues: (copy) v_u_17, (copy) v_u_1, (copy) v_u_36, (ref) v_u_353, (copy) v_u_34, (copy) v_u_358, (ref) v_u_352
	local v361 = v_u_17:FindFirstChild("Store")
	if v361 then
		local v362 = v_u_1.invoke
		local v363, v364 = pcall(v362, v361, "Info")
		if v363 and type(v364) == "table" then
			local v365 = v_u_36
			local v366 = v364.owned
			v365.owned = type(v366) == "table" and (v364.owned or {}) or {}
			local v367 = v_u_36
			local v368 = v364.codes
			v367.codes = type(v368) == "table" and (v364.codes or {}) or {}
			local v369 = v_u_36
			local v370 = v364.best
			local v371
			if type(v370) == "table" then
				v371 = v364.best or nil
			else
				v371 = nil
			end
			v369.best = v371
			v_u_353 = {}
			if v_u_34.isOpen() then
				v_u_358(v_u_352)
			end
		end
	end
end
local v_u_373 = v_u_352
local v_u_374 = v_u_353
for _, v375 in v_u_14.MONEY do
	local v376 = v375.pass
	if type(v376) ~= "number" then
		continue
	end
	v_u_16:GetAttributeChangedSignal("MoneyPass_" .. v375.pass):Connect(function()
		-- upvalues: (ref) v_u_374, (copy) v_u_34, (ref) v_u_373, (copy) v_u_358
		v_u_374.Money = nil
		if v_u_34.isOpen() and v_u_373 == "Money" then
			v_u_358(v_u_373)
		end
	end)
end
for _, v377 in v_u_14.GAMEPASSES do
	v_u_16:GetAttributeChangedSignal("Pass_" .. v377.key):Connect(function()
		-- upvalues: (ref) v_u_374, (copy) v_u_34, (ref) v_u_373, (copy) v_u_358
		local v378 = v_u_374
		v_u_374.Passes = nil
		v378.Gifts = nil
		if v_u_34.isOpen() and (v_u_373 == "Passes" or v_u_373 == "Gifts") then
			v_u_358(v_u_373)
		end
	end)
end
local function v_u_381(p379, p380) -- name: setOpen
	-- upvalues: (copy) v_u_351, (ref) v_u_373, (copy) v_u_34, (copy) v_u_359, (copy) v_u_358, (copy) v_u_372, (copy) v_u_13
	if p379 then
		if p380 and v_u_351[p380] then
			v_u_373 = p380
		end
		v_u_34.setOpen(true)
		v_u_359(v_u_373)
		v_u_358(v_u_373)
		task.spawn(v_u_372)
	else
		v_u_34.setOpen(false)
	end
	v_u_13.isOpen = v_u_34.isOpen()
end
v_u_34.changed.Event:Connect(function(p382)
	-- upvalues: (copy) v_u_13
	v_u_13.isOpen = p382
end)
v_u_13.changed.Event:Connect(function(p383, p384)
	-- upvalues: (copy) v_u_351, (ref) v_u_373, (copy) v_u_34, (copy) v_u_359, (copy) v_u_358, (copy) v_u_372, (copy) v_u_13, (copy) v_u_381
	if p383 == "open" then
		if p384 and v_u_351[p384] then
			v_u_373 = p384
		end
		v_u_34.setOpen(true)
		v_u_359(v_u_373)
		v_u_358(v_u_373)
		task.spawn(v_u_372)
		v_u_13.isOpen = v_u_34.isOpen()
		return
	elseif p383 == "close" then
		v_u_34.setOpen(false)
		v_u_13.isOpen = v_u_34.isOpen()
	else
		v_u_381(not v_u_34.isOpen())
	end
end)