-- Path: ReplicatedStorage/PCX160Shared
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_28 = {
	["TAG"] = "PCX160",
	["REMOTE_NAME"] = "PCX160Remote",
	["MAX_STEER"] = 0.6108652381980153,
	["MIN_STEER"] = 0.048869219055841226,
	["STEER_FADE_SPEED"] = 70,
	["STEER_HEAVY_FROM"] = 100,
	["STEER_HEAVY_POWER"] = 1.3,
	["STEER_RATE_SLOW"] = 14,
	["STEER_RATE_FAST"] = 3.5,
	["STEER_RATE_SLOW_SPEED"] = 60,
	["STEER_RATE_FAST_SPEED"] = 250,
	["MAX_LEAN"] = 0.6108652381980153,
	["LEAN_GRAVITY"] = 35,
	["THROTTLE_ACCEL"] = 30,
	["ACCEL_TAPER"] = 2.5,
	["DEFAULT_MAX_SPEED"] = 130,
	["BRAKE_DECEL"] = 62,
	["BRAKE_BOOST_FROM"] = 80,
	["BRAKE_BOOST_PER"] = 150,
	["BRAKE_BOOST_MAX"] = 2.2,
	["BRAKE_DECEL_MAX"] = 140,
	["REVERSE_SPEED"] = 9,
	["REVERSE_ACCEL"] = 8,
	["STOPPED_SPEED"] = 0.3,
	["DRIVE_FORCE_PER_MASS"] = 400,
	["KMH_PER_STUD"] = 1.008,
	["TUCK_SPEED_BONUS"] = 1.1,
	["RIDER_LEAN"] = 0.15707963267948966,
	["TUCK_HIP_OFFSET"] = Vector3.new(0, 0.48, 1),
	["TUCK_PITCH"] = -1.3962634015954636,
	["TUCK_FOOT_OFFSET"] = Vector3.new(0.3, 0.22, 3),
	["TUCK_KNEE_POLE_OFFSET"] = Vector3.new(0.35, -1.4, 2.1),
	["LOOK_AHEAD_OFFSET"] = Vector3.new(0, 0.95, -30),
	["WHEELIE_MAX"] = 0.4886921905584123,
	["WHEELIE_MIN_SPEED"] = 4,
	["WHEELIE_FULL_SPEED"] = 14,
	["WHEELIE_RISE_RATE"] = 0.7853981633974483,
	["WHEELIE_FALL_RATE"] = 1.2217304763960306,
	["MOUNT_DISTANCE"] = 14,
	["CRASH_MIN_SPEED"] = 55,
	["CRASH_SPEED_DROP"] = 30,
	["CRASH_SIDE_SPEED"] = 42,
	["CRASH_WINDOW"] = 0.15,
	["CRASH_RAGDOLL_TIME"] = 3.2,
	["CRASH_RESET_TIME"] = 4.5,
	["CRASH_FALL_RESPONSIVENESS"] = 7,
	["CRASH_LIE_ANGLE"] = 1.4660765716752369,
	["CRASH_BOUNCE_KEEP"] = 0.15,
	["DRIVE_RESPONSIVENESS"] = 25,
	["lyingRotation"] = function(p1, p2) -- name: lyingRotation
		-- upvalues: (copy) v_u_28
		return p1 * CFrame.Angles(0, 0, -p2 * v_u_28.CRASH_LIE_ANGLE)
	end,
	["SUSP_FRONT_TRAVEL"] = 0.24,
	["SUSP_REAR_TRAVEL"] = 0.17,
	["SUSP_EXTEND"] = 0.13,
	["SUSP_STIFFNESS"] = 230,
	["SUSP_DAMPING"] = 15,
	["DEFAULT_BIKE_SCALE"] = 1.1,
	["RIDER_SCALE"] = 1.1,
	["riderScale"] = function(p3) -- name: riderScale
		-- upvalues: (copy) v_u_28
		local v4 = p3:GetAttribute("RiderScale") or p3:GetAttribute("BikeScale")
		if typeof(v4) == "number" and v4 > 0 then
			return v4
		else
			return v_u_28.RIDER_SCALE
		end
	end,
	["LOWER_LEVELS"] = 4,
	["LOWER_STEP"] = 0.1,
	["lowerSteps"] = function(p5) -- name: lowerSteps
		-- upvalues: (copy) v_u_28
		local v6 = p5:GetAttribute("LowerMax")
		local v7 = p5:GetAttribute("LowerMaxFront") or v6
		local v8 = p5:GetAttribute("LowerMaxRear") or v6
		return (typeof(v7) ~= "number" and 0 or v7) / v_u_28.LOWER_LEVELS, (typeof(v8) ~= "number" and 0 or v8) / v_u_28.LOWER_LEVELS
	end,
	["compressionTravel"] = function(p9) -- name: compressionTravel
		-- upvalues: (copy) v_u_28
		local v10, v11 = v_u_28.lowerSteps(p9)
		local v12, v13 = v_u_28.lowerDrops(p9)
		local v14 = v_u_28.SUSP_FRONT_TRAVEL
		local v15 = v10 * v_u_28.LOWER_LEVELS
		if v12 > 0 then
			local v16 = v15 - v12
			v14 = math.clamp(v16, 0.03, v14)
		end
		local v17 = v_u_28.SUSP_REAR_TRAVEL
		local v18 = v11 * v_u_28.LOWER_LEVELS
		if v13 <= 0 then
			return v14, v17
		end
		local v19 = v18 - v13
		return v14, math.clamp(v19, 0.03, v17)
	end,
	["lowerDrops"] = function(p20) -- name: lowerDrops
		-- upvalues: (copy) v_u_28
		local v21, v22 = v_u_28.lowerSteps(p20)
		local v23 = p20:GetAttribute("LowerLevel") or 0
		return (p20:GetAttribute("LowerFront") or v23) * v21, (p20:GetAttribute("LowerRear") or v23) * v22
	end,
	["PAINT_GROUPS"] = {
		"Body",
		"Shock",
		"ShockBody",
		"Wheel",
		"Logo",
		"Accent",
		"TailLight",
		"Bolt",
		"Grip",
		"BarCap",
		"ExhaustLogo",
		"Swingarm",
		"Footrest",
		"Fan"
	},
	["paintAllowed"] = function(p24, p25) -- name: paintAllowed
		if p24:GetAttribute("NoPaint") ~= true then
			return true
		end
		local v26 = p24:GetAttribute("PaintAllow")
		if type(v26) ~= "string" then
			return false
		end
		for v27 in v26:gmatch("[^,%s]+") do
			if v27 ~= p25 then
				continue
			end
			return true
		end
		return false
	end,
	["STAND_TYPES"] = {
		["Side"] = true,
		["Center"] = true
	}
}
local v29 = {
	["Gloss"] = {
		["material"] = nil,
		["reflectance"] = 0.08,
		["material"] = Enum.Material.SmoothPlastic
	},
	["Matte"] = {
		["material"] = nil,
		["reflectance"] = 0,
		["material"] = Enum.Material.SmoothPlastic
	},
	["Chrome"] = {
		["material"] = nil,
		["reflectance"] = 0.55,
		["material"] = Enum.Material.SmoothPlastic
	}
}
v_u_28.PAINT_FINISHES = v29
v_u_28.FINISH_MAPS = {
	["Matte"] = {
		["roughness"] = "rbxassetid://5901439821",
		["metalness"] = "rbxassetid://4504689679"
	},
	["Chrome"] = {
		["roughness"] = "rbxassetid://4504689679",
		["metalness"] = "rbxassetid://6100607594"
	}
}
function v_u_28.setFinishLook(p30, p31) -- name: setFinishLook
	-- upvalues: (copy) v_u_28
	local v32 = p30:FindFirstChild("FinishLooks")
	if v32 then
		local v33 = not v_u_28.PAINT_FINISHES[p31] and "Gloss" or p31
		for _, v34 in v32:GetChildren() do
			if not v34:IsA("SurfaceAppearance") or v34:GetAttribute("FinishLook") ~= v33 then
				continue
			end
			for _, v35 in p30:GetChildren() do
				if not v35:IsA("SurfaceAppearance") then
					continue
				end
				v35.Parent = v32
			end
			v34.Parent = p30
			return
		end
	end
end
v_u_28.CARBON_PARTS = {
	{
		["key"] = "Panels",
		["th"] = "\224\184\158\224\184\165\224\184\178\224\184\170\224\184\149\224\184\180\224\184\129\224\184\148\224\184\179\224\184\130\224\185\137\224\184\178\224\184\135\224\184\132\224\184\177\224\184\153"
	},
	{
		["key"] = "Cowl",
		["th"] = "\224\184\171\224\184\153\224\185\137\224\184\178\224\184\129\224\184\178\224\184\129 / \224\184\132\224\184\163\224\184\173\224\184\154\224\185\132\224\184\159\224\184\171\224\184\153\224\185\137\224\184\178"
	},
	{
		["key"] = "FrontPanel",
		["th"] = "\224\185\129\224\184\156\224\184\135\224\184\129\224\184\165\224\184\178\224\184\135\224\184\171\224\184\153\224\185\137\224\184\178"
	},
	{
		["key"] = "Handle",
		["th"] = "\224\184\132\224\184\163\224\184\173\224\184\154\224\185\129\224\184\174\224\184\153\224\184\148\224\185\140 / \224\185\128\224\184\163\224\184\183\224\184\173\224\184\153\224\185\132\224\184\161\224\184\165\224\185\140"
	},
	{
		["key"] = "Inner",
		["th"] = "\224\184\154\224\184\177\224\184\135\224\184\165\224\184\161\224\185\131\224\184\153 / \224\184\132\224\184\173\224\184\153\224\185\130\224\184\139\224\184\165"
	},
	{
		["key"] = "Floor",
		["th"] = "\224\184\158\224\184\183\224\185\137\224\184\153\224\184\167\224\184\178\224\184\135\224\185\128\224\184\151\224\185\137\224\184\178"
	},
	{
		["key"] = "Side",
		["th"] = "\224\184\157\224\184\178\224\184\130\224\185\137\224\184\178\224\184\135 / \224\185\131\224\184\149\224\185\137\224\185\128\224\184\154\224\184\178\224\184\176"
	},
	{
		["key"] = "Under",
		["th"] = "\224\185\131\224\184\149\224\185\137\224\184\151\224\185\137\224\184\173\224\184\135"
	},
	{
		["key"] = "Fender",
		["th"] = "\224\184\154\224\184\177\224\184\135\224\185\130\224\184\132\224\184\165\224\184\153\224\184\171\224\184\153\224\185\137\224\184\178"
	},
	{
		["key"] = "Hugger",
		["th"] = "\224\184\154\224\184\177\224\184\135\224\185\130\224\184\132\224\184\165\224\184\153\224\184\171\224\184\165\224\184\177\224\184\135 / \224\184\129\224\184\177\224\184\153\224\184\148\224\184\181\224\184\148"
	},
	{
		["key"] = "Tail",
		["th"] = "\224\184\151\224\185\137\224\184\178\224\184\162 / \224\185\131\224\184\149\224\185\137\224\184\151\224\185\137\224\184\178\224\184\162"
	},
	{
		["key"] = "Trim",
		["th"] = "\224\184\130\224\184\173\224\184\154\224\184\149\224\184\129\224\185\129\224\184\149\224\185\136\224\184\135"
	},
	{
		["key"] = "CVT",
		["th"] = "\224\184\132\224\184\163\224\184\173\224\184\154\224\185\129\224\184\132\224\184\163\224\185\137\224\184\135"
	},
	{
		["key"] = "ExhaustShield",
		["th"] = "\224\184\129\224\184\177\224\184\153\224\184\163\224\185\137\224\184\173\224\184\153\224\184\151\224\185\136\224\184\173"
	}
}
v_u_28.ACCESSORIES = {
	{
		["key"] = "CamL",
		["th"] = "\224\184\129\224\184\165\224\185\137\224\184\173\224\184\135\224\185\129\224\184\174\224\184\153\224\184\148\224\185\140\224\184\139\224\185\137\224\184\178\224\184\162"
	},
	{
		["key"] = "CamR",
		["th"] = "\224\184\129\224\184\165\224\185\137\224\184\173\224\184\135\224\185\129\224\184\174\224\184\153\224\184\148\224\185\140\224\184\130\224\184\167\224\184\178"
	},
	{
		["key"] = "CamRear",
		["th"] = "\224\184\129\224\184\165\224\185\137\224\184\173\224\184\135\224\184\151\224\185\137\224\184\178\224\184\162"
	},
	{
		["key"] = "Cam360",
		["th"] = "\224\184\129\224\184\165\224\185\137\224\184\173\224\184\135 360",
		["price"] = 5000
	},
	{
		["key"] = "RackOff",
		["th"] = "\224\184\149\224\184\176\224\185\129\224\184\129\224\184\163\224\184\135\224\184\151\224\185\137\224\184\178\224\184\162",
		["remove"] = true,
		["price"] = 2000
	},
	{
		["key"] = "EngineCoverOff",
		["th"] = "\224\184\132\224\184\163\224\184\173\224\184\154\224\185\128\224\184\132\224\184\163\224\184\183\224\185\136\224\184\173\224\184\135\224\184\148\224\184\179",
		["remove"] = true,
		["price"] = 2000
	},
	{
		["key"] = "ExhaustCoverOff",
		["th"] = "\224\184\132\224\184\163\224\184\173\224\184\154\224\184\151\224\185\136\224\184\173",
		["remove"] = true,
		["price"] = 2000
	},
	{
		["key"] = "SeatRailOff",
		["th"] = "\224\184\129\224\184\178\224\184\163\224\185\140\224\184\148\224\184\171\224\184\165\224\184\177\224\184\135\224\185\128\224\184\154\224\184\178\224\184\176",
		["remove"] = true,
		["price"] = 500
	},
	{
		["key"] = "GuardOff",
		["th"] = "\224\184\129\224\184\177\224\184\153\224\184\149\224\184\129",
		["remove"] = true,
		["price"] = 500
	},
	{
		["key"] = "MirrorsOff",
		["th"] = "\224\184\129\224\184\163\224\184\176\224\184\136\224\184\129\224\184\161\224\184\173\224\184\135\224\184\130\224\185\137\224\184\178\224\184\135",
		["remove"] = true,
		["price"] = 500
	},
	{
		["key"] = "ExhaustSC",
		["th"] = "\224\184\151\224\185\136\224\184\173 SC",
		["price"] = 5999,
		["group"] = "Exhaust"
	},
	{
		["key"] = "ExhaustTourerSC",
		["th"] = "\224\184\151\224\185\136\224\184\173 SC \224\184\148\224\184\179",
		["price"] = 10000
	},
	{
		["key"] = "RearShock",
		["th"] = "\224\185\130\224\184\138\224\185\138\224\184\132\224\184\171\224\184\165\224\184\177\224\184\135\224\185\129\224\184\149\224\185\136\224\184\135",
		["price"] = 5000,
		["group"] = "RearShock"
	},
	{
		["key"] = "RearShock2",
		["th"] = "\224\185\130\224\184\138\224\185\138\224\184\132\224\184\171\224\184\165\224\184\177\224\184\135\224\185\129\224\184\149\224\185\136\224\184\135 2",
		["price"] = 5000,
		["group"] = "RearShock"
	},
	{
		["key"] = "SeatSport",
		["th"] = "\224\185\128\224\184\154\224\184\178\224\184\176\224\185\129\224\184\149\224\185\136\224\184\135 \224\184\165\224\184\178\224\184\162\224\184\170\224\184\155\224\184\173\224\184\163\224\185\140\224\184\149",
		["price"] = 5000,
		["group"] = "Seat"
	},
	{
		["key"] = "SeatCross",
		["th"] = "\224\185\128\224\184\154\224\184\178\224\184\176\224\185\129\224\184\149\224\185\136\224\184\135 \224\184\165\224\184\178\224\184\162\224\184\132\224\184\163\224\184\173\224\184\170",
		["price"] = 5000,
		["group"] = "Seat"
	},
	{
		["key"] = "SeatCrossV1",
		["th"] = "\224\185\128\224\184\154\224\184\178\224\184\176\224\185\129\224\184\149\224\185\136\224\184\135 \224\184\165\224\184\178\224\184\162\224\184\132\224\184\163\224\184\173\224\184\170 V1",
		["price"] = 5000,
		["group"] = "Seat"
	},
	{
		["key"] = "RimGold",
		["th"] = "\224\184\165\224\185\137\224\184\173\224\185\129\224\184\161\224\185\135\224\184\129 MFZ \224\184\170\224\184\181\224\184\151\224\184\173\224\184\135 (\224\184\171\224\184\153\224\185\137\224\184\178+\224\184\171\224\184\165\224\184\177\224\184\135)",
		["price"] = 5000,
		["group"] = "Rim"
	},
	{
		["key"] = "RimYellow",
		["th"] = "\224\184\165\224\185\137\224\184\173\224\185\129\224\184\161\224\185\135\224\184\129\224\184\170\224\184\181\224\185\128\224\184\171\224\184\165\224\184\183\224\184\173\224\184\135 (\224\184\171\224\184\153\224\185\137\224\184\178+\224\184\171\224\184\165\224\184\177\224\184\135)",
		["price"] = 2000,
		["group"] = "Rim"
	},
	{
		["key"] = "RimBlack",
		["th"] = "\224\184\165\224\185\137\224\184\173\224\185\129\224\184\161\224\185\135\224\184\129\224\184\148\224\184\179 Forza (\224\184\171\224\184\153\224\185\137\224\184\178+\224\184\171\224\184\165\224\184\177\224\184\135)",
		["price"] = 5000,
		["group"] = "Rim"
	},
	{
		["key"] = "RimCNC",
		["th"] = "\224\184\165\224\185\137\224\184\173\224\185\129\224\184\161\224\185\135\224\184\129 CNC \224\184\129\224\184\177\224\184\148\224\184\165\224\184\178\224\184\162 OL (\224\184\171\224\184\153\224\185\137\224\184\178+\224\184\171\224\184\165\224\184\177\224\184\135)",
		["price"] = 10000,
		["group"] = "Rim"
	},
	{
		["key"] = "CvtCNC",
		["th"] = "\224\184\132\224\184\163\224\184\173\224\184\154\224\185\129\224\184\132\224\184\163\224\185\137\224\184\135 CNC OL",
		["price"] = 5000
	},
	{
		["key"] = "ExhaustStylo",
		["th"] = "\224\184\151\224\185\136\224\184\173\224\185\129\224\184\149\224\185\136\224\184\135 \224\184\148\224\184\179-\224\185\132\224\184\151\224\185\128\224\184\151",
		["price"] = 10000,
		["group"] = "Exhaust"
	},
	{
		["key"] = "ExhaustTi",
		["th"] = "\224\184\151\224\185\136\224\184\173\224\185\132\224\184\151",
		["price"] = 4500,
		["group"] = "Exhaust"
	},
	{
		["key"] = "BrakeHose",
		["th"] = "\224\184\170\224\184\178\224\184\162\224\184\150\224\184\177\224\184\129\224\185\128\224\184\154\224\184\163\224\184\129",
		["price"] = 1000
	},
	{
		["key"] = "SwingArmK2",
		["th"] = "\224\184\170\224\184\167\224\184\180\224\184\135\224\184\173\224\184\178\224\184\163\224\185\140\224\184\161 K2",
		["price"] = 3500
	},
	{
		["key"] = "LiveryBlue",
		["th"] = "\224\184\170\224\184\149\224\184\180\224\185\138\224\184\129\224\185\128\224\184\129\224\184\173\224\184\163\224\185\140\224\184\165\224\184\178\224\184\162 \224\184\170\224\184\181\224\184\153\224\185\137\224\184\179\224\185\128\224\184\135\224\184\180\224\184\153",
		["price"] = 5000,
		["group"] = "Livery"
	},
	{
		["key"] = "LiveryGreen",
		["th"] = "\224\184\170\224\184\149\224\184\180\224\185\138\224\184\129\224\185\128\224\184\129\224\184\173\224\184\163\224\185\140\224\184\165\224\184\178\224\184\162 \224\184\170\224\184\181\224\185\128\224\184\130\224\184\181\224\184\162\224\184\167",
		["price"] = 5000,
		["group"] = "Livery"
	},
	{
		["key"] = "LiveryYellow",
		["th"] = "\224\184\170\224\184\149\224\184\180\224\185\138\224\184\129\224\185\128\224\184\129\224\184\173\224\184\163\224\185\140\224\184\165\224\184\178\224\184\162 \224\184\170\224\184\181\224\185\128\224\184\171\224\184\165\224\184\183\224\184\173\224\184\135",
		["price"] = 5000,
		["group"] = "Livery"
	},
	{
		["key"] = "LiveryPink",
		["th"] = "\224\184\170\224\184\149\224\184\180\224\185\138\224\184\129\224\185\128\224\184\129\224\184\173\224\184\163\224\185\140\224\184\165\224\184\178\224\184\162 \224\184\170\224\184\181\224\184\138\224\184\161\224\184\158\224\184\185",
		["price"] = 5000,
		["group"] = "Livery"
	},
	{
		["key"] = "LiveryRed",
		["th"] = "\224\184\170\224\184\149\224\184\180\224\185\138\224\184\129\224\185\128\224\184\129\224\184\173\224\184\163\224\185\140\224\184\165\224\184\178\224\184\162 \224\184\170\224\184\181\224\185\129\224\184\148\224\184\135",
		["price"] = 5000,
		["group"] = "Livery"
	},
	{
		["key"] = "LiveryPurple",
		["th"] = "\224\184\170\224\184\149\224\184\180\224\185\138\224\184\129\224\185\128\224\184\129\224\184\173\224\184\163\224\185\140\224\184\165\224\184\178\224\184\162 \224\184\170\224\184\181\224\184\161\224\185\136\224\184\167\224\184\135",
		["price"] = 5000,
		["group"] = "Livery"
	},
	{
		["key"] = "LiveryCyan",
		["th"] = "\224\184\170\224\184\149\224\184\180\224\185\138\224\184\129\224\185\128\224\184\129\224\184\173\224\184\163\224\185\140\224\184\165\224\184\178\224\184\162 \224\184\170\224\184\181\224\184\159\224\185\137\224\184\178",
		["price"] = 5000,
		["group"] = "Livery"
	},
	{
		["key"] = "LiveryOff",
		["th"] = "\224\184\150\224\184\173\224\184\148\224\184\165\224\184\178\224\184\162\224\185\132\224\184\159\224\184\173\224\184\173\224\184\129 (\224\184\149\224\184\177\224\184\167\224\184\163\224\184\150\224\185\128\224\184\163\224\184\181\224\184\162\224\184\154)",
		["price"] = 5000,
		["group"] = "Livery"
	}
}
function v_u_28.accessory(p36) -- name: accessory
	-- upvalues: (copy) v_u_28
	for _, v37 in v_u_28.ACCESSORIES do
		if v37.key ~= p36 then
			continue
		end
		return v37
	end
	return nil
end
function v_u_28.carbonPart(p38) -- name: carbonPart
	-- upvalues: (copy) v_u_28
	for _, v39 in v_u_28.CARBON_PARTS do
		if v39.key ~= p38 then
			continue
		end
		return v39
	end
	return nil
end
v_u_28.PISTON_SOUND = {
	["none"] = {
		["volume"] = 1,
		["rasp"] = 0,
		["bass"] = 0,
		["pops"] = 1
	},
	["smallest"] = {
		["bore"] = 53,
		["volume"] = 1.08,
		["rasp"] = 0.03,
		["bass"] = 0.8,
		["pops"] = 1.1
	},
	["biggest"] = {
		["bore"] = 90,
		["volume"] = 1.8,
		["rasp"] = 0.26,
		["bass"] = 6,
		["pops"] = 2.1
	}
}
function v_u_28.pistonSound(p40) -- name: pistonSound
	-- upvalues: (copy) v_u_28
	local v41 = v_u_28.PISTON_SOUND
	if type(p40) ~= "number" or p40 <= 0 then
		return v41.none
	end
	local v42 = v41.smallest
	local v43 = v41.biggest
	local v44 = (p40 - v42.bore) / (v43.bore - v42.bore)
	local v45 = math.clamp(v44, 0, 1)
	return {
		["volume"] = v42.volume + (v43.volume - v42.volume) * v45,
		["rasp"] = v42.rasp + (v43.rasp - v42.rasp) * v45,
		["bass"] = v42.bass + (v43.bass - v42.bass) * v45,
		["pops"] = v42.pops + (v43.pops - v42.pops) * v45
	}
end
v_u_28.DRL_STYLES = {
	["Rainbow"] = true,
	["Solid"] = true,
	["Gradient"] = true,
	["Mode"] = true
}
v_u_28.DRL_DEFAULT_COLOR = Color3.fromRGB(70, 140, 255)
v_u_28.INDICATOR_MODES = {
	["Off"] = true,
	["Left"] = true,
	["Right"] = true,
	["Hazard"] = true
}
v_u_28.BLINK_PERIOD = 0.7
v_u_28.BLINK_ON_TIME = 0.38
v_u_28.DEFAULT_BLINKER_SOUND = "103115521237862"
v_u_28.DEFAULT_SWITCH_SOUND = "6725066621"
v_u_28.BLINK_RATE_MAX = 16
function v_u_28.blinkRate(p46) -- name: blinkRate
	-- upvalues: (copy) v_u_28
	if p46 then
		p46 = p46:GetAttribute("BlinkRate")
	end
	if type(p46) ~= "number" or p46 ~= p46 then
		return 1
	end
	local v47 = v_u_28.BLINK_RATE_MAX
	return math.clamp(p46, 1, v47)
end
v_u_28.SIGNAL_DEFAULT_COLOR = Color3.fromRGB(255, 140, 0)
function v_u_28.signalColor(p48) -- name: signalColor
	-- upvalues: (copy) v_u_28
	if p48 then
		p48 = p48:GetAttribute("SignalColor")
	end
	if typeof(p48) == "Color3" then
		return p48
	else
		return v_u_28.SIGNAL_DEFAULT_COLOR
	end
end
function v_u_28.blinkAt(p49, p50) -- name: blinkAt
	-- upvalues: (copy) v_u_28
	local v51 = v_u_28.blinkRate(p49)
	if v_u_28.BLINK_RATE_MAX <= v51 then
		return true, 1
	end
	local v52 = v_u_28.BLINK_ON_TIME / v51
	local v53 = p50 % (v_u_28.BLINK_PERIOD / v51)
	return v53 < v52, v53 / v52
end
v_u_28.FOOT_STOP_SPEED = 0.6
v_u_28.FOOT_CREEP_SPEED = 3
v_u_28.FOOT_GO_SPEED = 2
v_u_28.FOOT_LEAN_BOTH = 0.05235987755982989
v_u_28.FOOT_LEAN_ONE = 0.13962634015954636
v_u_28.FOOT_LEAN_STAND = 0.15707963267948966
v_u_28.STAND_STEER = 0.5
v_u_28.STAND_RIDER_LEAN = 0.4
function v_u_28.standFootMode(p54, p55, p56) -- name: standFootMode
	-- upvalues: (copy) v_u_28
	if p54 ~= "none" and math.abs(p55) < v_u_28.FOOT_CREEP_SPEED then
		if v_u_28.STAND_STEER < p56 then
			return "right"
		end
		if p56 < -v_u_28.STAND_STEER then
			return "left"
		end
	end
	return p54
end
function v_u_28.footLean(p57, p58) -- name: footLean
	-- upvalues: (copy) v_u_28
	if p57 == "right" then
		return v_u_28.FOOT_LEAN_STAND
	elseif p57 == "left" then
		if p58 < -v_u_28.STAND_STEER then
			return -v_u_28.FOOT_LEAN_STAND
		else
			return -v_u_28.FOOT_LEAN_ONE
		end
	else
		return -v_u_28.FOOT_LEAN_ONE
	end
end
function v_u_28.footMode(p59, p60, p61) -- name: footMode
	-- upvalues: (copy) v_u_28
	local v62 = math.abs(p60)
	return p61 > 0 and v_u_28.FOOT_GO_SPEED < v62 and "none" or (p59 == "none" and (p61 <= 0 and v62 < v_u_28.FOOT_CREEP_SPEED - 0.5 and (v62 < v_u_28.FOOT_STOP_SPEED and "both" or "left") or "none") or (p59 == "both" and ((p61 > 0 or v_u_28.FOOT_STOP_SPEED * 2 < v62) and "left" or "both") or (v_u_28.FOOT_CREEP_SPEED < v62 and "none" or (v62 < v_u_28.FOOT_STOP_SPEED and p61 <= 0 and "both" or "left"))))
end
function v_u_28.maxSteer(p63) -- name: maxSteer
	-- upvalues: (copy) v_u_28
	local v64 = math.abs(p63) / v_u_28.STEER_FADE_SPEED
	local v65 = math.min(1, v64)
	return v_u_28.MAX_STEER + (v_u_28.MIN_STEER - v_u_28.MAX_STEER) * v65
end
function v_u_28.stepSpeed(p66, p67, p68, p69, p70, p71) -- name: stepSpeed
	-- upvalues: (copy) v_u_28
	if p67 <= 0 then
		if p67 >= 0 then
			return v_u_28.coast(p66, p69)
		end
		if p66 > 0.5 then
			return v_u_28.brake(p66, p69, p71)
		end
		local v72 = p66 - v_u_28.REVERSE_ACCEL * -p67 * p69
		local v73 = -v_u_28.REVERSE_SPEED
		return math.max(v72, v73)
	end
	if p66 < 0 then
		local v74 = p66 + v_u_28.BRAKE_DECEL * (p71 or 1) * p69
		return math.min(v74, 0)
	end
	local v75 = v_u_28.THROTTLE_ACCEL * (p70 or 1)
	local v76 = p66 / p68
	local v77 = 1 - math.clamp(v76, 0, 1) ^ v_u_28.ACCEL_TAPER
	local v78 = p66 + v75 * math.max(0, v77) * p67 * p69
	return math.min(v78, p68)
end
function v_u_28.coast(p79, p80) -- name: coast
	-- upvalues: (copy) v_u_28
	if p79 > 0 then
		local v81 = p79 - (1.5 + 0.0004 * p79 * p79) * p80
		return math.max(v81, 0)
	end
	if p79 >= 0 then
		return 0
	end
	local v82 = p79 + v_u_28.REVERSE_ACCEL * p80
	return math.min(v82, 0)
end
function v_u_28.brake(p83, p84, p85) -- name: brake
	-- upvalues: (copy) v_u_28
	local v86 = v_u_28.BRAKE_BOOST_MAX
	local v87 = math.abs(p83) - v_u_28.BRAKE_BOOST_FROM
	local v88 = 1 + math.max(0, v87) / v_u_28.BRAKE_BOOST_PER
	local v89 = math.min(v86, v88)
	local v90 = v_u_28.BRAKE_DECEL * (p85 or 1) * v89
	local v91 = v_u_28.BRAKE_DECEL_MAX
	local v92 = math.min(v90, v91)
	if p83 > 0 then
		local v93 = p83 - v92 * p84
		return math.max(v93, 0)
	else
		local v94 = p83 + v92 * p84
		return math.min(v94, 0)
	end
end
function v_u_28.yawRate(p95, p96, p97) -- name: yawRate
	-- upvalues: (copy) v_u_28
	if p95 == 0 or p96 == 0 then
		return 0
	end
	local v98 = p96 * p95
	local v99 = v_u_28.maxSteer(p95)
	local v100 = v98 * math.tan(v99) / p97
	local v101 = math.abs(p95)
	if v_u_28.STEER_HEAVY_FROM < v101 then
		v100 = v100 * (v_u_28.STEER_HEAVY_FROM / v101) ^ v_u_28.STEER_HEAVY_POWER
	end
	return v100
end
function v_u_28.steerRate(p102) -- name: steerRate
	-- upvalues: (copy) v_u_28
	local v103 = (math.abs(p102) - v_u_28.STEER_RATE_SLOW_SPEED) / (v_u_28.STEER_RATE_FAST_SPEED - v_u_28.STEER_RATE_SLOW_SPEED)
	local v104 = math.clamp(v103, 0, 1)
	return v_u_28.STEER_RATE_SLOW + (v_u_28.STEER_RATE_FAST - v_u_28.STEER_RATE_SLOW) * v104
end
function v_u_28.leanFor(p105, p106) -- name: leanFor
	-- upvalues: (copy) v_u_28
	local v107 = p105 * p106 / v_u_28.LEAN_GRAVITY
	local v108 = math.atan(v107)
	local v109 = -v_u_28.MAX_LEAN
	local v110 = v_u_28.MAX_LEAN
	return math.clamp(v108, v109, v110)
end
function v_u_28.toKmh(p111) -- name: toKmh
	-- upvalues: (copy) v_u_28
	return p111 * v_u_28.KMH_PER_STUD
end
function v_u_28.alpha(p112, p113) -- name: alpha
	local v114 = -p112 * p113
	return 1 - math.exp(v114)
end
function v_u_28.smoothstep(p115, p116, p117) -- name: smoothstep
	local v118 = (p117 - p115) / (p116 - p115)
	local v119 = math.clamp(v118, 0, 1)
	return v119 * v119 * (3 - v119 * 2)
end
function v_u_28.flatRotation(p120) -- name: flatRotation
	local v121 = p120.LookVector
	local v122 = v121.X
	local v123 = v121.Z
	local v124 = Vector3.new(v122, 0, v123)
	if v124.Magnitude < 0.001 then
		local v125 = -p120.UpVector
		local v126 = v121.Y
		local v127 = v125 * math.sign(v126)
		local v128 = v127.X
		local v129 = v127.Z
		v124 = Vector3.new(v128, 0, v129)
	end
	return CFrame.lookAt(Vector3.new(0, 0, 0), v124.Unit)
end
function v_u_28.bikeFromSeat(p130) -- name: bikeFromSeat
	-- upvalues: (copy) v_u_28
	if p130 and p130:IsA("VehicleSeat") then
		local v131 = p130.Parent
		if v131 and v131:HasTag(v_u_28.TAG) then
			return v131
		else
			return nil
		end
	else
		return nil
	end
end
v_u_28.FREE_REV_SPIN = 30
function v_u_28.freeRev(p132, p133) -- name: freeRev
	if not p133 or (not p133.Occupant or (p132:GetAttribute("EngineOn") ~= true or (p132:GetAttribute("StandDown") == false or p132:GetAttribute("DismountStart") ~= nil))) then
		return 0
	end
	local v134 = p133.ThrottleFloat
	return math.max(0, v134)
end
return v_u_28