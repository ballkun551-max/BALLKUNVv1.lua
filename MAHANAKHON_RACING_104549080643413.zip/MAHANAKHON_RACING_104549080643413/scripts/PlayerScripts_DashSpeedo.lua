-- Path: Players/ygggggg55551/PlayerScripts/DashSpeedo
-- Class: LocalScript  true/Enum.RunContext.Legacy
-- Decompiled by BALL KUN Universal Map Dump

local v1 = game:GetService("CollectionService")
local v2 = game:GetService("RunService")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = require(v3:WaitForChild("GearShared"))
local v_u_5 = {}
local v_u_6 = setmetatable({}, {
	["__mode"] = "k"
})
local function v_u_9(p7) -- name: vehicleOf
	local v8 = p7.Parent
	while v8 and v8 ~= workspace do
		if v8:IsA("Model") and v8:GetAttribute("VehicleId") ~= nil then
			return v8
		end
		v8 = v8.Parent
	end
	return nil
end
local function v_u_19(p10, p11, p12, p13, p14, p15, p16, p17) -- name: box
	local v18 = Instance.new("Frame")
	v18.Name = p11
	v18.Position = UDim2.fromScale(p12, p13)
	v18.Size = UDim2.fromScale(p14, p15)
	v18.BackgroundColor3 = p16 or Color3.new()
	v18.BackgroundTransparency = p17 or 0
	v18.BorderSizePixel = 0
	v18.Parent = p10
	return v18
end
local function v_u_31(p20, p21, p22, p23, p24, p25, p26, p27, p28, p29) -- name: text
	local v30 = Instance.new("TextLabel")
	v30.Name = p21
	v30.BackgroundTransparency = 1
	v30.Position = UDim2.fromScale(p23, p24)
	v30.Size = UDim2.fromScale(p25, p26)
	v30.Font = p28 or Enum.Font.GothamBold
	v30.TextScaled = true
	v30.TextColor3 = p27
	v30.Text = p22
	v30.TextXAlignment = p29 or Enum.TextXAlignment.Center
	v30.Parent = p20
	return v30
end
local function v_u_40(p32, p33) -- name: shade
	local v34 = Color3.new
	local v35 = p32.R * p33
	local v36 = math.clamp(v35, 0, 1)
	local v37 = p32.G * p33
	local v38 = math.clamp(v37, 0, 1)
	local v39 = p32.B * p33
	return v34(v36, v38, (math.clamp(v39, 0, 1)))
end
local v_u_41 = {
	["0"] = "abcdef",
	["1"] = "bc",
	["2"] = "abdeg",
	["3"] = "abcdg",
	["4"] = "bcfg",
	["5"] = "acdfg",
	["6"] = "acdefg",
	["7"] = "abc",
	["8"] = "abcdefg",
	["9"] = "abcdfg",
	["-"] = "g",
	[" "] = ""
}
local function v_u_55(p42, p43, p44, p45, p46, p47, p48) -- name: newDigit
	-- upvalues: (copy) v_u_19
	local v49 = v_u_19(p42, "Digit", p43, p44, p45, p46, nil, 1)
	local v50 = {}
	for v51, v52 in {
		["a"] = {
			0.12,
			0,
			0.76,
			0.1
		},
		["g"] = {
			0.12,
			0.45,
			0.76,
			0.1
		},
		["d"] = {
			0.12,
			0.9,
			0.76,
			0.1
		},
		["f"] = {
			0,
			0.06,
			0.2,
			0.41
		},
		["b"] = {
			0.8,
			0.06,
			0.2,
			0.41
		},
		["e"] = {
			0,
			0.53,
			0.2,
			0.41
		},
		["c"] = {
			0.8,
			0.53,
			0.2,
			0.41
		}
	} do
		local v53 = v_u_19(v49, v51, v52[1], v52[2], v52[3], v52[4], p47, p48)
		local v54 = Instance.new("UICorner")
		v54.CornerRadius = UDim.new(0.5, 0)
		v54.Parent = v53
		v50[v51] = v53
	end
	return {
		["segs"] = nil,
		["ch"] = nil,
		["ghost"] = nil,
		["segs"] = v50,
		["ghost"] = p48
	}
end
local function v_u_61(p56, p57) -- name: setDigit
	-- upvalues: (copy) v_u_41
	if p56.ch ~= p57 then
		p56.ch = p57
		local v58 = v_u_41[p57] or ""
		for v59, v60 in p56.segs do
			v60.BackgroundTransparency = v58:find(v59, 1, true) and 0 or p56.ghost
		end
	end
end
local function v_u_69(p62, p63, p64) -- name: setNumber
	-- upvalues: (copy) v_u_61
	local v65
	if p64 then
		v65 = string.rep("8", #p62)
	else
		v65 = not p63 and "" or tostring(p63)
	end
	if #v65 > #p62 then
		v65 = string.rep("9", #p62)
	end
	local v66 = string.rep(" ", #p62 - #v65) .. v65
	for v67, v68 in p62 do
		v_u_61(v68, v66:sub(v67, v67))
	end
end
local function v_u_82(p70, p71, p72, p73, p74, p75, p76, p77) -- name: digitRow
	-- upvalues: (copy) v_u_55
	local v78 = p74 / p71
	local v79 = {}
	for v80 = 1, p71 do
		local v81 = v_u_55(p70, p72 + (v80 - 1) * v78 + v78 * 0.08, p73, v78 * 0.84, p75, p76, p77)
		table.insert(v79, v81)
	end
	return v79
end
local function v_u_99(p83, p84, p85, p86, p87, p88, p89, p90, p91) -- name: barRow
	-- upvalues: (copy) v_u_19
	local v92 = p91 or 0.25
	local v93 = {}
	for v94 = 1, p84 do
		local v95
		if p90 then
			local v96 = p88 / p84
			v95 = v_u_19(p83, "Bar", p85, p86 + p88 - v94 * v96 + v96 * v92 / 2, p87, v96 * (1 - v92), p89(v94, p84), 0.85)
		else
			local v97 = p87 / p84
			v95 = v_u_19(p83, "Bar", p85 + (v94 - 1) * v97 + v97 * v92 / 2, p86, v97 * (1 - v92), p88, p89(v94, p84), 0.85)
		end
		local v98 = Instance.new("UICorner")
		v98.CornerRadius = UDim.new(0.25, 0)
		v98.Parent = v95
		table.insert(v93, v95)
	end
	return v93
end
local function v_u_105(p100, p101, p102) -- name: setBars
	if p100.lit ~= p101 or p100.off ~= p102 then
		p100.lit = p101
		p100.off = p102
		for v103, v104 in ipairs(p100) do
			v104.BackgroundTransparency = v103 <= p101 and 0 or p102
		end
	end
end
local function v_u_117(p106, p107, p108, p109, p110, p111, p112) -- name: arrow
	-- upvalues: (copy) v_u_19
	local v113 = v_u_19(p106, p112 and "ArrowR" or "ArrowL", p107, p108, p109, p110, nil, 1)
	for _, v114 in { 1, -1 } do
		local v115 = v_u_19(v113, "Stroke", 0.2, 0.41000000000000003, 0.62, 0.18, p111, 0)
		v115.AnchorPoint = Vector2.new(0, 0.5)
		v115.Position = UDim2.fromScale(0.18, 0.5 + v114 * 0.18)
		v115.Rotation = (p112 and -1 or 1) * v114 * 40
		local v116 = Instance.new("UICorner")
		v116.CornerRadius = UDim.new(0.5, 0)
		v116.Parent = v115
	end
	return v113
end
local function v_u_123(p118, p119, p120) -- name: setArrow
	local v121 = tostring(p119) .. p120
	if p118 and p118:GetAttribute("K") ~= v121 then
		p118:SetAttribute("K", v121)
		for _, v122 in p118:GetChildren() do
			if not v122:IsA("Frame") then
				continue
			end
			v122.BackgroundTransparency = p119 and 0 or p120
		end
	end
end
local v_u_124 = {
	["paper"] = nil,
	["ink"] = nil,
	["ghost"] = 0.93,
	["paper"] = Color3.fromRGB(7, 9, 12),
	["ink"] = Color3.fromRGB(226, 240, 255)
}
local v_u_125 = {
	["paper"] = nil,
	["ink"] = nil,
	["ghost"] = 0.88,
	["paper"] = Color3.fromRGB(176, 204, 192),
	["ink"] = Color3.fromRGB(18, 26, 30)
}
local function v167(p126, p127, p128, p129) -- name: buildLcd
	-- upvalues: (copy) v_u_125, (copy) v_u_124, (copy) v_u_19, (copy) v_u_40, (copy) v_u_82, (copy) v_u_31, (copy) v_u_99, (copy) v_u_117
	local v130
	if p129.style == "lcd" then
		v130 = v_u_125
	else
		v130 = v_u_124
	end
	local v131 = p129.screen:GetAttribute("ThemePaper") or v130.paper
	local v_u_132 = p129.screen:GetAttribute("ThemeInk") or v130.ink
	local v133 = v130.ghost
	local v134 = v_u_19(p126, "Glass", 0, 0, 1, 1, v131, p129.shape and 1 or 0)
	p129.glass = v134
	if not p129.shape then
		local v135 = p129.round and 0.5 or 0.14
		local v136 = Instance.new("UICorner")
		v136.CornerRadius = UDim.new(v135, 0)
		v136.Parent = v134
		local v137 = Instance.new("UIGradient")
		local v138 = ColorSequence.new
		local v139 = Color3.new
		local v140 = v131.R * 1.25
		local v141 = math.clamp(v140, 0, 1)
		local v142 = v131.G * 1.25
		local v143 = math.clamp(v142, 0, 1)
		local v144 = v131.B * 1.25
		v137.Color = v138(v139(v141, v143, (math.clamp(v144, 0, 1))), v_u_40(v131, 0.8))
		v137.Rotation = 90
		v137.Parent = v134
		local v145 = Color3.new(0, 0, 0)
		local v146 = p128 * 0.025
		local v147 = math.max(1, v146)
		local v148 = Instance.new("UIStroke")
		v148.Color = v145
		v148.Thickness = v147
		v148.Transparency = 0.35
		v148.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
		v148.Parent = v134
	end
	p129.ink = v_u_132
	p129.paper = v131
	local v149 = (p128 < 75 or p127 < 110) and true or p129.shape ~= nil
	if p129.round then
		p129.digits = v_u_82(v134, 3, 0.2, 0.3, 0.6, 0.32, v_u_132, v133)
		p129.unit = v_u_31(v134, "Unit", "km/h", 0.33, 0.64, 0.34, 0.1, v_u_132)
		p129.revBars = {}
		for v150 = 1, 13 do
			local v151 = (v150 - 1) * 240 / 12 + -120
			local v152 = math.rad(v151)
			local v153 = v_u_19
			local v154 = "Rev"
			local v155 = math.sin(v152) * 0.41 + 0.5
			local v156 = 0.5 - math.cos(v152) * 0.41
			local v157 = 0.035
			local v158 = 0.075
			local v159
			if v150 > 10 then
				v159 = Color3.fromRGB(255, 70, 50)
			else
				v159 = v_u_132
			end
			local v160 = v153(v134, v154, v155, v156, v157, v158, v159, 0.85)
			v160.AnchorPoint = Vector2.new(0.5, 0.5)
			v160.Rotation = math.deg(v152)
			local v161 = Instance.new("UICorner")
			v161.CornerRadius = UDim.new(0.4, 0)
			v161.Parent = v160
			local v162 = p129.revBars
			table.insert(v162, v160)
		end
		if p129.manual then
			p129.gearLabel = v_u_31(v134, "Gear", "N", 0.42, 0.16, 0.16, 0.12, v_u_132, Enum.Font.GothamBlack)
		else
			p129.fuel = v_u_99(v134, 5, 0.32, 0.78, 0.36, 0.05, function()
				-- upvalues: (copy) v_u_132
				return v_u_132
			end, false, 0.3)
		end
	elseif v149 then
		local v163 = p129.shape and 0.24 or 0.05
		local v164 = p129.shape and 0.42 or 0.64
		p129.digits = v_u_82(v134, 3, v163, 0.14, v164, 0.72, v_u_132, v133)
		p129.unit = v_u_31(v134, "Unit", "km/h", v163 + v164 + 0.02, 0.58, 0.26, 0.24, v_u_132)
		if p129.manual then
			p129.gearLabel = v_u_31(v134, "Gear", "N", v163 + v164 + 0.04, 0.12, 0.18, 0.4, v_u_132, Enum.Font.GothamBlack)
		end
	else
		p129.clock = v_u_31(v134, "Clock", "", 0.05, 0.04, 0.26, 0.15, v_u_132, Enum.Font.Code, Enum.TextXAlignment.Left)
		p129.arrowL = v_u_117(v134, 0.36, 0.04, 0.08, 0.15, Color3.fromRGB(70, 230, 110), false)
		p129.arrowR = v_u_117(v134, 0.47, 0.04, 0.08, 0.15, Color3.fromRGB(70, 230, 110), true)
		if p129.manual then
			local v165 = v_u_19(v134, "GearBox", 0.84, 0.04, 0.12, 0.28, v_u_132, 0.9)
			local v166 = Instance.new("UICorner")
			v166.CornerRadius = UDim.new(0.2, 0)
			v166.Parent = v165
			p129.gearLabel = v_u_31(v165, "Gear", "N", 0.05, 0.05, 0.9, 0.9, v_u_132, Enum.Font.GothamBlack)
		else
			p129.eco = v_u_31(v134, "Eco", "ECO", 0.62, 0.05, 0.16, 0.13, Color3.fromRGB(70, 230, 110), Enum.Font.GothamBlack)
		end
		p129.digits = v_u_82(v134, 3, 0.04, 0.22, 0.6, 0.54, v_u_132, v133)
		p129.unit = v_u_31(v134, "Unit", "km/h", 0.64, 0.58, 0.16, 0.16, v_u_132)
		v_u_31(v134, "F", "F", 0.79, p129.manual and 0.34 or 0.22, 0.05, 0.1, v_u_132)
		v_u_31(v134, "E", "E", 0.79, 0.66, 0.05, 0.1, v_u_132)
		p129.fuel = v_u_99(v134, 6, 0.85, p129.manual and 0.34 or 0.22, 0.1, p129.manual and 0.42 or 0.54, function()
			-- upvalues: (copy) v_u_132
			return v_u_132
		end, true, 0.3)
		v_u_31(v134, "OdoTag", "TRIP", 0.05, 0.81, 0.12, 0.12, v_u_132, Enum.Font.GothamBold, Enum.TextXAlignment.Left)
		p129.trip = v_u_31(v134, "Trip", "0.0", 0.17, 0.79, 0.24, 0.16, v_u_132, Enum.Font.Code, Enum.TextXAlignment.Left)
		v_u_31(v134, "OdoTag2", "ODO", 0.46, 0.81, 0.1, 0.12, v_u_132, Enum.Font.GothamBold, Enum.TextXAlignment.Left)
		p129.odo = v_u_31(v134, "Odo", "000000", 0.57, 0.79, 0.38, 0.16, v_u_132, Enum.Font.Code, Enum.TextXAlignment.Left)
	end
end
local v_u_168 = {
	["lcd"] = nil,
	["inner"] = 0.88,
	["stripeL"] = nil,
	["stripeR"] = nil,
	["lcd"] = {
		0.254,
		0.005,
		0.736,
		1
	},
	["stripeL"] = {
		{
			0,
			0.378,
			0.108,
			0.419
		},
		{
			0.108,
			0.419,
			0.2,
			0.723
		}
	},
	["stripeR"] = {
		{
			0.785,
			0.687,
			0.82,
			0.557
		},
		{
			0.82,
			0.557,
			1,
			0.549
		}
	}
}
local v_u_169 = Color3.fromRGB(16, 20, 18)
local v_u_170 = Color3.fromRGB(80, 255, 120)
local function v_u_186(p171, p172, p173, p174) -- name: stripe
	-- upvalues: (copy) v_u_169
	local v175 = p174[1] * p172
	local v176 = p174[2] * p173
	local v177 = p174[3] * p172
	local v178 = p174[4] * p173
	local v179 = (v177 - v175) ^ 2 + (v178 - v176) ^ 2
	local v180 = math.sqrt(v179) * 1.08
	local v181 = Instance.new("Frame")
	v181.Name = "Stripe"
	v181.AnchorPoint = Vector2.new(0.5, 0.5)
	v181.Position = UDim2.fromOffset((v175 + v177) / 2, (v176 + v178) / 2)
	v181.Size = UDim2.fromOffset(v180 + p173 * 0.1, p173 * 0.15)
	local v182 = v178 - v176
	local v183 = v177 - v175
	local v184 = math.atan2(v182, v183)
	v181.Rotation = math.deg(v184)
	v181.BackgroundColor3 = v_u_169
	v181.BorderSizePixel = 0
	v181.Parent = p171
	local v185 = Instance.new("UICorner")
	v185.CornerRadius = UDim.new(0.5, 0)
	v185.Parent = v181
	return v181
end
local v_u_187 = {
	["x0"] = -0.64,
	["y0"] = 0.165,
	["x1"] = 0.63,
	["y1"] = -0.255,
	["lcd"] = nil,
	["plate"] = nil,
	["lamps"] = nil,
	["arrowL"] = nil,
	["arrowR"] = nil,
	["lampList"] = nil,
	["lcd"] = {
		-0.179,
		0.153,
		0.356,
		0.229
	},
	["plate"] = {
		-0.128,
		-0.091,
		0.25,
		0.057
	},
	["lamps"] = {
		-0.162,
		-0.172,
		0.318,
		0.082
	},
	["arrowL"] = { -0.586, 0.038 },
	["arrowR"] = { 0.578, 0.028 },
	["lampList"] = {
		{
			-0.106,
			-0.194,
			"OIL",
			"red"
		},
		{
			-0.052,
			-0.194,
			"TC",
			"amber"
		},
		{
			-0.005,
			-0.194,
			"TEMP",
			"red"
		},
		{
			0.046,
			-0.194,
			"KEY",
			"amber"
		},
		{
			-0.134,
			-0.231,
			"FI",
			"amber"
		},
		{
			-0.078,
			-0.231,
			"HI",
			"blue"
		},
		{
			0.117,
			-0.231,
			"ABS",
			"amber"
		}
	}
}
local v_u_188 = {
	["red"] = Color3.fromRGB(255, 60, 45),
	["amber"] = Color3.fromRGB(255, 160, 30),
	["blue"] = Color3.fromRGB(60, 140, 255)
}
local v_u_189 = Color3.fromRGB(70, 255, 110)
local v_u_190 = Color3.fromRGB(10, 22, 14)
local v_u_506 = {
	["neg"] = v167,
	["lcd"] = v167,
	["tft"] = function(p191, _, p192, p193) -- name: buildTft
		-- upvalues: (copy) v_u_19, (copy) v_u_31, (copy) v_u_117, (copy) v_u_99
		local v_u_194 = p193.screen:GetAttribute("ThemeAccent") or Color3.fromRGB(235, 40, 40)
		local v195 = v_u_19(p191, "Glass", 0, 0, 1, 1, Color3.fromRGB(10, 12, 18), 0)
		p193.glass = v195
		local v196 = Instance.new("UICorner")
		v196.CornerRadius = UDim.new(0.08, 0)
		v196.Parent = v195
		local v197 = Instance.new("UIGradient")
		v197.Color = ColorSequence.new(Color3.fromRGB(28, 32, 46), Color3.fromRGB(4, 5, 8))
		v197.Rotation = 90
		v197.Parent = v195
		local v198 = Color3.fromRGB(0, 0, 0)
		local v199 = p192 * 0.02
		local v200 = math.max(1, v199)
		local v201 = Instance.new("UIStroke")
		v201.Color = v198
		v201.Thickness = v200
		v201.Transparency = 0.2
		v201.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
		v201.Parent = v195
		p193.accent = v_u_194
		if p193.screen:GetAttribute("ThemeBare") == true then
			v195.BackgroundColor3 = Color3.fromRGB(6, 8, 12)
			v197.Color = ColorSequence.new(Color3.fromRGB(255, 255, 255), Color3.fromRGB(255, 255, 255))
			v197.Rotation = 0
			v197.Transparency = NumberSequence.new({
				NumberSequenceKeypoint.new(0, 1),
				NumberSequenceKeypoint.new(0.16, 0.05),
				NumberSequenceKeypoint.new(0.84, 0.05),
				NumberSequenceKeypoint.new(1, 1)
			})
			for _, v202 in v195:GetChildren() do
				if not v202:IsA("UIStroke") then
					continue
				end
				v202:Destroy()
			end
			p193.speedText = v_u_31(v195, "Speed", "0", 0.16, 0.06, 0.5, 0.7, Color3.fromRGB(240, 244, 250), Enum.Font.GothamBlack)
			p193.unit = v_u_31(v195, "Unit", "km/h", 0.3, 0.76, 0.22, 0.16, Color3.fromRGB(150, 160, 175), Enum.Font.GothamMedium)
			local v203 = v_u_19(v195, "GearBox", 0.7, 0.2, 0.16, 0.56, Color3.fromRGB(0, 0, 0), 0.5)
			local v204 = Instance.new("UICorner")
			v204.CornerRadius = UDim.new(0.2, 0)
			v204.Parent = v203
			local v205 = p192 * 0.02
			local v206 = math.max(1, v205)
			local v207 = Instance.new("UIStroke")
			v207.Color = v_u_194
			v207.Thickness = v206
			v207.Transparency = 0
			v207.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
			v207.Parent = v203
			p193.gearLabel = v_u_31(v203, "Gear", "N", 0.1, 0.08, 0.8, 0.84, v_u_194, Enum.Font.GothamBlack)
		else
			local v208 = p192 < 95
			local v_u_209 = Color3.fromRGB(235, 240, 248)
			local v210 = Color3.fromRGB(140, 150, 165)
			local v211 = v208 and 0.06 or 0.2
			if not v208 then
				p193.clock = v_u_31(v195, "Clock", "", 0.05, 0.04, 0.22, 0.12, v_u_209, Enum.Font.GothamMedium, Enum.TextXAlignment.Left)
				p193.temp = v_u_31(v195, "Temp", "31\194\176C", 0.74, 0.04, 0.21, 0.12, v210, Enum.Font.GothamMedium, Enum.TextXAlignment.Right)
				p193.arrowL = v_u_117(v195, 0.36, 0.03, 0.08, 0.14, Color3.fromRGB(70, 230, 110), false)
				p193.arrowR = v_u_117(v195, 0.56, 0.03, 0.08, 0.14, Color3.fromRGB(70, 230, 110), true)
			end
			p193.revBars = v_u_99(v195, 24, 0.05, v211, 0.9, v208 and 0.13 or 0.09, function(p212, p213)
				-- upvalues: (copy) v_u_194, (copy) v_u_209
				if p213 * 0.85 < p212 then
					return v_u_194
				elseif p213 * 0.7 < p212 then
					return Color3.fromRGB(255, 175, 40)
				else
					return v_u_209
				end
			end, false, 0.3)
			p193.speedText = v_u_31(v195, "Speed", "0", 0.12, v211 + 0.13, 0.58, v208 and 0.66 or 0.48, v_u_209, Enum.Font.GothamBlack)
			p193.unit = v_u_31(v195, "Unit", "km/h", 0.3, v211 + (v208 and 0.78 or 0.6), 0.22, v208 and 0.12 or 0.09, v210, Enum.Font.GothamMedium)
			local v214 = v_u_19(v195, "GearBox", 0.75, v211 + 0.14, 0.19, v208 and 0.6 or 0.42, Color3.fromRGB(0, 0, 0), 0.4)
			local v215 = Instance.new("UICorner")
			v215.CornerRadius = UDim.new(0.18, 0)
			v215.Parent = v214
			local v216 = p192 * 0.018
			local v217 = math.max(1, v216)
			local v218 = Instance.new("UIStroke")
			v218.Color = v_u_194
			v218.Thickness = v217
			v218.Transparency = 0
			v218.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
			v218.Parent = v214
			p193.gearLabel = v_u_31(v214, "Gear", "N", 0.1, 0.08, 0.8, 0.84, v_u_194, Enum.Font.GothamBlack)
			if not v208 then
				v_u_31(v195, "E", "E", 0.05, 0.86, 0.04, 0.09, v210)
				p193.fuel = v_u_99(v195, 8, 0.09, 0.875, 0.22, 0.07, function()
					-- upvalues: (copy) v_u_209
					return v_u_209
				end, false, 0.3)
				v_u_31(v195, "F", "F", 0.31, 0.86, 0.04, 0.09, v210)
				p193.mode = v_u_31(v195, "Mode", "SPORT", 0.4, 0.85, 0.2, 0.1, v_u_194, Enum.Font.GothamBlack)
				p193.odo = v_u_31(v195, "Odo", "ODO 0", 0.62, 0.86, 0.33, 0.09, v210, Enum.Font.GothamMedium, Enum.TextXAlignment.Right)
			end
		end
	end,
	["race"] = function(p219, p220, p221, p222) -- name: buildRace
		-- upvalues: (copy) v_u_19, (copy) v_u_82, (copy) v_u_31
		local v223 = p222.screen:GetAttribute("ThemeAccent") or Color3.fromRGB(80, 255, 140)
		local v224 = v_u_19(p219, "Glass", 0, 0, 1, 1, Color3.fromRGB(5, 6, 8), 0)
		p222.glass = v224
		local v225 = Instance.new("UICorner")
		v225.CornerRadius = UDim.new(0.1, 0)
		v225.Parent = v224
		local v226 = Color3.fromRGB(70, 74, 80)
		local v227 = p221 * 0.025
		local v228 = math.max(1, v227)
		local v229 = Instance.new("UIStroke")
		v229.Color = v226
		v229.Thickness = v228
		v229.Transparency = 0
		v229.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
		v229.Parent = v224
		p222.leds = {}
		local v230 = {}
		for v231 = 1, 10 do
			local v232
			if v231 <= 4 then
				v232 = Color3.fromRGB(60, 255, 90)
			elseif v231 <= 7 then
				v232 = Color3.fromRGB(255, 210, 40)
			else
				v232 = Color3.fromRGB(255, 40, 40)
			end
			v230[v231] = v232
		end
		local v233 = 0.13 * p221 / p220
		local v234 = math.min(0.07, v233)
		for v235 = 1, 10 do
			local v236 = v_u_19(v224, "Led", (v235 - 1) * 0.09333333333333332 + 0.08 - v234 / 2, 0.06, v234, v234 * p220 / p221, v230[v235], 0.85)
			local v237 = Instance.new("UICorner")
			v237.CornerRadius = UDim.new(0.5, 0)
			v237.Parent = v236
			local v238 = p222.leds
			table.insert(v238, v236)
		end
		p222.digits = v_u_82(v224, 3, 0.04, 0.28, 0.58, 0.52, Color3.fromRGB(240, 245, 250), 0.93)
		v_u_31(v224, "GearTag", "GEAR", 0.67, 0.26, 0.27, 0.1, Color3.fromRGB(150, 155, 160))
		p222.gearLabel = v_u_31(v224, "Gear", "N", 0.67, 0.36, 0.27, 0.44, v223, Enum.Font.GothamBlack)
		p222.timer = v_u_31(v224, "Timer", "00:00.0", 0.05, 0.84, 0.42, 0.12, Color3.fromRGB(170, 175, 180), Enum.Font.Code, Enum.TextXAlignment.Left)
		p222.rpmText = v_u_31(v224, "Rpm", "0 rpm", 0.5, 0.84, 0.45, 0.12, v223, Enum.Font.Code, Enum.TextXAlignment.Right)
	end,
	["dial"] = function(p239, p240, p241, p242) -- name: buildDial
		-- upvalues: (copy) v_u_82, (copy) v_u_19
		local v243 = p242.screen
		local v244 = v243:GetAttribute("DialMax") or 140
		local v245 = v243:GetAttribute("DialFrom") or -120
		local v246 = v243:GetAttribute("DialTo") or 120
		local v247 = v243:GetAttribute("DialStep") or 20
		local v248 = v243:GetAttribute("DialMinor") or 2
		local v249 = v243:GetAttribute("DialRed")
		local v250 = v243:GetAttribute("DialEvery") or 1
		local v251 = v243:GetAttribute("DialCy") or 0.5
		local v252 = (v243:GetAttribute("DialR") or 0.5) * p240
		local v253 = 0.5 * p240
		local v254 = v251 * p241
		local v255 = v243:GetAttribute("DialFace") or Color3.fromRGB(14, 15, 17)
		local v256 = v243:GetAttribute("DialNeedle") or Color3.fromRGB(240, 50, 40)
		local v257 = Color3.fromRGB(238, 238, 232)
		p239.ClipsDescendants = true
		local v258 = v243:GetAttribute("DialMarks") or ""
		local v259 = {}
		for v260, v261 in tostring(v258):gmatch("([%d%.%-]+):([%d%.%-]+)") do
			local v262 = { tonumber(v260), (tonumber(v261)) }
			table.insert(v259, v262)
		end
		local v263 = {
			["max"] = v244,
			["from"] = v245,
			["to"] = v246
		}
		if #v259 < 2 then
			v259 = nil
		end
		v263.marks = v259
		p242.dial = v263
		local v264 = v243:GetAttribute("DialBare") == true
		if not v264 then
			local v265 = Instance.new("Frame")
			v265.Name = "Disc"
			v265.AnchorPoint = Vector2.new(0.5, 0.5)
			v265.Position = UDim2.fromOffset(v253, v254)
			v265.Size = UDim2.fromOffset(2 * v252, 2 * v252)
			v265.BackgroundColor3 = v255
			v265.BorderSizePixel = 0
			v265.Parent = p239
			local v266 = Instance.new("UICorner")
			v266.CornerRadius = UDim.new(0.5, 0)
			v266.Parent = v265
			local v267 = Color3.fromRGB(150, 152, 158)
			local v268 = v252 * 0.05
			local v269 = math.max(1, v268)
			local v270 = Instance.new("UIStroke")
			v270.Color = v267
			v270.Thickness = v269
			v270.Transparency = 0
			v270.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
			v270.Parent = v265
			local v271 = Instance.new("UIGradient")
			v271.Color = ColorSequence.new(Color3.fromRGB(255, 255, 255), Color3.fromRGB(150, 150, 150))
			v271.Rotation = 90
			v271.Parent = v265
			local v272 = v244 / v247 * v248 + 0.5
			for v273 = 0, math.floor(v272) do
				local v274 = v273 * v247 / v248
				local v275 = v273 % v248 == 0
				local v276 = v245 + (v246 - v245) * v274 / v244
				local v277 = math.rad(v276)
				local v278
				if v275 then
					v278 = 0.14 * v252
				else
					v278 = 0.07 * v252
				end
				local v279 = Instance.new("Frame")
				v279.Name = "Tick"
				v279.AnchorPoint = Vector2.new(0.5, 0.5)
				local v280 = v252 * 0.9 - v278 / 2
				local v281 = (v275 and 0.04 or 0.022) * v252
				local v282 = math.max(1, v281)
				local v283 = UDim2.fromOffset(v253 + math.sin(v277) * v280, v254 - math.cos(v277) * v280)
				local v284 = UDim2.fromOffset(v282, v278)
				v279.Position = v283
				v279.Size = v284
				v279.Rotation = math.deg(v277)
				local v285
				if v249 and v249 <= v274 then
					v285 = Color3.fromRGB(235, 40, 30)
				else
					v285 = v257
				end
				v279.BackgroundColor3 = v285
				v279.BorderSizePixel = 0
				v279.Parent = p239
				if not v275 then
					continue
				end
				local v286 = v274 / v247 + 0.5
				if math.floor(v286) % v250 ~= 0 then
					continue
				end
				local v287 = Instance.new("TextLabel")
				v287.Name = "Num"
				v287.AnchorPoint = Vector2.new(0.5, 0.5)
				local v288 = v252 * 0.62
				local v289 = 0.3 * v252
				local v290 = 0.17 * v252
				local v291 = UDim2.fromOffset(v253 + math.sin(v277) * v288, v254 - math.cos(v277) * v288)
				local v292 = UDim2.fromOffset(v289, v290)
				v287.Position = v291
				v287.Size = v292
				v287.BackgroundTransparency = 1
				v287.Font = Enum.Font.GothamBold
				v287.TextScaled = true
				local v293
				if v249 and v249 <= v274 then
					v293 = Color3.fromRGB(235, 40, 30)
				else
					v293 = v257
				end
				v287.TextColor3 = v293
				local v294 = v274 + 0.5
				local v295 = math.floor(v294)
				v287.Text = tostring(v295)
				v287.Parent = p239
			end
			local v296 = Instance.new("TextLabel")
			v296.Name = "Unit"
			v296.AnchorPoint = Vector2.new(0.5, 0.5)
			v296.Position = UDim2.fromOffset(v253, v254 - 0.3 * v252)
			v296.Size = UDim2.fromOffset(0.6 * v252, 0.12 * v252)
			v296.BackgroundTransparency = 1
			v296.Font = Enum.Font.GothamMedium
			v296.TextScaled = true
			v296.TextColor3 = Color3.fromRGB(190, 190, 185)
			v296.Text = v243:GetAttribute("DialLabel") or "km/h"
			v296.Parent = p239
		end
		if v243:GetAttribute("DialLcd") then
			local v297 = Instance.new("Frame")
			v297.Name = "OdoWindow"
			v297.AnchorPoint = Vector2.new(0.5, 0)
			v297.Position = UDim2.fromOffset(v253, v254 + 0.17 * v252)
			v297.Size = UDim2.fromOffset(0.86 * v252, 0.22 * v252)
			v297.BackgroundColor3 = Color3.fromRGB(2, 3, 4)
			v297.BorderSizePixel = 0
			v297.Parent = p239
			local v298 = Instance.new("UICorner")
			v298.CornerRadius = UDim.new(0.2, 0)
			v298.Parent = v297
			local v299 = Color3.fromRGB(90, 92, 96)
			local v300 = v252 * 0.015
			local v301 = math.max(1, v300)
			local v302 = Instance.new("UIStroke")
			v302.Color = v299
			v302.Thickness = v301
			v302.Transparency = 0
			v302.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
			v302.Parent = v297
			p242.digits = v_u_82(v297, 6, 0.05, 0.16, 0.9, 0.68, Color3.fromRGB(230, 236, 240), 0.94)
			p242.odoDigits = true
		end
		local v303 = Instance.new("Frame")
		v303.Name = "Pivot"
		v303.AnchorPoint = Vector2.new(0.5, 0.5)
		v303.Position = UDim2.fromOffset(v253, v254)
		v303.Size = UDim2.fromOffset(2 * v252, 2 * v252)
		v303.BackgroundTransparency = 1
		v303.ZIndex = 3
		v303.Parent = p239
		local v304 = v_u_19(v303, "Needle", 0.5, 0.58, 0.02, 0.51, v256, 0)
		v304.AnchorPoint = Vector2.new(0.5, 1)
		v304.ZIndex = 3
		local v305 = Instance.new("UICorner")
		v305.CornerRadius = UDim.new(0.5, 0)
		v305.Parent = v304
		local v306 = Instance.new("Frame")
		v306.Name = "Cap"
		v306.AnchorPoint = Vector2.new(0.5, 0.5)
		v306.Position = UDim2.fromOffset(v253, v254)
		local v307
		if v264 then
			v307 = UDim2.fromOffset(0.14 * v252, 0.14 * v252)
		else
			v307 = UDim2.fromOffset(0.24 * v252, 0.24 * v252)
		end
		v306.Size = v307
		v306.BackgroundColor3 = Color3.fromRGB(25, 25, 28)
		v306.BorderSizePixel = 0
		v306.ZIndex = 4
		v306.Parent = p239
		local v308 = Instance.new("UICorner")
		v308.CornerRadius = UDim.new(0.5, 0)
		v308.Parent = v306
		local v309 = Color3.fromRGB(120, 120, 125)
		local v310 = v252 * 0.02
		local v311 = math.max(1, v310)
		local v312 = Instance.new("UIStroke")
		v312.Color = v309
		v312.Thickness = v311
		v312.Transparency = 0
		v312.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
		v312.Parent = v306
		p242.pivot = v303
		p242.dialValue = 0
		if p242.dial.marks then
			v245 = p242.dial.marks[1][2]
		end
		v303.Rotation = v245
	end,
	["pcxtft"] = function(p313, p314, p315, p316) -- name: buildPcxTft
		-- upvalues: (copy) v_u_19, (copy) v_u_117, (copy) v_u_31, (copy) v_u_99
		local v_u_317 = Color3.fromRGB(236, 242, 250)
		local v318 = Color3.fromRGB(128, 140, 158)
		local v319 = Color3.fromRGB(70, 230, 110)
		local v_u_320 = Color3.fromRGB(255, 170, 40)
		local v321 = Color3.fromRGB(255, 60, 50)
		local v322 = v_u_19(p313, "Glass", 0, 0, 1, 1, Color3.fromRGB(255, 255, 255), 0)
		p316.glass = v322
		local v323 = Instance.new("UICorner")
		v323.CornerRadius = UDim.new(0.06, 0)
		v323.Parent = v322
		local v324 = Instance.new("UIGradient")
		v324.Color = ColorSequence.new(Color3.fromRGB(22, 27, 38), Color3.fromRGB(5, 6, 9))
		v324.Rotation = 90
		v324.Parent = v322
		local v325 = Color3.fromRGB(0, 0, 0)
		local v326 = p315 * 0.012
		local v327 = math.max(1, v326)
		local v328 = Instance.new("UIStroke")
		v328.Color = v325
		v328.Thickness = v327
		v328.Transparency = 0.2
		v328.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
		v328.Parent = v322
		p316.statics = {}
		p316.arrowL = v_u_117(v322, 0.015, 0.03, 0.065, 0.13, v319, false)
		p316.arrowR = v_u_117(v322, 0.92, 0.03, 0.065, 0.13, v319, true)
		p316.clock = v_u_31(v322, "Clock", "", 0.09, 0.04, 0.15, 0.1, v_u_317, Enum.Font.GothamMedium, Enum.TextXAlignment.Left)
		p316.eco = v_u_31(v322, "Eco", "ECO", 0.76, 0.04, 0.13, 0.1, v319, Enum.Font.GothamBlack, Enum.TextXAlignment.Right)
		local v329 = 0.47 * p314
		local v330 = 0.86 * p315
		local v331 = 0.66 * p315
		p316.revBars = {}
		local v332 = 6.283185307179586 * v331 * 192 / 360 / 34 * 0.62
		for v333 = 1, 34 do
			local v334 = (v333 - 0.5) * 192 / 34 + -96
			local v335 = math.rad(v334)
			local v336 = v333 / 34
			local v337
			if v336 > 0.85 then
				v337 = v321
			elseif v336 > 0.72 then
				v337 = v_u_320
			else
				v337 = v_u_317
			end
			local v338 = v_u_19(v322, "Rev", (v329 + math.sin(v335) * v331) / p314, (v330 - math.cos(v335) * v331) / p315, v332 / p314, 0.085, v337, 0.86)
			v338.AnchorPoint = Vector2.new(0.5, 0.5)
			v338.Rotation = v334
			local v339 = Instance.new("UICorner")
			v339.CornerRadius = UDim.new(0.3, 0)
			v339.Parent = v338
			local v340 = p316.revBars
			table.insert(v340, v338)
		end
		for v341 = 0, 10, 2 do
			local v342 = v341 * 192 / 10 + -96
			local v343 = math.rad(v342)
			local v344 = v_u_31
			local v345 = "Num" .. v341
			local v346 = tostring(v341)
			local v347 = 0
			local v348 = 0
			local v349 = 0.05
			local v350 = 0.09
			local v351
			if v341 >= 9 then
				v351 = v321
			else
				v351 = v318
			end
			local v352 = v344(v322, v345, v346, v347, v348, v349, v350, v351, Enum.Font.GothamBold)
			local v353 = p316.statics
			table.insert(v353, v352)
			v352.AnchorPoint = Vector2.new(0.5, 0.5)
			v352.Position = UDim2.fromScale((v329 + math.sin(v343) * v331 * 0.8) / p314, (v330 - math.cos(v343) * v331 * 0.8) / p315)
		end
		local v354 = v_u_31(v322, "RpmTag", "x1000 r/min", 0.4, 0.87, 0.14, 0.06, v318, Enum.Font.GothamMedium)
		local v355 = p316.statics
		table.insert(v355, v354)
		p316.speedText = v_u_31(v322, "Speed", "0", 0.3, 0.41, 0.34, 0.36, v_u_317, Enum.Font.GothamBlack)
		p316.unit = v_u_31(v322, "Unit", "km/h", 0.42, 0.78, 0.1, 0.08, v318, Enum.Font.GothamMedium)
		local v356 = v_u_31(v322, "F", "F", 0.02, 0.2, 0.04, 0.08, v318, Enum.Font.GothamBold)
		local v357 = p316.statics
		table.insert(v357, v356)
		p316.fuel = v_u_99(v322, 8, 0.03, 0.3, 0.05, 0.5, function(p358)
			-- upvalues: (copy) v_u_320, (copy) v_u_317
			if p358 <= 2 then
				return v_u_320
			else
				return v_u_317
			end
		end, true, 0.32)
		local v359 = v_u_31(v322, "E", "E", 0.02, 0.82, 0.04, 0.08, v318, Enum.Font.GothamBold)
		local v360 = p316.statics
		table.insert(v360, v359)
		local v361 = v_u_19(v322, "Pump", 0.09, 0.5, 0.035, 0.16, nil, 1)
		local v362 = v_u_19(v361, "Body", 0, 0.15, 0.62, 0.85, v318, 0)
		local v363 = Instance.new("UICorner")
		v363.CornerRadius = UDim.new(0.15, 0)
		v363.Parent = v362
		v_u_19(v362, "Window", 0.18, 0.12, 0.64, 0.3, Color3.fromRGB(10, 12, 16), 0)
		local v364 = v_u_19(v361, "Hose", 0.66, 0.15, 0.18, 0.55, v318, 0)
		local v365 = Instance.new("UICorner")
		v365.CornerRadius = UDim.new(0.4, 0)
		v365.Parent = v364
		p316.pump = v361
		p316.pumpParts = { v362, v364 }
		local v366 = v_u_31(v322, "TripTag", "TRIP", 0.8, 0.3, 0.16, 0.07, v318, Enum.Font.GothamBold, Enum.TextXAlignment.Right)
		local v367 = p316.statics
		table.insert(v367, v366)
		p316.trip = v_u_31(v322, "Trip", "0.0", 0.78, 0.38, 0.18, 0.12, v_u_317, Enum.Font.GothamMedium, Enum.TextXAlignment.Right)
		local v368 = v_u_31(v322, "TotalTag", "TOTAL", 0.8, 0.56, 0.16, 0.07, v318, Enum.Font.GothamBold, Enum.TextXAlignment.Right)
		local v369 = p316.statics
		table.insert(v369, v368)
		p316.odo = v_u_31(v322, "Odo", "0 km", 0.72, 0.64, 0.24, 0.12, v_u_317, Enum.Font.GothamMedium, Enum.TextXAlignment.Right)
	end,
	["pcx21"] = function(p370, p371, p372, p373) -- name: buildPcx21
		-- upvalues: (copy) v_u_168, (copy) v_u_19, (copy) v_u_186, (copy) v_u_31, (copy) v_u_82, (copy) v_u_99
		local v_u_374 = Color3.fromRGB(236, 244, 255)
		local v375 = v_u_168.lcd
		local v376 = v_u_19(p370, "Lcd", v375[1], v375[2], v375[3] - v375[1], v375[4] - v375[2], Color3.fromRGB(255, 255, 255), 0)
		local v377 = v_u_19(v376, "Inner", 0, 0, 1, v_u_168.inner, nil, 1)
		local v378 = Instance.new("UICorner")
		v378.CornerRadius = UDim.new(0.06, 0)
		v378.Parent = v376
		local v379 = Instance.new("UIGradient")
		v379.Color = ColorSequence.new(Color3.fromRGB(86, 140, 235), Color3.fromRGB(28, 56, 140))
		v379.Rotation = 90
		v379.Parent = v376
		p373.lcdGlass = v376
		p373.ink = v_u_374
		p373.stripes = {
			["L"] = {},
			["R"] = {}
		}
		for v380, v381 in {
			["L"] = v_u_168.stripeL,
			["R"] = v_u_168.stripeR
		} do
			for _, v382 in v381 do
				local v383 = p373.stripes[v380]
				local v384 = v_u_186(p370, p371, p372, v382)
				table.insert(v383, v384)
			end
		end
		p373.statics = {}
		p373.clock = v_u_31(v377, "Clock", "", 0.04, 0.04, 0.22, 0.17, v_u_374, Enum.Font.Code, Enum.TextXAlignment.Left)
		local v385 = v_u_31(v377, "Oil", "OIL CHANGE", 0.04, 0.24, 0.2, 0.08, v_u_374, Enum.Font.GothamBold, Enum.TextXAlignment.Left)
		local v386 = p373.statics
		table.insert(v386, v385)
		v385.TextTransparency = 0.82
		p373.digits = v_u_82(v377, 3, 0.34, 0.05, 0.42, 0.5, v_u_374, 0.9)
		p373.unit = v_u_31(v377, "Unit", "km/h", 0.77, 0.36, 0.17, 0.16, v_u_374, Enum.Font.GothamBold, Enum.TextXAlignment.Left)
		local v387 = v_u_19(v377, "Pump", 0.03, 0.59, 0.035, 0.15, nil, 1)
		local v388 = v_u_19(v387, "Body", 0, 0.15, 0.62, 0.85, v_u_374, 0)
		local v389 = Instance.new("UICorner")
		v389.CornerRadius = UDim.new(0.15, 0)
		v389.Parent = v388
		v_u_19(v388, "Window", 0.18, 0.12, 0.64, 0.3, Color3.fromRGB(28, 56, 140), 0)
		local v390 = v_u_19(v387, "Hose", 0.66, 0.15, 0.18, 0.55, v_u_374, 0)
		local v391 = Instance.new("UICorner")
		v391.CornerRadius = UDim.new(0.4, 0)
		v391.Parent = v390
		p373.pump = v387
		p373.pumpParts = { v388, v390 }
		p373.fuel = v_u_99(v377, 14, 0.08, 0.62, 0.84, 0.09, function()
			-- upvalues: (copy) v_u_374
			return v_u_374
		end, false, 0.22)
		local v392 = v_u_31(v377, "F", "F", 0.93, 0.59, 0.05, 0.14, v_u_374, Enum.Font.GothamBold)
		local v393 = p373.statics
		table.insert(v393, v392)
		local v394 = v_u_31(v377, "TripTag", "TRIP", 0.04, 0.8, 0.1, 0.1, v_u_374, Enum.Font.GothamBold, Enum.TextXAlignment.Left)
		local v395 = p373.statics
		table.insert(v395, v394)
		p373.trip = v_u_31(v377, "Trip", "0.0", 0.14, 0.76, 0.28, 0.17, v_u_374, Enum.Font.Code, Enum.TextXAlignment.Left)
		local v396 = v_u_31(v377, "TotalTag", "TOTAL", 0.47, 0.8, 0.12, 0.1, v_u_374, Enum.Font.GothamBold, Enum.TextXAlignment.Left)
		local v397 = p373.statics
		table.insert(v397, v396)
		p373.odo = v_u_31(v377, "Odo", "0 km", 0.6, 0.76, 0.36, 0.17, v_u_374, Enum.Font.Code, Enum.TextXAlignment.Right)
	end,
	["forza"] = function(p398, _, _, p399) -- name: buildForza
		-- upvalues: (copy) v_u_187, (copy) v_u_31, (copy) v_u_19, (copy) v_u_82, (copy) v_u_99, (copy) v_u_188, (copy) v_u_190
		local v400 = v_u_187.x1 - v_u_187.x0
		local v401 = v_u_187.y0 - v_u_187.y1
		local v_u_402 = Color3.fromRGB(214, 228, 255)
		local v403 = {
			["lamps"] = {},
			["statics"] = {},
			["turn"] = {}
		}
		p399.fz = v403
		local v404 = v_u_187.lcd
		local v405, v406, v407, v408 = table.unpack(v404)
		local v409 = v_u_19(p398, "Lcd", (v405 - v_u_187.x0) / v400, (v_u_187.y0 - v406) / v401, v407 / v400, v408 / v401, Color3.fromRGB(4, 5, 8), 0)
		local v410 = Instance.new("UICorner")
		v410.CornerRadius = UDim.new(0.05, 0)
		v410.Parent = v409
		local v411 = v_u_19(v409, "Glass", 0.012, 0.02, 0.976, 0.96, Color3.fromRGB(255, 255, 255), 0)
		local v412 = Instance.new("UICorner")
		v412.CornerRadius = UDim.new(0.04, 0)
		v412.Parent = v411
		local v413 = Instance.new("UIGradient")
		v413.Color = ColorSequence.new(Color3.fromRGB(46, 92, 228), Color3.fromRGB(14, 30, 128))
		v413.Rotation = 90
		v413.Parent = v411
		v403.glass = v411
		local v414 = v_u_19(v411, "Content", 0, 0, 1, 1, nil, 1)
		v403.content = v414
		local v415 = v_u_19(v414, "Slash", 0.3, 0, 0.007, 0.2, v_u_402, 0.25)
		local v416 = v403.statics
		table.insert(v416, v415)
		v415.Rotation = 32
		v403.hours = v_u_82(v414, 2, 0.39, 0.045, 0.13, 0.14, v_u_402, 0.9)
		v403.mins = v_u_82(v414, 2, 0.535, 0.045, 0.13, 0.14, v_u_402, 0.9)
		local v417 = v_u_19(v414, "Colon", 0.523, 0.075, 0.01, 0.022, v_u_402, 0)
		local v418 = v403.statics
		table.insert(v418, v417)
		local v419 = v_u_19(v414, "Colon", 0.523, 0.13, 0.01, 0.022, v_u_402, 0)
		local v420 = v403.statics
		table.insert(v420, v419)
		local v421 = Enum.TextXAlignment.Center
		local v422 = v_u_31(v414, "Tag", "E", 0.02, 0.205, 0.04, 0.08, v_u_402, Enum.Font.GothamBold, v421 or Enum.TextXAlignment.Left)
		local v423 = v403.statics
		table.insert(v423, v422)
		v403.fuel = v_u_99(v414, 8, 0.065, 0.215, 0.36, 0.065, function()
			-- upvalues: (copy) v_u_402
			return v_u_402
		end, false, 0.22)
		local v424 = Enum.TextXAlignment.Center
		local v425 = v_u_31(v414, "Tag", "F", 0.43, 0.205, 0.04, 0.08, v_u_402, Enum.Font.GothamBold, v424 or Enum.TextXAlignment.Left)
		local v426 = v403.statics
		table.insert(v426, v425)
		local v427 = v_u_19(v414, "Pump", 0.245, 0.12, 0.028, 0.08, nil, 1)
		local v428 = v403.statics
		table.insert(v428, v427)
		local v429 = v_u_19(v427, "Body", 0, 0.1, 0.62, 0.9, v_u_402, 0)
		local v430 = Instance.new("UICorner")
		v430.CornerRadius = UDim.new(0.15, 0)
		v430.Parent = v429
		v_u_19(v429, "Window", 0.18, 0.12, 0.64, 0.3, Color3.fromRGB(20, 40, 150), 0)
		local v431 = v_u_19(v427, "Hose", 0.68, 0.15, 0.2, 0.55, v_u_402, 0)
		local v432 = Instance.new("UICorner")
		v432.CornerRadius = UDim.new(0.4, 0)
		v432.Parent = v431
		v403.pump = v427
		local v433 = v_u_19(v414, "TCBox", 0.5, 0.205, 0.04, 0.08, nil, 1)
		local v434 = v403.statics
		table.insert(v434, v433)
		local v435 = Instance.new("UIStroke")
		v435.Color = v_u_402
		v435.Thickness = 1
		v435.Transparency = 0
		v435.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
		v435.Parent = v433
		v_u_31(v433, "C", "C", 0.1, 0.05, 0.8, 0.9, v_u_402, Enum.Font.GothamBold)
		local v436 = v_u_19(v414, "Rule", 0.56, 0.24, 0.4, 0.008, v_u_402, 0)
		local v437 = v403.statics
		table.insert(v437, v436)
		for _, v438 in { 0.315, 0.575, 0.805 } do
			local v439 = v_u_19(v414, "Rule", 0.1, v438, 0.88, 0.006, v_u_402, 0.15)
			local v440 = v403.statics
			table.insert(v440, v439)
		end
		local v441 = v_u_31(v414, "Tag", "TRIP A", 0.12, 0.34, 0.16, 0.065, v_u_402, Enum.Font.GothamBold, Enum.TextXAlignment.Left)
		local v442 = v403.statics
		table.insert(v442, v441)
		v403.trip = v_u_82(v414, 4, 0.19, 0.41, 0.22, 0.13, v_u_402, 0.9)
		local v443 = v_u_19(v414, "Dot", 0.349, 0.525, 0.008, 0.016, v_u_402, 0)
		local v444 = v403.statics
		table.insert(v444, v443)
		v403.tripDot = v443
		local v445 = v_u_31(v414, "Tag", "km", 0.415, 0.49, 0.06, 0.055, v_u_402, Enum.Font.GothamBold, Enum.TextXAlignment.Left)
		local v446 = v403.statics
		table.insert(v446, v445)
		local v447 = v_u_31(v414, "Tag", "ODO", 0.5, 0.34, 0.1, 0.065, v_u_402, Enum.Font.GothamBold, Enum.TextXAlignment.Left)
		local v448 = v403.statics
		table.insert(v448, v447)
		v403.odo = v_u_82(v414, 6, 0.55, 0.41, 0.33, 0.13, v_u_402, 0.9)
		local v449 = v_u_31(v414, "Tag", "km", 0.885, 0.49, 0.06, 0.055, v_u_402, Enum.Font.GothamBold, Enum.TextXAlignment.Left)
		local v450 = v403.statics
		table.insert(v450, v449)
		local v451 = v_u_31(v414, "Tag", "RANGE", 0.4, 0.595, 0.14, 0.06, v_u_402, Enum.Font.GothamBold, Enum.TextXAlignment.Left)
		local v452 = v403.statics
		table.insert(v452, v451)
		v403.range = v_u_82(v414, 3, 0.44, 0.655, 0.17, 0.125, v_u_402, 0.9)
		local v453 = v_u_31(v414, "Tag", "km", 0.62, 0.73, 0.06, 0.055, v_u_402, Enum.Font.GothamBold, Enum.TextXAlignment.Left)
		local v454 = v403.statics
		table.insert(v454, v453)
		local v455 = v_u_31(v414, "Tag", "AIR TEMP.", 0.15, 0.835, 0.2, 0.06, v_u_402, Enum.Font.GothamBold, Enum.TextXAlignment.Left)
		local v456 = v403.statics
		table.insert(v456, v455)
		v403.temp = v_u_82(v414, 2, 0.355, 0.83, 0.09, 0.12, v_u_402, 0.9)
		local v457 = v_u_31(v414, "Tag", "\194\176C", 0.45, 0.87, 0.05, 0.06, v_u_402, Enum.Font.GothamBold, Enum.TextXAlignment.Left)
		local v458 = v403.statics
		table.insert(v458, v457)
		local v459 = v_u_19(v414, "Battery", 0.53, 0.865, 0.042, 0.065, nil, 1)
		local v460 = v403.statics
		table.insert(v460, v459)
		local v461 = Instance.new("UIStroke")
		v461.Color = v_u_402
		v461.Thickness = 1
		v461.Transparency = 0
		v461.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
		v461.Parent = v459
		v_u_19(v459, "Pole", 0.15, -0.25, 0.2, 0.2, v_u_402, 0)
		v_u_19(v459, "Pole", 0.65, -0.25, 0.2, 0.2, v_u_402, 0)
		v403.volt = v_u_82(v414, 3, 0.6, 0.83, 0.135, 0.12, v_u_402, 0.9)
		local v462 = v_u_19(v414, "Dot", 0.6849999999999999, 0.935, 0.008, 0.015, v_u_402, 0)
		local v463 = v403.statics
		table.insert(v463, v462)
		local v464 = v_u_31(v414, "Tag", "V", 0.745, 0.87, 0.04, 0.06, v_u_402, Enum.Font.GothamBold, Enum.TextXAlignment.Left)
		local v465 = v403.statics
		table.insert(v465, v464)
		local v466 = v_u_187.plate
		local v467, v468, v469, v470 = table.unpack(v466)
		local v471 = v_u_19(p398, "Plate", (v467 - v_u_187.x0) / v400, (v_u_187.y0 - v468) / v401, v469 / v400, v470 / v401, Color3.fromRGB(255, 255, 255), 0)
		local v472 = Instance.new("UICorner")
		v472.CornerRadius = UDim.new(0.3, 0)
		v472.Parent = v471
		local v473 = Instance.new("UIGradient")
		v473.Color = ColorSequence.new(Color3.fromRGB(58, 61, 68), Color3.fromRGB(12, 13, 15))
		v473.Rotation = 90
		v473.Parent = v471
		local v474 = Color3.fromRGB(90, 94, 102)
		local v475 = Instance.new("UIStroke")
		v475.Color = v474
		v475.Thickness = 1
		v475.Transparency = 0.3
		v475.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
		v475.Parent = v471
		v_u_31(v471, "Name", "TOURER", 0.12, 0.2, 0.76, 0.6, Color3.fromRGB(205, 208, 214), Enum.Font.GothamBlack).FontFace = Font.new("rbxasset://fonts/families/GothamSSm.json", Enum.FontWeight.Heavy, Enum.FontStyle.Italic)
		local v476 = v_u_187.lamps
		local v477, v478, v479, v480 = table.unpack(v476)
		local v481 = v_u_19(p398, "Lamps", (v477 - v_u_187.x0) / v400, (v_u_187.y0 - v478) / v401, v479 / v400, v480 / v401, Color3.fromRGB(6, 7, 9), 0)
		local v482 = Instance.new("UICorner")
		v482.CornerRadius = UDim.new(0.2, 0)
		v482.Parent = v481
		for _, v483 in v_u_187.lampList do
			local v484 = v483[1] - 0.022
			local v485 = v483[2] + 0.011
			local v486 = (v484 - v_u_187.x0) / v400
			local v487 = (v_u_187.y0 - v485) / v401
			local v488 = 0.044 / v400
			local v489 = 0.022 / v401
			local v490 = v_u_31(p398, "Lamp", v483[3], v486, v487, v488, v489, v_u_188[v483[4]], Enum.Font.GothamBlack)
			v490.ZIndex = 3
			local v491 = v403.lamps
			table.insert(v491, v490)
		end
		for v492, v493 in {
			["L"] = v_u_187.arrowL,
			["R"] = v_u_187.arrowR
		} do
			local v494 = v493[1] - 0.032
			local v495 = v493[2] + 0.032
			local v496 = (v494 - v_u_187.x0) / v400
			local v497 = (v_u_187.y0 - v495) / v401
			local v498 = 0.064 / v400
			local v499 = 0.064 / v401
			local v500 = v_u_19(p398, "Turn" .. v492, v496, v497, v498, v499, Color3.fromRGB(5, 6, 8), 0)
			local v501 = Instance.new("UICorner")
			v501.CornerRadius = UDim.new(0.5, 0)
			v501.Parent = v500
			local v502 = v_u_19(v500, "Glyph", 0.11, 0.11, 0.78, 0.78, nil, 1)
			local v503 = v492 == "R"
			local v504 = v_u_19(v502, "Stem", v503 and 0.2 or 0.42, 0.4, 0.38, 0.2, v_u_190, 0)
			local v505 = v_u_19(v502, "Head", v503 and 0.46 or 0.2, 0.33, 0.34, 0.34, v_u_190, 0)
			v505.Rotation = 45
			v403.turn[v492] = { v504, v505 }
		end
	end
}
local v_u_507 = setmetatable({}, {
	["__mode"] = "k"
})
local function v_u_514(p508) -- name: marks
	-- upvalues: (copy) v_u_507
	local v509 = v_u_507[p508]
	if not v509 then
		local v510 = p508:GetAttribute("Marks") or ""
		v509 = {}
		for v511, v512 in tostring(v510):gmatch("([%d%.%-]+):([%d%.%-]+)") do
			local v513 = { tonumber(v511), (tonumber(v512)) }
			table.insert(v509, v513)
		end
		v_u_507[p508] = v509
	end
	return v509
end
local function v_u_537(p515, p516) -- name: pointNeedle
	-- upvalues: (copy) v_u_514
	local v517 = p515:FindFirstChild("Display")
	if v517 then
		v517 = p515.Display:FindFirstChild("Needle")
	end
	if v517 then
		local v518 = nil
		local v519 = v_u_514(p515)
		if #v519 >= 2 then
			local v520 = v519[1][1]
			local v521 = v519[#v519][1]
			local v522 = math.clamp(p516, v520, v521)
			for v523 = 2, #v519 do
				if v522 > v519[v523][1] and v523 ~= #v519 then
					continue
				end
				local v524 = v519[v523 - 1]
				local v525 = v519[v523]
				v518 = v524[2] + (v525[2] - v524[2]) * (v522 - v524[1]) / (v525[1] - v524[1])
			end
		else
			local v526 = p515:GetAttribute("From") or -90
			local v527 = (p515:GetAttribute("To") or 90) - v526
			local v528 = p516 / (p515:GetAttribute("Max") or 140)
			v518 = v526 + v527 * math.clamp(v528, 0, 1)
		end
		local v529 = math.rad(v518)
		local v530 = p515.Size.X
		local v531 = math.sin(v529) * (p515:GetAttribute("RadiusX") or 0) / v530
		local v532 = -math.cos(v529) * (p515:GetAttribute("RadiusY") or 0) / v530
		local v533 = v531 * v531 + v532 * v532
		local v534 = math.sqrt(v533)
		v517.Position = UDim2.fromScale(0.5 + v531 / 2, 0.5 + v532 / 2)
		v517.Size = UDim2.new(0, 5, v534, 0)
		local v535 = -v532
		local v536 = math.atan2(v531, v535)
		v517.Rotation = math.deg(v536)
	end
end
local v_u_538 = 0
local function v_u_574(p539, p540) -- name: stateOf
	-- upvalues: (copy) v_u_6, (copy) v_u_4, (ref) v_u_538
	local v541 = v_u_6[p539]
	if not v541 then
		local v542 = p539:GetAttribute("VehicleId") or p539.Name
		local v543 = tostring(v542)
		local v544 = 7
		for v545 = 1, #v543 do
			v544 = (v544 * 31 + string.byte(v543, v545)) % 1000003
		end
		v541 = {
			["id"] = nil,
			["revs"] = 0,
			["trip"] = 0,
			["odoBase"] = nil,
			["fuelShare"] = nil,
			["onSince"] = nil,
			["topAt"] = -1000000000,
			["top"] = 100,
			["gears"] = nil,
			["isCar"] = nil,
			["lastSpeed"] = 0,
			["frame"] = -1,
			["id"] = v543,
			["odoBase"] = 3000 + v544 % 47000,
			["fuelShare"] = 0.6 + v544 % 5 / 10,
			["gears"] = v_u_4.gears(p539),
			["isCar"] = p539:FindFirstChild("SteeringWheel") ~= nil
		}
		v_u_6[p539] = v541
	end
	if v541.frame == v_u_538 then
		return v541
	end
	v541.frame = v_u_538
	local v546 = os.clock()
	local v547 = p539:FindFirstChild("Chassis")
	local v548 = p539:GetAttribute("EngineOn") == true
	local v549, v550
	if v547 and v547:IsA("BasePart") then
		local v551 = v547.AssemblyLinearVelocity
		local v552 = v551.X
		local v553 = v551.Z
		v549 = Vector3.new(v552, 0, v553).Magnitude
		if v549 > 1 then
			v550 = v551:Dot(v547.CFrame.LookVector) < 0
		else
			v550 = false
		end
		local v554 = v547.Position
		if v548 and v541.lastPos then
			local v555 = v554.X - v541.lastPos.X
			local v556 = v554.Z - v541.lastPos.Z
			local v557 = Vector3.new(v555, 0, v556).Magnitude
			if v557 < 60 then
				v541.trip = v541.trip + v557 * 0.00028000000000000003
			end
		end
		v541.lastPos = v554
	else
		v549 = 0
		v550 = false
	end
	if v548 and not v541.on then
		v541.onSince = v546
	elseif not v548 then
		v541.onSince = nil
	end
	v541.on = v548
	local v558 = v549 * 1.008 + 0.5
	v541.kmh = math.floor(v558)
	v541.back = v550
	local v559
	if v541.onSince then
		local v560 = (v546 - v541.onSince) / 1.1
		v559 = math.clamp(v560, 0, 1)
	else
		v559 = 1
	end
	v541.welcome = v559
	if v546 - v541.topAt > 2 then
		v541.topAt = v546
		local v561 = v_u_4.topSpeed
		local v562, v563 = pcall(v561, p539)
		if v562 and (typeof(v563) == "number" and v563 > 1) then
			v541.top = v563
		end
	end
	local v564 = p540 <= 0 and 0 or (v549 - v541.lastSpeed) / p540
	v541.lastSpeed = v549
	v541.accel = v564
	v541.gear = v_u_4.gear(p539)
	local v565
	if v548 then
		if v541.gears and v541.gear then
			v565 = v_u_4.revs(v549, v541.top, v541.gears, v541.gear)
		elseif v549 < 0.5 then
			v565 = 0.02
		else
			local v566 = 0.42 + v549 * 0.48 / v541.top + (v564 > 2 and 0.12 or 0)
			v565 = math.clamp(v566, 0, 0.97)
		end
	else
		v565 = 0
	end
	local v567 = v541.revs
	local v568 = v565 - v541.revs
	local v569 = 6 * p540
	v541.revs = v567 + v568 * math.min(1, v569)
	v541.indicator = p539:GetAttribute("Indicator")
	local v570 = p539:GetAttribute("Fuel")
	if typeof(v570) == "number" then
		local v571 = v570 / 100
		v541.fuelShare = math.clamp(v571, 0, 1)
		v541.fuelLow = v570 < 15
	end
	local v572 = p539:GetAttribute("OdoKm")
	local v573 = p539:GetAttribute("TripKm")
	if typeof(v572) ~= "number" then
		v572 = nil
	end
	v541.odoKm = v572
	if typeof(v573) ~= "number" then
		v573 = nil
	end
	v541.tripKm = v573
	return v541
end
local function v582(p575) -- name: add
	-- upvalues: (copy) v_u_5, (copy) v_u_9
	if p575:IsA("BasePart") and not v_u_5[p575] then
		local v576 = p575:WaitForChild("Display", 10)
		local v577 = v_u_9(p575)
		if v576 and v577 then
			if p575.Name == "DashNeedle" then
				v_u_5[p575] = {
					["model"] = nil,
					["needle"] = nil,
					["needleKmh"] = 0,
					["nextAt"] = 0,
					["model"] = v577,
					["needle"] = p575
				}
				return
			else
				local v578 = v576:WaitForChild("Back", 10)
				if v578 then
					local v579 = p575:FindFirstChild("Needle")
					local v580 = v_u_5
					local v581 = {
						["model"] = nil,
						["screen"] = nil,
						["display"] = nil,
						["back"] = nil,
						["speed"] = nil,
						["unit0"] = nil,
						["shape"] = nil,
						["needle"] = nil,
						["needleKmh"] = 0,
						["style"] = nil,
						["round"] = nil,
						["on"] = nil,
						["kmh"] = nil,
						["nextAt"] = 0,
						["model"] = v577,
						["screen"] = p575,
						["display"] = v576,
						["back"] = v578,
						["speed"] = v578:WaitForChild("Speed", 5),
						["unit0"] = v578:FindFirstChild("Unit"),
						["shape"] = v578:FindFirstChild("Shape")
					}
					if v579 then
						v579 = v579.Value
					end
					v581.needle = v579
					v581.style = p575:GetAttribute("Style")
					v581.round = p575:GetAttribute("Round") == true
					v580[p575] = v581
				end
			end
		else
			return
		end
	else
		return
	end
end
local function v_u_586(_, p583) -- name: gearText
	if not p583.isCar then
		if not p583.gear then
			return p583.kmh < 1 and "N" or "1"
		end
		local v584 = p583.gear
		return tostring(v584)
	end
	if not p583.gears then
		return p583.back and "R" or (p583.kmh < 1 and "P" or "D")
	end
	if p583.back then
		return "R"
	end
	if p583.kmh < 1 and not p583.gear then
		return "N"
	end
	local v585 = p583.gear or 1
	return tostring(v585)
end
local v_u_587 = {
	["tft"] = 7500,
	["race"] = 12000,
	["neg"] = 9000,
	["lcd"] = 9000,
	["dial"] = 9000
}
v1:GetInstanceAddedSignal("DashSpeedo"):Connect(v582)
v1:GetInstanceRemovedSignal("DashSpeedo"):Connect(function(p588)
	-- upvalues: (copy) v_u_5
	v_u_5[p588] = nil
end)
local v_u_589 = v_u_538
local function v_u_599(p590) -- name: build
	-- upvalues: (copy) v_u_574, (copy) v_u_506
	p590.built = true
	local v591 = p590.screen.Size.X * p590.display.PixelsPerStud
	local v592 = p590.screen.Size.Y * p590.display.PixelsPerStud
	if p590.display.SizingMode == Enum.SurfaceGuiSizingMode.FixedSize then
		v591 = p590.display.CanvasSize.X
		v592 = p590.display.CanvasSize.Y
	end
	local v593 = v_u_574(p590.model, 0)
	local v594
	if v593.gears == nil then
		v594 = false
	else
		v594 = not v593.isCar
	end
	p590.manual = v594
	local v595 = Instance.new("Frame")
	v595.Name = "Face"
	v595.Size = UDim2.fromScale(1, 1)
	v595.BackgroundTransparency = 1
	v595.ZIndex = 2
	v595.Parent = p590.display
	p590.face = v595
	if p590.speed then
		p590.speed.Visible = false
	end
	if p590.unit0 then
		p590.unit0.Visible = false
	end
	if p590.shape then
		p590.back.BackgroundTransparency = 1
	else
		p590.back.Visible = false
	end
	local v596 = v_u_506[p590.style]
	local v597, v598 = pcall(v596, v595, v591, v592, p590)
	if not v597 then
		warn("DashSpeedo: " .. tostring(v598))
		v595:Destroy()
		p590.face = nil
		p590.style = nil
		if p590.speed then
			p590.speed.Visible = true
		end
		if p590.unit0 then
			p590.unit0.Visible = true
		end
		p590.back.Visible = true
	end
end
local function v_u_726(p600, p601, p602) -- name: updateFace
	-- upvalues: (copy) v_u_69, (copy) v_u_105, (copy) v_u_189, (copy) v_u_190, (copy) v_u_170, (copy) v_u_169, (copy) v_u_586, (copy) v_u_123, (copy) v_u_587
	local v603 = p601.on
	local v604
	if v603 then
		v604 = p601.welcome < 0.7
	else
		v604 = v603
	end
	local v605
	if p601.welcome < 1 then
		local v606 = 3.141592653589793 * p601.welcome
		v605 = math.sin(v606)
	else
		v605 = 0
	end
	local v607 = p600.style
	local v608
	if v603 then
		if p601.indicator == "Left" or p601.indicator == "Hazard" then
			v608 = os.clock() * 1.6 % 1 < 0.5
		else
			v608 = false
		end
	else
		v608 = v603
	end
	local v609
	if v603 then
		if p601.indicator == "Right" or p601.indicator == "Hazard" then
			v609 = os.clock() * 1.6 % 1 < 0.5
		else
			v609 = false
		end
	else
		v609 = v603
	end
	if v607 == "dial" then
		local v610
		if p600.screen:GetAttribute("DialRole") == "revs" then
			v610 = not v603 and 0 or (1400 + p601.revs * 8600) / 1000
		else
			v610 = not v603 and 0 or p601.kmh
		end
		if p601.welcome < 1 and v603 then
			p600.dialValue = p600.dial.max * v605
		else
			local v611 = p600.dialValue
			local v612 = v610 - p600.dialValue
			local v613 = 8 * p602
			p600.dialValue = v611 + v612 * math.min(1, v613)
		end
		local v614 = p600.dial
		if v614.marks then
			local v615 = v614.marks
			local v616 = p600.dialValue
			local v617 = v615[1][1]
			local v618 = v615[#v615][1] * 1.02
			local v619 = math.clamp(v616, v617, v618)
			local v620 = v615[#v615][2]
			for v621 = 2, #v615 do
				if v619 > v615[v621][1] and v621 ~= #v615 then
					continue
				end
				local v622 = v615[v621 - 1]
				local v623 = v615[v621]
				v620 = v622[2] + (v623[2] - v622[2]) * (v619 - v622[1]) / (v623[1] - v622[1])
			end
			p600.pivot.Rotation = v620
		else
			local v624 = p600.pivot
			local v625 = v614.from
			local v626 = v614.to - v614.from
			local v627 = p600.dialValue / v614.max
			v624.Rotation = v625 + v626 * math.clamp(v627, 0, 1.03)
		end
		if p600.digits then
			local v628 = v_u_69
			local v629 = p600.digits
			local v630
			if v603 then
				local v631 = p601.odoKm or p601.odoBase + p601.trip
				v630 = math.floor(v631) % 1000000
			else
				v630 = nil
			end
			v628(v629, v630, v604)
		end
		return
	elseif v607 == "forza" then
		local v632 = p600.fz
		if v632.on ~= v603 then
			v632.on = v603
			local v633 = v632.glass
			local v634
			if v603 then
				v634 = Color3.fromRGB(255, 255, 255)
			else
				v634 = Color3.fromRGB(26, 28, 34)
			end
			v633.BackgroundColor3 = v634
			v632.content.Visible = v603
			for _, v635 in v632.statics do
				v635.Visible = v603
			end
		end
		local v636 = (p601.tripKm or p601.trip) % 1000
		local v637 = v_u_69
		local v638 = v632.hours
		local v639
		if v603 then
			local v640 = os.date
			v639 = tonumber(v640("%H"))
		else
			v639 = nil
		end
		v637(v638, v639, v604)
		local v641 = v_u_69
		local v642 = v632.mins
		local v643
		if v603 then
			v643 = os.date("%M")
		else
			v643 = nil
		end
		v641(v642, v643, v604)
		local v644 = v_u_69
		local v645 = v632.trip
		local v646
		if v603 then
			local v647 = v636 * 10
			v646 = ("%02d"):format((math.floor(v647)))
		else
			v646 = nil
		end
		v644(v645, v646, v604)
		local v648 = v_u_69
		local v649 = v632.odo
		local v650
		if v603 then
			local v651 = p601.odoKm or p601.odoBase + p601.trip
			v650 = math.floor(v651) % 1000000
		else
			v650 = nil
		end
		v648(v649, v650, v604)
		local v652 = v_u_69
		local v653 = v632.range
		local v654
		if v603 then
			local v655 = p601.fuelShare * 362
			v654 = math.floor(v655)
		else
			v654 = nil
		end
		v652(v653, v654, v604)
		v_u_69(v632.temp, v603 and 31 or nil, v604)
		v_u_69(v632.volt, v603 and 141 or nil, v604)
		local v656
		if v604 then
			v656 = #v632.fuel
		else
			local v657 = p601.fuelShare * #v632.fuel
			v656 = math.ceil(v657)
		end
		local v658 = v603 and not v604
		if v658 then
			v658 = p601.fuelLow
		end
		if v658 then
			v656 = os.clock() * 1.2 % 1 >= 0.5 and 0 or math.max(1, v656)
		end
		v_u_105(v632.fuel, not v603 and 0 or v656, v603 and 0.88 or 1)
		local v659
		if v603 then
			v659 = not v658 or os.clock() * 1.2 % 1 < 0.5
		else
			v659 = v603
		end
		if v632.pump.Visible ~= v659 then
			v632.pump.Visible = v659
		end
		local v660 = v604 and 0 or (v603 and 0.94 or 0.97)
		for _, v661 in v632.lamps do
			if v661.TextTransparency == v660 then
				continue
			end
			v661.TextTransparency = v660
		end
		for v662, v663 in v632.turn do
			local v664
			if v662 == "L" then
				v664 = v608
			else
				v664 = v609
			end
			local v665
			if v664 or v604 then
				v665 = v_u_189
			else
				v665 = v_u_190
			end
			for _, v666 in v663 do
				if v666.BackgroundColor3 == v665 then
					continue
				end
				v666.BackgroundColor3 = v665
			end
		end
	else
		if p600.digits then
			local v667 = v_u_69
			local v668 = p600.digits
			local v669
			if v603 then
				v669 = p601.kmh
			else
				v669 = nil
			end
			v667(v668, v669, v604)
		end
		if p600.speedText then
			local v670 = p600.speedText
			local v671
			if v603 then
				local v672 = v604 and 888 or p601.kmh
				v671 = tostring(v672)
			else
				v671 = ""
			end
			if v670.Text ~= v671 then
				v670.Text = v671
			end
		end
		if not v604 then
			v605 = p601.revs
		end
		if p600.revBars then
			local v673 = v_u_105
			local v674 = p600.revBars
			local v675
			if v603 then
				local v676 = v605 * #p600.revBars + 0.5
				v675 = math.floor(v676)
			else
				v675 = 0
			end
			v673(v674, v675, v603 and 0.82 or 1)
		end
		if p600.leds then
			local v677
			if v603 then
				local v678 = (v605 - 0.45) / 0.5
				local v679 = math.clamp(v678, 0, 1) * #p600.leds + 0.5
				v677 = math.floor(v679)
			else
				v677 = 0
			end
			local v680 = v603 and (not v604 and p601.revs > 0.97) and (os.clock() * 8 % 1 < 0.5 and #p600.leds or 0) or v677
			v_u_105(p600.leds, v680, v603 and 0.85 or 0.92)
		end
		if p600.fuel then
			local v681
			if v604 then
				v681 = #p600.fuel
			else
				local v682 = p601.fuelShare * #p600.fuel
				v681 = math.ceil(v682)
			end
			if v603 and (not v604 and p601.fuelLow) then
				v681 = os.clock() * 1.2 % 1 >= 0.5 and 0 or math.max(1, v681)
			end
			v_u_105(p600.fuel, not v603 and 0 or v681, v603 and 0.86 or 0.95)
		end
		if p600.pumpParts then
			local v683
			if v603 and (v604 or p601.fuelLow and os.clock() * 1.2 % 1 < 0.5) then
				v683 = Color3.fromRGB(255, 170, 40)
			else
				v683 = Color3.fromRGB(128, 140, 158)
			end
			for _, v684 in p600.pumpParts do
				if v684.BackgroundColor3 == v683 then
					continue
				end
				v684.BackgroundColor3 = v683
			end
			if p600.pump.Visible ~= v603 then
				p600.pump.Visible = v603
			end
		end
		if p600.stripes then
			for v685, v686 in p600.stripes do
				local v687
				if v685 == "L" then
					v687 = v608 or v604
				else
					v687 = v609 or v604
				end
				local v688
				if v687 then
					v688 = v_u_170
				else
					v688 = v_u_169
				end
				for _, v689 in v686 do
					if v689.BackgroundColor3 == v688 then
						continue
					end
					v689.BackgroundColor3 = v688
				end
			end
		end
		if p600.lcdGlass then
			local v690
			if v603 then
				v690 = Color3.fromRGB(255, 255, 255)
			else
				v690 = Color3.fromRGB(34, 38, 46)
			end
			if p600.lcdGlass.BackgroundColor3 ~= v690 then
				p600.lcdGlass.BackgroundColor3 = v690
			end
		end
		if p600.statics and p600.staticsOn ~= v603 then
			p600.staticsOn = v603
			for _, v691 in p600.statics do
				v691.Visible = v603
			end
		end
		if p600.gearLabel then
			local v692 = p600.gearLabel
			local v693 = not v603 and "" or (v604 and "8" or v_u_586(p600, p601))
			if v692.Text ~= v693 then
				v692.Text = v693
			end
		end
		if p600.clock then
			local v694 = p600.clock
			local v695 = not v603 and "" or os.date(os.clock() * 1 % 1 < 0.5 and "%H:%M" or "%H %M")
			if v694.Text ~= v695 then
				v694.Text = v695
			end
		end
		if p600.temp then
			local v696 = p600.temp
			local v697 = v603 and "31\194\176C" or ""
			if v696.Text ~= v697 then
				v696.Text = v697
			end
		end
		if p600.unit then
			p600.unit.Visible = v603
		end
		if p600.trip then
			local v698 = p600.trip
			local v699 = not v603 and "" or ("%.1f"):format((p601.tripKm or p601.trip) % 1000)
			if v698.Text ~= v699 then
				v698.Text = v699
			end
		end
		if p600.odo then
			local v700 = p601.odoKm or p601.odoBase + p601.trip
			local v701 = math.floor(v700)
			local v702 = p600.odo
			local v703
			if v603 then
				if p600.style == "tft" then
					v703 = ("ODO %d km"):format(v701)
				elseif p600.style == "pcxtft" or p600.style == "pcx21" then
					local v704 = math.floor(v701)
					v703 = tostring(v704):reverse():gsub("(%d%d%d)", "%1,"):reverse():gsub("^,", "") .. " km"
				else
					v703 = ("%06d"):format(v701 % 1000000)
				end
			else
				v703 = ""
			end
			if v702.Text ~= v703 then
				v702.Text = v703
			end
		end
		if p600.mode then
			local v705 = p600.mode
			local v706 = v603 and (p601.revs > 0.7 and "SPORT" or "NORMAL") or ""
			if v705.Text ~= v706 then
				v705.Text = v706
			end
		end
		if p600.eco then
			local v707
			if v603 then
				if p601.kmh > 10 and p601.kmh < 75 then
					local v708 = p601.accel or 0
					v707 = math.abs(v708) < 3
				else
					v707 = false
				end
			else
				v707 = v603
			end
			p600.eco.TextTransparency = (v604 or v707) and 0 or (v603 and 0.88 or 1)
		end
		v_u_123(p600.arrowL, v608 or v604, v603 and 0.88 or 1)
		v_u_123(p600.arrowR, v609 or v604, v603 and 0.88 or 1)
		if p600.timer then
			local v709 = not p601.onSince and 0 or os.clock() - p601.onSince
			local v710 = p600.timer
			local v711
			if v603 then
				local v712 = v709 / 60
				v711 = ("%02d:%04.1f"):format(math.floor(v712) % 100, v709 % 60)
			else
				v711 = ""
			end
			if v710.Text ~= v711 then
				v710.Text = v711
			end
		end
		if p600.rpmText then
			local v713 = v_u_587[v607] or 9000
			local v714 = p600.rpmText
			local v715
			if v603 then
				local v716 = (1400 + v605 * (v713 - 1400)) / 50 + 0.5
				v715 = ("%d rpm"):format(math.floor(v716) * 50)
			else
				v715 = ""
			end
			if v714.Text ~= v715 then
				v714.Text = v715
			end
		end
		if p600.glass and not p600.shape then
			if v607 == "lcd" then
				local v717 = p600.glass
				local v718
				if v603 then
					v718 = p600.paper
				else
					local v719 = p600.paper
					local v720 = Color3.new
					local v721 = v719.R * 0.55
					local v722 = math.clamp(v721, 0, 1)
					local v723 = v719.G * 0.55
					local v724 = math.clamp(v723, 0, 1)
					local v725 = v719.B * 0.55
					v718 = v720(v722, v724, (math.clamp(v725, 0, 1)))
				end
				v717.BackgroundColor3 = v718
				return
			end
			if v607 == "tft" or v607 == "race" then
				p600.glass.BackgroundTransparency = 0
			end
		end
	end
end
for _, v727 in v1:GetTagged("DashSpeedo") do
	task.spawn(v582, v727)
end
v2.RenderStepped:Connect(function(p728)
	-- upvalues: (ref) v_u_589, (copy) v_u_5, (copy) v_u_574, (copy) v_u_599, (copy) v_u_726, (copy) v_u_537
	v_u_589 = v_u_589 + 1
	local v729 = workspace.CurrentCamera
	local v730 = v729 and v729.CFrame.Position or Vector3.new(0, 0, 0)
	local v731 = os.clock()
	for v732, v733 in v_u_5 do
		if v732.Parent then
			local v734 = (v732.Position - v730).Magnitude
			if v734 > 95 then
				continue
			end
			local v735
			if v734 < 60 then
				v735 = p728
			else
				if v731 < v733.nextAt then
					continue
				end
				v733.nextAt = v731 + 0.25
				v735 = 0.25
			end
			local v736 = v_u_574(v733.model, v735)
			if v733.style and (not v733.built and v732:IsDescendantOf(workspace)) then
				v_u_599(v733)
			end
			if v733.face then
				v_u_726(v733, v736, v735)
			else
				local v737 = v736.on
				local v738 = v736.kmh
				if v733.speed and v737 ~= v733.on then
					v733.on = v737
					v733.speed.Visible = v737
					if v733.unit0 then
						v733.unit0.Visible = v737
					end
					if v733.shape then
						v733.shape.ImageTransparency = v737 and 0.08 or 0.35
					elseif v733.back then
						v733.back.BackgroundTransparency = v737 and 0.08 or 0.35
					end
				end
				if v733.speed and (v737 and v738 ~= v733.kmh) then
					v733.kmh = v738
					v733.speed.Text = tostring(v738)
				end
			end
			if not (v733.needle and v733.needle.Parent) then
				continue
			end
			local v739 = not v736.on and 0 or v736.kmh
			local v740 = v733.needleKmh
			local v741 = v739 - v733.needleKmh
			local v742 = 8 * v735
			v733.needleKmh = v740 + v741 * math.min(1, v742)
			v_u_537(v733.needle, v733.needleKmh)
		else
			v_u_5[v732] = nil
		end
	end
end)