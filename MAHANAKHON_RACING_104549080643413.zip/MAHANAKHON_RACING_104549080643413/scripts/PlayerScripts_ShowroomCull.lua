-- Path: Players/ygggggg55551/PlayerScripts/ShowroomCull
-- Class: LocalScript  true/Enum.RunContext.Legacy
-- Decompiled by BALL KUN Universal Map Dump

local v1 = {
	"Display",
	"RepairZone",
	"HexLights",
	"Decor"
}
local v2 = game:GetService("Players").LocalPlayer
local v3 = workspace:WaitForChild("Map"):WaitForChild("Landmarks"):WaitForChild("Showroom")
local v_u_4 = v3:GetAttribute("CullBox")
local v5 = v3:GetAttribute("CullSize")
if typeof(v_u_4) ~= "CFrame" or typeof(v5) ~= "Vector3" then
	return
end
local v_u_6 = v5 / 2
local v7 = {}
local v8 = true
task.wait(5)
local v9 = v8
local function v16(p10, p11) -- name: within
	-- upvalues: (copy) v_u_4, (copy) v_u_6
	local v12 = v_u_4:PointToObjectSpace(p10)
	local v13 = v12.X
	local v14
	if math.abs(v13) <= v_u_6.X + p11 then
		local v15 = v12.Z
		if math.abs(v15) <= v_u_6.Z + p11 and v12.Y <= v_u_6.Y + p11 then
			v14 = v12.Y >= -v_u_6.Y - p11
		else
			v14 = false
		end
	else
		v14 = false
	end
	return v14
end
while true do
	local v17 = workspace.CurrentCamera
	local v18 = v2.Character
	if v18 then
		v18 = v2.Character:FindFirstChild("HumanoidRootPart")
	end
	local v19 = {}
	if v18 then
		local v20 = v18.Position
		table.insert(v19, v20)
	end
	if v17 then
		local v21 = v17.CFrame.Position
		table.insert(v19, v21)
	end
	if #v19 > 0 then
		local v22 = false
		local v23 = false
		for _, v24 in v19 do
			v22 = v16(v24, 4) and true or v22
			if not v16(v24, 12) then
				continue
			end
			v23 = true
		end
		if v22 then
			if v9 ~= true then
				v8 = true
				v9 = v8
				for _, v25 in v1 do
					local v26 = v7[v25]
					if not v26 then
						continue
					end
					v26.Parent = v3
					v7[v25] = nil
				end
			end
		elseif not v23 and v9 ~= false then
			v8 = false
			v9 = v8
			for _, v27 in v1 do
				local v28 = v3:FindFirstChild(v27)
				if not v28 then
					continue
				end
				v7[v27] = v28
				v28.Parent = nil
			end
		end
	end
	task.wait(0.5)
end