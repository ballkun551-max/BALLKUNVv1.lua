-- Path: ReplicatedStorage/GameUI/Icons
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = require(game:GetService("ReplicatedStorage"):WaitForChild("UiOwn")).Instance
local v_u_2 = {
	["SHEET"] = "rbxassetid://127697862570039"
}
local v_u_3 = {
	["power"] = 0,
	["parking"] = 1,
	["horn"] = 2,
	["hazard"] = 3,
	["arrow"] = 4,
	["tuck"] = 5,
	["wheelie"] = 6,
	["camera"] = 7,
	["phone"] = 8,
	["exit"] = 9,
	["run"] = 10,
	["home"] = 11,
	["play"] = 12,
	["store"] = 13,
	["settings"] = 14,
	["bag"] = 15,
	["pin"] = 16,
	["key"] = 17,
	["trash"] = 18,
	["close"] = 19,
	["crown"] = 20,
	["gem"] = 21,
	["bulb"] = 22,
	["sound"] = 23,
	["sun"] = 24,
	["shield"] = 25,
	["zap"] = 26,
	["gauge"] = 27,
	["headlight"] = 28
}
local v_u_4 = Color3.new(0, 0, 0)
local function v_u_15(p5, p6, p7, p8, p9, p10, p11) -- name: box
	-- upvalues: (copy) v_u_1
	local v12 = v_u_1.new("Frame")
	v12.BorderSizePixel = 0
	v12.BackgroundColor3 = p10
	v12.Position = UDim2.fromOffset(p6, p7)
	v12.Size = UDim2.fromOffset(p8, p9)
	for v13, v14 in p11 or {} do
		v12[v13] = v14
	end
	v12.Parent = p5
	return v12
end
local function v_u_29(p16, p17, p18, p19, p20, p21, p22, p23) -- name: ring
	-- upvalues: (copy) v_u_15, (copy) v_u_1
	local v24 = v_u_15(p16, p17, p18, p19, p20, p21, {
		["BackgroundTransparency"] = 1
	})
	local v25 = p23 or "round"
	local v26 = v_u_1.new("UICorner")
	local v27
	if v25 == "round" then
		v27 = UDim.new(1, 0)
	else
		v27 = UDim.new(0, v25 or 2)
	end
	v26.CornerRadius = v27
	v26.Parent = v24
	local v28 = v_u_1.new("UIStroke")
	v28.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v28.Thickness = p22 or 2
	v28.Color = p21
	v28.Parent = v24
	return v24
end
local v_u_362 = {
	["key"] = function(p30, p31) -- name: key
		-- upvalues: (copy) v_u_29, (copy) v_u_15, (copy) v_u_1, (copy) v_u_4
		v_u_29(p30, 3, 2, 10, 10, p31, 3)
		local v32 = v_u_15(p30, 9, 8, 13, 18, p31, {
			["Rotation"] = -18
		})
		local v33 = v_u_1.new("UICorner")
		v33.CornerRadius = UDim.new(0, 5)
		v33.Parent = v32
		local v34 = v_u_15(p30, 13.399999999999999, 11.399999999999999, 4.4, 4.4, p31, nil)
		local v35 = v_u_1.new("UICorner")
		v35.CornerRadius = UDim.new(1, 0)
		v35.Parent = v34
		v34.Name = "Hole"
		v34.BackgroundColor3 = v_u_4
		v34.BackgroundTransparency = 0.55
		local v36 = v_u_15(p30, 12, 17, 4.4, 4.4, p31, nil)
		local v37 = v_u_1.new("UICorner")
		v37.CornerRadius = UDim.new(1, 0)
		v37.Parent = v36
		v36.Name = "Hole"
		v36.BackgroundColor3 = v_u_4
		v36.BackgroundTransparency = 0.55
	end,
	["bag"] = function(p38, p39) -- name: bag
		-- upvalues: (copy) v_u_15, (copy) v_u_29, (copy) v_u_1, (copy) v_u_4
		v_u_29(v_u_15(p38, 8, 2, 12, 9, p39, {
			["BackgroundTransparency"] = 1,
			["ClipsDescendants"] = true
		}), 1, 1, 10, 14, p39, 2.6)
		local v40 = v_u_15(p38, 4, 9, 20, 17, p39, nil)
		local v41 = v_u_1.new("UICorner")
		v41.CornerRadius = UDim.new(0, 4)
		v41.Parent = v40
		local v42 = v_u_15(p38, 8.6, 11.6, 2.8, 2.8, p39, nil)
		local v43 = v_u_1.new("UICorner")
		v43.CornerRadius = UDim.new(1, 0)
		v43.Parent = v42
		v42.Name = "Hole"
		v42.BackgroundColor3 = v_u_4
		v42.BackgroundTransparency = 0.55
		local v44 = v_u_15(p38, 16.6, 11.6, 2.8, 2.8, p39, nil)
		local v45 = v_u_1.new("UICorner")
		v45.CornerRadius = UDim.new(1, 0)
		v45.Parent = v44
		v44.Name = "Hole"
		v44.BackgroundColor3 = v_u_4
		v44.BackgroundTransparency = 0.55
	end,
	["trash"] = function(p46, p47) -- name: trash
		-- upvalues: (copy) v_u_15, (copy) v_u_1, (copy) v_u_4
		local v48 = v_u_15(p46, 11, 2, 6, 4, p47, nil)
		local v49 = v_u_1.new("UICorner")
		v49.CornerRadius = UDim.new(0, 1.5)
		v49.Parent = v48
		local v50 = v_u_15(p46, 4, 5, 20, 4, p47, nil)
		local v51 = v_u_1.new("UICorner")
		v51.CornerRadius = UDim.new(0, 2)
		v51.Parent = v50
		local v52 = v_u_15(p46, 6.5, 10, 15, 16, p47, nil)
		local v53 = v_u_1.new("UICorner")
		v53.CornerRadius = UDim.new(0, 3)
		v53.Parent = v52
		local v54 = v_u_15(p46, 10.5, 13, 2, 10, p47, nil)
		local v55 = v_u_1.new("UICorner")
		v55.CornerRadius = UDim.new(0, 1)
		v55.Parent = v54
		v54.Name = "Hole"
		v54.BackgroundColor3 = v_u_4
		v54.BackgroundTransparency = 0.55
		local v56 = v_u_15(p46, 15.5, 13, 2, 10, p47, nil)
		local v57 = v_u_1.new("UICorner")
		v57.CornerRadius = UDim.new(0, 1)
		v57.Parent = v56
		v56.Name = "Hole"
		v56.BackgroundColor3 = v_u_4
		v56.BackgroundTransparency = 0.55
	end,
	["phone"] = function(p58, p59) -- name: phone
		-- upvalues: (copy) v_u_15, (copy) v_u_1, (copy) v_u_4
		local v60 = v_u_15(p58, 7, 1, 14, 26, p59, nil)
		local v61 = v_u_1.new("UICorner")
		v61.CornerRadius = UDim.new(0, 4)
		v61.Parent = v60
		local v62 = v_u_15(p58, 9, 4, 10, 17, p59, nil)
		local v63 = v_u_1.new("UICorner")
		v63.CornerRadius = UDim.new(0, 2)
		v63.Parent = v62
		v62.Name = "Hole"
		v62.BackgroundColor3 = v_u_4
		v62.BackgroundTransparency = 0.55
		local v64 = v_u_15(p58, 11, 23, 6, 1.6, v_u_4, {
			["BackgroundTransparency"] = 0.55,
			["Name"] = "Hole"
		})
		local v65 = v_u_1.new("UICorner")
		v65.CornerRadius = UDim.new(0, 1)
		v65.Parent = v64
	end,
	["pin"] = function(p66, p67) -- name: pin
		-- upvalues: (copy) v_u_15, (copy) v_u_1, (copy) v_u_4
		local v68 = v_u_15(p66, 6, 2, 16, 16, p67, nil)
		local v69 = v_u_1.new("UICorner")
		v69.CornerRadius = UDim.new(1, 0)
		v69.Parent = v68
		local v70 = v_u_15(p66, 10.8, 6.8, 6.4, 6.4, p67, nil)
		local v71 = v_u_1.new("UICorner")
		v71.CornerRadius = UDim.new(1, 0)
		v71.Parent = v70
		v70.Name = "Hole"
		v70.BackgroundColor3 = v_u_4
		v70.BackgroundTransparency = 0.55
		local v72 = v_u_15(p66, 12.3, 15, 3.4, 9, p67, nil)
		local v73 = v_u_1.new("UICorner")
		v73.CornerRadius = UDim.new(0, 1.7)
		v73.Parent = v72
		local v74 = v_u_15(p66, 7, 24, 14, 3, p67, nil)
		local v75 = v_u_1.new("UICorner")
		v75.CornerRadius = UDim.new(1, 0)
		v75.Parent = v74
		v74.BackgroundTransparency = 0.45
	end,
	["person"] = function(p76, p77) -- name: person
		-- upvalues: (copy) v_u_15, (copy) v_u_1
		local v78 = v_u_15(p76, 8.5, 3, 11, 11, p77, nil)
		local v79 = v_u_1.new("UICorner")
		v79.CornerRadius = UDim.new(1, 0)
		v79.Parent = v78
		local v80 = v_u_15(v_u_15(p76, 3, 16, 22, 11, p77, {
			["BackgroundTransparency"] = 1,
			["ClipsDescendants"] = true
		}), 0, 0, 22, 22, p77, nil)
		local v81 = v_u_1.new("UICorner")
		v81.CornerRadius = UDim.new(0, 10)
		v81.Parent = v80
	end,
	["people"] = function(p82, p83) -- name: people
		-- upvalues: (copy) v_u_15, (copy) v_u_1
		local v84 = v_u_15(p82, 14.8, 4.8, 8.4, 8.4, p83, nil)
		local v85 = v_u_1.new("UICorner")
		v85.CornerRadius = UDim.new(1, 0)
		v85.Parent = v84
		local v86 = v_u_15(v_u_15(p82, 12, 15, 15, 10, p83, {
			["BackgroundTransparency"] = 1,
			["ClipsDescendants"] = true
		}), 0, 0, 15, 16, p83, nil)
		local v87 = v_u_1.new("UICorner")
		v87.CornerRadius = UDim.new(0, 7)
		v87.Parent = v86
		local v88 = v_u_15(p82, 5.5, 5, 10, 10, p83, nil)
		local v89 = v_u_1.new("UICorner")
		v89.CornerRadius = UDim.new(1, 0)
		v89.Parent = v88
		local v90 = v_u_15(v_u_15(p82, 1.5, 17, 18, 9, p83, {
			["BackgroundTransparency"] = 1,
			["ClipsDescendants"] = true
		}), 0, 0, 18, 18, p83, nil)
		local v91 = v_u_1.new("UICorner")
		v91.CornerRadius = UDim.new(0, 8)
		v91.Parent = v90
	end,
	["scooter"] = function(p92, p93) -- name: scooter
		-- upvalues: (copy) v_u_29, (copy) v_u_15, (copy) v_u_1, (copy) v_u_4
		v_u_29(p92, 2.5, 17, 8, 8, p93, 2.6)
		v_u_29(p92, 17.5, 17, 8, 8, p93, 2.6)
		local v94 = v_u_15(p92, 8, 16, 13, 4, p93, nil)
		local v95 = v_u_1.new("UICorner")
		v95.CornerRadius = UDim.new(0, 2)
		v95.Parent = v94
		local v96 = v_u_15(p92, 19.75, 13, 12.907764064044152, 2.6, p93, {
			["AnchorPoint"] = nil,
			["Rotation"] = -104.03624346792648,
			["AnchorPoint"] = Vector2.new(0.5, 0.5)
		})
		local v97 = v_u_1.new("UICorner")
		v97.CornerRadius = UDim.new(1, 0)
		v97.Parent = v96
		local v98 = v_u_15(p92, 19, 7.5, 7.4, 2.4, p93, {
			["AnchorPoint"] = nil,
			["Rotation"] = 0,
			["AnchorPoint"] = Vector2.new(0.5, 0.5)
		})
		local v99 = v_u_1.new("UICorner")
		v99.CornerRadius = UDim.new(1, 0)
		v99.Parent = v98
		local v100 = v_u_15(p92, 3, 7, 11, 9, p93, nil)
		local v101 = v_u_1.new("UICorner")
		v101.CornerRadius = UDim.new(0, 2)
		v101.Parent = v100
		local v102 = v_u_15(p92, 5, 10, 7, 2, p93, nil)
		local v103 = v_u_1.new("UICorner")
		v103.CornerRadius = UDim.new(0, 1)
		v103.Parent = v102
		v102.Name = "Hole"
		v102.BackgroundColor3 = v_u_4
		v102.BackgroundTransparency = 0.55
	end,
	["rider"] = function(p104, p105) -- name: rider
		-- upvalues: (copy) v_u_15, (copy) v_u_1, (copy) v_u_29, (copy) v_u_4
		local v106 = v_u_15(p104, 14, 14, 28, 28, p105, {
			["Name"] = "Art",
			["AnchorPoint"] = nil,
			["BackgroundTransparency"] = 1,
			["AnchorPoint"] = Vector2.new(0.5, 0.5)
		})
		local v107 = v_u_1.new("UIScale")
		v107.Scale = 0.72
		v107.Parent = v106
		v_u_29(v106, 1, 17.5, 9, 9, p105, 3)
		v_u_29(v106, 18, 17.5, 9, 9, p105, 3)
		local v108 = v_u_15(v106, 7.5, 13.2, 13.5, 7.8, p105, nil)
		local v109 = v_u_1.new("UICorner")
		v109.CornerRadius = UDim.new(0, 2.5)
		v109.Parent = v108
		local v110 = v_u_15(v106, 1.5, 11.6, 10, 2.8, p105, nil)
		local v111 = v_u_1.new("UICorner")
		v111.CornerRadius = UDim.new(0, 1.4)
		v111.Parent = v110
		local v112 = v_u_15(v106, 21.15, 16.2, 14.51007976463634, 2.6, p105, {
			["AnchorPoint"] = nil,
			["Rotation"] = -103.10278994126246,
			["AnchorPoint"] = Vector2.new(0.5, 0.5)
		})
		local v113 = v_u_1.new("UICorner")
		v113.CornerRadius = UDim.new(1, 0)
		v113.Parent = v112
		local v114 = v_u_15(v106, 20.8, 10.7, 3.8, 3.8, p105, nil)
		local v115 = v_u_1.new("UICorner")
		v115.CornerRadius = UDim.new(1, 0)
		v115.Parent = v114
		local v116 = v_u_15(v106, 19.4, 9.2, 5.887817782917153, 2.2, p105, {
			["AnchorPoint"] = nil,
			["Rotation"] = -12.528807709151502,
			["AnchorPoint"] = Vector2.new(0.5, 0.5)
		})
		local v117 = v_u_1.new("UICorner")
		v117.CornerRadius = UDim.new(1, 0)
		v117.Parent = v116
		local v118 = v_u_15(v106, 8.3, 0.5, 6.2, 6.2, p105, nil)
		local v119 = v_u_1.new("UICorner")
		v119.CornerRadius = UDim.new(1, 0)
		v119.Parent = v118
		local v120 = v_u_15(v106, 10, 9.399999999999999, 8.222154055254965, 4.6, p105, {
			["AnchorPoint"] = nil,
			["Rotation"] = 83.65980825409011,
			["AnchorPoint"] = Vector2.new(0.5, 0.5)
		})
		local v121 = v_u_1.new("UICorner")
		v121.CornerRadius = UDim.new(1, 0)
		v121.Parent = v120
		local v122 = v_u_15(v106, 14.7, 9.1, 9.602702209328697, 2.2, p105, {
			["AnchorPoint"] = nil,
			["Rotation"] = 1.5481576989779626,
			["AnchorPoint"] = Vector2.new(0.5, 0.5)
		})
		local v123 = v_u_1.new("UICorner")
		v123.CornerRadius = UDim.new(1, 0)
		v123.Parent = v122
		local v124 = v_u_15(v106, 13, 12.55, 8.44690384893796, 3.2, p105, {
			["AnchorPoint"] = nil,
			["Rotation"] = 7.66680426181419,
			["AnchorPoint"] = Vector2.new(0.5, 0.5)
		})
		local v125 = v_u_1.new("UICorner")
		v125.CornerRadius = UDim.new(1, 0)
		v125.Parent = v124
		local v126 = v_u_15(v106, 15.399999999999999, 15.850000000000001, 8.713543776789008, 2.8, p105, {
			["AnchorPoint"] = nil,
			["Rotation"] = 93.87852450284771,
			["AnchorPoint"] = Vector2.new(0.5, 0.5)
		})
		local v127 = v_u_1.new("UICorner")
		v127.CornerRadius = UDim.new(1, 0)
		v127.Parent = v126
		local v128 = v_u_15(v106, 11.5, 15.15, 5.629657196511319, 1.4, p105, {
			["AnchorPoint"] = nil,
			["Rotation"] = 6.788974574438792,
			["AnchorPoint"] = Vector2.new(0.5, 0.5)
		})
		local v129 = v_u_1.new("UICorner")
		v129.CornerRadius = UDim.new(1, 0)
		v129.Parent = v128
		v128.Name = "Hole"
		v128.BackgroundColor3 = v_u_4
		v128.BackgroundTransparency = 0.55
		local v130 = v_u_15(v106, 13.5, 17.9, 6.40399840127872, 1.4, p105, {
			["AnchorPoint"] = nil,
			["Rotation"] = 92.29061004263852,
			["AnchorPoint"] = Vector2.new(0.5, 0.5)
		})
		local v131 = v_u_1.new("UICorner")
		v131.CornerRadius = UDim.new(1, 0)
		v131.Parent = v130
		v130.Name = "Hole"
		v130.BackgroundColor3 = v_u_4
		v130.BackgroundTransparency = 0.55
		local v132 = v_u_15(v106, 17.35, 17.4, 7.407495318350234, 1.4, p105, {
			["AnchorPoint"] = nil,
			["Rotation"] = 92.86240522611176,
			["AnchorPoint"] = Vector2.new(0.5, 0.5)
		})
		local v133 = v_u_1.new("UICorner")
		v133.CornerRadius = UDim.new(1, 0)
		v133.Parent = v132
		v132.Name = "Hole"
		v132.BackgroundColor3 = v_u_4
		v132.BackgroundTransparency = 0.55
	end,
	["bowl"] = function(p134, p135) -- name: bowl
		-- upvalues: (copy) v_u_15, (copy) v_u_1
		local v136 = v_u_15(v_u_15(p134, 3, 13, 22, 12, p135, {
			["BackgroundTransparency"] = 1,
			["ClipsDescendants"] = true
		}), 0, -11, 22, 22, p135, nil)
		local v137 = v_u_1.new("UICorner")
		v137.CornerRadius = UDim.new(1, 0)
		v137.Parent = v136
		local v138 = v_u_15(p134, 2, 12, 24, 3, p135, nil)
		local v139 = v_u_1.new("UICorner")
		v139.CornerRadius = UDim.new(0, 1.5)
		v139.Parent = v138
		local v140 = v_u_15(p134, 10, 23.5, 8, 2.5, p135, nil)
		local v141 = v_u_1.new("UICorner")
		v141.CornerRadius = UDim.new(0, 1)
		v141.Parent = v140
		local v142 = v_u_15(p134, 9.5, 6, 8.082762530298218, 2, p135, {
			["AnchorPoint"] = nil,
			["Rotation"] = -80.53767779197439,
			["AnchorPoint"] = Vector2.new(0.5, 0.5)
		})
		local v143 = v_u_1.new("UICorner")
		v143.CornerRadius = UDim.new(1, 0)
		v143.Parent = v142
		local v144 = v_u_15(p134, 14.5, 6, 8.082762530298218, 2, p135, {
			["AnchorPoint"] = nil,
			["Rotation"] = -80.53767779197439,
			["AnchorPoint"] = Vector2.new(0.5, 0.5)
		})
		local v145 = v_u_1.new("UICorner")
		v145.CornerRadius = UDim.new(1, 0)
		v145.Parent = v144
		local v146 = v_u_15(p134, 19.5, 6, 8.082762530298218, 2, p135, {
			["AnchorPoint"] = nil,
			["Rotation"] = -80.53767779197439,
			["AnchorPoint"] = Vector2.new(0.5, 0.5)
		})
		local v147 = v_u_1.new("UICorner")
		v147.CornerRadius = UDim.new(1, 0)
		v147.Parent = v146
	end,
	["money"] = function(p148, p149) -- name: money
		-- upvalues: (copy) v_u_15, (copy) v_u_1, (copy) v_u_4
		local v150 = v_u_15(p148, 2, 7, 24, 15, p149, nil)
		local v151 = v_u_1.new("UICorner")
		v151.CornerRadius = UDim.new(0, 3)
		v151.Parent = v150
		local v152 = v_u_15(p148, 10, 10.5, 8, 8, p149, nil)
		local v153 = v_u_1.new("UICorner")
		v153.CornerRadius = UDim.new(1, 0)
		v153.Parent = v152
		v152.Name = "Hole"
		v152.BackgroundColor3 = v_u_4
		v152.BackgroundTransparency = 0.55
		local v154 = v_u_15(p148, 5.1, 13.1, 2.8, 2.8, p149, nil)
		local v155 = v_u_1.new("UICorner")
		v155.CornerRadius = UDim.new(1, 0)
		v155.Parent = v154
		v154.Name = "Hole"
		v154.BackgroundColor3 = v_u_4
		v154.BackgroundTransparency = 0.55
		local v156 = v_u_15(p148, 20.1, 13.1, 2.8, 2.8, p149, nil)
		local v157 = v_u_1.new("UICorner")
		v157.CornerRadius = UDim.new(1, 0)
		v157.Parent = v156
		v156.Name = "Hole"
		v156.BackgroundColor3 = v_u_4
		v156.BackgroundTransparency = 0.55
	end,
	["clock"] = function(p158, p159) -- name: clock
		-- upvalues: (copy) v_u_15, (copy) v_u_1, (copy) v_u_4
		local v160 = v_u_15(p158, 2, 2, 24, 24, p159, nil)
		local v161 = v_u_1.new("UICorner")
		v161.CornerRadius = UDim.new(1, 0)
		v161.Parent = v160
		local v162 = v_u_15(p158, 5, 5, 18, 18, p159, nil)
		local v163 = v_u_1.new("UICorner")
		v163.CornerRadius = UDim.new(1, 0)
		v163.Parent = v162
		v162.Name = "Hole"
		v162.BackgroundColor3 = v_u_4
		v162.BackgroundTransparency = 0.55
		v162.BackgroundTransparency = 0.7
		local v164 = v_u_15(p158, 14, 11, 8.4, 2.4, p159, {
			["AnchorPoint"] = nil,
			["Rotation"] = -90,
			["AnchorPoint"] = Vector2.new(0.5, 0.5)
		})
		local v165 = v_u_1.new("UICorner")
		v165.CornerRadius = UDim.new(1, 0)
		v165.Parent = v164
		local v166 = v_u_15(p158, 16.25, 15.25, 7.547815070493501, 2.4, p159, {
			["AnchorPoint"] = nil,
			["Rotation"] = 29.054604099077146,
			["AnchorPoint"] = Vector2.new(0.5, 0.5)
		})
		local v167 = v_u_1.new("UICorner")
		v167.CornerRadius = UDim.new(1, 0)
		v167.Parent = v166
	end,
	["check"] = function(p168, p169) -- name: check
		-- upvalues: (copy) v_u_15, (copy) v_u_1
		local v170 = v_u_15(p168, 8, 18, 11.88528137423857, 3.4, p169, {
			["AnchorPoint"] = nil,
			["Rotation"] = 45,
			["AnchorPoint"] = Vector2.new(0.5, 0.5)
		})
		local v171 = v_u_1.new("UICorner")
		v171.CornerRadius = UDim.new(1, 0)
		v171.Parent = v170
		local v172 = v_u_15(p168, 17, 14, 21.839088914585773, 3.4, p169, {
			["AnchorPoint"] = nil,
			["Rotation"] = -49.398705354995535,
			["AnchorPoint"] = Vector2.new(0.5, 0.5)
		})
		local v173 = v_u_1.new("UICorner")
		v173.CornerRadius = UDim.new(1, 0)
		v173.Parent = v172
	end,
	["home"] = function(p174, p175) -- name: home
		-- upvalues: (copy) v_u_15, (copy) v_u_1, (copy) v_u_4
		local v176 = v_u_15(v_u_15(p174, 2, 2, 24, 12, p175, {
			["BackgroundTransparency"] = 1,
			["ClipsDescendants"] = true
		}), 4, 3.5, 16, 16, p175, {
			["Rotation"] = 45
		})
		local v177 = v_u_1.new("UICorner")
		v177.CornerRadius = UDim.new(0, 2)
		v177.Parent = v176
		local v178 = v_u_15(p174, 6, 13, 16, 13, p175, nil)
		local v179 = v_u_1.new("UICorner")
		v179.CornerRadius = UDim.new(0, 2)
		v179.Parent = v178
		local v180 = v_u_15(p174, 11.5, 17, 5, 9, p175, nil)
		local v181 = v_u_1.new("UICorner")
		v181.CornerRadius = UDim.new(0, 1.5)
		v181.Parent = v180
		v180.Name = "Hole"
		v180.BackgroundColor3 = v_u_4
		v180.BackgroundTransparency = 0.55
	end,
	["star"] = function(p182, p183) -- name: star
		-- upvalues: (copy) v_u_15, (copy) v_u_1, (copy) v_u_4
		local v184 = v_u_15(p182, 6, 6, 16, 16, p183, nil)
		local v185 = v_u_1.new("UICorner")
		v185.CornerRadius = UDim.new(0, 2)
		v185.Parent = v184
		local v186 = v_u_15(p182, 6, 6, 16, 16, p183, {
			["Rotation"] = 45
		})
		local v187 = v_u_1.new("UICorner")
		v187.CornerRadius = UDim.new(0, 2)
		v187.Parent = v186
		local v188 = v_u_15(p182, 11, 11, 6, 6, p183, nil)
		local v189 = v_u_1.new("UICorner")
		v189.CornerRadius = UDim.new(1, 0)
		v189.Parent = v188
		v188.Name = "Hole"
		v188.BackgroundColor3 = v_u_4
		v188.BackgroundTransparency = 0.55
	end,
	["gift"] = function(p190, p191) -- name: gift
		-- upvalues: (copy) v_u_15, (copy) v_u_1, (copy) v_u_4, (copy) v_u_29
		local v192 = v_u_15(p190, 5, 13, 18, 13, p191, nil)
		local v193 = v_u_1.new("UICorner")
		v193.CornerRadius = UDim.new(0, 2)
		v193.Parent = v192
		local v194 = v_u_15(p190, 3, 8, 22, 6, p191, nil)
		local v195 = v_u_1.new("UICorner")
		v195.CornerRadius = UDim.new(0, 2)
		v195.Parent = v194
		local v196 = v_u_15(p190, 12.6, 8, 2.8, 18, p191, nil)
		local v197 = v_u_1.new("UICorner")
		v197.CornerRadius = UDim.new(0, 0)
		v197.Parent = v196
		v196.Name = "Hole"
		v196.BackgroundColor3 = v_u_4
		v196.BackgroundTransparency = 0.55
		v_u_29(p190, 7.5, 2.5, 7, 6, p191, 2.2)
		v_u_29(p190, 13.5, 2.5, 7, 6, p191, 2.2)
	end,
	["ticket"] = function(p198, p199) -- name: ticket
		-- upvalues: (copy) v_u_15, (copy) v_u_1, (copy) v_u_4
		local v200 = v_u_15(p198, 2, 7, 24, 14, p199, nil)
		local v201 = v_u_1.new("UICorner")
		v201.CornerRadius = UDim.new(0, 3)
		v201.Parent = v200
		local v202 = v_u_15(p198, -0.6000000000000001, 11.4, 5.2, 5.2, p199, nil)
		local v203 = v_u_1.new("UICorner")
		v203.CornerRadius = UDim.new(1, 0)
		v203.Parent = v202
		v202.Name = "Hole"
		v202.BackgroundColor3 = v_u_4
		v202.BackgroundTransparency = 0.55
		local v204 = v_u_15(p198, 23.4, 11.4, 5.2, 5.2, p199, nil)
		local v205 = v_u_1.new("UICorner")
		v205.CornerRadius = UDim.new(1, 0)
		v205.Parent = v204
		v204.Name = "Hole"
		v204.BackgroundColor3 = v_u_4
		v204.BackgroundTransparency = 0.55
		for _, v206 in { 9.5, 13, 16.5 } do
			local v207 = v_u_15(p198, 17.4, v206, 1.6, 2.2, p199, nil)
			local v208 = v_u_1.new("UICorner")
			v208.CornerRadius = UDim.new(0, 0.5)
			v208.Parent = v207
			v207.Name = "Hole"
			v207.BackgroundColor3 = v_u_4
			v207.BackgroundTransparency = 0.55
		end
		local v209 = v_u_15(p198, 6, 11, 8, 2, p199, nil)
		local v210 = v_u_1.new("UICorner")
		v210.CornerRadius = UDim.new(0, 1)
		v210.Parent = v209
		v209.Name = "Hole"
		v209.BackgroundColor3 = v_u_4
		v209.BackgroundTransparency = 0.55
		local v211 = v_u_15(p198, 6, 15, 6, 2, p199, nil)
		local v212 = v_u_1.new("UICorner")
		v212.CornerRadius = UDim.new(0, 1)
		v212.Parent = v211
		v211.Name = "Hole"
		v211.BackgroundColor3 = v_u_4
		v211.BackgroundTransparency = 0.55
	end,
	["plus"] = function(p213, p214) -- name: plus
		-- upvalues: (copy) v_u_15, (copy) v_u_1
		local v215 = v_u_15(p213, 14, 14, 21.6, 3.6, p214, {
			["AnchorPoint"] = nil,
			["Rotation"] = 90,
			["AnchorPoint"] = Vector2.new(0.5, 0.5)
		})
		local v216 = v_u_1.new("UICorner")
		v216.CornerRadius = UDim.new(1, 0)
		v216.Parent = v215
		local v217 = v_u_15(p213, 14, 14, 21.6, 3.6, p214, {
			["AnchorPoint"] = nil,
			["Rotation"] = 0,
			["AnchorPoint"] = Vector2.new(0.5, 0.5)
		})
		local v218 = v_u_1.new("UICorner")
		v218.CornerRadius = UDim.new(1, 0)
		v218.Parent = v217
	end,
	["coin"] = function(p219, p220) -- name: coin
		-- upvalues: (copy) v_u_29, (copy) v_u_1
		v_u_29(p219, 2.5, 2.5, 23, 23, p220, 2.6)
		local v221 = v_u_1.new("TextLabel")
		v221.BackgroundTransparency = 1
		v221.Size = UDim2.fromScale(1, 1)
		v221.FontFace = Font.new("rbxasset://fonts/families/BuilderSans.json", Enum.FontWeight.ExtraBold)
		v221.TextSize = 17
		v221.TextColor3 = p220
		v221.Text = "\224\184\191"
		v221.Parent = p219
	end,
	["lock"] = function(p222, p223) -- name: lock
		-- upvalues: (copy) v_u_15, (copy) v_u_29, (copy) v_u_1, (copy) v_u_4
		v_u_29(v_u_15(p222, 7, 2, 14, 11, p223, {
			["BackgroundTransparency"] = 1,
			["ClipsDescendants"] = true
		}), 1.5, 1.5, 11, 18, p223, 2.8)
		local v224 = v_u_15(p222, 5, 12, 18, 14, p223, nil)
		local v225 = v_u_1.new("UICorner")
		v225.CornerRadius = UDim.new(0, 3)
		v225.Parent = v224
		local v226 = v_u_15(p222, 11.8, 15.8, 4.4, 4.4, p223, nil)
		local v227 = v_u_1.new("UICorner")
		v227.CornerRadius = UDim.new(1, 0)
		v227.Parent = v226
		v226.Name = "Hole"
		v226.BackgroundColor3 = v_u_4
		v226.BackgroundTransparency = 0.55
		local v228 = v_u_15(p222, 13.1, 18, 1.8, 4, p223, nil)
		local v229 = v_u_1.new("UICorner")
		v229.CornerRadius = UDim.new(0, 0.8)
		v229.Parent = v228
		v228.Name = "Hole"
		v228.BackgroundColor3 = v_u_4
		v228.BackgroundTransparency = 0.55
	end,
	["trophy"] = function(p230, p231) -- name: trophy
		-- upvalues: (copy) v_u_15, (copy) v_u_1, (copy) v_u_29
		local v232 = v_u_15(v_u_15(p230, 7, 3, 14, 13, p231, {
			["BackgroundTransparency"] = 1,
			["ClipsDescendants"] = true
		}), 0, -10, 14, 23, p231, nil)
		local v233 = v_u_1.new("UICorner")
		v233.CornerRadius = UDim.new(0, 7)
		v233.Parent = v232
		v_u_29(p230, 2, 5, 7, 8, p231, 2.2)
		v_u_29(p230, 19, 5, 7, 8, p231, 2.2)
		local v234 = v_u_15(p230, 12.5, 15, 3, 6, p231, nil)
		local v235 = v_u_1.new("UICorner")
		v235.CornerRadius = UDim.new(0, 1)
		v235.Parent = v234
		local v236 = v_u_15(p230, 8, 21, 12, 4, p231, nil)
		local v237 = v_u_1.new("UICorner")
		v237.CornerRadius = UDim.new(0, 1.5)
		v237.Parent = v236
	end,
	["brush"] = function(p238, p239) -- name: brush
		-- upvalues: (copy) v_u_15, (copy) v_u_1
		local v240 = v_u_15(p238, 19.5, 8.5, 16.127922061357854, 3.4, p239, {
			["AnchorPoint"] = nil,
			["Rotation"] = -45,
			["AnchorPoint"] = Vector2.new(0.5, 0.5)
		})
		local v241 = v_u_1.new("UICorner")
		v241.CornerRadius = UDim.new(1, 0)
		v241.Parent = v240
		local v242 = v_u_15(p238, 9.5, 12, 7, 6, p239, {
			["Rotation"] = 45
		})
		local v243 = v_u_1.new("UICorner")
		v243.CornerRadius = UDim.new(0, 1.5)
		v243.Parent = v242
		local v244 = v_u_15(p238, 3.5, 17, 8, 8, p239, {
			["Rotation"] = 45
		})
		local v245 = v_u_1.new("UICorner")
		v245.CornerRadius = UDim.new(0, 3)
		v245.Parent = v244
		v244.Size = UDim2.fromOffset(9, 7)
	end,
	["car"] = function(p246, p247) -- name: car
		-- upvalues: (copy) v_u_15, (copy) v_u_1, (copy) v_u_4
		local v248 = v_u_15(p246, 2, 13, 24, 8, p247, nil)
		local v249 = v_u_1.new("UICorner")
		v249.CornerRadius = UDim.new(0, 3)
		v249.Parent = v248
		local v250 = v_u_15(v_u_15(p246, 6, 6, 16, 8, p247, {
			["BackgroundTransparency"] = 1,
			["ClipsDescendants"] = true
		}), 0, 0, 16, 14, p247, nil)
		local v251 = v_u_1.new("UICorner")
		v251.CornerRadius = UDim.new(0, 5)
		v251.Parent = v250
		local v252 = v_u_15(p246, 8.5, 8.3, 5, 4.5, p247, nil)
		local v253 = v_u_1.new("UICorner")
		v253.CornerRadius = UDim.new(0, 1.5)
		v253.Parent = v252
		v252.Name = "Hole"
		v252.BackgroundColor3 = v_u_4
		v252.BackgroundTransparency = 0.55
		local v254 = v_u_15(p246, 14.8, 8.3, 5, 4.5, p247, nil)
		local v255 = v_u_1.new("UICorner")
		v255.CornerRadius = UDim.new(0, 1.5)
		v255.Parent = v254
		v254.Name = "Hole"
		v254.BackgroundColor3 = v_u_4
		v254.BackgroundTransparency = 0.55
		local v256 = v_u_15(p246, 4.4, 17.4, 7.2, 7.2, p247, nil)
		local v257 = v_u_1.new("UICorner")
		v257.CornerRadius = UDim.new(1, 0)
		v257.Parent = v256
		local v258 = v_u_15(p246, 16.4, 17.4, 7.2, 7.2, p247, nil)
		local v259 = v_u_1.new("UICorner")
		v259.CornerRadius = UDim.new(1, 0)
		v259.Parent = v258
		local v260 = v_u_15(p246, 6.5, 19.5, 3, 3, p247, nil)
		local v261 = v_u_1.new("UICorner")
		v261.CornerRadius = UDim.new(1, 0)
		v261.Parent = v260
		v260.Name = "Hole"
		v260.BackgroundColor3 = v_u_4
		v260.BackgroundTransparency = 0.55
		local v262 = v_u_15(p246, 18.5, 19.5, 3, 3, p247, nil)
		local v263 = v_u_1.new("UICorner")
		v263.CornerRadius = UDim.new(1, 0)
		v263.Parent = v262
		v262.Name = "Hole"
		v262.BackgroundColor3 = v_u_4
		v262.BackgroundTransparency = 0.55
	end,
	["arrow"] = function(p264, p265) -- name: arrow
		-- upvalues: (copy) v_u_15, (copy) v_u_1
		local v266 = v_u_15(p264, 15, 14, 21, 3, p265, {
			["AnchorPoint"] = nil,
			["Rotation"] = 0,
			["AnchorPoint"] = Vector2.new(0.5, 0.5)
		})
		local v267 = v_u_1.new("UICorner")
		v267.CornerRadius = UDim.new(1, 0)
		v267.Parent = v266
		local v268 = v_u_15(p264, 9.5, 10.5, 12.899494936611665, 3, p265, {
			["AnchorPoint"] = nil,
			["Rotation"] = -45,
			["AnchorPoint"] = Vector2.new(0.5, 0.5)
		})
		local v269 = v_u_1.new("UICorner")
		v269.CornerRadius = UDim.new(1, 0)
		v269.Parent = v268
		local v270 = v_u_15(p264, 9.5, 17.5, 12.899494936611665, 3, p265, {
			["AnchorPoint"] = nil,
			["Rotation"] = 45,
			["AnchorPoint"] = Vector2.new(0.5, 0.5)
		})
		local v271 = v_u_1.new("UICorner")
		v271.CornerRadius = UDim.new(1, 0)
		v271.Parent = v270
	end,
	["close"] = function(p272, p273) -- name: close
		-- upvalues: (copy) v_u_15, (copy) v_u_1
		local v274 = v_u_15(p272, 14, 14, 22.19898987322333, 2.4, p273, {
			["AnchorPoint"] = nil,
			["Rotation"] = 45,
			["AnchorPoint"] = Vector2.new(0.5, 0.5)
		})
		local v275 = v_u_1.new("UICorner")
		v275.CornerRadius = UDim.new(1, 0)
		v275.Parent = v274
		local v276 = v_u_15(p272, 14, 14, 22.19898987322333, 2.4, p273, {
			["AnchorPoint"] = nil,
			["Rotation"] = 135,
			["AnchorPoint"] = Vector2.new(0.5, 0.5)
		})
		local v277 = v_u_1.new("UICorner")
		v277.CornerRadius = UDim.new(1, 0)
		v277.Parent = v276
	end,
	["horn"] = function(p278, p279) -- name: horn
		-- upvalues: (copy) v_u_15, (copy) v_u_1
		local v280 = v_u_15(p278, 3, 10, 6, 8, p279, nil)
		local v281 = v_u_1.new("UICorner")
		v281.CornerRadius = UDim.new(0, 1.5)
		v281.Parent = v280
		local v282 = v_u_15(p278, 12, 7, 11.08528137423857, 2.6, p279, {
			["AnchorPoint"] = nil,
			["Rotation"] = -45,
			["AnchorPoint"] = Vector2.new(0.5, 0.5)
		})
		local v283 = v_u_1.new("UICorner")
		v283.CornerRadius = UDim.new(1, 0)
		v283.Parent = v282
		local v284 = v_u_15(p278, 12, 21, 11.08528137423857, 2.6, p279, {
			["AnchorPoint"] = nil,
			["Rotation"] = 45,
			["AnchorPoint"] = Vector2.new(0.5, 0.5)
		})
		local v285 = v_u_1.new("UICorner")
		v285.CornerRadius = UDim.new(1, 0)
		v285.Parent = v284
		local v286 = v_u_15(p278, 15, 14, 22.6, 2.6, p279, {
			["AnchorPoint"] = nil,
			["Rotation"] = 90,
			["AnchorPoint"] = Vector2.new(0.5, 0.5)
		})
		local v287 = v_u_1.new("UICorner")
		v287.CornerRadius = UDim.new(1, 0)
		v287.Parent = v286
		local v288 = v_u_15(p278, 9, 9, 5, 10, p279, nil)
		local v289 = v_u_1.new("UICorner")
		v289.CornerRadius = UDim.new(0, 0)
		v289.Parent = v288
		local v290 = v_u_15(p278, 22, 14, 8.2, 2.2, p279, {
			["AnchorPoint"] = nil,
			["Rotation"] = 0,
			["AnchorPoint"] = Vector2.new(0.5, 0.5)
		})
		local v291 = v_u_1.new("UICorner")
		v291.CornerRadius = UDim.new(1, 0)
		v291.Parent = v290
		local v292 = v_u_15(p278, 21.5, 7.5, 8.030951894845302, 2.2, p279, {
			["AnchorPoint"] = nil,
			["Rotation"] = -30.96375653207352,
			["AnchorPoint"] = Vector2.new(0.5, 0.5)
		})
		local v293 = v_u_1.new("UICorner")
		v293.CornerRadius = UDim.new(1, 0)
		v293.Parent = v292
		local v294 = v_u_15(p278, 21.5, 20.5, 8.030951894845302, 2.2, p279, {
			["AnchorPoint"] = nil,
			["Rotation"] = 30.96375653207352,
			["AnchorPoint"] = Vector2.new(0.5, 0.5)
		})
		local v295 = v_u_1.new("UICorner")
		v295.CornerRadius = UDim.new(1, 0)
		v295.Parent = v294
	end,
	["headlight"] = function(p296, p297) -- name: headlight
		-- upvalues: (copy) v_u_15, (copy) v_u_29, (copy) v_u_1
		v_u_29(v_u_15(p296, 13, 4, 13, 20, p297, {
			["BackgroundTransparency"] = 1,
			["ClipsDescendants"] = true
		}), -10, 0, 20, 20, p297, 2.6)
		local v298 = v_u_15(p296, 13, 14, 20.6, 2.6, p297, {
			["AnchorPoint"] = nil,
			["Rotation"] = 90,
			["AnchorPoint"] = Vector2.new(0.5, 0.5)
		})
		local v299 = v_u_1.new("UICorner")
		v299.CornerRadius = UDim.new(1, 0)
		v299.Parent = v298
		for _, v300 in {
			7,
			11.5,
			16,
			20.5
		} do
			local v301 = v300 - v300
			local v302 = 36 + v301 * v301
			local v303 = math.sqrt(v302)
			local v304 = v_u_15
			local v305 = (v300 + v300) / 2
			local v306 = v303 + 2.2
			local v307 = {
				["AnchorPoint"] = Vector2.new(0.5, 0.5)
			}
			local v308 = math.atan2(v301, 6)
			v307.Rotation = math.deg(v308)
			local v309 = v304(p296, 6, v305, v306, 2.2, p297, v307)
			local v310 = v_u_1.new("UICorner")
			v310.CornerRadius = UDim.new(1, 0)
			v310.Parent = v309
		end
	end,
	["power"] = function(p311, p312) -- name: power
		-- upvalues: (copy) v_u_29, (copy) v_u_15, (copy) v_u_1
		v_u_29(p311, 5, 6, 18, 18, p312, 2.6)
		local v313 = v_u_15(p311, 14, 8, 13, 3, p312, {
			["AnchorPoint"] = nil,
			["Rotation"] = 90,
			["AnchorPoint"] = Vector2.new(0.5, 0.5)
		})
		local v314 = v_u_1.new("UICorner")
		v314.CornerRadius = UDim.new(1, 0)
		v314.Parent = v313
	end,
	["hazard"] = function(p315, p316) -- name: hazard
		-- upvalues: (copy) v_u_15, (copy) v_u_1
		local v317 = v_u_15(p315, 19.25, 13.5, 24.70829334609241, 3, p316, {
			["AnchorPoint"] = nil,
			["Rotation"] = 61.07357416474638,
			["AnchorPoint"] = Vector2.new(0.5, 0.5)
		})
		local v318 = v_u_1.new("UICorner")
		v318.CornerRadius = UDim.new(1, 0)
		v318.Parent = v317
		local v319 = v_u_15(p315, 14, 23, 24, 3, p316, {
			["AnchorPoint"] = nil,
			["Rotation"] = 180,
			["AnchorPoint"] = Vector2.new(0.5, 0.5)
		})
		local v320 = v_u_1.new("UICorner")
		v320.CornerRadius = UDim.new(1, 0)
		v320.Parent = v319
		local v321 = v_u_15(p315, 8.75, 13.5, 24.70829334609241, 3, p316, {
			["AnchorPoint"] = nil,
			["Rotation"] = -61.07357416474638,
			["AnchorPoint"] = Vector2.new(0.5, 0.5)
		})
		local v322 = v_u_1.new("UICorner")
		v322.CornerRadius = UDim.new(1, 0)
		v322.Parent = v321
	end,
	["parking"] = function(p323, p324) -- name: parking
		-- upvalues: (copy) v_u_29, (copy) v_u_1
		v_u_29(p323, 3, 3, 22, 22, p324, 2.4)
		local v325 = v_u_1.new("TextLabel")
		v325.BackgroundTransparency = 1
		v325.Size = UDim2.fromScale(1, 1)
		v325.Font = Enum.Font.GothamBlack
		v325.TextSize = 15
		v325.TextColor3 = p324
		v325.Text = "P"
		v325.Parent = p323
	end,
	["wheelie"] = function(p326, p327) -- name: wheelie
		-- upvalues: (copy) v_u_362
		v_u_362.scooter(p326, p327)
		p326.Rotation = -25
	end,
	["camera"] = function(p328, p329) -- name: camera
		-- upvalues: (copy) v_u_15, (copy) v_u_1
		local v330 = v_u_15(p328, 4.5, 4.5, 9, 9, p329, nil)
		local v331 = v_u_1.new("UICorner")
		v331.CornerRadius = UDim.new(1, 0)
		v331.Parent = v330
		local v332 = v_u_15(v_u_15(p328, 1, 15, 16, 10, p329, {
			["BackgroundTransparency"] = 1,
			["ClipsDescendants"] = true
		}), 0, 0, 16, 18, p329, nil)
		local v333 = v_u_1.new("UICorner")
		v333.CornerRadius = UDim.new(0, 7)
		v333.Parent = v332
		local v334 = v_u_15(p328, 15, 12, 9, 8, p329, nil)
		local v335 = v_u_1.new("UICorner")
		v335.CornerRadius = UDim.new(0, 2)
		v335.Parent = v334
		local v336 = v_u_15(p328, 23, 13.5, 4, 5, p329, nil)
		local v337 = v_u_1.new("UICorner")
		v337.CornerRadius = UDim.new(0, 1)
		v337.Parent = v336
	end,
	["tuck"] = function(p338, p339) -- name: tuck
		-- upvalues: (copy) v_u_15, (copy) v_u_1
		local v340 = v_u_15(p338, 17, 6, 8, 8, p339, nil)
		local v341 = v_u_1.new("UICorner")
		v341.CornerRadius = UDim.new(1, 0)
		v341.Parent = v340
		local v342 = v_u_15(p338, 10.5, 13.5, 16.741664064126333, 3.4, p339, {
			["AnchorPoint"] = nil,
			["Rotation"] = -12.994616791916505,
			["AnchorPoint"] = Vector2.new(0.5, 0.5)
		})
		local v343 = v_u_1.new("UICorner")
		v343.CornerRadius = UDim.new(1, 0)
		v343.Parent = v342
		local v344 = v_u_15(p338, 19, 16.5, 13.23014581273465, 2.6, p339, {
			["AnchorPoint"] = nil,
			["Rotation"] = 41.18592516570965,
			["AnchorPoint"] = Vector2.new(0.5, 0.5)
		})
		local v345 = v_u_1.new("UICorner")
		v345.CornerRadius = UDim.new(1, 0)
		v345.Parent = v344
		local v346 = v_u_15(p338, 5, 19.5, 11.819544457292887, 2.6, p339, {
			["AnchorPoint"] = nil,
			["Rotation"] = 102.52880770915151,
			["AnchorPoint"] = Vector2.new(0.5, 0.5)
		})
		local v347 = v_u_1.new("UICorner")
		v347.CornerRadius = UDim.new(1, 0)
		v347.Parent = v346
		local v348 = v_u_15(p338, 9, 5.5, 7, 2, p339, {
			["AnchorPoint"] = nil,
			["Rotation"] = 90,
			["AnchorPoint"] = Vector2.new(0.5, 0.5)
		})
		local v349 = v_u_1.new("UICorner")
		v349.CornerRadius = UDim.new(1, 0)
		v349.Parent = v348
		local v350 = v_u_15(p338, 7.75, 6.75, 5.535533905932738, 2, p339, {
			["AnchorPoint"] = nil,
			["Rotation"] = -135,
			["AnchorPoint"] = Vector2.new(0.5, 0.5)
		})
		local v351 = v_u_1.new("UICorner")
		v351.CornerRadius = UDim.new(1, 0)
		v351.Parent = v350
		local v352 = v_u_15(p338, 10.25, 6.75, 5.535533905932738, 2, p339, {
			["AnchorPoint"] = nil,
			["Rotation"] = -45,
			["AnchorPoint"] = Vector2.new(0.5, 0.5)
		})
		local v353 = v_u_1.new("UICorner")
		v353.CornerRadius = UDim.new(1, 0)
		v353.Parent = v352
	end,
	["exit"] = function(p354, p355) -- name: exit
		-- upvalues: (copy) v_u_29, (copy) v_u_15, (copy) v_u_1
		v_u_29(p354, 4, 3, 12, 22, p355, 2.4, 2)
		local v356 = v_u_15(p354, 18.5, 14, 15.6, 2.6, p355, {
			["AnchorPoint"] = nil,
			["Rotation"] = 0,
			["AnchorPoint"] = Vector2.new(0.5, 0.5)
		})
		local v357 = v_u_1.new("UICorner")
		v357.CornerRadius = UDim.new(1, 0)
		v357.Parent = v356
		local v358 = v_u_15(p354, 23, 12, 8.256854249492381, 2.6, p355, {
			["AnchorPoint"] = nil,
			["Rotation"] = -135,
			["AnchorPoint"] = Vector2.new(0.5, 0.5)
		})
		local v359 = v_u_1.new("UICorner")
		v359.CornerRadius = UDim.new(1, 0)
		v359.Parent = v358
		local v360 = v_u_15(p354, 23, 16, 8.256854249492381, 2.6, p355, {
			["AnchorPoint"] = nil,
			["Rotation"] = 135,
			["AnchorPoint"] = Vector2.new(0.5, 0.5)
		})
		local v361 = v_u_1.new("UICorner")
		v361.CornerRadius = UDim.new(1, 0)
		v361.Parent = v360
	end
}
v_u_362.mobile = v_u_362.phone
function v_u_362.desktop(p363, p364) -- name: desktop
	-- upvalues: (copy) v_u_15, (copy) v_u_1, (copy) v_u_4
	local v365 = v_u_15(p363, 2, 4, 24, 16, p364, nil)
	local v366 = v_u_1.new("UICorner")
	v366.CornerRadius = UDim.new(0, 3)
	v366.Parent = v365
	local v367 = v_u_15(p363, 4.5, 6.5, 19, 11, p364, nil)
	local v368 = v_u_1.new("UICorner")
	v368.CornerRadius = UDim.new(0, 1.5)
	v368.Parent = v367
	v367.Name = "Hole"
	v367.BackgroundColor3 = v_u_4
	v367.BackgroundTransparency = 0.55
	local v369 = v_u_15(p363, 12, 19.5, 4, 3.5, p364, nil)
	local v370 = v_u_1.new("UICorner")
	v370.CornerRadius = UDim.new(0, 0)
	v370.Parent = v369
	local v371 = v_u_15(p363, 7.5, 22.5, 13, 2.6, p364, nil)
	local v372 = v_u_1.new("UICorner")
	v372.CornerRadius = UDim.new(1, 0)
	v372.Parent = v371
end
function v_u_362.layout(p373, p374) -- name: layout
	-- upvalues: (copy) v_u_15, (copy) v_u_29, (copy) v_u_1
	for _, v375 in {
		{
			0,
			0,
			28,
			16
		},
		{
			0,
			16,
			18.2,
			6
		},
		{
			21.000000000000004,
			16,
			8,
			6
		}
	} do
		v_u_29(v_u_15(p373, v375[1], v375[2], v375[3], v375[4], p374, {
			["BackgroundTransparency"] = 1,
			["ClipsDescendants"] = true
		}), 4.7 - v375[1], 4.5 - v375[2], 18.6, 12.2, p374, 2.2, 1.9)
	end
	v_u_29(v_u_15(p373, 3.8, 6.4, 12, 7, p374, {
		["BackgroundTransparency"] = 1,
		["ClipsDescendants"] = true
	}), 3.1, 3.1, 5.8, 5.8, p374, 2.2)
	local v376 = v_u_15(p373, 10.8, 11.2, 5.324099870362662, 2.2, p374, {
		["AnchorPoint"] = nil,
		["Rotation"] = -50.19442890773481,
		["AnchorPoint"] = Vector2.new(0.5, 0.5)
	})
	local v377 = v_u_1.new("UICorner")
	v377.CornerRadius = UDim.new(1, 0)
	v377.Parent = v376
	local v378 = v_u_15(p373, 8.450000000000001, 11.05, 2.7, 2.7, p374, nil)
	local v379 = v_u_1.new("UICorner")
	v379.CornerRadius = UDim.new(1, 0)
	v379.Parent = v378
	local v380 = v_u_15(p373, 18.9, 7.6, 8.2, 2.2, p374, {
		["AnchorPoint"] = nil,
		["Rotation"] = 0,
		["AnchorPoint"] = Vector2.new(0.5, 0.5)
	})
	local v381 = v_u_1.new("UICorner")
	v381.CornerRadius = UDim.new(1, 0)
	v381.Parent = v380
	local v382 = v_u_15(p373, 16.7, 5.2, 2.4, 4.8, p374, nil)
	local v383 = v_u_1.new("UICorner")
	v383.CornerRadius = UDim.new(1, 0)
	v383.Parent = v382
	local v384 = v_u_15(p373, 19.6, 15.8, 10.2, 2.2, p374, {
		["AnchorPoint"] = nil,
		["Rotation"] = 90,
		["AnchorPoint"] = Vector2.new(0.5, 0.5)
	})
	local v385 = v_u_1.new("UICorner")
	v385.CornerRadius = UDim.new(1, 0)
	v385.Parent = v384
	for _, v386 in {
		{
			0,
			19.3,
			18.2,
			10
		},
		{
			21.000000000000004,
			19.3,
			10,
			10
		},
		{
			0,
			20.4,
			30,
			10
		}
	} do
		v_u_29(v_u_15(p373, v386[1], v386[2], v386[3], v386[4], p374, {
			["BackgroundTransparency"] = 1,
			["ClipsDescendants"] = true
		}), 17.1 - v386[1], 20.400000000000002 - v386[2], 6.2, 2.3999999999999995, p374, 2.2, 1)
	end
	local v387 = v_u_15(p373, 20.200000000000003, 25.6, 9, 2.2, p374, {
		["AnchorPoint"] = nil,
		["Rotation"] = 0,
		["AnchorPoint"] = Vector2.new(0.5, 0.5)
	})
	local v388 = v_u_1.new("UICorner")
	v388.CornerRadius = UDim.new(1, 0)
	v388.Parent = v387
end
function v_u_2.make(p389, p390, p391) -- name: make
	-- upvalues: (copy) v_u_1, (copy) v_u_362, (copy) v_u_3, (copy) v_u_2
	local v392 = v_u_1.new("Frame")
	v392.Name = "Icon_" .. p389
	v392.BackgroundTransparency = 1
	v392.Size = UDim2.fromOffset(28, 28)
	local v393 = v_u_362[p389]
	local v394 = v_u_3[p389]
	if v394 then
		local v395 = v_u_1.new("ImageLabel")
		v395.Name = "Glyph"
		v395.BackgroundTransparency = 1
		v395.Size = UDim2.fromScale(1, 1)
		v395.Image = v_u_2.SHEET
		local v396 = Vector2.new
		local v397 = v394 % 8 * 96
		local v398 = v394 / 8
		v395.ImageRectOffset = v396(v397, math.floor(v398) * 96)
		v395.ImageRectSize = Vector2.new(96, 96)
		v395.ImageColor3 = p390 or Color3.new(1, 1, 1)
		v395.Parent = v392
	elseif v393 then
		v393(v392, p390 or Color3.new(1, 1, 1))
	end
	if p391 and p391 ~= 28 then
		local v399 = v_u_1.new("UIScale")
		v399.Scale = p391 / 28
		v399.Parent = v392
	end
	return v392
end
function v_u_2.tint(p400, p401) -- name: tint
	for _, v402 in p400:GetDescendants() do
		if v402:IsA("Frame") and (v402.BackgroundTransparency < 1 and v402.Name ~= "Hole") then
			v402.BackgroundColor3 = p401
		elseif v402:IsA("UIStroke") then
			v402.Color = p401
		else
			if not v402:IsA("ImageLabel") or v402.Name ~= "Glyph" then
				continue
			end
			v402.ImageColor3 = p401
		end
	end
end
return v_u_2