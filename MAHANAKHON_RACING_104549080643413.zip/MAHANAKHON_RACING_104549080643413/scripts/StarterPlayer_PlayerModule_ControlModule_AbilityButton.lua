-- Path: StarterPlayer/PlayerModule/ControlModule/AbilityButton
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v1 = game:GetService("Players")
local v_u_2 = require(script.Parent.Parent:WaitForChild("CommonUtils")).get("FlagUtil").getUserFlag("UserAbilitiesUserInterfaceD")
local v_u_3 = require(script.Parent:WaitForChild("AvatarAbilitiesInterface")).get(v1.LocalPlayer)
return {
	["create"] = function(p_u_4, p_u_5, p6, p_u_7, p_u_8, p_u_9, p_u_10) -- name: create
		-- upvalues: (copy) v_u_2, (copy) v_u_3
		local v_u_11 = false
		local v_u_12 = false
		local v_u_13 = not p6.ButtonAssetId and "rbxassetid://136780077406114" or p6.ButtonAssetId
		local v_u_14 = not p6.ButtonPressedAssetId and "rbxassetid://76895455502876" or p6.ButtonPressedAssetId
		local v_u_15
		if p6.ButtonInvalidAssetId then
			v_u_15 = p6.ButtonInvalidAssetId
		else
			v_u_15 = nil
		end
		local v_u_16 = Instance.new("ImageButton")
		v_u_16.Name = p_u_5 .. "Button"
		v_u_16.Visible = false
		v_u_16.BackgroundTransparency = 1
		v_u_16.Image = v_u_13
		v_u_16.Parent = p_u_4.parentUIFrame
		for _, v17 in p_u_7:GetChildren() do
			if not (string.find(v17.Name, "Touch") and v17:IsA("InputBinding")) then
				continue
			end
			v17.UIButton = v_u_16
		end
		local function v26() -- name: ResizeButton
			-- upvalues: (copy) p_u_4, (copy) p_u_8, (copy) v_u_16, (copy) p_u_9
			local v18 = p_u_4.parentUIFrame.AbsoluteSize.x
			local v19 = p_u_4.parentUIFrame.AbsoluteSize.y
			local v20 = math.min(v18, v19) <= 500 and p_u_8.small or p_u_8.large
			local v21 = v20[1]
			local v22 = v20[2]
			local v23 = v20[3]
			local v24 = -v22 - v21
			v_u_16.Size = UDim2.new(0, v21, 0, v21)
			if p_u_9 then
				v_u_16.Position = UDim2.new(1, v24, 0, v23)
			else
				local v25 = -v23 - v21
				v_u_16.Position = UDim2.new(1, v24, 1, v25)
			end
		end
		v26()
		local v_u_27 = {}
		local v28 = p_u_4.parentUIFrame:GetPropertyChangedSignal("AbsoluteSize")
		table.insert(v_u_27, v28:Connect(v26))
		local function v_u_39() -- name: UpdateButtonState
			-- upvalues: (copy) v_u_16, (ref) v_u_2, (ref) v_u_3, (copy) p_u_5, (ref) v_u_11, (ref) v_u_12, (copy) p_u_4, (copy) p_u_7, (copy) p_u_10, (ref) v_u_15, (ref) v_u_13, (ref) v_u_14
			if v_u_16.Parent ~= nil then
				if v_u_2 then
					local v29 = v_u_3:GetAbilityUIState(p_u_5)
					local v30 = v_u_11 or v_u_12
					local v31 = v29 == 0
					local v32 = v_u_16
					local v33 = p_u_4.enabled and p_u_7.Enabled
					if v33 then
						v33 = p_u_10 or not v31
					end
					v32.Visible = v33
					if v_u_16.Visible then
						if v29 == 1 or v31 then
							if v_u_15 then
								v_u_16.Image = v_u_15
								v_u_16.ImageTransparency = 0
							else
								v_u_16.Image = v_u_13
								v_u_16.ImageTransparency = 0.6
							end
						elseif v29 == 3 or v30 then
							v_u_16.Image = v_u_14
							v_u_16.ImageTransparency = 0
						else
							v_u_16.Image = v_u_13
							v_u_16.ImageTransparency = 0
						end
					end
				else
					local v34 = v_u_3:GetAbilityValid(p_u_5)
					local v35 = v_u_3:GetAbilityActive(p_u_5)
					local v36 = v_u_11 or v_u_12
					local v37 = v_u_16
					local v38 = p_u_4.enabled
					if v38 then
						v38 = p_u_7.Enabled
					end
					v37.Visible = v38
					if v_u_16.Visible then
						if v35 or v36 and v34 then
							v_u_16.Image = v_u_14
							v_u_16.ImageTransparency = 0
							return
						end
						if v34 then
							v_u_16.Image = v_u_13
							v_u_16.ImageTransparency = 0
							return
						end
						if v_u_15 then
							v_u_16.Image = v_u_15
							v_u_16.ImageTransparency = 0
							return
						end
						v_u_16.Image = v_u_13
						v_u_16.ImageTransparency = 0.6
					end
				end
			end
		end
		v_u_39()
		v_u_16.MouseButton1Down:Connect(function()
			-- upvalues: (ref) v_u_11, (copy) v_u_39
			v_u_11 = true
			v_u_39()
		end)
		v_u_16.MouseButton1Up:Connect(function()
			-- upvalues: (ref) v_u_11, (copy) v_u_39
			v_u_11 = false
			v_u_39()
		end)
		v_u_16.MouseLeave:Connect(function()
			-- upvalues: (ref) v_u_11, (copy) v_u_39
			v_u_11 = false
			v_u_39()
		end)
		if v_u_2 then
			local v40 = v_u_3:GetAbilityUIStateChangedSignal(p_u_5)
			table.insert(v_u_27, v40:Connect(v_u_39))
		else
			local v41 = v_u_3:GetAbilityActiveChangedSignal(p_u_5)
			table.insert(v_u_27, v41:Connect(v_u_39))
			local v42 = v_u_3:GetAbilityValidChangedSignal(p_u_5)
			table.insert(v_u_27, v42:Connect(v_u_39))
		end
		local v43 = p_u_4.enabledChangedEvent.Event
		table.insert(v_u_27, v43:Connect(v_u_39))
		local v44 = p_u_7:GetPropertyChangedSignal("Enabled")
		table.insert(v_u_27, v44:Connect(v_u_39))
		v_u_16.Destroying:Connect(function()
			-- upvalues: (copy) v_u_27
			for _, v45 in v_u_27 do
				v45:Disconnect()
			end
			table.clear(v_u_27)
		end)
		return {
			["instance"] = v_u_16,
			["Destroy"] = function(_) -- name: Destroy
				-- upvalues: (copy) v_u_16
				v_u_16:Destroy()
			end,
			["SetSelectionPressed"] = function(_, p46) -- name: SetSelectionPressed
				-- upvalues: (ref) v_u_12, (copy) p_u_7, (copy) v_u_39
				if v_u_12 ~= p46 then
					v_u_12 = p46
					local v47 = p_u_7:FindFirstChild("SelectionActivateBinding")
					if not v47 then
						v47 = Instance.new("InputBinding")
						v47.Name = "SelectionActivateBinding"
						v47.Type = Enum.InputBindingType.Scriptable
						v47.Parent = p_u_7
					end
					v47:Fire(p46)
					v_u_39()
				end
			end
		}
	end
}