-- Path: ReplicatedStorage/GameUI/ClanWindow
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = require(game:GetService("ReplicatedStorage"):WaitForChild("NetSeal"))
local v_u_2 = game:GetService("Players")
local v_u_3 = game:GetService("ReplicatedStorage")
local v_u_4 = require(v_u_3:WaitForChild("GameShared"))
local v_u_5 = require(v_u_3:WaitForChild("ClanShared"))
local v_u_6 = require(script.Parent:WaitForChild("Theme"))
local v_u_7 = require(script.Parent:WaitForChild("Toast"))
local v8 = {}
local v_u_9 = v_u_2.LocalPlayer
local v_u_10 = v_u_6.isTouch()
local v_u_11 = v_u_10 and 52 or 56
function v8.build(p12) -- name: build
	-- upvalues: (copy) v_u_3, (copy) v_u_4, (copy) v_u_5, (copy) v_u_1, (copy) v_u_7, (copy) v_u_6, (copy) v_u_10, (copy) v_u_11, (copy) v_u_9, (copy) v_u_2
	local v_u_13 = nil
	local function v_u_20(p14, ...) -- name: call
		-- upvalues: (ref) v_u_13, (ref) v_u_3, (ref) v_u_4, (ref) v_u_5, (ref) v_u_1
		v_u_13 = v_u_13 or v_u_3:WaitForChild(v_u_4.REMOTES):WaitForChild(v_u_5.REMOTE, 10)
		if v_u_13 then
			local v15 = v_u_1.invoke
			local v16 = v_u_13
			local v17, v18, v19 = pcall(v15, v16, p14, ...)
			if v17 then
				return v18, v19
			else
				return false, "Couldn\'t reach the server"
			end
		else
			return false, "Clans aren\'t ready yet"
		end
	end
	local v_u_21 = v_u_6.window({
		["name"] = "ClanWindow",
		["gui"] = nil,
		["icon"] = "people",
		["grad"] = "pink",
		["title"] = "Clan",
		["sub"] = nil,
		["max"] = nil,
		["gui"] = p12,
		["sub"] = ("Up to %d people \194\183 a leader and %d co-leaders"):format(v_u_5.MAX_MEMBERS, v_u_5.MAX_CO),
		["max"] = Vector2.new(900, 720)
	})
	local v_u_22 = v_u_10 and 42 or 46
	local v_u_23 = v_u_6.new("Frame", {
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Parent"] = nil,
		["Size"] = UDim2.new(1, 0, 0, v_u_22),
		["Parent"] = v_u_21.body
	})
	local v_u_24 = v_u_6.new("Frame", {
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Position"] = UDim2.fromOffset(0, v_u_22 + 10),
		["Size"] = UDim2.new(1, 0, 1, -(v_u_22 + 10)),
		["Parent"] = v_u_21.body
	})
	local function v27(p25) -- name: scroller
		-- upvalues: (ref) v_u_6, (copy) v_u_24
		local v26 = v_u_6.new("ScrollingFrame", {
			["Name"] = nil,
			["BackgroundTransparency"] = 1,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["CanvasSize"] = nil,
			["AutomaticCanvasSize"] = nil,
			["ScrollingDirection"] = nil,
			["ScrollBarThickness"] = 5,
			["Visible"] = false,
			["Parent"] = nil,
			["Name"] = p25,
			["Size"] = UDim2.fromScale(1, 1),
			["CanvasSize"] = UDim2.new(),
			["AutomaticCanvasSize"] = Enum.AutomaticSize.Y,
			["ScrollingDirection"] = Enum.ScrollingDirection.Y,
			["Parent"] = v_u_24
		})
		v_u_6.new("UIPadding", {
			["PaddingRight"] = UDim.new(0, 8),
			["PaddingBottom"] = UDim.new(0, 12),
			["Parent"] = v26
		})
		v_u_6.new("UIListLayout", {
			["Padding"] = UDim.new(0, 10),
			["SortOrder"] = Enum.SortOrder.LayoutOrder,
			["Parent"] = v26
		})
		return v26
	end
	local v_u_28 = {}
	for _, v29 in {
		"Join",
		"Create",
		"Members",
		"Requests",
		"Settings",
		"Clan"
	} do
		v_u_28[v29] = v27(v29)
	end
	local function v_u_32(p30) -- name: clear
		for _, v31 in p30:GetChildren() do
			if not v31:IsA("GuiObject") then
				continue
			end
			v31:Destroy()
		end
	end
	local function v_u_41(p33, p34, p35) -- name: card
		-- upvalues: (ref) v_u_6
		local v36 = v_u_6.new
		local v37 = "Frame"
		local v38 = {
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.1,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["LayoutOrder"] = nil,
			["Parent"] = nil,
			["BackgroundColor3"] = v_u_6.CARD,
			["Size"] = UDim2.new(1, 0, 0, p35 or 0)
		}
		local v39
		if p35 then
			v39 = Enum.AutomaticSize.None
		else
			v39 = Enum.AutomaticSize.Y
		end
		v38.AutomaticSize = v39
		v38.LayoutOrder = p34
		v38.Parent = p33
		local v40 = v36(v37, v38)
		v_u_6.corner(v40, 14)
		v_u_6.border(v40, Color3.new(1, 1, 1), 0.88, 1)
		v_u_6.padding(v40, 12, 10)
		return v40
	end
	local function v_u_50(p42, p43, p44, p45, p46) -- name: text
		-- upvalues: (ref) v_u_6
		local v47 = v_u_6.text({
			["Text"] = p43,
			["TextSize"] = p44 or 16,
			["TextColor3"] = p45 or v_u_6.TEXT,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["TextTruncate"] = Enum.TextTruncate.AtEnd,
			["Size"] = UDim2.new(1, 0, 0, (p44 or 16) + 6),
			["Parent"] = p42
		})
		for v48, v49 in p46 or {} do
			v47[v48] = v49
		end
		return v47
	end
	local function v_u_59(p51, p52, p53) -- name: box
		-- upvalues: (ref) v_u_6
		local v54 = v_u_6.new("Frame", {
			["BackgroundColor3"] = v_u_6.CARD_DARK,
			["Size"] = UDim2.new(1, 0, 0, 42),
			["LayoutOrder"] = p53,
			["Parent"] = p51
		})
		v_u_6.corner(v54, 10)
		local v_u_55 = v_u_6.border(v54, Color3.new(1, 1, 1), 0.82, 1.2)
		local v56 = v_u_6.new("TextBox", {
			["BackgroundTransparency"] = 1,
			["Text"] = "",
			["PlaceholderText"] = nil,
			["PlaceholderColor3"] = nil,
			["ClearTextOnFocus"] = false,
			["FontFace"] = nil,
			["TextSize"] = 17,
			["TextColor3"] = nil,
			["TextXAlignment"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["PlaceholderText"] = p52,
			["PlaceholderColor3"] = Color3.fromRGB(110, 114, 130),
			["FontFace"] = v_u_6.FONT_BOLD,
			["TextColor3"] = v_u_6.TEXT,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["Position"] = UDim2.fromOffset(12, 0),
			["Size"] = UDim2.new(1, -24, 1, 0),
			["Parent"] = v54
		})
		v56.Focused:Connect(function()
			-- upvalues: (copy) v_u_55, (ref) v_u_6
			local v57 = v_u_55
			v_u_55.Color = v_u_6.YELLOW
			v57.Transparency = 0.2
		end)
		v56.FocusLost:Connect(function()
			-- upvalues: (copy) v_u_55
			local v58 = v_u_55
			v_u_55.Color = Color3.new(1, 1, 1)
			v58.Transparency = 0.82
		end)
		return v56, v54
	end
	local function v_u_66(p60, p61, p62) -- name: logo
		-- upvalues: (ref) v_u_6, (ref) v_u_5
		local v63 = v_u_6.new("ImageLabel", {
			["Name"] = "Logo",
			["BackgroundColor3"] = nil,
			["Image"] = nil,
			["ScaleType"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["BackgroundColor3"] = v_u_6.CARD_DARK,
			["Image"] = v_u_5.logoImage(p61),
			["ScaleType"] = Enum.ScaleType.Crop,
			["Size"] = UDim2.fromOffset(p62, p62),
			["Parent"] = p60
		})
		local v64 = v_u_6.corner
		local v65 = p62 * 0.22
		v64(v63, (math.floor(v65)))
		v_u_6.border(v63, Color3.new(1, 1, 1), 0.8, 1)
		return v63
	end
	local function v_u_74(p67, p68, p69) -- name: actionsOn
		-- upvalues: (ref) v_u_6
		local v70 = v_u_6.new("Frame", {
			["BackgroundTransparency"] = 1,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(1, 0.5),
			["Position"] = UDim2.new(1, 0, 0.5, 0),
			["Size"] = UDim2.fromOffset(0, 38),
			["AutomaticSize"] = Enum.AutomaticSize.X,
			["Parent"] = p67
		})
		v_u_6.new("UIListLayout", {
			["FillDirection"] = Enum.FillDirection.Horizontal,
			["HorizontalAlignment"] = Enum.HorizontalAlignment.Right,
			["Padding"] = UDim.new(0, 6),
			["SortOrder"] = Enum.SortOrder.LayoutOrder,
			["Parent"] = v70
		})
		for v71, v72 in p68 do
			local v73 = v_u_6.button({
				["text"] = nil,
				["grad"] = nil,
				["textSize"] = 14,
				["size"] = nil,
				["parent"] = nil,
				["text"] = v72[1],
				["grad"] = v72[2],
				["size"] = UDim2.fromOffset(p69 or 92, 38),
				["parent"] = v70
			})
			v73.LayoutOrder = v71
			v73.Activated:Connect(v72[3])
		end
		return v70
	end
	local function v_u_89(p75, p76, p77, p_u_78) -- name: swatches
		-- upvalues: (ref) v_u_6, (ref) v_u_5
		local v79 = v_u_6.new("Frame", {
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["LayoutOrder"] = nil,
			["Parent"] = nil,
			["Size"] = UDim2.new(1, 0, 0, 0),
			["AutomaticSize"] = Enum.AutomaticSize.Y,
			["LayoutOrder"] = p76,
			["Parent"] = p75
		})
		v_u_6.new("UIGridLayout", {
			["CellSize"] = UDim2.fromOffset(38, 38),
			["CellPadding"] = UDim2.fromOffset(8, 8),
			["SortOrder"] = Enum.SortOrder.LayoutOrder,
			["Parent"] = v79
		})
		local v_u_80 = {}
		local function v_u_85(p81) -- name: paint
			-- upvalues: (copy) v_u_80, (ref) v_u_6
			for v82, v83 in v_u_80 do
				local v84
				if v82 == p81 then
					v84 = v_u_6.YELLOW
				else
					v84 = Color3.new(1, 1, 1)
				end
				v83.Color = v84
				v83.Transparency = v82 == p81 and 0 or 0.75
				v83.Thickness = v82 == p81 and 3 or 1
			end
		end
		for v_u_86, v87 in v_u_5.TAG_COLORS do
			local v88 = v_u_6.new("TextButton", {
				["Text"] = "",
				["AutoButtonColor"] = false,
				["BackgroundColor3"] = nil,
				["LayoutOrder"] = nil,
				["Parent"] = nil,
				["BackgroundColor3"] = v87,
				["LayoutOrder"] = v_u_86,
				["Parent"] = v79
			})
			v_u_6.corner(v88, 19)
			v_u_80[v_u_86] = v_u_6.new("UIStroke", {
				["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
				["Parent"] = v88
			})
			v88.Activated:Connect(function()
				-- upvalues: (copy) v_u_85, (copy) v_u_86, (copy) p_u_78
				v_u_85(v_u_86)
				p_u_78(v_u_86)
			end)
		end
		v_u_85(p77)
		return v79
	end
	local v_u_90 = nil
	local v_u_91 = nil
	local v_u_92 = nil
	local v_u_93 = nil
	local v_u_94 = nil
	local v_u_95 = {}
	local function v_u_99(p96) -- name: show
		-- upvalues: (ref) v_u_91, (copy) v_u_28, (copy) v_u_95
		v_u_91 = p96
		for v97, v98 in v_u_28 do
			v98.Visible = v97 == p96
		end
		if v_u_95[p96] then
			v_u_95[p96]()
		end
	end
	local function v_u_107(p100) -- name: setTabs
		-- upvalues: (ref) v_u_94, (ref) v_u_92, (ref) v_u_93, (ref) v_u_6, (copy) v_u_23, (copy) v_u_99, (copy) v_u_22, (ref) v_u_91, (copy) v_u_28, (copy) v_u_95
		if p100 ~= v_u_94 then
			v_u_94 = p100
			if v_u_92 then
				v_u_92:Destroy()
			end
			local v101 = p100 == "out" and {
				{
					["id"] = "Join",
					["label"] = "All clans",
					["icon"] = "pin",
					["grad"] = "pink"
				},
				{
					["id"] = "Create",
					["label"] = "Create",
					["icon"] = "plus",
					["grad"] = "pink"
				}
			} or {
				{
					["id"] = "Members",
					["label"] = "Members",
					["icon"] = "people",
					["grad"] = "pink"
				},
				{
					["id"] = "Requests",
					["label"] = "Requests",
					["icon"] = "person",
					["grad"] = "pink"
				},
				{
					["id"] = "Settings",
					["label"] = "Settings",
					["icon"] = "settings",
					["grad"] = "pink"
				}
			}
			if p100 == "in" then
				table.remove(v101, 2)
			end
			if p100 ~= "out" then
				table.insert(v101, {
					["id"] = "Join",
					["label"] = "All clans",
					["icon"] = "pin",
					["grad"] = "pink"
				})
			end
			local v102, v103 = v_u_6.tabs(v_u_23, v101, v_u_99, v_u_22)
			v_u_92 = v102
			v_u_93 = v103
			local v104 = v101[1].id
			v_u_93(v104)
			v_u_91 = v104
			for v105, v106 in v_u_28 do
				v106.Visible = v105 == v104
			end
			if v_u_95[v104] then
				v_u_95[v104]()
			end
		end
	end
	local function v_u_118() -- name: refresh
		-- upvalues: (copy) v_u_20, (ref) v_u_7, (ref) v_u_90, (copy) v_u_21, (ref) v_u_5, (ref) v_u_94, (copy) v_u_107, (ref) v_u_91, (copy) v_u_28, (copy) v_u_95
		local v108, v109 = v_u_20("Get")
		if v108 and type(v109) == "table" then
			v_u_90 = v109
			local v110 = v_u_90.mine
			local v111 = v110 and ((v110.role == "Leader" or v110.role == "Co") and "officer" or "in") or "out"
			local v112 = v_u_21.sub
			local v113
			if v110 then
				v113 = ("[%s] %s \194\183 %d/%d \194\183 %s"):format(v110.tag, v110.name, v110.count, v_u_5.MAX_MEMBERS, v_u_5.ROLES[v110.role].label)
			else
				v113 = ("Up to %d people \194\183 a leader and %d co-leaders"):format(v_u_5.MAX_MEMBERS, v_u_5.MAX_CO)
			end
			v112.Text = v113
			if v111 == v_u_94 then
				if v_u_91 then
					local v114 = v_u_91
					v_u_91 = v114
					for v115, v116 in v_u_28 do
						v116.Visible = v115 == v114
					end
					if v_u_95[v114] then
						v_u_95[v114]()
					end
				end
			else
				v_u_107(v111)
			end
		else
			local v117 = v109 or "Couldn\'t load the clan"
			if v117 then
				v_u_7.show(tostring(v117), "error")
			end
			return
		end
	end
	local v_u_119 = nil
	local v_u_120 = ""
	local v_u_121 = nil
	local function v_u_130(p_u_122, p_u_123) -- name: joinItems
		-- upvalues: (ref) v_u_90, (copy) v_u_20, (ref) v_u_7, (copy) v_u_118, (ref) v_u_5
		return v_u_90 and v_u_90.mine and {} or (p_u_122.invited and {
			{ "Join", "green", function()
					-- upvalues: (ref) v_u_20, (copy) p_u_122, (ref) v_u_7, (ref) v_u_118
					local v124, v125 = v_u_20("Join", p_u_122.id)
					if v125 then
						v_u_7.show(tostring(v125), v124 and "ok" or "error")
					end
					if v124 then
						v_u_118()
					end
				end }
		} or (p_u_122.requested and {
			{ "Cancel", "dark", function()
					-- upvalues: (ref) v_u_20, (copy) p_u_122, (ref) v_u_7, (copy) p_u_123
					local v126, v127 = v_u_20("Cancel", p_u_122.id)
					if v127 then
						v_u_7.show(tostring(v127), v126 and "ok" or "error")
					end
					p_u_123()
				end }
		} or (p_u_122.count >= v_u_5.MAX_MEMBERS and {
			{ "Full", "grey", function() end }
		} or {
			{ "Ask to join", "pink", function()
					-- upvalues: (ref) v_u_20, (copy) p_u_122, (ref) v_u_7, (copy) p_u_123
					local v128, v129 = v_u_20("Request", p_u_122.id)
					if v129 then
						v_u_7.show(tostring(v129), v128 and "ok" or "error")
					end
					p_u_123()
				end }
		})))
	end
	local function v_u_151(p131, p132, p_u_133) -- name: clanCard
		-- upvalues: (copy) v_u_41, (ref) v_u_11, (ref) v_u_6, (ref) v_u_121, (ref) v_u_91, (copy) v_u_28, (copy) v_u_95, (copy) v_u_66, (ref) v_u_90, (copy) v_u_50, (ref) v_u_5, (copy) v_u_130, (copy) v_u_74
		local v134 = v_u_41(p131, p132, v_u_11 + 20)
		v_u_6.new("TextButton", {
			["Name"] = "Open",
			["Text"] = "",
			["BackgroundTransparency"] = 1,
			["ZIndex"] = 0,
			["Size"] = nil,
			["Parent"] = nil,
			["Size"] = UDim2.fromScale(1, 1),
			["Parent"] = v134
		}).Activated:Connect(function()
			-- upvalues: (copy) p_u_133, (ref) v_u_121, (ref) v_u_91, (ref) v_u_28, (ref) v_u_95
			v_u_121 = p_u_133.id
			v_u_91 = "Clan"
			for v135, v136 in v_u_28 do
				v136.Visible = v135 == "Clan"
			end
			if v_u_95.Clan then
				v_u_95.Clan()
			end
		end)
		v_u_66(v134, p_u_133.logo, v_u_11).Position = UDim2.fromOffset(0, 0)
		local v137 = v_u_90 and v_u_90.mine
		if v137 then
			v137 = v_u_90.mine.id == p_u_133.id
		end
		local v138 = v_u_50
		local v139 = p_u_133.tag
		local v140 = p_u_133.color
		local v141 = p_u_133.name
		local v142 = "<font color=\"#%s\">[%s]</font> %s"
		local v143
		if type(v140) == "table" then
			v143 = Color3.fromRGB(v140[1] or 255, v140[2] or 255, v140[3] or 255)
		else
			v143 = Color3.new(1, 1, 1)
		end
		v138(v134, v142:format(v143:ToHex(), tostring(v139):gsub("&", "&amp;"):gsub("<", "&lt;"):gsub(">", "&gt;"), (tostring(v141):gsub("&", "&amp;"):gsub("<", "&lt;"):gsub(">", "&gt;"))) .. (v137 and "  <font color=\"#9ea4b6\">(your clan)</font>" or ""), 18, v_u_6.TEXT, {
			["RichText"] = true,
			["Position"] = nil,
			["Size"] = nil,
			["Position"] = UDim2.fromOffset(v_u_11 + 12, 2),
			["Size"] = UDim2.new(1, -(v_u_11 + 262), 0, 24)
		})
		local v144 = v_u_50
		local v145 = v_u_5.ROLES.Leader.color:ToHex()
		local v146 = p_u_133.leader or "?"
		v144(v134, ("Leader <font color=\"#%s\"><b>%s</b></font>  \194\183  %d/%d members"):format(v145, tostring(v146):gsub("&", "&amp;"):gsub("<", "&lt;"):gsub(">", "&gt;"), p_u_133.count, v_u_5.MAX_MEMBERS), 14, v_u_6.TEXT_DIM, {
			["RichText"] = true,
			["Position"] = nil,
			["Size"] = nil,
			["Position"] = UDim2.fromOffset(v_u_11 + 12, 28),
			["Size"] = UDim2.new(1, -(v_u_11 + 262), 0, 20)
		})
		local v147 = v_u_130(p_u_133, function()
			-- upvalues: (ref) v_u_95
			v_u_95.Join(true)
		end)
		local v150 = { "Members", "dark", function()
				-- upvalues: (copy) p_u_133, (ref) v_u_121, (ref) v_u_91, (ref) v_u_28, (ref) v_u_95
				v_u_121 = p_u_133.id
				v_u_91 = "Clan"
				for v148, v149 in v_u_28 do
					v149.Visible = v148 == "Clan"
				end
				if v_u_95.Clan then
					v_u_95.Clan()
				end
			end }
		table.insert(v147, 1, v150)
		v_u_74(v134, v147, 116)
	end
	function v_u_95.Join(p152) -- name: Join
		-- upvalues: (copy) v_u_28, (copy) v_u_32, (ref) v_u_6, (copy) v_u_59, (ref) v_u_120, (copy) v_u_95, (ref) v_u_119, (copy) v_u_20, (copy) v_u_41, (copy) v_u_50, (ref) v_u_90, (copy) v_u_151
		local v153 = v_u_28.Join
		v_u_32(v153)
		local v154 = v_u_6.new("Frame", {
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["LayoutOrder"] = 1,
			["Parent"] = nil,
			["Size"] = UDim2.new(1, 0, 0, 42),
			["Parent"] = v153
		})
		local v_u_155, v156 = v_u_59(v154, "Find a clan by its name\226\128\166", 1)
		v156.Size = UDim2.new(1, -130, 1, 0)
		v_u_155.Text = v_u_120
		v_u_6.button({
			["text"] = "Search",
			["grad"] = "pink",
			["textSize"] = 15,
			["anchor"] = nil,
			["position"] = nil,
			["size"] = nil,
			["parent"] = nil,
			["anchor"] = Vector2.new(1, 0),
			["position"] = UDim2.fromScale(1, 0),
			["size"] = UDim2.new(0, 122, 1, 0),
			["parent"] = v154
		}).Activated:Connect(function()
			-- upvalues: (ref) v_u_120, (copy) v_u_155, (ref) v_u_95
			v_u_120 = v_u_155.Text
			v_u_95.Join(true)
		end)
		v_u_155.FocusLost:Connect(function(p157)
			-- upvalues: (ref) v_u_120, (copy) v_u_155, (ref) v_u_95
			if p157 then
				v_u_120 = v_u_155.Text
				v_u_95.Join(true)
			end
		end)
		if p152 or not v_u_119 then
			local v158, v159 = v_u_20("Browse", v_u_120)
			v_u_119 = (not v158 or type(v159) ~= "table") and {} or v159
		end
		local v160 = 2
		if #v_u_119 == 0 then
			v_u_50(v_u_41(v153, v160), "No clans yet. Search one by its exact name" .. (v_u_90 and v_u_90.mine and "." or ", or make your own."), 15, v_u_6.TEXT_DIM, {
				["TextWrapped"] = true,
				["Size"] = nil,
				["Size"] = UDim2.new(1, 0, 0, 44)
			})
		end
		for _, v161 in v_u_119 do
			v160 = v160 + 1
			v_u_151(v153, v160, v161)
		end
	end
	function v_u_95.Clan() -- name: Clan
		-- upvalues: (copy) v_u_28, (copy) v_u_32, (ref) v_u_6, (ref) v_u_91, (copy) v_u_95, (ref) v_u_121, (copy) v_u_20, (copy) v_u_41, (copy) v_u_50, (copy) v_u_66, (ref) v_u_90, (ref) v_u_5, (copy) v_u_130, (ref) v_u_119, (copy) v_u_74, (ref) v_u_11, (ref) v_u_9
		local v162 = v_u_28.Clan
		v_u_32(v162)
		local v163 = v_u_6.button({
			["text"] = "\226\128\185  All clans",
			["grad"] = "dark",
			["textSize"] = 15,
			["size"] = nil,
			["parent"] = nil,
			["size"] = UDim2.fromOffset(150, 40),
			["parent"] = v162
		})
		v163.LayoutOrder = 1
		v163.Activated:Connect(function()
			-- upvalues: (ref) v_u_91, (ref) v_u_28, (ref) v_u_95
			v_u_91 = "Join"
			for v164, v165 in v_u_28 do
				v165.Visible = v164 == "Join"
			end
			if v_u_95.Join then
				v_u_95.Join()
			end
		end)
		local v166 = v_u_121
		local v167, v168 = v_u_20("Info", v166)
		if v166 == v_u_121 and v_u_91 == "Clan" then
			if v167 and type(v168) == "table" then
				local v169 = v_u_41(v162, 2, 92)
				v_u_66(v169, v168.logo, 72)
				local v170 = v_u_90 and v_u_90.mine
				if v170 then
					v170 = v_u_90.mine.id == v168.id
				end
				local v171 = v_u_50
				local v172 = v168.tag
				local v173 = v168.color
				local v174 = v168.name
				local v175 = "<font color=\"#%s\">[%s]</font> %s"
				local v176
				if type(v173) == "table" then
					v176 = Color3.fromRGB(v173[1] or 255, v173[2] or 255, v173[3] or 255)
				else
					v176 = Color3.new(1, 1, 1)
				end
				v171(v169, v175:format(v176:ToHex(), tostring(v172):gsub("&", "&amp;"):gsub("<", "&lt;"):gsub(">", "&gt;"), (tostring(v174):gsub("&", "&amp;"):gsub("<", "&lt;"):gsub(">", "&gt;"))) .. (v170 and "  <font color=\"#9ea4b6\">(your clan)</font>" or ""), 22, v_u_6.TEXT, {
					["RichText"] = true,
					["Position"] = nil,
					["Size"] = nil,
					["Position"] = UDim2.fromOffset(86, 4),
					["Size"] = UDim2.new(1, -222, 0, 28)
				})
				local v177 = v_u_50
				local v178 = v_u_5.ROLES.Leader.color:ToHex()
				local v179 = v168.leader or "?"
				v177(v169, ("Leader <font color=\"#%s\"><b>%s</b></font>  \194\183  %d/%d members"):format(v178, tostring(v179):gsub("&", "&amp;"):gsub("<", "&lt;"):gsub(">", "&gt;"), v168.count, v_u_5.MAX_MEMBERS), 16, v_u_6.TEXT_DIM, {
					["RichText"] = true,
					["Position"] = nil,
					["Size"] = nil,
					["Position"] = UDim2.fromOffset(86, 38),
					["Size"] = UDim2.new(1, -222, 0, 22)
				})
				local v180 = v_u_130(v168, function()
					-- upvalues: (ref) v_u_119, (ref) v_u_95
					v_u_119 = nil
					v_u_95.Clan()
				end)
				if #v180 > 0 then
					v_u_74(v169, v180, 124)
				end
				v_u_50(v162, ("Members (%d)"):format(#(v168.members or {})), 17, v_u_6.TEXT, {
					["LayoutOrder"] = 3,
					["FontFace"] = nil,
					["FontFace"] = v_u_6.FONT_HEAVY
				}).Size = UDim2.new(1, 0, 0, 26)
				for v181, v182 in v168.members or {} do
					local v183 = v_u_41(v162, 10 + v181, v_u_11)
					local v184 = v_u_5.ROLES[v182.role] or v_u_5.ROLES.Member
					local v185 = v_u_6.new
					local v186 = "Frame"
					local v187 = {}
					local v188
					if v182.online then
						v188 = Color3.fromRGB(70, 220, 120)
					else
						v188 = Color3.fromRGB(110, 114, 128)
					end
					v187.BackgroundColor3 = v188
					v187.AnchorPoint = Vector2.new(0, 0.5)
					v187.Position = UDim2.new(0, 2, 0.5, 0)
					v187.Size = UDim2.fromOffset(10, 10)
					v187.Parent = v183
					local v189 = v185(v186, v187)
					v_u_6.corner(v189, 5)
					local v190 = v_u_50
					local v191 = v182.name
					v190(v183, tostring(v191):gsub("&", "&amp;"):gsub("<", "&lt;"):gsub(">", "&gt;") .. (v182.id == v_u_9.UserId and "  (you)" or ""), 17, v_u_6.TEXT, {
						["RichText"] = true,
						["AnchorPoint"] = nil,
						["Position"] = nil,
						["Size"] = nil,
						["AnchorPoint"] = Vector2.new(0, 0.5),
						["Position"] = UDim2.new(0, 22, 0.5, -9),
						["Size"] = UDim2.new(1, -30, 0, 22)
					})
					v_u_50(v183, v184.label .. (v182.online and "  \194\183  in this server" or ""), 14, v184.color, {
						["AnchorPoint"] = Vector2.new(0, 0.5),
						["Position"] = UDim2.new(0, 22, 0.5, 11),
						["Size"] = UDim2.new(1, -30, 0, 18)
					})
				end
			else
				v_u_50(v_u_41(v162, 2), tostring(v168 or "Couldn\'t load this clan"), 15, v_u_6.TEXT_DIM, {
					["TextWrapped"] = true,
					["Size"] = nil,
					["Size"] = UDim2.new(1, 0, 0, 44)
				})
			end
		else
			return
		end
	end
	local v_u_192 = 2
	function v_u_95.Create() -- name: Create
		-- upvalues: (copy) v_u_28, (copy) v_u_32, (copy) v_u_41, (ref) v_u_6, (copy) v_u_50, (copy) v_u_59, (ref) v_u_5, (ref) v_u_192, (ref) v_u_9, (copy) v_u_89, (copy) v_u_66, (ref) v_u_90, (ref) v_u_4, (copy) v_u_20, (ref) v_u_7, (copy) v_u_118
		local v193 = v_u_28.Create
		v_u_32(v193)
		local v194 = v_u_41(v193, 1)
		v_u_6.new("UIListLayout", {
			["Padding"] = UDim.new(0, 8),
			["SortOrder"] = Enum.SortOrder.LayoutOrder,
			["Parent"] = v194
		})
		v_u_50(v194, "Clan name", 15, v_u_6.TEXT_DIM, {
			["LayoutOrder"] = 1
		})
		local v_u_195 = v_u_59(v194, ("%d-%d characters"):format(v_u_5.NAME_MIN, v_u_5.NAME_MAX), 2)
		v_u_50(v194, "Tag (in front of your name)", 15, v_u_6.TEXT_DIM, {
			["LayoutOrder"] = 3
		})
		local v_u_196 = v_u_59(v194, ("%d-%d letters or digits, e.g. MHN"):format(v_u_5.TAG_MIN, v_u_5.TAG_MAX), 4)
		v_u_50(v194, "Tag colour", 15, v_u_6.TEXT_DIM, {
			["LayoutOrder"] = 5
		})
		local v_u_197 = v_u_50(v194, "", 20, v_u_6.TEXT, {
			["RichText"] = true,
			["LayoutOrder"] = 7
		})
		local function v202() -- name: updatePreview
			-- upvalues: (ref) v_u_5, (copy) v_u_196, (ref) v_u_192, (copy) v_u_197, (ref) v_u_9
			local v198 = v_u_5.cleanTag(v_u_196.Text) or "TAG"
			local v199 = v_u_197
			local v200 = v_u_5.TAG_COLORS[v_u_192]:ToHex()
			local v201 = v_u_9.Name
			v199.Text = ("<font color=\"#%s\">[%s]</font> %s"):format(v200, v198, (tostring(v201):gsub("&", "&amp;"):gsub("<", "&lt;"):gsub(">", "&gt;")))
		end
		v_u_89(v194, 6, v_u_192, function(p203)
			-- upvalues: (ref) v_u_192, (ref) v_u_5, (copy) v_u_196, (copy) v_u_197, (ref) v_u_9
			v_u_192 = p203
			local v204 = v_u_5.cleanTag(v_u_196.Text) or "TAG"
			local v205 = v_u_197
			local v206 = v_u_5.TAG_COLORS[v_u_192]:ToHex()
			local v207 = v_u_9.Name
			v205.Text = ("<font color=\"#%s\">[%s]</font> %s"):format(v206, v204, (tostring(v207):gsub("&", "&amp;"):gsub("<", "&lt;"):gsub(">", "&gt;")))
		end)
		v_u_196:GetPropertyChangedSignal("Text"):Connect(v202)
		local v208 = v_u_5.cleanTag(v_u_196.Text) or "TAG"
		local v209 = v_u_5.TAG_COLORS[v_u_192]:ToHex()
		local v210 = v_u_9.Name
		v_u_197.Text = ("<font color=\"#%s\">[%s]</font> %s"):format(v209, v208, (tostring(v210):gsub("&", "&amp;"):gsub("<", "&lt;"):gsub(">", "&gt;")))
		v_u_50(v194, "Logo: a Roblox image or decal id (optional). Images that break Roblox\'s rules can\'t be used.", 15, v_u_6.TEXT_DIM, {
			["LayoutOrder"] = 8,
			["TextWrapped"] = true,
			["Size"] = nil,
			["Size"] = UDim2.new(1, 0, 0, 40)
		})
		local v211 = v_u_6.new("Frame", {
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["LayoutOrder"] = 9,
			["Parent"] = nil,
			["Size"] = UDim2.new(1, 0, 0, 56),
			["Parent"] = v194
		})
		local v_u_212, v213 = v_u_59(v211, "e.g. 1234567890", 1)
		v213.Size = UDim2.new(1, -66, 0, 42)
		v213.Position = UDim2.fromOffset(0, 7)
		local v_u_214 = v_u_66(v211, nil, 56)
		v_u_214.AnchorPoint = Vector2.new(1, 0)
		v_u_214.Position = UDim2.fromScale(1, 0)
		v_u_212:GetPropertyChangedSignal("Text"):Connect(function()
			-- upvalues: (copy) v_u_214, (ref) v_u_5, (copy) v_u_212
			v_u_214.Image = v_u_5.logoImage(v_u_5.assetId(v_u_212.Text))
		end)
		local v215 = v_u_90 and v_u_90.cost or v_u_5.CREATE_COST
		local v216 = v_u_6.button({
			["text"] = nil,
			["grad"] = "gold",
			["icon"] = "coin",
			["textSize"] = 17,
			["size"] = nil,
			["parent"] = nil,
			["text"] = ("Create clan  \194\183  \224\184\191%s"):format(v_u_4.formatNumber(v215)),
			["size"] = UDim2.new(1, 0, 0, 48),
			["parent"] = v194
		})
		v216.LayoutOrder = 10
		local v_u_217 = false
		v216.Activated:Connect(function()
			-- upvalues: (ref) v_u_217, (ref) v_u_20, (copy) v_u_195, (copy) v_u_196, (ref) v_u_192, (copy) v_u_212, (ref) v_u_7, (ref) v_u_118
			if not v_u_217 then
				v_u_217 = true
				local v218, v219 = v_u_20("Create", v_u_195.Text, v_u_196.Text, v_u_192, v_u_212.Text)
				if v219 then
					v_u_7.show(tostring(v219), v218 and "ok" or "error")
				end
				v_u_217 = false
				if v218 then
					v_u_118()
				end
			end
		end)
		v_u_50(v194, ("Your money: \224\184\191%s"):format(v_u_4.formatNumber(v_u_9:GetAttribute("Cash") or 0)), 14, v_u_6.TEXT_DIM, {
			["LayoutOrder"] = 11
		})
	end
	function v_u_95.Members() -- name: Members
		-- upvalues: (copy) v_u_28, (copy) v_u_32, (ref) v_u_90, (copy) v_u_41, (copy) v_u_66, (copy) v_u_50, (ref) v_u_6, (ref) v_u_5, (ref) v_u_11, (ref) v_u_9, (copy) v_u_20, (ref) v_u_7, (copy) v_u_118, (copy) v_u_74, (ref) v_u_2
		local v220 = v_u_28.Members
		v_u_32(v220)
		local v221 = v_u_90
		if v221 then
			v221 = v_u_90.mine
		end
		if v221 then
			local v222 = v_u_41(v220, 1, 84)
			v_u_66(v222, v221.logo, 64)
			local v223 = v_u_50
			local v224 = v221.tag
			local v225 = v221.color
			local v226 = v221.name
			local v227 = "<font color=\"#%s\">[%s]</font> %s"
			local v228
			if type(v225) == "table" then
				v228 = Color3.fromRGB(v225[1] or 255, v225[2] or 255, v225[3] or 255)
			else
				v228 = Color3.new(1, 1, 1)
			end
			v223(v222, v227:format(v228:ToHex(), tostring(v224):gsub("&", "&amp;"):gsub("<", "&lt;"):gsub(">", "&gt;"), (tostring(v226):gsub("&", "&amp;"):gsub("<", "&lt;"):gsub(">", "&gt;"))), 22, v_u_6.TEXT, {
				["RichText"] = true,
				["Position"] = nil,
				["Size"] = nil,
				["Position"] = UDim2.fromOffset(78, 6),
				["Size"] = UDim2.new(1, -78, 0, 28)
			})
			v_u_50(v222, ("%d/%d members \194\183 you are %s"):format(v221.count, v_u_5.MAX_MEMBERS, v_u_5.ROLES[v221.role].label), 15, v_u_6.TEXT_DIM, {
				["Position"] = UDim2.fromOffset(78, 38),
				["Size"] = UDim2.new(1, -78, 0, 20)
			})
			local v229 = v_u_5.ROLES[v221.role].level
			for v230, v_u_231 in v221.members do
				local v232 = v_u_41(v220, 10 + v230, v_u_11)
				local v233 = v_u_5.ROLES[v_u_231.role]
				local v234 = v_u_6.new
				local v235 = "Frame"
				local v236 = {}
				local v237
				if v_u_231.online then
					v237 = Color3.fromRGB(70, 220, 120)
				else
					v237 = Color3.fromRGB(110, 114, 128)
				end
				v236.BackgroundColor3 = v237
				v236.AnchorPoint = Vector2.new(0, 0.5)
				v236.Position = UDim2.new(0, 2, 0.5, 0)
				v236.Size = UDim2.fromOffset(10, 10)
				v236.Parent = v232
				local v238 = v234(v235, v236)
				v_u_6.corner(v238, 5)
				local v239 = v_u_50
				local v240 = v_u_231.name
				v239(v232, tostring(v240):gsub("&", "&amp;"):gsub("<", "&lt;"):gsub(">", "&gt;") .. (v_u_231.id == v_u_9.UserId and "  (you)" or ""), 17, v_u_6.TEXT, {
					["RichText"] = true,
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["AnchorPoint"] = Vector2.new(0, 0.5),
					["Position"] = UDim2.new(0, 22, 0.5, -9),
					["Size"] = UDim2.new(1, -260, 0, 22)
				})
				v_u_50(v232, v233.label, 14, v233.color, {
					["AnchorPoint"] = Vector2.new(0, 0.5),
					["Position"] = UDim2.new(0, 22, 0.5, 11),
					["Size"] = UDim2.new(1, -260, 0, 18)
				})
				local v241 = {}
				if v_u_231.id ~= v_u_9.UserId then
					if v221.role == "Leader" and v_u_231.role == "Member" then
						local v244 = { "Co-leader", "cyan", function()
								-- upvalues: (ref) v_u_20, (copy) v_u_231, (ref) v_u_7, (ref) v_u_118
								local v242, v243 = v_u_20("Promote", v_u_231.id)
								if v243 then
									v_u_7.show(tostring(v243), v242 and "ok" or "error")
								end
								if v242 then
									v_u_118()
								end
							end }
						table.insert(v241, v244)
					elseif v221.role == "Leader" and v_u_231.role == "Co" then
						local v247 = { "Member", "dark", function()
								-- upvalues: (ref) v_u_20, (copy) v_u_231, (ref) v_u_7, (ref) v_u_118
								local v245, v246 = v_u_20("Demote", v_u_231.id)
								if v246 then
									v_u_7.show(tostring(v246), v245 and "ok" or "error")
								end
								if v245 then
									v_u_118()
								end
							end }
						table.insert(v241, v247)
					end
					if v233.level < v229 and v229 >= 2 then
						local v250 = { "Kick", "red", function()
								-- upvalues: (ref) v_u_20, (copy) v_u_231, (ref) v_u_7, (ref) v_u_118
								local v248, v249 = v_u_20("Kick", v_u_231.id)
								if v249 then
									v_u_7.show(tostring(v249), v248 and "ok" or "error")
								end
								if v248 then
									v_u_118()
								end
							end }
						table.insert(v241, v250)
					end
				end
				if #v241 <= 0 then
					continue
				end
				v_u_74(v232, v241, 96)
			end
			if v229 >= 2 then
				local v251 = {}
				for _, v252 in v_u_2:GetPlayers() do
					if v252 == v_u_9 or v252:GetAttribute("ClanId") then
						continue
					end
					table.insert(v251, v252)
				end
				v_u_50(v220, "Invite people in this server", 17, v_u_6.TEXT, {
					["LayoutOrder"] = 100,
					["FontFace"] = nil,
					["FontFace"] = v_u_6.FONT_HEAVY
				}).Size = UDim2.new(1, 0, 0, 26)
				if #v251 == 0 then
					v_u_50(v220, "Everyone here is in a clan already.", 15, v_u_6.TEXT_DIM, {
						["LayoutOrder"] = 101
					})
				end
				for v253, v_u_254 in v251 do
					local v255 = v_u_41(v220, 101 + v253, v_u_11)
					local v256 = v_u_50
					local v257 = v_u_254.Name
					v256(v255, tostring(v257):gsub("&", "&amp;"):gsub("<", "&lt;"):gsub(">", "&gt;"), 17, v_u_6.TEXT, {
						["RichText"] = true,
						["AnchorPoint"] = nil,
						["Position"] = nil,
						["Size"] = nil,
						["AnchorPoint"] = Vector2.new(0, 0.5),
						["Position"] = UDim2.new(0, 4, 0.5, 0),
						["Size"] = UDim2.new(1, -140, 0, 22)
					})
					v_u_74(v255, {
						{ "Invite", "pink", function()
								-- upvalues: (ref) v_u_20, (copy) v_u_254, (ref) v_u_7
								local v258, v259 = v_u_20("Invite", v_u_254.UserId)
								if v259 then
									v_u_7.show(tostring(v259), v258 and "ok" or "error")
								end
							end }
					}, 110)
				end
			end
		end
	end
	function v_u_95.Requests() -- name: Requests
		-- upvalues: (copy) v_u_28, (copy) v_u_32, (ref) v_u_90, (copy) v_u_41, (copy) v_u_50, (ref) v_u_6, (ref) v_u_11, (copy) v_u_74, (copy) v_u_20, (ref) v_u_7, (copy) v_u_118
		local v260 = v_u_28.Requests
		v_u_32(v260)
		local v261 = v_u_90
		if v261 then
			v261 = v_u_90.mine
		end
		local v262 = v261 and v261.requests or {}
		if #v262 == 0 then
			v_u_50(v_u_41(v260, 1), "Nobody is asking to join right now.", 15, v_u_6.TEXT_DIM)
		end
		for v263, v_u_264 in v262 do
			local v265 = v_u_41(v260, v263, v_u_11)
			local v266 = v_u_50
			local v267 = v_u_264.name
			v266(v265, tostring(v267):gsub("&", "&amp;"):gsub("<", "&lt;"):gsub(">", "&gt;"), 17, v_u_6.TEXT, {
				["RichText"] = true,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["AnchorPoint"] = Vector2.new(0, 0.5),
				["Position"] = UDim2.new(0, 4, 0.5, 0),
				["Size"] = UDim2.new(1, -220, 0, 22)
			})
			v_u_74(v265, {
				{ "Accept", "green", function()
						-- upvalues: (ref) v_u_20, (copy) v_u_264, (ref) v_u_7, (ref) v_u_118
						local v268, v269 = v_u_20("Accept", v_u_264.id)
						if v269 then
							v_u_7.show(tostring(v269), v268 and "ok" or "error")
						end
						if v268 then
							v_u_118()
						end
					end },
				{ "Decline", "red", function()
						-- upvalues: (ref) v_u_20, (copy) v_u_264, (ref) v_u_7, (ref) v_u_118
						local v270, v271 = v_u_20("Reject", v_u_264.id)
						if v271 then
							v_u_7.show(tostring(v271), v270 and "ok" or "error")
						end
						if v270 then
							v_u_118()
						end
					end }
			}, 96)
		end
	end
	local v_u_272 = 0
	function v_u_95.Settings() -- name: Settings
		-- upvalues: (copy) v_u_28, (copy) v_u_32, (ref) v_u_90, (copy) v_u_41, (ref) v_u_6, (copy) v_u_50, (ref) v_u_5, (copy) v_u_89, (copy) v_u_20, (ref) v_u_7, (copy) v_u_118, (copy) v_u_59, (copy) v_u_66, (ref) v_u_272
		local v273 = v_u_28.Settings
		v_u_32(v273)
		local v274 = v_u_90
		if v274 then
			v274 = v_u_90.mine
		end
		if v274 then
			if v274.role == "Leader" and true or v274.role == "Co" then
				local v275 = v_u_41(v273, 1)
				v_u_6.new("UIListLayout", {
					["Padding"] = UDim.new(0, 8),
					["SortOrder"] = Enum.SortOrder.LayoutOrder,
					["Parent"] = v275
				})
				v_u_50(v275, "Tag colour", 17, v_u_6.TEXT, {
					["LayoutOrder"] = 1,
					["FontFace"] = nil,
					["FontFace"] = v_u_6.FONT_HEAVY
				})
				local v276 = 1
				local v277 = v274.color
				local v278
				if type(v277) == "table" then
					v278 = Color3.fromRGB(v277[1] or 255, v277[2] or 255, v277[3] or 255)
				else
					v278 = Color3.new(1, 1, 1)
				end
				for v279, v280 in v_u_5.TAG_COLORS do
					if v280:ToHex() ~= v278:ToHex() then
						continue
					end
					v276 = v279
				end
				v_u_89(v275, 2, v276, function(p281)
					-- upvalues: (ref) v_u_20, (ref) v_u_7, (ref) v_u_118
					local v282, v283 = v_u_20("Color", p281)
					if v283 then
						v_u_7.show(tostring(v283), v282 and "ok" or "error")
					end
					if v282 then
						v_u_118()
					end
				end)
			end
			if v274.role == "Leader" then
				local v284 = v_u_41(v273, 2)
				v_u_6.new("UIListLayout", {
					["Padding"] = UDim.new(0, 8),
					["SortOrder"] = Enum.SortOrder.LayoutOrder,
					["Parent"] = v284
				})
				v_u_50(v284, "Logo", 17, v_u_6.TEXT, {
					["LayoutOrder"] = 1,
					["FontFace"] = nil,
					["FontFace"] = v_u_6.FONT_HEAVY
				})
				v_u_50(v284, "A Roblox image or decal id. Images that break Roblox\'s rules can\'t be used.", 14, v_u_6.TEXT_DIM, {
					["LayoutOrder"] = 2,
					["TextWrapped"] = true,
					["Size"] = nil,
					["Size"] = UDim2.new(1, 0, 0, 36)
				})
				local v285 = v_u_6.new("Frame", {
					["BackgroundTransparency"] = 1,
					["Size"] = nil,
					["LayoutOrder"] = 3,
					["Parent"] = nil,
					["Size"] = UDim2.new(1, 0, 0, 56),
					["Parent"] = v284
				})
				local v_u_286, v287 = v_u_59(v285, "Image id", 1)
				v287.Size = UDim2.new(1, -196, 0, 42)
				v287.Position = UDim2.fromOffset(0, 7)
				local v288
				if v274.logo then
					local v289 = v274.logo
					v288 = tostring(v289)
				else
					v288 = ""
				end
				v_u_286.Text = v288
				local v_u_290 = v_u_66(v285, v274.logo, 56)
				v_u_290.AnchorPoint = Vector2.new(1, 0)
				v_u_290.Position = UDim2.new(1, -124, 0, 0)
				v_u_286:GetPropertyChangedSignal("Text"):Connect(function()
					-- upvalues: (copy) v_u_290, (ref) v_u_5, (copy) v_u_286
					v_u_290.Image = v_u_5.logoImage(v_u_5.assetId(v_u_286.Text))
				end)
				v_u_6.button({
					["text"] = "Save",
					["grad"] = "pink",
					["textSize"] = 15,
					["anchor"] = nil,
					["position"] = nil,
					["size"] = nil,
					["parent"] = nil,
					["anchor"] = Vector2.new(1, 0),
					["position"] = UDim2.new(1, 0, 0, 7),
					["size"] = UDim2.fromOffset(112, 42),
					["parent"] = v285
				}).Activated:Connect(function()
					-- upvalues: (ref) v_u_20, (copy) v_u_286, (ref) v_u_7, (ref) v_u_118
					local v291, v292 = v_u_20("Logo", v_u_286.Text)
					if v292 then
						v_u_7.show(tostring(v292), v291 and "ok" or "error")
					end
					if v291 then
						v_u_118()
					end
				end)
			end
			local v293 = v_u_41(v273, 3)
			v_u_6.new("UIListLayout", {
				["Padding"] = UDim.new(0, 8),
				["SortOrder"] = Enum.SortOrder.LayoutOrder,
				["Parent"] = v293
			})
			local v294 = v_u_6.button({
				["text"] = "Leave clan",
				["grad"] = "dark",
				["icon"] = "exit",
				["textSize"] = 16,
				["size"] = nil,
				["parent"] = nil,
				["size"] = UDim2.new(1, 0, 0, 44),
				["parent"] = v293
			})
			v294.LayoutOrder = 1
			v294.Activated:Connect(function()
				-- upvalues: (ref) v_u_20, (ref) v_u_7, (ref) v_u_118
				local v295, v296 = v_u_20("Leave")
				if v296 then
					v_u_7.show(tostring(v296), v295 and "ok" or "error")
				end
				if v295 then
					v_u_118()
				end
			end)
			if v274.role == "Leader" then
				v_u_50(v293, "Leaving hands the clan to a co-leader (or the longest member).", 14, v_u_6.TEXT_DIM, {
					["LayoutOrder"] = 2,
					["TextWrapped"] = true,
					["Size"] = nil,
					["Size"] = UDim2.new(1, 0, 0, 36)
				})
				local v297, v_u_298 = v_u_6.button({
					["text"] = "Disband clan",
					["grad"] = "red",
					["icon"] = "trash",
					["textSize"] = 16,
					["size"] = nil,
					["parent"] = nil,
					["size"] = UDim2.new(1, 0, 0, 44),
					["parent"] = v293
				})
				v297.LayoutOrder = 3
				v297.Activated:Connect(function()
					-- upvalues: (ref) v_u_272, (copy) v_u_298, (ref) v_u_20, (ref) v_u_7, (ref) v_u_118
					if os.clock() - v_u_272 > 3 then
						v_u_272 = os.clock()
						v_u_298.Text = "Press again to disband for good"
					else
						v_u_272 = 0
						local v299, v300 = v_u_20("Disband")
						if v300 then
							v_u_7.show(tostring(v300), v299 and "ok" or "error")
						end
						if v299 then
							v_u_118()
						end
					end
				end)
			end
		end
	end
	local v_u_302 = {
		["setOpen"] = function(p301) -- name: setOpen
			-- upvalues: (copy) v_u_21, (ref) v_u_119, (copy) v_u_118
			v_u_21.setOpen(p301)
			if p301 then
				v_u_119 = nil
				task.spawn(v_u_118)
			end
		end,
		["isOpen"] = function() -- name: isOpen
			-- upvalues: (copy) v_u_21
			return v_u_21.isOpen()
		end,
		["toggle"] = function() -- name: toggle
			-- upvalues: (copy) v_u_302, (copy) v_u_21
			v_u_302.setOpen(not v_u_21.isOpen())
		end
	}
	local v_u_303 = false
	v_u_9:GetAttributeChangedSignal("ClanStamp"):Connect(function()
		-- upvalues: (copy) v_u_21, (ref) v_u_303, (ref) v_u_119, (copy) v_u_118
		if v_u_21.isOpen() and not v_u_303 then
			v_u_303 = true
			task.delay(0.3, function()
				-- upvalues: (ref) v_u_303, (ref) v_u_21, (ref) v_u_119, (ref) v_u_118
				v_u_303 = false
				if v_u_21.isOpen() then
					v_u_119 = nil
					v_u_118()
				end
			end)
		end
	end)
	return v_u_302
end
return v8