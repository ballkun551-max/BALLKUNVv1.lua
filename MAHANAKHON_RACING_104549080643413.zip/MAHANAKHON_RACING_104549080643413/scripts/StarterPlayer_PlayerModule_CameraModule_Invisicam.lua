-- Path: StarterPlayer/PlayerModule/CameraModule/Invisicam
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = game:GetService("Players")
local v2 = require(script.Parent.Parent:WaitForChild("CommonUtils")).get("FlagUtil")
local v_u_3 = v2.getUserFlag("UserRaycastUpdateAPI2")
local v_u_4 = v2.getUserFlag("UserPlayerModuleEngineAPI")
local v_u_5 = {
	["LIMBS"] = 2,
	["MOVEMENT"] = 3,
	["CORNERS"] = 4,
	["CIRCLE1"] = 5,
	["CIRCLE2"] = 6,
	["LIMBMOVE"] = 7,
	["SMART_CIRCLE"] = 8,
	["CHAR_OUTLINE"] = 9
}
local v_u_6 = {
	["Head"] = true,
	["Left Arm"] = true,
	["Right Arm"] = true,
	["Left Leg"] = true,
	["Right Leg"] = true,
	["LeftLowerArm"] = true,
	["RightLowerArm"] = true,
	["LeftUpperLeg"] = true,
	["RightUpperLeg"] = true
}
local v_u_7 = {
	Vector3.new(1, 1, -1),
	Vector3.new(1, -1, -1),
	Vector3.new(-1, -1, -1),
	Vector3.new(-1, 1, -1)
}
local v_u_8 = RaycastParams.new()
v_u_8.FilterType = Enum.RaycastFilterType.Exclude
local v_u_9 = RaycastParams.new()
v_u_9.FilterType = Enum.RaycastFilterType.Include
local function v_u_17(p10, ...) -- name: AssertTypes
	local v11 = {}
	local v12 = ""
	for _, v13 in pairs({ ... }) do
		v11[v13] = true
		v12 = v12 .. (v12 == "" and "" or " or ") .. v13
	end
	local v14 = type(p10)
	local v15 = v11[v14]
	local v16 = v12 .. " type expected, got: " .. v14
	assert(v15, v16)
end
local function v_u_53(p18, p19, p20, p21) -- name: RayIntersection
	local v22 = p19:Cross(p21)
	local v23 = p20.X - p18.X
	local v24 = p20.Y - p18.Y
	local v25 = p20.Z - p18.Z
	local v26 = p19.X
	local v27 = -p21.X
	local v28 = v22.X
	local v29 = p19.Y
	local v30 = -p21.Y
	local v31 = v22.Y
	local v32 = p19.Z
	local v33 = -p21.Z
	local v34 = v22.Z
	local v35 = v26 * (v30 * v34 - v31 * v33) - v27 * (v29 * v34 - v31 * v32) + v28 * (v29 * v33 - v30 * v32)
	if v35 == 0 then
		return Vector3.new(0, 0, 0)
	end
	local v36 = -p21.X
	local v37 = v22.X
	local v38 = -p21.Y
	local v39 = v22.Y
	local v40 = -p21.Z
	local v41 = v22.Z
	local v42 = (v23 * (v38 * v41 - v39 * v40) - v36 * (v24 * v41 - v39 * v25) + v37 * (v24 * v40 - v38 * v25)) / v35
	local v43 = p19.X
	local v44 = v22.X
	local v45 = p19.Y
	local v46 = v22.Y
	local v47 = p19.Z
	local v48 = v22.Z
	local v49 = (v43 * (v24 * v48 - v46 * v25) - v23 * (v45 * v48 - v46 * v47) + v44 * (v45 * v25 - v24 * v47)) / v35
	local v50 = p18 + v42 * p19
	local v51 = p20 + v49 * p21
	local v52 = v50 + (v51 - v50) * 0.5
	return (v51 - v50).Magnitude >= 0.25 and Vector3.new(0, 0, 0) or v52
end
local v_u_54 = require(script.Parent:WaitForChild("BaseOcclusion"))
local v_u_55 = setmetatable({}, v_u_54)
v_u_55.__index = v_u_55
function v_u_55.new() -- name: new
	-- upvalues: (copy) v_u_54, (copy) v_u_55, (copy) v_u_5
	local v56 = v_u_54.new()
	local v57 = v_u_55
	local v58 = setmetatable(v56, v57)
	v58.char = nil
	v58.humanoidRootPart = nil
	v58.torsoPart = nil
	v58.headPart = nil
	v58.childAddedConn = nil
	v58.childRemovedConn = nil
	v58.behaviors = {}
	v58.behaviors[v_u_5.LIMBS] = v58.LimbBehavior
	v58.behaviors[v_u_5.MOVEMENT] = v58.MoveBehavior
	v58.behaviors[v_u_5.CORNERS] = v58.CornerBehavior
	v58.behaviors[v_u_5.CIRCLE1] = v58.CircleBehavior
	v58.behaviors[v_u_5.CIRCLE2] = v58.CircleBehavior
	v58.behaviors[v_u_5.LIMBMOVE] = v58.LimbMoveBehavior
	v58.behaviors[v_u_5.SMART_CIRCLE] = v58.SmartCircleBehavior
	v58.behaviors[v_u_5.CHAR_OUTLINE] = v58.CharacterOutlineBehavior
	v58.mode = v_u_5.SMART_CIRCLE
	v58.behaviorFunction = v58.SmartCircleBehavior
	v58.savedHits = {}
	v58.trackedLimbs = {}
	v58.camera = game.Workspace.CurrentCamera
	v58.enabled = false
	return v58
end
function v_u_55.Enable(p59, p60) -- name: Enable
	p59.enabled = p60
	if not p60 then
		p59:Cleanup()
	end
end
function v_u_55.GetOcclusionMode(_) -- name: GetOcclusionMode
	return Enum.DevCameraOcclusionMode.Invisicam
end
function v_u_55.LimbBehavior(p61, p62) -- name: LimbBehavior
	for v63, _ in pairs(p61.trackedLimbs) do
		p62[#p62 + 1] = v63.Position
	end
end
function v_u_55.MoveBehavior(p64, p65) -- name: MoveBehavior
	for v66 = 1, 3 do
		local v67 = p64.humanoidRootPart.Position
		local v68 = p64.humanoidRootPart.Velocity
		local v69 = v68.X
		local v70 = v68.Z
		local v71 = Vector3.new(v69, 0, v70).Magnitude / 2
		local v72 = (v66 - 1) * p64.humanoidRootPart.CFrame.lookVector * v71
		p65[#p65 + 1] = v67 + v72
	end
end
function v_u_55.CornerBehavior(p73, p74) -- name: CornerBehavior
	-- upvalues: (copy) v_u_7
	local v75 = p73.humanoidRootPart.CFrame
	local v76 = v75.Position
	local v77 = v75 - v76
	local v78 = p73.char:GetExtentsSize() / 2
	p74[#p74 + 1] = v76
	for v79 = 1, #v_u_7 do
		p74[#p74 + 1] = v76 + v77 * (v78 * v_u_7[v79])
	end
end
function v_u_55.CircleBehavior(p80, p81) -- name: CircleBehavior
	-- upvalues: (copy) v_u_5
	local v82
	if p80.mode == v_u_5.CIRCLE1 then
		v82 = p80.humanoidRootPart.CFrame
	else
		local v83 = p80.camera.CoordinateFrame
		v82 = v83 - v83.Position + p80.humanoidRootPart.Position
	end
	p81[#p81 + 1] = v82.Position
	for v84 = 0, 9 do
		local v85 = 0.6283185307179586 * v84
		local v86 = math.cos(v85)
		local v87 = math.sin(v85)
		local v88 = Vector3.new(v86, v87, 0) * 3
		p81[#p81 + 1] = v82 * v88
	end
end
function v_u_55.LimbMoveBehavior(p89, p90) -- name: LimbMoveBehavior
	p89:LimbBehavior(p90)
	p89:MoveBehavior(p90)
end
function v_u_55.CharacterOutlineBehavior(p91, p92) -- name: CharacterOutlineBehavior
	-- upvalues: (copy) v_u_3, (copy) v_u_9
	local v93 = p91.torsoPart.CFrame.upVector.unit
	local v94 = p91.torsoPart.CFrame.rightVector.unit
	p92[#p92 + 1] = p91.torsoPart.CFrame.Position
	p92[#p92 + 1] = p91.torsoPart.CFrame.Position + v93
	p92[#p92 + 1] = p91.torsoPart.CFrame.Position - v93
	p92[#p92 + 1] = p91.torsoPart.CFrame.Position + v94
	p92[#p92 + 1] = p91.torsoPart.CFrame.Position - v94
	if p91.headPart then
		p92[#p92 + 1] = p91.headPart.CFrame.Position
	end
	local v95 = CFrame.new
	local v96 = p91.camera.CoordinateFrame.lookVector.X
	local v97 = p91.camera.CoordinateFrame.lookVector.Z
	local v98 = v95(Vector3.new(0, 0, 0), (Vector3.new(v96, 0, v97)))
	local v99 = p91.torsoPart and p91.torsoPart.Position or p91.humanoidRootPart.Position
	local v100 = { p91.torsoPart }
	if p91.headPart then
		v100[#v100 + 1] = p91.headPart
	end
	for v101 = 1, 24 do
		local v102 = 6.283185307179586 * v101 / 24
		local v103 = math.cos(v102)
		local v104 = math.sin(v102)
		local v105 = v98 * (Vector3.new(v103, v104, 0) * 3)
		local v106 = v105.X
		local v107 = v105.Y
		local v108 = math.max(v107, -2.25)
		local v109 = v105.Z
		local v110 = Vector3.new(v106, v108, v109)
		if v_u_3 then
			v_u_9.FilterDescendantsInstances = v100
			local v111 = game.Workspace:Raycast(v99 + v110, -3 * v110, v_u_9)
			if not v111 then
				continue
			end
			local v112 = v111.Position
			p92[#p92 + 1] = v112 + 0.2 * (v99 - v112).unit
		else
			local v113 = Ray.new(v99 + v110, -3 * v110)
			local v114, v115 = game.Workspace:FindPartOnRayWithWhitelist(v113, v100, false)
			if not v114 then
				continue
			end
			p92[#p92 + 1] = v115 + 0.2 * (v99 - v115).unit
		end
	end
end
function v_u_55.SmartCircleBehavior(p116, p117) -- name: SmartCircleBehavior
	-- upvalues: (copy) v_u_3, (copy) v_u_8, (copy) v_u_53
	local v118 = p116.torsoPart.CFrame.upVector.unit
	local v119 = p116.torsoPart.CFrame.rightVector.unit
	p117[#p117 + 1] = p116.torsoPart.CFrame.Position
	p117[#p117 + 1] = p116.torsoPart.CFrame.Position + v118
	p117[#p117 + 1] = p116.torsoPart.CFrame.Position - v118
	p117[#p117 + 1] = p116.torsoPart.CFrame.Position + v119
	p117[#p117 + 1] = p116.torsoPart.CFrame.Position - v119
	if p116.headPart then
		p117[#p117 + 1] = p116.headPart.CFrame.Position
	end
	local v120 = p116.camera.CFrame - p116.camera.CFrame.Position
	local v121 = Vector3.new(0, 0.5, 0) + (p116.torsoPart and p116.torsoPart.Position or p116.humanoidRootPart.Position)
	for v122 = 1, 24 do
		local v123 = 0.2617993877991494 * v122 - 1.5707963267948966
		local v124 = math.cos(v123)
		local v125 = math.sin(v123)
		local v126 = v121 + v120 * (Vector3.new(v124, v125, 0) * 2.5)
		local v127 = v126 - p116.camera.CFrame.Position
		if v_u_3 then
			v_u_8.FilterDescendantsInstances = { p116.char }
			local v128 = game.Workspace:Raycast(v121, v126 - v121, v_u_8)
			if v128 then
				local v129 = v128.Position
				local v130 = v128.Normal
				local v131 = v129 + 0.1 * v130.unit
				local v132 = v131 - v121
				local v133 = v132:Cross(v127).unit:Cross(v130).unit
				local v134 = (v131 - p116.camera.CFrame.Position).unit
				if v132.unit:Dot(-v133) < v132.unit:Dot(v134) then
					v126 = v_u_53(v131, v133, v126, v127)
					if v126.Magnitude > 0 then
						local v135 = game.Workspace:Raycast(v131, v126 - v131, v_u_8)
						if v135 then
							v126 = v135.Position + 0.1 * v135.Normal.Unit
						end
					else
						v126 = v131
					end
				else
					v126 = v131
				end
				local v136 = game.Workspace:Raycast(v121, v126 - v121, v_u_8)
				if v136 then
					v126 = v136.Position - 0.1 * (v126 - v121).unit
				end
			end
			p117[#p117 + 1] = v126
		else
			local v137 = Ray.new(v121, v126 - v121)
			local v138, v139, v140 = game.Workspace:FindPartOnRayWithIgnoreList(v137, { p116.char }, false, false)
			if v138 then
				local v141 = v139 + 0.1 * v140.unit
				local v142 = v141 - v121
				local v143 = v142:Cross(v127).unit:Cross(v140).unit
				local v144 = (v141 - p116.camera.CFrame.Position).unit
				if v142.unit:Dot(-v143) < v142.unit:Dot(v144) then
					v126 = v_u_53(v141, v143, v126, v127)
					if v126.Magnitude > 0 then
						local v145 = Ray.new(v141, v126 - v141)
						local v146, v147, v148 = game.Workspace:FindPartOnRayWithIgnoreList(v145, { p116.char }, false, false)
						if v146 then
							v126 = v147 + 0.1 * v148.unit
						end
					else
						v126 = v141
					end
				else
					v126 = v141
				end
				local v149 = Ray.new(v121, v126 - v121)
				local v150, v151 = game.Workspace:FindPartOnRayWithIgnoreList(v149, { p116.char }, false, false)
				if v150 then
					v126 = v151 - 0.1 * (v126 - v121).unit
				end
			end
			p117[#p117 + 1] = v126
		end
	end
end
function v_u_55.CheckTorsoReference(p152) -- name: CheckTorsoReference
	if p152.char then
		p152.torsoPart = p152.char:FindFirstChild("Torso")
		if not p152.torsoPart then
			p152.torsoPart = p152.char:FindFirstChild("UpperTorso")
			if not p152.torsoPart then
				p152.torsoPart = p152.char:FindFirstChild("HumanoidRootPart")
			end
		end
		p152.headPart = p152.char:FindFirstChild("Head")
	end
end
function v_u_55.CharacterAdded(p_u_153, p154, p155) -- name: CharacterAdded
	-- upvalues: (copy) v_u_1, (copy) v_u_6
	if p155 == v_u_1.LocalPlayer then
		if p_u_153.childAddedConn then
			p_u_153.childAddedConn:Disconnect()
			p_u_153.childAddedConn = nil
		end
		if p_u_153.childRemovedConn then
			p_u_153.childRemovedConn:Disconnect()
			p_u_153.childRemovedConn = nil
		end
		p_u_153.char = p154
		p_u_153.trackedLimbs = {}
		local function v157(p156) -- name: childAdded
			-- upvalues: (ref) v_u_6, (copy) p_u_153
			if p156:IsA("BasePart") then
				if v_u_6[p156.Name] then
					p_u_153.trackedLimbs[p156] = true
				end
				if p156.Name == "Torso" or p156.Name == "UpperTorso" then
					p_u_153.torsoPart = p156
				end
				if p156.Name == "Head" then
					p_u_153.headPart = p156
				end
			end
		end
		p_u_153.childAddedConn = p154.ChildAdded:Connect(v157)
		p_u_153.childRemovedConn = p154.ChildRemoved:Connect(function(p158) -- name: childRemoved
			-- upvalues: (copy) p_u_153
			p_u_153.trackedLimbs[p158] = nil
			p_u_153:CheckTorsoReference()
		end)
		for _, v159 in pairs(p_u_153.char:GetChildren()) do
			if not v159:IsA("BasePart") then
				continue
			end
			if v_u_6[v159.Name] then
				p_u_153.trackedLimbs[v159] = true
			end
			if v159.Name == "Torso" or v159.Name == "UpperTorso" then
				p_u_153.torsoPart = v159
			end
			if v159.Name ~= "Head" then
				continue
			end
			p_u_153.headPart = v159
		end
	end
end
function v_u_55.SetMode(p160, p161) -- name: SetMode
	-- upvalues: (copy) v_u_17, (copy) v_u_5
	v_u_17(p161, "number")
	for _, v162 in pairs(v_u_5) do
		if v162 ~= p161 then
			continue
		end
		p160.mode = p161
		p160.behaviorFunction = p160.behaviors[p160.mode]
		return
	end
	error("Invalid mode number")
end
function v_u_55.GetObscuredParts(p163) -- name: GetObscuredParts
	return p163.savedHits
end
function v_u_55.Cleanup(p164) -- name: Cleanup
	for v165, v166 in pairs(p164.savedHits) do
		v165.LocalTransparencyModifier = v166
	end
end
function v_u_55.Update(p_u_167, _, p168, p169, p170) -- name: Update
	-- upvalues: (copy) v_u_4
	local v171 = p170.engineInterface
	local v172 = v171.player
	local v173 = v171.character
	if v_u_4 and (v171.characterChanged and (v172 and v173)) then
		p_u_167:CharacterAdded(v173, v172)
	end
	if not (p_u_167.enabled and p_u_167.char) then
		return p168, p169
	end
	p_u_167.camera = game.Workspace.CurrentCamera
	if not p_u_167.humanoidRootPart then
		local v174 = p_u_167.char:FindFirstChildOfClass("Humanoid")
		if v174 and v174.RootPart then
			p_u_167.humanoidRootPart = v174.RootPart
		else
			p_u_167.humanoidRootPart = p_u_167.char:FindFirstChild("HumanoidRootPart")
			if not p_u_167.humanoidRootPart then
				return p168, p169
			end
		end
		local v_u_175 = nil
		v_u_175 = p_u_167.humanoidRootPart.AncestryChanged:Connect(function(p176, p177)
			-- upvalues: (copy) p_u_167, (ref) v_u_175
			if p176 == p_u_167.humanoidRootPart and not p177 then
				p_u_167.humanoidRootPart = nil
				if v_u_175 and v_u_175.Connected then
					v_u_175:Disconnect()
					v_u_175 = nil
				end
			end
		end)
	end
	if not p_u_167.torsoPart then
		p_u_167:CheckTorsoReference()
		if not p_u_167.torsoPart then
			return p168, p169
		end
	end
	local v178 = {}
	p_u_167.behaviorFunction(p_u_167, v178)
	local v179 = { p_u_167.char }
	local v180 = p_u_167.headPart and p_u_167.headPart.CFrame.Position or v178[1]
	local v181 = p_u_167.torsoPart and p_u_167.torsoPart.CFrame.Position or v178[2]
	local v182 = p_u_167.camera:GetPartsObscuringTarget({ v180, v181 }, v179)
	local v183 = 0
	local v184 = {}
	local v185 = 0.75
	local v186 = {}
	local v187 = 0.75
	for v188 = 1, #v182 do
		local v189 = v182[v188]
		v183 = v183 + 1
		v184[v189] = true
		for _, v190 in pairs(v189:GetChildren()) do
			if not (v190:IsA("Decal") or v190:IsA("Texture")) then
				continue
			end
			v183 = v183 + 1
		end
	end
	if v183 > 0 then
		local v191 = 0.375 / v183 + 0.375
		local v192 = 1 / v183
		v185 = math.pow(v191, v192)
		local v193 = 0.25 / v183 + 0.25
		local v194 = 1 / v183
		v187 = math.pow(v193, v194)
	end
	local v195 = p_u_167.camera:GetPartsObscuringTarget(v178, v179)
	local v196 = {}
	for v197 = 1, #v195 do
		local v198 = v195[v197]
		v196[v198] = v184[v198] and v185 and v185 or v187
		if v198.Transparency < v196[v198] then
			v186[v198] = true
			if not p_u_167.savedHits[v198] then
				p_u_167.savedHits[v198] = v198.LocalTransparencyModifier
			end
		end
		for _, v199 in pairs(v198:GetChildren()) do
			if not (v199:IsA("Decal") or v199:IsA("Texture")) or v199.Transparency >= v196[v198] then
				continue
			end
			v196[v199] = v196[v198]
			v186[v199] = true
			if p_u_167.savedHits[v199] then
				continue
			end
			p_u_167.savedHits[v199] = v199.LocalTransparencyModifier
		end
	end
	for v200, v201 in pairs(p_u_167.savedHits) do
		if v186[v200] then
			v200.LocalTransparencyModifier = v200.Transparency < 1 and ((v196[v200] - v200.Transparency) / (1 - v200.Transparency) or 0) or 0
		else
			v200.LocalTransparencyModifier = v201
			p_u_167.savedHits[v200] = nil
		end
	end
	return p168, p169
end
return v_u_55