-- Path: StarterPlayer/PlayerModule/InputSampler
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v1 = game:GetService("Players")
local v_u_2 = game:GetService("Workspace")
local v_u_3 = UserSettings():GetService("UserGameSettings")
local v4 = require(script.Parent:WaitForChild("CommonUtils"))
require(script.Parent.Types)
local v5 = v4.get("FlagUtil")
local v6 = v5.getUserFlag("UserPlayerScriptsCCLIntegrationD") or v5.getUserFlag("UserPlayerScriptsCCLIntegrationDGA")
local v_u_7 = v5.getUserFlag("UserPlayerScriptsPlayerControlState2") or v5.getUserFlag("UserPlayerScriptsPlayerControlState2GA")
local v_u_8 = v5.getUserFlag("UserAbilitiesUserInterfaceB")
local v_u_9 = v5.getUserFlag("UserControlModuleDisabledUpdate")
local v_u_10 = v5.getUserFlag("UserPlayerModuleEngineAPI")
local v11 = require(script.Parent:WaitForChild("ControlModule"):WaitForChild("AvatarAbilitiesInterface"))
local v_u_12
if v6 then
	v_u_12 = v11.get(v1.LocalPlayer)
else
	v_u_12 = nil
end
local v_u_13 = v_u_8 and "ControlState" or "PlayerControlState"
local v_u_14 = {}
v_u_14.__index = v_u_14
function v_u_14.new() -- name: new
	-- upvalues: (copy) v_u_14
	local v15 = v_u_14
	return setmetatable({
		["controlData"] = {
			["enabled"] = true,
			["isJumping"] = false,
			["worldMoveVector"] = Vector3.new(0, 0, 0)
		}
	}, v15)
end
function v_u_14.Update(p16, p17) -- name: Update
	-- upvalues: (copy) v_u_9, (copy) v_u_7, (copy) v_u_10, (copy) v_u_8, (copy) v_u_13, (copy) v_u_3, (copy) v_u_2, (copy) v_u_12
	if v_u_9 then
		local v18 = p17.engineInterface.player
		if v18 then
			if v_u_7 then
				local v19
				if v_u_10 then
					v19 = p17.engineInterface.character
				else
					v19 = v18.Character
				end
				if v19 then
					local v20
					if v_u_8 then
						v20 = v19:FindFirstChildOfClass(v_u_13)
					else
						v20 = v19:FindFirstChild(v_u_13)
					end
					if v20 then
						local v21
						if v_u_10 then
							v21 = p17.engineInterface.humanoid
						else
							v21 = v19:FindFirstChildOfClass("Humanoid")
						end
						if v21 then
							local v22 = v_u_3.RotationType == Enum.RotationType.CameraRelative
							local v23 = v_u_2.CurrentCamera and v_u_2.CurrentCamera.CFrame.LookVector or Vector3.new(0, 0, 1)
							local v24 = v23.X
							local v25 = v23.Z
							local v26 = Vector3.new(v24, 0, v25)
							local v27 = {
								["RotateToLookDirection"] = v22,
								["LookDirection"] = v26.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v26.Unit
							}
							if p17.controlModule.enabled or p16.controlData.enabled then
								v27.Move = p17.controlModule.worldMoveVector
								if not (v_u_12 and v_u_12:isEnabled()) then
									v27.Jump = p17.controlModule.isJumping
								end
							end
							p16.controlData.enabled = p17.controlModule.enabled
							p16.controlData.isJumping = p17.controlModule.isJumping
							p16.controlData.worldMoveVector = p17.controlModule.worldMoveVector
							v20:UpdateFields(v27)
						end
					else
						return
					end
				else
					return
				end
			else
				if p17.isServerAuthority then
					local v28 = v18:FindFirstChild("InputContexts")
					if not v28 then
						return
					end
					local v29 = v28:FindFirstChild("CharacterContext")
					if not v29 then
						return
					end
					local v30 = v29:FindFirstChild("RotationAction")
					local v31 = v30 and v30:FindFirstChild("RotationScriptableBinding")
					if v31 then
						v31:Fire(v_u_3.RotationType == Enum.RotationType.CameraRelative)
					end
				end
				return
			end
		else
			return
		end
	else
		return
	end
end
return v_u_14