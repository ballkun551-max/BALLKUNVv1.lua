-- Path: Players/ygggggg55551/PlayerScripts/AnimatedWaterClient
-- Class: LocalScript  true/Enum.RunContext.Legacy
-- Decompiled by BALL KUN Universal Map Dump

local v1 = game:GetService("CollectionService")
local v2 = 1
while true do
	task.wait(0.03333333333333333)
	v2 = v2 % 25 + 1
	local v3 = workspace.CurrentCamera
	if v3 then
		v3 = v3.CFrame.Position
	end
	if not v3 then
		continue
	end
	local v4 = string.format("rbxasset://textures/water/normal_%02d.dds", v2)
	for _, v5 in v1:GetTagged("AnimatedWater") do
		if not v5:IsA("BasePart") or (v5.Position - v3).Magnitude >= 300 then
			continue
		end
		for _, v6 in v5:GetChildren() do
			if not v6:IsA("Texture") then
				continue
			end
			v6.Texture = v4
		end
	end
end