-- Path: Players/ygggggg55551/PlayerScripts/KitCarClient
-- Class: LocalScript  true/Enum.RunContext.Legacy
-- Decompiled by BALL KUN Universal Map Dump

local v1 = game:GetService("CollectionService")
local v2 = game:GetService("Players")
local v_u_3 = game:GetService("ReplicatedStorage")
local v4 = game:GetService("RunService")
local v_u_5 = game:GetService("Lighting")
local v_u_6 = require(v_u_3:WaitForChild("CarShared"))
local v_u_7 = require(v_u_3:WaitForChild("NetSeal"))
local v_u_8 = v_u_3:WaitForChild("KitCarRemote")
local v_u_9 = v2.LocalPlayer
local v_u_10 = Color3.fromRGB(255, 165, 25)
local v_u_11 = Color3.fromRGB(110, 0, 0)
local v_u_12 = Color3.fromRGB(255, 20, 20)
local v_u_13 = Color3.fromRGB(255, 165, 50)
local v_u_14 = Color3.fromRGB(255, 195, 60)
local v_u_15 = Color3.fromRGB(220, 120, 20)
local v_u_16 = {}
local function v20(p17, ...) -- name: S
	local v18 = {}
	for _, v19 in ipairs({ ... }) do
		v18[v19] = true
	end
	return {
		["c"] = p17,
		["on"] = v18
	}
end
local v21 = {
	["c"] = 1,
	["on"] = nil,
	["on"] = {}
}
v_u_16.Modes = {
	{
		["id"] = "SideSwap",
		["rate"] = 3,
		["duty"] = 0.85,
		["steps"] = nil,
		["steps"] = { v20(1, "FL", "RL"), v20(2, "FR", "RR") }
	},
	{
		["id"] = "FrontBack",
		["rate"] = 3,
		["duty"] = 0.85,
		["steps"] = nil,
		["steps"] = { v20(1, "FL", "FR"), v20(2, "RL", "RR") }
	},
	{
		["id"] = "Cross",
		["rate"] = 3,
		["duty"] = 0.85,
		["steps"] = nil,
		["steps"] = { v20(1, "FL", "RR"), v20(2, "FR", "RL") }
	},
	{
		["id"] = "Circle",
		["rate"] = 5,
		["duty"] = 0.9,
		["steps"] = nil,
		["steps"] = {
			v20(1, "FL"),
			v20(2, "FR"),
			v20(1, "RR"),
			v20(2, "RL")
		}
	},
	{
		["id"] = "PingPong",
		["rate"] = 6,
		["duty"] = 0.9,
		["steps"] = nil,
		["steps"] = {
			v20(1, "FL"),
			v20(2, "FR"),
			v20(1, "RR"),
			v20(2, "RL"),
			v20(1, "RR"),
			v20(2, "FR")
		}
	},
	{
		["id"] = "Double",
		["rate"] = 8,
		["duty"] = 0.8,
		["steps"] = nil,
		["steps"] = {
			v20(1, "FL", "RL"),
			v21,
			v20(1, "FL", "RL"),
			v21,
			v20(2, "FR", "RR"),
			v21,
			v20(2, "FR", "RR"),
			v21
		}
	},
	{
		["id"] = "Police",
		["rate"] = 10,
		["duty"] = 0.8,
		["steps"] = nil,
		["steps"] = {
			v20(1, "FL", "RL"),
			v21,
			v20(1, "FL", "RL"),
			v21,
			v20(1, "FL", "RL"),
			v21,
			v20(2, "FR", "RR"),
			v21,
			v20(2, "FR", "RR"),
			v21,
			v20(2, "FR", "RR"),
			v21
		}
	},
	{
		["id"] = "Build",
		["rate"] = 4,
		["duty"] = 1,
		["steps"] = nil,
		["steps"] = {
			v20(1, "FL"),
			v20(1, "FL", "FR"),
			v20(1, "FL", "FR", "RR"),
			v20(1, "FL", "FR", "RR", "RL"),
			v20(2, "FL", "FR", "RR", "RL"),
			v21
		}
	},
	{
		["id"] = "Flash",
		["rate"] = 4,
		["duty"] = 0.5,
		["steps"] = nil,
		["steps"] = { v20(1, "FL", "FR", "RL", "RR"), v20(2, "FL", "FR", "RL", "RR") }
	},
	{
		["id"] = "Strobe",
		["rate"] = 14,
		["duty"] = 0.45,
		["steps"] = nil,
		["steps"] = { v20(1, "FL", "FR", "RL", "RR"), v21 }
	},
	{
		["id"] = "ColorSwap",
		["smooth"] = true
	},
	{
		["id"] = "Rainbow",
		["smooth"] = true
	},
	{
		["id"] = "Breathe",
		["smooth"] = true
	},
	{
		["id"] = "Solid",
		["smooth"] = true
	}
}
v_u_16.ById = {}
local v_u_22 = {
	["FrontGuide"] = true,
	["FrontGuideBack"] = true,
	["RearBar"] = true,
	["RearBottomBar"] = true,
	["FrontSignal"] = true,
	["RowHalf"] = true
}
local function v_u_24(p23) -- name: pedals
	-- upvalues: (copy) v_u_9
	if p23:GetAttribute("DriverId") == v_u_9.UserId and p23:GetAttribute("LocalBraking") ~= nil then
		return p23:GetAttribute("LocalBraking") == true, p23:GetAttribute("LocalReversing") == true
	else
		return p23:GetAttribute("Braking") == true, p23:GetAttribute("Reversing") == true
	end
end
for _, v25 in ipairs(v_u_16.Modes) do
	v_u_16.ById[v25.id] = v25
end
local v_u_26 = {
	["FL"] = 0,
	["FR"] = 0.25,
	["RR"] = 0.5,
	["RL"] = 0.75
}
function v_u_16.evaluate(p27, p28, p29, p30, p31, p32) -- name: evaluate
	-- upvalues: (copy) v_u_16, (copy) v_u_26
	local v33 = v_u_16.ById[p27] or v_u_16.Modes[1]
	local v34
	if p32 then
		v34 = p31 or p30
	else
		v34 = p30
	end
	if v33.id == "Solid" then
		return p30, 1
	elseif v33.id == "Breathe" then
		local v35 = p28 * 3.141592653589793 * 0.9
		return p30, (0.5 - math.cos(v35) * 0.5) * 0.92 + 0.08
	elseif v33.id == "Rainbow" then
		local v36 = Color3.fromHSV
		local v37 = p28 * 0.25 + (v_u_26[p29] or 0)
		return v36(v37 - math.floor(v37), 1, 1), 1
	elseif v33.id == "ColorSwap" then
		local v38 = p28 * 3.141592653589793 * 0.8
		return p30:Lerp(v34, 0.5 - math.cos(v38) * 0.5), 1
	else
		local v39 = p28 * v33.rate
		local v40 = v33.steps[math.floor(v39) % #v33.steps + 1]
		if v40.on[p29] then
			if v39 - math.floor(v39) > v33.duty then
				return p30, 0
			else
				return v40.c == 2 and v34 and v34 or p30, 1
			end
		else
			return p30, 0
		end
	end
end
local function v_u_49(p41, p42) -- name: collectHalos
	p42.halos = {}
	for _, v43 in p41:GetDescendants() do
		if not (v43:IsA("BasePart") and v43:GetAttribute("HaloSet")) then
			continue
		end
		local v44 = v43:FindFirstChildWhichIsA("SurfaceGui")
		if not v44 then
			continue
		end
		local v45 = {}
		for _, v46 in v44:GetDescendants() do
			if not v46:IsA("ImageLabel") then
				continue
			end
			table.insert(v45, v46)
		end
		v44.Enabled = false
		local v47 = p42.halos
		local v48 = {
			["part"] = v43,
			["gui"] = v44,
			["labels"] = v45,
			["set"] = v43:GetAttribute("HaloSet"),
			["side"] = v43:GetAttribute("HaloSide") or "Left",
			["bright"] = v43:GetAttribute("HaloBrightness") or 2,
			["back"] = v44.Face == Enum.NormalId.Back
		}
		table.insert(v47, v48)
	end
end
local function v_u_64(p50, p51, p52) -- name: setHalo
	local v53
	if p51 == nil then
		v53 = false
	else
		v53 = p52 > 0.02
	end
	if p50.on ~= v53 then
		p50.on = v53
		p50.gui.Enabled = v53
	end
	if v53 then
		local v54 = p50.bright * p52 * 50 + 0.5
		local v55 = math.floor(v54) / 50
		if p50.b ~= v55 then
			p50.b = v55
			p50.gui.Brightness = v55
		end
		local v56 = Color3.new
		local v57 = p51.R * 48 + 0.5
		local v58 = math.floor(v57) / 48
		local v59 = p51.G * 48 + 0.5
		local v60 = math.floor(v59) / 48
		local v61 = p51.B * 48 + 0.5
		local v62 = v56(v58, v60, math.floor(v61) / 48)
		if p50.color ~= v62 then
			p50.color = v62
			for _, v63 in p50.labels do
				v63.ImageColor3 = v62
			end
		end
	end
end
local v_u_65 = {}
local function v_u_88(p66, p67) -- name: collectSlices
	-- upvalues: (copy) v_u_49, (copy) v_u_22, (copy) v_u_15
	p67.slices = {}
	p67.backs = {}
	v_u_49(p66, p67)
	for _, v68 in p66:GetDescendants() do
		if not v68:IsA("BasePart") then
			continue
		end
		local v69 = v68:GetAttribute("KitKind")
		if v69 == "Back" then
			local v70 = p67.backs
			local v71 = {
				["part"] = v68,
				["set"] = v68:GetAttribute("KitBackSet") or "RearLower"
			}
			table.insert(v70, v71)
		elseif v69 == "Sliced" then
			v68.Transparency = 1
		else
			if not v_u_22[v68:GetAttribute("FlowSet")] then
				continue
			end
			local v72 = v68:GetAttribute("FlowU") or 0
			local v73 = p67.slices
			local v74 = {
				["part"] = v68,
				["set"] = v68:GetAttribute("FlowSet"),
				["side"] = v68:GetAttribute("FlowSide") or "Left",
				["u"] = v72,
				["u0"] = v68:GetAttribute("FlowU0") or v72,
				["u1"] = v68:GetAttribute("FlowU1") or v72,
				["color"] = v68:GetAttribute("BaseColor") or v68.Color,
				["material"] = Enum.Material[v68:GetAttribute("BaseMaterial") or v68.Material.Name],
				["transparency"] = v68:GetAttribute("BaseTransparency") or v68.Transparency
			}
			table.insert(v73, v74)
		end
	end
	p67.piecesLight = #p67.slices > 0
	p67.rowHalves = false
	for _, v75 in p67.slices do
		if v75.set ~= "RowHalf" then
			continue
		end
		p67.rowHalves = true
	end
	p67.lens = {}
	local v76 = p66:FindFirstChild("KitFlowParts")
	if v76 then
		for _, v77 in p67.slices do
			if v77.set ~= "FrontSignal" then
				continue
			end
			local v78 = p67.lens[v77.side]
			if not v78 then
				local v79 = "FrontSignalLens_" .. v77.side
				local v80 = v76:FindFirstChild(v79) or Instance.new("Model")
				v80.Name = v79
				v80.Parent = v76
				v78 = {
					["holder"] = v80
				}
				local v81 = v80:FindFirstChildOfClass("Highlight") or Instance.new("Highlight")
				v81.Adornee = v80
				v81.OutlineTransparency = 1
				v81.DepthMode = Enum.HighlightDepthMode.Occluded
				v81.FillColor = v_u_15
				v81.FillTransparency = 0.1
				v81.Parent = v80
				v78.hl = v81
				v78.groups = {}
				p67.lens[v77.side] = v78
			end
			local v82 = v77.u * 5
			local v83 = math.floor(v82) + 1
			local v84 = math.clamp(v83, 1, 5)
			v77.lensGroup = v84
			local v85 = v78.groups[v84]
			if not v85 then
				local v86 = v78.holder:FindFirstChild("Piece" .. v84) or Instance.new("Model")
				v86.Name = "Piece" .. v84
				v86.Parent = v78.holder
				v85 = {
					["holder"] = v86
				}
				local v87 = v86:FindFirstChildOfClass("Highlight") or Instance.new("Highlight")
				v87.Adornee = v86
				v87.OutlineTransparency = 1
				v87.DepthMode = Enum.HighlightDepthMode.Occluded
				v87.FillColor = v_u_15
				v87.FillTransparency = 0.1
				v87.Parent = v86
				v85.hl = v87
				v85.hl.Enabled = false
				v78.groups[v84] = v85
			end
			if v77.part.Parent == v85.holder then
				continue
			end
			v77.part.Parent = v85.holder
		end
	end
end
local function v_u_97(p89) -- name: groupSteps
	table.sort(p89, function(p90, p91)
		return p90.seq < p91.seq
	end)
	local v92 = nil
	local v93 = {}
	for _, v94 in p89 do
		if v94.seq ~= v92 then
			table.insert(v93, {})
			v92 = v94.seq
		end
		local v95 = v93[#v93]
		local v96 = v94.part
		table.insert(v95, v96)
	end
	return v93
end
local function v130(p98) -- name: track
	-- upvalues: (copy) v_u_65, (copy) v_u_97, (copy) v_u_88
	if v_u_65[p98] or not p98:IsA("Model") then
		return
	elseif p98:GetAttribute("KitLights") == true or p98:GetAttribute("KitBackfire") == true then
		local v_u_99 = {
			["model"] = nil,
			["chassis"] = nil,
			["parts"] = nil,
			["steps"] = nil,
			["fx"] = nil,
			["beams"] = nil,
			["hood"] = nil,
			["hoodOpen"] = 0,
			["signalStart"] = nil,
			["model"] = p98,
			["chassis"] = p98:FindFirstChild("Chassis"),
			["parts"] = {},
			["steps"] = {
				["Signal"] = {
					["Left"] = {},
					["Right"] = {}
				},
				["Tail"] = {
					["Left"] = {},
					["Right"] = {}
				}
			},
			["fx"] = {},
			["beams"] = {},
			["signalStart"] = os.clock()
		}
		local v100 = {
			["Signal"] = {
				["Left"] = {},
				["Right"] = {}
			},
			["Tail"] = {
				["Left"] = {},
				["Right"] = {}
			}
		}
		for _, v101 in p98:GetDescendants() do
			if v101:IsA("BasePart") and v101:GetAttribute("KitLamp") then
				local v102 = v101:GetAttribute("KitKind")
				local v103 = v101:GetAttribute("KitSide")
				if not (v100[v102] and v100[v102][v103]) then
					continue
				end
				v_u_99.parts[v101] = {
					["kind"] = v102,
					["side"] = v103,
					["color"] = v101.Color,
					["material"] = v101.Material,
					["light"] = v101:FindFirstChildWhichIsA("Light"),
					["twin"] = v101:GetAttribute("KitTwin") == true
				}
				local v104 = v100[v102][v103]
				local v105 = {
					["seq"] = v101:GetAttribute("KitSeq") or 0,
					["part"] = v101
				}
				table.insert(v104, v105)
			elseif v101:IsA("Light") and v101:GetAttribute("KitBeam") then
				local v106 = v_u_99.beams
				table.insert(v106, v101)
			else
				if not v101:IsA("BasePart") or (not v101:GetAttribute("Area") or (not v101.Parent or v101.Parent.Name ~= "RungFX")) then
					continue
				end
				local v107 = v101:FindFirstChild("Source")
				local v108 = v_u_99.fx
				local v109 = {
					["part"] = v101,
					["area"] = v101:GetAttribute("Area")
				}
				if v107 then
					v107 = v107.Value
				end
				v109.source = v107
				table.insert(v108, v109)
				v101.Transparency = 1
			end
		end
		for v110, v111 in v100 do
			for v112, v113 in v111 do
				v_u_99.steps[v110][v112] = v_u_97(v113)
			end
		end
		local v114 = v_u_99.chassis
		if v114 then
			v114 = v_u_99.chassis:FindFirstChild("BonnetMotor")
		end
		if v114 then
			v_u_99.hood = {
				["motor"] = v114,
				["base"] = v114:GetAttribute("BaseC0") or v114.C0,
				["angle"] = v114:GetAttribute("OpenAngle") or 0.8726646259971648,
				["sign"] = v114:GetAttribute("OpenSign") or 1
			}
			v_u_99.hoodOpen = 0
		end
		v_u_99.conn = p98:GetAttributeChangedSignal("Indicator"):Connect(function()
			-- upvalues: (copy) v_u_99
			v_u_99.signalStart = os.clock()
		end)
		local v115 = {
			["beams"] = nil,
			["parts"] = nil,
			["backs"] = nil,
			["slices"] = nil,
			["rowCovered"] = false,
			["splitSignal"] = nil,
			["beams"] = {},
			["parts"] = {},
			["backs"] = {},
			["slices"] = {},
			["splitSignal"] = p98:GetAttribute("RearSignalSides") == true
		}
		local v116 = p98:FindFirstChild("KitFlow")
		if v116 then
			for _, v117 in v116:GetChildren() do
				if not v117:IsA("Beam") then
					continue
				end
				local v118 = v117:GetAttribute("FlowU0") or 0
				local v119 = v117:GetAttribute("FlowU1") or 0
				local v120 = v117:GetAttribute("FlowSet")
				local v121 = v115.beams
				local v122 = {
					["beam"] = v117,
					["set"] = v120,
					["side"] = v117:GetAttribute("FlowSide"),
					["baseU0"] = v118,
					["baseU1"] = v119,
					["u0"] = v118,
					["u1"] = v119,
					["emission"] = v117.LightEmission,
					["brightness"] = v117.Brightness,
					["w0"] = v117.Width0,
					["w1"] = v117.Width1
				}
				table.insert(v121, v122)
				if v120 ~= "RearSignal" then
					continue
				end
				v115.rowCovered = true
			end
		end
		for _, v123 in p98:GetDescendants() do
			if not v123:IsA("BasePart") or v123:GetAttribute("FlowSet") ~= "RearRow" then
				continue
			end
			local v124 = not v_u_99.chassis and 0 or v_u_99.chassis.CFrame:PointToObjectSpace(v123.Position).X
			local v125 = math.abs(v124) < 0.5 and "None" or (v124 > 0 and "Right" or "Left")
			local v126 = v115.parts
			local v127 = {
				["part"] = v123,
				["u"] = v123:GetAttribute("FlowU") or 0,
				["side"] = v125,
				["color"] = v123.Color,
				["material"] = v123.Material,
				["bright"] = v123:GetAttribute("TailBright") == true
			}
			table.insert(v126, v127)
		end
		v_u_88(p98, v115)
		v_u_99.sliceConn = p98:GetAttributeChangedSignal("KitSlicesReady"):Connect(function()
			-- upvalues: (copy) v_u_99
			v_u_99.slicesDirty = true
		end)
		v_u_99.sliceAdded = p98.DescendantAdded:Connect(function(p128)
			-- upvalues: (copy) v_u_99
			if p128:IsA("BasePart") and p128:GetAttribute("FlowSet") then
				v_u_99.slicesDirty = true
			end
		end)
		v_u_99.sliceAdded = p98.DescendantAdded:Connect(function(p129)
			-- upvalues: (copy) v_u_99
			if p129:IsA("BasePart") and p129:GetAttribute("FlowSet") then
				v_u_99.slicesDirty = true
			end
		end)
		if #v115.beams > 0 or (#v115.parts > 0 or (#v115.backs > 0 or (#v115.slices > 0 or (#v115.halos > 0 or p98:GetAttribute("VehicleId") == "FL5B")))) then
			v_u_99.flow = v115
		end
		v_u_65[p98] = v_u_99
	end
end
local function v133(p131) -- name: untrack
	-- upvalues: (copy) v_u_65
	local v132 = v_u_65[p131]
	if v132 then
		v132.conn:Disconnect()
		if v132.sliceConn then
			v132.sliceConn:Disconnect()
		end
		if v132.sliceAdded then
			v132.sliceAdded:Disconnect()
		end
		if v132.sliceAdded then
			v132.sliceAdded:Disconnect()
		end
		v_u_65[p131] = nil
	end
end
local function v_u_146(p134, p135, p136) -- name: litSegments
	if p135 == "Off" then
		return
	else
		local v137 = (os.clock() - p134.signalStart) % 0.95
		if v137 < 0.6 then
			for _, v138 in { "Left", "Right" } do
				if p135 ~= v138 and p135 ~= "Hazard" then
					continue
				end
				for _, v139 in { "Signal", "Tail" } do
					local v140 = p134.steps[v139][v138]
					local v141 = #v140
					local v142 = v141 <= 1 and 0 or 0.32 / (v141 - 1)
					for v143, v144 in v140 do
						if (v143 - 1) * v142 > v137 then
							continue
						end
						for _, v145 in v144 do
							p136[v145] = true
						end
					end
				end
			end
		end
	end
end
local v_u_147 = Color3.fromRGB(235, 242, 255)
local v_u_148 = Color3.fromRGB(150, 0, 0)
local v_u_149 = Color3.fromRGB(255, 15, 15)
local v_u_150 = Color3.fromRGB(255, 25, 25)
local v_u_151 = Color3.fromRGB(255, 244, 228)
local v_u_152 = Color3.fromRGB(14, 3, 3)
local v_u_153 = Color3.fromRGB(7, 5, 8)
local v_u_154 = {
	{ 0.17, 0.25 },
	{ 0.5, 0.5 },
	{ 0.83, 0.25 }
}
local v_u_155 = nil
local function v_u_201(p_u_156, p_u_157, p158, p_u_159, p_u_160, p_u_161, p_u_162) -- name: paintBeam
	-- upvalues: (copy) v_u_147, (copy) v_u_10, (copy) v_u_152
	if p_u_157 == "cover" then
		local v163 = p_u_156.emission
		local v164 = p_u_156.brightness
		if p_u_156.beam.LightEmission ~= v163 then
			p_u_156.beam.LightEmission = v163
		end
		if p_u_156.beam.Brightness ~= v164 then
			p_u_156.beam.Brightness = v164
		end
	else
		local v165 = p_u_156.set == "Front" and 1 or 0
		local v166 = p_u_156.brightness
		local v167 = math.max(v166, 2)
		if p_u_156.beam.LightEmission ~= v165 then
			p_u_156.beam.LightEmission = v165
		end
		if p_u_156.beam.Brightness ~= v167 then
			p_u_156.beam.Brightness = v167
		end
	end
	if p_u_157 == "white" or p_u_157 == "solid" then
		if p_u_157 == "white" then
			p158 = v_u_147
		end
		if p_u_156.kind ~= p_u_157 or p_u_156.solid ~= p158 then
			p_u_156.beam.Color = ColorSequence.new(p158)
			p_u_156.beam.Transparency = NumberSequence.new(0)
			p_u_156.alpha = 0
		end
		p_u_156.solid = p158
		p_u_156.keys = nil
		p_u_156.kind = p_u_157
		return
	else
		p_u_156.solid = nil
		local function v183(p168) -- name: at
			-- upvalues: (copy) p_u_157, (ref) v_u_10, (copy) p_u_161, (copy) p_u_162, (ref) v_u_152, (copy) p_u_159, (copy) p_u_156, (copy) p_u_160
			if p_u_157 == "signal" then
				local v169 = v_u_10
				local v170 = p_u_161
				local v171 = p_u_162
				local v172
				if v170 then
					local v173 = (v170 / 0.3 * 1.25 - p168) / 0.25
					local v174 = math.clamp(v173, 0, 1)
					v172 = v174 * v174 * (3 - 2 * v174) * v171
				else
					v172 = 0
				end
				return v169, 1 - v172
			elseif p_u_157 == "cover" then
				local v175 = v_u_152
				local v176 = v_u_10
				local v177 = p_u_161
				local v178 = p_u_162
				local v179
				if v177 then
					local v180 = (v177 / 0.3 * 1.25 - p168) / 0.25
					local v181 = math.clamp(v180, 0, 1)
					v179 = v181 * v181 * (3 - 2 * v181) * v178
				else
					v179 = 0
				end
				return v175:Lerp(v176, v179), 0
			else
				local v182 = p_u_159(p168, p_u_156.side, p_u_160)
				if v182 then
					return v182, 0
				else
					return v_u_152, 1
				end
			end
		end
		local v184 = p_u_156.u1 - p_u_156.u0
		local v185 = math.abs(v184)
		local v186
		if v185 < 0.001 then
			v186 = 1
		else
			local v187 = v185 / 0.035
			local v188 = math.ceil(v187) + 1
			v186 = math.clamp(v188, 2, 20)
		end
		local v189 = table.create(v186)
		local v190 = table.create(v186)
		local v191
		if p_u_156.keys == nil then
			v191 = false
		else
			v191 = #p_u_156.keys == v186
		end
		for v192 = 1, v186 do
			local v193 = v186 <= 1 and 0 or (v192 - 1) / (v186 - 1)
			local v194, v195 = v183(p_u_156.u0 + (p_u_156.u1 - p_u_156.u0) * v193)
			v189[v192] = v194
			v190[v192] = v195
			if not v191 or v189[v192] == p_u_156.keys[v192] and v190[v192] == p_u_156.alphas[v192] then
				continue
			end
			v191 = false
		end
		p_u_156.kind = p_u_157
		if v191 then
			return
		else
			p_u_156.keys = v189
			p_u_156.alphas = v190
			if v186 == 1 then
				p_u_156.beam.Color = ColorSequence.new(v189[1])
				p_u_156.beam.Transparency = NumberSequence.new(v190[1])
			else
				local v196 = table.create(v186)
				local v197 = table.create(v186)
				local v198 = v190[1]
				for v199 = 1, v186 do
					local v200 = (v199 - 1) / (v186 - 1)
					v196[v199] = ColorSequenceKeypoint.new(v200, v189[v199])
					v197[v199] = NumberSequenceKeypoint.new(v200, v190[v199])
					if v190[v199] == v198 then
						continue
					end
					v198 = false
				end
				p_u_156.beam.Color = ColorSequence.new(v196)
				if v198 == false or p_u_156.alpha ~= v198 then
					p_u_156.beam.Transparency = NumberSequence.new(v197)
					p_u_156.alpha = v198
				end
			end
		end
	end
end
local function v_u_352(p202, p203, p_u_204, p205) -- name: stepFlow
	-- upvalues: (copy) v_u_88, (copy) v_u_24, (copy) v_u_6, (copy) v_u_151, (copy) v_u_150, (copy) v_u_148, (copy) v_u_153, (copy) v_u_201, (copy) v_u_10, (copy) v_u_149, (copy) v_u_154, (copy) v_u_14, (copy) v_u_147, (copy) v_u_13, (copy) v_u_15, (copy) v_u_5, (copy) v_u_64
	local v206 = p202.flow
	if v206 then
		local v_u_207 = p202.model
		if p202.slicesDirty then
			p202.slicesDirty = false
			v_u_88(v_u_207, v206)
		end
		local v208 = v_u_207:GetAttribute("EngineOn") == true
		local v209 = v_u_207:GetAttribute("HeadlightsOn") == true
		local v210, v211 = v_u_24(v_u_207)
		local v212
		if v208 then
			if v_u_207:GetAttribute("RainbowOn") == true then
				v212 = v_u_207:GetAttribute("KitRung") ~= true
			else
				v212 = false
			end
		else
			v212 = v208
		end
		local v213 = v_u_207:GetAttribute("Indicator") or "Off"
		local v_u_214 = os.clock()
		local v_u_215 = {}
		local v_u_216 = v_u_207:GetAttribute("DRLStyle") == "Mode"
		local function v_u_231(p217, p218, p219)
			-- upvalues: (copy) v_u_215, (copy) v_u_216, (ref) v_u_6, (copy) v_u_207, (copy) p_u_204, (copy) v_u_214
			local v220 = math.clamp(p217, 0, 1) * 400 + 0.5
			local v221 = math.floor(v220)
			local v222 = v221 * 4 + (p218 == "Right" and 2 or 0) + (p219 and 1 or 0)
			local v223 = v_u_215[v222]
			if v223 == nil then
				local v224 = v221 / 400
				if v_u_216 then
					v223 = v_u_6.modeColor(v_u_207, v224, p218, p_u_204, p219)
				else
					v223 = v_u_6.lightColor(v_u_207, v224 + 1, 2, v_u_214)
				end
				if v223 then
					local v225 = v223.R
					local v226 = v223.G
					local v227 = v223.B
					local v228 = math.max(v225, v226, v227)
					if v228 >= 0.02 then
						local v229 = 1 / v228
						local v230 = math.min(1.4, v229)
						v223 = Color3.new(v223.R * v230, v223.G * v230, v223.B * v230)
					end
				end
				v_u_215[v222] = v223 or false
			end
			return v223 or nil
		end
		local v232 = p_u_204 % v_u_6.BLINK_PERIOD
		local v233
		if v232 < v_u_6.BLINK_ON_TIME then
			v233 = 1
		elseif v232 < v_u_6.BLINK_ON_TIME + 0.14 then
			local v234 = 1 - (v232 - v_u_6.BLINK_ON_TIME) / 0.14
			local v235 = math.clamp(v234, 0, 1)
			v233 = v235 * v235 * (3 - 2 * v235)
		else
			v232 = nil
			v233 = 0
		end
		local v236 = {
			["Left"] = v213 == "Left" and true or v213 == "Hazard",
			["Right"] = v213 == "Right" and true or v213 == "Hazard"
		}
		local v237 = v236.Left or v236.Right
		local v238 = v_u_207:GetAttribute("FlowRearSignalReverse") == true
		local v239
		if v211 then
			v239 = v_u_151
		elseif v212 then
			v239 = nil
		elseif v210 then
			v239 = v_u_150
		elseif v208 or v209 then
			v239 = v_u_148
		else
			v239 = nil
		end
		for _, v240 in v206.beams do
			local v241 = nil
			local v242 = nil
			if p203 then
				if v240.set == "Front" then
					if v236[v240.side] then
						v241 = "signal"
					elseif v212 then
						v241 = "rgb"
					elseif v208 or v209 then
						v241 = "white"
					else
						v241 = nil
					end
				elseif v240.set == "RearSignal" then
					local v243
					if v236[v240.side] then
						v243 = v206.piecesLight and "signal" or "cover"
					else
						v243 = v212 and not v206.piecesLight and "rgb" or nil
					end
					v241 = v206.piecesLight and not v206.splitSignal and "none" or v243
					if v241 == "none" then
						v241 = nil
					elseif v241 == nil and (v237 and v206.piecesLight) then
						if v210 or v211 then
							v242 = v_u_150
							v241 = "solid"
						elseif v212 then
							v241 = "rgb"
						elseif v208 or v209 then
							v242 = v_u_148
							v241 = "solid"
						end
					end
				elseif v240.set == "RearLower" then
					if v212 then
						v241 = "rgb"
					else
						v241 = nil
					end
				elseif v240.set == "RearBottom" then
					if v239 then
						v242 = v239
						v241 = "solid"
					elseif v212 then
						v241 = "rgb"
					end
				end
			end
			if v240.w0 then
				local v244 = v240.set == "RearSignal" and (v237 and v206.piecesLight) and 2.2 or 1
				if v240.beam.Width0 ~= v240.w0 * v244 then
					v240.beam.Width0 = v240.w0 * v244
					v240.beam.Width1 = v240.w1 * v244
				end
			end
			if v241 then
				if v238 and v241 == "cover" then
					local v245 = 1 - v240.baseU0
					local v246 = 1 - v240.baseU1
					v240.u0 = v245
					v240.u1 = v246
				else
					local v247 = v240.baseU0
					local v248 = v240.baseU1
					v240.u0 = v247
					v240.u1 = v248
				end
				v_u_201(v240, v241, v242, v_u_231, v240.set ~= "Front", v232, v233)
			else
				v240.kind = nil
			end
			if v240.beam.Enabled == (v241 ~= nil) then
				continue
			end
			v240.beam.Enabled = v241 ~= nil
		end
		for _, v249 in v206.parts do
			if p203 then
				if (v249.side == "None" or not v236[v249.side]) and (not v237 or (v249.bright or (v249.side ~= "None" or v206.splitSignal))) then
					if v237 and (v206.splitSignal and (not v249.bright and v249.side == "None")) then
						local v250 = v249.part
						local v251 = v249.color
						local v252 = v249.material
						if v250.Color ~= v251 then
							v250.Color = v251
						end
						if v250.Material == v252 then
							continue
						end
						v250.Material = v252
					elseif v210 or v211 then
						local v253 = v249.part
						local v254 = v_u_150
						local v255 = Enum.Material.Neon
						if v253.Color ~= v254 then
							v253.Color = v254
						end
						if v253.Material == v255 then
							continue
						end
						v253.Material = v255
					elseif v212 then
						local v256 = v_u_231(v249.u, "Left", true)
						local v257 = v249.part
						local v258
						if v206.piecesLight or not v206.rowCovered then
							v258 = v256 or v_u_153
						elseif v256 then
							v258 = v_u_153:Lerp(v256, 0.35)
						else
							v258 = v_u_153
						end
						local v259 = Enum.Material.Neon
						if v257.Color ~= v258 then
							v257.Color = v258
						end
						if v257.Material == v259 then
							continue
						end
						v257.Material = v259
					elseif v208 or v209 then
						local v260 = v249.part
						local v261
						if v249.bright then
							v261 = v_u_149
						else
							v261 = v_u_148
						end
						local v262 = Enum.Material.Neon
						if v260.Color ~= v261 then
							v260.Color = v261
						end
						if v260.Material == v262 then
							continue
						end
						v260.Material = v262
					else
						local v263 = v249.part
						local v264 = v249.color
						local v265 = v249.material
						if v263.Color ~= v264 then
							v263.Color = v264
						end
						if v263.Material == v265 then
							continue
						end
						v263.Material = v265
					end
				else
					local v266 = v249.part
					local v267 = v_u_153
					local v268 = v_u_10
					local v269 = v249.u
					local v270
					if v232 then
						local v271 = (v232 / 0.3 * 1.25 - v269) / 0.25
						local v272 = math.clamp(v271, 0, 1)
						v270 = v272 * v272 * (3 - 2 * v272) * v233
					else
						v270 = 0
					end
					local v273 = v267:Lerp(v268, v270 <= 0 and 0 or v270 ^ 0.4)
					local v274 = Enum.Material.Neon
					if v266.Color ~= v273 then
						v266.Color = v273
					end
					if v266.Material == v274 then
						continue
					end
					v266.Material = v274
				end
			else
				local v275 = v249.part
				local v276 = v249.color
				local v277 = v249.material
				if v275.Color ~= v276 then
					v275.Color = v276
				end
				if v275.Material == v277 then
					continue
				end
				v275.Material = v277
			end
		end
		for _, v278 in v206.backs do
			local v279 = "off"
			local v280 = nil
			if p203 then
				if v278.set == "RearBottom" then
					if v211 then
						v280 = v_u_151
						v279 = "dim"
					elseif v239 then
						v280 = v239
						v279 = "on"
					elseif v212 then
						v279 = "on"
						local v281 = v_u_231(0.2, "Left", true)
						if v281 then
							v280 = v_u_153:Lerp(v281, 0.35)
						else
							v280 = v_u_153
						end
					end
				elseif v212 then
					v279 = "on"
					local v282 = v_u_231(0.5, "Left", true)
					if v282 then
						v280 = v_u_153:Lerp(v282, 0.35)
					else
						v280 = v_u_153
					end
				elseif v210 or v211 then
					v280 = v_u_150
					v279 = "on"
				elseif v208 or v209 then
					v280 = v_u_148
					v279 = "on"
				end
			end
			local v283 = v279 .. tostring(v280)
			if v278.state == v283 then
				continue
			end
			v278.state = v283
			if v280 then
				v278.part.Color = v280
			end
			v278.part.Transparency = v279 == "on" and 0 or (v279 == "dim" and 0.45 or 1)
		end
		local function v291(p284, p285) -- name: shade
			-- upvalues: (ref) v_u_154, (copy) v_u_231, (ref) v_u_153
			local v286 = 0
			local v287 = 0
			local v288 = 0
			for _, v289 in v_u_154 do
				local v290 = v_u_231(p284.u0 + (p284.u1 - p284.u0) * v289[1], p284.side, p285)
				if not v290 then
					continue
				end
				v286 = v286 + v290.R * v289[2]
				v287 = v287 + v290.G * v289[2]
				v288 = v288 + v290.B * v289[2]
			end
			if v286 + v287 + v288 > 0.02 then
				return Color3.new(v286, v287, v288)
			else
				return v_u_153
			end
		end
		local v292 = {}
		for _, v293 in v206.slices do
			local v294 = nil
			local v295
			if p203 then
				if v293.set == "FrontGuide" or v293.set == "FrontGuideBack" then
					if v208 or v209 then
						if v236[v293.side] then
							local v296 = v_u_153
							local v297 = v_u_14
							local v298 = v293.u
							local v299
							if v232 then
								local v300 = (v232 / 0.3 * 1.25 - v298) / 0.25
								local v301 = math.clamp(v300, 0, 1)
								v299 = v301 * v301 * (3 - 2 * v301) * v233
							else
								v299 = 0
							end
							v294 = v296:Lerp(v297, v299)
							v295 = p203
						elseif v212 then
							v294 = v291(v293, false)
							v295 = p203
						else
							v294 = v_u_147
							v295 = p203
						end
					else
						v295 = false
					end
				elseif v293.set == "FrontSignal" then
					local v302
					if p203 and v236[v293.side] then
						local v303 = v293.u
						if v232 then
							local v304 = (v232 / 0.3 * 1.25 - v303) / 0.25
							local v305 = math.clamp(v304, 0, 1)
							v302 = v305 * v305 * (3 - 2 * v305) * v233
						else
							v302 = 0
						end
					else
						v302 = 0
					end
					local v306 = v292[v293.side] or {}
					v292[v293.side] = v306
					if v293.lensGroup then
						local v307 = v293.lensGroup
						local v308 = v306[v293.lensGroup] or 0
						v306[v307] = math.max(v308, v302)
					end
					if v302 > 0.02 then
						v294 = v_u_13:Lerp(v_u_14, v302)
						v295 = p203
					else
						v295 = false
					end
				elseif v293.set == "RowHalf" then
					if v236[v293.side] then
						local v309 = v_u_153
						local v310 = v_u_10
						local v311 = v293.u
						local v312
						if v232 then
							local v313 = (v232 / 0.3 * 1.25 - v311) / 0.25
							local v314 = math.clamp(v313, 0, 1)
							v312 = v314 * v314 * (3 - 2 * v314) * v233
						else
							v312 = 0
						end
						v294 = v309:Lerp(v310, v312 <= 0 and 0 or v312 ^ 0.4)
						v295 = p203
					elseif v210 or v211 then
						v294 = v_u_150
						v295 = p203
					elseif v212 then
						v294 = v_u_231(v293.u, "Left", true) or v_u_153
						v295 = p203
					elseif v208 or v209 then
						v294 = v_u_148
						v295 = p203
					else
						v295 = false
					end
				elseif v293.set == "RearBottomBar" and v211 then
					v294 = v_u_151
					v295 = p203
				elseif v210 or v211 then
					v294 = v_u_150
					v295 = p203
				elseif v212 then
					v294 = v291(v293, true)
					v295 = p203
				elseif v208 or v209 then
					if v293.set == "RearBar" or v293.set == "RearBottomBar" then
						v294 = v_u_149
						v295 = p203
					else
						v294 = v_u_148
						v295 = p203
					end
				else
					v295 = false
				end
			else
				v295 = false
			end
			local v315 = v293.part
			if v295 then
				if v315.Color ~= v294 then
					v315.Color = v294
				end
				if v315.Material ~= Enum.Material.Neon then
					v315.Material = Enum.Material.Neon
				end
				if v315.Transparency == 0 then
					continue
				end
				v315.Transparency = 0
			else
				local v316 = v293.set == "FrontSignal"
				local v317
				if v316 then
					v317 = v_u_15
				else
					v317 = v293.color
				end
				local v318
				if v316 then
					v318 = Enum.Material.SmoothPlastic
				else
					v318 = v293.material
				end
				if v315.Color ~= v317 then
					v315.Color = v317
				end
				if v315.Material ~= v318 then
					v315.Material = v318
				end
				local v319 = v316 and 1 or v293.transparency
				if v315.Transparency == v319 then
					continue
				end
				v315.Transparency = v319
			end
		end
		if v206.lens then
			for v320, v321 in v206.lens do
				local v322
				if p203 then
					v322 = v236[v320] == true
				else
					v322 = p203
				end
				if v321.hl.Enabled ~= false then
					v321.hl.Enabled = false
				end
				local v323 = v292[v320] or {}
				for v324, v325 in v321.groups do
					if v325.hl.Enabled ~= v322 then
						v325.hl.Enabled = v322
					end
					if not v322 then
						continue
					end
					local v326 = v323[v324] or 0
					local v327 = v_u_15:Lerp(v_u_14, v326)
					if v325.hl.FillColor ~= v327 then
						v325.hl.FillColor = v327
					end
					local v328 = 0.1 * (1 - v326)
					if v325.hl.FillTransparency == v328 then
						continue
					end
					v325.hl.FillTransparency = v328
				end
			end
		end
		if v206.halos and #v206.halos > 0 then
			local v329 = 0.3
			local v330 = 0.7
			local v331 = v_u_5.ClockTime
			local v332
			if v331 >= 7.5 and v331 <= 16.5 then
				v332 = 0
			elseif v331 > 16.5 and v331 < 18.5 then
				v332 = (v331 - 16.5) / 2
			else
				v332 = (v331 <= 5.8 or v331 >= 7.5) and 1 or (7.5 - v331) / 1.7
			end
			local v333 = v329 + v330 * v332
			for _, v334 in v206.halos do
				local v335 = nil
				local v336 = 0
				local v337
				if p203 and v334.part.Parent then
					local v338
					if v236[v334.side] and v232 then
						local v339 = (v232 / 0.3 * 1.25 - 0.5) / 0.25
						local v340 = math.clamp(v339, 0, 1)
						v338 = v340 * v340 * (3 - 2 * v340) * v233
					else
						v338 = 0
					end
					if v334.set == "Front" then
						if v208 or v209 then
							v337 = v_u_147
							v336 = v209 and 1 or 0.6
							if v212 then
								local v341 = v_u_231(0.5, v334.side, false)
								if v209 then
									v337 = v_u_147:Lerp(v341 or v_u_147, 0.35)
								elseif v341 then
									v337 = v341
								else
									v336 = 0
								end
							end
						else
							v337 = v335
						end
						if v338 > 0 then
							if v337 and v336 > 0 then
								local v342 = v_u_14
								local v343
								if v209 then
									v343 = v338 * 0.6
								else
									v343 = v338
								end
								v337 = v337:Lerp(v342, v343)
							else
								v337 = v_u_14
							end
							local v344 = v338 * 0.6
							v336 = math.max(v336, v344)
						end
					else
						if v210 then
							v337 = v_u_150
							v336 = 1
						elseif v211 then
							v337 = v_u_150:Lerp(v_u_151, 0.35)
							v336 = 0.9
						elseif v212 then
							v337 = v_u_231(0.5, v334.side, true)
							if v337 then
								v336 = 0.8
							else
								v337 = v335
							end
						elseif v208 or v209 then
							v337 = v_u_149
							v336 = 0.55
						else
							v337 = v335
						end
						local v345 = v338 <= 0 and 0 or v338 ^ 0.4
						if v345 > 0 then
							if v337 and v336 > 0 then
								v337 = v337:Lerp(v_u_10, v345)
							else
								v337 = v_u_10
							end
							local v346 = v345 * 0.8
							v336 = math.max(v336, v346)
						end
					end
					if v336 > 0 and p205 then
						local v347 = v334.part.CFrame.LookVector
						if v334.back then
							v347 = -v347
						end
						local v348 = p205 - v334.part.Position
						local v349 = v348.Magnitude
						local v350 = ((v349 <= 0.001 and 0 or v347:Dot(v348 / v349)) - 0.1) / 0.45
						local v351 = math.clamp(v350, 0, 1)
						v336 = v336 * (v351 * v351 * (3 - 2 * v351) * v333)
					end
				else
					v337 = v335
				end
				v_u_64(v334, v337, v336)
			end
		end
	end
end
local function v_u_416(p353, p354, p355, p356) -- name: stepCar
	-- upvalues: (copy) v_u_352, (copy) v_u_146, (copy) v_u_24, (copy) v_u_10, (copy) v_u_12, (copy) v_u_6, (copy) v_u_11, (copy) v_u_16
	local v357 = p353.model
	local v358 = p353.chassis
	if v358 and v358.Parent then
		local v359 = (v358.Position - p354).Magnitude < 300
		local v360 = {}
		v_u_352(p353, v359, p356, p354)
		if v359 then
			v_u_146(p353, v357:GetAttribute("Indicator") or "Off", v360)
		end
		local v361 = v_u_24(v357)
		local v362 = v357:GetAttribute("EngineOn") == true
		local v363 = v362 or v357:GetAttribute("HeadlightsOn") == true
		if v362 then
			if v357:GetAttribute("RainbowOn") == true then
				v362 = v357:GetAttribute("KitRung") ~= true
			else
				v362 = false
			end
		end
		local v364 = os.clock()
		local v365 = v357:GetAttribute("DRLStyle") == "Mode"
		local v366 = p356
		for v367, v368 in p353.parts do
			local v369 = v360[v367] == true
			if v368.kind == "Signal" then
				if v369 then
					local v370 = v_u_10
					local v371 = Enum.Material.Neon
					if v367.Color ~= v370 then
						v367.Color = v370
					end
					if v367.Material ~= v371 then
						v367.Material = v371
					end
				else
					local v372 = v368.color
					local v373 = v368.material
					if v367.Color ~= v372 then
						v367.Color = v372
					end
					if v367.Material ~= v373 then
						v367.Material = v373
					end
				end
				if v368.light then
					v368.light.Enabled = v369
				end
			else
				if v369 then
					local v374 = v_u_10
					local v375 = Enum.Material.Neon
					if v367.Color ~= v374 then
						v367.Color = v374
					end
					if v367.Material ~= v375 then
						v367.Material = v375
					end
				elseif v361 then
					local v376 = v_u_12
					local v377 = Enum.Material.Neon
					if v367.Color ~= v376 then
						v367.Color = v376
					end
					if v367.Material ~= v377 then
						v367.Material = v377
					end
				elseif v362 and v367:GetAttribute("KitRgbT") then
					local v378 = v367:GetAttribute("KitRgbT")
					local v379
					if v365 then
						v379 = v_u_6.modeColor(v357, v378, v368.side, p356, true)
					else
						v379 = v_u_6.lightColor(v357, 1 + v378, 2, v364)
					end
					if v379 then
						local v380 = Enum.Material.Neon
						if v367.Color ~= v379 then
							v367.Color = v379
						end
						if v367.Material ~= v380 then
							v367.Material = v380
						end
					else
						local v381 = v368.color
						local v382 = v368.material
						if v367.Color ~= v381 then
							v367.Color = v381
						end
						if v367.Material ~= v382 then
							v367.Material = v382
						end
					end
				elseif v363 then
					local v383 = v_u_11
					local v384 = Enum.Material.Neon
					if v367.Color ~= v383 then
						v367.Color = v383
					end
					if v367.Material ~= v384 then
						v367.Material = v384
					end
				else
					local v385 = v368.color
					local v386 = v368.material
					if v367.Color ~= v385 then
						v367.Color = v385
					end
					if v367.Material ~= v386 then
						v367.Material = v386
					end
				end
				if v368.light then
					local v387 = v368.light
					local v388
					if v359 then
						v388 = v369 or v361
					else
						v388 = v359
					end
					v387.Enabled = v388
					local v389 = v368.light
					local v390
					if v369 then
						v390 = v_u_10
					else
						v390 = v_u_12
					end
					v389.Color = v390
				end
			end
			if not v368.twin then
				continue
			end
			local v391 = v367.Material == Enum.Material.Neon and 0 or 1
			if v367.Transparency == v391 then
				continue
			end
			v367.Transparency = v391
		end
		local v392 = v357:GetAttribute("HeadlightsOn") == true
		for _, v393 in p353.beams do
			local v394 = v359 and v392
			if v393.Enabled == v394 then
				continue
			end
			v393.Enabled = v394
		end
		local v395 = p353.hood
		if v395 and v395.motor.Parent then
			local v396 = v357:GetAttribute("HoodOpen") == true and 1 or 0
			local v397 = v357:GetAttribute("HoodOpenTime") or 1.2
			local v398 = 1 / math.max(v397, 0.1)
			if p353.hoodOpen ~= v396 then
				local v399 = p353.hoodOpen
				local v400 = v396 - p353.hoodOpen
				local v401 = v399 + math.sign(v400) * v398 * p355
				p353.hoodOpen = math.clamp(v401, 0, 1)
				local v402 = p353.hoodOpen
				local v403 = v402 * v402 * (3 - 2 * v402)
				v395.motor.C0 = v395.base * CFrame.fromAxisAngle(Vector3.new(1, 0, 0), v395.sign * v395.angle * v403)
			end
		end
		if v359 then
			v359 = v357:GetAttribute("RungOn") == true
		end
		local v404 = v357:GetAttribute("RungMode") or "SideSwap"
		local v405 = v357:GetAttribute("RungColor") or Color3.new(1, 1, 1)
		local v406 = v357:GetAttribute("RungColor2") or v405
		local v407 = v357:GetAttribute("RungTwoTone") ~= false
		local v408 = v357:GetAttribute("RungBright") or 1
		local v409 = math.clamp(v408, 0.1, 1)
		local v410 = v366 * (v357:GetAttribute("RungSpeed") or 1)
		for _, v411 in p353.fx do
			local v412, v413
			if v359 and v357:GetAttribute("Rung" .. v411.area) ~= false then
				v412, v413 = v_u_16.evaluate(v404, v410, v411.area, v405, v406, v407)
				local v414 = v411.source
				if v414 and (v360[v414] or v361 and (p353.parts[v414] and p353.parts[v414].kind == "Tail")) then
					v413 = 0
				end
			else
				v412 = v405
				v413 = 0
			end
			local v415 = 1 - math.clamp(v413, 0, 1) * v409
			if v411.part.Transparency ~= v415 then
				v411.part.Transparency = v415
			end
			if v413 <= 0 or v411.part.Color == v412 then
				continue
			end
			v411.part.Color = v412
		end
	end
end
v4.RenderStepped:Connect(function(p417)
	-- upvalues: (ref) v_u_155, (copy) v_u_65, (copy) v_u_416
	local v418 = workspace:GetServerTimeNow()
	local v419, v420, v421
	if v_u_155 == nil then
		v_u_155 = v418
		v419 = v_u_155
		v420 = workspace.CurrentCamera
		v421 = v420 and v420.CFrame.Position or Vector3.new(0, 0, 0)
		for v430, v431 in v_u_65 do
			if not v430.Parent then
				continue
			end
			v_u_416(v431, v421, p417, v419)
		end
		return
	else
		local v424 = v418 - v_u_155
		if math.abs(v424) > 0.25 then
			v_u_155 = v418
			v419 = v_u_155
			v420 = workspace.CurrentCamera
			v421 = v420 and v420.CFrame.Position or Vector3.new(0, 0, 0)
			for v430, v431 in v_u_65 do
				if not v430.Parent then
					continue
				end
				v_u_416(v431, v421, p417, v419)
			end
		else
			v_u_155 = v_u_155 + p417
			local v427 = v_u_155
			local v428 = v418 - v_u_155
			local v429 = p417 * 2
			v_u_155 = v427 + v428 * math.min(v429, 1)
			v419 = v_u_155
			v420 = workspace.CurrentCamera
			v421 = v420 and v420.CFrame.Position or Vector3.new(0, 0, 0)
			for v430, v431 in v_u_65 do
				if not v430.Parent then
					continue
				end
				v_u_416(v431, v421, p417, v419)
			end
		end
	end
end)
local v_u_432 = nil
local v_u_433 = { 2, 4 }
local function v_u_437(p434, p435, p436) -- name: burst
	-- upvalues: (copy) v_u_7, (copy) v_u_8
	if p434.busy then
		return
	end
	p434.busy = true
	for _ = 1, p435 do
		if not p434.active then
			break
		end
		v_u_7.fire(v_u_8, p434.model, "Pop")
		task.wait(p436 + math.random() * p436)
	end
	p434.busy = false
end
local function v_u_457(p438) -- name: backfireLoop
	-- upvalues: (copy) v_u_6, (copy) v_u_437, (copy) v_u_433
	local v439 = 0
	local v440 = 0
	local v441 = nil
	local v442 = -100
	local v443 = false
	local v444 = 0
	while p438.active do
		task.wait(0.05)
		local v445 = p438.model
		local v446 = p438.seat
		local v447 = v445:FindFirstChild("Chassis")
		if not (v447 and v446.Parent) then
			break
		end
		local v448 = os.clock()
		local v449 = v445:GetAttribute("EngineOn") == true
		local v450 = not v449 and 0 or v446.ThrottleFloat
		local v451 = v_u_6.flatRotation(v447.CFrame)
		local v452 = v447.AssemblyLinearVelocity:Dot(v451.LookVector)
		local v453, v454 = v_u_6.rpm(v452, v445:GetAttribute("MaxSpeed") or v_u_6.DEFAULT_MAX_SPEED, v450)
		if v454 == v441 then
			v454 = v441
		else
			v440 = v448
		end
		local v455 = v450 <= 0.02
		if v455 then
			v439 = v439 + 1
		else
			v444 = v448
			v443 = false
			v439 = 0
		end
		local v456 = v448 - v440 < 0.6 and true or v448 - v442 < 2.5
		if v449 and (v455 and (not v456 and (v439 == 3 and (v448 - v444 < 0.5 and (v453 > 4500 and not v443))))) then
			task.spawn(v_u_437, p438, math.random(v_u_433[1], v_u_433[2]), 0.07)
			v443 = true
		elseif v449 and (v455 and (not v456 and (v439 > 10 and (v453 > 4000 and math.random() < 0.012)))) then
			task.spawn(v_u_437, p438, 1, 0.09)
		else
			v448 = v442
		end
		v442 = v448
		v441 = v454
	end
end
local function v_u_463(p458, p459) -- name: startDriving
	-- upvalues: (ref) v_u_432, (copy) v_u_3, (copy) v_u_9, (copy) v_u_457
	if v_u_432 then
		if v_u_432.gui then
			v_u_432.gui:Destroy()
		end
		v_u_432.active = false
		v_u_432 = nil
	end
	local v460 = {
		["model"] = nil,
		["seat"] = nil,
		["active"] = true,
		["model"] = p458,
		["seat"] = p459
	}
	v_u_432 = v460
	if p458:GetAttribute("KitRung") == true then
		local v461 = v_u_3:FindFirstChild("KitCarAssets")
		if v461 then
			v461 = v461:FindFirstChild("RungPanel")
		end
		if v461 then
			local v462 = v461:Clone()
			v462.Car.Value = p458
			v462.Parent = v_u_9:WaitForChild("PlayerGui")
			v460.gui = v462
		end
	end
	if p458:GetAttribute("KitBackfire") == true then
		task.spawn(v_u_457, v460)
	end
end
local function v_u_466(p464) -- name: onSeat
	-- upvalues: (ref) v_u_432, (copy) v_u_463
	if p464 and (p464:IsA("VehicleSeat") and p464.Name == "DriverSeat") then
		local v465 = p464.Parent
		if v465 and (v465:GetAttribute("KitLights") == true or v465:GetAttribute("KitBackfire") == true) then
			if not v_u_432 or v_u_432.model ~= v465 then
				v_u_463(v465, p464)
			end
			return
		end
	end
	if v_u_432 then
		if v_u_432.gui then
			v_u_432.gui:Destroy()
		end
		v_u_432.active = false
		v_u_432 = nil
	end
end
local function v469(p467) -- name: watchCharacter
	-- upvalues: (copy) v_u_466
	local v_u_468 = p467:WaitForChild("Humanoid")
	v_u_468:GetPropertyChangedSignal("SeatPart"):Connect(function()
		-- upvalues: (ref) v_u_466, (copy) v_u_468
		v_u_466(v_u_468.SeatPart)
	end)
	v_u_466(v_u_468.SeatPart)
end
v_u_9.CharacterAdded:Connect(v469)
if v_u_9.Character then
	task.spawn(v469, v_u_9.Character)
end
v1:GetInstanceAddedSignal("GTACar"):Connect(v130)
v1:GetInstanceRemovedSignal("GTACar"):Connect(v133)
for _, v470 in v1:GetTagged("GTACar") do
	task.spawn(v130, v470)
end