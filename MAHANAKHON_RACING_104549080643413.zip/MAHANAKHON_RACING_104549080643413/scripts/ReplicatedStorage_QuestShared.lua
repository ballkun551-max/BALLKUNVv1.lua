-- Path: ReplicatedStorage/QuestShared
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = {
	["REMOTE"] = "Quest",
	["TZ"] = 25200,
	["DAILY"] = {
		{
			["id"] = "d_jobs3",
			["stat"] = "jobs",
			["goal"] = 3,
			["reward"] = 1000
		},
		{
			["id"] = "d_jobs10",
			["stat"] = "jobs",
			["goal"] = 10,
			["reward"] = 3500
		},
		{
			["id"] = "d_min15",
			["stat"] = "min",
			["goal"] = 15,
			["reward"] = 800
		},
		{
			["id"] = "d_min60",
			["stat"] = "min",
			["goal"] = 60,
			["reward"] = 2500
		},
		{
			["id"] = "d_km5",
			["stat"] = "km",
			["goal"] = 5,
			["reward"] = 1000
		},
		{
			["id"] = "d_km20",
			["stat"] = "km",
			["goal"] = 20,
			["reward"] = 3000
		}
	},
	["WEEKLY"] = {
		{
			["id"] = "w_jobs40",
			["stat"] = "jobs",
			["goal"] = 40,
			["reward"] = 15000
		},
		{
			["id"] = "w_jobs100",
			["stat"] = "jobs",
			["goal"] = 100,
			["reward"] = 40000
		},
		{
			["id"] = "w_min300",
			["stat"] = "min",
			["goal"] = 300,
			["reward"] = 12000
		},
		{
			["id"] = "w_min900",
			["stat"] = "min",
			["goal"] = 900,
			["reward"] = 35000
		},
		{
			["id"] = "w_km100",
			["stat"] = "km",
			["goal"] = 100,
			["reward"] = 15000
		},
		{
			["id"] = "w_km300",
			["stat"] = "km",
			["goal"] = 300,
			["reward"] = 40000
		}
	}
}
v_u_1.PERIODS = {
	["daily"] = v_u_1.DAILY,
	["weekly"] = v_u_1.WEEKLY
}
local v2 = {
	["jobs"] = {
		["icon"] = "scooter",
		["color"] = nil,
		["unit"] = "jobs",
		["title"] = "Deliver %d jobs",
		["color"] = Color3.fromRGB(255, 120, 30)
	},
	["min"] = {
		["icon"] = "clock",
		["color"] = nil,
		["unit"] = "min",
		["title"] = "Be online %s",
		["color"] = Color3.fromRGB(70, 130, 250)
	},
	["km"] = {
		["icon"] = "gauge",
		["color"] = nil,
		["unit"] = "km",
		["title"] = "Drive %d km",
		["color"] = Color3.fromRGB(30, 180, 120)
	}
}
v_u_1.STATS = v2
function v_u_1.quest(p3, p4) -- name: quest
	-- upvalues: (copy) v_u_1
	for _, v5 in v_u_1.PERIODS[p3] or {} do
		if v5.id ~= p4 then
			continue
		end
		return v5
	end
	return nil
end
function v_u_1.dayKey(p6) -- name: dayKey
	-- upvalues: (copy) v_u_1
	return (p6 + v_u_1.TZ) // 86400
end
function v_u_1.weekKey(p7) -- name: weekKey
	-- upvalues: (copy) v_u_1
	return (v_u_1.dayKey(p7) + 3) // 7
end
function v_u_1.periodKey(p8, p9) -- name: periodKey
	-- upvalues: (copy) v_u_1
	if p8 == "daily" then
		return v_u_1.dayKey(p9)
	else
		return v_u_1.weekKey(p9)
	end
end
function v_u_1.periodEnd(p10, p11) -- name: periodEnd
	-- upvalues: (copy) v_u_1
	if p10 == "daily" then
		return (v_u_1.dayKey(p11) + 1) * 86400 - v_u_1.TZ
	else
		return ((v_u_1.weekKey(p11) + 1) * 7 - 3) * 86400 - v_u_1.TZ
	end
end
function v_u_1.title(p12) -- name: title
	-- upvalues: (copy) v_u_1
	local v13 = v_u_1.STATS[p12.stat]
	if p12.stat ~= "min" then
		return v13.title:format(p12.goal)
	end
	local v14 = v13.title
	local v15
	if p12.goal >= 60 and p12.goal % 60 == 0 then
		v15 = ("%d h"):format(p12.goal // 60)
	else
		v15 = ("%d min"):format(p12.goal)
	end
	return v14:format(v15)
end
return v_u_1