-- Path: ReplicatedStorage/PistonShared
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = require(script.Parent:WaitForChild("EcuShared"))
local v_u_29 = {
	["REMOTE"] = "Piston",
	["SIZES"] = {
		53,
		56,
		58,
		62,
		67,
		72,
		75,
		80,
		88,
		90
	},
	["PRICES"] = {
		[53] = 3000,
		[56] = 5000,
		[58] = 8000,
		[62] = 14000,
		[67] = 25000,
		[72] = 40000,
		[75] = 60000,
		[80] = 100000,
		[88] = 150000,
		[90] = 200000
	},
	["INSTALL_TIME"] = 5,
	["INSTALL_SOUND"] = "rbxassetid://9118047004",
	["FULL_SIZE"] = 90,
	["BIG_BORE_FROM"] = 65,
	["TIERS"] = {
		[0] = {
			["accel"] = 1,
			["top"] = 1,
			["cap"] = 250,
			["tuck"] = 250
		},
		[53] = {
			["accel"] = 1.06,
			["top"] = 1.04,
			["cap"] = 258,
			["tuck"] = 262
		},
		[56] = {
			["accel"] = 1.1,
			["top"] = 1.08,
			["cap"] = 265,
			["tuck"] = 270
		},
		[58] = {
			["accel"] = 1.14,
			["top"] = 1.11,
			["cap"] = 272,
			["tuck"] = 278
		},
		[62] = {
			["accel"] = 1.19,
			["top"] = 1.15,
			["cap"] = 279,
			["tuck"] = 286
		},
		[67] = {
			["accel"] = 1.25,
			["top"] = 1.19,
			["cap"] = 286,
			["tuck"] = 294
		},
		[72] = {
			["accel"] = 1.31,
			["top"] = 1.24,
			["cap"] = 293,
			["tuck"] = 302
		},
		[75] = {
			["accel"] = 1.37,
			["top"] = 1.28,
			["cap"] = 299,
			["tuck"] = 309
		},
		[80] = {
			["accel"] = 1.44,
			["top"] = 1.32,
			["cap"] = 305,
			["tuck"] = 316
		},
		[88] = {
			["accel"] = 1.52,
			["top"] = 1.36,
			["cap"] = 310,
			["tuck"] = 319
		},
		[90] = {
			["accel"] = 1.6,
			["top"] = 1.4,
			["cap"] = 315,
			["tuck"] = 340
		}
	},
	["PEAK_KMH"] = 320,
	["CAR_KMH"] = 315,
	["ECU_CAP_MIN"] = 0.85,
	["CAP_FULL_GAIN"] = 1.5,
	["STOCK_BORE"] = {
		["WAVE_SILVER"] = 50,
		["WAVE_BARE"] = 50,
		["WAVE_STREET"] = 50,
		["WAVE_110I"] = 50,
		["FINO115"] = 50,
		["WAVE_KAGE"] = 52.4,
		["WAVE_WHITE"] = 52.4,
		["WAVE125S"] = 52.4,
		["DREAM_RACE"] = 52.4,
		["DREAM_DRAG"] = 52.4,
		["GIORNO23"] = 52.4,
		["LEAD25"] = 52.4,
		["LEAD25G"] = 52.4,
		["LEAD23V"] = 52.4,
		["LEAD23"] = 52.4,
		["SPORT_STEP"] = 52.4,
		["FILANO24"] = 52.4,
		["CHER74"] = 52.4,
		["CHER150"] = 52.4,
		["CHER72"] = 52.4,
		["GIORNO25D"] = 60,
		["GIORNO25T"] = 60,
		["GIORNO22"] = 60,
		["LEAD25F"] = 60,
		["CITY150"] = 58,
		["NMAX20"] = 58,
		["SPORT155"] = 58,
		["VESPA_S"] = 58,
		["FLAT150"] = 57,
		["PCX160"] = 60,
		["PCX160SA"] = 60,
		["PCX160B"] = 60,
		["STREET160"] = 60,
		["STYLO160G"] = 60,
		["MAXI250"] = 69,
		["XMAX"] = 70,
		["XMAX23G"] = 70,
		["XMAX23W"] = 70,
		["XMAX23F"] = 70,
		["TOURER350"] = 77,
		["TOURER350B"] = 77,
		["TOURER350GT"] = 77
	},
	["stockBore"] = function(p2) -- name: stockBore
		-- upvalues: (copy) v_u_29
		return v_u_29.STOCK_BORE[p2]
	end,
	["fits"] = function(p3, p4) -- name: fits
		-- upvalues: (copy) v_u_29
		local v5 = v_u_29.STOCK_BORE[p3]
		if v5 then
			if v_u_29.TIERS[p4] then
				if v_u_29.BIG_BORE_FROM <= v5 and p4 <= v5 then
					return false, ("\224\184\165\224\184\185\224\184\129\224\185\128\224\184\148\224\184\180\224\184\161 %g \224\184\161\224\184\161. \224\185\131\224\184\170\224\185\136\224\185\132\224\184\148\224\185\137\224\185\129\224\184\132\224\185\136\224\184\165\224\184\185\224\184\129\224\184\151\224\184\181\224\185\136\224\185\131\224\184\171\224\184\141\224\185\136\224\184\129\224\184\167\224\185\136\224\184\178\224\184\153\224\184\181\224\185\137"):format(v5)
				else
					return true, nil
				end
			else
				return false, nil
			end
		else
			return false, "\224\184\163\224\184\150\224\184\132\224\184\177\224\184\153\224\184\153\224\184\181\224\185\137\224\185\131\224\184\170\224\185\136\224\184\165\224\184\185\224\184\129\224\185\132\224\184\161\224\185\136\224\185\132\224\184\148\224\185\137"
		end
	end,
	["canFit"] = function(p6, p7, p8) -- name: canFit
		-- upvalues: (copy) v_u_29
		local v9, v10 = v_u_29.fits(p6, p7)
		if not v9 then
			return false, v10
		end
		if typeof(p8) == "number" then
			if p7 == p8 then
				return false, "\224\185\131\224\184\170\224\185\136\224\184\165\224\184\185\224\184\129\224\184\153\224\184\181\224\185\137\224\184\173\224\184\162\224\184\185\224\185\136\224\185\129\224\184\165\224\185\137\224\184\167"
			end
			if p7 < p8 then
				return false, ("\224\185\131\224\184\170\224\185\136\224\185\132\224\184\148\224\185\137\224\185\129\224\184\132\224\185\136\224\184\165\224\184\185\224\184\129\224\184\151\224\184\181\224\185\136\224\185\131\224\184\171\224\184\141\224\185\136\224\184\129\224\184\167\224\185\136\224\184\178 %d \224\184\161\224\184\161. \224\184\151\224\184\181\224\185\136\224\185\131\224\184\170\224\185\136\224\184\173\224\184\162\224\184\185\224\185\136"):format(p8)
			end
		end
		return true, nil
	end,
	["tier"] = function(p11) -- name: tier
		-- upvalues: (copy) v_u_29
		return v_u_29.TIERS[typeof(p11) ~= "number" and 0 or p11] or v_u_29.TIERS[0]
	end,
	["ratio"] = function(_, p12) -- name: ratio
		-- upvalues: (copy) v_u_29
		return (v_u_29.TIERS[typeof(p12) ~= "number" and 0 or p12] or v_u_29.TIERS[0]).accel
	end,
	["scales"] = function(p13) -- name: scales
		-- upvalues: (copy) v_u_29
		local v14 = p13:GetAttribute("PistonBore")
		local v15 = v_u_29.TIERS[typeof(v14) ~= "number" and 0 or v14] or v_u_29.TIERS[0]
		return v15.accel, v15.top
	end,
	["PEAK_ENGINE"] = 3,
	["capKmhFor"] = function(p16, p17, p18, p19, p20) -- name: capKmhFor
		-- upvalues: (copy) v_u_29
		local v21
		if p19 then
			local v22 = (p19 - 1) / (v_u_29.CAP_FULL_GAIN - 1)
			v21 = math.clamp(v22, 0, 1)
		else
			v21 = 1
		end
		local v23
		if v_u_29.STOCK_BORE[p16] then
			local v24 = v_u_29.TIERS[typeof(p17) ~= "number" and 0 or p17] or v_u_29.TIERS[0]
			if p18 then
				v23 = v24.tuck
			else
				v23 = v24.cap
			end
		else
			v23 = v_u_29.CAR_KMH
			p18 = false
		end
		local v25 = v23 * (v_u_29.ECU_CAP_MIN + (1 - v_u_29.ECU_CAP_MIN) * v21)
		local v26 = p20 == nil and true or v_u_29.PEAK_ENGINE <= p20
		if v_u_29.PEAK_KMH <= v25 and (not p18 or (p17 ~= v_u_29.FULL_SIZE or not v26)) then
			v25 = v_u_29.PEAK_KMH - 1
		end
		return v25
	end,
	["capKmh"] = function(p27, p28) -- name: capKmh
		-- upvalues: (copy) v_u_29, (copy) v_u_1
		return v_u_29.capKmhFor(p27:GetAttribute("VehicleId") or p27.Name, p27:GetAttribute("PistonBore"), p28, v_u_1.gain(p27), tonumber(p27:GetAttribute("EngineLevel")) or 0)
	end
}
return v_u_29