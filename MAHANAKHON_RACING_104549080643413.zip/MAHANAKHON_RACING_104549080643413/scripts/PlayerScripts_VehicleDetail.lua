-- Path: Players/ygggggg55551/PlayerScripts/VehicleDetail
-- Class: LocalScript  true/Enum.RunContext.Legacy
-- Decompiled by BALL KUN Universal Map Dump

local v1 = game:GetService("Players")
local v2 = game:GetService("Lighting")
local v_u_3 = v1.LocalPlayer
local v_u_4 = {
	{ 80, 60, 0.5 },
	{ 220, 140, 1 },
	{ 330, 240, 2 }
}
local v_u_5 = {
	"light",
	"lamp",
	"drl",
	"signal",
	"indicator",
	"glow",
	"rainbow",
	"neon",
	"plate",
	"speedo",
	"sticker",
	"needle",
	"mirror",
	"seat",
	"collider",
	"hub",
	"wheel",
	"root",
	"logo",
	"badge",
	"carbon",
	"paint",
	"exhaust",
	"muffler",
	"pipe",
	"nozzle",
	"tip",
	"silencer",
	"shock",
	"spring",
	"susp",
	"fork",
	"swing",
	"damper",
	"coil",
	"caliper",
	"brake",
	"brembo",
	"disc",
	"disk",
	"rotor",
	"bolt",
	"lug",
	"nut",
	"spoke",
	"rim",
	"tire",
	"tyre",
	"advan",
	"kit",
	"part",
	"bramb",
	"gpracing",
	"mesin",
	"radiator",
	"stab",
	"kickstand",
	"stand",
	"foot",
	"spoiler",
	"wing",
	"lip",
	"diffuser",
	"skirt",
	"intake",
	"filter",
	"turbo",
	"piston",
	"engine",
	"\224\184\151\224\185\136\224\184\173",
	"\224\185\130\224\184\138\224\185\137\224\184\132",
	"\224\185\130\224\184\138\224\185\138\224\184\132",
	"\224\184\170\224\184\155\224\184\163\224\184\180\224\184\135",
	"\224\184\165\224\185\137\224\184\173",
	"\224\184\162\224\184\178\224\184\135",
	"\224\185\128\224\184\154\224\184\163\224\184\129",
	"\224\185\128\224\184\154\224\184\163\224\184\132",
	"\224\184\136\224\184\178\224\184\153",
	"\224\184\155\224\184\177\224\185\138\224\184\161",
	"\224\184\132\224\184\178\224\184\165\224\184\180\224\184\155",
	"\224\184\153\224\185\135\224\184\173\224\184\149",
	"\224\184\139\224\184\181\224\185\136",
	"\224\184\170\224\184\155\224\184\173\224\184\162\224\185\128\224\184\165\224\184\173\224\184\163\224\185\140",
	"\224\185\132\224\184\159",
	"\224\184\129\224\184\163\224\184\176\224\184\136\224\184\129"
}
local v_u_6 = {
	["SourceName"] = true,
	["FidelityWas"] = true,
	["Note"] = true,
	["KitPath"] = true
}
local v_u_7 = { "integrasmengine" }
local v_u_8 = {}
local function v_u_14(p9) -- name: noShadow
	if p9:IsA("BasePart") and p9.CastShadow then
		local v10 = p9.Size
		local v11 = v10.X
		local v12 = v10.Y
		local v13 = v10.Z
		if math.max(v11, v12, v13) < 2 then
			p9.CastShadow = false
		end
	end
end
local function v_u_18(p15) -- name: inBay
	-- upvalues: (copy) v_u_7
	local v16 = p15:lower()
	for _, v17 in v_u_7 do
		if v16:sub(1, #v17) ~= v17 then
			continue
		end
		return true
	end
	return false
end
local function v_u_31(p19) -- name: leaves
	local v20 = {}
	local v21 = {}
	for _, v22 in p19:GetDescendants() do
		if not (v22:IsA("JointInstance") or v22:IsA("WeldConstraint")) then
			continue
		end
		local v23 = v22.Part0
		local v24 = v22.Part1
		if not (v23 and v24) then
			continue
		end
		v20[v23] = v20[v23] or {}
		v20[v24] = v20[v24] or {}
		local v25 = v20[v23]
		table.insert(v25, v24)
		local v26 = v20[v24]
		table.insert(v26, v23)
		if not v22:IsA("Motor6D") then
			continue
		end
		v21[v23] = true
		v21[v24] = true
	end
	local v27 = {}
	for v28, v29 in v20 do
		local v30 = v29[1]
		if #v29 ~= 1 or (v21[v28] or (v30 == p19 or not v30:IsDescendantOf(p19))) then
			continue
		end
		v27[v28] = v30
	end
	return v27
end
local function v_u_56(p32) -- name: candidates
	-- upvalues: (copy) v_u_31, (copy) v_u_4, (copy) v_u_6, (copy) v_u_18, (copy) v_u_5
	local v33 = v_u_31(p32)
	local v34 = {}
	for _, v35 in p32:GetAttributes() do
		if type(v35) ~= "string" then
			continue
		end
		for v36 in v35:gmatch("[%w_%.]+") do
			v34[v36] = true
		end
	end
	local v37 = v_u_4[#v_u_4][3]
	local v38 = {}
	for _, v39 in p32:GetDescendants() do
		if not v39:IsA("BasePart") or (not v33[v39] or (v39:IsA("Seat") or (v39:IsA("VehicleSeat") or (v39.CanCollide or (v39.CanQuery or (v39.CanTouch or (v39.Transparency ~= 0 or (v39.Material == Enum.Material.Neon or v39.Material == Enum.Material.Glass)))))))) then
			continue
		end
		local v40 = v39.Size
		local v41 = v40.X
		local v42 = v40.Y
		local v43 = v40.Z
		if math.max(v41, v42, v43) >= v37 then
			continue
		end
		for v44 in v39:GetAttributes() do
			if v_u_6[v44] then
				continue
			end
			v45 = false
		end
		local v45 = true
		if not v45 or (v34[v39.Name] or v_u_18(v39.Name)) then
			break
		end
		local v46 = v39.Name:lower()
		local v47 = true
		for _, v48 in v_u_5 do
			if not v46:find(v48, 1, true) then
				continue
			end
			v47 = false
		end
		if v47 then
			for _, v49 in v39:GetChildren() do
				if v49:IsA("JointInstance") or (v49:IsA("WeldConstraint") or (v49:IsA("SurfaceAppearance") or v49:IsA("DataModelMesh"))) then
					continue
				end
				v47 = false
			end
		end
		if not v47 then
			break
		end
		local v50 = v39.Size
		local v51 = {}
		local v52 = v33[v39]
		local v53 = v50.X
		local v54 = v50.Y
		local v55 = v50.Z
		__set_list(v51, 1, {v39, v52, (math.max(v53, v54, v55))})
		table.insert(v38, v51)
	end
	return v38
end
local function v_u_62(p57) -- name: bayParts
	-- upvalues: (copy) v_u_31, (copy) v_u_18
	local v58 = v_u_31(p57)
	local v59 = {}
	for _, v60 in p57:GetDescendants() do
		if not v60:IsA("BasePart") or (not v58[v60] or (not v60.Massless or (v60.CanCollide or not v_u_18(v60.Name)))) then
			continue
		end
		local v61 = { v60, v58[v60] }
		table.insert(v59, v61)
	end
	return v59
end
local function v_u_69(p_u_63, p_u_64, p_u_65) -- name: take
	if p_u_63.hidden[p_u_64] then
		return
	else
		local v_u_66 = p_u_64.Parent
		if v_u_66 then
			if not pcall(function()
				-- upvalues: (copy) p_u_65, (copy) p_u_64, (copy) p_u_63, (copy) v_u_66
				local v67 = p_u_65.CFrame:ToObjectSpace(p_u_64.CFrame)
				p_u_64.Parent = nil
				local v68 = { v_u_66, p_u_65, v67 }
				p_u_63.hidden[p_u_64] = v68
			end) then
				pcall(function()
					-- upvalues: (copy) p_u_64, (copy) v_u_66
					p_u_64.Parent = v_u_66
				end)
			end
		end
	end
end
local function v_u_77(p70, p71, p_u_72) -- name: give
	local v73 = p70.hidden[p_u_72]
	if v73 then
		p70.hidden[p_u_72] = nil
		local v_u_74 = v73[1]
		local v_u_75 = v73[2]
		local v_u_76 = v73[3]
		if p_u_72.Parent == nil and (v_u_74 == p71 or v_u_74:IsDescendantOf(p71)) and v_u_75:IsDescendantOf(workspace) then
			pcall(function()
				-- upvalues: (copy) p_u_72, (copy) v_u_75, (copy) v_u_76, (copy) v_u_74
				p_u_72.CFrame = v_u_75.CFrame * v_u_76
				p_u_72.Parent = v_u_74
			end)
		end
	end
end
local function v_u_83(p78, p79, p80) -- name: setLevel
	-- upvalues: (copy) v_u_4, (copy) v_u_56, (copy) v_u_69, (copy) v_u_77
	if p80 ~= p78.level then
		p78.level = p80
		local v81 = p80 <= 0 and 0 or v_u_4[p80][3]
		if p80 > 0 and not p78.cands then
			p78.cands = v_u_56(p79)
		end
		for _, v82 in p78.cands or {} do
			if v82[3] < v81 then
				v_u_69(p78, v82[1], v82[2])
			else
				v_u_77(p78, p79, v82[1])
			end
		end
	end
end
task.spawn(function()
	-- upvalues: (copy) v_u_14
	local v_u_84 = workspace:WaitForChild("Map"):WaitForChild("Landmarks", 30)
	if v_u_84 then
		for _, v_u_85 in {
			{ "Showroom", "Display" },
			{ "RepairZone", "Vehicles" }
		} do
			task.spawn(function()
				-- upvalues: (copy) v_u_84, (copy) v_u_85, (ref) v_u_14
				local v86 = v_u_84:WaitForChild(v_u_85[1], 60)
				if v86 then
					v86 = v86:WaitForChild(v_u_85[2], 60)
				end
				if v86 then
					for _, v87 in v86:GetDescendants() do
						if not (v87:IsA("BasePart") and v87.CastShadow) then
							continue
						end
						local v88 = v87.Size
						local v89 = v88.X
						local v90 = v88.Y
						local v91 = v88.Z
						if math.max(v89, v90, v91) >= 2 then
							continue
						end
						v87.CastShadow = false
					end
					v86.DescendantAdded:Connect(v_u_14)
				end
			end)
		end
	end
end)
local v92 = workspace:WaitForChild("SpawnedVehicles")
local function v107(p_u_93) -- name: track
	-- upvalues: (copy) v_u_8, (copy) v_u_83, (copy) v_u_77, (copy) v_u_14
	if p_u_93:IsA("Model") then
		local v94 = v_u_8[p_u_93]
		if v94 then
			v94.gone = nil
			v_u_83(v94, p_u_93, 0)
			local v95 = v94
			if v95.bayOff ~= false then
				v95.bayOff = false
				for _, v96 in v95.bay or {} do
					v_u_77(v95, p_u_93, v96[1])
				end
			end
		else
			local v_u_97 = {
				["born"] = nil,
				["level"] = 0,
				["bayOff"] = false,
				["hidden"] = nil,
				["born"] = os.clock(),
				["hidden"] = {}
			}
			local v98 = {}
			for _, v99 in p_u_93:GetDescendants() do
				if not (v99:IsA("BasePart") and v99.CastShadow) then
					continue
				end
				local v100 = v99.Size
				local v101 = v100.X
				local v102 = v100.Y
				local v103 = v100.Z
				if math.max(v101, v102, v103) >= 2 then
					continue
				end
				v99.CastShadow = false
			end
			__set_list(v98, 1, {p_u_93.DescendantAdded:Connect(v_u_14), p_u_93:GetAttributeChangedSignal("HoodOpen"):Connect(function()
	-- upvalues: (copy) p_u_93, (ref) v_u_8, (ref) v_u_97, (ref) v_u_77
	if p_u_93:GetAttribute("HoodOpen") == true and v_u_8[p_u_93] == v_u_97 then
		local v104 = v_u_97
		local v105 = p_u_93
		if v104.bayOff == false then
			return
		end
		v104.bayOff = false
		for _, v106 in v104.bay or {} do
			v_u_77(v104, v105, v106[1])
		end
	end
end)})
			v_u_97.conns = v98
			v_u_8[p_u_93] = v_u_97
		end
	else
		return
	end
end
local function v110(p108) -- name: drop
	-- upvalues: (copy) v_u_8
	local v109 = v_u_8[p108]
	if v109 and not v109.gone then
		v109.gone = os.clock()
	end
end
local function v_u_118(p111, p112, p113) -- name: levelFor
	-- upvalues: (copy) v_u_4
	local v114 = 0
	for v115, v116 in v_u_4 do
		local v117
		if p112 then
			v117 = v116[2]
		else
			v117 = v116[1]
		end
		if v115 <= p113 then
			v117 = v117 - 30
		end
		if v117 > p111 then
			continue
		end
		v114 = v115
	end
	return v114
end
local function v_u_123(p119, p120, p121) -- name: setBay
	-- upvalues: (copy) v_u_62, (copy) v_u_69, (copy) v_u_77
	if p121 ~= p119.bayOff then
		p119.bayOff = p121
		if p121 and not p119.bay then
			p119.bay = v_u_62(p120)
		end
		for _, v122 in p119.bay or {} do
			if p121 then
				v_u_69(p119, v122[1], v122[2])
			else
				v_u_77(p119, p120, v122[1])
			end
		end
	end
end
local function v129(p124, p125) -- name: purge
	-- upvalues: (copy) v_u_8
	v_u_8[p124] = nil
	for _, v126 in p125.conns do
		v126:Disconnect()
	end
	for v127 in p125.hidden do
		if v127.Parent ~= nil then
			continue
		end
		local v128 = v127.Destroy
		pcall(v128, v127)
	end
end
for _, v130 in v92:GetChildren() do
	v107(v130)
end
v92.ChildAdded:Connect(v107)
v92.ChildRemoved:Connect(v110)
while true do
	task.wait(0.5)
	local v_u_131 = workspace:GetAttribute("VehicleDetailOff") == true
	local v_u_132 = v2:GetAttribute("LowGfx") == true
	local v_u_133 = workspace.CurrentCamera
	if v_u_133 then
		v_u_133 = v_u_133.CFrame.Position
	end
	local v_u_134 = os.clock()
	for v_u_135, v_u_136 in v_u_8 do
		if v_u_136.gone then
			if v_u_134 - v_u_136.gone <= 30 then
				continue
			end
			v129(v_u_135, v_u_136)
		elseif v_u_135.Parent == v92 then
			local v145, v146 = pcall(function()
				-- upvalues: (copy) v_u_134, (copy) v_u_136, (copy) v_u_123, (copy) v_u_135, (copy) v_u_131, (copy) v_u_133, (copy) v_u_3, (copy) v_u_83, (copy) v_u_118, (copy) v_u_132
				local v137 = v_u_134 - v_u_136.born >= 4
				local v138 = v_u_123
				local v139 = v_u_136
				local v140 = v_u_135
				local v141 = not v_u_131
				if v141 then
					if v137 then
						v141 = v_u_135:GetAttribute("HoodOpen") ~= true
					else
						v141 = v137
					end
				end
				v138(v139, v140, v141)
				if not v_u_131 and v_u_133 then
					local v142 = v_u_135
					local v143
					if v142:GetAttribute("OwnerUserId") == v_u_3.UserId then
						v143 = true
					else
						local v144 = v_u_3.Character
						if v144 then
							v144 = v144:FindFirstChildOfClass("Humanoid")
						end
						if v144 then
							v144 = v144.SeatPart
						end
						if v144 == nil then
							v143 = false
						else
							v143 = v144:IsDescendantOf(v142)
						end
					end
					if not v143 then
						if v137 then
							v_u_83(v_u_136, v_u_135, (v_u_118((v_u_135:GetPivot().Position - v_u_133).Magnitude, v_u_132, v_u_136.level)))
						end
						return
					end
				end
				v_u_83(v_u_136, v_u_135, 0)
			end)
			if v145 then
				continue
			end
			warn("VehicleDetail:", v146)
		else
			local v147 = v_u_8[v_u_135]
			if not v147 or v147.gone then
				continue
			end
			v147.gone = os.clock()
		end
	end
end