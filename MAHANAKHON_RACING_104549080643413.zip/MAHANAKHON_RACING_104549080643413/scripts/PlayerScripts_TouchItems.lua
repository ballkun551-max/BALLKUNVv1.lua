-- Path: Players/ygggggg55551/PlayerScripts/TouchItems
-- Class: LocalScript  true/Enum.RunContext.Legacy
-- Decompiled by BALL KUN Universal Map Dump

local v1 = game:GetService("Players")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("StarterGui")
local v_u_4 = game:GetService("TweenService")
local v5 = v2:WaitForChild("GameUI")
local v_u_6 = require(v5:WaitForChild("Theme"))
local v_u_7 = require(v5:WaitForChild("Icons"))
local v_u_8 = require(v5:WaitForChild("Toast"))
local v_u_9 = require(v5:WaitForChild("Menu"))
local v10 = require(v2:WaitForChild("ShopShared"))
if v_u_6.isTouch() then
	local v_u_11 = v1.LocalPlayer
	local v_u_12 = Color3.new(1, 1, 1)
	local v_u_13 = {
		["PistonItem"] = {
			["icon"] = "settings",
			["colors"] = nil,
			["order"] = 3,
			["colors"] = v_u_6.GRAD.blue
		}
	}
	for _, v14 in v10.ITEMS do
		if v14.once then
			continue
		end
		v_u_13[v14.id] = {
			["icon"] = v14.icon,
			["colors"] = v14.colors,
			["order"] = v14.id == "RepairKit" and 1 or 2
		}
	end
	local v_u_15 = {
		["icon"] = "bag",
		["colors"] = nil,
		["order"] = 9,
		["colors"] = v_u_6.GRAD.dark
	}
	local v16 = v_u_3.GetCoreGuiEnabled
	local v17 = Enum.CoreGuiType.Backpack
	local v18, v19 = pcall(v16, v_u_3, v17)
	if v18 and v19 then
		local v20 = v_u_3.SetCoreGuiEnabled
		local v21 = Enum.CoreGuiType.Backpack
		pcall(v20, v_u_3, v21, false)
	end
	local v_u_22 = v_u_6.screen("TouchItems", 4, v_u_11:WaitForChild("PlayerGui"))
	local v_u_23 = v_u_6.new("Frame", {
		["Name"] = "Bar",
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["Visible"] = false,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(1, 1),
		["Position"] = UDim2.new(1, -110, 1, -20),
		["Size"] = UDim2.fromOffset(0, 60),
		["AutomaticSize"] = Enum.AutomaticSize.X,
		["Parent"] = v_u_22
	}, { v_u_6.new("UIListLayout", {
			["FillDirection"] = Enum.FillDirection.Horizontal,
			["Padding"] = UDim.new(0, 8),
			["SortOrder"] = Enum.SortOrder.LayoutOrder
		}) })
	v_u_6.autoScale(v_u_23, v_u_6.PHONE_SHRINK)
	local function v_u_30() -- name: place
		-- upvalues: (copy) v_u_11, (copy) v_u_22, (copy) v_u_23
		local v24 = v_u_11.PlayerGui:FindFirstChild("TouchGui")
		if v24 then
			v24 = v24:FindFirstChild("TouchControlFrame")
		end
		if v24 then
			v24 = v24:FindFirstChild("JumpButton")
		end
		local v25
		if v24 and v24.AbsoluteSize.X > 0 then
			local v26 = UDim2.fromOffset
			local v27 = v24.AbsolutePosition.X - v_u_22.AbsolutePosition.X - 10
			local v28 = math.floor(v27)
			local v29 = v24.AbsolutePosition.Y + v24.AbsoluteSize.Y - v_u_22.AbsolutePosition.Y
			v25 = v26(v28, (math.floor(v29)))
		else
			v25 = UDim2.new(1, -110, 1, -20)
		end
		if v_u_23.Position ~= v25 then
			v_u_23.Position = v25
		end
	end
	local function v_u_34(p31) -- name: toggle
		-- upvalues: (copy) v_u_11, (copy) v_u_8
		local v32 = v_u_11.Character
		local v33
		if v32 then
			v33 = v32:FindFirstChildOfClass("Humanoid")
		else
			v33 = v32
		end
		if v33 and (v33.Health > 0 and not v33.SeatPart) then
			if p31.Parent == v32 then
				v33:UnequipTools()
			elseif p31.Parent and p31.Parent:IsA("Backpack") then
				v33:EquipTool(p31)
				if p31.ToolTip ~= "" then
					v_u_8.show(p31.ToolTip, "info")
				end
			end
		else
			return
		end
	end
	local v_u_35 = {}
	local function v_u_47(p_u_36) -- name: makeTile
		-- upvalues: (copy) v_u_13, (copy) v_u_15, (copy) v_u_6, (copy) v_u_12, (copy) v_u_23, (copy) v_u_7, (copy) v_u_4, (copy) v_u_34
		for v37, v39 in v_u_13 do
			if not p_u_36:GetAttribute(v37) then
				continue
			end
		end
		local v39 = v_u_15
		local v40 = v_u_6.new("Frame", {
			["Name"] = "Item",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["LayoutOrder"] = nil,
			["ZIndex"] = 2,
			["Parent"] = nil,
			["BackgroundColor3"] = v_u_12,
			["Size"] = UDim2.fromOffset(60, 60),
			["LayoutOrder"] = v39.order,
			["Parent"] = v_u_23
		})
		v_u_6.corner(v40, 18)
		v_u_6.new("UIGradient", {
			["Rotation"] = 90,
			["Color"] = nil,
			["Parent"] = nil,
			["Color"] = ColorSequence.new(v39.colors[1], v39.colors[2]),
			["Parent"] = v40
		})
		v_u_6.gloss(v40, 18, 0.28)
		local v41 = v_u_6.new("UIStroke", {
			["ApplyStrokeMode"] = nil,
			["Color"] = nil,
			["Transparency"] = 0.62,
			["Thickness"] = 1.5,
			["Parent"] = nil,
			["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
			["Color"] = v_u_12,
			["Parent"] = v40
		})
		local v42 = v_u_7.make(v39.icon, v_u_12, 30)
		v42.AnchorPoint = Vector2.new(0.5, 0.5)
		v42.Position = UDim2.new(0.5, 0, 0.5, -4)
		v42.ZIndex = 3
		v42.Parent = v40
		local v43 = v_u_6.text({
			["Name"] = "Count",
			["Text"] = "",
			["TextSize"] = 17,
			["FontFace"] = nil,
			["TextColor3"] = nil,
			["TextStrokeTransparency"] = 0.35,
			["TextXAlignment"] = nil,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = 4,
			["Parent"] = nil,
			["FontFace"] = v_u_6.FONT_HEAVY,
			["TextColor3"] = v_u_12,
			["TextXAlignment"] = Enum.TextXAlignment.Right,
			["AnchorPoint"] = Vector2.new(1, 1),
			["Position"] = UDim2.new(1, -5, 1, -1),
			["Size"] = UDim2.fromOffset(50, 18),
			["Parent"] = v40
		})
		local v44 = v_u_6.new("TextButton", {
			["Name"] = "Hit",
			["Text"] = "",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["ZIndex"] = 5,
			["Parent"] = nil,
			["Size"] = UDim2.fromScale(1, 1),
			["Parent"] = v40
		})
		local v_u_45 = v_u_6.new("UIScale", {
			["Parent"] = v40
		})
		v44.MouseButton1Down:Connect(function()
			-- upvalues: (ref) v_u_4, (copy) v_u_45, (ref) v_u_6
			v_u_4:Create(v_u_45, v_u_6.QUICK, {
				["Scale"] = 0.9
			}):Play()
		end)
		for _, v46 in { v44.MouseButton1Up, v44.MouseLeave } do
			v46:Connect(function()
				-- upvalues: (ref) v_u_4, (copy) v_u_45, (ref) v_u_6
				v_u_4:Create(v_u_45, v_u_6.QUICK, {
					["Scale"] = 1
				}):Play()
			end)
		end
		v44.Activated:Connect(function()
			-- upvalues: (ref) v_u_34, (copy) p_u_36
			v_u_34(p_u_36)
		end)
		return {
			["frame"] = v40,
			["count"] = v43,
			["ring"] = v41
		}
	end
	local function v_u_62() -- name: refresh
		-- upvalues: (copy) v_u_11, (copy) v_u_35, (copy) v_u_47, (copy) v_u_6, (copy) v_u_12, (copy) v_u_23, (copy) v_u_9, (copy) v_u_30
		local v48 = {}
		for _, v49 in { v_u_11:FindFirstChildOfClass("Backpack"), v_u_11.Character } do
			for _, v50 in not v49 and {} or v49:GetChildren() do
				if not v50:IsA("Tool") then
					continue
				end
				v48[v50] = true
				local v51 = v_u_35[v50] or v_u_47(v50)
				v_u_35[v50] = v51
				local v52 = v50.Name:match("\195\151%s*(%d+)%s*$")
				v51.count.Text = not v52 and "" or "\195\151" .. v52
				local v53 = v49 == v_u_11.Character
				local v54 = v51.ring
				local v55
				if v53 then
					v55 = v_u_6.YELLOW
				else
					v55 = v_u_12
				end
				v54.Color = v55
				v51.ring.Transparency = v53 and 0 or 0.62
				v51.ring.Thickness = v53 and 3 or 1.5
			end
		end
		for v56, v57 in v_u_35 do
			if v48[v56] then
				continue
			end
			v57.frame:Destroy()
			v_u_35[v56] = nil
		end
		local v58 = v_u_23
		local v59
		if next(v_u_35) == nil then
			v59 = false
		else
			local v60 = v_u_11.Character
			if v60 then
				v60 = v_u_11.Character:FindFirstChildOfClass("Humanoid")
			end
			local v61
			if v60 == nil then
				v61 = false
			else
				v61 = v60.SeatPart ~= nil
			end
			v59 = not v61
			if v59 then
				v59 = not v_u_9.isOpen
			end
		end
		v58.Visible = v59
		v_u_30()
	end
	local v_u_63 = false
	local function v_u_64() -- name: soon
		-- upvalues: (ref) v_u_63, (copy) v_u_62
		if not v_u_63 then
			v_u_63 = true
			task.defer(function()
				-- upvalues: (ref) v_u_63, (ref) v_u_62
				v_u_63 = false
				v_u_62()
			end)
		end
	end
	local function v67(p65) -- name: onCharacter
		-- upvalues: (copy) v_u_64, (ref) v_u_63, (copy) v_u_62
		p65.ChildAdded:Connect(v_u_64)
		p65.ChildRemoved:Connect(v_u_64)
		local v66 = p65:WaitForChild("Humanoid", 10)
		if v66 then
			v66:GetPropertyChangedSignal("SeatPart"):Connect(v_u_64)
		end
		if not v_u_63 then
			v_u_63 = true
			task.defer(function()
				-- upvalues: (ref) v_u_63, (ref) v_u_62
				v_u_63 = false
				v_u_62()
			end)
		end
	end
	v_u_11.CharacterAdded:Connect(v67)
	if v_u_11.Character then
		task.spawn(v67, v_u_11.Character)
	end
	v_u_11.ChildAdded:Connect(function(p68)
		-- upvalues: (copy) v_u_64, (ref) v_u_63, (copy) v_u_62
		if p68:IsA("Backpack") then
			p68.ChildAdded:Connect(v_u_64)
			p68.ChildRemoved:Connect(v_u_64)
			if not v_u_63 then
				v_u_63 = true
				task.defer(function()
					-- upvalues: (ref) v_u_63, (ref) v_u_62
					v_u_63 = false
					v_u_62()
				end)
			end
		end
	end)
	local v69 = v_u_11:FindFirstChildOfClass("Backpack")
	if v69 then
		v69.ChildAdded:Connect(v_u_64)
		v69.ChildRemoved:Connect(v_u_64)
	end
	v_u_9.changed.Event:Connect(function()
		-- upvalues: (copy) v_u_64
		task.delay(0.1, v_u_64)
	end)
	task.spawn(function()
		-- upvalues: (copy) v_u_22, (copy) v_u_3, (copy) v_u_62
		while v_u_22.Parent do
			local v70 = v_u_3.GetCoreGuiEnabled
			local v71 = v_u_3
			local v72 = Enum.CoreGuiType.Backpack
			local v73, v74 = pcall(v70, v71, v72)
			if v73 and v74 then
				local v75 = v_u_3.SetCoreGuiEnabled
				local v76 = v_u_3
				local v77 = Enum.CoreGuiType.Backpack
				pcall(v75, v76, v77, false)
			end
			v_u_62()
			task.wait(1)
		end
	end)
end