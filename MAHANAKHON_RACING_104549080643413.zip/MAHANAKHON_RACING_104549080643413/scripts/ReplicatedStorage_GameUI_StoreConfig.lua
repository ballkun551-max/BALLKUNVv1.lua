-- Path: ReplicatedStorage/GameUI/StoreConfig
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v1 = {
	["GAMEPASSES"] = {
		{
			["key"] = "VIP",
			["id"] = 2052456637,
			["gift"] = 3722578211,
			["name"] = "VIP",
			["icon"] = "crown",
			["grad"] = "gold",
			["description"] = "Stand out on every street",
			["perks"] = nil,
			["perks"] = { "\240\159\145\145 VIP on your nametag, your colour", "x1.5 pay from every job", "No wait between spawns" }
		},
		{
			["key"] = "Custom",
			["id"] = nil,
			["gift"] = nil,
			["name"] = "Custom",
			["icon"] = "brush",
			["grad"] = "pink",
			["description"] = "Paint and light your ride any way you like",
			["perks"] = nil,
			["perks"] = { "Free color picker: any color", "Chrome finish + gradient RGB lights", "Underglow on cars" }
		},
		{
			["key"] = "LuxuryCar",
			["id"] = nil,
			["gift"] = nil,
			["name"] = "Luxury Car",
			["icon"] = "car",
			["grad"] = "purple",
			["description"] = "A luxury car in your garage",
			["perks"] = nil,
			["perks"] = { "Unlocks the luxury car to spawn", "Tune it like any other car" }
		},
		{
			["key"] = "GiornoCustom",
			["id"] = nil,
			["product"] = 3724398302,
			["gift"] = 3724398302,
			["name"] = "Giorno Duo",
			["icon"] = "car",
			["grad"] = "orange",
			["description"] = "Two custom Retro Round 125 scooters",
			["perks"] = nil,
			["perks"] = { "Retro Round 125 Custom Blue + Custom Green", "Their own RGB light kit: lights you can change", "Tune them like any other bike (no paint)" }
		},
		{
			["key"] = "LeadGreen",
			["id"] = nil,
			["product"] = 3726613684,
			["gift"] = 3726613684,
			["name"] = "Lead 125 \224\184\165\224\184\178\224\184\162\224\185\132\224\184\159\224\184\170\224\184\181\224\185\128\224\184\130\224\184\181\224\184\162\224\184\167",
			["icon"] = "car",
			["grad"] = "green",
			["description"] = "A green flame Family Box 125 scooter",
			["perks"] = nil,
			["perks"] = { "Family Box 125 Green Flame", "Launches and runs like the Retro Round 125 Custom", "Lights you can change, tune it like any other bike (no paint)" }
		},
		{
			["key"] = "Skylo160",
			["id"] = nil,
			["product"] = 3729614518,
			["gift"] = 3729614518,
			["name"] = "Skylo160",
			["icon"] = "car",
			["grad"] = "purple",
			["description"] = "A Retro Style 160 R scooter",
			["perks"] = nil,
			["perks"] = { "Retro Style 160 R: sequential signals, RGB tail and front lights", "Parts you can take off or swap (SC exhaust)", "Paint, carbon and tune it like any other bike" }
		},
		{
			["key"] = "GiornoClassic",
			["id"] = nil,
			["product"] = 3731713216,
			["gift"] = 3731713216,
			["name"] = "Giorno Mahanakhon \224\184\165\224\184\178\224\184\162\224\185\132\224\184\159",
			["icon"] = "car",
			["grad"] = "red",
			["description"] = "A Retro Round 125 Classic scooter",
			["perks"] = nil,
			["perks"] = { "Retro Round 125 Classic: rainbow front lens, flame pops", "Bolt-ons: CNC / gold / black rims, CNC CVT cover, exhausts, livery colours", "Paint, carbon and tune it like any other bike" }
		},
		{
			["key"] = "X2Money",
			["id"] = 2053680656,
			["gift"] = 3722578296,
			["name"] = "2x Money",
			["icon"] = "coin",
			["grad"] = "green",
			["description"] = "Every job pays double",
			["perks"] = nil,
			["perks"] = { "x2 pay: deliveries, rides, repairs, building", "With VIP: x2.5" }
		}
	},
	["MONEY"] = {
		{
			["id"] = 3722577197,
			["pass"] = 2054046789,
			["cash"] = 10000,
			["tier"] = 1
		},
		{
			["id"] = 3722577492,
			["pass"] = 2053380623,
			["cash"] = 35000,
			["tier"] = 2,
			["tag"] = "+15%"
		},
		{
			["id"] = 3722577602,
			["pass"] = 2052924717,
			["cash"] = 80000,
			["tier"] = 3
		},
		{
			["id"] = 3722577965,
			["pass"] = 2053578683,
			["cash"] = 200000,
			["tier"] = 4,
			["tag"] = "+30%"
		},
		{
			["id"] = 3722578129,
			["pass"] = 2052666704,
			["cash"] = 500000,
			["tier"] = 5,
			["tag"] = "BEST VALUE"
		}
	}
}
return v1