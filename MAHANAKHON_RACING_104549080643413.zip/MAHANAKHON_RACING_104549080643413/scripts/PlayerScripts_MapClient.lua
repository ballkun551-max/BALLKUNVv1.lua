-- Path: Players/ygggggg55551/PlayerScripts/MapClient
-- Class: LocalScript  true/Enum.RunContext.Legacy
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = require(game:GetService("ReplicatedStorage"):WaitForChild("UiOwn")).Instance
local v2 = game:GetService("Players")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("CollectionService")
local v_u_5 = game:GetService("Lighting")
local v_u_6 = v2.LocalPlayer
local v7 = Font.new("rbxasset://fonts/families/GothamSSm.json", Enum.FontWeight.Bold)
Font.new("rbxasset://fonts/families/GothamSSm.json", Enum.FontWeight.Medium)
local v8 = v_u_1.new("ScreenGui")
v8.Name = "MapUI"
v8.ResetOnSpawn = false
v8.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
v8.Parent = v_u_6:WaitForChild("PlayerGui")
local v9 = game:GetService("UserInputService").TouchEnabled
if v9 then
	v9 = not game:GetService("UserInputService").KeyboardEnabled
end
local v10 = v_u_1.new("TextButton")
v10.Name = "SkyButton"
v10.Size = UDim2.fromOffset(112, 40)
local v11
if v9 then
	v11 = UDim2.fromOffset(12, 72)
else
	v11 = UDim2.fromOffset(16, 12)
end
v10.Position = v11
v10.Visible = not game:GetService("StarterPlayer").StarterPlayerScripts:FindFirstChild("GameHud")
v10.BackgroundColor3 = Color3.fromRGB(0, 82, 160)
v10.TextColor3 = Color3.fromRGB(238, 238, 232)
v10.FontFace = Font.new("rbxasset://fonts/families/BuilderSans.json", Enum.FontWeight.Bold)
v10.TextSize = 18
v10.Text = "      Sky"
v10.AutoButtonColor = true
v10.Parent = v8
local v12 = v_u_1.new("UICorner")
v12.CornerRadius = UDim.new(0, 8)
v12.Parent = v10
local v13 = v_u_1.new("UIStroke")
v13.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
v13.Color = Color3.new(1, 1, 1)
v13.Transparency = 0.7
v13.Thickness = 1.5
v13.Parent = v10
local v14 = v_u_1.new("Frame")
v14.BackgroundTransparency = 1
v14.Size = UDim2.fromOffset(12, 12)
v14.Position = UDim2.fromOffset(20, 9)
v14.Parent = v10
local v15 = v_u_1.new("UICorner")
v15.CornerRadius = UDim.new(0, 6)
v15.Parent = v14
local v16 = v_u_1.new("UIStroke")
v16.Color = Color3.fromRGB(238, 238, 232)
v16.Thickness = 2
v16.Parent = v14
local v17 = v_u_1.new("Frame")
v17.BorderSizePixel = 0
v17.BackgroundColor3 = Color3.fromRGB(238, 238, 232)
v17.Size = UDim2.fromOffset(2, 9)
v17.Position = UDim2.fromOffset(25, 22)
v17.Parent = v10
local v_u_18 = v_u_1.new("Frame")
v_u_18.Name = "WarpPanel"
v_u_18.Size = UDim2.fromOffset(340, 460)
local v19
if v9 then
	v19 = Vector2.new(0, 0)
else
	v19 = Vector2.new(0, 1)
end
v_u_18.AnchorPoint = v19
local v20
if v9 then
	v20 = UDim2.fromOffset(12, 12)
else
	v20 = UDim2.new(0, 96, 1, -76)
end
v_u_18.Position = v20
v_u_18.BackgroundColor3 = Color3.fromRGB(32, 33, 36)
v_u_18.BackgroundTransparency = 0.12
v_u_18.Visible = false
v_u_18.Parent = v8
local v21 = v_u_1.new("UICorner")
v21.CornerRadius = UDim.new(0, 8)
v21.Parent = v_u_18
local v22 = v_u_1.new("UIStroke")
v22.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
v22.Color = Color3.new(1, 1, 1)
v22.Transparency = 0.7
v22.Thickness = 1.5
v22.Parent = v_u_18
local v23 = v_u_1.new("TextLabel")
v23.BackgroundTransparency = 1
v23.Size = UDim2.new(1, -60, 0, 44)
v23.Position = UDim2.fromOffset(16, 6)
v23.Text = "Time & weather"
v23.TextColor3 = Color3.new(1, 1, 1)
v23.FontFace = v7
v23.TextSize = 22
v23.TextXAlignment = Enum.TextXAlignment.Left
v23.Parent = v_u_18
local v24 = v_u_1.new("TextButton")
v24.Size = UDim2.fromOffset(36, 36)
v24.Position = UDim2.new(1, -46, 0, 10)
v24.Text = "X"
v24.TextSize = 18
v24.BackgroundColor3 = Color3.fromRGB(60, 30, 34)
v24.TextColor3 = Color3.new(1, 1, 1)
v24.FontFace = v7
v24.Parent = v_u_18
local v25 = v_u_1.new("UICorner")
v25.CornerRadius = UDim.new(0, 8)
v25.Parent = v24
local v26 = v_u_1.new("ScrollingFrame")
v26.Size = UDim2.new(1, -20, 1, -118)
v26.Position = UDim2.fromOffset(10, 54)
v26.BackgroundTransparency = 1
v26.BorderSizePixel = 0
v26.ScrollBarThickness = 6
v26.AutomaticCanvasSize = Enum.AutomaticSize.Y
v26.CanvasSize = UDim2.new()
v26.Parent = v_u_18
local v27 = v_u_1.new("UIListLayout")
v27.Padding = UDim.new(0, 6)
v27.SortOrder = Enum.SortOrder.LayoutOrder
v27.Parent = v26
local v_u_28 = game:GetService("TweenService")
local v29 = game:GetService("RunService")
local v_u_30 = game:GetService("SoundService")
local function v34(p31) -- name: makeBar
	-- upvalues: (copy) v_u_1, (copy) v_u_18
	local v32 = v_u_1.new("Frame")
	v32.Size = UDim2.new(1, -20, 0, 40)
	v32.Position = UDim2.new(0, 10, 1, p31)
	v32.BackgroundTransparency = 1
	v32.Parent = v_u_18
	local v33 = v_u_1.new("UIListLayout")
	v33.FillDirection = Enum.FillDirection.Horizontal
	v33.Padding = UDim.new(0, 5)
	v33.Parent = v32
	return v32
end
v_u_18.Size = UDim2.fromOffset(340, 520)
v26.Size = UDim2.new(1, -20, 1, -158)
if v9 then
	v_u_18.Size = UDim2.new(0, 340, 1, -152)
	local v35 = v_u_1.new("UISizeConstraint")
	v35.MaxSize = Vector2.new(340, 520)
	v35.Parent = v_u_18
end
local v36 = v34(-96)
local v37 = v34(-50)
local v_u_38 = v_u_5:FindFirstChildOfClass("Atmosphere")
local v_u_39 = v_u_5:FindFirstChild("BKK_ColorCorrection") or v_u_5:FindFirstChildOfClass("ColorCorrectionEffect")
local v_u_40 = v_u_5:FindFirstChild("Bloom") or v_u_5:FindFirstChildOfClass("BloomEffect")
local v_u_41 = v_u_5:FindFirstChildOfClass("SunRaysEffect")
local v_u_42 = v_u_1.new("ColorCorrectionEffect")
v_u_42.Name = "WeatherGrade"
v_u_42.Parent = v_u_5
local v_u_43 = v_u_1.new("ColorCorrectionEffect")
v_u_43.Name = "LightningFlash"
v_u_43.Parent = v_u_5
local v_u_44 = workspace.Terrain:FindFirstChildOfClass("Clouds") or v_u_1.new("Clouds")
v_u_44.Enabled = false
v_u_44.Cover = 0
v_u_44.Parent = workspace.Terrain
local v45 = Color3.fromRGB
local v_u_46 = {
	{
		["id"] = "Dawn",
		["label"] = "Dawn",
		["clock"] = 6.3,
		["lights"] = true,
		["lamp"] = 0.55,
		["lighting"] = nil,
		["atmosphere"] = nil,
		["grade"] = nil,
		["bloom"] = nil,
		["sunRays"] = nil,
		["lighting"] = {
			["Brightness"] = 1.6,
			["ExposureCompensation"] = 0,
			["Ambient"] = nil,
			["OutdoorAmbient"] = nil,
			["Ambient"] = v45(68, 66, 80),
			["OutdoorAmbient"] = v45(104, 100, 124)
		},
		["atmosphere"] = {
			["Density"] = 0.38,
			["Offset"] = 0.25,
			["Color"] = nil,
			["Decay"] = nil,
			["Glare"] = 0.9,
			["Haze"] = 1.8,
			["Color"] = v45(214, 182, 172),
			["Decay"] = v45(104, 110, 150)
		},
		["grade"] = {
			["TintColor"] = nil,
			["Saturation"] = 0.06,
			["Contrast"] = 0.1,
			["Brightness"] = 0,
			["TintColor"] = v45(255, 242, 236)
		},
		["bloom"] = {
			["Intensity"] = 0.3,
			["Size"] = 20,
			["Threshold"] = 2
		},
		["sunRays"] = {
			["Intensity"] = 0.1,
			["Spread"] = 0.8
		}
	},
	{
		["id"] = "Day",
		["label"] = "Day",
		["clock"] = 12,
		["lights"] = false,
		["lamp"] = 0,
		["sky"] = "Mountain Sunrise",
		["lighting"] = nil,
		["atmosphere"] = nil,
		["grade"] = nil,
		["bloom"] = nil,
		["sunRays"] = nil,
		["lighting"] = {
			["Brightness"] = 2.5,
			["ExposureCompensation"] = 0,
			["Ambient"] = nil,
			["OutdoorAmbient"] = nil,
			["Ambient"] = v45(70, 70, 70),
			["OutdoorAmbient"] = v45(70, 70, 70)
		},
		["atmosphere"] = {
			["Density"] = 0.225,
			["Offset"] = 1,
			["Color"] = nil,
			["Decay"] = nil,
			["Glare"] = 0.17,
			["Haze"] = 0.21,
			["Color"] = v45(138, 138, 138),
			["Decay"] = v45(99, 81, 62)
		},
		["grade"] = {
			["TintColor"] = nil,
			["Saturation"] = 0,
			["Contrast"] = 0,
			["Brightness"] = 0,
			["TintColor"] = v45(255, 255, 255)
		},
		["bloom"] = {
			["Intensity"] = 1,
			["Size"] = 24,
			["Threshold"] = 2
		},
		["sunRays"] = {
			["Intensity"] = 0.027,
			["Spread"] = 1
		}
	},
	{
		["id"] = "Dusk",
		["label"] = "Evening",
		["clock"] = 17.6,
		["lights"] = true,
		["lamp"] = 0.6,
		["lighting"] = nil,
		["atmosphere"] = nil,
		["grade"] = nil,
		["bloom"] = nil,
		["sunRays"] = nil,
		["lighting"] = {
			["Brightness"] = 1.6,
			["ExposureCompensation"] = -0.1,
			["Ambient"] = nil,
			["OutdoorAmbient"] = nil,
			["Ambient"] = v45(74, 68, 68),
			["OutdoorAmbient"] = v45(112, 100, 98)
		},
		["atmosphere"] = {
			["Density"] = 0.35,
			["Offset"] = 0.22,
			["Color"] = nil,
			["Decay"] = nil,
			["Glare"] = 0.6,
			["Haze"] = 1.7,
			["Color"] = v45(222, 178, 148),
			["Decay"] = v45(128, 102, 100)
		},
		["grade"] = {
			["TintColor"] = nil,
			["Saturation"] = 0.06,
			["Contrast"] = 0.12,
			["Brightness"] = 0,
			["TintColor"] = v45(255, 244, 234)
		},
		["bloom"] = {
			["Intensity"] = 0.3,
			["Size"] = 20,
			["Threshold"] = 2
		},
		["sunRays"] = {
			["Intensity"] = 0.08,
			["Spread"] = 0.6
		}
	},
	{
		["id"] = "Night",
		["label"] = "Night",
		["clock"] = 21.5,
		["lights"] = true,
		["lamp"] = 1.3,
		["lighting"] = nil,
		["atmosphere"] = nil,
		["grade"] = nil,
		["bloom"] = nil,
		["sunRays"] = nil,
		["lighting"] = {
			["Brightness"] = 1,
			["ExposureCompensation"] = 0.45,
			["Ambient"] = nil,
			["OutdoorAmbient"] = nil,
			["Ambient"] = v45(62, 68, 88),
			["OutdoorAmbient"] = v45(92, 102, 134)
		},
		["atmosphere"] = {
			["Density"] = 0.34,
			["Offset"] = 0.15,
			["Color"] = nil,
			["Decay"] = nil,
			["Glare"] = 0,
			["Haze"] = 1,
			["Color"] = v45(72, 84, 116),
			["Decay"] = v45(40, 46, 72)
		},
		["grade"] = {
			["TintColor"] = nil,
			["Saturation"] = 0.06,
			["Contrast"] = 0.08,
			["Brightness"] = 0,
			["TintColor"] = v45(232, 238, 255)
		},
		["bloom"] = {
			["Intensity"] = 0.45,
			["Size"] = 22,
			["Threshold"] = 1.6
		},
		["sunRays"] = {
			["Intensity"] = 0,
			["Spread"] = 0.5
		}
	}
}
local v_u_47 = {
	["id"] = "Auto",
	["label"] = "Auto"
}
local v_u_48 = true
local v_u_49 = {
	{
		["minutes"] = 4,
		["from"] = 5,
		["to"] = 7.5
	},
	{
		["minutes"] = 28,
		["from"] = 7.5,
		["to"] = 16.5
	},
	{
		["minutes"] = 4,
		["from"] = 16.5,
		["to"] = 19
	},
	{
		["minutes"] = 12,
		["from"] = 19,
		["to"] = 29
	}
}
local v_u_50 = {
	{ 0, "Night" },
	{ 5.2, "Night" },
	{ 6.4, "Dawn" },
	{ 8.2, "Day" },
	{ 16.2, "Day" },
	{ 17.6, "Dusk" },
	{ 19.4, "Night" },
	{ 24, "Night" }
}
local v_u_51 = { "rbxassetid://139319051979882", "rbxassetid://136909414800877" }
local v_u_52 = {
	{
		["id"] = "Clear",
		["label"] = "Sunny",
		["light"] = 1,
		["grey"] = 0,
		["tint"] = nil,
		["saturation"] = 0,
		["clouds"] = nil,
		["tint"] = v45(255, 255, 255),
		["clouds"] = {
			["Cover"] = 0.529,
			["Density"] = 0.367,
			["Color"] = nil,
			["Color"] = v45(255, 255, 255)
		}
	},
	{
		["id"] = "Rain",
		["label"] = "Rain",
		["light"] = 0.55,
		["grey"] = 0.6,
		["dim"] = 0.85,
		["greyColor"] = nil,
		["density"] = 0.45,
		["haze"] = 2.6,
		["saturation"] = -0.18,
		["tint"] = nil,
		["clouds"] = nil,
		["rain"] = 1,
		["wet"] = true,
		["sound"] = "rbxassetid://7127218501",
		["volume"] = 0.55,
		["greyColor"] = v45(150, 156, 166),
		["tint"] = v45(232, 238, 246),
		["clouds"] = {
			["Cover"] = 0.88,
			["Density"] = 0.8,
			["Color"] = nil,
			["Color"] = v45(150, 154, 162)
		}
	},
	{
		["id"] = "Storm",
		["label"] = "Storm",
		["light"] = 0.32,
		["grey"] = 0.85,
		["dim"] = 0.6,
		["greyColor"] = nil,
		["density"] = 0.55,
		["haze"] = 3.2,
		["saturation"] = -0.28,
		["tint"] = nil,
		["clouds"] = nil,
		["rain"] = 2.2,
		["wind"] = Vector3.new(14, 0, 6),
		["wet"] = true,
		["lightning"] = true,
		["lightsOn"] = true,
		["sound"] = "rbxassetid://5911952995",
		["volume"] = 0.85,
		["greyColor"] = v45(96, 102, 114),
		["tint"] = v45(220, 228, 242),
		["clouds"] = {
			["Cover"] = 1,
			["Density"] = 1,
			["Color"] = nil,
			["Color"] = v45(80, 84, 92)
		}
	},
	{
		["id"] = "Snow",
		["label"] = "Snow",
		["light"] = 0.85,
		["grey"] = 0.55,
		["greyColor"] = nil,
		["density"] = 0.5,
		["haze"] = 2.4,
		["saturation"] = -0.22,
		["tint"] = nil,
		["clouds"] = nil,
		["snow"] = 1,
		["wind"] = Vector3.new(2, 0, 1),
		["greyColor"] = v45(214, 222, 236),
		["tint"] = v45(236, 244, 255),
		["clouds"] = {
			["Cover"] = 0.9,
			["Density"] = 0.7,
			["Color"] = nil,
			["Color"] = v45(226, 230, 238)
		}
	},
	{
		["id"] = "Fog",
		["label"] = "Fog",
		["light"] = 0.8,
		["grey"] = 0.6,
		["greyColor"] = nil,
		["density"] = 0.72,
		["offset"] = 0.05,
		["haze"] = 4,
		["saturation"] = -0.12,
		["tint"] = nil,
		["clouds"] = nil,
		["greyColor"] = v45(196, 198, 202),
		["tint"] = v45(246, 248, 252),
		["clouds"] = {
			["Cover"] = 0.8,
			["Density"] = 0.4,
			["Color"] = nil,
			["Color"] = v45(210, 212, 216)
		}
	}
}
local v_u_53 = v_u_46[2]
local v_u_54 = v_u_52[1]
local v_u_55 = TweenInfo.new(1.5, Enum.EasingStyle.Sine)
local function v_u_68(p56, p57, p58) -- name: toward
	if p58 <= 0 then
		return p56
	end
	local v59 = (p56.R + p56.G + p56.B) / 3
	local v60 = (p57.R + p57.G + p57.B) / 3
	local v61 = math.max(v60, 0.001)
	local v62 = Color3.new
	local v63 = p57.R / v61 * v59
	local v64 = math.min(v63, 1)
	local v65 = p57.G / v61 * v59
	local v66 = math.min(v65, 1)
	local v67 = p57.B / v61 * v59
	return p56:Lerp(v62(v64, v66, (math.min(v67, 1))), p58)
end
local v_u_69 = v45(255, 240, 222)
local v_u_70 = setmetatable({}, {
	["__mode"] = "k"
})
local v_u_71 = false
local v_u_72 = 0
local v_u_73 = v_u_5:GetAttribute("LowGfx") == true
local function v_u_77(p74) -- name: lampLook
	-- upvalues: (copy) v_u_70, (ref) v_u_72, (copy) v_u_69, (ref) v_u_71, (ref) v_u_73
	local v75 = v_u_70[p74]
	if not v75 then
		v75 = { p74.Brightness, p74.Color }
		v_u_70[p74] = v75
	end
	p74.Brightness = v75[1] * v_u_72
	p74.Color = v75[2]:Lerp(v_u_69, 0.7)
	local v76 = v_u_71
	if v76 then
		v76 = not v_u_73
	end
	p74.Enabled = v76
end
v_u_4:GetInstanceAddedSignal("StreetLight"):Connect(v_u_77)
v_u_4:GetInstanceAddedSignal("StreetLampLens"):Connect(function(p78)
	-- upvalues: (ref) v_u_71
	p78.Material = v_u_71 and Enum.Material.Neon or Enum.Material.SmoothPlastic
end)
local v_u_79 = v_u_1.new("Folder")
v_u_79.Name = "WeatherFX"
local v_u_80 = v_u_73
local v_u_81 = {}
local function v_u_84() -- name: applyLights
	-- upvalues: (copy) v_u_4, (copy) v_u_77, (ref) v_u_71
	for _, v82 in ipairs(v_u_4:GetTagged("StreetLight")) do
		v_u_77(v82)
	end
	for _, v83 in ipairs(v_u_4:GetTagged("StreetLampLens")) do
		v83.Material = v_u_71 and Enum.Material.Neon or Enum.Material.SmoothPlastic
	end
end
for v85 = 1, 5 do
	for v86 = 1, 5 do
		local v87 = v_u_1.new("Part")
		v87.Name = "Cell"
		v87.Anchored = true
		v87.CanCollide = false
		v87.CanQuery = false
		v87.CanTouch = false
		v87.CastShadow = false
		v87.Transparency = 1
		v87.Size = Vector3.new(18, 0.2, 18)
		v87.Parent = v_u_79
		local v88 = v_u_1.new("ParticleEmitter")
		v88.Name = "Rain"
		v88.Texture = "rbxasset://textures/particles/sparkles_main.dds"
		v88.EmissionDirection = Enum.NormalId.Bottom
		v88.Orientation = Enum.ParticleOrientation.VelocityParallel
		v88.Speed = NumberRange.new(90, 100)
		v88.Lifetime = NumberRange.new(0.7, 0.8)
		v88.Size = NumberSequence.new(0.38)
		v88.Squash = NumberSequence.new(-4)
		v88.Color = ColorSequence.new(v45(200, 210, 225))
		v88.LightEmission = 0.4
		v88.LightInfluence = 0.7
		v88.Transparency = NumberSequence.new(0.4)
		v88.SpreadAngle = Vector2.new(2, 2)
		v88.Rate = 0
		v88.Parent = v87
		local v89 = v_u_1.new("ParticleEmitter")
		v89.Name = "Snow"
		v89.Texture = "rbxasset://textures/particles/smoke_main.dds"
		v89.EmissionDirection = Enum.NormalId.Bottom
		v89.Speed = NumberRange.new(4, 7)
		v89.Lifetime = NumberRange.new(8, 10)
		v89.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.22, 0.08), NumberSequenceKeypoint.new(1, 0.22, 0.08) })
		v89.Rotation = NumberRange.new(0, 360)
		v89.RotSpeed = NumberRange.new(-50, 50)
		v89.SpreadAngle = Vector2.new(25, 25)
		v89.Color = ColorSequence.new(v45(255, 255, 255))
		v89.LightEmission = 0.7
		v89.LightInfluence = 0.6
		v89.Transparency = NumberSequence.new({
			NumberSequenceKeypoint.new(0, 1),
			NumberSequenceKeypoint.new(0.08, 0),
			NumberSequenceKeypoint.new(0.9, 0),
			NumberSequenceKeypoint.new(1, 1)
		})
		v89.Rate = 0
		v89.Parent = v87
		local v90 = {
			["part"] = nil,
			["rain"] = nil,
			["snow"] = nil,
			["ox"] = nil,
			["oz"] = nil,
			["covered"] = false,
			["part"] = v87,
			["rain"] = v88,
			["snow"] = v89,
			["ox"] = (v85 - 3) * 18,
			["oz"] = (v86 - 3) * 18
		}
		table.insert(v_u_81, v90)
	end
end
local v91 = v_u_1.new("Part")
v91.Name = "Splashes"
v91.Anchored = true
v91.CanCollide = false
v91.CanQuery = false
v91.CanTouch = false
v91.Transparency = 1
v91.Size = Vector3.new(0.2, 0.2, 0.2)
v91.Parent = v_u_79
local v_u_92 = v_u_1.new("Attachment")
v_u_92.Parent = v91
local v_u_93 = v_u_1.new("ParticleEmitter")
v_u_93.Texture = "rbxasset://textures/particles/smoke_main.dds"
v_u_93.EmissionDirection = Enum.NormalId.Top
v_u_93.SpreadAngle = Vector2.new(70, 70)
v_u_93.Speed = NumberRange.new(1.5, 3)
v_u_93.Lifetime = NumberRange.new(0.2, 0.3)
v_u_93.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.15), NumberSequenceKeypoint.new(1, 0.6) })
v_u_93.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.55), NumberSequenceKeypoint.new(1, 1) })
v_u_93.Color = ColorSequence.new(v45(210, 220, 230))
v_u_93.LightEmission = 0.3
v_u_93.Rate = 0
v_u_93.Parent = v_u_92
local v_u_94 = v_u_1.new("Sound")
v_u_94.Name = "WeatherRain"
v_u_94.Looped = true
v_u_94.Volume = 0
v_u_94.Parent = v_u_30
local v_u_95 = v_u_1.new("EqualizerSoundEffect")
v_u_95.HighGain = 0
v_u_95.MidGain = 0
v_u_95.LowGain = 0
v_u_95.Parent = v_u_94
local v_u_96 = {}
local v_u_97 = RaycastParams.new()
v_u_97.FilterType = Enum.RaycastFilterType.Exclude
local function v_u_104() -- name: refreshSkip
	-- upvalues: (copy) v_u_96, (copy) v_u_79, (copy) v_u_6, (copy) v_u_97
	table.clear(v_u_96)
	local v98 = v_u_96
	local v99 = v_u_79
	table.insert(v98, v99)
	local v100 = v_u_6.Character
	if v100 then
		local v101 = v_u_96
		table.insert(v101, v100)
		local v102 = v100:FindFirstChildOfClass("Humanoid")
		if v102 then
			v102 = v102.SeatPart
		end
		if v102 then
			v102 = v102:FindFirstAncestorWhichIsA("Model")
		end
		while v102 and (v102.Parent and (v102.Parent ~= workspace and v102.Parent:IsA("Model"))) do
			v102 = v102.Parent
		end
		if v102 and v102 ~= v100 then
			local v103 = v_u_96
			table.insert(v103, v102)
		end
	end
	v_u_97.FilterDescendantsInstances = v_u_96
end
local v_u_105 = setmetatable({}, {
	["__mode"] = "k"
})
local v_u_106 = false
local v_u_107 = nil
local function v_u_111(p108) -- name: wetPart
	-- upvalues: (copy) v_u_105, (ref) v_u_106
	if p108:IsA("BasePart") and p108.Material == Enum.Material.Asphalt then
		if v_u_105[p108] == nil then
			v_u_105[p108] = p108.Reflectance
		end
		local v109
		if v_u_106 then
			local v110 = v_u_105[p108]
			v109 = math.max(v110, 0.12)
		else
			v109 = v_u_105[p108]
		end
		p108.Reflectance = v109
	end
end
local function v_u_119(p_u_112) -- name: setWet
	-- upvalues: (ref) v_u_106, (ref) v_u_107, (copy) v_u_111, (copy) v_u_105
	if p_u_112 ~= v_u_106 then
		v_u_106 = p_u_112
		local v_u_113 = workspace:FindFirstChild("Map")
		if v_u_107 then
			v_u_107:Disconnect()
			v_u_107 = nil
		end
		if p_u_112 and v_u_113 then
			v_u_107 = v_u_113.DescendantAdded:Connect(v_u_111)
		end
		task.spawn(function()
			-- upvalues: (copy) p_u_112, (copy) v_u_113, (ref) v_u_106, (ref) v_u_105
			if p_u_112 then
				if v_u_113 then
					for v114, v115 in ipairs(v_u_113:GetDescendants()) do
						if v_u_106 ~= p_u_112 then
							return
						end
						if v115:IsA("BasePart") and v115.Material == Enum.Material.Asphalt then
							if v_u_105[v115] == nil then
								v_u_105[v115] = v115.Reflectance
							end
							local v116
							if v_u_106 then
								local v117 = v_u_105[v115]
								v116 = math.max(v117, 0.12)
							else
								v116 = v_u_105[v115]
							end
							v115.Reflectance = v116
						end
						if v114 % 8000 ~= 0 then
							continue
						end
						task.wait()
					end
				end
			else
				for v118 in v_u_105 do
					if not v118.Parent then
						continue
					end
					v118.Reflectance = v_u_105[v118]
				end
				return
			end
		end)
	end
end
local function v_u_126(p120) -- name: setPrecipitation
	-- upvalues: (ref) v_u_80, (copy) v_u_81, (copy) v_u_79, (copy) v_u_94, (copy) v_u_28, (copy) v_u_55
	local v121 = p120.wind or Vector3.new(0, 0, 0)
	local v122 = v_u_80 and 0.5 or 1
	for _, v123 in v_u_81 do
		v123.rain.Rate = (p120.rain or 0) * 75 * v122
		v123.snow.Rate = (p120.snow or 0) * 26 * v122
		v123.rain.Acceleration = v121
		v123.snow.Acceleration = v121
	end
	local v124 = v_u_79
	local v125
	if p120.rain or p120.snow then
		v125 = workspace.CurrentCamera
	else
		v125 = nil
	end
	v124.Parent = v125
	if p120.sound then
		if v_u_94.SoundId ~= p120.sound then
			v_u_94.SoundId = p120.sound
		end
		if not v_u_94.IsPlaying then
			v_u_94:Play()
		end
		v_u_28:Create(v_u_94, v_u_55, {
			["Volume"] = p120.volume or 0.6
		}):Play()
	else
		v_u_28:Create(v_u_94, v_u_55, {
			["Volume"] = 0
		}):Play()
	end
end
v_u_5:GetAttributeChangedSignal("LowGfx"):Connect(function()
	-- upvalues: (ref) v_u_80, (copy) v_u_5, (copy) v_u_84, (copy) v_u_126, (ref) v_u_54
	v_u_80 = v_u_5:GetAttribute("LowGfx") == true
	v_u_84()
	v_u_126(v_u_54)
end)
local v_u_127 = {}
local v_u_128 = {}
local v_u_129 = v45(40, 110, 200)
local v_u_130 = v45(44, 50, 64)
local function v_u_138() -- name: paintButtons
	-- upvalues: (copy) v_u_127, (copy) v_u_47, (ref) v_u_48, (ref) v_u_53, (copy) v_u_129, (copy) v_u_130, (copy) v_u_128, (ref) v_u_54
	for v131, v132 in v_u_127 do
		local v133
		if v131 == v_u_47 then
			v133 = v_u_48
		else
			v133 = not v_u_48
			if v133 then
				v133 = v131 == v_u_53
			end
		end
		local v134
		if v133 then
			v134 = v_u_129
		else
			v134 = v_u_130
		end
		v132.BackgroundColor3 = v134
	end
	for v135, v136 in v_u_128 do
		local v137
		if v135 == v_u_54 then
			v137 = v_u_129
		else
			v137 = v_u_130
		end
		v136.BackgroundColor3 = v137
	end
end
local v_u_139 = v3:FindFirstChild("MapSkies")
local function v_u_143(p140) -- name: setSky
	-- upvalues: (copy) v_u_139, (copy) v_u_5
	local v141 = v_u_139
	if v141 then
		v141 = v_u_139:FindFirstChild(p140 or "Sky")
	end
	if v141 then
		local v142 = v_u_5:FindFirstChildOfClass("Sky")
		if not v142 or v142.Name ~= v141.Name then
			if v142 then
				v142:Destroy()
			end
			v141:Clone().Parent = v_u_5
		end
	else
		return
	end
end
local v_u_144 = nil
local v_u_145 = nil
local function v_u_194(p146, p147) -- name: refreshLook
	-- upvalues: (ref) v_u_53, (ref) v_u_54, (copy) v_u_5, (copy) v_u_143, (copy) v_u_68, (copy) v_u_28, (copy) v_u_55, (copy) v_u_38, (copy) v_u_39, (copy) v_u_42, (copy) v_u_40, (copy) v_u_41, (copy) v_u_44, (ref) v_u_71, (ref) v_u_72, (ref) v_u_144, (ref) v_u_145, (copy) v_u_84, (copy) v_u_104, (copy) v_u_126, (copy) v_u_119, (copy) v_u_138
	local v148 = v_u_53
	local v149 = v_u_54
	local v150 = v149.grey or 0
	v_u_5.ClockTime = v148.clock
	v_u_143(v148.sky)
	local v151 = table.clone(v148.lighting)
	v151.Brightness = v148.lighting.Brightness * v149.light
	local v152 = v149.dim or 1
	local v153 = v_u_68(v148.lighting.OutdoorAmbient, v149.greyColor or v148.lighting.OutdoorAmbient, v150 * 0.7)
	v151.OutdoorAmbient = Color3.new(v153.R * v152, v153.G * v152, v153.B * v152)
	local v154 = v_u_68(v148.lighting.Ambient, v149.greyColor or v148.lighting.Ambient, v150 * 0.5)
	v151.Ambient = Color3.new(v154.R * v152, v154.G * v152, v154.B * v152)
	local v155 = v_u_5
	if v155 then
		if p146 then
			for v156, v157 in v151 do
				v155[v156] = v157
			end
		else
			v_u_28:Create(v155, v_u_55, v151):Play()
		end
	end
	local v158 = table.clone(v148.atmosphere)
	if v150 > 0 then
		local v159 = v_u_68(v148.atmosphere.Color, v149.greyColor, v150)
		v158.Color = Color3.new(v159.R * v152, v159.G * v152, v159.B * v152)
		local v160 = v_u_68(v148.atmosphere.Decay, v149.greyColor, v150)
		v158.Decay = Color3.new(v160.R * v152, v160.G * v152, v160.B * v152)
		v158.Glare = v148.atmosphere.Glare * (1 - v150)
	end
	local v161 = v148.atmosphere.Density
	local v162 = v149.density or 0
	v158.Density = math.max(v161, v162)
	local v163 = v148.atmosphere.Haze
	local v164 = v149.haze or 0
	v158.Haze = math.max(v163, v164)
	v158.Offset = v149.offset or v148.atmosphere.Offset
	local v165 = v_u_38
	if v165 then
		if p146 then
			for v166, v167 in v158 do
				v165[v166] = v167
			end
		else
			v_u_28:Create(v165, v_u_55, v158):Play()
		end
	end
	local v168 = v_u_39
	local v169 = v148.grade
	if v168 then
		if p146 then
			for v170, v171 in v169 do
				v168[v170] = v171
			end
		else
			v_u_28:Create(v168, v_u_55, v169):Play()
		end
	end
	local v172 = v_u_42
	local v173 = {
		["TintColor"] = v149.tint,
		["Saturation"] = v149.saturation or 0
	}
	if v172 then
		if p146 then
			for v174, v175 in v173 do
				v172[v174] = v175
			end
		else
			v_u_28:Create(v172, v_u_55, v173):Play()
		end
	end
	local v176 = v_u_40
	local v177 = v148.bloom
	if v176 then
		if p146 then
			for v178, v179 in v177 do
				v176[v178] = v179
			end
		else
			v_u_28:Create(v176, v_u_55, v177):Play()
		end
	end
	local v180 = v_u_41
	local v181 = {
		["Intensity"] = v148.sunRays.Intensity * (1 - v150),
		["Spread"] = v148.sunRays.Spread
	}
	if v180 then
		if p146 then
			for v182, v183 in v181 do
				v180[v182] = v183
			end
		else
			v_u_28:Create(v180, v_u_55, v181):Play()
		end
	end
	if not p147 then
		if v149.clouds then
			v_u_44.Enabled = true
			v_u_44.Color = v149.clouds.Color
			local v184 = v_u_44
			local v185 = {
				["Cover"] = v149.clouds.Cover,
				["Density"] = v149.clouds.Density
			}
			if v184 then
				if p146 then
					for v186, v187 in v185 do
						v184[v186] = v187
					end
				else
					v_u_28:Create(v184, v_u_55, v185):Play()
				end
			end
		else
			local v188 = v_u_44
			local v189 = {
				["Cover"] = 0
			}
			if v188 then
				if p146 then
					for v190, v191 in v189 do
						v188[v190] = v191
					end
				else
					v_u_28:Create(v188, v_u_55, v189):Play()
				end
			end
			task.delay(p146 and 0 or 1.6, function()
				-- upvalues: (ref) v_u_54, (ref) v_u_44
				if not v_u_54.clouds then
					v_u_44.Enabled = false
				end
			end)
		end
	end
	v_u_71 = v148.lights or v149.lightsOn == true
	v_u_72 = not v148.lights and 0.6 or v148.lamp
	local v192
	if v_u_71 == v_u_144 then
		local v193 = v_u_72 - (v_u_145 or -1)
		if math.abs(v193) > 0.03 then
			v192 = v_u_72
			v_u_144 = v_u_71
			v_u_145 = v192
			v_u_84()
			v_u_104()
			if not p147 then
				v_u_126(v149)
				v_u_119(v149.wet == true)
			end
			v_u_138()
		else
			v_u_104()
			if not p147 then
				v_u_126(v149)
				v_u_119(v149.wet == true)
			end
			v_u_138()
		end
	else
		v192 = v_u_72
		v_u_144 = v_u_71
		v_u_145 = v192
		v_u_84()
		v_u_104()
		if not p147 then
			v_u_126(v149)
			v_u_119(v149.wet == true)
		end
		v_u_138()
		return
	end
end
local v_u_195 = nil
local v_u_196 = 0
local v_u_197 = false
v29.RenderStepped:Connect(function(p198)
	-- upvalues: (ref) v_u_54, (copy) v_u_79, (ref) v_u_195, (ref) v_u_196, (copy) v_u_104, (copy) v_u_81, (copy) v_u_97, (ref) v_u_197, (copy) v_u_28, (copy) v_u_95, (ref) v_u_80, (copy) v_u_92, (copy) v_u_93
	local v199 = v_u_54
	if v199.rain or v199.snow then
		local v200 = workspace.CurrentCamera
		if v_u_79.Parent ~= v200 then
			v_u_79.Parent = v200
		end
		local v201 = v200.CFrame.Position
		local v202 = not v_u_195 and Vector3.new(0, 0, 0) or (v201 - v_u_195) / math.max(p198, 0.004166666666666667)
		v_u_195 = v201
		local v203 = v202.X
		local v204 = v202.Z
		local v205 = Vector3.new(v203, 0, v204)
		if v205.Magnitude > 80 then
			v205 = v205.Unit * 80
		end
		local v206 = v205 * (v199.rain and 0.55 or 1.5)
		local v207 = v199.rain and 40 or 30
		local v208 = os.clock()
		local v209 = v208 - v_u_196 > 0.3
		if v209 then
			v_u_196 = v208
			v_u_104()
		end
		for _, v210 in v_u_81 do
			local v211 = v201.X + v206.X + v210.ox
			local v212 = v201.Z + v206.Z + v210.oz
			v210.part.CFrame = CFrame.new(v211, v201.Y + v207, v212)
			if not v209 then
				continue
			end
			local v213 = workspace
			local v214 = v201.Y + 1
			local v215 = v213:Raycast(Vector3.new(v211, v214, v212), Vector3.new(0, 70, 0), v_u_97)
			local v216 = v210.covered
			v210.covered = v215 ~= nil
			if v216 == v210.covered then
				continue
			end
			v210.rain.Enabled = not v210.covered
			v210.snow.Enabled = not v210.covered
		end
		if v209 then
			local v217 = workspace:Raycast(v201, Vector3.new(0, 70, 0), v_u_97)
			if v217 ~= nil ~= v_u_197 then
				v_u_197 = v217 ~= nil
				local v218 = {
					["HighGain"] = v_u_197 and -14 or 0,
					["MidGain"] = v_u_197 and -5 or 0
				}
				v_u_28:Create(v_u_95, TweenInfo.new(0.4), v218):Play()
			end
		end
		if v199.rain then
			local v219 = (v_u_80 and 4 or 8) * v199.rain
			for _ = 1, math.floor(v219) do
				local v220 = math.random() * 3.141592653589793 * 2
				local v221 = 4 + math.random() * 34
				local v222 = v201.X + math.cos(v220) * v221
				local v223 = v201.Y + 30
				local v224 = v201.Z + math.sin(v220) * v221
				local v225 = Vector3.new(v222, v223, v224)
				local v226 = workspace:Raycast(v225, Vector3.new(0, -90, 0), v_u_97)
				if not v226 then
					continue
				end
				v_u_92.WorldPosition = v226.Position + v226.Normal * 0.05
				v_u_93:Emit(1)
			end
		end
	end
end)
task.spawn(function()
	-- upvalues: (ref) v_u_54, (copy) v_u_43, (copy) v_u_1, (copy) v_u_51, (copy) v_u_30
	while true do
		repeat
			task.wait(5 + math.random() * 9)
		until v_u_54.lightning
		v_u_43.Brightness = 0.55
		task.wait(0.06)
		v_u_43.Brightness = 0
		if math.random() < 0.6 then
			task.wait(0.08)
			v_u_43.Brightness = 0.35
			task.wait(0.05)
			v_u_43.Brightness = 0
		end
		task.delay(0.4 + math.random() * 1.8, function()
			-- upvalues: (ref) v_u_1, (ref) v_u_51, (ref) v_u_30
			local v_u_227 = v_u_1.new("Sound")
			v_u_227.SoundId = v_u_51[math.random(1, #v_u_51)]
			v_u_227.Volume = 0.6 + math.random() * 0.4
			v_u_227.PlaybackSpeed = 0.85 + math.random() * 0.25
			v_u_227.Parent = v_u_30
			v_u_227:Play()
			v_u_227.Ended:Connect(function()
				-- upvalues: (copy) v_u_227
				v_u_227:Destroy()
			end)
		end)
	end
end)
local function v_u_233() -- name: autoClock
	-- upvalues: (copy) v_u_49
	local v228 = 0
	for _, v229 in v_u_49 do
		v228 = v228 + v229.minutes * 60
	end
	local v230 = workspace:GetServerTimeNow() % v228
	for _, v231 in v_u_49 do
		local v232 = v231.minutes * 60
		if v230 < v232 then
			return (v231.from + (v231.to - v231.from) * v230 / v232) % 24
		end
		v230 = v230 - v232
	end
	return 12
end
local function v_u_237(p234, p235, p236) -- name: mix
	if typeof(p234) == "number" and typeof(p235) == "number" then
		return p234 + (p235 - p234) * p236
	elseif typeof(p234) == "Color3" and typeof(p235) == "Color3" then
		return p234:Lerp(p235, p236)
	elseif p236 < 0.5 then
		return p234
	else
		return p235
	end
end
local function v_u_244(p238, p239, p240) -- name: mixTable
	-- upvalues: (copy) v_u_237
	local v241 = {}
	for v242, v243 in p238 do
		v241[v242] = v_u_237(v243, p239[v242], p240)
	end
	return v241
end
local v245 = { v_u_47 }
local function v_u_260() -- name: autoLook
	-- upvalues: (copy) v_u_233, (copy) v_u_46, (copy) v_u_50, (copy) v_u_237, (copy) v_u_244
	local v246 = v_u_233()
	local v255 = v_u_46[4]
	local v258 = v_u_46[4]
	local v249 = 0
	for v250 = 1, #v_u_50 - 1 do
		local v251 = v_u_50[v250]
		local v252 = v_u_50[v250 + 1]
		if v251[1] > v246 or v246 > v252[1] then
			continue
		end
		local v253 = v_u_46
		local v254 = v251[2]
		for _, v255 in v253 do
			if v255.id ~= v254 then
				continue
			end
		end
		v255 = nil
		local v256 = v_u_46
		local v257 = v252[2]
		for _, v258 in v256 do
			if v258.id ~= v257 then
				continue
			end
		end
		v258 = nil
		if v252[1] > v251[1] then
			v249 = (v246 - v251[1]) / (v252[1] - v251[1])
		else
			v249 = 0
		end
	end
	local v259
	if v249 < 0.5 then
		v259 = v255
	else
		v259 = v258
	end
	return {
		["id"] = "Auto",
		["label"] = "Auto",
		["clock"] = nil,
		["sky"] = nil,
		["lights"] = nil,
		["lamp"] = nil,
		["lighting"] = nil,
		["atmosphere"] = nil,
		["grade"] = nil,
		["bloom"] = nil,
		["sunRays"] = nil,
		["clock"] = v246,
		["sky"] = v259.sky,
		["lights"] = v259.lights,
		["lamp"] = v_u_237(v255.lamp, v258.lamp, v249),
		["lighting"] = v_u_244(v255.lighting, v258.lighting, v249),
		["atmosphere"] = v_u_244(v255.atmosphere, v258.atmosphere, v249),
		["grade"] = v_u_244(v255.grade, v258.grade, v249),
		["bloom"] = v_u_244(v255.bloom, v258.bloom, v249),
		["sunRays"] = v_u_244(v255.sunRays, v258.sunRays, v249)
	}
end
for _, v261 in ipairs(v_u_46) do
	table.insert(v245, v261)
end
for v262, v_u_263 in ipairs(v245) do
	local v264 = v_u_1.new("TextButton")
	v264.Size = UDim2.new(1 / #v245, -4, 1, 0)
	v264.BackgroundColor3 = v_u_130
	v264.TextColor3 = Color3.new(1, 1, 1)
	v264.Name = "Time" .. v262
	v264.FontFace = v7
	v264.TextSize = 15
	v264.Text = v_u_263.label
	v264.Parent = v37
	local v265 = v_u_1.new("UICorner")
	v265.CornerRadius = UDim.new(0, 10)
	v265.Parent = v264
	v264.Activated:Connect(function()
		-- upvalues: (copy) v_u_6, (copy) v_u_263
		v_u_6:SetAttribute("TimeOfDay", v_u_263.id)
	end)
	v_u_127[v_u_263] = v264
end
for v266, v_u_267 in ipairs(v_u_52) do
	local v268 = v_u_1.new("TextButton")
	v268.Size = UDim2.new(1 / #v_u_52, -4, 1, 0)
	v268.BackgroundColor3 = v_u_130
	v268.TextColor3 = Color3.new(1, 1, 1)
	v268.Name = "Weather" .. v266
	v268.FontFace = v7
	v268.TextSize = 14
	v268.Text = v_u_267.label
	v268.Parent = v36
	local v269 = v_u_1.new("UICorner")
	v269.CornerRadius = UDim.new(0, 10)
	v269.Parent = v268
	v268.Activated:Connect(function()
		-- upvalues: (copy) v_u_6, (copy) v_u_267
		v_u_6:SetAttribute("Weather", v_u_267.id)
	end)
	v_u_128[v_u_267] = v268
end
v_u_6:GetAttributeChangedSignal("TimeOfDay"):Connect(function()
	-- upvalues: (copy) v_u_6, (copy) v_u_46, (ref) v_u_48, (ref) v_u_53, (copy) v_u_260, (copy) v_u_194
	local v270 = v_u_6:GetAttribute("TimeOfDay")
	for _, v272 in v_u_46 do
		if v272.id ~= v270 then
			continue
		end
	end
	local v272 = nil
	if v272 then
		if v_u_48 or v272 ~= v_u_53 then
			v_u_48 = false
			v_u_53 = v272
			v_u_194(false)
		end
	elseif not v_u_48 then
		v_u_48 = true
		v_u_53 = v_u_260()
		v_u_194(false)
		return
	end
end)
v_u_6:GetAttributeChangedSignal("Weather"):Connect(function()
	-- upvalues: (copy) v_u_52, (copy) v_u_6, (ref) v_u_54, (copy) v_u_194
	local v273 = v_u_52
	local v274 = v_u_6:GetAttribute("Weather")
	for _, v276 in v273 do
		if v276.id ~= v274 then
			continue
		end
	end
	local v276 = nil
	if v276 and v276 ~= v_u_54 then
		v_u_54 = v276
		v_u_194(false)
	end
end)
local v277 = v_u_6:GetAttribute("TimeOfDay")
for _, v279 in v_u_46 do
	if v279.id ~= v277 then
		continue
	end
end
local v279 = nil
local v280
if v279 == nil then
	v280 = true
else
	v280 = false
end
local v281, v_u_282, v_u_283
if v280 then
	v281 = v_u_260()
	v_u_282 = v281
	v_u_283 = v280
else
	local v284 = v_u_6:GetAttribute("TimeOfDay")
	v_u_283 = v280
	for _, v286 in v_u_46 do
		if v286.id ~= v284 then
			continue
		end
	end
	local v286 = nil
	v281 = v286
	v_u_282 = v281
end
local v287 = v_u_6:GetAttribute("Weather")
for _, v289 in v_u_52 do
	if v289.id ~= v287 then
		continue
	end
end
local v289 = nil
local _ = v289 or v_u_52[1]
v_u_194(true)
v_u_6.CharacterAdded:Connect(v_u_104)
task.spawn(function()
	-- upvalues: (copy) v_u_6, (ref) v_u_283, (ref) v_u_282, (copy) v_u_260, (copy) v_u_194
	while true do
		task.wait(2)
		local v290 = v_u_6:FindFirstChild("PlayerGui")
		if v290 then
			v290 = v_u_6.PlayerGui:FindFirstChild("JobPicker")
		end
		if not v_u_283 or v290 and (v290:IsA("ScreenGui") and v290.Enabled) then
			continue
		end
		v_u_282 = v_u_260()
		v_u_194(false, true)
	end
end)
v10.Activated:Connect(function()
	-- upvalues: (copy) v_u_18
	v_u_18.Visible = not v_u_18.Visible
end)
v24.Activated:Connect(function()
	-- upvalues: (copy) v_u_18
	v_u_18.Visible = false
end)