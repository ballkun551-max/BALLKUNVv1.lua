-- Path: Players/ygggggg55551/PlayerScripts/DashcamViewClient
-- Class: LocalScript  true/Enum.RunContext.Legacy
-- Decompiled by BALL KUN Universal Map Dump

local v1 = game:GetService("Players")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("UserInputService")
local v_u_4 = game:GetService("CollectionService")
local v5 = require(v2:WaitForChild("DashcamShared"))
local v_u_6 = require(v2:WaitForChild("DashcamView"))
local v7 = require(v2:WaitForChild("GameUI"):WaitForChild("Theme"))
local v_u_8 = v1.LocalPlayer
local function v_u_13() -- name: vehicle
	-- upvalues: (copy) v_u_8, (copy) v_u_4
	local v9 = v_u_8.Character
	if v9 then
		v9 = v_u_8.Character:FindFirstChildOfClass("Humanoid")
	end
	if v9 then
		v9 = v9.SeatPart
	end
	local v10 = workspace:FindFirstChild("SpawnedVehicles")
	local v11
	if v9 then
		v11 = v9.Parent
	else
		v11 = v9
	end
	while v11 and v11 ~= workspace do
		if v11.Parent == v10 then
			local v12 = v9.Name == "VehicleSeat" and true or v9.Name == "DriverSeat"
			return v11, v_u_4:HasTag(v11, "PCX160") and v12, v12
		end
		v11 = v11.Parent
	end
	return nil, false, false
end
v_u_3.InputBegan:Connect(function(p14, p15)
	-- upvalues: (copy) v_u_3, (copy) v_u_13, (copy) v_u_6
	if not p15 and (p14.KeyCode == Enum.KeyCode.U and not v_u_3:GetFocusedTextBox()) then
		local v16, v17 = v_u_13()
		if v16 and not v17 then
			v_u_6.toggle(v16)
		end
	end
end)
local v18 = v7.screen("DashcamViewButton", 6, v_u_8:WaitForChild("PlayerGui"))
local v19 = v7.button({
	["name"] = "CamView",
	["text"] = "\224\184\161\224\184\184\224\184\161\224\184\129\224\184\165\224\185\137\224\184\173\224\184\135",
	["icon"] = "camera",
	["grad"] = "dark",
	["textSize"] = 14,
	["anchor"] = nil,
	["position"] = nil,
	["size"] = nil,
	["parent"] = nil,
	["radius"] = 12,
	["anchor"] = Vector2.new(1, 0.5),
	["position"] = UDim2.new(1, -16, 0.32, 0),
	["size"] = UDim2.fromOffset(124, 42),
	["parent"] = v18
})
v19.Visible = false
v19.Activated:Connect(function()
	-- upvalues: (copy) v_u_13, (copy) v_u_6
	local v20 = v_u_13()
	if v20 then
		v_u_6.toggle(v20)
	end
end)
while true do
	task.wait(0.5)
	local v21
	if v_u_3.TouchEnabled then
		local v22, _, v23 = v_u_13()
		v21 = v22 ~= nil and not v23
		if v21 then
			local v24 = v5.PARTS_ATTR
			v21 = type(v22:GetAttribute(v24)) == "string"
		end
	else
		v21 = false
	end
	if v19.Visible == v21 then
		continue
	end
	v19.Visible = v21
end