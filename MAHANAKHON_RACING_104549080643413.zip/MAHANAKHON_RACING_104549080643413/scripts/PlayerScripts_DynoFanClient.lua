-- Path: Players/ygggggg55551/PlayerScripts/DynoFanClient
-- Class: LocalScript  true/Enum.RunContext.Legacy
-- Decompiled by BALL KUN Universal Map Dump

local v1 = game:GetService("Players")
local v2 = game:GetService("RunService")
local v3 = game:GetService("CollectionService")
local v_u_4 = v1.LocalPlayer
local v_u_5 = {}
local function v_u_9(p6) -- name: add
	-- upvalues: (copy) v_u_5
	local v7 = p6:WaitForChild("Rotor", 10)
	local v8 = p6:WaitForChild("Pad", 10)
	if v7 and v8 then
		v_u_5[p6] = {
			["rotor"] = nil,
			["base"] = nil,
			["angle"] = 0,
			["speed"] = 0,
			["link"] = nil,
			["rotor"] = v7,
			["base"] = v7:GetPivot(),
			["link"] = v8
		}
	end
end
v3:GetInstanceAddedSignal("DynoFan"):Connect(function(p10)
	-- upvalues: (copy) v_u_9
	task.spawn(v_u_9, p10)
end)
v3:GetInstanceRemovedSignal("DynoFan"):Connect(function(p11)
	-- upvalues: (copy) v_u_5
	v_u_5[p11] = nil
end)
for _, v12 in v3:GetTagged("DynoFan") do
	task.spawn(v_u_9, v12)
end
local function v_u_20(p13) -- name: bikeOn
	local v14 = workspace:FindFirstChild("SpawnedVehicles")
	if not v14 then
		return nil
	end
	for _, v15 in v14:GetChildren() do
		local v16 = v15:GetPivot().Position - p13.Position
		local v17 = v16.X
		local v18 = v16.Z
		if Vector3.new(v17, 0, v18).Magnitude >= 9 then
			continue
		end
		local v19 = v16.Y
		if math.abs(v19) >= 8 then
			continue
		end
		return v15
	end
	return nil
end
v2.Heartbeat:Connect(function(p21)
	-- upvalues: (copy) v_u_4, (copy) v_u_5, (copy) v_u_20
	local v22 = v_u_4.Character
	if v22 then
		v22 = v_u_4.Character:FindFirstChild("HumanoidRootPart")
	end
	for v23, v24 in v_u_5 do
		if v23.Parent and v24.rotor.Parent then
			local v25 = v24.link.Value
			if not v25 or (not v22 or (v22.Position - v25.Position).Magnitude >= 140) then
				continue
			end
			local v26 = v_u_20(v25)
			local v27
			if v26 and v26:GetAttribute("EngineOn") then
				local v28 = v26:FindFirstChild("VehicleSeat", true) or v26:FindFirstChild("DriverSeat", true)
				local v29
				if v28 and v28.Occupant then
					local v30 = v28.ThrottleFloat
					v29 = math.max(0, v30)
				else
					v29 = 0
				end
				v27 = v29 * 9 + 9
			else
				v27 = 0
			end
			local v31 = v24.speed
			local v32 = v27 - v24.speed
			local v33 = p21 * (v24.speed < v27 and 0.9 or 0.3)
			v24.speed = v31 + v32 * math.min(1, v33)
			if v24.speed <= 0.01 then
				continue
			end
			v24.angle = (v24.angle + v24.speed * p21) % 6.283185307179586
			v24.rotor:PivotTo(v24.base * CFrame.Angles(0, 0, -v24.angle))
		else
			v_u_5[v23] = nil
		end
	end
end)