-- Path: Players/ygggggg55551/PlayerScripts/GameHud
-- Class: LocalScript  true/Enum.RunContext.Legacy
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = require(game:GetService("ReplicatedStorage"):WaitForChild("NetSeal"))
local v2 = game:GetService("Players")
local v3 = game:GetService("ReplicatedStorage")
local v4 = game:GetService("RunService")
local v_u_5 = game:GetService("TweenService")
local v6 = game:GetService("UserInputService")
local v_u_7 = game:GetService("MarketplaceService")
local v_u_8 = require(v3:WaitForChild("GameShared"))
local v9 = v3:WaitForChild("GameUI")
local v_u_10 = require(v9:WaitForChild("Theme"))
local v_u_11 = require(v9:WaitForChild("Icons"))
local v_u_12 = require(v9:WaitForChild("Toast"))
local v_u_13 = require(v9:WaitForChild("Phone"))
local v_u_14 = require(v9:WaitForChild("Store"))
local v_u_15 = require(v9:WaitForChild("Warp"))
local v_u_16 = require(v9:WaitForChild("Money"))
local v_u_17 = require(v9:WaitForChild("VehicleArt"))
local v_u_18 = v2.LocalPlayer
local v_u_19 = v3:WaitForChild(v_u_8.REMOTES)
local v_u_20 = v_u_19:WaitForChild("Garage")
local v21 = v_u_19:WaitForChild("Notify")
local v_u_22 = nil
local function v_u_31(p23) -- name: previewOf
	-- upvalues: (copy) v_u_18, (ref) v_u_22, (copy) v_u_19, (copy) v_u_1
	local v24 = v_u_18:FindFirstChildOfClass("PlayerGui")
	local v25
	if v24 then
		v25 = v24:FindFirstChild("PreviewCache")
	else
		v25 = v24
	end
	if v25 then
		v25 = v25:FindFirstChild(p23)
	end
	if v25 then
		return v25
	end
	v_u_22 = v_u_22 or v_u_19:WaitForChild("Preview", 10)
	if not (v_u_22 and v24) then
		return nil
	end
	local v26 = v_u_1.invoke
	local v27 = v_u_22
	local v28, v29 = pcall(v26, v27, p23)
	if not (v28 and v29) then
		return nil
	end
	local v30 = v24:WaitForChild("PreviewCache", 8)
	if v30 then
		v30 = v30:WaitForChild(p23, 8)
	end
	return v30
end
local v_u_32 = v_u_10.isTouch()
local v_u_33 = v_u_32 and 54 or 58
local v_u_34 = v_u_32 and 8 or 10
local v35 = v_u_32 and 244 or 262
local v_u_36 = v_u_32 and 46 or 50
local v_u_37 = v_u_32 and 54 or 60
local v38 = { Color3.fromRGB(255, 240, 168), Color3.fromRGB(255, 178, 34) }
local v_u_39 = v_u_10.screen("GameHud", 4, v_u_18:WaitForChild("PlayerGui"))
local v40 = v_u_10.new
local v41 = "Frame"
local v42 = {
	["Name"] = "Left",
	["BackgroundTransparency"] = 1,
	["Size"] = nil,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Parent"] = nil
}
local v43
if v_u_32 then
	local v44 = UDim2.fromOffset
	local v45 = (v_u_33 + v_u_34) * 5 - v_u_34
	v43 = v44(math.max(v35, v45) + 10, v_u_36 + v_u_34 + v_u_33 + 6)
else
	v43 = UDim2.fromOffset(v35 + 10, (v_u_33 + v_u_34) * 5 + v_u_36 + 6)
end
v42.Size = v43
v42.AnchorPoint = Vector2.new(0, 1)
v42.Position = UDim2.new(0, v_u_10.EDGE + 8, 1, -v_u_10.EDGE)
v42.Parent = v_u_39
local v_u_46 = v40(v41, v42)
v_u_10.autoScale(v_u_46, v_u_10.PHONE_SHRINK)
if v_u_32 then
	local v_u_47 = {}
	local function v_u_53() -- name: sticks
		-- upvalues: (copy) v_u_18, (copy) v_u_47
		local v48 = v_u_18.PlayerGui:FindFirstChild("TouchGui")
		if v48 then
			v48 = v48:FindFirstChild("TouchControlFrame")
		end
		if v48 then
			local v49 = v48:FindFirstChild("DynamicThumbstickFrame")
			local v50 = v49 and v49.Visible
			if v50 then
				v50 = v49:FindFirstChild("ThumbstickStart")
			end
			if v50 and v50.AbsoluteSize.X > 0 then
				local v51 = v50.Position
				if v51.X.Scale ~= 0 or (v51.Y.Scale ~= 0 or not v_u_47[v50]) then
					v_u_47[v50] = v51
				end
				return v50, v49, nil
			else
				local v52 = v48:FindFirstChild("ThumbstickFrame")
				if v52 and (v52.Visible and v52.AbsoluteSize.X > 0) then
					return nil, nil, v52
				else
					return nil
				end
			end
		else
			return nil
		end
	end
	local function v_u_58(p54, p55) -- name: restRect
		-- upvalues: (copy) v_u_47, (copy) v_u_39
		local v56 = v_u_47[p54]
		local v57 = p54.AbsoluteSize
		return p55.AbsolutePosition + p55.AbsoluteSize * Vector2.new(v56.X.Scale, v56.Y.Scale) + Vector2.new(v56.X.Offset, v56.Y.Offset) - v57 * p54.AnchorPoint - v_u_39.AbsolutePosition, v57
	end
	local function v_u_80() -- name: inset
		-- upvalues: (copy) v_u_39, (copy) v_u_53, (copy) v_u_58, (copy) v_u_46
		local v59 = workspace.CurrentCamera
		local v60
		if v59 then
			v60 = v59.ViewportSize
		else
			v60 = Vector2.new(844, 390)
		end
		local v61 = v60.X
		local v62 = v60.Y
		local v63
		if v61 / math.max(v62, 1) >= 1.9 then
			local v64 = v60.X * 0.07
			v63 = math.floor(v64)
		else
			v63 = 18
		end
		local v65 = v_u_39.AbsoluteSize.Y
		local v66, v67, v68 = v_u_53()
		local v69 = 29
		local v70 = v65 - 19
		if v66 then
			local v71, v72 = v_u_58(v66, v67)
			v69 = v71.X
			v70 = v71.Y + v72.Y
		elseif v68 then
			local v73 = v68.AbsolutePosition - v_u_39.AbsolutePosition
			v69 = v73.X
			v70 = v73.Y - 12
		end
		local v74 = math.max(v63, v69)
		local v75 = v_u_46.AbsoluteSize.Y + 8
		local v76 = v65 - 8
		local v77 = v_u_46.AbsoluteSize.Y + 8
		local v78 = math.max(v76, v77)
		local v79 = math.clamp(v70, v75, v78)
		if v_u_46.Position.X.Offset ~= v74 or (v_u_46.Position.Y.Offset ~= v79 or v_u_46.Position.Y.Scale ~= 0) then
			v_u_46.Position = UDim2.new(0, v74, 0, v79)
		end
	end
	local v_u_81 = 0
	v6.TouchStarted:Connect(function()
		-- upvalues: (ref) v_u_81
		v_u_81 = v_u_81 + 1
	end)
	v6.TouchEnded:Connect(function()
		-- upvalues: (ref) v_u_81
		local v82 = v_u_81 - 1
		v_u_81 = math.max(0, v82)
	end)
	local v_u_83 = false
	v4:BindToRenderStep("HudRestingStick", Enum.RenderPriority.Last.Value, function()
		-- upvalues: (copy) v_u_53, (copy) v_u_47, (ref) v_u_81, (ref) v_u_83
		local v84, v85 = v_u_53()
		if v84 then
			local v86 = v85:FindFirstChild("ThumbstickEnd")
			if v84.Position == v_u_47[v84] or v_u_81 == 0 then
				v84.ImageTransparency = 1
				if v86 then
					v86.ImageTransparency = 1
				end
				v_u_83 = true
			elseif v_u_83 then
				v_u_83 = false
				v84.ImageTransparency = 0
				if v86 then
					v86.ImageTransparency = 0
				end
			end
		else
			return
		end
	end)
	v_u_80()
	if workspace.CurrentCamera then
		workspace.CurrentCamera:GetPropertyChangedSignal("ViewportSize"):Connect(v_u_80)
	end
	task.spawn(function()
		-- upvalues: (copy) v_u_39, (copy) v_u_80
		while v_u_39.Parent do
			task.wait(2)
			v_u_80()
		end
	end)
end
local v87 = v_u_32 and 0 or (v_u_33 + v_u_34) * 5 + 6
local v_u_88 = v_u_10.new("Frame", {
	["Name"] = "Money",
	["BackgroundColor3"] = nil,
	["BackgroundTransparency"] = 0.06,
	["BorderSizePixel"] = 0,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["BackgroundColor3"] = v_u_10.PANEL,
	["Position"] = UDim2.fromOffset(10, v87),
	["Size"] = UDim2.fromOffset(v35, v_u_36),
	["Parent"] = v_u_46
})
v_u_10.corner(v_u_88, 8)
local v_u_89 = v_u_10.new("UIStroke", {
	["ApplyStrokeMode"] = nil,
	["Color"] = nil,
	["Transparency"] = 0.78,
	["Thickness"] = 1.5,
	["Parent"] = nil,
	["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
	["Color"] = v_u_10.YELLOW,
	["Parent"] = v_u_88
})
v_u_10.shadow(v_u_88, 8, 4, 0.55)
local v90 = v_u_10.new("Frame", {
	["Name"] = "Sheen",
	["BackgroundTransparency"] = 1,
	["Size"] = nil,
	["Visible"] = false,
	["Parent"] = nil,
	["Size"] = UDim2.fromScale(1, 1),
	["Parent"] = v_u_88
})
local v_u_91 = v_u_10.new("Frame", {
	["BackgroundColor3"] = nil,
	["BorderSizePixel"] = 0,
	["AnchorPoint"] = nil,
	["Rotation"] = 20,
	["Size"] = nil,
	["Position"] = nil,
	["Parent"] = nil,
	["BackgroundColor3"] = Color3.new(1, 1, 1),
	["AnchorPoint"] = Vector2.new(0.5, 0.5),
	["Size"] = UDim2.new(0, 46, 2.5, 0),
	["Position"] = UDim2.fromScale(-0.2, 0.5),
	["Parent"] = v90
})
v_u_10.new("UIGradient", {
	["Transparency"] = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(0.5, 0.82), NumberSequenceKeypoint.new(1, 1) }),
	["Parent"] = v_u_91
})
local v92, v_u_93 = v_u_16.coin(v_u_37, {
	["sweep"] = false
})
v92.AnchorPoint = Vector2.new(0, 0.5)
v92.Position = UDim2.new(0, -10, 0.5, 0)
v92.ZIndex = 3
v92.Parent = v_u_88
local v_u_94 = v_u_10.new("UIScale", {
	["Parent"] = v92
})
local v_u_95 = v_u_37 - 10 + 8
v_u_10.text({
	["Name"] = "Caption",
	["Text"] = "CASH",
	["TextSize"] = 11,
	["FontFace"] = nil,
	["TextColor3"] = nil,
	["TextXAlignment"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["FontFace"] = v_u_10.FONT_HEAVY,
	["TextColor3"] = v_u_10.TEXT_DIM,
	["TextXAlignment"] = Enum.TextXAlignment.Left,
	["Position"] = UDim2.fromOffset(v_u_95, v_u_32 and 4 or 5),
	["Size"] = UDim2.fromOffset(120, 12),
	["Parent"] = v_u_88
})
local v_u_96 = v_u_10.text({
	["Name"] = "Amount",
	["Text"] = "\226\128\148",
	["FontFace"] = nil,
	["TextSize"] = nil,
	["TextColor3"] = nil,
	["TextXAlignment"] = nil,
	["TextYAlignment"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["TextTruncate"] = nil,
	["ZIndex"] = 2,
	["Parent"] = nil,
	["FontFace"] = v_u_10.FONT_DISPLAY,
	["TextSize"] = v_u_32 and 22 or 24,
	["TextColor3"] = Color3.new(1, 1, 1),
	["TextXAlignment"] = Enum.TextXAlignment.Left,
	["TextYAlignment"] = Enum.TextYAlignment.Bottom,
	["Position"] = UDim2.fromOffset(v_u_95, 0),
	["Size"] = UDim2.new(1, -(v_u_95 + v_u_36), 1, v_u_32 and -5 or -6),
	["TextTruncate"] = Enum.TextTruncate.AtEnd,
	["Parent"] = v_u_88
})
v_u_10.new("UIGradient", {
	["Rotation"] = 90,
	["Color"] = nil,
	["Parent"] = nil,
	["Color"] = ColorSequence.new(v38[1], v38[2]),
	["Parent"] = v_u_96
})
v_u_10.new("UIStroke", {
	["Color"] = nil,
	["Transparency"] = 0.45,
	["Thickness"] = 1,
	["Parent"] = nil,
	["Color"] = Color3.fromRGB(60, 34, 0),
	["Parent"] = v_u_96
})
local v_u_97 = v_u_10.new("UIScale", {
	["Parent"] = v_u_96
})
local v98 = v_u_10.new("TextButton", {
	["Name"] = "TopUp",
	["Text"] = "",
	["AutoButtonColor"] = false,
	["BackgroundColor3"] = nil,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["ZIndex"] = 3,
	["Parent"] = nil,
	["BackgroundColor3"] = Color3.new(1, 1, 1),
	["AnchorPoint"] = Vector2.new(1, 0.5),
	["Position"] = UDim2.new(1, -7, 0.5, 0),
	["Size"] = UDim2.fromOffset(v_u_36 - 14, v_u_36 - 14),
	["Parent"] = v_u_88
})
v_u_10.corner(v98, 6)
v_u_10.gradient(v98, "gold")
local v99 = v_u_11.make("plus", v_u_10.INK, v_u_36 - 28)
v99.AnchorPoint = Vector2.new(0.5, 0.5)
v99.Position = UDim2.fromScale(0.5, 0.5)
v99.ZIndex = 4
v99.Parent = v98
local v_u_100 = v_u_10.new("UIScale", {
	["Parent"] = v98
})
v98.MouseEnter:Connect(function()
	-- upvalues: (copy) v_u_5, (copy) v_u_100, (copy) v_u_10
	v_u_5:Create(v_u_100, v_u_10.QUICK, {
		["Scale"] = 1.12
	}):Play()
end)
v98.MouseLeave:Connect(function()
	-- upvalues: (copy) v_u_5, (copy) v_u_100, (copy) v_u_10
	v_u_5:Create(v_u_100, v_u_10.QUICK, {
		["Scale"] = 1
	}):Play()
end)
v98.Activated:Connect(function()
	-- upvalues: (copy) v_u_14
	v_u_14.open("Money")
end)
v_u_10.new("TextButton", {
	["Name"] = "Hit",
	["Text"] = "",
	["BackgroundTransparency"] = 1,
	["Size"] = nil,
	["ZIndex"] = 5,
	["Parent"] = nil,
	["Size"] = UDim2.new(1, -v_u_36, 1, 0),
	["Parent"] = v_u_88
}).Activated:Connect(function()
	-- upvalues: (copy) v_u_14
	v_u_14.open("Money")
end)
local v_u_101 = nil
local v_u_102 = 0
local v_u_103 = 0
local v_u_104 = 0
local function v_u_112(p105) -- name: floatAmount
	-- upvalues: (copy) v_u_10, (copy) v_u_8, (copy) v_u_95, (copy) v_u_88, (copy) v_u_5
	local v106 = p105 > 0
	local v107 = v_u_10.text
	local v108 = {
		["Text"] = nil,
		["FontFace"] = nil,
		["TextSize"] = 22,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 6,
		["Parent"] = nil,
		["Text"] = (v106 and "+\224\184\191" or "-\224\184\191") .. v_u_8.formatNumber((math.abs(p105))),
		["FontFace"] = v_u_10.FONT_DISPLAY
	}
	local v109
	if v106 then
		v109 = v_u_10.GREEN_TEXT
	else
		v109 = Color3.fromRGB(255, 110, 100)
	end
	v108.TextColor3 = v109
	v108.TextXAlignment = Enum.TextXAlignment.Left
	v108.Position = UDim2.new(0, v_u_95, 0, -28)
	v108.Size = UDim2.fromOffset(220, 26)
	v108.Parent = v_u_88
	local v_u_110 = v107(v108)
	v_u_10.new("UIStroke", {
		["Color"] = nil,
		["Transparency"] = 0.35,
		["Thickness"] = 1.5,
		["Parent"] = nil,
		["Color"] = Color3.new(0, 0, 0),
		["Parent"] = v_u_110
	})
	local v111 = TweenInfo.new(1.3, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	v_u_5:Create(v_u_110, v111, {
		["Position"] = nil,
		["TextTransparency"] = 1,
		["Position"] = v_u_110.Position + UDim2.fromOffset(0, -34)
	}):Play()
	v_u_5:Create(v_u_110.UIStroke, v111, {
		["Transparency"] = 1
	}):Play()
	task.delay(1.4, function()
		-- upvalues: (copy) v_u_110
		v_u_110:Destroy()
	end)
end
local function v_u_119() -- name: burst
	-- upvalues: (copy) v_u_16, (copy) v_u_37, (copy) v_u_88, (copy) v_u_5, (copy) v_u_10
	for v113 = 1, 7 do
		local v_u_114 = v_u_16.coin(14, {
			["glow"] = false
		})
		v_u_114.AnchorPoint = Vector2.new(0.5, 0.5)
		v_u_114.Position = UDim2.new(0, v_u_37 / 2 - 10, 0.5, 0)
		v_u_114.ZIndex = 7
		v_u_114.Parent = v_u_88
		local v115 = (v113 - 1) * 25 + -150 + math.random(-8, 8)
		local v116 = math.rad(v115)
		local v117 = 34 + math.random() * 22
		local v118 = TweenInfo.new(0.55 + math.random() * 0.2, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
		v_u_5:Create(v_u_114, v118, {
			["Position"] = v_u_114.Position + UDim2.fromOffset(math.cos(v116) * v117, math.sin(v116) * v117),
			["Rotation"] = math.random(-90, 90)
		}):Play()
		v_u_5:Create(v_u_10.new("UIScale", {
			["Parent"] = v_u_114
		}), v118, {
			["Scale"] = 0.2
		}):Play()
		task.delay(0.8, function()
			-- upvalues: (copy) v_u_114
			v_u_114:Destroy()
		end)
	end
end
local function v_u_122(p120, p121) -- name: bump
	-- upvalues: (copy) v_u_5
	p120.Scale = p121
	v_u_5:Create(p120, TweenInfo.new(0.35, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
		["Scale"] = 1
	}):Play()
end
local function v127() -- name: onCash
	-- upvalues: (copy) v_u_18, (copy) v_u_96, (ref) v_u_101, (ref) v_u_102, (ref) v_u_103, (copy) v_u_8, (copy) v_u_112, (copy) v_u_93, (copy) v_u_119, (copy) v_u_122, (copy) v_u_94, (copy) v_u_97, (copy) v_u_89, (copy) v_u_5, (ref) v_u_104
	local v123 = v_u_18:GetAttribute("Cash")
	if typeof(v123) == "number" then
		if v_u_101 == nil then
			v_u_101 = v123
			v_u_102 = v123
			v_u_103 = v123
			v_u_96.Text = v_u_8.formatNumber(v123)
		else
			local v124 = v123 - v_u_103
			if v124 ~= 0 then
				v_u_112(v124)
				if v124 > 0 then
					v_u_93.flip()
					v_u_93.glow(true)
					task.delay(0.9, function()
						-- upvalues: (ref) v_u_93
						v_u_93.glow(false)
					end)
					v_u_119()
					v_u_122(v_u_94, 1.18)
					v_u_122(v_u_97, 1.1)
					v_u_89.Transparency = 0
					v_u_5:Create(v_u_89, TweenInfo.new(0.9), {
						["Transparency"] = 0.78
					}):Play()
				end
			end
			local v125 = v_u_101
			local v126 = os.clock()
			v_u_102 = v125
			v_u_103 = v123
			v_u_104 = v126
		end
	else
		v_u_96.Text = "\226\128\148"
		return
	end
end
v_u_18:GetAttributeChangedSignal("Cash"):Connect(v127)
v127()
v4.RenderStepped:Connect(function()
	-- upvalues: (ref) v_u_101, (ref) v_u_103, (ref) v_u_104, (ref) v_u_102, (copy) v_u_96, (copy) v_u_8
	if v_u_101 ~= nil and v_u_101 ~= v_u_103 then
		local v128 = (os.clock() - v_u_104) / 0.7
		local v129 = math.clamp(v128, 0, 1)
		local v130 = 1 - (1 - v129) ^ 3
		local v131
		if v129 >= 1 then
			v131 = v_u_103
		else
			local v132 = v_u_102 + (v_u_103 - v_u_102) * v130
			v131 = math.floor(v132)
		end
		v_u_101 = v131
		v_u_96.Text = v_u_8.formatNumber(v_u_101)
	end
end)
task.spawn(function()
	-- upvalues: (copy) v_u_39, (copy) v_u_93, (copy) v_u_91, (copy) v_u_5
	while v_u_39.Parent do
		task.wait(4.5)
		v_u_93.shine()
		task.wait(0.6)
		v_u_91.Position = UDim2.fromScale(-0.2, 0.5)
		local v133 = v_u_5
		local v134 = v_u_91
		local v135 = TweenInfo.new(1.1, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut)
		local v136 = {
			["Position"] = UDim2.fromScale(1.2, 0.5)
		}
		v133:Create(v134, v135, v136):Play()
	end
end)
local v_u_137 = {}
local v_u_138 = {
	["Map"] = v_u_10.GRAD.gold,
	["Garage"] = v_u_10.GRAD.gold,
	["Store"] = v_u_10.GRAD.gold,
	["Trash"] = v_u_10.GRAD.red,
	["Phone"] = v_u_10.GRAD.gold,
	["Clan"] = v_u_10.GRAD.gold
}
local v_u_139 = v_u_10.GRAD.grey
local v_u_140 = TweenInfo.new(0.12, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
local v141 = v_u_33 * 0.2
local v_u_142 = math.floor(v141)
local function v168(p143, p144, p145, p146, p147) -- name: squareButton
	-- upvalues: (copy) v_u_10, (copy) v_u_33, (copy) v_u_32, (copy) v_u_34, (copy) v_u_36, (copy) v_u_46, (copy) v_u_142, (copy) v_u_138, (copy) v_u_139, (copy) v_u_11, (copy) v_u_5, (copy) v_u_140, (copy) v_u_137
	local v148 = v_u_10.new
	local v149 = "Frame"
	local v150 = {
		["Name"] = nil,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.08,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["Position"] = nil,
		["ZIndex"] = 2,
		["Parent"] = nil,
		["Name"] = p144,
		["BackgroundColor3"] = v_u_10.PANEL,
		["Size"] = UDim2.fromOffset(v_u_33, v_u_33)
	}
	local v151
	if v_u_32 then
		v151 = UDim2.fromOffset(10 + (p143 - 1) * (v_u_33 + v_u_34), v_u_36 + v_u_34 + 4)
	else
		v151 = UDim2.fromOffset(10, (p143 - 1) * (v_u_33 + v_u_34))
	end
	v150.Position = v151
	v150.Parent = v_u_46
	local v152 = v148(v149, v150)
	v_u_10.corner(v152, v_u_142)
	v_u_10.shadow(v152, v_u_142, 4, 0.55)
	local v_u_153 = v_u_10.new("UIStroke", {
		["ApplyStrokeMode"] = nil,
		["Color"] = nil,
		["Transparency"] = 0.55,
		["Thickness"] = 1,
		["Parent"] = nil,
		["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
		["Color"] = Color3.new(1, 1, 1),
		["Parent"] = v152
	})
	local v154 = v_u_10.new("UIGradient", {
		["Rotation"] = 90,
		["Parent"] = nil,
		["Parent"] = v_u_153
	})
	local v155 = v_u_138[p144] or v_u_139
	v154.Color = ColorSequence.new(v155[1], v155[2])
	local v_u_156 = v_u_10.new("UIScale", {
		["Parent"] = v152
	})
	local v157 = v_u_11.make
	local v158 = Color3.new(1, 1, 1)
	local v159 = v_u_33 * 0.52
	local v160 = v157(p145, v158, (math.floor(v159)))
	v160.AnchorPoint = Vector2.new(0.5, 0.5)
	v160.Position = UDim2.fromScale(0.5, 0.5)
	v160.Parent = v152
	if not v_u_32 then
		local v161 = v_u_10.new("Frame", {
			["Name"] = "Key",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.55,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = 3,
			["Parent"] = nil,
			["BackgroundColor3"] = Color3.new(0, 0, 0),
			["AnchorPoint"] = Vector2.new(1, 1),
			["Position"] = UDim2.new(1, -3, 1, -3),
			["Size"] = UDim2.fromOffset(16, 16),
			["Parent"] = v152
		})
		v_u_10.corner(v161, 5)
		v_u_10.text({
			["Text"] = nil,
			["TextSize"] = 11,
			["FontFace"] = nil,
			["TextColor3"] = nil,
			["Size"] = nil,
			["ZIndex"] = 3,
			["Parent"] = nil,
			["Text"] = p146,
			["FontFace"] = v_u_10.FONT_HEAVY,
			["TextColor3"] = Color3.new(1, 1, 1),
			["Size"] = UDim2.fromScale(1, 1),
			["Parent"] = v161
		})
	end
	local v162 = v_u_10.new("TextButton", {
		["Name"] = "Hit",
		["Text"] = "",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 5,
		["Parent"] = nil,
		["Size"] = UDim2.fromScale(1, 1),
		["Parent"] = v152
	})
	local v163 = v_u_10.panel
	local v164 = {
		["Name"] = "Tip",
		["Visible"] = false,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["ZIndex"] = 10,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0, 0.5)
	}
	local v165
	if v_u_32 then
		v165 = UDim2.new(0, 0, 0, -18)
	else
		v165 = UDim2.new(1, 10, 0.5, 0)
	end
	v164.Position = v165
	v164.Size = UDim2.fromOffset(0, 32)
	v164.AutomaticSize = Enum.AutomaticSize.X
	v164.Parent = v152
	local v_u_166 = v163(v164)
	v_u_10.new("UIPadding", {
		["PaddingLeft"] = UDim.new(0, 12),
		["PaddingRight"] = UDim.new(0, 12),
		["Parent"] = v_u_166
	})
	v_u_10.text({
		["Text"] = nil,
		["TextSize"] = 15,
		["FontFace"] = nil,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["ZIndex"] = 10,
		["Parent"] = nil,
		["Text"] = p147 .. (v_u_32 and "" or "  [" .. p146 .. "]"),
		["FontFace"] = v_u_10.FONT_BOLD,
		["Size"] = UDim2.fromScale(0, 1),
		["AutomaticSize"] = Enum.AutomaticSize.X,
		["Parent"] = v_u_166
	})
	if not v_u_32 then
		v162.MouseEnter:Connect(function()
			-- upvalues: (copy) v_u_166, (ref) v_u_5, (copy) v_u_156, (ref) v_u_140, (copy) v_u_153, (ref) v_u_10
			v_u_166.Visible = true
			v_u_5:Create(v_u_156, v_u_140, {
				["Scale"] = 1.08
			}):Play()
			v_u_5:Create(v_u_153, v_u_10.QUICK, {
				["Transparency"] = 0,
				["Thickness"] = 1.5
			}):Play()
		end)
		v162.MouseLeave:Connect(function()
			-- upvalues: (copy) v_u_166, (ref) v_u_5, (copy) v_u_156, (ref) v_u_140, (copy) v_u_153, (ref) v_u_10
			v_u_166.Visible = false
			v_u_5:Create(v_u_156, v_u_140, {
				["Scale"] = 1
			}):Play()
			v_u_5:Create(v_u_153, v_u_10.QUICK, {
				["Transparency"] = 0.55,
				["Thickness"] = 1
			}):Play()
		end)
	end
	v162.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_5, (copy) v_u_156, (ref) v_u_140
		v_u_5:Create(v_u_156, v_u_140, {
			["Scale"] = 0.9
		}):Play()
	end)
	v162.MouseButton1Up:Connect(function()
		-- upvalues: (ref) v_u_32, (ref) v_u_5, (copy) v_u_156, (ref) v_u_140
		v_u_5:Create(v_u_156, v_u_140, {
			["Scale"] = v_u_32 and 1 or 1.08
		}):Play()
	end)
	local v167 = {
		["frame"] = v152,
		["hit"] = v162,
		["icon"] = v160,
		["tip"] = v_u_166,
		["gradient"] = v154
	}
	v_u_137[p144] = v167
	return v167
end
local v169 = v168(1, "Map", "sun", "N", "Time & Weather")
local v170 = v168(2, "Garage", "key", "G", "My Vehicles")
local v171 = v168(3, "Store", "bag", "B", "Store")
local v_u_172 = v168(4, "Trash", "trash", "J", "Hold to put away the nearest one")
local v173 = v168(5, "Clan", "people", "K", "Clan")
v171.hit.Activated:Connect(function()
	-- upvalues: (copy) v_u_14
	v_u_14.toggle()
end)
local v174 = v_u_10.screen("ClanWindow", 20, v_u_18:WaitForChild("PlayerGui"))
local v_u_175 = require(v9:WaitForChild("ClanWindow")).build(v174)
v173.hit.Activated:Connect(function()
	-- upvalues: (copy) v_u_175
	v_u_175.toggle()
end)
local v_u_176 = {}
for _, v177 in {
	"Top",
	"Right",
	"Bottom",
	"Left"
} do
	v_u_176[v177] = v_u_10.new("Frame", {
		["Name"] = nil,
		["BorderSizePixel"] = 0,
		["BackgroundColor3"] = nil,
		["Size"] = nil,
		["ZIndex"] = 4,
		["Parent"] = nil,
		["Name"] = "Ring" .. v177,
		["BackgroundColor3"] = Color3.new(1, 1, 1),
		["Size"] = UDim2.fromOffset(0, 0),
		["Parent"] = v_u_172.frame
	})
end
local function v_u_190(p178) -- name: drawRing
	-- upvalues: (copy) v_u_33, (copy) v_u_176
	local v179 = v_u_33
	v_u_176.Top.Position = UDim2.fromOffset(0, 0)
	local v180 = v_u_176.Top
	local v181 = UDim2.fromOffset
	local v182 = (p178 - 0) / 0.25
	v180.Size = v181(v179 * math.clamp(v182, 0, 1), 3)
	v_u_176.Right.Position = UDim2.fromOffset(v179 - 3, 0)
	local v183 = v_u_176.Right
	local v184 = UDim2.fromOffset
	local v185 = (p178 - 0.25) / 0.25
	v183.Size = v184(3, v179 * math.clamp(v185, 0, 1))
	local v186 = (p178 - 0.5) / 0.25
	local v187 = v179 * math.clamp(v186, 0, 1)
	v_u_176.Bottom.Position = UDim2.fromOffset(v179 - v187, v179 - 3)
	v_u_176.Bottom.Size = UDim2.fromOffset(v187, 3)
	local v188 = (p178 - 0.75) / 0.25
	local v189 = v179 * math.clamp(v188, 0, 1)
	v_u_176.Left.Position = UDim2.fromOffset(0, v179 - v189)
	v_u_176.Left.Size = UDim2.fromOffset(3, v189)
end
v_u_190(0)
local v_u_191 = nil
local v_u_192 = false
local function v_u_196() -- name: spawnedCounts
	-- upvalues: (copy) v_u_18
	local v193 = {}
	local v194 = v_u_18:GetAttribute("SpawnedIds")
	if type(v194) == "string" then
		for v195 in v194:gmatch("[^,]+") do
			v193[v195] = (v193[v195] or 0) + 1
		end
	end
	return v193
end
local function v199() -- name: updateTrashLook
	-- upvalues: (copy) v_u_172, (copy) v_u_18, (copy) v_u_138, (copy) v_u_139
	local v197 = v_u_172.gradient
	local v198
	if (v_u_18:GetAttribute("VehicleCount") or 0) > 0 and true or v_u_18:GetAttribute("ActiveVehicle") ~= nil then
		v198 = v_u_138.Trash
	else
		v198 = v_u_139
	end
	v197.Color = ColorSequence.new(v198[1], v198[2])
end
v_u_18:GetAttributeChangedSignal("ActiveVehicle"):Connect(v199)
v_u_18:GetAttributeChangedSignal("VehicleCount"):Connect(v199)
local v200 = v_u_172.gradient
local v201
if (v_u_18:GetAttribute("VehicleCount") or 0) > 0 and true or v_u_18:GetAttribute("ActiveVehicle") ~= nil then
	v201 = v_u_138.Trash
else
	v201 = v_u_139
end
v200.Color = ColorSequence.new(v201[1], v201[2])
local function v_u_207() -- name: despawn
	-- upvalues: (ref) v_u_192, (copy) v_u_1, (copy) v_u_20, (copy) v_u_12
	v_u_192 = true
	local v202 = v_u_1.invoke
	local v203 = v_u_20
	local v204, v205, v206 = pcall(v202, v203, "Despawn")
	v_u_192 = false
	if v204 then
		v_u_12.show(v206 or "", v205 and "ok" or "error")
	else
		v_u_12.show("Couldn\'t put the vehicle away", "error")
	end
end
v4.RenderStepped:Connect(function()
	-- upvalues: (ref) v_u_191, (copy) v_u_8, (copy) v_u_190, (copy) v_u_207
	if v_u_191 then
		local v208 = (os.clock() - v_u_191) / v_u_8.DELETE_HOLD
		v_u_190((math.min(v208, 1)))
		if v208 >= 1 then
			v_u_191 = nil
			v_u_190(0)
			task.spawn(v_u_207)
		end
	end
end)
v_u_172.hit.InputBegan:Connect(function(p209)
	-- upvalues: (ref) v_u_192, (copy) v_u_18, (copy) v_u_12, (ref) v_u_191
	if p209.UserInputType == Enum.UserInputType.MouseButton1 and true or p209.UserInputType == Enum.UserInputType.Touch then
		if v_u_192 then
			return
		end
		if (v_u_18:GetAttribute("VehicleCount") or 0) <= 0 and v_u_18:GetAttribute("ActiveVehicle") == nil then
			v_u_12.show("You have no vehicle out", "info")
			return
		end
		v_u_191 = os.clock()
	end
end)
v_u_172.hit.InputEnded:Connect(function(p210)
	-- upvalues: (ref) v_u_191, (copy) v_u_190
	if p210.UserInputType == Enum.UserInputType.MouseButton1 and true or p210.UserInputType == Enum.UserInputType.Touch then
		v_u_191 = nil
		v_u_190(0)
	end
end)
v_u_172.hit.MouseLeave:Connect(function() -- name: stopHold
	-- upvalues: (ref) v_u_191, (copy) v_u_190
	v_u_191 = nil
	v_u_190(0)
end)
local function v213(p211, p212) -- name: kp
	return NumberSequenceKeypoint.new(p211, p212)
end
local v_u_214 = v_u_32 and 236 or 300
local v_u_215 = v_u_32 and 300 or 380
local v_u_216 = v_u_32 and 84 or 98
local v_u_217 = v_u_32 and 18 or 34
local v218 = v_u_32 and 72 or 124
local v_u_219 = v_u_32 and 48 or 58
local v_u_220 = {
	["Scooter"] = "MOTORCYCLE",
	["Car"] = "CAR"
}
local v_u_221 = Color3.new(1, 1, 1)
local v222 = Font.new("rbxasset://fonts/families/PermanentMarker.json")
local v_u_223 = { Color3.fromRGB(46, 48, 58), Color3.fromRGB(24, 25, 31) }
local v_u_224 = { Color3.fromRGB(58, 60, 72), Color3.fromRGB(30, 31, 39) }
local v_u_225 = v_u_10.GRAD.gold
local v_u_226 = {
	["home"] = UDim2.fromScale(0.5, 0.82),
	["staff"] = { "ServerPanel", "BanMenu", "AdminPanel" },
	["off"] = {}
}
local v227 = v_u_10.screen("GarageWindow", 21, v_u_18.PlayerGui)
local v_u_228 = v_u_10.window({
	["name"] = "GaragePanel",
	["gui"] = nil,
	["icon"] = "key",
	["grad"] = "gold",
	["title"] = "My Vehicles",
	["sub"] = "Pick a vehicle to spawn beside you and ride",
	["bare"] = true,
	["size"] = nil,
	["touchSize"] = nil,
	["max"] = nil,
	["gui"] = v227,
	["size"] = Vector2.new(1, 1),
	["touchSize"] = Vector2.new(1, 1),
	["max"] = Vector2.new(8192, 8192)
})
local v_u_229 = v_u_228.panel
local v230 = v_u_228.body
v_u_228.shade.BackgroundTransparency = 0
v_u_228.shadeTo = 0
v_u_10.new("UIGradient", {
	["Transparency"] = NumberSequence.new({
		NumberSequenceKeypoint.new(0, 0.03),
		NumberSequenceKeypoint.new(0.3, 0.16),
		NumberSequenceKeypoint.new(0.5, 0.22),
		NumberSequenceKeypoint.new(0.7, 0.16),
		v213(1, 0.03)
	}),
	["Parent"] = v_u_228.shade
})
v_u_228.close.AnchorPoint = Vector2.new(0, 0)
v_u_228.close.Position = UDim2.fromOffset(v_u_217, v_u_32 and 12 or 22)
local v231 = v_u_229:FindFirstChild("Exit")
if v231 then
	v231.TextXAlignment = Enum.TextXAlignment.Left
	v231.AnchorPoint = Vector2.new(0, 0)
	v231.Position = UDim2.fromOffset(v_u_217 + 48, 22)
end
local v_u_232 = v_u_10.new("Frame", {
	["Name"] = "Title",
	["BackgroundTransparency"] = 1,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["AnchorPoint"] = Vector2.new(0.5, 0),
	["Position"] = UDim2.new(0.5, 0, 0, v_u_32 and 6 or 16),
	["Size"] = UDim2.fromOffset(v_u_32 and 220 or 480, v_u_32 and 60 or 100),
	["Parent"] = v230
})
local v233 = v_u_10.text({
	["Name"] = "Big",
	["Text"] = "VEHICLE",
	["FontFace"] = nil,
	["TextSize"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["FontFace"] = v_u_10.FONT_DISPLAY,
	["TextSize"] = v_u_32 and 34 or 68,
	["Size"] = UDim2.new(1, 0, 0, v_u_32 and 36 or 70),
	["Parent"] = v_u_232
})
v_u_10.new("UIStroke", {
	["Color"] = nil,
	["Transparency"] = 0.75,
	["Thickness"] = 1,
	["Parent"] = nil,
	["Color"] = Color3.new(0, 0, 0),
	["Parent"] = v233
})
v_u_10.text({
	["Name"] = "Script",
	["Text"] = "Garage",
	["FontFace"] = nil,
	["TextSize"] = nil,
	["TextColor3"] = nil,
	["Rotation"] = -7,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["FontFace"] = v222,
	["TextSize"] = v_u_32 and 22 or 44,
	["TextColor3"] = v_u_10.ACCENT,
	["AnchorPoint"] = Vector2.new(0.5, 0.5),
	["Position"] = UDim2.new(v_u_32 and 0.7 or 0.66, 0, 0, v_u_32 and 32 or 62),
	["Size"] = UDim2.fromOffset(220, 52),
	["Parent"] = v_u_232
})
v_u_10.text({
	["Name"] = "Line",
	["Text"] = "Pick a vehicle to spawn beside you and ride",
	["TextSize"] = nil,
	["TextTransparency"] = 0.2,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["TextSize"] = v_u_32 and 11 or 14,
	["AnchorPoint"] = Vector2.new(0.5, 1),
	["Position"] = UDim2.fromScale(0.5, 1),
	["Size"] = UDim2.new(1, v_u_32 and 60 or 0, 0, v_u_32 and 14 or 18),
	["Parent"] = v_u_232
})
local v_u_234 = v_u_10.new("Frame", {
	["Name"] = "Left",
	["BackgroundTransparency"] = 1,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["Position"] = UDim2.fromOffset(v_u_217, v218),
	["Size"] = UDim2.new(0, v_u_214 + 34, 1, -(v218 + 18)),
	["Parent"] = v230
})
local v235 = v_u_10.new("Frame", {
	["Name"] = "Categories",
	["BackgroundTransparency"] = 1,
	["Size"] = nil,
	["Parent"] = nil,
	["Size"] = UDim2.new(0, v_u_214, 0, v_u_32 and 36 or 40),
	["Parent"] = v_u_234
})
local v_u_236 = v_u_10.new("ScrollingFrame", {
	["Name"] = "List",
	["BackgroundTransparency"] = 1,
	["BorderSizePixel"] = 0,
	["Position"] = nil,
	["Size"] = nil,
	["CanvasSize"] = nil,
	["AutomaticCanvasSize"] = nil,
	["ScrollingDirection"] = nil,
	["ScrollBarThickness"] = 3,
	["ScrollBarImageColor3"] = nil,
	["ScrollBarImageTransparency"] = 0.3,
	["Parent"] = nil,
	["Position"] = UDim2.fromOffset(0, v_u_32 and 44 or 52),
	["Size"] = UDim2.new(1, 0, 1, v_u_32 and -44 or -52),
	["CanvasSize"] = UDim2.new(),
	["AutomaticCanvasSize"] = Enum.AutomaticSize.Y,
	["ScrollingDirection"] = Enum.ScrollingDirection.Y,
	["ScrollBarImageColor3"] = v_u_10.TEXT_DIM,
	["Parent"] = v_u_234
})
v_u_10.new("UIPadding", {
	["PaddingTop"] = UDim.new(0, 2),
	["PaddingBottom"] = UDim.new(0, 8),
	["Parent"] = v_u_236
})
v_u_10.new("UIListLayout", {
	["Padding"] = UDim.new(0, v_u_32 and 8 or 10),
	["SortOrder"] = Enum.SortOrder.LayoutOrder,
	["Parent"] = v_u_236
})
local v_u_237 = v_u_10.new("Frame", {
	["Name"] = "Stage",
	["BackgroundTransparency"] = 1,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["Position"] = UDim2.fromOffset(v_u_217 + v_u_214 + 54, v218 + 10),
	["Size"] = UDim2.new(1, -(v_u_217 * 2 + v_u_214 + 54 + v_u_215 + 30), 1, -(v218 + 70)),
	["Parent"] = v230
})
local v_u_238 = v_u_10.new("Frame", {
	["Name"] = "Shadow",
	["BackgroundColor3"] = nil,
	["BackgroundTransparency"] = 0.35,
	["BorderSizePixel"] = 0,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["BackgroundColor3"] = Color3.new(0, 0, 0),
	["AnchorPoint"] = Vector2.new(0.5, 0.5),
	["Position"] = UDim2.fromScale(0.5, 0.8),
	["Size"] = UDim2.new(0.8, 0, 0, 22),
	["Parent"] = v_u_237
})
v_u_10.corner(v_u_238, 999)
v_u_10.new("UIGradient", {
	["Transparency"] = NumberSequence.new({
		NumberSequenceKeypoint.new(0, 1),
		NumberSequenceKeypoint.new(0.22, 0.25),
		NumberSequenceKeypoint.new(0.78, 0.25),
		v213(1, 1)
	}),
	["Parent"] = v_u_238
})
local v_u_239 = v_u_10.new("Frame", {
	["Name"] = "Turntable",
	["BackgroundColor3"] = nil,
	["BackgroundTransparency"] = 0.5,
	["BorderSizePixel"] = 0,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["BackgroundColor3"] = Color3.fromRGB(10, 11, 15),
	["AnchorPoint"] = Vector2.new(0.5, 0.5),
	["Position"] = UDim2.fromScale(0.5, 0.79),
	["Size"] = UDim2.new(0.74, 0, 0, v_u_32 and 30 or 44),
	["Parent"] = v_u_237
})
v_u_10.corner(v_u_239, 999)
local v240 = v_u_10.new("UIStroke", {
	["Color"] = nil,
	["Thickness"] = 1.5,
	["Parent"] = nil,
	["Color"] = v_u_10.ACCENT,
	["Parent"] = v_u_239
})
v_u_10.new("UIGradient", {
	["Rotation"] = 90,
	["Transparency"] = nil,
	["Parent"] = nil,
	["Transparency"] = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(0.55, 0.85), v213(1, 0.25) }),
	["Parent"] = v240
})
v_u_10.new("UIGradient", {
	["Transparency"] = NumberSequence.new({
		NumberSequenceKeypoint.new(0, 1),
		NumberSequenceKeypoint.new(0.2, 0.2),
		NumberSequenceKeypoint.new(0.8, 0.2),
		v213(1, 1)
	}),
	["Parent"] = v_u_239
})
local v_u_241 = v_u_10.new("ImageLabel", {
	["Name"] = "Picture",
	["BackgroundTransparency"] = 1,
	["ScaleType"] = nil,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["ScaleType"] = Enum.ScaleType.Fit,
	["AnchorPoint"] = Vector2.new(0.5, 1),
	["Position"] = UDim2.fromScale(0.5, 0.82),
	["Size"] = UDim2.fromScale(0.78, 0.56),
	["Parent"] = v_u_237
})
local v_u_242 = v_u_10.new("UISizeConstraint", {
	["MaxSize"] = Vector2.new(620, 400),
	["Parent"] = v_u_241
})
local v_u_243 = v_u_10.new("ImageLabel", {
	["Name"] = "Still",
	["BackgroundTransparency"] = 1,
	["ScaleType"] = nil,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Visible"] = false,
	["Parent"] = nil,
	["ScaleType"] = Enum.ScaleType.Fit,
	["AnchorPoint"] = Vector2.new(0.5, 1),
	["Position"] = UDim2.fromScale(0.5, 0.83),
	["Size"] = UDim2.fromScale(0.8, 0.62),
	["Parent"] = v_u_237
})
v_u_10.corner(v_u_243, 12)
local v_u_244 = v_u_10.new("ViewportFrame", {
	["Name"] = "Turning",
	["BackgroundTransparency"] = 1,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Visible"] = false,
	["Ambient"] = nil,
	["LightColor"] = nil,
	["LightDirection"] = Vector3.new(-0.5, -1, -0.6),
	["Parent"] = nil,
	["AnchorPoint"] = Vector2.new(0.5, 1),
	["Position"] = UDim2.fromScale(0.5, 0.86),
	["Size"] = UDim2.fromScale(0.9, 0.72),
	["Ambient"] = Color3.fromRGB(150, 150, 158),
	["LightColor"] = Color3.fromRGB(255, 248, 236),
	["Parent"] = v_u_237
})
local v_u_245 = v_u_10.new("Camera", {
	["FieldOfView"] = 28,
	["Parent"] = nil,
	["Parent"] = v_u_244
})
v_u_244.CurrentCamera = v_u_245
local v_u_246 = v_u_10.text({
	["Name"] = "Counter",
	["Text"] = "",
	["RichText"] = true,
	["TextSize"] = 15,
	["FontFace"] = nil,
	["TextColor3"] = nil,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["FontFace"] = v_u_10.FONT_DISPLAY,
	["TextColor3"] = v_u_10.TEXT_DIM,
	["AnchorPoint"] = Vector2.new(0.5, 1),
	["Position"] = UDim2.new(0.5, 0, 1, -24),
	["Size"] = UDim2.fromOffset(120, 20),
	["Parent"] = v_u_237
})
local v_u_247 = v_u_10.text({
	["Name"] = "OutCount",
	["Text"] = "",
	["TextSize"] = 13,
	["FontFace"] = nil,
	["TextColor3"] = nil,
	["TextTruncate"] = nil,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["FontFace"] = v_u_10.FONT_BOLD,
	["TextColor3"] = v_u_10.LIME,
	["TextTruncate"] = Enum.TextTruncate.AtEnd,
	["AnchorPoint"] = Vector2.new(0.5, 1),
	["Position"] = UDim2.new(0.5, 0, 1, 0),
	["Size"] = UDim2.new(1, 0, 0, 18),
	["Parent"] = v_u_237
})
local v_u_248 = v_u_10.text({
	["Name"] = "Hint",
	["Text"] = "",
	["TextSize"] = 12,
	["TextColor3"] = nil,
	["TextTruncate"] = nil,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["TextColor3"] = v_u_10.TEXT_DIM,
	["TextTruncate"] = Enum.TextTruncate.AtEnd,
	["AnchorPoint"] = Vector2.new(0.5, 1),
	["Position"] = UDim2.new(0.5, 0, 1, -2),
	["Size"] = UDim2.new(1, 120, 0, 16),
	["Parent"] = v230
})
v_u_248.Position = UDim2.new(0.5, 0, 1, -8)
local v_u_249 = v_u_10.new("Frame", {
	["Name"] = "Right",
	["BackgroundTransparency"] = 1,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["AnchorPoint"] = Vector2.new(1, 0),
	["Position"] = UDim2.new(1, -v_u_217, 0, v218),
	["Size"] = UDim2.new(0, v_u_215, 1, -(v218 + 30)),
	["Parent"] = v230
})
local v250 = v_u_219 + 10 + (v_u_32 and 38 or 44)
local v_u_251 = v_u_10.new("ScrollingFrame", {
	["Name"] = "Info",
	["BackgroundTransparency"] = 1,
	["BorderSizePixel"] = 0,
	["Size"] = nil,
	["CanvasSize"] = nil,
	["AutomaticCanvasSize"] = nil,
	["ScrollingDirection"] = nil,
	["ScrollBarThickness"] = 2,
	["ScrollBarImageColor3"] = nil,
	["Parent"] = nil,
	["Size"] = UDim2.new(1, 0, 1, -(v250 + 14)),
	["CanvasSize"] = UDim2.new(),
	["AutomaticCanvasSize"] = Enum.AutomaticSize.Y,
	["ScrollingDirection"] = Enum.ScrollingDirection.Y,
	["ScrollBarImageColor3"] = v_u_10.TEXT_DIM,
	["Parent"] = v_u_249
})
v_u_10.new("UIPadding", {
	["PaddingRight"] = UDim.new(0, 6),
	["Parent"] = v_u_251
})
v_u_10.new("UIListLayout", {
	["Padding"] = UDim.new(0, 12),
	["SortOrder"] = Enum.SortOrder.LayoutOrder,
	["Parent"] = v_u_251
})
local v252 = v_u_10.new("Frame", {
	["Name"] = "NameBlock",
	["BackgroundTransparency"] = 1,
	["Size"] = nil,
	["LayoutOrder"] = 1,
	["Parent"] = nil,
	["Size"] = UDim2.new(1, 0, 0, v_u_32 and 62 or 74),
	["Parent"] = v_u_251
})
local v_u_253 = v_u_10.text({
	["Name"] = "Kind",
	["Text"] = "",
	["TextSize"] = 12,
	["FontFace"] = nil,
	["TextColor3"] = nil,
	["TextXAlignment"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["FontFace"] = v_u_10.FONT_HEAVY,
	["TextColor3"] = v_u_10.ACCENT,
	["TextXAlignment"] = Enum.TextXAlignment.Left,
	["Size"] = UDim2.new(1, 0, 0, 14),
	["Parent"] = v252
})
local v_u_254 = v_u_10.text({
	["Name"] = "VehicleName",
	["Text"] = "",
	["TextSize"] = nil,
	["FontFace"] = nil,
	["TextXAlignment"] = nil,
	["TextTruncate"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["TextSize"] = v_u_32 and 20 or 26,
	["FontFace"] = v_u_10.FONT_DISPLAY,
	["TextXAlignment"] = Enum.TextXAlignment.Left,
	["TextTruncate"] = Enum.TextTruncate.AtEnd,
	["Position"] = UDim2.fromOffset(0, 15),
	["Size"] = UDim2.new(1, 0, 0, v_u_32 and 26 or 32),
	["Parent"] = v252
})
if v_u_32 then
	v_u_254.TextScaled = true
	v_u_10.new("UITextSizeConstraint", {
		["MaxTextSize"] = 20,
		["MinTextSize"] = 12,
		["Parent"] = nil,
		["Parent"] = v_u_254
	})
end
local v_u_255 = v_u_10.new("Frame", {
	["Name"] = "Chips",
	["BackgroundTransparency"] = 1,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["AnchorPoint"] = Vector2.new(0, 1),
	["Position"] = UDim2.fromScale(0, 1),
	["Size"] = UDim2.new(1, 0, 0, 20),
	["Parent"] = v252
})
v_u_10.new("UIListLayout", {
	["FillDirection"] = Enum.FillDirection.Horizontal,
	["Padding"] = UDim.new(0, 6),
	["SortOrder"] = Enum.SortOrder.LayoutOrder,
	["Parent"] = v_u_255
});
(function(p256, p257, p258) -- name: section
	-- upvalues: (copy) v_u_10, (copy) v_u_251
	local v259 = v_u_10.new("Frame", {
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["LayoutOrder"] = nil,
		["Parent"] = nil,
		["Size"] = UDim2.new(1, 0, 0, p257 and 38 or 20),
		["LayoutOrder"] = p258,
		["Parent"] = v_u_251
	})
	v_u_10.text({
		["Text"] = nil,
		["TextSize"] = 15,
		["FontFace"] = nil,
		["TextXAlignment"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Text"] = p256,
		["FontFace"] = v_u_10.FONT_TITLE,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["Size"] = UDim2.new(1, 0, 0, 18),
		["Parent"] = v259
	})
	if p257 then
		v_u_10.text({
			["Text"] = nil,
			["TextSize"] = 12,
			["TextColor3"] = nil,
			["TextXAlignment"] = nil,
			["TextTruncate"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["Text"] = p257,
			["TextColor3"] = v_u_10.TEXT_DIM,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["TextTruncate"] = Enum.TextTruncate.AtEnd,
			["Position"] = UDim2.fromOffset(0, 20),
			["Size"] = UDim2.new(1, 0, 0, 16),
			["Parent"] = v259
		})
	end
	return v259
end)("Vehicle Specifications", "Stock figures: parts, pistons and tuning add more", 2)
local v_u_262 = (function(p260) -- name: box
	-- upvalues: (copy) v_u_10, (copy) v_u_251, (copy) v_u_221
	local v261 = v_u_10.new("Frame", {
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.18,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = Color3.fromRGB(14, 15, 20),
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y,
		["LayoutOrder"] = p260,
		["Parent"] = v_u_251
	})
	v_u_10.corner(v261, 10)
	v_u_10.border(v261, v_u_221, 0.93, 1)
	v_u_10.padding(v261, 12)
	v_u_10.new("UIListLayout", {
		["Padding"] = UDim.new(0, 12),
		["SortOrder"] = Enum.SortOrder.LayoutOrder,
		["Parent"] = v261
	})
	return v261
end)(3)
local function v270(p263, p264, p265) -- name: specRow
	-- upvalues: (copy) v_u_10, (copy) v_u_262, (copy) v_u_221
	local v266 = v_u_10.new("Frame", {
		["Name"] = nil,
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["LayoutOrder"] = nil,
		["Parent"] = nil,
		["Name"] = p263,
		["Size"] = UDim2.new(1, 0, 0, 36),
		["LayoutOrder"] = p265,
		["Parent"] = v_u_262
	})
	v_u_10.badge(v266, p264, "gold", 34).Position = UDim2.fromOffset(0, 1)
	v_u_10.text({
		["Text"] = nil,
		["TextSize"] = 12,
		["FontFace"] = nil,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Text"] = p263,
		["FontFace"] = v_u_10.FONT_HEAVY,
		["TextColor3"] = v_u_10.ACCENT,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["Position"] = UDim2.fromOffset(46, 2),
		["Size"] = UDim2.new(0.5, -46, 0, 16),
		["Parent"] = v266
	})
	local v267 = v_u_10.text({
		["Name"] = "Value",
		["Text"] = "",
		["TextSize"] = 13,
		["FontFace"] = nil,
		["TextXAlignment"] = nil,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["FontFace"] = v_u_10.FONT_BOLD,
		["TextXAlignment"] = Enum.TextXAlignment.Right,
		["AnchorPoint"] = Vector2.new(1, 0),
		["Position"] = UDim2.new(1, 0, 0, 2),
		["Size"] = UDim2.new(0.5, 0, 0, 16),
		["Parent"] = v266
	})
	local v268 = v_u_10.new("Frame", {
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.88,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_221,
		["Position"] = UDim2.fromOffset(46, 26),
		["Size"] = UDim2.new(1, -46, 0, 5),
		["Parent"] = v266
	})
	v_u_10.corner(v268, 3)
	local v269 = v_u_10.new("Frame", {
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_221,
		["Size"] = UDim2.fromScale(0, 1),
		["Parent"] = v268
	})
	v_u_10.corner(v269, 3)
	v_u_10.new("UIGradient", {
		["Color"] = ColorSequence.new(v_u_10.GRAD.gold[1], v_u_10.GRAD.gold[2]),
		["Parent"] = v269
	})
	return {
		["value"] = v267,
		["fill"] = v269
	}
end
local v_u_271 = v270("TOP SPEED", "trophy", 1)
local v_u_272 = v270("SEATS", "people", 2)
local v_u_273 = v270("ODOMETER", "pin", 3)
local function v_u_279(p274, p275, p276, p277) -- name: setSpec
	-- upvalues: (copy) v_u_5
	p274.value.Text = p275
	local v278 = UDim2.fromScale(math.clamp(p276 or 0, 0, 1), 1)
	if p277 then
		p274.fill.Size = UDim2.fromScale(0, 1)
		v_u_5:Create(p274.fill, TweenInfo.new(0.5, Enum.EasingStyle.Quart, Enum.EasingDirection.Out), {
			["Size"] = v278
		}):Play()
	else
		p274.fill.Size = v278
	end
end
local v_u_280 = v_u_10.new("Frame", {
	["Name"] = "GarageSettings",
	["BackgroundTransparency"] = 1,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["AnchorPoint"] = Vector2.new(1, 0),
	["Position"] = UDim2.new(1, -v_u_217, 0, v218),
	["Size"] = UDim2.new(0, v_u_215, 0, 34),
	["Parent"] = v230
})
v_u_10.new("UIListLayout", {
	["FillDirection"] = Enum.FillDirection.Horizontal,
	["HorizontalAlignment"] = Enum.HorizontalAlignment.Right,
	["VerticalAlignment"] = Enum.VerticalAlignment.Center,
	["Padding"] = UDim.new(0, 8),
	["SortOrder"] = Enum.SortOrder.LayoutOrder,
	["Parent"] = v_u_280
})
v_u_249.Position = UDim2.new(1, -v_u_217, 0, v218 + 34 + 12)
v_u_249.Size = UDim2.new(0, v_u_215, 1, -(v218 + 30 + 34 + 12))
local function v286(p281, p282, p283) -- name: settingRow
	-- upvalues: (copy) v_u_10, (copy) v_u_280, (copy) v_u_11
	local v284 = v_u_10.new("TextButton", {
		["Name"] = nil,
		["Text"] = "",
		["AutoButtonColor"] = false,
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AutomaticSize"] = nil,
		["Size"] = nil,
		["LayoutOrder"] = nil,
		["Parent"] = nil,
		["Name"] = p281,
		["BackgroundColor3"] = v_u_10.CARD_DARK,
		["AutomaticSize"] = Enum.AutomaticSize.X,
		["Size"] = UDim2.fromOffset(0, 34),
		["LayoutOrder"] = p283,
		["Parent"] = v_u_280
	})
	v_u_10.corner(v284, 17)
	v_u_10.border(v284, v_u_10.ACCENT, 0.72, 1)
	v_u_10.new("UIPadding", {
		["PaddingLeft"] = UDim.new(0, 12),
		["PaddingRight"] = UDim.new(0, 6),
		["Parent"] = v284
	})
	v_u_10.new("UIListLayout", {
		["FillDirection"] = Enum.FillDirection.Horizontal,
		["VerticalAlignment"] = Enum.VerticalAlignment.Center,
		["Padding"] = UDim.new(0, 7),
		["SortOrder"] = Enum.SortOrder.LayoutOrder,
		["Parent"] = v284
	})
	local v285 = v_u_11.make(p282, v_u_10.ACCENT, 16)
	v285.LayoutOrder = 1
	v285.Parent = v284
	return v284, v_u_10.text({
		["Name"] = "Title",
		["Text"] = "",
		["TextSize"] = 13,
		["FontFace"] = nil,
		["AutomaticSize"] = nil,
		["Size"] = nil,
		["LayoutOrder"] = 2,
		["Parent"] = nil,
		["FontFace"] = v_u_10.FONT_HEAVY,
		["AutomaticSize"] = Enum.AutomaticSize.X,
		["Size"] = UDim2.fromOffset(0, 18),
		["Parent"] = v284
	}), v_u_10.text({
		["Name"] = "Sub",
		["Text"] = "",
		["Visible"] = false,
		["Size"] = nil,
		["Parent"] = nil,
		["Size"] = UDim2.fromOffset(0, 0),
		["Parent"] = v284
	}), v285
end
local v287 = v_u_10.new("Frame", {
	["Name"] = "Buttons",
	["BackgroundTransparency"] = 1,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["AnchorPoint"] = Vector2.new(0, 1),
	["Position"] = UDim2.fromScale(0, 1),
	["Size"] = UDim2.new(1, 0, 0, v250),
	["Parent"] = v_u_249
})
local v_u_288 = v_u_10.button({
	["name"] = "Spawn",
	["text"] = "Spawn",
	["icon"] = "key",
	["grad"] = "gold",
	["textSize"] = nil,
	["slant"] = 16,
	["position"] = nil,
	["size"] = nil,
	["parent"] = nil,
	["textSize"] = v_u_32 and 18 or 21,
	["position"] = UDim2.fromOffset(0, 0),
	["size"] = UDim2.new(1, 0, 0, v_u_219),
	["parent"] = v287
})
local v_u_289 = v_u_10.button({
	["name"] = "BuyRobux",
	["text"] = "R$",
	["grad"] = "green",
	["textSize"] = 16,
	["slant"] = 16,
	["anchor"] = nil,
	["position"] = nil,
	["size"] = nil,
	["parent"] = nil,
	["anchor"] = Vector2.new(1, 0),
	["position"] = UDim2.fromScale(1, 0),
	["size"] = UDim2.new(0.4, -8, 0, v_u_219),
	["parent"] = v287
})
v_u_289.Visible = false
local v_u_290 = v_u_10.button({
	["name"] = "Favorite",
	["text"] = "\226\152\134  Add to favourites",
	["grad"] = "grey",
	["textSize"] = 15,
	["slant"] = 16,
	["anchor"] = nil,
	["position"] = nil,
	["size"] = nil,
	["parent"] = nil,
	["anchor"] = Vector2.new(0, 1),
	["position"] = UDim2.fromScale(0, 1),
	["size"] = UDim2.new(1, 0, 0, v_u_32 and 38 or 44),
	["parent"] = v287
})
local v_u_291 = false
local v_u_292 = {}
local v_u_293 = {}
local v_u_294 = nil
local v_u_295 = 0
local v_u_296 = v_u_8.MAX_SPAWNED
local v_u_297 = nil
local v_u_298 = nil
local v_u_299 = {
	["max"] = 1,
	["odo"] = 0
}
local v_u_300 = {
	{
		["id"] = "All",
		["label"] = "ALL",
		["icon"] = "key",
		["empty"] = "No vehicles yet"
	},
	{
		["id"] = "Scooter",
		["label"] = "BIKES",
		["icon"] = "scooter",
		["empty"] = "No motorcycles yet"
	},
	{
		["id"] = "Car",
		["label"] = "CARS",
		["icon"] = "car",
		["empty"] = "No cars yet"
	}
}
local v_u_301 = "All"
local function v_u_309() -- name: applyFilter
	-- upvalues: (ref) v_u_293, (ref) v_u_292, (ref) v_u_301, (ref) v_u_297, (copy) v_u_300, (copy) v_u_236, (ref) v_u_294, (ref) v_u_298
	local v302 = 0
	local v303 = nil
	for _, v304 in v_u_293 do
		local v305 = v_u_292[v304]
		local v306 = v_u_301 == "All" and true or v305.category == v_u_301
		v305.holder.Visible = v306
		if not v306 then
			continue
		end
		v302 = v302 + 1
		v303 = v303 or v304
	end
	if v_u_297 then
		v_u_297.Visible = v302 == 0
		for _, v307 in v_u_300 do
			if v307.id ~= v_u_301 then
				continue
			end
			v_u_297.Text = v307.empty
		end
	end
	v_u_236.CanvasPosition = Vector2.zero
	local v308 = v_u_294 and v_u_292[v_u_294]
	if v308 then
		v308 = v_u_292[v_u_294].holder.Visible
	end
	if not v308 and v_u_298 then
		v_u_298(v303)
	end
end
local v_u_311, v312 = v_u_10.tabs(v235, v_u_300, function(p310)
	-- upvalues: (ref) v_u_301, (copy) v_u_309
	v_u_301 = p310
	v_u_309()
end, v_u_32 and 36 or 40)
v312(v_u_301)
local v_u_313, v_u_314, v_u_315, v_u_316
if v_u_32 then
	v_u_313 = v_u_293
	v_u_314 = v_u_294
	v_u_315 = v_u_297
	v_u_316 = v_u_292
	for _, v317 in v_u_311:GetChildren() do
		local v318 = v317:IsA("GuiButton")
		if v318 then
			v318 = v317:FindFirstChildWhichIsA("Frame")
		end
		if not v318 then
			continue
		end
		local v319 = v318:FindFirstChildOfClass("UIListLayout")
		if v319 then
			v319.Padding = UDim.new(0, 5)
		end
		for _, v320 in v318:GetChildren() do
			if v320:IsA("TextLabel") then
				v320.TextSize = 13
			else
				if not (v320:IsA("Frame") and v320:FindFirstChildOfClass("UIScale")) then
					continue
				end
				v320:FindFirstChildOfClass("UIScale").Scale = 0.5714285714285714
			end
		end
	end
	function v_u_226.tabs() -- name: tabs
		-- upvalues: (copy) v_u_311, (copy) v_u_10
		local v321 = {}
		local v322 = 0
		for _, v323 in v_u_311:GetChildren() do
			local v324 = v323:IsA("GuiButton")
			if v324 then
				v324 = v323:FindFirstChildWhichIsA("Frame")
			end
			if not v324 then
				continue
			end
			local v325 = v_u_10.unscaledSize(v324).X + 10
			table.insert(v321, { v323, v325, v324 })
			v322 = v322 + v325
		end
		local v326 = v_u_10.unscaledSize(v_u_311).X - 8
		local v327 = #v321 - 1
		local v328 = v326 - math.max(v327, 0) * 4
		if #v321 ~= 0 and v328 >= 60 then
			local v329 = (v328 - v322) / #v321
			for _, v330 in v321 do
				local v331 = v330[1]
				local v332 = UDim2.new
				local v333 = v330[2] + v329
				local v334 = math.floor(v333)
				v331.Size = v332(0, math.max(20, v334), 1, 0)
				v330[1].ClipsDescendants = v329 < 0
			end
		end
	end
else
	v_u_313 = v_u_293
	v_u_314 = v_u_294
	v_u_315 = v_u_297
	v_u_316 = v_u_292
end
local function v_u_338(p335) -- name: setTabCounts
	-- upvalues: (copy) v_u_300, (copy) v_u_311, (copy) v_u_226
	for _, v336 in v_u_300 do
		local v337 = v_u_311:FindFirstChild(v336.id)
		if v337 then
			v337 = v337:FindFirstChildWhichIsA("TextLabel", true)
		end
		if not v337 then
			continue
		end
		v337.RichText = true
		v337.Text = ("%s <font transparency=\"0.45\">%d</font>"):format(v336.label, p335[v336.id] or 0)
	end
	if v_u_226.tabs then
		task.delay(0.05, v_u_226.tabs)
	end
end
local v_u_339 = true
local v340, v341, v_u_342, _ = v286("AutoDelete", "trash", 1)
v341.Text = "Auto delete"
local _, v_u_346, v_u_347 = (function(p343) -- name: makeSwitch
	-- upvalues: (copy) v_u_10, (copy) v_u_221
	local v344 = v_u_10.new("Frame", {
		["Name"] = "Track",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["LayoutOrder"] = 3,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_221,
		["Size"] = UDim2.fromOffset(38, 22),
		["Parent"] = p343
	})
	v_u_10.corner(v344, 11)
	local v345 = v_u_10.gradient(v344, "grey")
	v345.Rotation = 0
	return v344, v345, v_u_10.text({
		["Name"] = "Knob",
		["Text"] = "OFF",
		["TextSize"] = 11,
		["FontFace"] = nil,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["Size"] = nil,
		["ZIndex"] = 2,
		["Parent"] = nil,
		["FontFace"] = v_u_10.FONT_HEAVY,
		["TextColor3"] = v_u_221,
		["TextXAlignment"] = Enum.TextXAlignment.Center,
		["Size"] = UDim2.fromScale(1, 1),
		["Parent"] = v344
	})
end)(v340)
local function v_u_351(_) -- name: paintSwitch
	-- upvalues: (ref) v_u_339, (copy) v_u_10, (copy) v_u_346, (copy) v_u_347, (copy) v_u_221, (copy) v_u_342
	local v348
	if v_u_339 then
		v348 = v_u_10.GRAD.gold
	else
		v348 = v_u_10.GRAD.grey
	end
	v_u_346.Color = ColorSequence.new(v348[1], v348[2])
	v_u_347.Text = v_u_339 and "ON" or "OFF"
	local v349 = v_u_347
	local v350
	if v_u_339 then
		v350 = v_u_10.INK
	else
		v350 = v_u_221
	end
	v349.TextColor3 = v350
	v_u_342.Text = not v_u_339 and "Off \194\183 stays until you put it away" or ("On \194\183 put away after %d min unused"):format(3)
end
v_u_351(false)
local v_u_352 = false
v340.Activated:Connect(function()
	-- upvalues: (ref) v_u_352, (ref) v_u_339, (copy) v_u_351, (copy) v_u_1, (copy) v_u_20, (copy) v_u_12
	if v_u_352 then
		return
	else
		v_u_352 = true
		local v353 = not v_u_339
		v_u_339 = v353
		v_u_351(true)
		local v354 = v_u_1.invoke
		local v355 = v_u_20
		local v356, v357 = pcall(v354, v355, "AutoDelete", v353)
		v_u_352 = false
		if v356 and v357 then
			v_u_12.show(not v353 and "Auto delete off: your vehicle stays until you put it away or leave the game" or ("Auto delete on: a vehicle left unused for %d minutes is put away"):format(3), "info")
		else
			v_u_339 = not v353
			v_u_351(true)
			v_u_12.show("Couldn\'t change auto delete, try again", "error")
		end
	end
end)
local v_u_358 = require(v3:WaitForChild("RankShared"))
local v359, v_u_360, v_u_361 = v286("VipOut", "crown", 2)
local v_u_362 = v_u_10.new("Frame", {
	["Name"] = "Stepper",
	["BackgroundTransparency"] = 1,
	["Size"] = nil,
	["LayoutOrder"] = 3,
	["Parent"] = nil,
	["Size"] = UDim2.fromOffset(76, 24),
	["Parent"] = v359
})
local function v366(p363, p364) -- name: stepButton
	-- upvalues: (copy) v_u_10, (copy) v_u_362
	local v365 = v_u_10.new("TextButton", {
		["Name"] = nil,
		["Text"] = nil,
		["FontFace"] = nil,
		["TextSize"] = 15,
		["TextColor3"] = nil,
		["AutoButtonColor"] = true,
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Name"] = p363,
		["Text"] = p363,
		["FontFace"] = v_u_10.FONT_HEAVY,
		["TextColor3"] = v_u_10.TEXT,
		["BackgroundColor3"] = v_u_10.CARD_HOVER,
		["Position"] = UDim2.fromOffset(p364, 0),
		["Size"] = UDim2.fromOffset(24, 24),
		["Parent"] = v_u_362
	})
	v_u_10.corner(v365, 6)
	return v365
end
local v367 = v366("-", 0)
local v368 = v366("+", 52)
local v_u_369 = v_u_10.new("TextBox", {
	["Name"] = "Count",
	["Text"] = "1",
	["ClearTextOnFocus"] = true,
	["FontFace"] = nil,
	["TextSize"] = 17,
	["TextColor3"] = nil,
	["BackgroundColor3"] = nil,
	["BorderSizePixel"] = 0,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["FontFace"] = v_u_10.FONT_HEAVY,
	["TextColor3"] = v_u_10.ACCENT,
	["BackgroundColor3"] = Color3.fromRGB(10, 11, 15),
	["Position"] = UDim2.fromOffset(26, 0),
	["Size"] = UDim2.fromOffset(24, 24),
	["Parent"] = v_u_362
})
v_u_10.corner(v_u_369, 6)
local v_u_370 = v_u_11.make("lock", v_u_10.TEXT_DIM, 14)
v_u_370.LayoutOrder = 4
v_u_370.Parent = v359
local function v_u_373() -- name: paintHint
	-- upvalues: (copy) v_u_248, (ref) v_u_296, (copy) v_u_32
	local v371 = v_u_248
	local v372
	if v_u_296 > 1 then
		v372 = ("Up to %d out at once (VIP): spawning more swaps the oldest"):format(v_u_296)
	else
		v372 = v_u_32 and "One at a time: spawning another swaps it" or "One vehicle at a time: spawning another swaps it  \194\183  Hold J or the bin button to put it away"
	end
	v371.Text = v372
end
local function v_u_384() -- name: paintVip
	-- upvalues: (copy) v_u_8, (copy) v_u_18, (copy) v_u_358, (copy) v_u_362, (copy) v_u_370, (copy) v_u_360, (copy) v_u_10, (copy) v_u_361, (copy) v_u_369, (ref) v_u_296, (ref) v_u_373
	local v374 = v_u_8.hasPass(v_u_18, "VIP") or v_u_358.isStaff(v_u_18)
	v_u_362.Visible = v374
	v_u_370.Visible = not v374
	v_u_360.Text = "VIP"
	local v375 = v_u_360
	local v376
	if v374 then
		v376 = v_u_10.TEXT
	else
		v376 = v_u_10.TEXT_DIM
	end
	v375.TextColor3 = v376
	local v377 = v_u_361
	local v378
	if v374 then
		v378 = ("Out at once: 1-%d"):format(v_u_8.VIP_MAX_OUT)
	else
		v378 = ("Locked \194\183 VIP gets %d at once"):format(v_u_8.VIP_MAX_OUT)
	end
	v377.Text = v378
	if not v_u_369:IsFocused() then
		local v379 = v_u_369
		local v380 = v_u_18:GetAttribute("VipVehiclesOut")
		local v381
		if type(v380) == "number" and v380 == v380 then
			local v382 = math.floor(v380)
			local v383 = v_u_8.VIP_MAX_OUT
			v381 = math.clamp(v382, 1, v383)
		else
			v381 = 1
		end
		v379.Text = tostring(v381)
	end
	v_u_296 = v_u_8.spawnLimits(v_u_18)
	v_u_373()
end
local v_u_385 = false
local function v_u_396(p386) -- name: setVip
	-- upvalues: (ref) v_u_385, (copy) v_u_8, (copy) v_u_12, (copy) v_u_384, (copy) v_u_18, (copy) v_u_369, (copy) v_u_1, (copy) v_u_20
	if v_u_385 then
		return
	elseif type(p386) == "number" and (p386 == p386 and (p386 == math.floor(p386) and (p386 >= 1 and v_u_8.VIP_MAX_OUT >= p386))) then
		local v387 = v_u_18:GetAttribute("VipVehiclesOut")
		local v388
		if type(v387) == "number" and v387 == v387 then
			local v389 = math.floor(v387)
			local v390 = v_u_8.VIP_MAX_OUT
			v388 = math.clamp(v389, 1, v390)
		else
			v388 = 1
		end
		if p386 == v388 then
			v_u_384()
		else
			v_u_385 = true
			v_u_369.Text = tostring(p386)
			local v391 = v_u_1.invoke
			local v392 = v_u_20
			local v393, v394, v395 = pcall(v391, v392, "VipOut", p386)
			v_u_385 = false
			if v393 and v394 then
				v_u_12.show(("VIP: up to %d vehicles out at once \194\183 spawning more puts the oldest away"):format(p386), "ok")
			else
				v_u_12.show((not v393 or type(v395) ~= "string") and "Couldn\'t change it, try again" or v395, "error")
			end
			v_u_384()
		end
	else
		v_u_12.show(("VIP: 1 to %d vehicles only"):format(v_u_8.VIP_MAX_OUT), "error")
		v_u_384()
		return
	end
end
v367.Activated:Connect(function()
	-- upvalues: (copy) v_u_396, (copy) v_u_18, (copy) v_u_8
	local v397 = v_u_396
	local v398 = v_u_18:GetAttribute("VipVehiclesOut")
	local v399
	if type(v398) == "number" and v398 == v398 then
		local v400 = math.floor(v398)
		local v401 = v_u_8.VIP_MAX_OUT
		v399 = math.clamp(v400, 1, v401)
	else
		v399 = 1
	end
	v397(v399 - 1)
end)
v368.Activated:Connect(function()
	-- upvalues: (copy) v_u_396, (copy) v_u_18, (copy) v_u_8
	local v402 = v_u_396
	local v403 = v_u_18:GetAttribute("VipVehiclesOut")
	local v404
	if type(v403) == "number" and v403 == v403 then
		local v405 = math.floor(v403)
		local v406 = v_u_8.VIP_MAX_OUT
		v404 = math.clamp(v405, 1, v406)
	else
		v404 = 1
	end
	v402(v404 + 1)
end)
v_u_369.FocusLost:Connect(function()
	-- upvalues: (copy) v_u_369, (copy) v_u_396
	local v407 = v_u_369.Text:gsub("%s", "")
	local v408 = v_u_396
	local v409
	if v407:match("^%d+$") then
		v409 = tonumber(v407)
	else
		v409 = nil
	end
	v408(v409)
end)
v359.Activated:Connect(function()
	-- upvalues: (copy) v_u_8, (copy) v_u_18, (copy) v_u_358, (copy) v_u_12
	if not (v_u_8.hasPass(v_u_18, "VIP") or v_u_358.isStaff(v_u_18)) then
		v_u_12.show(("VIP only: up to %d vehicles out at once. Get VIP in the Store"):format(v_u_8.VIP_MAX_OUT), "info")
	end
end)
local v_u_410 = v_u_339
local v_u_411 = v_u_352
local v_u_412 = v_u_373
for _, v413 in { "VipVehiclesOut", "Pass_VIP", "Rank" } do
	v_u_18:GetAttributeChangedSignal(v413):Connect(v_u_384)
end
v_u_384()
local v_u_414 = v_u_280:FindFirstChildOfClass("UIListLayout")
function v_u_226.layout() -- name: layout
	-- upvalues: (copy) v_u_32, (copy) v_u_10, (copy) v_u_229, (copy) v_u_414, (copy) v_u_232, (copy) v_u_217, (copy) v_u_214, (copy) v_u_215, (copy) v_u_280, (copy) v_u_249, (copy) v_u_234, (copy) v_u_237, (copy) v_u_247, (copy) v_u_246, (copy) v_u_239, (copy) v_u_238, (copy) v_u_226, (copy) v_u_241, (copy) v_u_243, (copy) v_u_244, (copy) v_u_248
	if v_u_32 then
		local v415 = v_u_10.unscaledSize(v_u_229)
		local v416 = v415.X
		local v417 = v415.Y
		if v416 >= 200 and (v417 >= 150 and v_u_229.AbsoluteSize.X > 0) then
			local v418 = v_u_229.AbsoluteSize.X / v416
			local v419 = (not v_u_414 and 0 or v_u_414.AbsoluteContentSize.X) / v418
			local v420 = v416 / 2
			for _, v421 in v_u_232:GetChildren() do
				if not v421:IsA("TextLabel") then
					continue
				end
				local v422 = (v421.AbsolutePosition.X + v421.AbsoluteSize.X / 2 - v_u_229.AbsolutePosition.X) / v418 + v421.TextBounds.X / v418 / 2 + (v421.Rotation == 0 and 0 or 6)
				v420 = math.max(v420, v422)
			end
			local v423 = v416 - v_u_217 - v419 >= v420 + 8
			local v424 = v416 - (v_u_217 * 2 + v_u_214 + 18 + 28 + 250)
			local v425 = v_u_215
			local v426 = math.clamp(v424, 252, v425)
			if not v423 then
				local v427 = v_u_215
				local v428 = math.min(v419, v427)
				v426 = math.max(v426, v428)
			end
			v_u_280.Position = UDim2.new(1, -v_u_217, 0, v423 and 12 or 72)
			v_u_280.Size = UDim2.new(0, math.max(v426, v419), 0, 34)
			local v429 = v423 and 72 or 118
			v_u_249.Position = UDim2.new(1, -v_u_217, 0, v429)
			v_u_249.Size = UDim2.new(0, v426, 1, -(v429 + 12))
			v_u_234.Position = UDim2.fromOffset(v_u_217, 72)
			v_u_234.Size = UDim2.new(0, v_u_214 + 22, 1, -84)
			local v430 = v_u_217 + v_u_214 + 18 + 14
			local v431 = v416 - v_u_217 - v426 - 14
			local v432 = v417 - 118
			v_u_237.Position = UDim2.fromOffset(v430, 72)
			local v433 = v_u_237
			local v434 = UDim2.fromOffset
			local v435 = v431 - v430
			v433.Size = v434(math.max(v435, 80), v432)
			v_u_247.Position = UDim2.new(0.5, 0, 1, 0)
			v_u_247.Size = UDim2.new(1, 0, 0, 16)
			v_u_246.Position = UDim2.new(0.5, 0, 1, -18)
			local v436 = v432 - 18 - 20 - 6 - 15
			v_u_239.Position = UDim2.new(0.5, 0, 0, v436)
			v_u_238.Position = UDim2.new(0.5, 0, 0, v436 + 2)
			local v437 = v436 + 2
			local v438 = math.max(v437, 40)
			v_u_226.home = UDim2.new(0.5, 0, 0, v436 + 6)
			v_u_241.Position = v_u_226.home
			v_u_241.Size = UDim2.new(0.92, 0, 0, v438)
			v_u_243.Position = UDim2.new(0.5, 0, 0, v436 + 8)
			v_u_243.Size = UDim2.new(0.86, 0, 0, v438)
			v_u_244.Position = UDim2.new(0.5, 0, 0, v436 + 12)
			v_u_244.Size = UDim2.new(0.96, 0, 0, v438 + 6)
			v_u_248.TextWrapped = true
			v_u_248.TextTruncate = Enum.TextTruncate.AtEnd
			v_u_248.AnchorPoint = Vector2.new(0.5, 1)
			v_u_248.Position = UDim2.new(0, (v430 + v431) / 2, 1, -12)
			local v439 = v_u_248
			local v440 = UDim2.fromOffset
			local v441 = v431 - v430
			v439.Size = v440(math.max(v441, 80), 30)
			if v_u_226.tabs then
				v_u_226.tabs()
			end
		end
	else
		return
	end
end
if v_u_32 then
	v_u_229:GetPropertyChangedSignal("AbsoluteSize"):Connect(function()
		-- upvalues: (copy) v_u_229, (copy) v_u_226
		if v_u_229.Visible then
			v_u_226.layout()
		end
	end)
	if v_u_414 then
		v_u_414:GetPropertyChangedSignal("AbsoluteContentSize"):Connect(function()
			-- upvalues: (copy) v_u_229, (copy) v_u_226
			if v_u_229.Visible then
				v_u_226.layout()
			end
		end)
	end
end
local function v_u_446(p442, p443) -- name: paintModel
	-- upvalues: (copy) v_u_8
	if type(p443) == "table" then
		for _, v444 in p442:GetDescendants() do
			local v445 = v444:IsA("BasePart")
			if v445 then
				v445 = v444:GetAttribute("PaintGroup")
			end
			if v445 then
				v445 = v_u_8.decodeValue(p443["Paint" .. v445])
			end
			if typeof(v445) ~= "Color3" then
				continue
			end
			v444.Color = v445
		end
	end
end
local function v_u_461(p_u_447, p_u_448, p449) -- name: smallPicture
	-- upvalues: (copy) v_u_17, (copy) v_u_10, (copy) v_u_8, (copy) v_u_31, (copy) v_u_446
	local v450 = v_u_17.of(p_u_447)
	if v450 then
		return v_u_10.new("ImageLabel", {
			["Name"] = "Picture",
			["BackgroundTransparency"] = 1,
			["Image"] = nil,
			["ScaleType"] = nil,
			["Parent"] = nil,
			["Image"] = v450,
			["ScaleType"] = Enum.ScaleType.Fit,
			["Parent"] = p449
		})
	else
		local v451 = v_u_8.vehicle(p_u_447)
		local v452 = v_u_10.new("Frame", {
			["Name"] = "Picture",
			["BackgroundTransparency"] = 1,
			["ClipsDescendants"] = true,
			["Parent"] = nil,
			["Parent"] = p449
		})
		if v451 and v451.thumb then
			local v453 = v_u_10.new("ImageLabel", {
				["Image"] = nil,
				["ScaleType"] = nil,
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["Parent"] = nil,
				["Image"] = v451.thumb,
				["ScaleType"] = Enum.ScaleType.Crop,
				["Size"] = UDim2.fromScale(1, 1),
				["Parent"] = v452
			})
			v_u_10.corner(v453, 8)
			return v452
		else
			local v_u_454 = v_u_10.new("ViewportFrame", {
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["Ambient"] = nil,
				["LightColor"] = nil,
				["LightDirection"] = Vector3.new(-0.6, -1, -0.4),
				["Parent"] = nil,
				["Size"] = UDim2.fromScale(1, 1),
				["Ambient"] = Color3.fromRGB(150, 150, 150),
				["LightColor"] = Color3.fromRGB(255, 250, 240),
				["Parent"] = v452
			})
			task.spawn(function()
				-- upvalues: (ref) v_u_31, (copy) p_u_447, (copy) v_u_454, (ref) v_u_446, (copy) p_u_448
				local v455 = v_u_31(p_u_447)
				if v455 and v_u_454.Parent then
					local v456 = v455:Clone()
					v_u_446(v456, p_u_448)
					v456.Parent = v_u_454
					local v457 = Instance.new("Camera")
					v457.FieldOfView = 30
					local v458, v459 = v456:GetBoundingBox()
					local v460 = (CFrame.Angles(0, 0, 0) * Vector3.new(0.85, 0.36, -1)).Unit
					v457.CFrame = CFrame.lookAt(v458.Position + v460 * v459.Magnitude * 1.12, v458.Position)
					v457.Parent = v_u_454
					v_u_454.CurrentCamera = v457
				end
			end)
			return v452
		end
	end
end
local v_u_462 = nil
local v_u_463 = 0
v4.RenderStepped:Connect(function(p464)
	-- upvalues: (ref) v_u_462, (ref) v_u_291, (copy) v_u_244, (ref) v_u_463, (ref) v_u_245
	if v_u_462 and (v_u_291 and v_u_244.Visible) then
		v_u_463 = (v_u_463 + p464 * 0.35) % 6.283185307179586
		local v465 = v_u_245
		local v466 = v_u_463
		local v467, v468 = v_u_462:GetBoundingBox()
		local v469 = (CFrame.Angles(0, v466, 0) * Vector3.new(0.85, 0.36, -1)).Unit
		v465.CFrame = CFrame.lookAt(v467.Position + v469 * v468.Magnitude * 1.15, v467.Position)
	end
end)
local v_u_470 = 0
local v_u_471 = {}
local function v_u_492() -- name: paintMain
	-- upvalues: (ref) v_u_314, (ref) v_u_316, (copy) v_u_288, (copy) v_u_289, (copy) v_u_290, (copy) v_u_219, (ref) v_u_470, (copy) v_u_10, (copy) v_u_8, (copy) v_u_471, (ref) v_u_295, (copy) v_u_196, (ref) v_u_296, (copy) v_u_221
	local v472 = v_u_314
	if v472 then
		v472 = v_u_316[v_u_314]
	end
	local v473
	if v472 then
		v473 = v472.entry
	else
		v473 = v472
	end
	local v474
	if v472 then
		v474 = v472.info
	else
		v474 = v472
	end
	v_u_288.Visible = v472 ~= nil
	local v475 = v_u_289
	local v476
	if v472 == nil then
		v476 = false
	else
		v476 = v473.buy ~= nil
	end
	v475.Visible = v476
	v_u_290.Visible = v472 ~= nil
	if v472 then
		if v473.buy then
			v_u_288.Size = UDim2.new(0.6, -8, 0, v_u_219)
			local v477 = os.clock() < v_u_470
			v_u_10.setButton(v_u_288, "gold", v477 and "Tap again to buy" or "Buy " .. v_u_8.formatCash(v473.buy.cash), v_u_10.DARK_TEXT)
			local v478 = v474.product
			if v478 then
				v478 = v_u_471[v474.product]
			end
			v_u_10.setButton(v_u_289, v473.buy.onSale and "green" or "grey", "R$ " .. v_u_8.formatNumber(v478 or (v473.buy.robux or 0)) .. (v473.buy.onSale and "" or " (soon)"))
			return
		else
			v_u_288.Size = UDim2.new(1, 0, 0, v_u_219)
			if v473.locked then
				v_u_10.setButton(v_u_288, "gold", "Unlock with " .. v_u_8.passName(v473.pass), v_u_10.DARK_TEXT)
			else
				local v479 = v_u_295 - os.clock()
				local v480 = math.ceil(v479)
				local v481 = v_u_196()
				local v482 = 0
				for _, v483 in v481 do
					v482 = v482 + v483
				end
				local v484 = v481[v_u_314] or 0
				local v485
				if v_u_296 <= v482 then
					v485 = v484 == 0
				else
					v485 = false
				end
				local v486 = v480 > 0
				local v487 = v_u_10.setButton
				local v488 = v_u_288
				local v489 = v486 and "grey" or (v484 > 0 and "green" or "gold")
				local v490
				if v486 then
					v490 = ("Wait %d"):format(v480)
				else
					v490 = v484 > 0 and "Bring it here" or (v485 and "Swap to this" or "Spawn")
				end
				local v491
				if v486 then
					v491 = v_u_10.TEXT_DIM
				elseif v484 > 0 then
					v491 = v_u_221
				else
					v491 = v_u_10.DARK_TEXT
				end
				v487(v488, v489, v490, v491)
			end
		end
	else
		return
	end
end
local function v_u_507(p493, p494) -- name: paintChips
	-- upvalues: (copy) v_u_255, (copy) v_u_10, (copy) v_u_221
	for _, v495 in v_u_255:GetChildren() do
		if not v495:IsA("GuiObject") then
			continue
		end
		v495:Destroy()
	end
	local v496 = 0
	local v497
	if p494 > 0 then
		local v498 = p494 <= 1 and "Out now" or ("%d out now"):format(p494)
		local v499 = v_u_10.LIME
		v496 = v496 + 1
		local v500 = {
			["LayoutOrder"] = nil,
			["ZIndex"] = 1,
			["LayoutOrder"] = v496
		}
		v_u_10.chip(v_u_255, v498, v499, v500)
		v497 = v496
	else
		v497 = v496
	end
	if p493.buy then
		local v501 = v_u_221
		v496 = v497 + 1
		local v502 = {
			["LayoutOrder"] = nil,
			["ZIndex"] = 1,
			["LayoutOrder"] = v496
		}
		v_u_10.chip(v_u_255, "For sale", v501, v502)
		v497 = v496
	elseif p493.locked then
		local v503 = v_u_10.ACCENT
		v496 = v497 + 1
		local v504 = {
			["LayoutOrder"] = nil,
			["ZIndex"] = 1,
			["LayoutOrder"] = v496
		}
		v_u_10.chip(v_u_255, "Game pass", v503, v504)
		v497 = v496
	end
	if p493.fav then
		local v505 = v_u_10.GOLD
		v496 = v497 + 1
		local v506 = {
			["LayoutOrder"] = nil,
			["ZIndex"] = 1,
			["LayoutOrder"] = v496
		}
		v_u_10.chip(v_u_255, "\226\152\133 Favourite", v505, v506)
	end
end
local function v_u_520() -- name: refreshButtons
	-- upvalues: (copy) v_u_196, (copy) v_u_8, (copy) v_u_247, (ref) v_u_316, (ref) v_u_314, (copy) v_u_507, (copy) v_u_492
	local v508 = v_u_196()
	local v509 = 0
	local v510 = {}
	for v514, v512 in v508 do
		v509 = v509 + v512
		local v513 = v_u_8.vehicle(v514)
		if v513 then
			local v514 = v513.th
		end
		table.insert(v510, v514)
	end
	v_u_247.Text = v509 <= 0 and "" or "Out now: " .. table.concat(v510, ", ")
	for v515, v516 in v_u_316 do
		local v517 = v508[v515] or 0
		v516.status.Visible = v517 > 0
		v516.statusText.Text = v517 <= 1 and "OUT" or ("%d OUT"):format(v517)
	end
	local v518 = v_u_314
	if v518 then
		v518 = v_u_316[v_u_314]
	end
	local v519
	if v518 then
		v519 = v518.entry
	else
		v519 = v518
	end
	if v518 then
		local _ = v518.info
	end
	if v518 then
		v_u_507(v519, v508[v_u_314] or 0)
	end
	v_u_492()
end
local function v_u_528(p521) -- name: spawnVehicle
	-- upvalues: (ref) v_u_192, (ref) v_u_295, (copy) v_u_1, (copy) v_u_20, (copy) v_u_12, (copy) v_u_8, (copy) v_u_18, (ref) v_u_291, (copy) v_u_228
	if v_u_192 or os.clock() < v_u_295 then
		return
	else
		v_u_192 = true
		local v522 = v_u_1.invoke
		local v523 = v_u_20
		local v524, v525, v526 = pcall(v522, v523, "Spawn", p521)
		v_u_192 = false
		if v524 then
			v_u_12.show(v526 or "", v525 and "ok" or "error")
			if v525 then
				local _, v527 = v_u_8.spawnLimits(v_u_18)
				v_u_295 = os.clock() + v527
				v_u_291 = false
				v_u_228.setOpen(false)
			end
		else
			v_u_12.show("Couldn\'t spawn", "error")
		end
	end
end
local v_u_529 = nil
v_u_298 = function(p_u_530) -- name: selectVehicle
	-- upvalues: (ref) v_u_316, (ref) v_u_314, (ref) v_u_470, (copy) v_u_254, (copy) v_u_253, (copy) v_u_246, (copy) v_u_241, (copy) v_u_243, (copy) v_u_244, (copy) v_u_290, (copy) v_u_520, (copy) v_u_220, (ref) v_u_313, (copy) v_u_279, (copy) v_u_271, (copy) v_u_299, (copy) v_u_272, (copy) v_u_273, (copy) v_u_8, (copy) v_u_10, (copy) v_u_221, (ref) v_u_462, (ref) v_u_245, (copy) v_u_17, (copy) v_u_242, (copy) v_u_226, (copy) v_u_5, (copy) v_u_31, (copy) v_u_446, (ref) v_u_463, (copy) v_u_471, (copy) v_u_7, (copy) v_u_492
	local v531
	if p_u_530 then
		v531 = v_u_316[p_u_530]
	else
		v531 = p_u_530
	end
	if v_u_314 and v_u_316[v_u_314] then
		v_u_316[v_u_314].select(false)
	end
	local v532
	if v531 then
		v532 = p_u_530
	else
		v532 = nil
	end
	v_u_314 = v532
	v_u_470 = 0
	if v531 then
		v531.select(true)
		local v_u_533 = v531.info
		local v_u_534 = v531.entry
		v_u_253.Text = (v_u_220[v_u_533.category] or string.upper(v_u_533.category or "")) .. (v_u_534.buy and "  \194\183  FOR SALE" or (v_u_534.locked and "  \194\183  GAME PASS" or ""))
		v_u_254.Text = v_u_533.th
		v_u_246.Text = ("<font color=\"#EEE452\">%02d</font>  /  %02d"):format(table.find(v_u_313, p_u_530) or 0, #v_u_313)
		v_u_279(v_u_271, not v_u_534.top and "\226\128\148" or ("%d KM/H"):format(v_u_534.top), not v_u_534.top and 0 or v_u_534.top / v_u_299.max, true)
		local v535 = v_u_279
		local v536 = v_u_272
		local v537 = v_u_533.seats or 2
		v535(v536, tostring(v537), (v_u_533.seats or 2) / 4, true)
		local v538 = v_u_279
		local v539 = v_u_273
		local v540 = v_u_534.odoKm or 0
		local v541
		if v540 < 100 then
			v541 = string.format("%.1f KM", v540)
		else
			v541 = v_u_8.formatNumber((math.floor(v540))) .. " KM"
		end
		v538(v539, v541, v_u_299.odo <= 0 and 0 or (v_u_534.odoKm or 0) / v_u_299.odo, true)
		local v542 = v_u_10.setButton
		local v543 = v_u_290
		local v544 = "grey"
		local v545 = v_u_534.fav and "\226\152\133  Favourite" or "\226\152\134  Add to favourites"
		local v546
		if v_u_534.fav then
			v546 = v_u_10.GOLD
		else
			v546 = v_u_221
		end
		v542(v543, v544, v545, v546)
		v_u_462 = nil
		v_u_244:ClearAllChildren()
		local v547 = {
			["FieldOfView"] = 28,
			["Parent"] = nil,
			["Parent"] = v_u_244
		}
		v_u_245 = v_u_10.new("Camera", v547)
		v_u_244.CurrentCamera = v_u_245
		local v548 = v_u_17.of(p_u_530)
		local v549 = v_u_243
		local v550 = v_u_244
		v_u_241.Visible = v548 ~= nil
		v549.Visible = false
		v550.Visible = false
		if v548 then
			local v551, v552 = v_u_17.size(p_u_530)
			local v553 = v_u_242
			local v554 = Vector2.new
			local v555 = (v551 or 560) * 1.12
			local v556 = math.min(640, v555)
			local v557 = (v552 or 300) * 1.12
			v553.MaxSize = v554(v556, (math.min(420, v557)))
			v_u_241.Image = v548
			v_u_241.ImageTransparency = 1
			v_u_241.Position = v_u_226.home + UDim2.fromScale(0.06, 0)
			v_u_5:Create(v_u_241, TweenInfo.new(0.35, Enum.EasingStyle.Quint, Enum.EasingDirection.Out), {
				["ImageTransparency"] = 0,
				["Position"] = nil,
				["Position"] = v_u_226.home
			}):Play()
		elseif v_u_533.thumb then
			v_u_243.Image = v_u_533.thumb
			v_u_243.Visible = true
		else
			v_u_244.Visible = true
			task.spawn(function()
				-- upvalues: (ref) v_u_31, (copy) p_u_530, (ref) v_u_314, (ref) v_u_446, (copy) v_u_534, (ref) v_u_244, (ref) v_u_463, (ref) v_u_462, (ref) v_u_245
				local v558 = v_u_31(p_u_530)
				if v558 and v_u_314 == p_u_530 then
					local v559 = v558:Clone()
					v_u_446(v559, v_u_534.look)
					v559.Parent = v_u_244
					v_u_463 = 0
					v_u_462 = v559
					local v560 = v_u_245
					local v561, v562 = v559:GetBoundingBox()
					local v563 = (CFrame.Angles(0, 0, 0) * Vector3.new(0.85, 0.36, -1)).Unit
					v560.CFrame = CFrame.lookAt(v561.Position + v563 * v562.Magnitude * 1.15, v561.Position)
				end
			end)
		end
		if v_u_534.buy and v_u_534.buy.onSale then
			local v564 = v_u_533.product
			if type(v564) == "number" and not v_u_471[v_u_533.product] then
				task.spawn(function()
					-- upvalues: (ref) v_u_7, (copy) v_u_533, (ref) v_u_471, (ref) v_u_314, (copy) p_u_530, (ref) v_u_492
					local v565 = v_u_7.GetProductInfo
					local v566 = v_u_7
					local v567 = v_u_533.product
					local v568 = Enum.InfoType.Product
					local v569, v570 = pcall(v565, v566, v567, v568)
					if v569 and v570 then
						local v571 = v570.PriceInRobux
						if type(v571) == "number" then
							v_u_471[v_u_533.product] = v570.PriceInRobux
							if v_u_314 == p_u_530 then
								v_u_492()
							end
						end
					end
				end)
			end
		end
		v_u_520()
	else
		local v572 = v_u_253
		local v573 = v_u_246
		v_u_254.Text = ""
		v572.Text = ""
		v573.Text = ""
		v_u_241.Image = ""
		local v574 = v_u_244
		v_u_243.Visible = false
		v574.Visible = false
		v_u_290.Visible = false
		v_u_520()
	end
end
v_u_290.Activated:Connect(function()
	-- upvalues: (ref) v_u_314, (ref) v_u_316, (copy) v_u_1, (copy) v_u_20, (copy) v_u_12, (ref) v_u_529
	local v575 = v_u_314
	if v575 then
		v575 = v_u_316[v_u_314]
	end
	local v576
	if v575 then
		v576 = v575.entry
	else
		v576 = v575
	end
	local v577
	if v575 then
		v577 = v575.info
	else
		v577 = v575
	end
	if v575 then
		local v578 = not v576.fav
		local v579 = v_u_1.invoke
		local v580 = v_u_20
		local v581 = v577.id
		local v582, v583 = pcall(v579, v580, "Favorite", v581, v578)
		if v582 and v583 then
			v576.fav = v578
			local v584 = v_u_12.show
			local v585
			if v578 then
				v585 = v577.th .. " is a favourite: it comes first"
			else
				v585 = v577.th .. " is no longer a favourite"
			end
			v584(v585, "ok")
			task.spawn(v_u_529)
		else
			v_u_12.show("Couldn\'t save that, try again", "error")
		end
	else
		return
	end
end)
v_u_288.Activated:Connect(function()
	-- upvalues: (ref) v_u_314, (ref) v_u_316, (ref) v_u_470, (copy) v_u_492, (ref) v_u_192, (copy) v_u_1, (copy) v_u_20, (copy) v_u_12, (ref) v_u_529, (ref) v_u_291, (copy) v_u_228, (copy) v_u_14, (copy) v_u_528
	local v586 = v_u_314
	if v586 then
		v586 = v_u_316[v_u_314]
	end
	local v587
	if v586 then
		v587 = v586.entry
	else
		v587 = v586
	end
	local v588
	if v586 then
		v588 = v586.info
	else
		v588 = v586
	end
	if v586 then
		if v587.buy then
			if v_u_470 < os.clock() then
				v_u_470 = os.clock() + 3
				v_u_492()
				task.delay(3.05, v_u_492)
				return
			else
				v_u_470 = 0
				if v_u_192 then
					return
				else
					v_u_192 = true
					local v589 = v_u_1.invoke
					local v590 = v_u_20
					local v591 = v588.id
					local v592, v593, v594 = pcall(v589, v590, "Buy", v591)
					v_u_192 = false
					v_u_12.show(v592 and (v594 or "") or "Couldn\'t buy that, try again", v592 and v593 and "ok" or "error")
					if v592 and v593 then
						task.spawn(v_u_529)
					else
						v_u_492()
					end
				end
			end
		elseif v587.locked then
			v_u_291 = false
			v_u_228.setOpen(false)
			v_u_14.open("Passes")
		else
			task.spawn(v_u_528, v588.id)
		end
	else
		return
	end
end)
v_u_289.Activated:Connect(function()
	-- upvalues: (ref) v_u_314, (ref) v_u_316, (ref) v_u_192, (copy) v_u_1, (copy) v_u_20, (copy) v_u_12, (copy) v_u_7, (ref) v_u_291, (ref) v_u_529, (copy) v_u_18
	local v595 = v_u_314
	if v595 then
		v595 = v_u_316[v_u_314]
	end
	local v596
	if v595 then
		v596 = v595.entry
	else
		v596 = v595
	end
	local v597
	if v595 then
		v597 = v595.info
	else
		v597 = v595
	end
	if v595 and (v596.buy and not v_u_192) then
		v_u_192 = true
		local v598 = v_u_1.invoke
		local v599 = v_u_20
		local v600 = v597.id
		local v601, v602, v603, v_u_604 = pcall(v598, v599, "BuyRobux", v600)
		v_u_192 = false
		if v601 and (v602 and type(v_u_604) == "number") then
			local v_u_605 = nil
			v_u_605 = v_u_7.PromptProductPurchaseFinished:Connect(function(_, p606, p607)
				-- upvalues: (copy) v_u_604, (ref) v_u_605, (ref) v_u_291, (ref) v_u_529
				if p606 == v_u_604 then
					v_u_605:Disconnect()
					if p607 then
						task.delay(2, function()
							-- upvalues: (ref) v_u_291, (ref) v_u_529
							if v_u_291 then
								v_u_529()
							end
						end)
					end
				end
			end)
			v_u_7:PromptProductPurchase(v_u_18, v_u_604)
		else
			v_u_12.show(v601 and (v603 or "Robux sale coming soon") or "Couldn\'t open that, try again", "error")
		end
	else
		return
	end
end)
local function v_u_643(p_u_608, p609, p610) -- name: card
	-- upvalues: (copy) v_u_10, (copy) v_u_216, (copy) v_u_236, (copy) v_u_221, (copy) v_u_214, (copy) v_u_223, (copy) v_u_32, (copy) v_u_461, (copy) v_u_220, (copy) v_u_8, (copy) v_u_11, (copy) v_u_225, (copy) v_u_224, (ref) v_u_314, (ref) v_u_298, (ref) v_u_316, (copy) v_u_5, (ref) v_u_313
	local v611 = v_u_10.new("Frame", {
		["Name"] = nil,
		["BackgroundTransparency"] = 1,
		["LayoutOrder"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Name"] = p_u_608.id,
		["LayoutOrder"] = p610,
		["Size"] = UDim2.new(1, 0, 0, v_u_216),
		["Parent"] = v_u_236
	})
	local v_u_612 = v_u_10.new("TextButton", {
		["Name"] = "Card",
		["Text"] = "",
		["AutoButtonColor"] = false,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.06,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_221,
		["Size"] = UDim2.new(0, v_u_214, 1, 0),
		["Parent"] = v611
	})
	local v_u_613 = v_u_10.new("UIGradient", {
		["Color"] = ColorSequence.new(v_u_223[1], v_u_223[2]),
		["Parent"] = v_u_612
	})
	v_u_10.slant(v_u_612, v_u_32 and 18 or 22, v_u_613)
	local v_u_614 = v_u_10.text({
		["Name"] = "Number",
		["Text"] = nil,
		["TextSize"] = 11,
		["FontFace"] = nil,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Text"] = ("%02d"):format(p610),
		["FontFace"] = v_u_10.FONT_HEAVY,
		["TextColor3"] = v_u_10.TEXT_DIM,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["Position"] = UDim2.fromOffset(v_u_32 and 26 or 30, 8),
		["Size"] = UDim2.fromOffset(30, 14),
		["Parent"] = v_u_612
	})
	local v615 = v_u_461(p_u_608.id, p609.look, v_u_612)
	v615.AnchorPoint = Vector2.new(0, 0.5)
	v615.Position = UDim2.new(0, v_u_32 and 8 or 12, 0.5, 6)
	v615.Size = UDim2.new(0.56, 0, 1, -16)
	local v_u_616 = v_u_10.text({
		["Name"] = "Title",
		["Text"] = nil,
		["TextSize"] = nil,
		["FontFace"] = nil,
		["TextXAlignment"] = nil,
		["TextTruncate"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Text"] = p_u_608.th,
		["TextSize"] = v_u_32 and 13 or 15,
		["FontFace"] = v_u_10.FONT_HEAVY,
		["TextXAlignment"] = Enum.TextXAlignment.Right,
		["TextTruncate"] = Enum.TextTruncate.AtEnd,
		["Position"] = UDim2.new(0.5, 0, 0, v_u_32 and 10 or 14),
		["Size"] = UDim2.new(0.5, v_u_32 and -20 or -26, 0, 18),
		["Parent"] = v_u_612
	})
	local v_u_617 = v_u_10.text({
		["Name"] = "Kind",
		["Text"] = nil,
		["TextSize"] = 10,
		["FontFace"] = nil,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Text"] = v_u_220[p_u_608.category] or "",
		["FontFace"] = v_u_10.FONT_HEAVY,
		["TextColor3"] = v_u_10.TEXT_DIM,
		["TextXAlignment"] = Enum.TextXAlignment.Right,
		["Position"] = UDim2.new(0.5, 0, 0, v_u_32 and 28 or 33),
		["Size"] = UDim2.new(0.5, v_u_32 and -22 or -30, 0, 12),
		["Parent"] = v_u_612
	})
	if v_u_32 then
		local v618 = v_u_10.new("Frame", {
			["Name"] = "Words",
			["BackgroundTransparency"] = 1,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["Position"] = UDim2.new(0.5, 0, 0, 8),
			["Size"] = UDim2.new(0.5, -20, 0, 48),
			["Parent"] = v_u_612
		})
		v_u_10.new("UIListLayout", {
			["HorizontalAlignment"] = Enum.HorizontalAlignment.Right,
			["Padding"] = UDim.new(0, 2),
			["SortOrder"] = Enum.SortOrder.LayoutOrder,
			["Parent"] = v618
		})
		v_u_616.TextWrapped = true
		v_u_616.TextYAlignment = Enum.TextYAlignment.Top
		v_u_616.AutomaticSize = Enum.AutomaticSize.Y
		v_u_616.Position = UDim2.new()
		v_u_616.Size = UDim2.new(1, 0, 0, 14)
		v_u_616.LayoutOrder = 1
		v_u_10.new("UISizeConstraint", {
			["MaxSize"] = Vector2.new((1 / 0), 32),
			["Parent"] = v_u_616
		})
		v_u_616.Parent = v618
		v_u_617.Position = UDim2.new()
		v_u_617.Size = UDim2.new(1, -2, 0, 12)
		v_u_617.LayoutOrder = 2
		v_u_617.Parent = v618
	end
	local v619 = v_u_10.text
	local v620 = {
		["Name"] = "Sub",
		["Text"] = nil,
		["TextSize"] = nil,
		["FontFace"] = nil,
		["TextXAlignment"] = nil,
		["TextTruncate"] = nil,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil
	}
	local v621
	if p609.buy then
		v621 = v_u_8.formatCash(p609.buy.cash)
	elseif p609.locked then
		v621 = v_u_8.passName(p609.pass)
	else
		local v622 = p609.odoKm or 0
		if v622 < 100 then
			v621 = string.format("%.1f KM", v622)
		else
			v621 = v_u_8.formatNumber((math.floor(v622))) .. " KM"
		end
	end
	v620.Text = v621
	v620.TextSize = v_u_32 and 11 or 12
	v620.FontFace = v_u_10.FONT_BOLD
	v620.TextXAlignment = Enum.TextXAlignment.Right
	v620.TextTruncate = Enum.TextTruncate.AtEnd
	v620.AnchorPoint = Vector2.new(0, 1)
	v620.Position = UDim2.new(0.5, 0, 1, v_u_32 and -10 or -14)
	v620.Size = UDim2.new(0.5, v_u_32 and -40 or -52, 0, 16)
	v620.Parent = v_u_612
	local v_u_623 = v619(v620)
	local v624 = v_u_10.chip(v_u_612, "OUT", v_u_10.LIME, {
		["Name"] = "Out",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Visible"] = false,
		["ZIndex"] = 3,
		["AnchorPoint"] = Vector2.new(1, 1),
		["Position"] = UDim2.new(1, v_u_32 and -24 or -30, 1, v_u_32 and -10 or -12)
	})
	local v625 = v624:FindFirstChild("Text")
	local v_u_626 = nil
	if p609.buy or p609.locked then
		v_u_626 = v_u_11.make("lock", v_u_10.TEXT_DIM, 16)
	elseif p609.fav then
		v_u_626 = v_u_10.text({
			["Text"] = "\226\152\133",
			["TextSize"] = 16,
			["FontFace"] = nil,
			["TextColor3"] = nil,
			["Size"] = nil,
			["FontFace"] = v_u_10.FONT_HEAVY,
			["TextColor3"] = v_u_10.GOLD,
			["Size"] = UDim2.fromOffset(16, 16)
		})
	end
	if v_u_626 then
		v_u_626.AnchorPoint = Vector2.new(1, 1)
		v_u_626.Position = UDim2.new(1, v_u_32 and -24 or -30, 1, v_u_32 and -10 or -13)
		v_u_626.Parent = v_u_612
	end
	local v_u_627 = false
	local v_u_628 = {
		v_u_616,
		v_u_617,
		v_u_623,
		v_u_614
	}
	local function v_u_639(p629) -- name: look
		-- upvalues: (ref) v_u_627, (ref) v_u_225, (ref) v_u_224, (ref) v_u_223, (copy) v_u_613, (ref) v_u_10, (ref) v_u_221, (copy) v_u_616, (copy) v_u_623, (copy) v_u_617, (copy) v_u_614, (ref) v_u_626, (ref) v_u_11, (copy) v_u_628
		local v630
		if v_u_627 then
			v630 = v_u_225
		elseif p629 then
			v630 = v_u_224
		else
			v630 = v_u_223
		end
		v_u_613.Color = ColorSequence.new(v630[1], v630[2])
		local v631
		if v_u_627 then
			v631 = v_u_10.INK
		else
			v631 = v_u_221
		end
		v_u_616.TextColor3 = v631
		v_u_623.TextColor3 = v631
		local v632 = v_u_617
		local v633
		if v_u_627 then
			v633 = Color3.fromRGB(70, 64, 10)
		else
			v633 = v_u_10.TEXT_DIM
		end
		v632.TextColor3 = v633
		local v634 = v_u_614
		local v635
		if v_u_627 then
			v635 = Color3.fromRGB(70, 64, 10)
		else
			v635 = v_u_10.TEXT_DIM
		end
		v634.TextColor3 = v635
		if v_u_626 and v_u_626:IsA("Frame") then
			local v636 = v_u_11.tint
			local v637 = v_u_626
			local v638
			if v_u_627 then
				v638 = v_u_10.INK
			else
				v638 = v_u_10.TEXT_DIM
			end
			v636(v637, v638)
		end
	end
	v_u_612.MouseEnter:Connect(function()
		-- upvalues: (copy) v_u_639
		v_u_639(true)
	end)
	v_u_612.MouseLeave:Connect(function()
		-- upvalues: (copy) v_u_639
		v_u_639(false)
	end)
	v_u_612.Activated:Connect(function()
		-- upvalues: (ref) v_u_314, (copy) p_u_608, (ref) v_u_298
		if v_u_314 ~= p_u_608.id then
			v_u_298(p_u_608.id)
		end
	end)
	v_u_316[p_u_608.id] = {
		["holder"] = v611,
		["frame"] = v611,
		["card"] = v_u_612,
		["status"] = v624,
		["statusText"] = v625,
		["locked"] = p609.locked,
		["category"] = p_u_608.category,
		["info"] = p_u_608,
		["entry"] = p609,
		["select"] = function(p640) -- name: select
			-- upvalues: (ref) v_u_627, (copy) v_u_639, (ref) v_u_5, (copy) v_u_612, (ref) v_u_10, (ref) v_u_32
			v_u_627 = p640
			v_u_639(false)
			v_u_5:Create(v_u_612, v_u_10.QUICK, {
				["Position"] = UDim2.fromOffset(p640 and (v_u_32 and 18 or 26) or 0, 0)
			}):Play()
		end
	}
	local v641 = v_u_313
	local v642 = p_u_608.id
	table.insert(v641, v642)
end
local function v_u_666(p644) -- name: fillPanel
	-- upvalues: (copy) v_u_236, (ref) v_u_314, (ref) v_u_316, (ref) v_u_313, (ref) v_u_296, (copy) v_u_8, (ref) v_u_412, (ref) v_u_295, (ref) v_u_411, (ref) v_u_410, (copy) v_u_351, (copy) v_u_299, (copy) v_u_643, (copy) v_u_338, (ref) v_u_315, (copy) v_u_10, (copy) v_u_196, (ref) v_u_298, (copy) v_u_309, (copy) v_u_520
	for _, v645 in v_u_236:GetChildren() do
		if not v645:IsA("GuiObject") then
			continue
		end
		v645:Destroy()
	end
	local v646 = v_u_314
	v_u_316 = {}
	v_u_313 = {}
	v_u_314 = nil
	v_u_296 = p644.max or v_u_8.MAX_SPAWNED
	v_u_412()
	local v647 = v_u_295
	local v648 = os.clock() + (p644.cooldown or 0)
	v_u_295 = math.max(v647, v648)
	local v649 = p644.autoDelete
	if type(v649) == "boolean" and not v_u_411 then
		v_u_410 = p644.autoDelete
		v_u_351(false)
	end
	local v650 = v_u_299
	v_u_299.max = 1
	v650.odo = 0
	for _, v651 in p644.vehicles or {} do
		local v652 = v651.top
		if type(v652) == "number" then
			local v653 = v_u_299
			local v654 = v_u_299.max
			local v655 = v651.top
			v653.max = math.max(v654, v655)
		end
		local v656 = v_u_299
		local v657 = v_u_299.odo
		local v658 = v651.odoKm
		local v659 = tonumber(v658) or 0
		v656.odo = math.max(v657, v659)
	end
	local v660 = {
		["All"] = 0
	}
	for _, v661 in p644.vehicles or {} do
		local v662 = v_u_8.vehicle(v661.id)
		if not v662 then
			continue
		end
		v_u_643(v662, v661, #v_u_313 + 1)
		v660.All = v660.All + 1
		v660[v662.category] = (v660[v662.category] or 0) + 1
	end
	v_u_338(v660)
	v_u_315 = v_u_10.text({
		["Name"] = "Empty",
		["Text"] = "No vehicles yet",
		["TextSize"] = 16,
		["TextColor3"] = nil,
		["Size"] = nil,
		["LayoutOrder"] = 999,
		["Visible"] = false,
		["Parent"] = nil,
		["TextColor3"] = v_u_10.TEXT_DIM,
		["Size"] = UDim2.new(1, 0, 0, 40),
		["Parent"] = v_u_236
	})
	local v663 = v_u_196()
	local v664 = nil
	for _, v665 in v_u_313 do
		if (v663[v665] or 0) <= 0 then
			continue
		end
		v664 = v665
	end
	if v664 then
		v646 = v664
	elseif not (v646 and (v_u_316[v646] and v646)) then
		v646 = v_u_313[1]
	end
	v_u_298(v646)
	v_u_309()
	v_u_520()
end
v_u_529 = function() -- name: openPanel
	-- upvalues: (ref) v_u_291, (copy) v_u_228, (copy) v_u_1, (copy) v_u_20, (copy) v_u_666, (copy) v_u_12
	v_u_291 = true
	v_u_228.setOpen(true)
	local v667 = v_u_1.invoke
	local v668 = v_u_20
	local v669, v670 = pcall(v667, v668, "List")
	if v_u_291 then
		if v669 and type(v670) == "table" then
			v_u_666(v670)
		else
			v_u_12.show("Couldn\'t load your vehicles", "error")
		end
	else
		return
	end
end
local v_u_671 = {}
local function v_u_679(p672) -- name: hideCharacter
	-- upvalues: (copy) v_u_18, (copy) v_u_671
	if p672 then
		local v673 = v_u_18.Character
		if v673 then
			for _, v674 in v673:GetDescendants() do
				if v674:IsA("BasePart") or v674:IsA("Decal") then
					local v675 = v_u_671
					local v676 = { v674, "LocalTransparencyModifier", v674.LocalTransparencyModifier }
					table.insert(v675, v676)
					v674.LocalTransparencyModifier = 1
				else
					if not (v674:IsA("BillboardGui") and v674.Enabled) then
						continue
					end
					local v677 = v_u_671
					table.insert(v677, { v674, "Enabled", true })
					v674:SetAttribute("GameHid", true)
					v674.Enabled = false
				end
			end
		end
	else
		for _, v678 in v_u_671 do
			if not v678[1].Parent then
				continue
			end
			v678[1][v678[2]] = v678[3]
			if v678[2] ~= "Enabled" then
				continue
			end
			v678[1]:SetAttribute("GameHid", nil)
		end
		table.clear(v_u_671)
		return
	end
end
v_u_228.changed.Event:Connect(function(p680)
	-- upvalues: (ref) v_u_291, (copy) v_u_679, (copy) v_u_32, (copy) v_u_46, (copy) v_u_18, (copy) v_u_226
	if not p680 then
		v_u_291 = false
	end
	v_u_679(false)
	if p680 then
		v_u_679(true)
	end
	if v_u_32 then
		local v681 = v_u_46
		local v682 = not p680
		if v682 then
			v682 = v_u_18:GetAttribute("PhoneOpen") ~= true
		end
		v681.Visible = v682
		if p680 then
			for _, v683 in v_u_226.staff do
				local v684 = v_u_18.PlayerGui:FindFirstChild(v683)
				if not (v684 and (v684:IsA("ScreenGui") and v684.Enabled)) then
					continue
				end
				v684.Enabled = false
				v_u_226.off[v684] = true
			end
			v_u_226.layout()
			return
		end
		for v685 in v_u_226.off do
			if not v685.Parent then
				continue
			end
			v685.Enabled = true
		end
		table.clear(v_u_226.off)
	end
end)
local function v686() -- name: togglePanel
	-- upvalues: (ref) v_u_291, (copy) v_u_228, (copy) v_u_15, (copy) v_u_14, (ref) v_u_529
	if v_u_291 then
		v_u_291 = false
		v_u_228.setOpen(false)
	else
		v_u_15.close()
		v_u_14.close()
		task.spawn(v_u_529)
	end
end
v170.hit.Activated:Connect(v686)
v169.hit.Activated:Connect(function() -- name: toggleWarp
	-- upvalues: (ref) v_u_291, (copy) v_u_228, (copy) v_u_15
	v_u_291 = false
	v_u_228.setOpen(false)
	v_u_15.toggle()
end)
v_u_13.launched.Event:Connect(function(p687)
	-- upvalues: (ref) v_u_291, (copy) v_u_228, (copy) v_u_15, (copy) v_u_14, (ref) v_u_529
	if p687 == "garage" then
		if not v_u_291 then
			if v_u_291 then
				v_u_291 = false
				v_u_228.setOpen(false)
			else
				v_u_15.close()
				v_u_14.close()
				task.spawn(v_u_529)
			end
		end
	else
		if p687 == "warp" then
			v_u_291 = false
			v_u_228.setOpen(false)
			v_u_15.open()
			return
		end
		if p687 == "store" then
			v_u_14.open()
		end
	end
end)
task.spawn(function()
	-- upvalues: (ref) v_u_291, (copy) v_u_520
	while true do
		repeat
			task.wait(0.25)
		until v_u_291
		v_u_520()
	end
end)
v_u_18:GetAttributeChangedSignal("SpawnedIds"):Connect(function()
	-- upvalues: (copy) v_u_172, (copy) v_u_18, (copy) v_u_138, (copy) v_u_139, (ref) v_u_291, (copy) v_u_520
	local v688 = v_u_172.gradient
	local v689
	if (v_u_18:GetAttribute("VehicleCount") or 0) > 0 and true or v_u_18:GetAttribute("ActiveVehicle") ~= nil then
		v689 = v_u_138.Trash
	else
		v689 = v_u_139
	end
	v688.Color = ColorSequence.new(v689[1], v689[2])
	if v_u_291 then
		v_u_520()
	end
end)
v6.InputBegan:Connect(function(p690, p691)
	-- upvalues: (copy) v_u_10, (copy) v_u_18, (ref) v_u_291, (copy) v_u_228, (copy) v_u_15, (copy) v_u_14, (ref) v_u_529, (copy) v_u_13, (ref) v_u_192, (copy) v_u_12, (ref) v_u_191, (copy) v_u_175
	if not (p691 or v_u_10.menuOpen()) then
		local v692 = p690.KeyCode
		if v692 == Enum.KeyCode.G then
			local v693 = v_u_18.Character
			if v693 then
				v693 = v693:FindFirstChildOfClass("Humanoid")
			end
			local v694
			if v693 == nil then
				v694 = false
			else
				v694 = v693.SeatPart ~= nil
			end
			if not v694 then
				if v_u_291 then
					v_u_291 = false
					v_u_228.setOpen(false)
				else
					v_u_15.close()
					v_u_14.close()
					task.spawn(v_u_529)
				end
			end
		else
			if v692 == Enum.KeyCode.N then
				v_u_291 = false
				v_u_228.setOpen(false)
				v_u_15.toggle()
				return
			end
			if v692 == Enum.KeyCode.B then
				v_u_291 = false
				v_u_228.setOpen(false)
				v_u_14.toggle()
				return
			end
			if v692 == Enum.KeyCode.F then
				v_u_13.toggle()
				return
			end
			if v692 == Enum.KeyCode.J then
				if v_u_192 then
					return
				elseif (v_u_18:GetAttribute("VehicleCount") or 0) > 0 and true or v_u_18:GetAttribute("ActiveVehicle") ~= nil then
					v_u_191 = os.clock()
				else
					v_u_12.show("You have no vehicle out", "info")
				end
			end
			if v692 == Enum.KeyCode.K then
				local v695 = v_u_18.Character
				if v695 then
					v695 = v695:FindFirstChildOfClass("Humanoid")
				end
				local v696
				if v695 == nil then
					v696 = false
				else
					v696 = v695.SeatPart ~= nil
				end
				if not v696 then
					v_u_175.toggle()
				end
			end
		end
	end
end)
v6.InputEnded:Connect(function(p697)
	-- upvalues: (ref) v_u_191, (copy) v_u_190
	if p697.KeyCode == Enum.KeyCode.J then
		v_u_191 = nil
		v_u_190(0)
	end
end)
if v_u_32 then
	local v_u_698 = nil
	local v_u_699 = false
	local function v702() -- name: updateVisible
		-- upvalues: (copy) v_u_46, (ref) v_u_699, (copy) v_u_18
		local v700 = v_u_46
		local v701 = not v_u_699
		if v701 then
			v701 = v_u_18:GetAttribute("PhoneOpen") ~= true
		end
		v700.Visible = v701
	end
	v_u_18:GetAttributeChangedSignal("PhoneOpen"):Connect(v702)
	local function v712(p703) -- name: onCharacter
		-- upvalues: (ref) v_u_698, (ref) v_u_699, (copy) v_u_46, (copy) v_u_18, (ref) v_u_291, (copy) v_u_228, (copy) v_u_15, (ref) v_u_191, (copy) v_u_190
		if v_u_698 then
			v_u_698:Disconnect()
		end
		local v_u_704 = p703:WaitForChild("Humanoid")
		v_u_698 = v_u_704:GetPropertyChangedSignal("SeatPart"):Connect(function()
			-- upvalues: (copy) v_u_704, (ref) v_u_699, (ref) v_u_46, (ref) v_u_18, (ref) v_u_291, (ref) v_u_228, (ref) v_u_15, (ref) v_u_191, (ref) v_u_190
			local v705 = v_u_704
			local v706
			if v705.SeatPart == nil then
				v706 = false
			else
				v706 = v705.SeatPart:IsA("VehicleSeat")
			end
			v_u_699 = v706
			local v707 = v_u_46
			local v708 = not v_u_699
			if v708 then
				v708 = v_u_18:GetAttribute("PhoneOpen") ~= true
			end
			v707.Visible = v708
			if v706 then
				v_u_291 = false
				v_u_228.setOpen(false)
				v_u_15.close()
				v_u_191 = nil
				v_u_190(0)
			end
		end)
		local v709
		if v_u_704.SeatPart == nil then
			v709 = false
		else
			v709 = v_u_704.SeatPart:IsA("VehicleSeat")
		end
		v_u_699 = v709
		local v710 = v_u_46
		local v711 = not v_u_699
		if v711 then
			v711 = v_u_18:GetAttribute("PhoneOpen") ~= true
		end
		v710.Visible = v711
		if v709 then
			v_u_291 = false
			v_u_228.setOpen(false)
			v_u_15.close()
			v_u_191 = nil
			v_u_190(0)
		end
	end
	v_u_18.CharacterAdded:Connect(v712)
	if v_u_18.Character then
		task.spawn(v712, v_u_18.Character)
	end
end
v21.OnClientEvent:Connect(function(p713, p714)
	-- upvalues: (copy) v_u_12
	if type(p713) == "string" then
		v_u_12.show(p713, p714)
	end
end)