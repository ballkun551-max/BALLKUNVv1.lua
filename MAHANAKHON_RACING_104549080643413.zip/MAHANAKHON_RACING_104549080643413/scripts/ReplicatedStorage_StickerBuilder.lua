-- Path: ReplicatedStorage/StickerBuilder
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = require(script.Parent:WaitForChild("StickerCatalog"))
local v_u_2 = game:GetService("HttpService")
local v_u_168 = {
	["ATTR"] = "Stickers",
	["MAX"] = {
		["PCX160"] = 20,
		["GTACar"] = 30
	},
	["MAX_TILES"] = 120,
	["MIN_W"] = 0.2,
	["MAX_W"] = 4,
	["LIFT"] = 0.012,
	["LAYER_LIFT"] = 0.003,
	["THICK"] = 0.02,
	["MAX_OUT"] = 5,
	["MIN_OUT"] = -5,
	["out"] = function(p3) -- name: out
		-- upvalues: (copy) v_u_168
		if typeof(p3) ~= "number" or p3 ~= p3 then
			return nil
		end
		local v4 = v_u_168.MIN_OUT
		local v5 = v_u_168.MAX_OUT
		local v6 = math.clamp(p3, v4, v5)
		if math.abs(v6) < 0.001 then
			return nil
		end
		local v7 = v6 * 1000
		return math.round(v7) / 1000
	end,
	["MAX_TILT"] = 80,
	["tilt"] = function(p8) -- name: tilt
		-- upvalues: (copy) v_u_168
		if typeof(p8) == "number" and p8 == p8 then
			local v9 = -v_u_168.MAX_TILT
			local v10 = v_u_168.MAX_TILT
			local v11 = math.clamp(p8, v9, v10) * 10
			local v12 = math.round(v11) / 10
			if math.abs(v12) >= 0.05 then
				return v12
			else
				return nil
			end
		else
			return nil
		end
	end,
	["tiltFrame"] = function(p13, p14, p15, p16) -- name: tiltFrame
		local v17 = p16.a or 0
		local v18 = p16.b or 0
		if v17 == 0 and v18 == 0 then
			return p13
		end
		local v19 = math.rad(v17)
		local v20 = math.rad(v18)
		local v21 = p14 / 2
		local v22 = math.sin(v19)
		local v23 = v21 * math.abs(v22) * math.cos(v20)
		local v24 = p15 / 2
		local v25 = math.sin(v20)
		local v26 = v23 + v24 * math.abs(v25)
		return (p13 + p13.LookVector * v26) * CFrame.Angles(v20, v19, 0)
	end,
	["COLORS"] = {
		"ffffff",
		"1a1a1a",
		"e53935",
		"fb8c00",
		"fdd835",
		"43a047",
		"1e88e5",
		"8e24aa",
		"ec407a",
		"00acc1"
	},
	["maxFor"] = function(p27) -- name: maxFor
		-- upvalues: (copy) v_u_168
		return v_u_168.MAX[p27:GetAttribute("VehicleTag")] or 20
	end,
	["panels"] = function(p28) -- name: panels
		local v29 = {}
		local v30 = {}
		for _, v31 in p28:GetDescendants() do
			if not v31:IsA("BasePart") then
				continue
			end
			local v32 = v31:GetAttribute("Panel")
			if type(v32) ~= "string" then
				continue
			end
			v29[v32] = v31
			table.insert(v30, v31)
		end
		return v29, v30
	end,
	["decode"] = function(p33) -- name: decode
		-- upvalues: (copy) v_u_2, (copy) v_u_168
		local v34 = {}
		if type(p33) ~= "string" or p33 == "" then
			return v34
		end
		local v35 = v_u_2.JSONDecode
		local v36 = v_u_2
		local v37, v38 = pcall(v35, v36, p33)
		if not v37 or type(v38) ~= "table" then
			return v34
		end
		for _, v39 in v38 do
			if #v34 >= 60 then
				break
			end
			if type(v39) ~= "table" then
				continue
			end
			local v40 = v39.s
			if type(v40) ~= "string" or #v39.s > 40 then
				continue
			end
			local v41 = v39.p
			if type(v41) ~= "string" or #v39.p > 100 then
				continue
			end
			local v42 = v39.o
			local v43
			if type(v42) == "table" then
				local v44 = v42[1]
				local v45
				if typeof(v44) == "number" and v44 == v44 then
					v45 = math.abs(v44) < 1000000
				else
					v45 = false
				end
				if v45 then
					local v46 = v42[2]
					local v47
					if typeof(v46) == "number" and v46 == v46 then
						v47 = math.abs(v46) < 1000000
					else
						v47 = false
					end
					if v47 then
						local v48 = v42[3]
						local v49
						if typeof(v48) == "number" and v48 == v48 then
							v49 = math.abs(v48) < 1000000
						else
							v49 = false
						end
						if v49 then
							local v50 = v42[1]
							local v51 = v42[2]
							local v52 = v42[3]
							v43 = Vector3.new(v50, v51, v52)
						else
							v43 = nil
						end
					else
						v43 = nil
					end
				else
					v43 = nil
				end
			else
				v43 = nil
			end
			local v53 = v39.n
			local v54
			if type(v53) == "table" then
				local v55 = v53[1]
				local v56
				if typeof(v55) == "number" and v55 == v55 then
					v56 = math.abs(v55) < 1000000
				else
					v56 = false
				end
				if v56 then
					local v57 = v53[2]
					local v58
					if typeof(v57) == "number" and v57 == v57 then
						v58 = math.abs(v57) < 1000000
					else
						v58 = false
					end
					if v58 then
						local v59 = v53[3]
						local v60
						if typeof(v59) == "number" and v59 == v59 then
							v60 = math.abs(v59) < 1000000
						else
							v60 = false
						end
						if v60 then
							local v61 = v53[1]
							local v62 = v53[2]
							local v63 = v53[3]
							v54 = Vector3.new(v61, v62, v63)
						else
							v54 = nil
						end
					else
						v54 = nil
					end
				else
					v54 = nil
				end
			else
				v54 = nil
			end
			local v64 = v39.u
			local v65
			if type(v64) == "table" then
				local v66 = v64[1]
				local v67
				if typeof(v66) == "number" and v66 == v66 then
					v67 = math.abs(v66) < 1000000
				else
					v67 = false
				end
				if v67 then
					local v68 = v64[2]
					local v69
					if typeof(v68) == "number" and v68 == v68 then
						v69 = math.abs(v68) < 1000000
					else
						v69 = false
					end
					if v69 then
						local v70 = v64[3]
						local v71
						if typeof(v70) == "number" and v70 == v70 then
							v71 = math.abs(v70) < 1000000
						else
							v71 = false
						end
						if v71 then
							local v72 = v64[1]
							local v73 = v64[2]
							local v74 = v64[3]
							v65 = Vector3.new(v72, v73, v74)
						else
							v65 = nil
						end
					else
						v65 = nil
					end
				else
					v65 = nil
				end
			else
				v65 = nil
			end
			local v75 = v39.t
			local v76 = tonumber(v75) or 1
			if not (v43 and (v54 and v65)) then
				continue
			end
			local v77 = v39.w
			local v78
			if typeof(v77) == "number" and v77 == v77 then
				v78 = math.abs(v77) < 1000000
			else
				v78 = false
			end
			if not v78 or v76 ~= 1 and (v76 ~= 2 and v76 ~= 3) or (v54.Magnitude <= 0.5 or v65.Magnitude <= 0.5) then
				continue
			end
			local v79 = v39.c
			local v80
			if type(v79) == "string" and v39.c:match("^%x%x%x%x%x%x$") then
				v80 = v39.c:lower()
			else
				v80 = nil
			end
			local v81 = v39.d
			local v82
			if typeof(v81) == "number" and v81 == v81 then
				v82 = math.abs(v81) < 1000000
			else
				v82 = false
			end
			local v83
			if v82 then
				v83 = v_u_168.out(v39.d)
			else
				v83 = nil
			end
			local v84 = v39.a
			local v85
			if typeof(v84) == "number" and v84 == v84 then
				v85 = math.abs(v84) < 1000000
			else
				v85 = false
			end
			local v86
			if v85 then
				v86 = v_u_168.tilt(v39.a)
			else
				v86 = nil
			end
			local v87 = v39.b
			local v88
			if typeof(v87) == "number" and v87 == v87 then
				v88 = math.abs(v87) < 1000000
			else
				v88 = false
			end
			local v89
			if v88 then
				v89 = v_u_168.tilt(v39.b)
			else
				v89 = nil
			end
			local v90 = {
				["s"] = v39.s,
				["p"] = v39.p,
				["o"] = v43,
				["n"] = v54.Unit,
				["u"] = v65.Unit,
				["w"] = v39.w,
				["c"] = v80,
				["t"] = v76,
				["d"] = v83,
				["a"] = v86,
				["b"] = v89
			}
			table.insert(v34, v90)
		end
		return v34
	end,
	["encode"] = function(p91) -- name: encode
		-- upvalues: (copy) v_u_168, (copy) v_u_2
		local v92 = {}
		for _, v93 in p91 do
			local v94 = v_u_168.out(v93.d)
			local v95 = {
				["s"] = v93.s,
				["p"] = v93.p
			}
			local v96 = v93.o
			local v97 = {}
			local v98 = v96.X * 1000
			local v99 = math.round(v98) / 1000
			local v100 = v96.Y * 1000
			local v101 = math.round(v100) / 1000
			local v102 = v96.Z * 1000
			__set_list(v97, 1, {v99, v101, math.round(v102) / 1000})
			v95.o = v97
			local v103 = v93.n
			local v104 = {}
			local v105 = v103.X * 1000
			local v106 = math.round(v105) / 1000
			local v107 = v103.Y * 1000
			local v108 = math.round(v107) / 1000
			local v109 = v103.Z * 1000
			__set_list(v104, 1, {v106, v108, math.round(v109) / 1000})
			v95.n = v104
			local v110 = v93.u
			local v111 = {}
			local v112 = v110.X * 1000
			local v113 = math.round(v112) / 1000
			local v114 = v110.Y * 1000
			local v115 = math.round(v114) / 1000
			local v116 = v110.Z * 1000
			__set_list(v111, 1, {v113, v115, math.round(v116) / 1000})
			v95.u = v111
			local v117 = v93.w * 1000
			v95.w = math.round(v117) / 1000
			v95.c = v93.c
			v95.t = v93.t
			v95.d = v94
			v95.a = v_u_168.tilt(v93.a)
			v95.b = v_u_168.tilt(v93.b)
			table.insert(v92, v95)
		end
		return v_u_2:JSONEncode(v92)
	end,
	["read"] = function(p118) -- name: read
		-- upvalues: (copy) v_u_168
		return v_u_168.decode(p118:GetAttribute(v_u_168.ATTR))
	end,
	["tiles"] = function(p119) -- name: tiles
		local v120 = 0
		for _, v121 in p119 do
			v120 = v120 + v121.t * v121.t
		end
		return v120
	end,
	["check"] = function(p122, p123, p124) -- name: check
		-- upvalues: (copy) v_u_1, (copy) v_u_168
		local v125 = v_u_1.get(p122.s)
		if not v125 then
			return false, "\224\185\132\224\184\161\224\185\136\224\184\161\224\184\181\224\184\165\224\184\178\224\184\162\224\184\153\224\184\181\224\185\137"
		end
		local v126 = (p124 or v_u_168.panels(p123))[p122.p]
		if not v126 then
			return false, "\224\185\129\224\184\155\224\184\176\224\184\149\224\184\163\224\184\135\224\184\153\224\184\181\224\185\137\224\185\132\224\184\161\224\185\136\224\185\132\224\184\148\224\185\137"
		end
		local v127 = v126.Size / 2 + Vector3.new(0.6, 0.6, 0.6)
		local v128 = p122.o.X
		if math.abs(v128) <= v127.X then
			local v129 = p122.o.Y
			if math.abs(v129) <= v127.Y then
				local v130 = p122.o.Z
				if math.abs(v130) <= v127.Z then
					local v131 = p122.n:Dot(p122.u)
					if math.abs(v131) > 0.2 then
						return false, "\224\184\151\224\184\180\224\184\168\224\185\132\224\184\161\224\185\136\224\184\150\224\184\185\224\184\129\224\184\149\224\185\137\224\184\173\224\184\135"
					end
					local v132 = v_u_168.MAX_W
					local v133 = v125.maxSize or v_u_168.MAX_W
					local v134 = math.min(v132, v133)
					if p122.w < v_u_168.MIN_W - 1e-6 or p122.w > v134 + 1e-6 then
						return false, ("\224\184\130\224\184\153\224\184\178\224\184\148\224\184\149\224\185\137\224\184\173\224\184\135\224\184\173\224\184\162\224\184\185\224\185\136\224\184\163\224\184\176\224\184\171\224\184\167\224\185\136\224\184\178\224\184\135 %.1f \224\184\150\224\184\182\224\184\135 %.1f"):format(v_u_168.MIN_W, v134)
					end
					if p122.d ~= nil then
						local v135 = p122.d
						if type(v135) ~= "number" or (p122.d < v_u_168.MIN_OUT - 1e-6 or p122.d > v_u_168.MAX_OUT + 1e-6) then
							return false, ("\224\184\148\224\184\182\224\184\135\224\185\128\224\184\130\224\185\137\224\184\178-\224\184\173\224\184\173\224\184\129\224\185\132\224\184\148\224\185\137\224\184\163\224\184\176\224\184\171\224\184\167\224\185\136\224\184\178\224\184\135 %.0f \224\184\150\224\184\182\224\184\135 %.0f"):format(v_u_168.MIN_OUT, v_u_168.MAX_OUT)
						end
					end
					for _, v136 in { p122.a, p122.b } do
						if v136 == nil or type(v136) == "number" and math.abs(v136) <= v_u_168.MAX_TILT + 1e-6 then
							continue
						end
						return false, ("\224\185\128\224\184\137\224\184\181\224\184\162\224\184\135\224\185\132\224\184\148\224\185\137\224\185\132\224\184\161\224\185\136\224\185\128\224\184\129\224\184\180\224\184\153 %d\194\176"):format(v_u_168.MAX_TILT)
					end
					if p122.c and not v125.tint then
						p122.c = nil
					end
					return true
				end
			end
		end
		return false, "\224\184\171\224\184\165\224\184\184\224\184\148\224\184\130\224\184\173\224\184\154\224\184\138\224\184\180\224\185\137\224\184\153"
	end,
	["frame"] = function(p137, p138) -- name: frame
		-- upvalues: (copy) v_u_1
		local v139 = v_u_1.get(p137.s)
		local v140 = p138.CFrame
		local v141 = v140:VectorToWorldSpace(p137.n).Unit
		local v142 = v140:VectorToWorldSpace(p137.u)
		local v143 = v142 - v141 * v142:Dot(v141)
		if v143.Magnitude < 0.001 then
			local v144 = v141.Y
			local v145 = math.abs(v144) < 0.9 and Vector3.new(0, 1, 0) or Vector3.new(1, 0, 0)
			v143 = v145 - v141 * v145:Dot(v141)
		end
		local v146 = v143.Unit
		return CFrame.fromMatrix(v140:PointToWorldSpace(p137.o), v146:Cross(-v141), v146, -v141), p137.w, p137.w / (v139 and v139.aspect or 1)
	end,
	["fromHit"] = function(p147, p148, p149, p150, p151, p152, p153) -- name: fromHit
		local v154 = p148.CFrame
		local v155 = p151 - p150 * p151:Dot(p150)
		if v155.Magnitude < 0.001 then
			local v156 = p150.Y
			local v157 = math.abs(v156) < 0.9 and Vector3.new(0, 1, 0) or Vector3.new(1, 0, 0)
			v155 = v157 - p150 * v157:Dot(p150)
		end
		return {
			["s"] = nil,
			["p"] = nil,
			["o"] = nil,
			["n"] = nil,
			["u"] = nil,
			["w"] = nil,
			["c"] = nil,
			["t"] = 1,
			["s"] = p147,
			["p"] = p148:GetAttribute("Panel"),
			["o"] = v154:PointToObjectSpace(p149),
			["n"] = v154:VectorToObjectSpace(p150).Unit,
			["u"] = v154:VectorToObjectSpace(v155.Unit).Unit,
			["w"] = p152,
			["c"] = p153
		}
	end,
	["queryOn"] = function(p158) -- name: queryOn
		local v_u_159 = {}
		for _, v160 in p158 do
			if not v160.Parent or v160.CanQuery then
				continue
			end
			v160.CanQuery = true
			table.insert(v_u_159, v160)
		end
		return function()
			-- upvalues: (copy) v_u_159
			for _, v161 in v_u_159 do
				if not v161.Parent then
					continue
				end
				v161.CanQuery = false
			end
		end
	end,
	["withQuery"] = function(p162, p163, ...) -- name: withQuery
		-- upvalues: (copy) v_u_168
		local v164 = v_u_168.queryOn(p162)
		local v165, v166, v167 = pcall(p163, ...)
		v164()
		if not v165 then
			error(v166, 0)
		end
		return v166, v167
	end
}
local function v_u_189(p169, p170, p171, p172, p173) -- name: sampleGrid
	local v174 = p169.LookVector
	local v175 = math.max(p170, p171) * 0.6
	local v176 = math.max(0.6, v175)
	local v177 = {}
	for v178 = 0, p172 - 1 do
		for v179 = 0, p172 - 1 do
			local v180 = p172 == 1 and 0.5 or v179 / (p172 - 1)
			local v181 = p172 == 1 and 0.5 or v178 / (p172 - 1)
			local v182 = p170 / 2 - v180 * p170
			local v183 = p171 / 2 - v181 * p171
			local v184 = p169:PointToWorldSpace((Vector3.new(v182, v183, 0)))
			local v185 = v176 or 0.6
			local v186 = RaycastParams.new()
			v186.FilterType = Enum.RaycastFilterType.Include
			v186.FilterDescendantsInstances = p173
			local v187 = workspace:Raycast(v184 + v174 * v185, -v174 * (v185 * 2 + 0.4), v186)
			if v187 and v187.Normal:Dot(v174) > 0.2 then
				local v188 = {
					["pos"] = v187.Position,
					["d"] = (v187.Position - v184):Dot(v174),
					["normal"] = v187.Normal,
					["part"] = v187.Instance
				}
				table.insert(v177, v188)
			else
				table.insert(v177, false)
			end
		end
	end
	return v177
end
local function v_u_223(p190, p191, p192) -- name: settle
	-- upvalues: (copy) v_u_168, (copy) v_u_189
	local v193 = p191[p190.p]
	if not v193 then
		return p190
	end
	for _ = 1, 2 do
		local v194, v195, v196 = v_u_168.frame(p190, v193)
		local v197 = v194.LookVector
		local v198 = v_u_189(v194, v195 * 0.9, v196 * 0.9, 3, p192)
		local v199 = Vector3.new(0, 0, 0)
		local v200 = 0
		local v201 = 0
		for _, v202 in v198 do
			if not v202 then
				continue
			end
			v199 = v199 + v202.normal
			v200 = v200 + v202.d
			v201 = v201 + 1
		end
		if v201 < 3 or v199.Magnitude < 0.001 then
			break
		end
		local v203 = v199.Unit
		local v204 = v198[5]
		local v205
		if v204 then
			v205 = v204.pos
		else
			v205 = v194.Position + v197 * (v200 / v201)
		end
		if v204 then
			local v206 = v204.part:GetAttribute("Panel")
			if type(v206) == "string" and p191[v206] == v204.part then
				v193 = v204.part
				p190.p = v206
			end
		end
		local v207 = v193.CFrame
		p190.n = v207:VectorToObjectSpace(v203).Unit
		p190.o = v207:PointToObjectSpace(v205)
		local v208 = p190.u - p190.n * p190.u:Dot(p190.n)
		if v208.Magnitude <= 0.001 then
			break
		end
		p190.u = v208.Unit
	end
	local v209, v210, v211 = v_u_168.frame(p190, v193)
	local v212 = (1 / 0)
	local v213 = (-1 / 0)
	local v214 = 0
	for _, v215 in v_u_189(v209, v210, v211, 3, p192) do
		if not v215 then
			continue
		end
		local v216 = v215.d
		v212 = math.min(v212, v216)
		local v217 = v215.d
		v213 = math.max(v213, v217)
		v214 = v214 + 1
	end
	local v218 = v214 < 2 and 0 or v213 - v212
	local v219 = math.max(v210, v211)
	local v220 = v219 * 0.035
	local v221
	if v218 <= math.max(0.05, v220) then
		v221 = 1
	else
		local v222 = v219 * 0.09
		v221 = v218 <= math.max(0.14, v222) and 2 or 3
	end
	p190.t = v221
	return p190
end
function v_u_168.settle(p224, p225, p226) -- name: settle
	-- upvalues: (copy) v_u_168, (copy) v_u_223
	return v_u_168.withQuery(p226, v_u_223, p224, p225, p226)
end
function v_u_168.autoGrid(p227, p228, p229) -- name: autoGrid
	-- upvalues: (copy) v_u_168
	return v_u_168.settle(p227, p228, p229).t
end
local function v_u_249(p230, p231, p232, p233) -- name: mirror
	-- upvalues: (copy) v_u_168, (copy) v_u_223
	local v234 = p232[p231.p]
	local v235 = p230:FindFirstChild("DriverSeat", true) or p230:FindFirstChild("VehicleSeat", true)
	if not (v234 and v235) then
		return nil
	end
	local v236 = v_u_168.frame(p231, v234)
	local v237 = v235.CFrame.RightVector
	local v238 = v235.Position
	local v239 = v236.Position - 2 * (v236.Position - v238):Dot(v237) * v237
	local v240 = v236.LookVector
	local v241 = v240 - 2 * v240:Dot(v237) * v237
	local v242 = v236.UpVector
	local v243 = v242 - 2 * v242:Dot(v237) * v237
	local v244 = 1 or 0.6
	local v245 = RaycastParams.new()
	v245.FilterType = Enum.RaycastFilterType.Include
	v245.FilterDescendantsInstances = p233
	local v246 = workspace:Raycast(v239 + v241 * v244, -v241 * (v244 * 2 + 0.4), v245)
	if not (v246 and v246.Instance:GetAttribute("Panel")) then
		return nil
	end
	local v247 = v_u_168.fromHit(p231.s, v246.Instance, v246.Position, v246.Normal, v243, p231.w, p231.c)
	v247.d = p231.d
	local v248
	if p231.a then
		v248 = -p231.a
	else
		v248 = nil
	end
	v247.a = v248
	v247.b = p231.b
	return v_u_223(v247, p232, p233)
end
function v_u_168.mirror(p250, p251, p252, p253) -- name: mirror
	-- upvalues: (copy) v_u_168, (copy) v_u_249
	return v_u_168.withQuery(p253, v_u_249, p250, p251, p252, p253)
end
local function v_u_272(p254, p255, p256, p257, p258, p259, p260, p261, p262, p263, p264, p265) -- name: tilePart
	-- upvalues: (copy) v_u_168
	local v266 = Instance.new("Part")
	v266.Name = "StickerTile"
	local v267 = math.max(p256, 0.01)
	local v268 = math.max(p257, 0.01)
	local v269 = v_u_168.THICK
	v266.Size = Vector3.new(v267, v268, v269)
	v266.CFrame = p255
	v266.Transparency = 1
	v266.CanCollide = false
	v266.CanQuery = false
	v266.CanTouch = false
	v266.CastShadow = false
	v266.Massless = true
	v266.Anchored = p260.anchored == true
	local v270 = Instance.new("Texture")
	v270.Face = Enum.NormalId.Front
	v270.Texture = p258.image
	v270.StudsPerTileU = p261
	v270.StudsPerTileV = p262
	v270.OffsetStudsU = p263
	v270.OffsetStudsV = p264
	v270.Color3 = p259
	v270.Transparency = p260.ghost and 0.12 or 0
	v270.Parent = v266
	if not v266.Anchored and p265 then
		local v271 = Instance.new("WeldConstraint")
		v271.Part0 = v266
		v271.Part1 = p265
		v271.Parent = v266
	end
	v266.Parent = p254
	return v266
end
local function v_u_356(p273, p274, p275, p276, p277) -- name: buildOne
	-- upvalues: (copy) v_u_1, (copy) v_u_168, (copy) v_u_189, (copy) v_u_272
	local v278 = p277 or {}
	local v279 = v_u_1.get(p274.s)
	local v280 = v278.panels
	local v281 = v278.include
	if not (v280 and v281) then
		v280, v281 = v_u_168.panels(p273)
	end
	local v282 = v280[p274.p]
	if not (v279 and v282) then
		return nil
	end
	local v283, v284, v285 = v_u_168.frame(p274, v282)
	local v286 = v283.LookVector
	local v287 = p274.t
	local v288 = v_u_168.LIFT + v_u_168.LAYER_LIFT * (p275 - 1) + (p274.d or 0)
	local v289
	if v279.tint and p274.c then
		v289 = Color3.fromHex(p274.c)
	else
		v289 = Color3.new(1, 1, 1)
	end
	local v290 = Instance.new("Model")
	v290.Name = "S" .. p275
	local v291 = p274.a ~= nil and true or p274.b ~= nil
	if v287 <= 1 or v291 then
		local v292 = v_u_189(v283, v284, v285, 3, v281)
		local v293 = 0
		for _, v294 in v292 do
			if not v294 then
				continue
			end
			local v295 = v294.d
			v293 = math.max(v293, v295)
		end
		if v292[5] then
			v282 = v292[5].part
		end
		v_u_272(v290, v_u_168.tiltFrame(v283 + v286 * (v293 + v288), v284, v285, p274), v284, v285, v279, v289, v278, v284, v285, 0, 0, v282)
	else
		local v296 = v287 + 1
		local v297 = v_u_189(v283, v284, v285, v296, v281)
		local v298 = 0
		local v299 = 0
		for _, v300 in v297 do
			if not v300 then
				continue
			end
			v298 = v298 + v300.d
			v299 = v299 + 1
		end
		if v299 > 0 then
			local v301 = v298 / v299
			for v302 = 0, v287 - 1 do
				for v303 = 0, v287 - 1 do
					local v304 = v297[v302 * v296 + v303 + 1]
					local v305, v306, v307
					if v304 then
						v305 = v304.pos
						v306 = v304.normal
						local _ = v304.part
						v307 = true
					else
						local v308 = v284 / 2 - v303 / v287 * v284
						local v309 = v285 / 2 - v302 / v287 * v285
						v305 = v283:PointToWorldSpace((Vector3.new(v308, v309, 0))) + v286 * v301
						v306 = v286
						v307 = false
					end
					local v310 = v303 + 1
					local v311 = v297[v302 * v296 + v310 + 1]
					local v312, v313, v314
					if v311 then
						v312 = v311.pos
						v313 = v311.normal
						local _ = v311.part
						v314 = true
					else
						local v315 = v284 / 2 - v310 / v287 * v284
						local v316 = v285 / 2 - v302 / v287 * v285
						v312 = v283:PointToWorldSpace((Vector3.new(v315, v316, 0))) + v286 * v301
						v313 = v286
						v314 = false
					end
					local v317 = v302 + 1
					local v318 = v297[v317 * v296 + v303 + 1]
					local v319, v320, v321
					if v318 then
						v319 = v318.pos
						v320 = v318.normal
						local _ = v318.part
						v321 = true
					else
						local v322 = v284 / 2 - v303 / v287 * v284
						local v323 = v285 / 2 - v317 / v287 * v285
						v319 = v283:PointToWorldSpace((Vector3.new(v322, v323, 0))) + v286 * v301
						v320 = v286
						v321 = false
					end
					local v324 = v302 + 1
					local v325 = v303 + 1
					local v326 = v297[v324 * v296 + v325 + 1]
					local v327, v328, v329
					if v326 then
						v327 = v326.pos
						v328 = v326.normal
						local _ = v326.part
						v329 = true
					else
						local v330 = v284 / 2 - v325 / v287 * v284
						local v331 = v285 / 2 - v324 / v287 * v285
						v327 = v283:PointToWorldSpace((Vector3.new(v330, v331, 0))) + v286 * v301
						v328 = v286
						v329 = false
					end
					if not (v307 or (v314 or (v321 or v329))) then
						continue
					end
					local v332 = (v305 + v312 + v319 + v327) / 4
					local v333 = (v312 - v305 + (v327 - v319)) / 2
					local v334 = (v319 - v305 + (v327 - v312)) / 2
					local v335 = v333.Magnitude
					local v336 = v334.Magnitude
					local v337 = v306 + v313 + v320 + v328
					local v338
					if v337.Magnitude > 0.001 then
						v338 = v337.Unit
					else
						v338 = v286
					end
					if v338:Dot(v286) < 0.2 then
						v338 = v286
					end
					local v339 = -v334 - v338 * (-v334):Dot(v338)
					local v340
					if v339.Magnitude > 0.0001 then
						v340 = v339.Unit
					else
						v340 = v283.UpVector
					end
					if v335 <= 0.001 or v336 <= 0.001 then
						continue
					end
					local v341 = 0
					for _, v342 in {
						v305,
						v312,
						v319,
						v327
					} do
						local v343 = v342 - v332
						v341 = math.max(v341, v343:Dot(v338))
					end
					local v344 = 0.6
					local v345 = RaycastParams.new()
					v345.FilterType = Enum.RaycastFilterType.Include
					v345.FilterDescendantsInstances = v281
					local v346 = workspace:Raycast(v332 + v338 * v344, -v338 * (v344 * 2 + 0.4), v345)
					local v347
					if v346 == nil then
						v347 = false
					else
						v347 = v346.Normal:Dot(v338) > 0.2
					end
					if v347 then
						local v348 = v346.Position - v332
						v341 = math.max(v341, v348:Dot(v338))
					end
					local v349 = math.min(v335, v336) * 0.08
					local v350 = math.min(0.04, v349)
					local v351 = v303 <= 0 and 0 or v350
					local v352 = v303 >= v287 - 1 and 0 or v350
					local v353 = v302 <= 0 and 0 or v350
					local v354 = v302 >= v287 - 1 and 0 or v350
					local v355 = CFrame.fromMatrix(v332 + v338 * (v341 + v288), v340:Cross(-v338), v340, -v338)
					if not v347 then
						break
					end
					v_u_272(v290, v355 * CFrame.new((v351 - v352) / 2, (v353 - v354) / 2, 0), v335 + v351 + v352, v336 + v353 + v354, v279, v289, v278, v335 * v287, v336 * v287, v303 * v335 - v351, v302 * v336 - v353, v346.Instance)
				end
			end
		end
	end
	v290.Parent = p276
	return v290
end
function v_u_168.buildOne(p357, p358, p359, p360, p361) -- name: buildOne
	-- upvalues: (copy) v_u_168, (copy) v_u_356
	local v362 = p361 or {}
	if not (v362.panels and v362.include) then
		local v363, v364 = v_u_168.panels(p357)
		v362.panels = v363
		v362.include = v364
	end
	return v_u_168.withQuery(v362.include, v_u_356, p357, p358, p359, p360, v362)
end
function v_u_168.build(p_u_365, p_u_366, p_u_367, p368) -- name: build
	-- upvalues: (copy) v_u_168, (copy) v_u_356
	local v_u_369 = p368 or {}
	local v370, v371 = v_u_168.panels(p_u_365)
	v_u_369.panels = v370
	v_u_369.include = v371
	v_u_168.withQuery(v371, function()
		-- upvalues: (copy) p_u_366, (ref) v_u_356, (copy) p_u_365, (copy) p_u_367, (ref) v_u_369
		for v372, v373 in p_u_366 do
			v_u_356(p_u_365, v373, v372, p_u_367, v_u_369)
		end
	end)
end
return v_u_168