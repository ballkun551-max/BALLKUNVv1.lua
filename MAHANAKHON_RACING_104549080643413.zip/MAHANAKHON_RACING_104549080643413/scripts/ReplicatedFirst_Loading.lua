-- Path: ReplicatedFirst/Loading
-- Class: LocalScript  true/Enum.RunContext.Legacy
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = game:GetService("ContentProvider")
local v2 = game:GetService("Players")
local v3 = game:GetService("ReplicatedFirst")
local v4 = game:GetService("TweenService")
local v5 = script:WaitForChild("ObstacleAssets", 5)
local v_u_6 = not v5 and {} or v5:GetChildren()
v3:RemoveDefaultLoadingScreen()
local v_u_7 = v2.LocalPlayer
local v8 = Instance.new("ScreenGui")
v8.Name = "LoadingScreen"
v8.IgnoreGuiInset = true
v8.ScreenInsets = Enum.ScreenInsets.None
v8.DisplayOrder = 100
v8.ResetOnSpawn = false
v8.Parent = v_u_7:WaitForChild("PlayerGui")
local v9 = {
	["BackgroundColor3"] = nil,
	["BorderSizePixel"] = 0,
	["Size"] = nil,
	["Parent"] = nil,
	["BackgroundColor3"] = Color3.fromRGB(10, 11, 16),
	["Size"] = UDim2.fromScale(1, 1),
	["Parent"] = v8
}
local v10 = Instance.new("CanvasGroup")
local v11 = {
	"Press F to open your phone and take rider jobs for cash",
	"Press G to pick a vehicle and spawn it to ride",
	"Every vehicle can get new paint, RGB lights and plates",
	"Stop in the ring and slide in the app. Be on time for tips",
	"Laggy? Turn off shadows or bloom in Settings"
}
local function v19() -- name: highGraphics
	-- upvalues: (copy) v_u_7
	local function v12()
		-- upvalues: (ref) v_u_7
		return game:GetService("HttpService"):JSONDecode(v_u_7:GetAttribute("Settings") or "{}")
	end
	local v13, v14 = pcall(v12)
	if v13 and type(v14) == "table" then
		local v15 = v14.LowGfx
		if type(v15) == "boolean" then
			return not v14.LowGfx
		end
	end
	local v_u_16 = game:GetService("UserInputService")
	if not v_u_16.TouchEnabled then
		return true
	end
	if not (v_u_16.KeyboardEnabled and v_u_16.MouseEnabled) then
		return false
	end
	local v17, v18 = pcall(function()
		-- upvalues: (copy) v_u_16
		return v_u_16.PreferredInput == Enum.PreferredInput.Touch
	end)
	if v17 then
		v17 = v18 == true
	end
	return not v17
end
for v20, v21 in v9 do
	if v20 == "Parent" then
		continue
	end
	v10[v20] = v21
end
v10.Parent = v9.Parent
local v22 = {
	["Color"] = nil,
	["Rotation"] = 90,
	["Parent"] = nil,
	["Color"] = ColorSequence.new(Color3.fromRGB(40, 42, 58), Color3.fromRGB(10, 11, 16)),
	["Parent"] = v10
}
local v23 = Instance.new("UIGradient")
for v24, v25 in v22 do
	if v24 == "Parent" then
		continue
	end
	v23[v24] = v25
end
v23.Parent = v22.Parent
local v26 = {
	["BackgroundTransparency"] = 1,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["AnchorPoint"] = Vector2.new(0.5, 0.5),
	["Position"] = UDim2.fromScale(0.5, 0.5),
	["Size"] = UDim2.fromOffset(600, 400),
	["Parent"] = v10
}
local v27 = Instance.new("Frame")
for v28, v29 in v26 do
	if v28 == "Parent" then
		continue
	end
	v27[v28] = v29
end
v27.Parent = v26.Parent
local v30 = {
	["Parent"] = v27
}
local v_u_31 = Instance.new("UIScale")
for v32, v33 in v30 do
	if v32 == "Parent" then
		continue
	end
	v_u_31[v32] = v33
end
v_u_31.Parent = v30.Parent
local function v39() -- name: fit
	-- upvalues: (copy) v_u_31
	local v34 = workspace.CurrentCamera
	if v34 then
		local v35 = v_u_31
		local v36 = v34.ViewportSize.X / 700
		local v37 = v34.ViewportSize.Y / 460
		local v38 = math.min(v36, v37)
		v35.Scale = math.clamp(v38, 0.5, 1.4)
	end
end
local v40 = workspace.CurrentCamera
if v40 then
	local v41 = v40.ViewportSize.X / 700
	local v42 = v40.ViewportSize.Y / 460
	local v43 = math.min(v41, v42)
	v_u_31.Scale = math.clamp(v43, 0.5, 1.4)
end
workspace:GetPropertyChangedSignal("CurrentCamera"):Connect(v39)
if workspace.CurrentCamera then
	workspace.CurrentCamera:GetPropertyChangedSignal("ViewportSize"):Connect(v39)
end
local v44 = {
	["BackgroundTransparency"] = 1,
	["Image"] = "rbxassetid://93559157614977",
	["ScaleType"] = nil,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["ScaleType"] = Enum.ScaleType.Fit,
	["AnchorPoint"] = Vector2.new(0.5, 0),
	["Position"] = UDim2.fromOffset(300, -110),
	["Size"] = UDim2.fromOffset(900, 470),
	["Parent"] = v27
}
local v_u_45 = Instance.new("ImageLabel")
for v46, v47 in v44 do
	if v46 == "Parent" then
		continue
	end
	v_u_45[v46] = v47
end
v_u_45.Parent = v44.Parent
local v48 = {
	["Scale"] = 0.94,
	["Parent"] = nil,
	["Parent"] = v_u_45
}
local v49 = Instance.new("UIScale")
for v50, v51 in v48 do
	if v50 == "Parent" then
		continue
	end
	v49[v50] = v51
end
v49.Parent = v48.Parent
v4:Create(v49, TweenInfo.new(1.6, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true), {
	["Scale"] = 1
}):Play()
local v52 = {
	["BackgroundColor3"] = nil,
	["BackgroundTransparency"] = 0.85,
	["BorderSizePixel"] = 0,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["BackgroundColor3"] = Color3.new(1, 1, 1),
	["AnchorPoint"] = Vector2.new(0.5, 0),
	["Position"] = UDim2.fromOffset(300, 296),
	["Size"] = UDim2.fromOffset(380, 6),
	["Parent"] = v27
}
local v53 = Instance.new("Frame")
for v54, v55 in v52 do
	if v54 == "Parent" then
		continue
	end
	v53[v54] = v55
end
v53.Parent = v52.Parent
local v56 = {
	["CornerRadius"] = UDim.new(0, 3),
	["Parent"] = v53
}
local v57 = Instance.new("UICorner")
for v58, v59 in v56 do
	if v58 == "Parent" then
		continue
	end
	v57[v58] = v59
end
v57.Parent = v56.Parent
local v60 = {
	["BackgroundColor3"] = nil,
	["BorderSizePixel"] = 0,
	["Size"] = nil,
	["Parent"] = nil,
	["BackgroundColor3"] = Color3.new(1, 1, 1),
	["Size"] = UDim2.fromScale(0, 1),
	["Parent"] = v53
}
local v61 = Instance.new("Frame")
for v62, v63 in v60 do
	if v62 == "Parent" then
		continue
	end
	v61[v62] = v63
end
v61.Parent = v60.Parent
local v64 = {
	["CornerRadius"] = UDim.new(0, 3),
	["Parent"] = v61
}
local v65 = Instance.new("UICorner")
for v66, v67 in v64 do
	if v66 == "Parent" then
		continue
	end
	v65[v66] = v67
end
v65.Parent = v64.Parent
local v68 = {
	["Color"] = ColorSequence.new(Color3.fromRGB(255, 196, 40), Color3.fromRGB(255, 80, 60)),
	["Parent"] = v61
}
local v69 = Instance.new("UIGradient")
for v70, v71 in v68 do
	if v70 == "Parent" then
		continue
	end
	v69[v70] = v71
end
v69.Parent = v68.Parent
local v72 = {
	["BackgroundTransparency"] = 1,
	["Font"] = nil,
	["TextSize"] = 15,
	["TextColor3"] = nil,
	["Text"] = "Loading the map  0%",
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["Font"] = Enum.Font.GothamBold,
	["TextColor3"] = Color3.new(1, 1, 1),
	["AnchorPoint"] = Vector2.new(0.5, 0),
	["Position"] = UDim2.fromOffset(300, 312),
	["Size"] = UDim2.fromOffset(380, 20),
	["Parent"] = v27
}
local v73 = Instance.new("TextLabel")
for v74, v75 in v72 do
	if v74 == "Parent" then
		continue
	end
	v73[v74] = v75
end
v73.Parent = v72.Parent
local v76 = {
	["BackgroundTransparency"] = 1,
	["Font"] = nil,
	["TextSize"] = 14,
	["TextColor3"] = nil,
	["Text"] = nil,
	["TextWrapped"] = true,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["Font"] = Enum.Font.Gotham,
	["TextColor3"] = Color3.fromRGB(190, 194, 206),
	["Text"] = v11[math.random(#v11)],
	["AnchorPoint"] = Vector2.new(0.5, 0),
	["Position"] = UDim2.fromOffset(300, 346),
	["Size"] = UDim2.fromOffset(520, 40),
	["Parent"] = v27
}
local v77 = Instance.new("TextLabel")
for v78, v79 in v76 do
	if v78 == "Parent" then
		continue
	end
	v77[v78] = v79
end
v77.Parent = v76.Parent
task.spawn(function()
	-- upvalues: (copy) v_u_1, (copy) v_u_45
	local function v84()
		-- upvalues: (ref) v_u_1, (ref) v_u_45
		local v80 = v_u_1
		local v81 = {}
		local v82 = v_u_45
		local v83 = Instance.new("ImageLabel")
		v83.Image = "rbxassetid://127697862570039"
		__set_list(v81, 1, {v82, v83})
		v80:PreloadAsync(v81)
	end
	pcall(v84)
end)
local v_u_85 = os.clock()
local v_u_86 = false
task.spawn(function()
	-- upvalues: (copy) v_u_1, (copy) v_u_6, (ref) v_u_86, (copy) v_u_85
	local function v87()
		-- upvalues: (ref) v_u_1, (ref) v_u_6
		v_u_1:PreloadAsync(v_u_6)
	end
	pcall(v87)
	v_u_86 = true
	local v88 = script
	local v89 = (os.clock() - v_u_85) * 10
	v88:SetAttribute("ObstaclesSeconds", math.floor(v89) / 10)
end)
local v90 = v_u_1.RequestQueueSize
local v91 = math.max(1, v90)
local v92 = v_u_85 + 4
local v93 = v_u_86
local v94 = nil
local v95 = 0
while true do
	local v96 = v_u_1.RequestQueueSize
	v91 = math.max(v91, v96)
	local v97 = game:IsLoaded()
	if v97 and not v94 then
		v94 = os.clock()
	end
	local v98 = (v97 and 0.5 or 0.15) + 0.5 * (1 - v96 / v91)
	local v99 = os.clock() - v_u_85
	local v100 = v99 / 2.5
	v95 = v95 + (math.min(v98, v100) - v95) * 0.15
	v61.Size = UDim2.fromScale(math.clamp(v95, 0, 1), 1)
	local v101 = math.clamp(v95, 0, 1) * 100
	v73.Text = ("Loading the map  %d%%"):format((math.floor(v101)))
	if v92 < os.clock() then
		v92 = os.clock() + 4
		v77.Text = v11[math.random(#v11)]
	end
	local v102 = v97 and (v96 == 0 and v93)
	if v102 then
		if v99 >= 2.5 then
			v102 = v95 > 0.97
		else
			v102 = false
		end
	end
	if v102 or v94 and (v93 and (v99 >= 2.5 and os.clock() - v94 > 4)) or v99 > 12 then
		break
	end
	task.wait()
end
local v103 = os.clock()
while os.clock() - v103 < 15 do
	local v104 = v_u_7:FindFirstChild("PlayerGui")
	if v104 then
		v104 = v104:FindFirstChild("TopBar")
	end
	if v104 and v104:GetAttribute("Placed") == true then
		break
	end
	v73.Text = "Getting the screen ready"
	v95 = v95 + (0.99 - v95) * 0.1
	v61.Size = UDim2.fromScale(math.clamp(v95, 0, 1), 1)
	task.wait()
end
local v105 = script
local v106 = (os.clock() - v103) * 10
v105:SetAttribute("UiSeconds", math.floor(v106) / 10)
v61.Size = UDim2.fromScale(1, 1)
v73.Text = "Ready!"
local v107 = script
local v108 = (os.clock() - v_u_85) * 10
v107:SetAttribute("TookSeconds", math.floor(v108) / 10)
script:SetAttribute("Mode", v19() and "High" or "Low")
task.wait(0.3)
script:SetAttribute("Done", true)
local v109 = v4:Create(v10, TweenInfo.new(0.6, Enum.EasingStyle.Quad), {
	["GroupTransparency"] = 1
})
v109:Play()
v109.Completed:Wait()
v8:Destroy()