-- Path: Players/ygggggg55551/PlayerScripts/TouchPedals
-- Class: LocalScript  true/Enum.RunContext.Legacy
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = require(game:GetService("ReplicatedStorage"):WaitForChild("UiOwn")).Instance
local v2 = game:GetService("Players")
local v3 = game:GetService("ReplicatedStorage")
local v4 = game:GetService("RunService")
local v_u_5 = game:GetService("UserInputService")
local v6 = require(v3:WaitForChild("GameUI"):WaitForChild("Theme"))
local v_u_7 = require(v3:WaitForChild("GameUI"):WaitForChild("ControlLayout"))
if v6.isTouch() then
	local v_u_8 = v2.LocalPlayer
	local v9 = v6.DRIVE_PAD_H
	local v_u_10 = Color3.fromRGB(205, 207, 210)
	local v_u_11 = Color3.fromRGB(62, 64, 68)
	local v_u_12 = v_u_1.new("ScreenGui")
	v_u_12.Name = "TouchPedals"
	v_u_12.ResetOnSpawn = false
	v_u_12.DisplayOrder = 4
	v_u_12.IgnoreGuiInset = true
	v_u_12.Enabled = false
	v_u_12.Parent = v_u_8:WaitForChild("PlayerGui")
	local v_u_13 = v6.driveArea(v_u_12)
	local v_u_14 = {
		["gas"] = false,
		["brake"] = false,
		["left"] = false,
		["right"] = false
	}
	local function v26(p_u_15, p16, p17, p18) -- name: pad
		-- upvalues: (copy) v_u_1, (copy) v_u_10, (copy) v_u_13, (copy) v_u_14, (copy) v_u_5
		local v_u_19 = v_u_1.new("TextButton")
		v_u_19.Name = p_u_15
		v_u_19.Text = ""
		v_u_19.AutoButtonColor = false
		v_u_19.AnchorPoint = p18
		v_u_19.Position = p17
		v_u_19.Size = p16
		v_u_19.BackgroundColor3 = v_u_10
		v_u_19.BackgroundTransparency = 0.6
		v_u_19.BorderSizePixel = 0
		v_u_19.Parent = v_u_13
		local v20 = v_u_1.new("UICorner")
		v20.CornerRadius = UDim.new(0, 10)
		v20.Parent = v_u_19
		local v_u_21 = nil
		v_u_19.InputBegan:Connect(function(p22)
			-- upvalues: (ref) v_u_14, (copy) p_u_15, (ref) v_u_21, (copy) v_u_19
			if p22.UserInputType == Enum.UserInputType.Touch or p22.UserInputType == Enum.UserInputType.MouseButton1 then
				v_u_14[p_u_15] = true
				v_u_21 = p22
				v_u_19.BackgroundTransparency = 0.35
			end
		end)
		v_u_19.InputEnded:Connect(function(p23)
			-- upvalues: (ref) v_u_14, (copy) p_u_15, (ref) v_u_21, (copy) v_u_19
			if p23.UserInputType == Enum.UserInputType.Touch or p23.UserInputType == Enum.UserInputType.MouseButton1 then
				v_u_14[p_u_15] = false
				v_u_21 = nil
				v_u_19.BackgroundTransparency = 0.6
			end
		end)
		v_u_5.InputEnded:Connect(function(p24)
			-- upvalues: (ref) v_u_21, (ref) v_u_14, (copy) p_u_15, (copy) v_u_19
			if v_u_21 and (p24 == v_u_21 or p24.UserInputType == Enum.UserInputType.MouseButton1) then
				v_u_14[p_u_15] = false
				v_u_21 = nil
				v_u_19.BackgroundTransparency = 0.6
			end
		end)
		v_u_5.TouchEnded:Connect(function(p25)
			-- upvalues: (ref) v_u_21, (ref) v_u_14, (copy) p_u_15, (copy) v_u_19
			if p25 == v_u_21 then
				v_u_14[p_u_15] = false
				v_u_21 = nil
				v_u_19.BackgroundTransparency = 0.6
			end
		end)
		return v_u_19
	end
	local function v33(p27, p28) -- name: ribs
		-- upvalues: (copy) v_u_1, (copy) v_u_11
		local v29 = v_u_1.new("Frame")
		v29.BackgroundTransparency = 1
		v29.AnchorPoint = Vector2.new(0.5, 0.5)
		v29.Position = UDim2.fromScale(0.5, 0.5)
		v29.Size = UDim2.new(1, -24, 0.8, 0)
		v29.Parent = p27
		local v30 = v_u_1.new("UIListLayout")
		v30.FillDirection = Enum.FillDirection.Horizontal
		v30.HorizontalAlignment = Enum.HorizontalAlignment.Center
		v30.Padding = UDim.new(0, p28 > 3 and 12 or 22)
		v30.Parent = v29
		for _ = 1, p28 do
			local v31 = v_u_1.new("Frame")
			v31.BackgroundColor3 = v_u_11
			v31.BackgroundTransparency = 0.3
			v31.BorderSizePixel = 0
			v31.Size = UDim2.new(0, 12, 1, 0)
			v31.Parent = v29
			local v32 = v_u_1.new("UICorner")
			v32.CornerRadius = UDim.new(1, 0)
			v32.Parent = v31
		end
	end
	local v34 = UDim2.fromOffset(170, v9)
	local v35 = {
		["left"] = v26("left", v34, UDim2.new(0, 0, 1, 0), Vector2.new(0, 1)),
		["right"] = v26("right", v34, UDim2.new(0, 175, 1, 0), Vector2.new(0, 1)),
		["gas"] = v26("gas", v34, UDim2.new(1, 0, 1, 0), Vector2.new(1, 1)),
		["brake"] = v26("brake", v34, UDim2.new(1, -175, 1, 0), Vector2.new(1, 1))
	}
	local v36 = v35.left
	local v37 = v_u_1.new("TextLabel")
	v37.BackgroundTransparency = 1
	v37.Size = UDim2.fromScale(1, 1)
	v37.Font = Enum.Font.GothamBlack
	v37.TextSize = 72
	v37.TextColor3 = v_u_11
	v37.TextTransparency = 0.25
	v37.Text = "<"
	v37.Parent = v36
	local v38 = v35.right
	local v39 = v_u_1.new("TextLabel")
	v39.BackgroundTransparency = 1
	v39.Size = UDim2.fromScale(1, 1)
	v39.Font = Enum.Font.GothamBlack
	v39.TextSize = 72
	v39.TextColor3 = v_u_11
	v39.TextTransparency = 0.25
	v39.Text = ">"
	v39.Parent = v38
	v33(v35.gas, 3)
	v33(v35.brake, 6)
	for v40, v41 in {
		["left"] = "\224\185\128\224\184\165\224\184\181\224\185\137\224\184\162\224\184\167\224\184\139\224\185\137\224\184\178\224\184\162",
		["right"] = "\224\185\128\224\184\165\224\184\181\224\185\137\224\184\162\224\184\167\224\184\130\224\184\167\224\184\178",
		["gas"] = "\224\184\132\224\184\177\224\184\153\224\185\128\224\184\163\224\185\136\224\184\135",
		["brake"] = "\224\185\128\224\184\154\224\184\163\224\184\129"
	} do
		v_u_7.register("pad." .. v40, v35[v40], v41)
	end
	local v_u_42 = nil
	local function v_u_46(p43) -- name: setSeatedJump
		-- upvalues: (copy) v_u_8, (ref) v_u_42
		local v44 = v_u_8.Character
		if v44 then
			v44 = v_u_8.Character:FindFirstChildOfClass("Humanoid")
		end
		if p43 and (v44 and not v_u_42) then
			v_u_42 = { v44, v44.JumpPower, v44.JumpHeight }
			v44.JumpPower = 0
			v44.JumpHeight = 0
		elseif not p43 and v_u_42 then
			local v45 = v_u_42[1]
			if v45.Parent then
				v45.JumpPower = v_u_42[2]
				v45.JumpHeight = v_u_42[3]
			end
			v_u_42 = nil
		end
	end
	local function v51() -- name: apply
		-- upvalues: (copy) v_u_8, (copy) v_u_46, (copy) v_u_12, (copy) v_u_7, (copy) v_u_14
		local v47 = v_u_8.Character
		if v47 then
			v47 = v47:FindFirstChildOfClass("Humanoid")
		end
		if v47 then
			v47 = v47.SeatPart
		end
		if not (v47 and v47:IsA("VehicleSeat")) then
			v47 = nil
		end
		v_u_46(v47)
		local v48 = v_u_12
		local v49 = v47 ~= nil or v_u_7.isEditing()
		if v49 then
			v49 = not v_u_8:GetAttribute("Tuning")
		end
		v48.Enabled = v49
		if v47 then
			v47.ThrottleFloat = (v_u_14.gas and 1 or 0) - (v_u_14.brake and 1 or 0)
			v47.SteerFloat = (v_u_14.right and 1 or 0) - (v_u_14.left and 1 or 0)
		else
			for v50 in v_u_14 do
				v_u_14[v50] = false
			end
		end
	end
	v4:BindToRenderStep("TouchPedals", Enum.RenderPriority.Last.Value + 5, v51)
	v4.Stepped:Connect(v51)
end