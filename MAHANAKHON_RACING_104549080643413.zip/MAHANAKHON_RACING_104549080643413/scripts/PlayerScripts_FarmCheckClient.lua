-- Path: Players/ygggggg55551/PlayerScripts/FarmCheckClient
-- Class: LocalScript  true/Enum.RunContext.Legacy
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = require(game:GetService("ReplicatedStorage"):WaitForChild("NetSeal"))
local v2 = game:GetService("Players")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("TweenService")
local v5 = game:GetService("UserInputService")
local v6 = require(v3:WaitForChild("GameShared"))
local v7 = v3:WaitForChild("GameUI")
local v_u_8 = require(v7:WaitForChild("Theme"))
local v_u_9 = require(v7:WaitForChild("Toast"))
local v_u_10 = v2.LocalPlayer
local v11 = v3:WaitForChild(v6.REMOTES)
local v12 = v11:WaitForChild("FarmCheck")
local v_u_13 = v11:WaitForChild("FarmCheckAnswer")
local v_u_14 = v_u_8.screen("FarmCheck", 95, v_u_10:WaitForChild("PlayerGui"))
local v_u_15 = v_u_8.new("Frame", {
	["BackgroundColor3"] = nil,
	["BackgroundTransparency"] = 0.35,
	["BorderSizePixel"] = 0,
	["Size"] = nil,
	["Visible"] = false,
	["Parent"] = nil,
	["BackgroundColor3"] = Color3.fromRGB(4, 6, 12),
	["Size"] = UDim2.fromScale(1, 1),
	["Parent"] = v_u_14
})
local v_u_16 = v_u_8.panel({
	["AnchorPoint"] = Vector2.new(0.5, 0.5),
	["Position"] = UDim2.fromScale(0.5, 0.5),
	["Size"] = UDim2.fromOffset(520, 340),
	["Parent"] = v_u_15
})
v_u_16.UICorner.CornerRadius = UDim.new(0, 18)
v_u_8.autoScale(v_u_16)
v_u_8.text({
	["Text"] = "\240\159\164\150 \224\185\128\224\184\138\224\185\135\224\184\129\224\184\167\224\185\136\224\184\178\224\185\128\224\184\155\224\185\135\224\184\153\224\184\132\224\184\153\224\184\136\224\184\163\224\184\180\224\184\135",
	["TextSize"] = 24,
	["FontFace"] = nil,
	["TextColor3"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["FontFace"] = v_u_8.FONT_DISPLAY,
	["TextColor3"] = v_u_8.YELLOW,
	["Position"] = UDim2.fromOffset(0, 18),
	["Size"] = UDim2.new(1, 0, 0, 30),
	["Parent"] = v_u_16
})
local v_u_17 = v_u_8.text({
	["Text"] = "",
	["TextSize"] = 20,
	["FontFace"] = nil,
	["TextWrapped"] = true,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["FontFace"] = v_u_8.FONT_BOLD,
	["Position"] = UDim2.fromOffset(20, 54),
	["Size"] = UDim2.new(1, -40, 0, 30),
	["Parent"] = v_u_16
})
v_u_8.text({
	["Text"] = "\224\184\129\224\184\177\224\184\153\224\185\130\224\184\155\224\184\163\224\184\159\224\184\178\224\184\163\224\185\140\224\184\161\224\184\173\224\184\177\224\184\149\224\185\130\224\184\153\224\184\161\224\184\177\224\184\149\224\184\180 \194\183 \224\184\149\224\184\173\224\184\154\224\185\129\224\184\165\224\185\137\224\184\167\224\184\151\224\184\179\224\184\135\224\184\178\224\184\153\224\184\149\224\185\136\224\184\173\224\185\132\224\184\148\224\185\137\224\185\128\224\184\165\224\184\162 \224\185\132\224\184\161\224\185\136\224\185\128\224\184\170\224\184\181\224\184\162\224\184\173\224\184\176\224\185\132\224\184\163",
	["TextSize"] = 14,
	["TextColor3"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["TextColor3"] = v_u_8.TEXT_DIM,
	["Position"] = UDim2.fromOffset(20, 86),
	["Size"] = UDim2.new(1, -40, 0, 18),
	["Parent"] = v_u_16
})
local v18 = v_u_8.new("Frame", {
	["Name"] = "Lang",
	["BackgroundColor3"] = nil,
	["BackgroundTransparency"] = 0.1,
	["BorderSizePixel"] = 0,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["BackgroundColor3"] = v_u_8.CARD_DARK,
	["AnchorPoint"] = Vector2.new(1, 0),
	["Position"] = UDim2.new(1, -14, 0, 14),
	["Size"] = UDim2.fromOffset(96, 32),
	["Parent"] = v_u_16
})
v_u_8.corner(v18, 16)
v_u_8.border(v18, Color3.new(1, 1, 1), 0.82, 1)
v_u_8.padding(v18, 3)
v_u_8.new("UIListLayout", {
	["FillDirection"] = Enum.FillDirection.Horizontal,
	["SortOrder"] = Enum.SortOrder.LayoutOrder,
	["Parent"] = v18
})
local v_u_19 = {}
for v20, v_u_21 in { "th", "en" } do
	local v22 = v_u_8.new("TextButton", {
		["Name"] = nil,
		["Text"] = nil,
		["AutoButtonColor"] = false,
		["FontFace"] = nil,
		["TextSize"] = 14,
		["TextColor3"] = nil,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["LayoutOrder"] = nil,
		["Parent"] = nil,
		["Name"] = v_u_21,
		["Text"] = string.upper(v_u_21),
		["FontFace"] = v_u_8.FONT_BOLD,
		["TextColor3"] = v_u_8.TEXT_DIM,
		["BackgroundColor3"] = v_u_8.YELLOW,
		["Size"] = UDim2.fromScale(0.5, 1),
		["LayoutOrder"] = v20,
		["Parent"] = v18
	})
	v_u_8.corner(v22, 13)
	v22.Activated:Connect(function()
		-- upvalues: (copy) v_u_10, (copy) v_u_21
		v_u_10:SetAttribute("UiLang", v_u_21)
	end)
	v_u_19[v_u_21] = v22
end
local function v28() -- name: showLang
	-- upvalues: (copy) v_u_10, (copy) v_u_19, (copy) v_u_8
	local v23 = v_u_10:GetAttribute("UiLangNow")
	for v24, v25 in v_u_19 do
		local v26 = v24 == v23
		v25.BackgroundTransparency = v26 and 0 or 1
		local v27
		if v26 then
			v27 = v_u_8.DARK_TEXT
		else
			v27 = v_u_8.TEXT_DIM
		end
		v25.TextColor3 = v27
	end
end
v_u_10:GetAttributeChangedSignal("UiLangNow"):Connect(v28)
v28()
local v_u_29 = v_u_8.new("Frame", {
	["BackgroundTransparency"] = 1,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["Position"] = UDim2.fromOffset(20, 116),
	["Size"] = UDim2.new(1, -40, 0, 200),
	["Parent"] = v_u_16
})
v_u_8.new("UIGridLayout", {
	["CellSize"] = UDim2.new(0.25, -9, 1, 0),
	["CellPadding"] = UDim2.fromOffset(12, 0),
	["SortOrder"] = Enum.SortOrder.LayoutOrder,
	["Parent"] = v_u_29
})
local v_u_30 = nil
local v_u_31 = false
local v_u_32 = 0
local function v34(p33) -- name: hand
	-- upvalues: (ref) v_u_32
	if typeof(p33) ~= "Instance" or p33.UserInputType ~= Enum.UserInputType.Focus then
		v_u_32 = os.clock()
	end
end
v5.InputBegan:Connect(v34)
v5.InputEnded:Connect(v34)
v5.TouchStarted:Connect(v34)
v5.TouchEnded:Connect(v34)
local function v_u_43(p35, p36) -- name: stampFor
	-- upvalues: (ref) v_u_32
	local v37 = 7
	local v38 = {}
	for v39 = 1, #p35 do
		v37 = (v37 * 31 + string.byte(p35, v39) * v39) % 65521
	end
	v38.c = v37
	local v40 = os.clock() - v_u_32
	local v41 = math.clamp(v40, 0, 999) * 100
	v38.t = math.floor(v41) / 100
	local v42
	if typeof(p36) == "Instance" then
		v42 = p36:IsA("InputObject")
	else
		v42 = false
	end
	v38.i = v42
	return v38
end
task.spawn(function()
	-- upvalues: (copy) v_u_1, (copy) v_u_13
	local v44 = v_u_1.invoke
	local v45 = v_u_13
	pcall(v44, v45, "", {
		["c"] = nil,
		["hello"] = true,
		["c"] = 7
	})
end)
local function v_u_59(p_u_46) -- name: draw
	-- upvalues: (copy) v_u_29, (copy) v_u_17, (copy) v_u_8, (ref) v_u_31, (ref) v_u_30, (copy) v_u_1, (copy) v_u_13, (copy) v_u_43, (copy) v_u_9
	for _, v47 in v_u_29:GetChildren() do
		if not v47:IsA("GuiObject") then
			continue
		end
		v47:Destroy()
	end
	v_u_17.Text = p_u_46.prompt or ""
	for v48, v_u_49 in p_u_46.options or {} do
		local v50 = v_u_8.new("TextButton", {
			["Text"] = "",
			["AutoButtonColor"] = true,
			["BackgroundColor3"] = nil,
			["LayoutOrder"] = nil,
			["Visible"] = nil,
			["Parent"] = nil,
			["BackgroundColor3"] = v_u_8.CARD,
			["LayoutOrder"] = v48,
			["Visible"] = v_u_49.h ~= true,
			["Parent"] = v_u_29
		})
		v_u_8.corner(v50, 16)
		v_u_8.border(v50, Color3.new(1, 1, 1), 0.8, 1.5)
		v_u_8.text({
			["Text"] = nil,
			["TextSize"] = 72,
			["Size"] = nil,
			["Parent"] = nil,
			["Text"] = v_u_49.emoji,
			["Size"] = UDim2.fromScale(1, 1),
			["Parent"] = v50
		})
		v50.Activated:Connect(function(p51)
			-- upvalues: (ref) v_u_31, (ref) v_u_30, (copy) p_u_46, (ref) v_u_1, (ref) v_u_13, (copy) v_u_49, (ref) v_u_43, (ref) v_u_9
			if not v_u_31 and v_u_30 == p_u_46.id then
				v_u_31 = true
				local v52 = v_u_1.invoke
				local v53 = v_u_13
				local v54 = v_u_49.id
				local v55 = v_u_43(v_u_49.id, p51)
				local v56, v57, v58 = pcall(v52, v53, v54, v55)
				v_u_31 = false
				if v56 and v58 then
					v_u_9.show(v58, v57 and "ok" or "error")
				end
			end
		end)
	end
end
v12.OnClientEvent:Connect(function(p60, p61)
	-- upvalues: (ref) v_u_30, (copy) v_u_59, (copy) v_u_14, (copy) v_u_15, (copy) v_u_16, (copy) v_u_4, (copy) v_u_8
	if p60 ~= "Show" or (type(p61) ~= "table" or not p61.g) then
		if p60 == "Show" and type(p61) == "table" then
			if v_u_30 ~= p61.id then
				v_u_30 = p61.id
				v_u_59(p61)
			end
			v_u_14.Enabled = true
			if not v_u_15.Visible then
				v_u_15.Visible = true
				v_u_16.Position = UDim2.new(0.5, 0, 0.5, 30)
				v_u_4:Create(v_u_16, v_u_8.POP, {
					["Position"] = UDim2.fromScale(0.5, 0.5)
				}):Play()
				return
			end
		elseif p60 == "Hide" then
			v_u_30 = nil
			v_u_15.Visible = false
		end
	end
end)