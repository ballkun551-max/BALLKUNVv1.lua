-- Path: Players/ygggggg55551/PlayerScripts/BanMenu
-- Class: LocalScript  true/Enum.RunContext.Legacy
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = require(game:GetService("ReplicatedStorage"):WaitForChild("NetSeal"))
local v_u_2 = game:GetService("Players")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("TextChatService")
local v5 = game:GetService("UserInputService")
local v6 = require(v3:WaitForChild("GameShared"))
local v_u_7 = require(v3:WaitForChild("RankShared"))
local v8 = v3:WaitForChild("GameUI")
local v_u_9 = require(v8:WaitForChild("Theme"))
local v_u_10 = require(v8:WaitForChild("Toast"))
local v_u_11 = v_u_2.LocalPlayer
local v_u_12 = v3:WaitForChild(v6.REMOTES):WaitForChild("Admin")
local v13 = v_u_9.isTouch()
local v_u_14 = {
	{ "1 \224\184\138\224\184\161.", 1 },
	{ "1 \224\184\167\224\184\177\224\184\153", 24 },
	{ "7 \224\184\167\224\184\177\224\184\153", 168 },
	{ "30 \224\184\167\224\184\177\224\184\153", 720 },
	{ "\224\184\150\224\184\178\224\184\167\224\184\163", 0 }
}
local v_u_15 = {
	["No such player"] = "\224\185\132\224\184\161\224\185\136\224\184\158\224\184\154\224\184\156\224\184\185\224\185\137\224\185\128\224\184\165\224\185\136\224\184\153\224\184\138\224\184\183\224\185\136\224\184\173\224\184\153\224\184\181\224\185\137",
	["You can\'t ban yourself"] = "\224\185\129\224\184\154\224\184\153\224\184\149\224\184\177\224\184\167\224\185\128\224\184\173\224\184\135\224\185\132\224\184\161\224\185\136\224\185\132\224\184\148\224\185\137",
	["You can\'t ban someone of your rank or higher"] = "\224\185\129\224\184\154\224\184\153\224\184\132\224\184\153\224\184\151\224\184\181\224\185\136\224\184\162\224\184\168\224\185\128\224\184\151\224\185\136\224\184\178\224\184\171\224\184\163\224\184\183\224\184\173\224\184\170\224\184\185\224\184\135\224\184\129\224\184\167\224\185\136\224\184\178\224\184\132\224\184\184\224\184\147\224\185\132\224\184\161\224\185\136\224\185\132\224\184\148\224\185\137",
	["Banned for good"] = "\224\185\129\224\184\154\224\184\153\224\184\150\224\184\178\224\184\167\224\184\163\224\185\129\224\184\165\224\185\137\224\184\167",
	["Staff only"] = "\224\185\128\224\184\137\224\184\158\224\184\178\224\184\176\224\184\151\224\184\181\224\184\161\224\184\135\224\184\178\224\184\153",
	["Your rank can\'t do that"] = "\224\184\162\224\184\168\224\184\130\224\184\173\224\184\135\224\184\132\224\184\184\224\184\147\224\185\131\224\184\138\224\185\137\224\184\132\224\184\179\224\184\170\224\184\177\224\185\136\224\184\135\224\184\153\224\184\181\224\185\137\224\185\132\224\184\161\224\185\136\224\185\132\224\184\148\224\185\137",
	["Too many actions, wait a minute"] = "\224\185\131\224\184\138\224\185\137\224\184\132\224\184\179\224\184\170\224\184\177\224\185\136\224\184\135\224\184\150\224\184\181\224\185\136\224\185\128\224\184\129\224\184\180\224\184\153\224\185\132\224\184\155 \224\184\163\224\184\173\224\184\170\224\184\177\224\184\129\224\184\132\224\184\163\224\184\185\224\185\136",
	["Easy, slow down"] = "\224\184\138\224\185\137\224\184\178\224\184\165\224\184\135\224\184\171\224\184\153\224\185\136\224\184\173\224\184\162 \224\185\129\224\184\165\224\185\137\224\184\167\224\184\129\224\184\148\224\184\173\224\184\181\224\184\129\224\184\132\224\184\163\224\184\177\224\185\137\224\184\135",
	["Something went wrong"] = "\224\185\128\224\184\129\224\184\180\224\184\148\224\184\130\224\185\137\224\184\173\224\184\156\224\184\180\224\184\148\224\184\158\224\184\165\224\184\178\224\184\148 \224\184\165\224\184\173\224\184\135\224\185\131\224\184\171\224\184\161\224\185\136\224\184\173\224\184\181\224\184\129\224\184\132\224\184\163\224\184\177\224\185\137\224\184\135",
	["Couldn\'t reach the server"] = "\224\184\149\224\184\180\224\184\148\224\184\149\224\185\136\224\184\173\224\185\128\224\184\139\224\184\180\224\184\163\224\185\140\224\184\159\224\185\128\224\184\167\224\184\173\224\184\163\224\185\140\224\185\132\224\184\161\224\185\136\224\185\132\224\184\148\224\185\137",
	["Unbanned (strikes reset)"] = "\224\184\155\224\184\165\224\184\148\224\185\129\224\184\154\224\184\153\224\185\129\224\184\165\224\185\137\224\184\167 (\224\184\163\224\184\181\224\185\128\224\184\139\224\185\135\224\184\149\224\184\170\224\185\132\224\184\149\224\184\163\224\184\132\224\185\140\224\185\129\224\184\165\224\185\137\224\184\167)",
	["Unbanned (strikes NOT reset: try again)"] = "\224\184\155\224\184\165\224\184\148\224\185\129\224\184\154\224\184\153\224\185\129\224\184\165\224\185\137\224\184\167 \224\185\129\224\184\149\224\185\136\224\184\163\224\184\181\224\185\128\224\184\139\224\185\135\224\184\149\224\184\170\224\185\132\224\184\149\224\184\163\224\184\132\224\185\140\224\185\132\224\184\161\224\185\136\224\184\170\224\184\179\224\185\128\224\184\163\224\185\135\224\184\136 \224\184\129\224\184\148\224\184\155\224\184\165\224\184\148\224\185\129\224\184\154\224\184\153\224\184\173\224\184\181\224\184\129\224\184\132\224\184\163\224\184\177\224\185\137\224\184\135"
}
local v_u_16 = v_u_9.screen("BanMenu", 61, v_u_11:WaitForChild("PlayerGui"))
local v_u_17 = v_u_9.button({
	["name"] = "BanOpen",
	["text"] = nil,
	["icon"] = "lock",
	["grad"] = "dark",
	["textSize"] = 15,
	["anchor"] = nil,
	["position"] = nil,
	["size"] = nil,
	["parent"] = nil,
	["text"] = v13 and "" or "\224\184\165\224\184\177\224\184\154",
	["anchor"] = Vector2.new(1, 0),
	["position"] = UDim2.new(1, v13 and -66 or -132, 0, v13 and 56 or 12),
	["size"] = UDim2.fromOffset(v13 and 46 or 100, 40),
	["parent"] = v_u_16
})
v_u_17.Visible = false
local v_u_18 = v_u_9.window({
	["name"] = "BanWindow",
	["gui"] = nil,
	["icon"] = "lock",
	["grad"] = "red",
	["title"] = "\224\185\129\224\184\154\224\184\153 / \224\184\155\224\184\165\224\184\148\224\185\129\224\184\154\224\184\153",
	["sub"] = "\224\184\161\224\184\181\224\184\156\224\184\165\224\184\151\224\184\177\224\185\137\224\184\135\224\185\128\224\184\129\224\184\161 \224\184\151\224\184\184\224\184\129\224\185\128\224\184\139\224\184\180\224\184\163\224\185\140\224\184\159\224\185\128\224\184\167\224\184\173\224\184\163\224\185\140",
	["size"] = nil,
	["max"] = nil,
	["keepOpen"] = true,
	["gui"] = v_u_16,
	["size"] = Vector2.new(0.46, 0.82),
	["max"] = Vector2.new(560, 700)
})
local v_u_19 = v_u_9.new("ScrollingFrame", {
	["Name"] = "Page",
	["BackgroundTransparency"] = 1,
	["BorderSizePixel"] = 0,
	["Size"] = nil,
	["CanvasSize"] = nil,
	["AutomaticCanvasSize"] = nil,
	["ScrollingDirection"] = nil,
	["ScrollBarThickness"] = 5,
	["Parent"] = nil,
	["Size"] = UDim2.fromScale(1, 1),
	["CanvasSize"] = UDim2.new(),
	["AutomaticCanvasSize"] = Enum.AutomaticSize.Y,
	["ScrollingDirection"] = Enum.ScrollingDirection.Y,
	["Parent"] = v_u_18.body
})
v_u_9.new("UIPadding", {
	["PaddingRight"] = UDim.new(0, 8),
	["PaddingBottom"] = UDim.new(0, 12),
	["Parent"] = v_u_19
})
v_u_9.new("UIListLayout", {
	["Padding"] = UDim.new(0, 10),
	["SortOrder"] = Enum.SortOrder.LayoutOrder,
	["Parent"] = v_u_19
})
local function v22(p20) -- name: card
	-- upvalues: (copy) v_u_9, (copy) v_u_19
	local v21 = v_u_9.new("Frame", {
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_9.CARD,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y,
		["LayoutOrder"] = p20,
		["Parent"] = v_u_19
	})
	v_u_9.corner(v21, 14)
	v_u_9.border(v21, Color3.new(1, 1, 1), 0.88, 1)
	v_u_9.padding(v21, 12, 10)
	v_u_9.new("UIListLayout", {
		["Padding"] = UDim.new(0, 8),
		["SortOrder"] = Enum.SortOrder.LayoutOrder,
		["Parent"] = v21
	})
	return v21
end
local function v26(p23, p24, p25) -- name: heading
	-- upvalues: (copy) v_u_9
	return v_u_9.text({
		["Text"] = nil,
		["TextSize"] = 17,
		["FontFace"] = nil,
		["TextXAlignment"] = nil,
		["Size"] = nil,
		["LayoutOrder"] = nil,
		["Parent"] = nil,
		["Text"] = p25,
		["FontFace"] = v_u_9.FONT_HEAVY,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["Size"] = UDim2.new(1, 0, 0, 22),
		["LayoutOrder"] = p24,
		["Parent"] = p23
	})
end
local function v30(p27, p28, p29) -- name: note
	-- upvalues: (copy) v_u_9
	return v_u_9.text({
		["Text"] = nil,
		["TextSize"] = 13,
		["TextColor3"] = nil,
		["TextWrapped"] = true,
		["TextXAlignment"] = nil,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = nil,
		["Parent"] = nil,
		["Text"] = p29,
		["TextColor3"] = v_u_9.TEXT_DIM,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y,
		["LayoutOrder"] = p28,
		["Parent"] = p27
	})
end
local function v39(p31, p32, p33) -- name: box
	-- upvalues: (copy) v_u_9
	local v34 = v_u_9.new("Frame", {
		["BackgroundColor3"] = v_u_9.CARD_DARK,
		["Size"] = UDim2.new(1, 0, 0, 40),
		["LayoutOrder"] = p32,
		["Parent"] = p31
	})
	v_u_9.corner(v34, 10)
	local v_u_35 = v_u_9.border(v34, Color3.new(1, 1, 1), 0.82, 1.2)
	local v36 = v_u_9.new("TextBox", {
		["BackgroundTransparency"] = 1,
		["Text"] = "",
		["PlaceholderText"] = nil,
		["PlaceholderColor3"] = nil,
		["ClearTextOnFocus"] = false,
		["FontFace"] = nil,
		["TextSize"] = 16,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["PlaceholderText"] = p33,
		["PlaceholderColor3"] = Color3.fromRGB(110, 114, 130),
		["FontFace"] = v_u_9.FONT_BOLD,
		["TextColor3"] = v_u_9.TEXT,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["Position"] = UDim2.fromOffset(12, 0),
		["Size"] = UDim2.new(1, -24, 1, 0),
		["Parent"] = v34
	})
	v36.Focused:Connect(function()
		-- upvalues: (copy) v_u_35, (ref) v_u_9
		local v37 = v_u_35
		v_u_35.Color = v_u_9.YELLOW
		v37.Transparency = 0.2
	end)
	v36.FocusLost:Connect(function()
		-- upvalues: (copy) v_u_35
		local v38 = v_u_35
		v_u_35.Color = Color3.new(1, 1, 1)
		v38.Transparency = 0.82
	end)
	return v36
end
local function v56(p40, p41, p_u_42, p_u_43, p_u_44) -- name: cells
	-- upvalues: (copy) v_u_9
	local v_u_45 = v_u_9.new("Frame", {
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = nil,
		["Parent"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y,
		["LayoutOrder"] = p41,
		["Parent"] = p40
	})
	local v_u_46 = v_u_9.new("UIGridLayout", {
		["CellPadding"] = UDim2.fromOffset(6, 6),
		["CellSize"] = UDim2.fromOffset(p_u_42, p_u_43),
		["SortOrder"] = Enum.SortOrder.LayoutOrder,
		["Parent"] = v_u_45
	})
	local function v55() -- name: layout
		-- upvalues: (ref) v_u_9, (copy) v_u_45, (copy) p_u_42, (copy) p_u_44, (copy) v_u_46, (copy) p_u_43
		local v47 = v_u_9.unscaledSize(v_u_45).X
		if v47 > 0 then
			local v48 = (v47 + 6) / p_u_42
			local v49 = math.floor(v48)
			local v50 = p_u_44 or 99
			local v51 = math.clamp(v49, 1, v50)
			local v52 = v_u_46
			local v53 = UDim2.fromOffset
			local v54 = (v47 - (v51 - 1) * 6) / v51
			v52.CellSize = v53(math.floor(v54), p_u_43)
		end
	end
	v_u_45:GetPropertyChangedSignal("AbsoluteSize"):Connect(v55)
	task.defer(v55)
	return v_u_45
end
local v57 = v22(1)
v26(v57, 1, "\240\159\145\164 \224\184\156\224\184\185\224\185\137\224\185\128\224\184\165\224\185\136\224\184\153")
local v_u_58 = v39(v57, 2, "\224\184\138\224\184\183\224\185\136\224\184\173\224\184\156\224\184\185\224\185\137\224\185\131\224\184\138\224\185\137 \224\184\171\224\184\163\224\184\183\224\184\173 User ID")
v30(v57, 3, "\224\185\129\224\184\149\224\184\176\224\184\138\224\184\183\224\185\136\224\184\173\224\184\132\224\184\153\224\185\131\224\184\153\224\185\128\224\184\139\224\184\180\224\184\163\224\185\140\224\184\159\224\184\153\224\184\181\224\185\137\224\184\148\224\185\137\224\184\178\224\184\153\224\184\165\224\185\136\224\184\178\224\184\135 \224\184\171\224\184\163\224\184\183\224\184\173\224\184\158\224\184\180\224\184\161\224\184\158\224\185\140\224\184\138\224\184\183\224\185\136\224\184\173\224\185\128\224\184\173\224\184\135\224\184\170\224\184\179\224\184\171\224\184\163\224\184\177\224\184\154\224\184\132\224\184\153\224\184\151\224\184\181\224\185\136\224\184\173\224\184\162\224\184\185\224\185\136\224\185\128\224\184\139\224\184\180\224\184\163\224\185\140\224\184\159\224\184\173\224\184\183\224\185\136\224\184\153 \224\184\173\224\184\173\224\184\159\224\185\132\224\184\165\224\184\153\224\185\140 \224\184\171\224\184\163\224\184\183\224\184\173\224\185\130\224\184\148\224\184\153\224\185\129\224\184\154\224\184\153\224\185\132\224\184\155\224\185\129\224\184\165\224\185\137\224\184\167")
local v_u_59 = v56(v57, 4, 150, 34)
local v_u_60 = v30(v57, 5, "\224\185\132\224\184\161\224\185\136\224\184\161\224\184\181\224\184\132\224\184\153\224\184\173\224\184\183\224\185\136\224\184\153\224\185\131\224\184\153\224\185\128\224\184\139\224\184\180\224\184\163\224\185\140\224\184\159\224\184\153\224\184\181\224\185\137")
v_u_60.Visible = false
local v_u_61 = {}
local function v_u_68() -- name: markPicked
	-- upvalues: (copy) v_u_58, (copy) v_u_61, (copy) v_u_9
	local v62 = string.lower((v_u_58.Text:gsub("^%s*@?", ""):gsub("%s*$", "")))
	for v63, v64 in v_u_61 do
		local v65
		if v62 == "" then
			v65 = false
		elseif string.lower(v63.Name) == v62 then
			v65 = true
		else
			local v66 = v63.UserId
			v65 = tostring(v66) == v62
		end
		local v67
		if v65 then
			v67 = v_u_9.YELLOW
		else
			v67 = Color3.new(1, 1, 1)
		end
		v64.Color = v67
		v64.Transparency = v65 and 0.1 or 0.85
		v64.Thickness = v65 and 2 or 1
	end
end
v_u_58:GetPropertyChangedSignal("Text"):Connect(v_u_68)
local v_u_69 = v30(v22(4), 1, "\224\185\128\224\184\165\224\184\183\224\184\173\224\184\129\224\184\156\224\184\185\224\185\137\224\185\128\224\184\165\224\185\136\224\184\153 \224\185\129\224\184\165\224\185\137\224\184\167\224\184\129\224\184\148\224\185\129\224\184\154\224\184\153\224\184\171\224\184\163\224\184\183\224\184\173\224\184\155\224\184\165\224\184\148\224\185\129\224\184\154\224\184\153")
v_u_69.TextSize = 15
local v70 = v22(2)
v26(v70, 1, "\240\159\148\168 \224\185\129\224\184\154\224\184\153 / \240\159\148\147 \224\184\155\224\184\165\224\184\148\224\185\129\224\184\154\224\184\153")
local v71 = v56(v70, 2, 84, 36, #v_u_14)
local v_u_72 = v39(v70, 3, "\224\184\171\224\184\163\224\184\183\224\184\173\224\184\158\224\184\180\224\184\161\224\184\158\224\185\140\224\184\136\224\184\179\224\184\153\224\184\167\224\184\153\224\184\138\224\184\177\224\185\136\224\184\167\224\185\130\224\184\161\224\184\135 (\224\184\167\224\185\136\224\184\178\224\184\135 \224\184\171\224\184\163\224\184\183\224\184\173 0 = \224\184\150\224\184\178\224\184\167\224\184\163)")
local v_u_73 = v39(v70, 4, "\224\185\128\224\184\171\224\184\149\224\184\184\224\184\156\224\184\165 (\224\184\156\224\184\185\224\185\137\224\185\128\224\184\165\224\185\136\224\184\153\224\184\136\224\184\176\224\185\128\224\184\171\224\185\135\224\184\153\224\184\149\224\184\173\224\184\153\224\185\128\224\184\130\224\185\137\224\184\178\224\185\128\224\184\129\224\184\161\224\185\132\224\184\161\224\185\136\224\185\132\224\184\148\224\185\137)")
local v74 = v56(v70, 5, 150, 44, 2)
local v_u_75 = v_u_9.button({
	["name"] = "Ban",
	["text"] = "\224\185\129\224\184\154\224\184\153",
	["icon"] = "lock",
	["grad"] = "red",
	["textSize"] = 17,
	["parent"] = nil,
	["parent"] = v74
})
v_u_75.LayoutOrder = 1
local v76 = v_u_9.button({
	["name"] = "Unban",
	["text"] = "\224\184\155\224\184\165\224\184\148\224\185\129\224\184\154\224\184\153",
	["icon"] = "key",
	["grad"] = "green",
	["textSize"] = 17,
	["parent"] = nil,
	["parent"] = v74
})
v76.LayoutOrder = 2
v30(v70, 6, "\224\185\129\224\184\154\224\184\153: \224\184\129\224\184\148\224\184\170\224\184\173\224\184\135\224\184\132\224\184\163\224\184\177\224\185\137\224\184\135\224\185\128\224\184\158\224\184\183\224\185\136\224\184\173\224\184\162\224\184\183\224\184\153\224\184\162\224\184\177\224\184\153 \194\183 \224\184\155\224\184\165\224\184\148\224\185\129\224\184\154\224\184\153: \224\185\131\224\184\138\224\185\137\224\185\129\224\184\132\224\185\136\224\184\138\224\184\183\224\185\136\224\184\173 \224\185\132\224\184\161\224\185\136\224\184\149\224\185\137\224\184\173\224\184\135\224\185\131\224\184\170\224\185\136\224\185\128\224\184\167\224\184\165\224\184\178\224\184\171\224\184\163\224\184\183\224\184\173\224\185\128\224\184\171\224\184\149\224\184\184\224\184\156\224\184\165 \194\183 \224\184\161\224\184\181\224\184\156\224\184\165\224\184\151\224\184\184\224\184\129\224\185\128\224\184\139\224\184\180\224\184\163\224\185\140\224\184\159\224\185\128\224\184\167\224\184\173\224\184\163\224\185\140 \194\183 \224\185\129\224\184\154\224\184\153\224\184\132\224\184\153\224\184\151\224\184\181\224\185\136\224\184\162\224\184\168\224\185\128\224\184\151\224\185\136\224\184\178\224\184\171\224\184\163\224\184\183\224\184\173\224\184\170\224\184\185\224\184\135\224\184\129\224\184\167\224\185\136\224\184\178\224\184\132\224\184\184\224\184\147\224\185\132\224\184\161\224\185\136\224\185\132\224\184\148\224\185\137")
local v_u_77 = {}
local function v_u_91(p78) -- name: buildPlayers
	-- upvalues: (copy) v_u_59, (copy) v_u_61, (copy) v_u_2, (copy) v_u_11, (copy) v_u_9, (copy) v_u_58, (copy) v_u_60, (copy) v_u_68
	for _, v79 in v_u_59:GetChildren() do
		if not v79:IsA("GuiObject") then
			continue
		end
		v79:Destroy()
	end
	table.clear(v_u_61)
	local v80 = {}
	for _, v81 in v_u_2:GetPlayers() do
		if v81 == v_u_11 or v81 == p78 then
			continue
		end
		table.insert(v80, v81)
	end
	table.sort(v80, function(p82, p83)
		return string.lower(p82.Name) < string.lower(p83.Name)
	end)
	for v84, v_u_85 in v80 do
		local v86 = v_u_9.new
		local v87 = "TextButton"
		local v88 = {
			["Name"] = nil,
			["AutoButtonColor"] = true,
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Text"] = nil,
			["FontFace"] = nil,
			["TextSize"] = 14,
			["TextColor3"] = nil,
			["TextTruncate"] = nil,
			["TextXAlignment"] = nil,
			["LayoutOrder"] = nil,
			["Parent"] = nil,
			["Name"] = "P_" .. v_u_85.UserId,
			["BackgroundColor3"] = v_u_9.CARD_DARK
		}
		local v89
		if v_u_85.DisplayName == v_u_85.Name then
			v89 = v_u_85.Name
		else
			v89 = v_u_85.DisplayName .. "  @" .. v_u_85.Name
		end
		v88.Text = v89
		v88.FontFace = v_u_9.FONT_BOLD
		v88.TextColor3 = v_u_9.TEXT
		v88.TextTruncate = Enum.TextTruncate.AtEnd
		v88.TextXAlignment = Enum.TextXAlignment.Left
		v88.LayoutOrder = v84
		v88.Parent = v_u_59
		local v90 = v86(v87, v88)
		v_u_9.corner(v90, 8)
		v_u_61[v_u_85] = v_u_9.border(v90, Color3.new(1, 1, 1), 0.85, 1)
		v_u_9.new("UIPadding", {
			["PaddingLeft"] = UDim.new(0, 10),
			["PaddingRight"] = UDim.new(0, 8),
			["Parent"] = v90
		})
		v90.Activated:Connect(function()
			-- upvalues: (ref) v_u_58, (copy) v_u_85
			v_u_58.Text = v_u_85.Name
		end)
	end
	v_u_60.Visible = #v80 == 0
	v_u_68()
end
local function v_u_94(p92) -- name: hoursLabel
	-- upvalues: (copy) v_u_14
	if p92 <= 0 then
		return "\224\184\150\224\184\178\224\184\167\224\184\163"
	end
	for _, v93 in v_u_14 do
		if v93[2] ~= p92 then
			continue
		end
		return v93[1]
	end
	return ("%g \224\184\138\224\184\161."):format(p92)
end
local function v_u_101(p95, ...) -- name: call
	-- upvalues: (copy) v_u_1, (copy) v_u_12
	local v96 = v_u_1.invoke
	local v97 = v_u_12
	local v98, v99, v100 = pcall(v96, v97, p95, ...)
	if v98 then
		return v99, v100
	else
		return false, "Couldn\'t reach the server"
	end
end
local function v_u_107(p102) -- name: thai
	-- upvalues: (copy) v_u_15
	local v103 = tostring(p102 or "")
	if v_u_15[v103] then
		return v_u_15[v103]
	else
		local v104 = v103:match("^Banned for ([%d%.]+) h$")
		if v104 then
			return ("\224\185\129\224\184\154\224\184\153 %s \224\184\138\224\184\177\224\185\136\224\184\167\224\185\130\224\184\161\224\184\135\224\185\129\224\184\165\224\185\137\224\184\167"):format(v104)
		else
			local v105 = v103:match("^Ban failed: (.*)$")
			if v105 then
				return "\224\185\129\224\184\154\224\184\153\224\185\132\224\184\161\224\185\136\224\184\170\224\184\179\224\185\128\224\184\163\224\185\135\224\184\136: " .. v105
			else
				local v106 = v103:match("^Unban failed: (.*)$")
				if v106 then
					return "\224\184\155\224\184\165\224\184\148\224\185\129\224\184\154\224\184\153\224\185\132\224\184\161\224\185\136\224\184\170\224\184\179\224\185\128\224\184\163\224\185\135\224\184\136: " .. v106
				else
					return v103
				end
			end
		end
	end
end
for v108, v_u_109 in v_u_14 do
	local v110 = v_u_9.button({
		["name"] = nil,
		["text"] = nil,
		["grad"] = "grey",
		["textSize"] = 14,
		["parent"] = nil,
		["name"] = "D" .. v108,
		["text"] = v_u_109[1],
		["parent"] = v71
	})
	v110.LayoutOrder = v108
	local v111 = { v110, v_u_109[2], v_u_109[1] }
	table.insert(v_u_77, v111)
	v110.Activated:Connect(function()
		-- upvalues: (copy) v_u_72, (copy) v_u_109
		local v112 = v_u_72
		local v113
		if v_u_109[2] > 0 then
			local v114 = v_u_109[2]
			v113 = tostring(v114)
		else
			v113 = ""
		end
		v112.Text = v113
	end)
end
local function v123() -- name: markDuration
	-- upvalues: (copy) v_u_72, (copy) v_u_77, (copy) v_u_9
	local v115 = v_u_72.Text:gsub("[,%s]", "")
	local v116 = v115 == "" and 0 or tonumber(v115)
	for _, v117 in v_u_77 do
		local v118 = v_u_9.setButton
		local v119 = v117[1]
		local v120 = v116 == v117[2] and "gold" or "grey"
		local v121 = v117[3]
		local v122
		if v116 == v117[2] then
			v122 = v_u_9.DARK_TEXT
		else
			v122 = Color3.new(1, 1, 1)
		end
		v118(v119, v120, v121, v122)
	end
end
v_u_72:GetPropertyChangedSignal("Text"):Connect(v123)
v123()
local v_u_124 = false
local v_u_125 = nil
local function v_u_134(p126, p127) -- name: doBan
	-- upvalues: (ref) v_u_124, (copy) v_u_69, (copy) v_u_9, (copy) v_u_101, (copy) v_u_73, (copy) v_u_107, (copy) v_u_10, (copy) v_u_91
	v_u_124 = true
	v_u_69.Text = ("\224\184\129\224\184\179\224\184\165\224\184\177\224\184\135\224\185\129\224\184\154\224\184\153 %s\226\128\166"):format(p126)
	v_u_69.TextColor3 = v_u_9.TEXT_DIM
	local v128, v129 = v_u_101("Ban", p126, p127, v_u_73.Text)
	v_u_124 = false
	local v130 = v128 == true
	local v131
	if v128 then
		v131 = ("%s: %s"):format(p126, v_u_107(v129))
	else
		v131 = v_u_107(v129)
	end
	v_u_69.Text = v131
	local v132 = v_u_69
	local v133
	if v130 == true then
		v133 = Color3.fromRGB(90, 230, 140)
	elseif v130 == false then
		v133 = Color3.fromRGB(255, 110, 110)
	else
		v133 = v_u_9.TEXT_DIM
	end
	v132.TextColor3 = v133
	v_u_10.show(v131, v130 and "ok" or "error")
	if v128 then
		v_u_73.Text = ""
		v_u_91()
	end
end
v_u_75.Activated:Connect(function()
	-- upvalues: (ref) v_u_124, (copy) v_u_58, (ref) v_u_125, (copy) v_u_9, (copy) v_u_75, (copy) v_u_69, (copy) v_u_10, (copy) v_u_72, (copy) v_u_134, (copy) v_u_94
	if v_u_124 then
		return
	else
		local v135 = v_u_58.Text:gsub("^%s*@?", ""):gsub("%s*$", "")
		if v135 == "" then
			v_u_125 = nil
			v_u_9.setButton(v_u_75, "red", "\224\185\129\224\184\154\224\184\153")
			v_u_69.Text = "\224\184\158\224\184\180\224\184\161\224\184\158\224\185\140\224\184\138\224\184\183\224\185\136\224\184\173 \224\184\171\224\184\163\224\184\183\224\184\173\224\185\129\224\184\149\224\184\176\224\185\128\224\184\165\224\184\183\224\184\173\224\184\129\224\184\156\224\184\185\224\185\137\224\185\128\224\184\165\224\185\136\224\184\153\224\184\129\224\185\136\224\184\173\224\184\153"
			v_u_69.TextColor3 = Color3.fromRGB(255, 110, 110)
			v_u_10.show("\224\184\158\224\184\180\224\184\161\224\184\158\224\185\140\224\184\138\224\184\183\224\185\136\224\184\173 \224\184\171\224\184\163\224\184\183\224\184\173\224\185\129\224\184\149\224\184\176\224\185\128\224\184\165\224\184\183\224\184\173\224\184\129\224\184\156\224\184\185\224\185\137\224\185\128\224\184\165\224\185\136\224\184\153\224\184\129\224\185\136\224\184\173\224\184\153", "error")
			return
		else
			local v136 = v_u_72.Text:gsub("[,%s]", "")
			local v137 = v136 == "" and 0 or tonumber(v136)
			if v137 and v137 >= 0 then
				if v_u_125 and os.clock() - v_u_125 < 4 then
					v_u_125 = nil
					v_u_9.setButton(v_u_75, "red", "\224\185\129\224\184\154\224\184\153")
					v_u_134(v135, v137)
				else
					local v_u_138 = os.clock()
					v_u_125 = v_u_138
					v_u_9.setButton(v_u_75, "orange", "\224\184\129\224\184\148\224\184\173\224\184\181\224\184\129\224\184\132\224\184\163\224\184\177\224\185\137\224\184\135\224\185\128\224\184\158\224\184\183\224\185\136\224\184\173\224\184\162\224\184\183\224\184\153\224\184\162\224\184\177\224\184\153")
					v_u_69.Text = ("\224\184\136\224\184\176\224\185\129\224\184\154\224\184\153 %s \194\183 %s \194\183 \224\184\129\224\184\148\224\184\155\224\184\184\224\185\136\224\184\161\224\184\173\224\184\181\224\184\129\224\184\132\224\184\163\224\184\177\224\185\137\224\184\135\224\185\128\224\184\158\224\184\183\224\185\136\224\184\173\224\184\162\224\184\183\224\184\153\224\184\162\224\184\177\224\184\153"):format(v135, v_u_94(v137))
					v_u_69.TextColor3 = v_u_9.TEXT_DIM
					task.delay(4, function()
						-- upvalues: (ref) v_u_125, (copy) v_u_138, (ref) v_u_9, (ref) v_u_75, (ref) v_u_69
						if v_u_125 == v_u_138 then
							v_u_125 = nil
							v_u_9.setButton(v_u_75, "red", "\224\185\129\224\184\154\224\184\153")
							v_u_69.Text = "\224\184\162\224\184\129\224\185\128\224\184\165\224\184\180\224\184\129\224\185\129\224\184\165\224\185\137\224\184\167 (\224\185\132\224\184\161\224\185\136\224\185\132\224\184\148\224\185\137\224\184\129\224\184\148\224\184\162\224\184\183\224\184\153\224\184\162\224\184\177\224\184\153)"
							v_u_69.TextColor3 = v_u_9.TEXT_DIM
						end
					end)
				end
			else
				v_u_125 = nil
				v_u_9.setButton(v_u_75, "red", "\224\185\129\224\184\154\224\184\153")
				v_u_69.Text = "\224\184\136\224\184\179\224\184\153\224\184\167\224\184\153\224\184\138\224\184\177\224\185\136\224\184\167\224\185\130\224\184\161\224\184\135\224\184\149\224\185\137\224\184\173\224\184\135\224\185\128\224\184\155\224\185\135\224\184\153\224\184\149\224\184\177\224\184\167\224\185\128\224\184\165\224\184\130 0 \224\184\130\224\184\182\224\185\137\224\184\153\224\185\132\224\184\155 (\224\184\167\224\185\136\224\184\178\224\184\135 = \224\184\150\224\184\178\224\184\167\224\184\163)"
				v_u_69.TextColor3 = Color3.fromRGB(255, 110, 110)
				v_u_10.show("\224\184\136\224\184\179\224\184\153\224\184\167\224\184\153\224\184\138\224\184\177\224\185\136\224\184\167\224\185\130\224\184\161\224\184\135\224\184\149\224\185\137\224\184\173\224\184\135\224\185\128\224\184\155\224\185\135\224\184\153\224\184\149\224\184\177\224\184\167\224\185\128\224\184\165\224\184\130 0 \224\184\130\224\184\182\224\185\137\224\184\153\224\185\132\224\184\155 (\224\184\167\224\185\136\224\184\178\224\184\135 = \224\184\150\224\184\178\224\184\167\224\184\163)", "error")
				return
			end
		end
	end
end)
v_u_58:GetPropertyChangedSignal("Text"):Connect(function()
	-- upvalues: (ref) v_u_125, (copy) v_u_9, (copy) v_u_75
	if v_u_125 then
		v_u_125 = nil
		v_u_9.setButton(v_u_75, "red", "\224\185\129\224\184\154\224\184\153")
	end
end)
v_u_72:GetPropertyChangedSignal("Text"):Connect(function()
	-- upvalues: (ref) v_u_125, (copy) v_u_9, (copy) v_u_75
	if v_u_125 then
		v_u_125 = nil
		v_u_9.setButton(v_u_75, "red", "\224\185\129\224\184\154\224\184\153")
	end
end)
v76.Activated:Connect(function()
	-- upvalues: (ref) v_u_124, (copy) v_u_58, (copy) v_u_69, (copy) v_u_10, (copy) v_u_9, (copy) v_u_101, (copy) v_u_107
	if v_u_124 then
		return
	else
		local v139 = v_u_58.Text:gsub("^%s*@?", ""):gsub("%s*$", "")
		if v139 == "" then
			v_u_69.Text = "\224\184\158\224\184\180\224\184\161\224\184\158\224\185\140\224\184\138\224\184\183\224\185\136\224\184\173\224\184\171\224\184\163\224\184\183\224\184\173 User ID \224\184\130\224\184\173\224\184\135\224\184\132\224\184\153\224\184\151\224\184\181\224\185\136\224\184\136\224\184\176\224\184\155\224\184\165\224\184\148\224\185\129\224\184\154\224\184\153\224\184\129\224\185\136\224\184\173\224\184\153"
			v_u_69.TextColor3 = Color3.fromRGB(255, 110, 110)
			v_u_10.show("\224\184\158\224\184\180\224\184\161\224\184\158\224\185\140\224\184\138\224\184\183\224\185\136\224\184\173\224\184\171\224\184\163\224\184\183\224\184\173 User ID \224\184\130\224\184\173\224\184\135\224\184\132\224\184\153\224\184\151\224\184\181\224\185\136\224\184\136\224\184\176\224\184\155\224\184\165\224\184\148\224\185\129\224\184\154\224\184\153\224\184\129\224\185\136\224\184\173\224\184\153", "error")
		else
			v_u_124 = true
			v_u_69.Text = ("\224\184\129\224\184\179\224\184\165\224\184\177\224\184\135\224\184\155\224\184\165\224\184\148\224\185\129\224\184\154\224\184\153 %s\226\128\166"):format(v139)
			v_u_69.TextColor3 = v_u_9.TEXT_DIM
			local v140, v141 = v_u_101("Unban", v139)
			v_u_124 = false
			local v142 = v140 == true
			local v143
			if v140 then
				v143 = ("%s: %s"):format(v139, v_u_107(v141))
			else
				v143 = v_u_107(v141)
			end
			v_u_69.Text = v143
			local v144 = v_u_69
			local v145
			if v142 == true then
				v145 = Color3.fromRGB(90, 230, 140)
			elseif v142 == false then
				v145 = Color3.fromRGB(255, 110, 110)
			else
				v145 = v_u_9.TEXT_DIM
			end
			v144.TextColor3 = v145
			v_u_10.show(v143, v142 and "ok" or "error")
		end
	end
end)
v_u_17.Activated:Connect(function()
	-- upvalues: (copy) v_u_18, (copy) v_u_7, (copy) v_u_11, (copy) v_u_91
	local v146 = not v_u_18.isOpen()
	if not v146 or (v_u_7.isStaff(v_u_11) or v_u_11:GetAttribute("BanMenu") == true) then
		v_u_18.setOpen(v146)
		if v146 then
			v_u_91()
		end
	end
end)
v_u_16:GetAttributeChangedSignal("Open"):Connect(function()
	-- upvalues: (copy) v_u_16, (copy) v_u_18, (copy) v_u_7, (copy) v_u_11, (copy) v_u_91
	local v147 = v_u_16:GetAttribute("Open") == true
	if v147 ~= v_u_18.isOpen() then
		if v147 and (not v_u_7.isStaff(v_u_11) and v_u_11:GetAttribute("BanMenu") ~= true) then
			return
		end
		v_u_18.setOpen(v147)
		if v147 then
			v_u_91()
		end
	end
end)
v_u_18.changed.Event:Connect(function(p148)
	-- upvalues: (copy) v_u_16, (ref) v_u_125, (copy) v_u_9, (copy) v_u_75
	v_u_16:SetAttribute("Open", p148)
	if not p148 and v_u_125 then
		v_u_125 = nil
		v_u_9.setButton(v_u_75, "red", "\224\185\129\224\184\154\224\184\153")
	end
end)
v5.InputBegan:Connect(function(p149, p150)
	-- upvalues: (copy) v_u_18, (copy) v_u_7, (copy) v_u_11, (copy) v_u_91
	if not p150 and p149.KeyCode == Enum.KeyCode.F3 then
		local v151 = not v_u_18.isOpen()
		if v151 and (not v_u_7.isStaff(v_u_11) and v_u_11:GetAttribute("BanMenu") ~= true) then
			return
		end
		v_u_18.setOpen(v151)
		if v151 then
			v_u_91()
		end
	end
end)
v_u_2.PlayerAdded:Connect(function()
	-- upvalues: (copy) v_u_18, (copy) v_u_91
	if v_u_18.isOpen() then
		v_u_91()
	end
end)
v_u_2.PlayerRemoving:Connect(function(p152)
	-- upvalues: (copy) v_u_18, (copy) v_u_91
	if v_u_18.isOpen() then
		v_u_91(p152)
	end
end)
local v_u_153 = nil
local function v158() -- name: onRank
	-- upvalues: (copy) v_u_7, (copy) v_u_11, (copy) v_u_17, (ref) v_u_153, (copy) v_u_18, (copy) v_u_91, (copy) v_u_4
	local v154 = v_u_7.isStaff(v_u_11) or v_u_11:GetAttribute("BanMenu") == true
	v_u_17.Visible = v154
	if v154 and not v_u_153 then
		v_u_153 = Instance.new("TextChatCommand")
		v_u_153.Name = "StaffBanCommand"
		v_u_153.PrimaryAlias = "/6768"
		local function v155()
			-- upvalues: (ref) v_u_153
			v_u_153.AutocompleteVisible = false
		end
		pcall(v155)
		v_u_153.Triggered:Connect(function(p156)
			-- upvalues: (ref) v_u_11, (ref) v_u_18, (ref) v_u_7, (ref) v_u_91
			if not p156 or p156.UserId == v_u_11.UserId then
				local v157 = not v_u_18.isOpen()
				if v157 and (not v_u_7.isStaff(v_u_11) and v_u_11:GetAttribute("BanMenu") ~= true) then
					return
				end
				v_u_18.setOpen(v157)
				if v157 then
					v_u_91()
				end
			end
		end)
		v_u_153.Parent = v_u_4:FindFirstChild("TextChatCommands") or v_u_4
	elseif not v154 and v_u_153 then
		v_u_153:Destroy()
		v_u_153 = nil
	end
	if not v154 and v_u_18.isOpen() then
		v_u_18.setOpen(false)
	end
end
v_u_11:GetAttributeChangedSignal("Rank"):Connect(v158)
v_u_11:GetAttributeChangedSignal("BanMenu"):Connect(v158)
v158()