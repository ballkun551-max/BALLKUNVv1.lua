-- Path: ReplicatedStorage/GameUI/VehicleArt
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = require(game:GetService("ReplicatedStorage"):WaitForChild("UiOwn")).Instance
local v_u_2 = {
	["CHER150"] = { 132457995692021, 479, 252 },
	["CHER72"] = { 128013752422008, 405, 241 },
	["CHER74"] = { 108326808657716, 498, 278 },
	["CITY150"] = { 137608269836006, 300, 272 },
	["DMAXMUX"] = { 72028486397259, 623, 268 },
	["DREAM_DRAG"] = { 95330329786505, 440, 284 },
	["DREAM_RACE"] = { 131666524813489, 470, 313 },
	["FILANO24"] = { 124569010606361, 358, 270 },
	["FINO115"] = { 114354778028412, 361, 276 },
	["FK8"] = { 93004323943785, 590, 266 },
	["FK8T"] = { 91403215029796, 602, 219 },
	["FL5B"] = { 87693739394024, 621, 202 },
	["FLAT150"] = { 78126427755090, 415, 247 },
	["G20LCI"] = { 108755933815556, 609, 256 },
	["GIORNO22"] = { 73924747562436, 368, 251 },
	["GIORNO23"] = { 133363617308602, 370, 265 },
	["GIORNO25D"] = { 121028339158620, 417, 297 },
	["GIORNO25T"] = { 98272736439630, 418, 294 },
	["LEAD23"] = { 93604459360931, 572, 466 },
	["LEAD23V"] = { 71890511860678, 352, 263 },
	["LEAD25"] = { 98969676486499, 372, 261 },
	["LEAD25F"] = { 139697964635882, 454, 312 },
	["LEAD25G"] = { 122548565880569, 375, 258 },
	["MAXI250"] = { 135949228541288, 404, 259 },
	["NMAX20"] = { 102572974321900, 314, 226 },
	["PCX160"] = { 88615088157452, 397, 286 },
	["PCX160SA"] = { 127429253580411, 484, 301 },
	["SPORT155"] = { 132881616541084, 492, 303 },
	["SPORT_STEP"] = { 106727224814317, 504, 275 },
	["STREET160"] = { 126860930271837, 470, 307 },
	["STYLO160G"] = { 93271709611865, 444, 303 },
	["TOURER350"] = { 74314850771672, 355, 236 },
	["TOURER350B"] = { 122584156625426, 454, 308 },
	["TOURER350GT"] = { 77077300668505, 450, 289 },
	["TYPER23"] = { 116586903194844, 604, 220 },
	["VESPA_S"] = { 78436759592651, 348, 282 },
	["WAVE125S"] = { 112105068762389, 446, 300 },
	["WAVE_110I"] = { 112767606192773, 351, 262 },
	["WAVE_BARE"] = { 134395356948868, 349, 244 },
	["WAVE_KAGE"] = { 83140615137558, 450, 291 },
	["WAVE_SILVER"] = { 124477536394494, 414, 273 },
	["WAVE_STREET"] = { 88570805303022, 355, 243 },
	["WAVE_WHITE"] = { 133653441738691, 374, 246 },
	["XMAX"] = { 118301936422105, 469, 307 },
	["XMAX23F"] = { 128460172198787, 504, 301 },
	["XMAX23G"] = { 112053910156707, 389, 242 },
	["XMAX23W"] = { 123035567876634, 469, 305 }
}
local v_u_11 = {
	["of"] = function(p3) -- name: of
		-- upvalues: (copy) v_u_2
		if p3 then
			p3 = v_u_2[p3]
		end
		if p3 then
			return "rbxassetid://" .. p3[1], p3[2] / p3[3]
		else
			return nil
		end
	end,
	["size"] = function(p4) -- name: size
		-- upvalues: (copy) v_u_2
		if p4 then
			p4 = v_u_2[p4]
		end
		if p4 then
			return p4[2], p4[3]
		else
			return nil
		end
	end,
	["image"] = function(p5, p6) -- name: image
		-- upvalues: (copy) v_u_11, (copy) v_u_1
		local v7 = v_u_11.of(p5)
		if not v7 then
			return nil
		end
		local v8 = v_u_1.new("ImageLabel")
		v8.Name = "Art"
		v8.BackgroundTransparency = 1
		v8.Image = v7
		v8.ScaleType = Enum.ScaleType.Fit
		v8.Size = UDim2.fromScale(1, 1)
		for v9, v10 in p6 or {} do
			v8[v9] = v10
		end
		return v8
	end
}
return v_u_11