-- Path: Players/ygggggg55551/PlayerScripts/PCX160Client/Sound
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("Debris")
local v_u_3 = require(v1:WaitForChild("PCX160Shared"))
local v_u_4 = require(v1:WaitForChild("LiveRpm"))
local v_u_5 = require(v1:WaitForChild("GameShared"))
local v_u_6 = require(v1:WaitForChild("GearShared"))
local v_u_7 = require(v1:WaitForChild("PartsShared"))
local v_u_8 = {
	["volume"] = 1,
	["low"] = 0,
	["mid"] = 0,
	["high"] = 0,
	["rasp"] = 0,
	["pops"] = 1
}
local function v_u_14(p9, p10) -- name: popAttr
	-- upvalues: (copy) v_u_7, (copy) v_u_8
	local v11 = p9.pipe
	if not v11 then
		local v12 = p9.model
		v11 = v_u_7.exhaustSound(v12:GetAttribute("PartExhaustSound")) or v_u_8
	end
	if p10 == "SoundExhaustPop" and (v11.backfire and (v_u_7.keepsOwnPop(p9.model) and p9.model:GetAttribute(p10) ~= nil)) then
		return p9.model:GetAttribute(p10)
	else
		local v13 = v11.backfire
		if v13 then
			v13 = v_u_7.EXHAUST_BACKFIRE[p10]
		end
		if v13 == nil or v13 == false then
			return p9.model:GetAttribute(p10)
		else
			return v13
		end
	end
end
local v_u_15 = require(v1:WaitForChild("EcuShared"))
local v_u_16 = { 1, 3 }
local v_u_17 = { 0.4, 0.7 }
local v_u_18 = { 0.05, 0.16 }
local v_u_19 = {
	["Idle"] = { 0.01, 4 },
	["RevA"] = { 0.01, 2 },
	["RevB"] = { 0.01, 2 },
	["RelA"] = { 0.01, 2 },
	["RelB"] = { 0.01, 2 },
	["RmbA"] = { 0.01, 1.5 },
	["RmbB"] = { 0.01, 1.5 },
	["Red"] = { 0.05, 0.9 }
}
local v_u_20 = {
	["Idle"] = 0.05,
	["Red"] = 5,
	["RelA"] = 0.45,
	["RelB"] = 0.45
}
local v_u_21 = {
	["EngineLow"] = {
		"SoundEngineLow",
		"exhaust",
		true,
		true,
		"SoundEngineLowLoop"
	},
	["EngineHigh"] = {
		"SoundEngineHigh",
		"exhaust",
		true,
		true,
		"SoundEngineHighLoop"
	},
	["CvtWhine"] = {
		"SoundCvtWhine",
		"chassis",
		true,
		false,
		nil
	},
	["Start"] = {
		"SoundEngineStart",
		"exhaust",
		false,
		true,
		nil
	},
	["Pop"] = {
		"SoundExhaustPop",
		"exhaust",
		false,
		false,
		nil
	},
	["Limiter"] = {
		"SoundLimiter",
		"exhaust",
		true,
		false,
		nil
	}
}
local v_u_22 = {}
v_u_22.__index = v_u_22
local function v_u_28(p23, p24) -- name: addExhaustEffects
	local v25 = Instance.new("DistortionSoundEffect")
	local v26
	if p24 then
		v26 = p24:GetAttribute("ExhaustRasp")
	else
		v26 = p24
	end
	v25.Level = typeof(v26) ~= "number" and 0.3 or v26
	v25.Parent = p23
	local v27 = Instance.new("EqualizerSoundEffect")
	if p24 then
		p24 = p24:GetAttribute("ExhaustBass")
	end
	v27.LowGain = typeof(p24) ~= "number" and 6 or p24
	v27.MidGain = 0
	v27.HighGain = -2
	v27.Parent = p23
end
function v_u_22.new(p_u_29) -- name: new
	-- upvalues: (copy) v_u_22, (copy) v_u_6, (copy) v_u_21
	local v30 = v_u_22
	local v_u_31 = setmetatable({}, v30)
	v_u_31.model = p_u_29
	v_u_31.chassis = p_u_29:FindFirstChild("Chassis")
	v_u_31.seat = p_u_29:FindFirstChild("VehicleSeat")
	v_u_31.exhaust = v_u_31.chassis and v_u_31.chassis:FindFirstChild("ExhaustTip") or v_u_31.chassis
	v_u_31.sounds = {}
	v_u_31.connections = {}
	v_u_31.rpm = 1700
	v_u_31.fade = 0
	v_u_31.loopsAt = (1 / 0)
	v_u_31.engineOn = false
	v_u_31.wasThrottle = false
	v_u_31.gears = v_u_6.gears(p_u_29)
	v_u_31.gearTopAt = 0
	v_u_31.limiterLevel = 0
	for v_u_32, v33 in v_u_21 do
		v_u_31:refreshSound(v_u_32)
		local v34 = v_u_31.connections
		local v35 = p_u_29:GetAttributeChangedSignal(v33[1])
		table.insert(v34, v35:Connect(function()
			-- upvalues: (copy) v_u_31, (copy) v_u_32
			v_u_31:refreshSound(v_u_32)
		end))
		if not v33[5] then
			continue
		end
		local v36 = v_u_31.connections
		local v37 = p_u_29:GetAttributeChangedSignal(v33[5])
		table.insert(v36, v37:Connect(function()
			-- upvalues: (copy) v_u_31, (copy) v_u_32
			v_u_31:applyLoopRegion(v_u_32)
		end))
	end
	local v38 = v_u_31.connections
	local v39 = p_u_29:GetAttributeChangedSignal("EngineOn")
	table.insert(v38, v39:Connect(function()
		-- upvalues: (copy) v_u_31
		v_u_31:onEngineChanged()
	end))
	v_u_31:onEngineChanged()
	v_u_31:buildKit()
	local v40 = v_u_31.connections
	local v41 = p_u_29:GetAttributeChangedSignal("PistonBore")
	table.insert(v40, v41:Connect(function()
		-- upvalues: (copy) v_u_31
		v_u_31:applyExhaust()
	end))
	local v42 = v_u_31.connections
	local v43 = p_u_29:GetAttributeChangedSignal("PartExhaustSound")
	table.insert(v42, v43:Connect(function()
		-- upvalues: (copy) v_u_31
		v_u_31:applyExhaust()
		v_u_31:refreshSound("Pop")
	end))
	v_u_31:applyExhaust()
	if v_u_31.chassis then
		local v_u_44 = Instance.new("Sound")
		v_u_44.Name = "Horn"
		v_u_44.SoundId = "rbxassetid://127513531122725"
		v_u_44.Looped = true
		v_u_44.Volume = 0.8
		v_u_44.PlaybackSpeed = 1.35
		v_u_44.RollOffMaxDistance = 200
		v_u_44.Parent = v_u_31.chassis
		v_u_31.horn = v_u_44
		local v45 = v_u_31.connections
		local v46 = p_u_29:GetAttributeChangedSignal("HornOn")
		table.insert(v45, v46:Connect(function() -- name: updateHorn
			-- upvalues: (copy) p_u_29, (copy) v_u_44
			if p_u_29:GetAttribute("HornOn") == true then
				if not v_u_44.IsPlaying then
					v_u_44:Play()
					return
				end
			else
				v_u_44:Stop()
			end
		end))
		if p_u_29:GetAttribute("HornOn") == true then
			if not v_u_44.IsPlaying then
				v_u_44:Play()
				return v_u_31
			end
		else
			v_u_44:Stop()
		end
	end
	return v_u_31
end
function v_u_22.refreshSound(p47, p48) -- name: refreshSound
	-- upvalues: (copy) v_u_21, (copy) v_u_14, (copy) v_u_28
	local v49 = v_u_21[p48]
	local v50
	if p48 == "Pop" then
		v50 = v_u_14(p47, "SoundExhaustPop")
	else
		v50 = p47.model:GetAttribute(v49[1])
	end
	if typeof(v50) == "number" then
		v50 = "rbxassetid://" .. v50
	elseif typeof(v50) == "string" and v50 ~= "" then
		if v50:match("^%d+$") then
			v50 = "rbxassetid://" .. v50
		end
	else
		v50 = nil
	end
	local v51 = p47.sounds[p48]
	if v51 and v51.SoundId == v50 then
		return
	else
		if v51 then
			v51:Destroy()
			p47.sounds[p48] = nil
		end
		local v52
		if v49[2] == "exhaust" then
			v52 = p47.exhaust
		else
			v52 = p47.chassis
		end
		if v50 and v52 then
			local v53 = Instance.new("Sound")
			v53.Name = "PCX160_" .. p48
			v53.SoundId = v50
			v53.Looped = v49[3]
			v53.Volume = v49[3] and 0 or (p48 == "Start" and 0.75 or 1.3)
			v53.RollOffMode = Enum.RollOffMode.InverseTapered
			v53.RollOffMinDistance = 8
			v53.RollOffMaxDistance = 250
			if v49[4] then
				v_u_28(v53, p47.model)
			end
			v53.Parent = v52
			p47.sounds[p48] = v53
			p47:applyLoopRegion(p48)
			if v49[4] and p47.exhaustCfg then
				p47:applyExhaust()
			end
		end
	end
end
function v_u_22.buildKit(p54) -- name: buildKit
	-- upvalues: (copy) v_u_19
	local v55 = p54.model:FindFirstChild("EngineSoundSet")
	if v55 and p54.exhaust then
		p54.kit = {}
		p54.kitSet = v55
		for v56 in v_u_19 do
			local v57 = v55:FindFirstChild(v56)
			if not v57 or (not v57:IsA("Sound") or v57.SoundId == "") then
				continue
			end
			local v58 = Instance.new("Sound")
			v58.Name = "Kit_" .. v56
			v58.SoundId = v57.SoundId
			v58.Looped = true
			v58.Volume = 0
			v58.RollOffMode = Enum.RollOffMode.InverseTapered
			v58.RollOffMinDistance = 8
			v58.RollOffMaxDistance = 250
			Instance.new("DistortionSoundEffect", v58).Level = 0
			local v59 = Instance.new("EqualizerSoundEffect")
			v59.LowGain = 0
			v59.MidGain = 0
			v59.HighGain = 0
			v59.Parent = v58
			v58.Parent = p54.exhaust
			p54.kit[v56] = v58
		end
		for _, v60 in { "EngineLow", "EngineHigh" } do
			if not p54.sounds[v60] then
				continue
			end
			p54.sounds[v60]:Stop()
		end
	end
end
function v_u_22.applyExhaust(p61) -- name: applyExhaust
	-- upvalues: (copy) v_u_3, (copy) v_u_7, (copy) v_u_8, (copy) v_u_21
	local v62 = v_u_3.pistonSound(p61.model:GetAttribute("PistonBore"))
	p61.exhaustCfg = v62
	local v63 = p61.model
	local v64 = v_u_7.exhaustSound(v63:GetAttribute("PartExhaustSound")) or v_u_8
	p61.pipe = v64
	for _, v65 in p61.kit or {} do
		local v66 = v65:FindFirstChildOfClass("DistortionSoundEffect")
		local v67 = v65:FindFirstChildOfClass("EqualizerSoundEffect")
		if v66 then
			local v68 = v62.rasp + v64.rasp
			v66.Level = math.clamp(v68, 0, 1)
		end
		if not v67 then
			continue
		end
		v67.LowGain = v62.bass + v64.low
		v67.MidGain = v64.mid
		v67.HighGain = v64.high
	end
	for v69, v70 in p61.sounds do
		if not v_u_21[v69][4] then
			continue
		end
		local v71 = v70:FindFirstChildOfClass("DistortionSoundEffect")
		local v72 = v70:FindFirstChildOfClass("EqualizerSoundEffect")
		if v71 then
			local v73 = p61.model
			if v73 then
				v73 = v73:GetAttribute("ExhaustRasp")
			end
			local v74 = (typeof(v73) ~= "number" and 0.3 or v73) + v62.rasp + v64.rasp
			v71.Level = math.clamp(v74, 0, 1)
		end
		if not v72 then
			continue
		end
		local v75 = p61.model
		if v75 then
			v75 = v75:GetAttribute("ExhaustBass")
		end
		v72.LowGain = (typeof(v75) ~= "number" and 6 or v75) + v62.bass + v64.low
		v72.MidGain = v64.mid
		v72.HighGain = -2 + v64.high
	end
end
function v_u_22.applyLoopRegion(p76, p77) -- name: applyLoopRegion
	-- upvalues: (copy) v_u_21
	local v78 = p76.sounds[p77]
	local v79 = v_u_21[p77][5]
	if v78 and v79 then
		local v80 = p76.model:GetAttribute(v79)
		if typeof(v80) == "NumberRange" and v80.Max > v80.Min then
			v78.PlaybackRegionsEnabled = true
			v78.LoopRegion = v80
			if v78.TimePosition < v80.Min then
				v78.TimePosition = v80.Min
				return
			end
		else
			v78.PlaybackRegionsEnabled = false
		end
	end
end
function v_u_22.onEngineChanged(p81) -- name: onEngineChanged
	local v82 = p81.model:GetAttribute("EngineOn") == true
	if v82 == p81.engineOn then
		return
	else
		p81.engineOn = v82
		if v82 then
			p81.rpm = 1700
			local v83 = p81.sounds.Start
			if v83 then
				v83.TimePosition = 0
				v83:Play()
			end
			local v84 = os.clock()
			local v85 = p81.model
			if v85 then
				v85 = v85:GetAttribute("StartToLoops")
			end
			p81.loopsAt = v84 + (typeof(v85) ~= "number" and 0.9 or v85)
		else
			p81.loopsAt = (1 / 0)
		end
	end
end
local function v_u_90(p86, p87) -- name: makeFlame
	local v_u_88 = Instance.new("ParticleEmitter")
	v_u_88.Name = "PCX160_PopFlame"
	v_u_88.Texture = "rbxasset://textures/particles/fire_main.dds"
	v_u_88.Enabled = false
	v_u_88.EmissionDirection = Enum.NormalId.Back
	v_u_88.LightEmission = 1
	v_u_88.LightInfluence = 0
	pcall(function()
		-- upvalues: (copy) v_u_88
		v_u_88.Brightness = 2.5
	end)
	v_u_88.ZOffset = 0.6
	v_u_88.Color = ColorSequence.new({
		ColorSequenceKeypoint.new(0, Color3.fromRGB(255, 250, 220)),
		ColorSequenceKeypoint.new(0.25, Color3.fromRGB(255, 190, 70)),
		ColorSequenceKeypoint.new(0.6, Color3.fromRGB(255, 110, 20)),
		ColorSequenceKeypoint.new(1, Color3.fromRGB(190, 40, 10))
	})
	v_u_88.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.55, 0.2), NumberSequenceKeypoint.new(1, 1) })
	v_u_88.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.22 * p87), NumberSequenceKeypoint.new(0.35, 0.36 * p87), NumberSequenceKeypoint.new(1, 0.06 * p87) })
	v_u_88.Lifetime = NumberRange.new(0.08, 0.16)
	v_u_88.Speed = NumberRange.new(6 * p87, 10 * p87)
	v_u_88.SpreadAngle = Vector2.new(8, 8)
	v_u_88.Drag = 5
	v_u_88.LockedToPart = true
	v_u_88.Rotation = NumberRange.new(0, 360)
	v_u_88.RotSpeed = NumberRange.new(-180, 180)
	v_u_88.Parent = p86
	local v89 = Instance.new("PointLight")
	v89.Name = "PCX160_PopFlash"
	v89.Color = Color3.fromRGB(255, 140, 40)
	v89.Range = 8
	v89.Brightness = 6
	v89.Enabled = false
	v89.Parent = p86
	return v_u_88, v89
end
function v_u_22.popLoudness(p91) -- name: popLoudness
	-- upvalues: (copy) v_u_8, (copy) v_u_14, (copy) v_u_7
	local v92 = p91.pipe or v_u_8
	local v93 = v92.volume or 1
	if v92.backfire then
		local v94 = v_u_14(p91, "SoundExhaustPop") or ""
		local v95 = tostring(v94):match("%d+")
		v93 = v93 * (v95 and v_u_7.POP_FILE_VOLUME[v95] or (v_u_7.EXHAUST_BACKFIRE.volume or 1))
	end
	return v93, v92.bang or 1
end
function v_u_22.popFire(p96, p97) -- name: popFire
	-- upvalues: (copy) v_u_7, (copy) v_u_8
	local v98 = v_u_7.popTune(p96.model, "Flame")
	if v98 then
		local v99
		if v98 > 0 then
			v99 = math.random() * 100 < v98
		else
			v99 = false
		end
		return v99
	else
		if p96.model:GetAttribute("ExhaustPopFlame") ~= true then
			if (p96.pipe or v_u_8).flame ~= true then
				p97 = false
			end
		end
		return p97
	end
end
function v_u_22.popFlame(p100, p101) -- name: popFlame
	-- upvalues: (copy) v_u_7, (copy) v_u_8, (copy) v_u_90
	local v102 = p100.sounds.Pop
	if v102 then
		v102 = p100.sounds.Pop.Parent
	end
	if v102 then
		local v103 = p100.model
		local v104
		if v_u_7.popTune(v103, "Flame") ~= nil then
			v104 = v_u_7.POP_FLAME_BASE
		else
			if v103 then
				v103 = v103:GetAttribute("ExhaustPopFlameSize")
			end
			v104 = (typeof(v103) ~= "number" and 1 or v103) * ((p100.pipe or v_u_8).flameSize or 1)
		end
		if not p100.flame or (p100.flame.Parent ~= v102 or p100.flameScale ~= v104) then
			if p100.flame then
				p100.flame:Destroy()
				p100.flash:Destroy()
			end
			local v105, v106 = v_u_90(v102, v104)
			p100.flame = v105
			p100.flash = v106
			p100.flameScale = v104
		end
		local v107 = p100.flame
		local v108 = (5 + math.random(0, 3)) * p101
		local v109 = math.round(v108)
		v107:Emit((math.max(3, v109)))
		local v_u_110 = p100.flash
		v_u_110.Brightness = 6 * p101
		v_u_110.Enabled = true
		task.delay(0.08, function()
			-- upvalues: (copy) v_u_110
			if v_u_110.Parent then
				v_u_110.Enabled = false
			end
		end)
	end
end
function v_u_22.rattle(p_u_111, p112, p_u_113) -- name: rattle
	-- upvalues: (copy) v_u_8, (copy) v_u_7, (copy) v_u_2
	local v114 = (not p_u_111.exhaustCfg and 1 or p_u_111.exhaustCfg.pops) * (p_u_111.pipe or v_u_8).pops
	local v115 = v_u_7.popTune(p_u_111.model, "Amount") / 100
	local v_u_116 = v_u_7.popTune(p_u_111.model, "Rate") / 100
	local v117 = p_u_111.pipe
	if not v117 then
		local v118 = p_u_111.model
		v117 = v_u_7.exhaustSound(v118:GetAttribute("PartExhaustSound")) or v_u_8
	end
	local v119 = v117.backfire
	if v119 then
		v119 = v_u_7.EXHAUST_BACKFIRE.ExhaustPopDelay
	end
	if v119 == nil or v119 == false then
		v119 = p_u_111.model:GetAttribute("ExhaustPopDelay")
	end
	local v_u_120, v_u_121
	if typeof(v119) == "NumberRange" then
		v_u_120 = v119.Min
		v_u_121 = v119.Max
	else
		v_u_120 = 0.1
		v_u_121 = 0.2
	end
	local v122 = p_u_111.pipe
	if not v122 then
		local v123 = p_u_111.model
		v122 = v_u_7.exhaustSound(v123:GetAttribute("PartExhaustSound")) or v_u_8
	end
	local v124 = v122.backfire
	if v124 then
		v124 = v_u_7.EXHAUST_BACKFIRE.ExhaustPopBurst
	end
	if v124 == nil or v124 == false then
		v124 = p_u_111.model:GetAttribute("ExhaustPopBurst")
	end
	local v_u_125, v_u_126
	if typeof(v124) == "NumberRange" then
		v_u_125 = v124.Min
		v_u_126 = v124.Max
	else
		v_u_125 = 2
		v_u_126 = 6
	end
	local v127 = p_u_111.pipe
	if not v127 then
		local v128 = p_u_111.model
		v127 = v_u_7.exhaustSound(v128:GetAttribute("PartExhaustSound")) or v_u_8
	end
	local v129 = v127.backfire
	if v129 then
		v129 = v_u_7.EXHAUST_BACKFIRE.ExhaustPopRapid
	end
	if v129 == nil or v129 == false then
		v129 = p_u_111.model:GetAttribute("ExhaustPopRapid")
	end
	local v_u_130, v_u_131
	if typeof(v129) == "NumberRange" then
		v_u_130 = v129.Min
		v_u_131 = v129.Max
	else
		v_u_131 = 0.12
		v_u_130 = 0.05
	end
	local v132 = p_u_111.pipe
	if not v132 then
		local v133 = p_u_111.model
		v132 = v_u_7.exhaustSound(v133:GetAttribute("PartExhaustSound")) or v_u_8
	end
	local v134 = v132.backfire
	if v134 then
		v134 = v_u_7.EXHAUST_BACKFIRE.ExhaustPopGap
	end
	if v134 == nil or v134 == false then
		v134 = p_u_111.model:GetAttribute("ExhaustPopGap")
	end
	local v_u_135, v_u_136
	if typeof(v134) == "NumberRange" then
		v_u_135 = v134.Min
		v_u_136 = v134.Max
	else
		v_u_136 = 0.3
		v_u_135 = 0.1
	end
	local v137 = p_u_111.pipe
	if not v137 then
		local v138 = p_u_111.model
		v137 = v_u_7.exhaustSound(v138:GetAttribute("PartExhaustSound")) or v_u_8
	end
	local v139 = v137.backfire
	if v139 then
		v139 = v_u_7.EXHAUST_BACKFIRE.ExhaustCrackleTime
	end
	if v139 == nil or v139 == false then
		v139 = p_u_111.model:GetAttribute("ExhaustCrackleTime")
	end
	local v140, v141
	if typeof(v139) == "NumberRange" then
		v140 = v139.Min
		v141 = v139.Max
	else
		v141 = 2.8
		v140 = 0.6
	end
	local v142 = p_u_111.pipe
	if not v142 then
		local v143 = p_u_111.model
		v142 = v_u_7.exhaustSound(v143:GetAttribute("PartExhaustSound")) or v_u_8
	end
	local v144 = v142.backfire
	if v144 then
		v144 = v_u_7.EXHAUST_BACKFIRE.ExhaustPopPitch
	end
	if v144 == nil or v144 == false then
		v144 = p_u_111.model:GetAttribute("ExhaustPopPitch")
	end
	local v_u_145, v_u_146
	if typeof(v144) == "NumberRange" then
		v_u_145 = v144.Min
		v_u_146 = v144.Max
	else
		v_u_146 = 1.12
		v_u_145 = 0.92
	end
	local v147 = p_u_111.pipe
	if not v147 then
		local v148 = p_u_111.model
		v147 = v_u_7.exhaustSound(v148:GetAttribute("PartExhaustSound")) or v_u_8
	end
	local v149 = v147.backfire
	if v149 then
		v149 = v_u_7.EXHAUST_BACKFIRE.ExhaustPopVolume
	end
	if v149 == nil or v149 == false then
		v149 = p_u_111.model:GetAttribute("ExhaustPopVolume")
	end
	local v_u_150, v_u_151
	if typeof(v149) == "NumberRange" then
		v_u_150 = v149.Min
		v_u_151 = v149.Max
	else
		v_u_151 = 1
		v_u_150 = 0.6
	end
	local v152 = p_u_111.pipe
	if not v152 then
		local v153 = p_u_111.model
		v152 = v_u_7.exhaustSound(v153:GetAttribute("PartExhaustSound")) or v_u_8
	end
	local v154 = v152.backfire
	if v154 then
		v154 = v_u_7.EXHAUST_BACKFIRE.ExhaustCrackleRate
	end
	if v154 == nil or v154 == false then
		v154 = p_u_111.model:GetAttribute("ExhaustCrackleRate")
	end
	local v155 = (p112 or 0) * (typeof(v154) ~= "number" and 0.9 or v154) * (0.8 + math.random() * 0.4) * v114 * v115
	local v156 = v140 * v115
	local v157 = v141 * v115
	local v_u_158 = math.clamp(v155, v156, v157)
	local v_u_159, v_u_160 = p_u_111:popLoudness()
	p_u_111.popRun = (p_u_111.popRun or 0) + 1
	local v_u_161 = p_u_111.popRun
	task.spawn(function()
		-- upvalues: (copy) v_u_120, (copy) v_u_121, (copy) p_u_111, (copy) v_u_161, (copy) v_u_158, (copy) v_u_125, (copy) v_u_126, (copy) p_u_113, (copy) v_u_145, (copy) v_u_146, (copy) v_u_160, (copy) v_u_150, (copy) v_u_151, (copy) v_u_159, (ref) v_u_2, (copy) v_u_130, (copy) v_u_131, (copy) v_u_116, (copy) v_u_135, (copy) v_u_136
		task.wait(v_u_120 + math.random() * (v_u_121 - v_u_120))
		local v162 = os.clock()
		local v163 = true
		while p_u_111.popRun == v_u_161 and (not p_u_111.wasThrottle and p_u_111.engineOn) do
			local v164 = (os.clock() - v162) / v_u_158
			if v164 >= 1 then
				break
			end
			local v165 = (v_u_125 + math.random() * (v_u_126 - v_u_125)) * (1 - 0.5 * v164)
			local v166 = math.round(v165)
			for _ = 1, math.max(1, v166) do
				if p_u_111.popRun ~= v_u_161 and true or (p_u_111.wasThrottle or not p_u_111.engineOn) then
					return
				end
				local v167 = v163 or math.random() < 0.12
				local v168 = (1 - 0.5 * v164) * (v167 and 1.2 or 1)
				local v169 = p_u_111:popFire(v167 or math.random() < 0.45)
				local v170 = p_u_113:Clone()
				v170.PlaybackSpeed = (v_u_145 + math.random() * (v_u_146 - v_u_145)) * (v167 and 0.9 or 1) * (v169 and v_u_160 > 1 and 0.85 or 1)
				local v171 = (v_u_150 + math.random() * (v_u_151 - v_u_150)) * v168 * v_u_159 * (not v169 and 1 or v_u_160)
				v170.Volume = math.min(10, v171)
				v170.Parent = p_u_113.Parent
				v170:Play()
				v_u_2:AddItem(v170, 2)
				if v169 then
					p_u_111:popFlame((math.min(v168, 1)))
				end
				task.wait((v_u_130 + math.random() * (v_u_131 - v_u_130)) / v_u_116)
				v163 = false
			end
			task.wait((v_u_135 + math.random() * (v_u_136 - v_u_135)) * (1 + v164) / v_u_116)
		end
	end)
end
function v_u_22.crackle(p_u_172, p173, p174) -- name: crackle
	-- upvalues: (copy) v_u_7, (copy) v_u_8, (copy) v_u_14, (copy) v_u_16, (copy) v_u_18, (copy) v_u_17, (copy) v_u_2
	local v_u_175 = p_u_172.sounds.Pop
	if v_u_175 then
		if v_u_7.noPops(p_u_172.model) then
			return
		elseif p_u_172.model:GetAttribute("PartEngineSound") == nil or (v_u_7.popTuneOn(p_u_172.model) or v_u_7.popTuneBuiltIn(p_u_172.model)) then
			local v176 = v_u_7.popTune(p_u_172.model, "Chance")
			if v176 >= 100 or v176 > math.random() * 100 then
				if not p173 then
					local v177 = p_u_172.pipe
					if not v177 then
						local v178 = p_u_172.model
						v177 = v_u_7.exhaustSound(v178:GetAttribute("PartExhaustSound")) or v_u_8
					end
					local v179 = v177.backfire
					if v179 then
						v179 = v_u_7.EXHAUST_BACKFIRE.ExhaustPopStyle
					end
					if v179 == nil or v179 == false then
						v179 = p_u_172.model:GetAttribute("ExhaustPopStyle")
					end
					if v179 == "Rattle" then
						p_u_172:rattle(p174, v_u_175)
						return
					end
				end
				local v180 = (not p_u_172.exhaustCfg and 1 or p_u_172.exhaustCfg.pops) * (p_u_172.pipe or v_u_8).pops
				local v181 = v_u_14
				local v182 = typeof(v181(p_u_172, "ExhaustPopSpacing")) == "NumberRange"
				local v183 = v_u_16[1]
				local v184 = v_u_16[2]
				local v185 = p_u_172.pipe
				if not v185 then
					local v186 = p_u_172.model
					v185 = v_u_7.exhaustSound(v186:GetAttribute("PartExhaustSound")) or v_u_8
				end
				local v187 = v185.backfire
				if v187 then
					v187 = v_u_7.EXHAUST_BACKFIRE.ExhaustPopCount
				end
				if v187 == nil or v187 == false then
					v187 = p_u_172.model:GetAttribute("ExhaustPopCount")
				end
				if typeof(v187) == "NumberRange" then
					v183 = v187.Min
					v184 = v187.Max
				end
				local v_u_188 = v_u_18[1]
				local v_u_189 = v_u_18[2]
				local v190 = p_u_172.pipe
				if not v190 then
					local v191 = p_u_172.model
					v190 = v_u_7.exhaustSound(v191:GetAttribute("PartExhaustSound")) or v_u_8
				end
				local v192 = v190.backfire
				if v192 then
					v192 = v_u_7.EXHAUST_BACKFIRE.ExhaustPopSpacing
				end
				if v192 == nil or v192 == false then
					v192 = p_u_172.model:GetAttribute("ExhaustPopSpacing")
				end
				if typeof(v192) == "NumberRange" then
					v_u_188 = v192.Min
					v_u_189 = v192.Max
				end
				local v193 = p_u_172.pipe
				if not v193 then
					local v194 = p_u_172.model
					v193 = v_u_7.exhaustSound(v194:GetAttribute("PartExhaustSound")) or v_u_8
				end
				local v195 = v193.backfire
				if v195 then
					v195 = v_u_7.EXHAUST_BACKFIRE.ExhaustPopDelay
				end
				if v195 == nil or v195 == false then
					v195 = p_u_172.model:GetAttribute("ExhaustPopDelay")
				end
				local v_u_196, v_u_197
				if typeof(v195) == "NumberRange" then
					v_u_196 = v195.Min
					v_u_197 = v195.Max
				else
					v_u_196 = 0
					v_u_197 = 0
				end
				local v198 = p_u_172.pipe
				if not v198 then
					local v199 = p_u_172.model
					v198 = v_u_7.exhaustSound(v199:GetAttribute("PartExhaustSound")) or v_u_8
				end
				local v200 = v198.backfire
				if v200 then
					v200 = v_u_7.EXHAUST_BACKFIRE.ExhaustPopPitch
				end
				if v200 == nil or v200 == false then
					v200 = p_u_172.model:GetAttribute("ExhaustPopPitch")
				end
				local v_u_201, v_u_202
				if typeof(v200) == "NumberRange" then
					v_u_201 = v200.Min
					v_u_202 = v200.Max
				else
					v_u_202 = 1.25
					v_u_201 = 0.85
				end
				local v_u_203 = v_u_17[1]
				local v_u_204 = v_u_17[2]
				local v205 = p_u_172.pipe
				if not v205 then
					local v206 = p_u_172.model
					v205 = v_u_7.exhaustSound(v206:GetAttribute("PartExhaustSound")) or v_u_8
				end
				local v207 = v205.backfire
				if v207 then
					v207 = v_u_7.EXHAUST_BACKFIRE.ExhaustPopVolume
				end
				if v207 == nil or v207 == false then
					v207 = p_u_172.model:GetAttribute("ExhaustPopVolume")
				end
				if typeof(v207) == "NumberRange" then
					v_u_203 = v207.Min
					v_u_204 = v207.Max
				end
				local v208 = v_u_7.popTune(p_u_172.model, "Amount") / 100
				local v_u_209 = v_u_7.popTune(p_u_172.model, "Rate") / 100
				local v_u_210
				if v182 and p173 then
					v_u_210 = 1
				else
					local v211 = math.random(math.round(v183), (math.round(v184))) * v180 * v208
					local v212 = math.round(v211)
					v_u_210 = math.max(1, v212)
				end
				local v_u_213
				if v182 then
					v_u_213 = not p173
				else
					v_u_213 = v182
				end
				local v214 = p_u_172.pipe
				if not v214 then
					local v215 = p_u_172.model
					v214 = v_u_7.exhaustSound(v215:GetAttribute("PartExhaustSound")) or v_u_8
				end
				local v216 = v214.backfire
				if v216 then
					v216 = v_u_7.EXHAUST_BACKFIRE.ExhaustPopPerSecond
				end
				if v216 == nil or v216 == false then
					v216 = p_u_172.model:GetAttribute("ExhaustPopPerSecond")
				end
				if v_u_213 and (typeof(v216) == "number" and p174) then
					local v217 = p174 * v216 * (0.8 + math.random() * 0.4) * v180 * v208
					local v218 = math.round(v217)
					local v219 = v183 * v208
					local v220 = math.round(v219)
					local v221 = math.max(1, v220)
					local v222 = v184 * v208
					local v223 = math.round(v222)
					local v224 = math.max(1, v223)
					v_u_210 = math.clamp(v218, v221, v224)
				end
				local v_u_225
				if v182 then
					local v226 = p_u_172.pipe
					if not v226 then
						local v227 = p_u_172.model
						v226 = v_u_7.exhaustSound(v227:GetAttribute("PartExhaustSound")) or v_u_8
					end
					local v228 = v226.backfire
					if v228 then
						v228 = v_u_7.EXHAUST_BACKFIRE.ExhaustPopFade
					end
					if v228 == nil or v228 == false then
						v228 = p_u_172.model:GetAttribute("ExhaustPopFade")
					end
					v_u_225 = typeof(v228) ~= "number" and 1 or v228
				else
					v_u_225 = 1
				end
				local v_u_229
				if v182 then
					local v230 = p_u_172.pipe
					if not v230 then
						local v231 = p_u_172.model
						v230 = v_u_7.exhaustSound(v231:GetAttribute("PartExhaustSound")) or v_u_8
					end
					local v232 = v230.backfire
					if v232 then
						v232 = v_u_7.EXHAUST_BACKFIRE.ExhaustPopSpacingGrow
					end
					if v232 == nil or v232 == false then
						v232 = p_u_172.model:GetAttribute("ExhaustPopSpacingGrow")
					end
					v_u_229 = typeof(v232) ~= "number" and 0 or v232
				else
					v_u_229 = 0
				end
				local v_u_233, v_u_234 = p_u_172:popLoudness()
				p_u_172.popRun = (p_u_172.popRun or 0) + 1
				local v_u_235 = p_u_172.popRun
				task.spawn(function()
					-- upvalues: (copy) v_u_213, (copy) v_u_196, (copy) v_u_197, (ref) v_u_210, (copy) p_u_172, (copy) v_u_235, (copy) v_u_225, (copy) v_u_175, (copy) v_u_201, (copy) v_u_202, (copy) v_u_234, (copy) v_u_203, (copy) v_u_204, (copy) v_u_233, (ref) v_u_2, (copy) v_u_188, (copy) v_u_189, (copy) v_u_229, (copy) v_u_209
					if v_u_213 then
						task.wait(v_u_196 + math.random() * (v_u_197 - v_u_196))
					end
					for v236 = 1, v_u_210 do
						if v_u_213 and (p_u_172.popRun ~= v_u_235 or (p_u_172.wasThrottle or not p_u_172.engineOn)) then
							break
						end
						local v237 = v_u_225 ^ (v236 - 1)
						local v238 = p_u_172:popFire(v236 == 1 and true or math.random() < 0.75)
						local v239 = v_u_175:Clone()
						v239.PlaybackSpeed = (v_u_201 + math.random() * (v_u_202 - v_u_201)) * (v238 and v_u_234 > 1 and 0.85 or 1)
						local v240 = (v_u_203 + math.random() * (v_u_204 - v_u_203)) * v237 * v_u_233 * (not v238 and 1 or v_u_234)
						v239.Volume = math.min(10, v240)
						v239.Parent = v_u_175.Parent
						v239:Play()
						v_u_2:AddItem(v239, 2)
						if v238 then
							p_u_172:popFlame(v237)
						end
						task.wait((v_u_188 + math.random() * (v_u_189 - v_u_188)) * (1 + (v236 - 1) * v_u_229) / v_u_209)
					end
				end)
			end
		else
			return
		end
	else
		return
	end
end
function v_u_22.loopFade(p241, p242, p243, p244, p245, p246) -- name: loopFade
	-- upvalues: (copy) v_u_8
	local v247 = p241.sounds[p242]
	p241.twins = p241.twins or {}
	local v248 = p241.twins[p242]
	if p243 <= 0 or not (v247 and v247.PlaybackRegionsEnabled) then
		if v248 then
			v248:Destroy()
			p241.twins[p242] = nil
		end
		return 1
	end
	if not v248 or (not v248.Parent or v248.SoundId ~= v247.SoundId) then
		if v248 then
			v248:Destroy()
		end
		v248 = v247:Clone()
		v248.Name = v247.Name .. "Twin"
		v248.Volume = 0
		v248.Parent = v247.Parent
		v248:Stop()
		p241.twins[p242] = v248
	end
	if not p246 then
		v248:Stop()
		return 1
	end
	local v249 = v247.LoopRegion
	local v250 = v249.Min
	local v251 = v249.Max
	local v252 = v247.TimeLength
	local v253 = math.min(v251, v252)
	local v254 = v247.PlaybackSpeed
	local v255 = math.max(v254, 0.05)
	local v256 = (v253 - v247.TimePosition) / v255
	local v257 = 1
	if v247.IsPlaying and (v253 - v250 > 2 * p243 * v255 and (v256 > 0 and v256 <= p243)) then
		if not v248.IsPlaying then
			v248.PlaybackRegionsEnabled = true
			v248.LoopRegion = v247.LoopRegion
			v248.Looped = v247.Looped
			for _, v258 in v247:GetChildren() do
				local v259 = v248:FindFirstChild(v258.Name)
				if v259 and v258:IsA("DistortionSoundEffect") then
					v259.Level = v258.Level
				else
					if not (v259 and v258:IsA("EqualizerSoundEffect")) then
						continue
					end
					local v260 = v258.LowGain
					local v261 = v258.MidGain
					local v262 = v258.HighGain
					v259.LowGain = v260
					v259.MidGain = v261
					v259.HighGain = v262
				end
			end
			v248.TimePosition = v250 + (p243 - v256) * v255
			v248:Play()
		end
		v257 = v256 / p243
	elseif v248.IsPlaying then
		if v247.TimePosition >= v250 - 0.01 and v247.TimePosition < v250 + 0.5 then
			v247:Stop()
			local v263 = v248.Name
			local v264 = v247.Name
			v247.Name = v263
			v248.Name = v264
			local v265 = p241.sounds
			local v266 = p241.twins
			v265[p242] = v248
			v266[p242] = v247
			return 1
		end
		v248:Stop()
	end
	local v267 = p241.model
	if v267 then
		v267 = v267:GetAttribute("EnginePitch")
	end
	v248.PlaybackSpeed = p244 * (typeof(v267) ~= "number" and 1 or v267)
	local v268 = 1 - v257
	local v269 = p245 * math.sqrt(v268)
	local v270 = p241.model
	if v270 then
		v270 = v270:GetAttribute("ExhaustVolume")
	end
	v248.Volume = v269 * (typeof(v270) ~= "number" and 1 or v270) * (not p241.exhaustCfg and 1 or p241.exhaustCfg.volume) * (p241.pipe or v_u_8).volume
	return math.sqrt(v257)
end
function v_u_22.update(p_u_271, p272) -- name: update
	-- upvalues: (copy) v_u_3, (copy) v_u_15, (copy) v_u_6, (copy) v_u_5, (copy) v_u_4, (copy) v_u_8
	if p_u_271.chassis and p_u_271.seat then
		local v_u_273 = p_u_271.engineOn and os.clock() >= p_u_271.loopsAt and 1 or 0
		p_u_271.fade = p_u_271.fade + (v_u_273 - p_u_271.fade) * v_u_3.alpha(p_u_271.fade < v_u_273 and 3 or 4, p272)
		local v274 = not p_u_271.seat.Occupant and 0 or p_u_271.seat.ThrottleFloat
		local v275 = p_u_271.chassis.Anchored and 0 or p_u_271.chassis.AssemblyLinearVelocity:Dot(p_u_271.chassis.CFrame.LookVector)
		local v276 = v_u_3.toKmh
		local v277 = math.max(0, v276(v275))
		local v278 = v274 > 0
		if v278 and not p_u_271.wasThrottle then
			p_u_271.throttleFrom = os.clock()
			p_u_271.decelFrom = nil
			local v279 = p_u_271.sounds.EngineHigh
			if v279 and p_u_271.model:GetAttribute("RevFromStart") == true then
				v279.TimePosition = 0
				local v280 = p_u_271.twins
				if v280 then
					v280 = p_u_271.twins.EngineHigh
				end
				if v280 then
					v280:Stop()
				end
			end
		end
		if p_u_271.wasThrottle and (not v278 and (p_u_271.engineOn and (p_u_271.model:GetAttribute("RevDecel") == true and p_u_271.rpm > 2700))) then
			p_u_271.decelFrom = p_u_271.rpm
		end
		if p_u_271.wasThrottle and (not v278 and (p_u_271.engineOn and p_u_271.rpm > 4500)) then
			p_u_271:crackle(false, os.clock() - (p_u_271.throttleFrom or os.clock()))
		end
		p_u_271.wasThrottle = v278
		local v281 = v_u_3.toKmh(p_u_271.model:GetAttribute("MaxSpeed") or 100)
		local v282 = v_u_15.soundSetting(p_u_271.model, "Rev")
		local v283 = p_u_271.model
		if v283 then
			v283 = v283:GetAttribute("ThrottleRpm")
		end
		local v284 = (typeof(v283) ~= "number" and 3600 or v283) + (v282 - 1) * 1800
		local v285 = v282 ^ (-0.8)
		local v286 = v277 / v281
		if v286 < 1 then
			v286 = v286 ^ v285
		end
		local v287
		if v278 then
			v287 = v284 + (8600 - v284) * v286
		else
			v287 = v277 * 18 + 1700
		end
		local v288 = math.min(v287, 9000)
		local v289 = p_u_271.gears
		if v289 then
			v289 = v_u_6.gear(p_u_271.model)
		end
		p_u_271.noCut = false
		local v290 = p_u_271.model:GetAttribute("NoRevCut") == true
		local v291
		if v289 then
			if os.clock() - p_u_271.gearTopAt > 0.5 then
				p_u_271.gearTopAt = os.clock()
				local v292 = p_u_271.model:GetAttribute("Tuck") == true
				p_u_271.gearTop = v_u_3.toKmh(v_u_6.topSpeed(p_u_271.model, not v292 and 1 or v_u_3.TUCK_SPEED_BONUS))
			end
			local v293 = v_u_6.revs(v277, p_u_271.gearTop, p_u_271.gears, v289)
			if v278 then
				v293 = math.clamp(v293, 0, 1) ^ v285
			end
			local v294 = 1700 + 6900 * v293
			if v278 and v289 == 1 then
				v294 = math.max(v294, v284)
			end
			local v295 = v_u_6.noTopCut(p_u_271.model, v289)
			if v295 and v278 then
				p_u_271.noCut = true
				v294 = 9000 * (0.93 + 0.12 * v293)
			end
			if v278 then
				if v293 > 0.995 then
					v291 = not v295
					if v291 then
						v291 = not v290
					end
				else
					v291 = false
				end
			else
				v291 = v278
			end
			v288 = v291 and 9600 or v294
			if p_u_271.shownGear and v289 ~= p_u_271.shownGear then
				if p_u_271.shownGear < v289 and (p_u_271.engineOn and p_u_271.rpm > 4500) then
					p_u_271:crackle(true)
				end
				p_u_271.rpm = p_u_271.rpm + (v288 - p_u_271.rpm) * 0.7
			end
			p_u_271.shownGear = v289
		else
			v291 = false
		end
		local v296 = v_u_3.freeRev(p_u_271.model, p_u_271.seat)
		if v296 > 0 then
			v288 = 1700 + ((v290 and 8750 or 9600) - 1700) * v296
		end
		if v296 > 0 and p_u_271.model:GetAttribute("OnDyno") == true then
			local v297 = v_u_5.upgradeScales(p_u_271.model)
			local v298 = p_u_271.rpm + 730 * v297 * v296 * p272
			p_u_271.rpm = math.min(v298, 9001)
		else
			local v299
			if v296 > 0 then
				v299 = 5
			elseif v291 then
				v299 = 14
			elseif v278 then
				local v300 = p_u_271.model
				if v300 then
					v300 = v300:GetAttribute("ThrottleRevRate")
				end
				v299 = typeof(v300) ~= "number" and 3.5 or v300
			else
				local v301 = p_u_271.model
				if v301 then
					v301 = v301:GetAttribute("DecelRevRate")
				end
				v299 = typeof(v301) ~= "number" and 2.2 or v301
			end
			if p_u_271.rpm < v288 and not v291 then
				v299 = v299 * v282
			end
			p_u_271.rpm = p_u_271.rpm + (v288 - p_u_271.rpm) * v_u_3.alpha(v299, p272)
		end
		if (v296 > 0 or v291) and (p_u_271.rpm >= 9000 and not v290) then
			p_u_271.rpm = 8350
		end
		if v296 > 0 or v291 then
			if p_u_271.rpm > 8100 then
				v291 = not v290
			else
				v291 = false
			end
		end
		p_u_271.limiterLevel = p_u_271.limiterLevel + ((v291 and 1 or 0) - p_u_271.limiterLevel) * v_u_3.alpha(v291 and 12 or 6, p272)
		local v302 = 1 + (v_u_15.idleSpeed(p_u_271.model) - 1) * (1 - v_u_3.smoothstep(1700, 3500, p_u_271.rpm))
		p_u_271.idleFactor = v302
		v_u_4[p_u_271.model] = not p_u_271.engineOn and 0 or p_u_271.rpm * v302
		local v303 = p_u_271.model
		if v303 then
			v303 = v303:GetAttribute("ReleaseFade")
		end
		local v304 = typeof(v303) ~= "number" and 0 or v303
		local v305
		if v304 > 0 then
			if v278 or v296 > 0 then
				p_u_271.releaseLevel = 1
			else
				local v306 = (p_u_271.releaseLevel or 0) - p272 / v304
				p_u_271.releaseLevel = math.max(0, v306)
			end
			v305 = p_u_271.releaseLevel
		else
			v305 = 1
		end
		local v307 = v_u_3.smoothstep(2600, 4200, p_u_271.rpm)
		local v308 = (p_u_271.rpm - 1700) / 6900
		local v309 = math.clamp(v308, 0, 1)
		local v310 = v309 ^ 1.6 * 0.9 + 0.1
		local v311 = v278 and 1 or 0.55
		local v_u_312 = p_u_271.fade > 0.01
		local function v318(p313, p314, p315) -- name: drive
			-- upvalues: (copy) p_u_271, (ref) v_u_8, (copy) v_u_312, (copy) v_u_273
			if p313 then
				local v316 = p_u_271.model
				if v316 then
					v316 = v316:GetAttribute("EnginePitch")
				end
				p313.PlaybackSpeed = p314 * (typeof(v316) ~= "number" and 1 or v316)
				local v317 = p_u_271.model
				if v317 then
					v317 = v317:GetAttribute("ExhaustVolume")
				end
				p313.Volume = p315 * (typeof(v317) ~= "number" and 1 or v317) * (not p_u_271.exhaustCfg and 1 or p_u_271.exhaustCfg.volume) * (p_u_271.pipe or v_u_8).volume
				if v_u_312 and not p313.IsPlaying then
					if p313.PlaybackRegionsEnabled then
						p313.TimePosition = p313.LoopRegion.Min
					end
					p313:Play()
				elseif not v_u_312 and (v_u_273 == 0 and p313.IsPlaying) then
					p313:Stop()
				end
			else
				return
			end
		end
		if p_u_271.kit then
			if v296 > 0 then
				v274 = v296
			end
			p_u_271:updateKit(math.clamp(v274, 0, 1), v_u_312, v_u_273)
		else
			local v319 = p_u_271.sounds.Limiter
			local v320 = not v319 and 1 or 1 - 0.6 * p_u_271.limiterLevel
			local v321
			if p_u_271.decelFrom and not v278 then
				local v322 = p_u_271.rpm - 1700
				local v323 = p_u_271.decelFrom - 1700
				local v324 = v322 / math.max(v323, 1)
				v321 = math.clamp(v324, 0, 1)
				if v321 < 0.02 or not p_u_271.engineOn then
					p_u_271.decelFrom = nil
				end
			else
				v321 = 0
			end
			local v325
			if p_u_271.decelFrom == nil then
				v325 = false
			else
				v325 = not v278
			end
			local v326 = p_u_271.sounds.EngineLow
			local v327 = 1 + (p_u_271.rpm - 1700) * 0.00025
			local v328 = p_u_271.model
			if v328 then
				v328 = v328:GetAttribute("EngineLowPitch")
			end
			local v329 = v327 * (typeof(v328) ~= "number" and 1 or v328) * v302
			local v330 = 0.75
			local v331 = p_u_271.model
			if v331 then
				v331 = v331:GetAttribute("EngineLowGain")
			end
			local v332 = v330 * (typeof(v331) ~= "number" and 1 or v331)
			local v333
			if v325 then
				v333 = v321
			else
				v333 = v307 * v305
			end
			v318(v326, v329, v332 * (1 - v333) * v311 * p_u_271.fade * v320)
			local v334 = p_u_271.model:GetAttribute("RevNaturalPitch") == true and 1 or v309 * 0.5 + 0.8
			local v335 = 1.6
			local v336 = p_u_271.model
			if v336 then
				v336 = v336:GetAttribute("EngineHighGain")
			end
			local v337 = v335 * (typeof(v336) ~= "number" and 1 or v336) * v310 * v307 * v311 * v305
			if v304 > 0 and v305 < 1 then
				v334 = v334 * (v305 * 0.15000000000000002 + 0.85)
			end
			if v325 then
				local v338 = p_u_271.model
				if v338 then
					v338 = v338:GetAttribute("DecelPitchMin")
				end
				local v339 = typeof(v338) ~= "number" and 0.6 or v338
				v334 = v334 * (v339 + (1 - v339) * v321)
				local v340 = 1.6
				local v341 = p_u_271.model
				if v341 then
					v341 = v341:GetAttribute("EngineHighGain")
				end
				local v342 = v340 * (typeof(v341) ~= "number" and 1 or v341)
				local v343 = p_u_271.model
				if v343 then
					v343 = v343:GetAttribute("DecelVolume")
				end
				v337 = v342 * (typeof(v343) ~= "number" and 0.8 or v343) * v321 ^ 0.7
			end
			local v344 = p_u_271.model
			if v344 then
				v344 = v344:GetAttribute("EngineHighPitch")
			end
			local v345 = v334 * (typeof(v344) ~= "number" and 1 or v344)
			local v346 = v337 * p_u_271.fade * v320
			local v347 = "EngineHigh"
			local v348 = p_u_271.model
			if v348 then
				v348 = v348:GetAttribute("RevLoopFade")
			end
			local v349 = p_u_271:loopFade(v347, typeof(v348) ~= "number" and 0 or v348, v345, v346, v_u_312)
			v318(p_u_271.sounds.EngineHigh, v345, v346 * v349)
			if v319 then
				local v350 = p_u_271.model
				if v350 then
					v350 = v350:GetAttribute("LimiterPitch")
				end
				v319.PlaybackSpeed = typeof(v350) ~= "number" and 1 or v350
				local v351 = 1.6
				local v352 = p_u_271.model
				if v352 then
					v352 = v352:GetAttribute("LimiterGain")
				end
				v319.Volume = v351 * (typeof(v352) ~= "number" and 1 or v352) * (not p_u_271.exhaustCfg and 1 or p_u_271.exhaustCfg.volume) * (p_u_271.pipe or v_u_8).volume * p_u_271.limiterLevel * p_u_271.fade
				if v_u_312 then
					v_u_312 = p_u_271.limiterLevel > 0.02
				end
				if v_u_312 and not v319.IsPlaying then
					v319:Play()
				elseif not v_u_312 and v319.IsPlaying then
					v319:Stop()
				end
			end
		end
		v318(p_u_271.sounds.CvtWhine, v277 / 110 * 1.5 + 0.5, 0.12 * v_u_3.smoothstep(5, 40, v277) * p_u_271.fade)
	end
end
function v_u_22.updateKit(p353, p354, p355, p356) -- name: updateKit
	-- upvalues: (copy) v_u_8, (copy) v_u_19, (copy) v_u_20
	local v357 = p353.rpm / 9000
	local v358 = math.clamp(v357, 0, 1.1)
	local v359 = p353.rpm > 8700 and (p354 > 0.05 and not p353.noCut) and 0.5 or 1
	local v360 = p353.fade
	local v361 = p354 * v359
	local v362 = (1 - p354) * v359
	local v363
	if p353.noCut then
		v363 = 0
	else
		local v364 = v358 * 14 - 13
		local v365 = v361 * math.clamp(v364, 0, 1)
		v363 = math.max(v365, 0)
	end
	local v366 = v358 * 8 - 1
	local v367 = 1 - math.min(v366, 1)
	local v368 = {
		["Red"] = v363,
		["Idle"] = v367
	}
	local v369 = v358 * 11.25 - 6
	local v370 = v361 * math.clamp(v369, 0, 1) - v363 - v367
	v368.RevA = math.max(v370, 0)
	local v371 = v358 * 11.25 - 6
	local v372 = v361 * (1 - math.clamp(v371, 0, 1)) - v363
	v368.RevB = math.max(v372, 0)
	local v373 = v358 * 11.25 - 5
	local v374 = v362 * math.clamp(v373, 0, 1) - v363 - v367
	v368.RelA = math.max(v374, 0)
	local v375 = v358 * 11.25 - 5
	local v376 = v362 * (1 - math.clamp(v375, 0, 1)) - v363
	v368.RelB = math.max(v376, 0)
	local v377 = v358 * 28 - 4
	local v378 = math.clamp(v377, 0, 1)
	local v379 = v358 * 11.2 - 3
	local v380 = v378 - math.clamp(v379, 0, 1)
	v368.RmbA = math.max(v380, 0)
	local v381 = v358 * 11.2 - 3
	local v382 = math.clamp(v381, 0, 1)
	local v383 = v358 * 12.6 - 5
	local v384 = v382 - math.clamp(v383, 0, 1)
	v368.RmbB = math.max(v384, 0)
	local v385 = p353.kitSet
	local v386 = 4 * (tonumber(v385:GetAttribute("Volume")) or 1) * (not p353.exhaustCfg and 1 or p353.exhaustCfg.volume) * v360 * (p353.pipe or v_u_8).volume
	local v387 = tonumber(v385:GetAttribute("Pitch")) or 1
	for v388, v389 in p353.kit do
		local v390 = v_u_19[v388]
		local v391 = v390[1] + v390[2] * v358
		local v392 = v390[1]
		v389.PlaybackSpeed = math.max(v391, v392) * v387 * (v388 == "Idle" and (p353.idleFactor or 1) or 1)
		local v393 = v368[v388] * (v_u_20[v388] or 1) * v386
		v389.Volume = math.min(10, v393)
		if p355 and not v389.IsPlaying then
			v389:Play()
		else
			if p355 or (p356 ~= 0 or not v389.IsPlaying) then
				continue
			end
			v389:Stop()
		end
	end
end
function v_u_22.destroy(p394) -- name: destroy
	for _, v395 in p394.connections do
		v395:Disconnect()
	end
	for _, v396 in p394.sounds do
		v396:Destroy()
	end
	p394.sounds = {}
	for _, v397 in p394.twins or {} do
		v397:Destroy()
	end
	p394.twins = nil
	for _, v398 in p394.kit or {} do
		v398:Destroy()
	end
	p394.kit = nil
	if p394.horn then
		p394.horn:Destroy()
		p394.horn = nil
	end
end
return v_u_22