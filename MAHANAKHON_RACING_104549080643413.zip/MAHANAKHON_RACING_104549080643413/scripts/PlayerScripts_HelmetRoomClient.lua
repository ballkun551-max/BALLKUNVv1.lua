-- Path: Players/ygggggg55551/PlayerScripts/HelmetRoomClient
-- Class: LocalScript  true/Enum.RunContext.Legacy
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = require(game:GetService("ReplicatedStorage"):WaitForChild("NetSeal"))
local v_u_2 = game:GetService("ContextActionService")
local v_u_3 = game:GetService("GuiService")
local v4 = game:GetService("Players")
local v_u_5 = game:GetService("ProximityPromptService")
local v6 = game:GetService("ReplicatedStorage")
local v_u_7 = game:GetService("RunService")
local v_u_8 = game:GetService("TweenService")
local v_u_9 = game:GetService("UserInputService")
local v10 = require(v6:WaitForChild("GameShared"))
local v_u_11 = require(v6:WaitForChild("HelmetShared"))
local v12 = v6:WaitForChild("GameUI")
local v_u_13 = require(v12:WaitForChild("Theme"))
local v_u_14 = require(v12:WaitForChild("Toast"))
local v_u_15 = require(v12:WaitForChild("Icons"))
local v_u_16 = v4.LocalPlayer
local v_u_17 = v6:WaitForChild("Helmets")
local v_u_18 = v6:WaitForChild(v10.REMOTES):WaitForChild(v_u_11.REMOTE)
local v19 = v_u_13.isTouch()
local v_u_20 = {
	["HelmetRoom"] = true,
	["GameToast"] = true
}
local v_u_21 = v19 and 6.6 or 6
local v_u_22 = v19 and 2 or 1.8
local v_u_23 = {
	Enum.KeyCode.W,
	Enum.KeyCode.A,
	Enum.KeyCode.S,
	Enum.KeyCode.D,
	Enum.KeyCode.Up,
	Enum.KeyCode.Down,
	Enum.KeyCode.Left,
	Enum.KeyCode.Right,
	Enum.KeyCode.Space,
	Enum.KeyCode.Thumbstick1,
	Enum.KeyCode.ButtonA
}
local v_u_24 = v_u_13.screen("HelmetRoom", 30, v_u_16:WaitForChild("PlayerGui"))
v_u_24.Enabled = false
local function v33(p25, p26, p27, p28, p29) -- name: text
	-- upvalues: (copy) v_u_13
	local v30 = v_u_13.text({
		["Text"] = p26,
		["TextSize"] = p27 or 16,
		["TextColor3"] = p28 or v_u_13.TEXT,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["TextTruncate"] = Enum.TextTruncate.AtEnd,
		["Size"] = UDim2.new(1, 0, 0, (p27 or 16) + 6),
		["Parent"] = p25
	})
	for v31, v32 in p29 or {} do
		v30[v31] = v32
	end
	return v30
end
local v_u_34
if v19 then
	v_u_34 = Vector2.new(400, 510)
else
	v_u_34 = Vector2.new(440, 700)
end
local v35 = v_u_13.panel({
	["Name"] = "Panel",
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["AnchorPoint"] = Vector2.new(1, 0.5),
	["Position"] = UDim2.new(1, -16, 0.5, 0),
	["Size"] = UDim2.fromOffset(v_u_34.X, v_u_34.Y),
	["Parent"] = v_u_24
})
v35.UICorner.CornerRadius = UDim.new(0, 18)
local v_u_36 = v_u_13.new("UIScale", {
	["Parent"] = v35
})
local function v_u_42() -- name: fitPanel
	-- upvalues: (copy) v_u_36, (copy) v_u_13, (copy) v_u_3, (copy) v_u_34
	local v37 = workspace.CurrentCamera
	if v37 then
		local v38 = v37.ViewportSize
		local v39 = v_u_36
		local v40 = v_u_13.scaleFor(v38)
		local v41 = (v38.Y - v_u_3:GetGuiInset().Y - 24) / v_u_34.Y
		v39.Scale = math.min(v40, v41)
	end
end
local v43 = workspace.CurrentCamera
if v43 then
	local v44 = v43.ViewportSize
	local v45 = v_u_13.scaleFor(v44)
	local v46 = (v44.Y - v_u_3:GetGuiInset().Y - 24) / v_u_34.Y
	v_u_36.Scale = math.min(v45, v46)
end
if workspace.CurrentCamera then
	workspace.CurrentCamera:GetPropertyChangedSignal("ViewportSize"):Connect(v_u_42)
end
v_u_13.padding(v35, 14)
local v47 = v_u_13.new("Frame", {
	["Name"] = "Accent",
	["BackgroundColor3"] = nil,
	["BorderSizePixel"] = 0,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["BackgroundColor3"] = v_u_13.GRAD.gold[1],
	["AnchorPoint"] = Vector2.new(0.5, 0),
	["Position"] = UDim2.new(0.5, 0, 0, -14),
	["Size"] = UDim2.new(0.5, 0, 0, 3),
	["Parent"] = v35
})
v_u_13.new("UIGradient", {
	["Transparency"] = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(0.5, 0), NumberSequenceKeypoint.new(1, 1) }),
	["Parent"] = v47
})
v_u_13.header(v35, "person", "gold", "\224\184\171\224\185\137\224\184\173\224\184\135\224\184\165\224\184\173\224\184\135\224\184\171\224\184\161\224\184\167\224\184\129", "\224\185\128\224\184\165\224\184\183\224\184\173\224\184\129\224\185\129\224\184\154\224\184\154 \194\183 \224\185\128\224\184\165\224\184\183\224\184\173\224\184\129\224\184\170\224\184\181\224\184\138\224\184\180\224\184\165 \194\183 \224\184\129\224\184\148\224\184\151\224\184\181\224\185\136\224\184\138\224\184\180\224\184\165\224\184\171\224\184\153\224\185\137\224\184\178\224\185\128\224\184\158\224\184\183\224\185\136\224\184\173\224\185\128\224\184\155\224\184\180\224\184\148")
local v48 = v_u_13.closeButton(v35)
local v49 = v19 and 40 or 44
local v50 = v_u_13.new("Frame", {
	["BackgroundTransparency"] = 1,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["Position"] = UDim2.fromOffset(0, 58),
	["Size"] = UDim2.new(1, 0, 0, v49),
	["Parent"] = v35
})
local v51 = v19 and 92 or 104
local v_u_52 = v_u_13.new("Frame", {
	["BackgroundTransparency"] = 1,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["Position"] = UDim2.fromOffset(0, v49 + 58 + 10),
	["Size"] = UDim2.new(1, 0, 1, -(v49 + 58 + 10 + v51)),
	["Parent"] = v35
})
local function v55(p53) -- name: page
	-- upvalues: (copy) v_u_13, (copy) v_u_52
	local v54 = v_u_13.new("ScrollingFrame", {
		["Name"] = nil,
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["CanvasSize"] = nil,
		["AutomaticCanvasSize"] = nil,
		["ScrollingDirection"] = nil,
		["ScrollBarThickness"] = 4,
		["Visible"] = false,
		["Parent"] = nil,
		["Name"] = p53,
		["Size"] = UDim2.fromScale(1, 1),
		["CanvasSize"] = UDim2.new(),
		["AutomaticCanvasSize"] = Enum.AutomaticSize.Y,
		["ScrollingDirection"] = Enum.ScrollingDirection.Y,
		["Parent"] = v_u_52
	})
	v_u_13.new("UIPadding", {
		["PaddingRight"] = UDim.new(0, 6),
		["PaddingBottom"] = UDim.new(0, 8),
		["PaddingTop"] = UDim.new(0, 2),
		["PaddingLeft"] = UDim.new(0, 2),
		["Parent"] = v54
	})
	v_u_13.new("UIListLayout", {
		["Padding"] = UDim.new(0, 10),
		["SortOrder"] = Enum.SortOrder.LayoutOrder,
		["Parent"] = v54
	})
	return v54
end
local v_u_56 = v55("Full")
local v_u_57 = v55("Index")
local v58 = v_u_13.new("Frame", {
	["BackgroundTransparency"] = 1,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["AnchorPoint"] = Vector2.new(0, 1),
	["Position"] = UDim2.fromScale(0, 1),
	["Size"] = UDim2.new(1, 0, 0, v51),
	["Parent"] = v35
})
local v59 = v19 and 32 or 36
local v60 = v_u_13.new("Frame", {
	["BackgroundColor3"] = nil,
	["BackgroundTransparency"] = 0.3,
	["BorderSizePixel"] = 0,
	["Size"] = nil,
	["Parent"] = nil,
	["BackgroundColor3"] = v_u_13.CARD_DARK,
	["Size"] = UDim2.new(1, 0, 0, v59),
	["Parent"] = v58
})
v_u_13.corner(v60, v59 / 2)
v_u_13.border(v60, Color3.new(1, 1, 1), 0.9, 1)
local v_u_61 = v_u_15.make("check", v_u_13.GREEN_TEXT, 18)
v_u_61.AnchorPoint = Vector2.new(0, 0.5)
v_u_61.Position = UDim2.new(0, 12, 0.5, 0)
v_u_61.Parent = v60
local v_u_62 = v33(v60, "", 15, v_u_13.TEXT_DIM, {
	["FontFace"] = v_u_13.FONT_BOLD,
	["AnchorPoint"] = Vector2.new(0, 0.5),
	["Position"] = UDim2.new(0, 38, 0.5, 0),
	["Size"] = UDim2.new(0.58, -38, 0, 20)
})
local v_u_63 = v33(v60, "\224\185\129\224\184\149\224\184\176\224\184\138\224\184\180\224\184\165\224\184\154\224\184\153\224\184\171\224\184\177\224\184\167 = \224\185\128\224\184\155\224\184\180\224\184\148\224\184\138\224\184\180\224\184\165", 13, Color3.fromRGB(255, 214, 120), {
	["TextXAlignment"] = Enum.TextXAlignment.Right,
	["AnchorPoint"] = Vector2.new(1, 0.5),
	["Position"] = UDim2.new(1, -14, 0.5, 0),
	["Size"] = UDim2.new(0.42, -14, 0, 18)
})
local v64 = v19 and 44 or 50
local v_u_65 = v_u_13.button({
	["name"] = "Remove",
	["text"] = "\224\184\150\224\184\173\224\184\148\224\184\171\224\184\161\224\184\167\224\184\129",
	["grad"] = "dark",
	["textSize"] = 17,
	["anchor"] = nil,
	["position"] = nil,
	["size"] = nil,
	["parent"] = nil,
	["radius"] = 14,
	["anchor"] = Vector2.new(0, 1),
	["position"] = UDim2.fromScale(0, 1),
	["size"] = UDim2.new(0.42, -5, 0, v64),
	["parent"] = v58
})
local v66 = v_u_13.button({
	["name"] = "Done",
	["text"] = "\224\185\128\224\184\170\224\184\163\224\185\135\224\184\136",
	["icon"] = "check",
	["grad"] = "gold",
	["textSize"] = 18,
	["anchor"] = nil,
	["position"] = nil,
	["size"] = nil,
	["parent"] = nil,
	["radius"] = 14,
	["anchor"] = Vector2.new(1, 1),
	["position"] = UDim2.fromScale(1, 1),
	["size"] = UDim2.new(0.58, -5, 0, v64),
	["parent"] = v58
})
local v67 = v_u_13.panel({
	["Name"] = "Turn",
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["AnchorPoint"] = Vector2.new(0, 1),
	["Position"] = UDim2.new(0, 16, 1, -16),
	["Size"] = UDim2.fromOffset(v19 and 250 or 300, v19 and 56 or 62),
	["Parent"] = v_u_24
})
v67.UICorner.CornerRadius = UDim.new(0, 31)
v_u_13.autoScale(v67)
v_u_13.padding(v67, 7)
local v68 = v_u_13.button({
	["name"] = "TurnLeft",
	["text"] = "\226\151\128",
	["grad"] = "dark",
	["textSize"] = 24,
	["size"] = nil,
	["parent"] = nil,
	["radius"] = 24,
	["size"] = UDim2.new(0, v19 and 42 or 48, 1, 0),
	["parent"] = v67
})
local v69 = v_u_13.button({
	["name"] = "TurnRight",
	["text"] = "\226\150\182",
	["grad"] = "dark",
	["textSize"] = 24,
	["anchor"] = nil,
	["position"] = nil,
	["size"] = nil,
	["parent"] = nil,
	["radius"] = 24,
	["anchor"] = Vector2.new(1, 0),
	["position"] = UDim2.fromScale(1, 0),
	["size"] = UDim2.new(0, v19 and 42 or 48, 1, 0),
	["parent"] = v67
})
v33(v67, v19 and "\224\184\165\224\184\178\224\184\129\224\184\136\224\184\173\224\185\128\224\184\158\224\184\183\224\185\136\224\184\173\224\184\171\224\184\161\224\184\184\224\184\153\224\184\148\224\184\185" or "\224\184\165\224\184\178\224\184\129\224\185\128\224\184\161\224\184\178\224\184\170\224\185\140\224\185\128\224\184\158\224\184\183\224\185\136\224\184\173\224\184\171\224\184\161\224\184\184\224\184\153\224\184\148\224\184\185", 15, v_u_13.TEXT, {
	["TextXAlignment"] = Enum.TextXAlignment.Center,
	["AnchorPoint"] = Vector2.new(0.5, 0.5),
	["Position"] = UDim2.fromScale(0.5, 0.5),
	["Size"] = UDim2.new(1, -110, 1, 0)
})
local v_u_70 = {}
local function v_u_83(p71, p72) -- name: setPreview
	-- upvalues: (copy) v_u_17, (copy) v_u_70
	for _, v73 in p71:GetChildren() do
		if v73:IsA("Camera") then
			continue
		end
		v73:Destroy()
	end
	local v74 = v_u_17:FindFirstChild(p72)
	if v74 then
		local v75 = v74.Handle:Clone()
		for _, v76 in v75:GetDescendants() do
			if not (v76:IsA("ClickDetector") or (v76:IsA("JointInstance") or v76:IsA("Attachment"))) then
				continue
			end
			v76:Destroy()
		end
		v75.CFrame = CFrame.new()
		for _, v77 in v75:GetChildren() do
			if not v77:IsA("BasePart") then
				continue
			end
			v77.CFrame = v74:GetAttribute("Base" .. (v77.Name == "Visor" and "Visor" or "Spoiler") .. "C0")
			v77.Parent = p71
		end
		v75.Parent = p71
		local v78 = p71:FindFirstChildOfClass("Camera") or Instance.new("Camera")
		v78.FieldOfView = 40
		v78.Parent = p71
		p71.CurrentCamera = v78
		local v79 = v74:GetAttribute("BaseHandleSize")
		local v80 = v_u_70[p71] or {
			["angle"] = math.random() * 3.141592653589793
		}
		local v81 = v79.Magnitude * 1.25
		local v82 = v79.Y * 0.18
		v80.camera = v78
		v80.distance = v81
		v80.height = v82
		v_u_70[p71] = v80
	end
end
local function v89(p84, p85) -- name: viewportIn
	-- upvalues: (copy) v_u_13
	local v86 = v_u_13.new("ViewportFrame", {
		["BackgroundTransparency"] = 1,
		["Ambient"] = nil,
		["LightColor"] = nil,
		["LightDirection"] = Vector3.new(-0.6, -1, -0.8),
		["Parent"] = nil,
		["Ambient"] = Color3.fromRGB(170, 170, 180),
		["LightColor"] = Color3.fromRGB(255, 250, 240),
		["Parent"] = p84
	})
	for v87, v88 in p85 or {} do
		v86[v87] = v88
	end
	return v86
end
local v_u_90 = nil
local v_u_91 = false
local v_u_92 = v_u_11.FULL[1].name
local function v_u_99(p93) -- name: wear
	-- upvalues: (ref) v_u_91, (ref) v_u_90, (copy) v_u_1, (copy) v_u_18, (copy) v_u_14
	if v_u_91 or p93 == v_u_90 then
		return
	else
		v_u_91 = true
		local v94 = v_u_1.invoke
		local v95 = v_u_18
		local v96, v97, v98 = pcall(v94, v95, "Wear", p93)
		v_u_91 = false
		if v96 then
			if not v97 and v98 then
				v_u_14.show(v98, "error")
			end
		else
			v_u_14.show("\224\185\128\224\184\138\224\184\183\224\185\136\224\184\173\224\184\161\224\184\149\224\185\136\224\184\173\224\185\132\224\184\161\224\185\136\224\185\132\224\184\148\224\185\137 \224\184\165\224\184\173\224\184\135\224\185\131\224\184\171\224\184\161\224\185\136", "error")
		end
	end
end
local v_u_100 = { Color3.fromRGB(42, 44, 54), Color3.fromRGB(22, 23, 29) }
v33(v_u_56, "\224\184\171\224\184\161\224\184\167\224\184\129\224\185\128\224\184\149\224\185\135\224\184\161\224\185\131\224\184\154  \194\183  \224\184\155\224\184\180\224\184\148\224\184\151\224\184\177\224\185\137\224\184\135\224\184\171\224\184\177\224\184\167 (\224\184\139\224\185\136\224\184\173\224\184\153\224\184\156\224\184\161)", 15, v_u_13.TEXT_DIM, {
	["LayoutOrder"] = 1
})
local v101 = v_u_13.new("Frame", {
	["BackgroundTransparency"] = 1,
	["Size"] = nil,
	["AutomaticSize"] = nil,
	["LayoutOrder"] = 2,
	["Parent"] = nil,
	["Size"] = UDim2.new(1, 0, 0, 0),
	["AutomaticSize"] = Enum.AutomaticSize.Y,
	["Parent"] = v_u_56
})
local v102 = v19 and 150 or 178
local v_u_103 = v19 and 118 or 140
local v_u_104 = v19 and 74 or 84
local v_u_105 = v_u_13.new("UIGridLayout", {
	["CellSize"] = UDim2.new(0.5, -5, 0, v102),
	["CellPadding"] = UDim2.fromOffset(10, 10),
	["SortOrder"] = Enum.SortOrder.LayoutOrder,
	["Parent"] = v101
})
v_u_52:GetPropertyChangedSignal("AbsoluteSize"):Connect(function() -- name: fit
	-- upvalues: (copy) v_u_52, (copy) v_u_36, (copy) v_u_104, (copy) v_u_105, (copy) v_u_103
	local v106 = v_u_52.AbsoluteSize.Y
	local v107 = v_u_36.Scale
	local v108 = v106 / math.max(v107, 0.01) - 52 - (v_u_104 + 22 + 20)
	local v109 = v_u_105
	local v110 = UDim2.new
	local v111 = v_u_103
	local v112 = v108 / 2
	local v113 = math.floor(v112)
	v109.CellSize = v110(0.5, -5, 0, (math.max(v111, v113)))
end)
local v114 = v_u_52.AbsoluteSize.Y
local v115 = v_u_36.Scale
local v116 = v114 / math.max(v115, 0.01) - 52 - (v_u_104 + 22 + 20)
local v117 = UDim2.new
local v118 = v116 / 2
local v119 = math.floor(v118)
v_u_105.CellSize = v117(0.5, -5, 0, (math.max(v_u_103, v119)))
local v_u_120 = v_u_91
local v_u_121 = v_u_90
local function v125(p122) -- name: onBadge
	-- upvalues: (copy) v_u_13, (copy) v_u_15
	local v123 = v_u_13.new("Frame", {
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["Visible"] = false,
		["Parent"] = nil,
		["BackgroundColor3"] = Color3.new(1, 1, 1),
		["AnchorPoint"] = Vector2.new(1, 0),
		["Position"] = UDim2.new(1, -8, 0, 8),
		["Size"] = UDim2.fromOffset(0, 24),
		["AutomaticSize"] = Enum.AutomaticSize.X,
		["Parent"] = p122
	})
	v_u_13.corner(v123, 12)
	v_u_13.gradient(v123, "gold")
	v_u_13.new("UIPadding", {
		["PaddingLeft"] = UDim.new(0, 8),
		["PaddingRight"] = UDim.new(0, 9),
		["Parent"] = v123
	})
	v_u_13.new("UIListLayout", {
		["FillDirection"] = Enum.FillDirection.Horizontal,
		["VerticalAlignment"] = Enum.VerticalAlignment.Center,
		["Padding"] = UDim.new(0, 4),
		["SortOrder"] = Enum.SortOrder.LayoutOrder,
		["Parent"] = v123
	})
	local v124 = v_u_15.make("check", v_u_13.DARK_TEXT, 14)
	v124.LayoutOrder = 1
	v124.Parent = v123
	v_u_13.text({
		["Text"] = "\224\185\131\224\184\170\224\185\136\224\184\173\224\184\162\224\184\185\224\185\136",
		["TextSize"] = 13,
		["FontFace"] = nil,
		["TextColor3"] = nil,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = 2,
		["Parent"] = nil,
		["FontFace"] = v_u_13.FONT_HEAVY,
		["TextColor3"] = v_u_13.DARK_TEXT,
		["Size"] = UDim2.fromScale(0, 1),
		["AutomaticSize"] = Enum.AutomaticSize.X,
		["Parent"] = v123
	})
	return v123
end
local function v132(p126, p127, p128) -- name: card
	-- upvalues: (copy) v_u_13, (copy) v_u_100, (copy) v_u_8
	local v_u_129 = v_u_13.new("TextButton", {
		["Text"] = "",
		["AutoButtonColor"] = false,
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["LayoutOrder"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = Color3.new(1, 1, 1),
		["Size"] = UDim2.new(1, 0, 0, p128),
		["LayoutOrder"] = p127,
		["Parent"] = p126
	})
	v_u_13.corner(v_u_129, 14)
	v_u_13.gradient(v_u_129, v_u_100)
	local v130 = v_u_13.border(v_u_129, Color3.new(1, 1, 1), 0.88, 1)
	local v_u_131 = v_u_13.new("UIScale", {
		["Parent"] = v_u_129
	})
	v_u_129.MouseEnter:Connect(function()
		-- upvalues: (copy) v_u_129, (ref) v_u_8, (copy) v_u_131, (ref) v_u_13
		if v_u_129.Active then
			v_u_8:Create(v_u_131, v_u_13.QUICK, {
				["Scale"] = 1.03
			}):Play()
		end
	end)
	v_u_129.MouseLeave:Connect(function()
		-- upvalues: (ref) v_u_8, (copy) v_u_131, (ref) v_u_13
		v_u_8:Create(v_u_131, v_u_13.QUICK, {
			["Scale"] = 1
		}):Play()
	end)
	return v_u_129, v130
end
local v_u_133 = 0
local v_u_134 = {}
local function v138(p135, p136) -- name: stage
	-- upvalues: (copy) v_u_13
	local v137 = v_u_13.new("Frame", {
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.9,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = Color3.fromRGB(190, 200, 255),
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.new(0.5, 0, 0.5, -p136 / 2),
		["Size"] = UDim2.fromScale(0.72, 0.72),
		["Parent"] = p135
	})
	v_u_13.new("UIAspectRatioConstraint", {
		["Parent"] = v137
	})
	v_u_13.corner(v137, 999)
end
local v_u_139 = 1
local v_u_140 = "White"
for v141, v_u_142 in v_u_11.FULL do
	local v143, v_u_144 = v132(v101, v141, v102)
	v138(v143, 34)
	local v_u_145 = v89(v143, {
		["Position"] = UDim2.fromOffset(6, 6),
		["Size"] = UDim2.new(1, -12, 1, -40)
	})
	local v_u_146 = v_u_142.name
	v_u_83(v_u_145, v_u_146)
	v33(v143, v_u_142.label, 18, v_u_13.TEXT, {
		["FontFace"] = v_u_13.FONT_HEAVY,
		["TextXAlignment"] = Enum.TextXAlignment.Center,
		["AnchorPoint"] = Vector2.new(0, 1),
		["Position"] = UDim2.new(0, 0, 1, -8),
		["Size"] = UDim2.new(1, 0, 0, 24)
	})
	local v_u_147 = v125(v143)
	v143.Activated:Connect(function()
		-- upvalues: (ref) v_u_92, (copy) v_u_142, (copy) v_u_99, (copy) v_u_11, (ref) v_u_133
		v_u_92 = v_u_142.name
		v_u_99(v_u_11.fullName(v_u_92, v_u_133))
	end)
	local function v153()
		-- upvalues: (copy) v_u_11, (ref) v_u_121, (copy) v_u_142, (copy) v_u_144, (copy) v_u_13, (copy) v_u_147, (ref) v_u_133, (ref) v_u_146, (copy) v_u_17, (copy) v_u_83, (copy) v_u_145
		local v148 = v_u_11.info(v_u_121)
		local v149 = v148 ~= nil and v148.full
		if v149 then
			v149 = v148.design == v_u_142.name
		end
		local v150 = v_u_144
		local v151
		if v149 then
			v151 = v_u_13.YELLOW
		else
			v151 = Color3.new(1, 1, 1)
		end
		v150.Color = v151
		v150.Transparency = v149 and 0 or 0.88
		v150.Thickness = v149 and 2.5 or 1
		v_u_147.Visible = v149
		local v152 = v_u_11.fullName(v_u_142.name, v_u_133)
		if v_u_146 ~= v152 and v_u_17:FindFirstChild(v152) then
			v_u_146 = v152
			v_u_83(v_u_145, v152)
		end
	end
	table.insert(v_u_134, v153)
end
v33(v_u_56, "\224\184\138\224\184\180\224\184\165\224\184\171\224\184\153\224\185\137\224\184\178", 15, v_u_13.TEXT_DIM, {
	["LayoutOrder"] = 3
})
local v154 = v_u_13.new("Frame", {
	["BackgroundTransparency"] = 1,
	["Size"] = nil,
	["AutomaticSize"] = nil,
	["LayoutOrder"] = 4,
	["Parent"] = nil,
	["Size"] = UDim2.new(1, 0, 0, 0),
	["AutomaticSize"] = Enum.AutomaticSize.Y,
	["Parent"] = v_u_56
})
v_u_13.new("UIGridLayout", {
	["CellSize"] = UDim2.new(0.25, -8, 0, v_u_104),
	["CellPadding"] = UDim2.fromOffset(10, 10),
	["SortOrder"] = Enum.SortOrder.LayoutOrder,
	["Parent"] = v154
})
for v155, v_u_156 in v_u_11.FULL_VISORS do
	local v157, v_u_158 = v132(v154, v155, 0)
	v157.Size = UDim2.fromScale(1, 1)
	local v159 = v_u_13.new("Frame", {
		["BackgroundColor3"] = Color3.new(1, 1, 1),
		["AnchorPoint"] = Vector2.new(0.5, 0),
		["Position"] = UDim2.new(0.5, 0, 0, 9),
		["Size"] = UDim2.fromOffset(38, 38),
		["Parent"] = v157
	})
	v_u_13.corner(v159, 19)
	v_u_13.new("UIGradient", {
		["Rotation"] = 35,
		["Color"] = nil,
		["Parent"] = nil,
		["Color"] = ColorSequence.new(v_u_156.colors[1], v_u_156.colors[2]),
		["Parent"] = v159
	})
	v_u_13.gloss(v159, 19, 0.3)
	v_u_13.border(v159, Color3.new(1, 1, 1), 0.5, 1.5)
	v33(v157, v_u_156.label, 15, v_u_13.TEXT, {
		["FontFace"] = v_u_13.FONT_BOLD,
		["TextXAlignment"] = Enum.TextXAlignment.Center,
		["AnchorPoint"] = Vector2.new(0, 1),
		["Position"] = UDim2.new(0, 0, 1, -6),
		["Size"] = UDim2.new(1, 0, 0, 20)
	})
	v157.Activated:Connect(function()
		-- upvalues: (ref) v_u_133, (copy) v_u_156, (copy) v_u_11, (ref) v_u_121, (ref) v_u_92, (copy) v_u_99, (copy) v_u_134
		v_u_133 = v_u_156.n
		local v160 = v_u_11.info(v_u_121)
		if v160 and v160.full then
			v_u_92 = v160.design
			v_u_99(v_u_11.fullName(v_u_92, v_u_133))
			local v161 = v_u_11.info(v_u_121)
			if v161 and v161.full then
				v_u_133 = v161.visor
			end
		end
		for _, v162 in v_u_134 do
			v162()
		end
	end)
	table.insert(v_u_134, function()
		-- upvalues: (copy) v_u_158, (ref) v_u_133, (copy) v_u_156, (copy) v_u_13
		local v163 = v_u_158
		local v164 = v_u_133 == v_u_156.n
		local v165
		if v164 then
			v165 = v_u_13.YELLOW
		else
			v165 = Color3.new(1, 1, 1)
		end
		v163.Color = v165
		v163.Transparency = v164 and 0 or 0.88
		v163.Thickness = v164 and 2.5 or 1
	end)
end
local v166, v_u_167 = v132(v_u_57, 1, v19 and 150 or 210)
v166.Active = false
v138(v166, 30)
local v_u_168 = v89(v166, {
	["Position"] = UDim2.fromOffset(8, 6),
	["Size"] = UDim2.new(1, -16, 1, -34)
})
local v_u_169 = v33(v166, "", 17, v_u_13.TEXT, {
	["FontFace"] = v_u_13.FONT_HEAVY,
	["TextXAlignment"] = Enum.TextXAlignment.Center,
	["AnchorPoint"] = Vector2.new(0, 1),
	["Position"] = UDim2.new(0, 12, 1, -8),
	["Size"] = UDim2.new(1, -24, 0, 22)
})
local v_u_170 = v125(v166)
v33(v_u_57, "\224\184\170\224\184\181\224\184\171\224\184\161\224\184\167\224\184\129  \194\183  \224\184\132\224\184\163\224\184\182\224\185\136\224\184\135\224\185\131\224\184\154 \224\185\132\224\184\161\224\185\136\224\184\155\224\184\180\224\184\148\224\184\156\224\184\161", 15, v_u_13.TEXT_DIM, {
	["LayoutOrder"] = 2
})
local v171 = v_u_13.new("Frame", {
	["BackgroundTransparency"] = 1,
	["Size"] = nil,
	["AutomaticSize"] = nil,
	["LayoutOrder"] = 3,
	["Parent"] = nil,
	["Size"] = UDim2.new(1, 0, 0, 0),
	["AutomaticSize"] = Enum.AutomaticSize.Y,
	["Parent"] = v_u_57
})
v_u_13.new("UIGridLayout", {
	["CellSize"] = UDim2.new(0.25, -8, 0, v19 and 74 or 84),
	["CellPadding"] = UDim2.fromOffset(10, 10),
	["SortOrder"] = Enum.SortOrder.LayoutOrder,
	["Parent"] = v171
})
v33(v_u_57, "\224\184\138\224\184\180\224\184\165\224\184\171\224\184\153\224\185\137\224\184\178", 15, v_u_13.TEXT_DIM, {
	["LayoutOrder"] = 4
})
local v172 = v_u_13.new("Frame", {
	["BackgroundTransparency"] = 1,
	["Size"] = nil,
	["AutomaticSize"] = nil,
	["LayoutOrder"] = 5,
	["Parent"] = nil,
	["Size"] = UDim2.new(1, 0, 0, 0),
	["AutomaticSize"] = Enum.AutomaticSize.Y,
	["Parent"] = v_u_57
})
v_u_13.new("UIGridLayout", {
	["CellSize"] = UDim2.new(0.3333333333333333, -7, 0, v19 and 58 or 64),
	["CellPadding"] = UDim2.fromOffset(10, 10),
	["SortOrder"] = Enum.SortOrder.LayoutOrder,
	["Parent"] = v172
})
for v173, v_u_174 in v_u_11.INDEX_SHELLS do
	local v175, v_u_176 = v132(v171, v173, 0)
	v175.Size = UDim2.fromScale(1, 1)
	local v177 = v_u_13.new("Frame", {
		["BackgroundColor3"] = v_u_174.color,
		["AnchorPoint"] = Vector2.new(0.5, 0),
		["Position"] = UDim2.new(0.5, 0, 0, 9),
		["Size"] = UDim2.fromOffset(38, 38),
		["Parent"] = v175
	})
	v_u_13.corner(v177, 19)
	v_u_13.gloss(v177, 19, 0.3)
	v_u_13.border(v177, Color3.new(1, 1, 1), 0.5, 1.5)
	v33(v175, v_u_174.label, 15, v_u_13.TEXT, {
		["FontFace"] = v_u_13.FONT_BOLD,
		["TextXAlignment"] = Enum.TextXAlignment.Center,
		["AnchorPoint"] = Vector2.new(0, 1),
		["Position"] = UDim2.new(0, 0, 1, -6),
		["Size"] = UDim2.new(1, 0, 0, 20)
	})
	v175.Activated:Connect(function()
		-- upvalues: (ref) v_u_140, (copy) v_u_174, (copy) v_u_99, (copy) v_u_11, (ref) v_u_139
		v_u_140 = v_u_174.key
		v_u_99(v_u_11.indexName(v_u_140, v_u_139))
	end)
	table.insert(v_u_134, function()
		-- upvalues: (copy) v_u_176, (ref) v_u_140, (copy) v_u_174, (copy) v_u_13
		local v178 = v_u_176
		local v179 = v_u_140 == v_u_174.key
		local v180
		if v179 then
			v180 = v_u_13.YELLOW
		else
			v180 = Color3.new(1, 1, 1)
		end
		v178.Color = v180
		v178.Transparency = v179 and 0 or 0.88
		v178.Thickness = v179 and 2.5 or 1
	end)
end
for v181, v_u_182 in v_u_11.INDEX_VISORS do
	local v183, v_u_184 = v132(v172, v181, 0)
	v183.Size = UDim2.fromScale(1, 1)
	local v185 = v_u_13.new("Frame", {
		["BackgroundColor3"] = Color3.new(1, 1, 1),
		["AnchorPoint"] = Vector2.new(0, 0.5),
		["Position"] = UDim2.new(0, 10, 0.5, 0),
		["Size"] = UDim2.fromOffset(28, 28),
		["Parent"] = v183
	})
	v_u_13.corner(v185, 14)
	v_u_13.new("UIGradient", {
		["Rotation"] = 35,
		["Color"] = nil,
		["Parent"] = nil,
		["Color"] = ColorSequence.new(v_u_182.colors[1], v_u_182.colors[2]),
		["Parent"] = v185
	})
	v_u_13.border(v185, Color3.new(1, 1, 1), 0.5, 1.5)
	v33(v183, v_u_182.label, 15, v_u_13.TEXT, {
		["FontFace"] = v_u_13.FONT_BOLD,
		["AnchorPoint"] = Vector2.new(0, 0.5),
		["Position"] = UDim2.new(0, 46, 0.5, 0),
		["Size"] = UDim2.new(1, -52, 0, 20)
	})
	v183.Activated:Connect(function()
		-- upvalues: (ref) v_u_139, (copy) v_u_182, (copy) v_u_99, (copy) v_u_11, (ref) v_u_140
		v_u_139 = v_u_182.n
		v_u_99(v_u_11.indexName(v_u_140, v_u_139))
	end)
	table.insert(v_u_134, function()
		-- upvalues: (copy) v_u_184, (ref) v_u_139, (copy) v_u_182, (copy) v_u_13
		local v186 = v_u_184
		local v187 = v_u_139 == v_u_182.n
		local v188
		if v187 then
			v188 = v_u_13.YELLOW
		else
			v188 = Color3.new(1, 1, 1)
		end
		v186.Color = v188
		v186.Transparency = v187 and 0 or 0.88
		v186.Thickness = v187 and 2.5 or 1
	end)
end
local v_u_189 = nil
local function v195()
	-- upvalues: (copy) v_u_11, (ref) v_u_140, (ref) v_u_139, (ref) v_u_189, (copy) v_u_83, (copy) v_u_168, (copy) v_u_169, (copy) v_u_170, (ref) v_u_121, (copy) v_u_167, (copy) v_u_13
	local v190 = v_u_11.indexName(v_u_140, v_u_139)
	if v_u_189 ~= v190 then
		v_u_189 = v190
		v_u_83(v_u_168, v190)
	end
	local v191 = v_u_11.info(v190)
	v_u_169.Text = v191 and v191.label or ""
	v_u_170.Visible = v_u_121 == v190
	local v192 = v_u_167
	local v193 = v_u_121 == v190
	local v194
	if v193 then
		v194 = v_u_13.YELLOW
	else
		v194 = Color3.new(1, 1, 1)
	end
	v192.Color = v194
	v192.Transparency = v193 and 0 or 0.88
	v192.Thickness = v193 and 2.5 or 1
end
table.insert(v_u_134, v195)
local function v_u_209() -- name: paint
	-- upvalues: (copy) v_u_11, (ref) v_u_121, (copy) v_u_62, (copy) v_u_13, (copy) v_u_63, (copy) v_u_61, (ref) v_u_140, (ref) v_u_139, (ref) v_u_92, (ref) v_u_133, (copy) v_u_134, (copy) v_u_65
	local v196 = v_u_11.info(v_u_121)
	v_u_62.Text = not v196 and "\224\184\162\224\184\177\224\184\135\224\185\132\224\184\161\224\185\136\224\185\132\224\184\148\224\185\137\224\185\131\224\184\170\224\185\136\224\184\171\224\184\161\224\184\167\224\184\129" or "\224\185\131\224\184\170\224\185\136\224\184\173\224\184\162\224\184\185\224\185\136: " .. v196.label
	local v197 = v_u_62
	local v198
	if v196 then
		v198 = v_u_13.TEXT
	else
		v198 = v_u_13.TEXT_DIM
	end
	v197.TextColor3 = v198
	v_u_63.Visible = v196 ~= nil
	v_u_61.Visible = v196 ~= nil
	v_u_62.Position = UDim2.new(0, v196 and 38 or 14, 0.5, 0)
	if v196 and not v196.full then
		local v199 = v196.shell
		local v200 = v196.visor
		v_u_140 = v199
		v_u_139 = v200
	end
	if v196 and v196.full then
		local v201 = v196.design
		local v202 = v196.visor
		v_u_92 = v201
		v_u_133 = v202
	end
	for _, v203 in v_u_134 do
		v203()
	end
	local v204 = v_u_13.setButton
	local v205 = v_u_65
	local v206 = v196 and "dark" or { Color3.fromRGB(70, 72, 84), Color3.fromRGB(52, 54, 64) }
	local v207 = nil
	local v208
	if v196 then
		v208 = v_u_13.TEXT
	else
		v208 = v_u_13.TEXT_DIM
	end
	v204(v205, v206, v207, v208)
end
local _, v_u_211 = v_u_13.tabs(v50, {
	{
		["id"] = "Full",
		["label"] = "\224\185\128\224\184\149\224\185\135\224\184\161\224\185\131\224\184\154",
		["icon"] = "star",
		["grad"] = "gold"
	},
	{
		["id"] = "Index",
		["label"] = "\224\184\132\224\184\163\224\184\182\224\185\136\224\184\135\224\185\131\224\184\154 INDEX",
		["icon"] = "scooter",
		["grad"] = "gold"
	}
}, function(p210)
	-- upvalues: (copy) v_u_56, (copy) v_u_57
	v_u_56.Visible = p210 == "Full"
	v_u_57.Visible = p210 == "Index"
end, v49)
local function v_u_214() -- name: helmetOn
	-- upvalues: (copy) v_u_16
	local v212 = v_u_16.Character
	for _, v213 in not v212 and {} or v212:GetChildren() do
		if not (v213:IsA("Model") and v213:GetAttribute("HelmetName")) then
			continue
		end
		return v213:GetAttribute("HelmetName")
	end
	return nil
end
local v_u_215 = nil
local function v_u_219() -- name: controls
	-- upvalues: (copy) v_u_16
	local v_u_216 = v_u_16:FindFirstChild("PlayerScripts")
	if v_u_216 then
		v_u_216 = v_u_16.PlayerScripts:FindFirstChild("PlayerModule")
	end
	if v_u_216 then
		local v217, v218 = pcall(function()
			-- upvalues: (copy) v_u_216
			return require(v_u_216):GetControls()
		end)
		if v217 then
			return v218
		else
			return nil
		end
	else
		return nil
	end
end
local v_u_220 = nil
local function v_u_289() -- name: open
	-- upvalues: (copy) v_u_16, (ref) v_u_215, (copy) v_u_20, (copy) v_u_5, (copy) v_u_219, (copy) v_u_2, (copy) v_u_23, (ref) v_u_121, (copy) v_u_214, (copy) v_u_11, (copy) v_u_56, (copy) v_u_57, (copy) v_u_211, (copy) v_u_209, (copy) v_u_42, (copy) v_u_24, (copy) v_u_7, (ref) v_u_220, (copy) v_u_21, (copy) v_u_22, (copy) v_u_70, (copy) v_u_9
	local v_u_221 = v_u_16.Character
	local v_u_222
	if v_u_221 then
		v_u_222 = v_u_221:FindFirstChild("HumanoidRootPart")
	else
		v_u_222 = v_u_221
	end
	local v_u_223
	if v_u_221 then
		v_u_223 = v_u_221:FindFirstChildOfClass("Humanoid")
	else
		v_u_223 = v_u_221
	end
	if not v_u_215 and (v_u_222 and (v_u_223 and (v_u_223.Health > 0 and not v_u_223.SeatPart))) then
		v_u_215 = {
			["yaw"] = 0,
			["targetYaw"] = 0,
			["origin"] = nil,
			["guis"] = nil,
			["conns"] = nil,
			["origin"] = v_u_222.Position,
			["guis"] = {},
			["conns"] = {}
		}
		local v224 = workspace:FindFirstChild("HelmetShop")
		if v224 then
			v224 = v224:FindFirstChild("HumanoidRootPart", true)
		end
		local v225 = not v224 and Vector3.new(0, 0, 0) or (v_u_222.Position - v224.Position) * Vector3.new(1, 0, 1)
		if v225.Magnitude < 0.5 then
			local v226
			if v224 then
				v226 = v224.CFrame.LookVector
			else
				v226 = v_u_222.CFrame.LookVector
			end
			v225 = v226 * Vector3.new(1, 0, 1)
		end
		if v225.Magnitude > 0.01 then
			v_u_222.CFrame = CFrame.lookAt(v_u_222.Position, v_u_222.Position + v225.Unit)
		end
		for _, v227 in v_u_16.PlayerGui:GetChildren() do
			if not v227:IsA("ScreenGui") or (not v227.Enabled or v_u_20[v227.Name]) then
				continue
			end
			v227.Enabled = false
			v_u_215.guis[v227] = true
		end
		v_u_215.prompts = v_u_5.Enabled
		v_u_5.Enabled = false
		local v228 = v_u_219()
		if v228 then
			local v229 = v228.Disable
			pcall(v229, v228)
		end
		local v230 = v_u_23
		v_u_2:BindActionAtPriority("HelmetRoomFreeze", function()
			return Enum.ContextActionResult.Sink
		end, false, Enum.ContextActionPriority.High.Value + 100, table.unpack(v230))
		v_u_215.walkSpeed = v_u_223.WalkSpeed
		v_u_223.WalkSpeed = 0
		local v_u_231 = workspace.CurrentCamera
		v_u_215.cameraType = v_u_231.CameraType
		v_u_231.CameraType = Enum.CameraType.Scriptable
		v_u_121 = v_u_214()
		local v232 = v_u_11.info(v_u_121)
		local v_u_233 = v232 and not v232.full and "Index" or "Full"
		v_u_56.Visible = v_u_233 == "Full"
		v_u_57.Visible = v_u_233 == "Index"
		for _, v234 in { function()
				-- upvalues: (ref) v_u_211, (copy) v_u_233
				v_u_211(v_u_233)
			end, v_u_209, v_u_42 } do
			local v235, v236 = pcall(v234)
			if v235 then
				continue
			end
			warn("[HelmetRoom] " .. tostring(v236))
		end
		v_u_24.Enabled = true
		local v237 = v_u_215.conns
		local v238 = v_u_7.RenderStepped
		local function v262(p239)
			-- upvalues: (copy) v_u_221, (copy) v_u_223, (copy) v_u_222, (ref) v_u_215, (ref) v_u_220, (ref) v_u_21, (ref) v_u_22, (copy) v_u_231, (ref) v_u_70
			local v240 = v_u_221:FindFirstChild("Head")
			if v240 and (v_u_221.Parent and (v_u_223.Health > 0 and (v_u_222.Position - v_u_215.origin).Magnitude <= 22)) then
				local v241 = v_u_215
				local v242 = v241.yaw
				local v243 = v_u_215.targetYaw - v_u_215.yaw
				local v244 = p239 * 8
				v241.yaw = v242 + v243 * math.min(1, v244)
				local v245 = v_u_222.CFrame.LookVector * Vector3.new(1, 0, 1)
				local v246 = CFrame.Angles(0, v_u_215.yaw, 0) * (v245.Magnitude <= 0.01 and Vector3.new(0, 0, -1) or v245.Unit)
				local v247 = v240.Position - Vector3.new(0, 0.6, 0)
				local v248 = CFrame.lookAt(v247 + v246 * v_u_21 + Vector3.new(0, 0.9, 0), v247) * CFrame.new(v_u_22, 0, 0)
				local v249 = v_u_231
				local v250 = v_u_231.CFrame
				local v251 = p239 * 8
				v249.CFrame = v250:Lerp(v248, (math.min(1, v251)))
				for _, v252 in v_u_70 do
					v252.angle = v252.angle + p239 * 0.6
					local v253 = v252.camera
					local v254 = CFrame.lookAt
					local v255 = v252.angle - 2.6
					local v256 = math.sin(v255) * v252.distance
					local v257 = v252.height + v252.distance * 0.18
					local v258 = v252.angle - 2.6
					local v259 = math.cos(v258) * v252.distance
					local v260 = Vector3.new(v256, v257, v259)
					local v261 = v252.height * 0.4
					v253.CFrame = v254(v260, (Vector3.new(0, v261, 0)))
				end
			else
				v_u_220()
			end
		end
		table.insert(v237, v238:Connect(v262))
		local v_u_263 = nil
		local v_u_264 = 0
		local v265 = v_u_215.conns
		local v266 = v_u_9.InputBegan
		local function v270(p267, p268)
			-- upvalues: (ref) v_u_263, (ref) v_u_264, (ref) v_u_220
			if p268 then
				return
			elseif p267.UserInputType == Enum.UserInputType.MouseButton1 or p267.UserInputType == Enum.UserInputType.Touch then
				local v269 = p267.Position.X
				v_u_263 = p267
				v_u_264 = v269
			elseif p267.KeyCode == Enum.KeyCode.Escape then
				v_u_220()
			end
		end
		table.insert(v265, v266:Connect(v270))
		local v271 = v_u_215.conns
		local v272 = v_u_9.InputChanged
		local function v276(p273)
			-- upvalues: (ref) v_u_263, (ref) v_u_215, (ref) v_u_264
			if v_u_263 then
				local v274
				if p273.UserInputType == Enum.UserInputType.MouseMovement then
					v274 = true
				elseif p273.UserInputType == Enum.UserInputType.Touch then
					v274 = p273 == v_u_263
				else
					v274 = false
				end
				if v274 then
					local v275 = v_u_215
					v275.targetYaw = v275.targetYaw - (p273.Position.X - v_u_264) * 0.012
					v_u_264 = p273.Position.X
				end
			end
		end
		table.insert(v271, v272:Connect(v276))
		local v277 = v_u_215.conns
		local v278 = v_u_9.InputEnded
		local function v280(p279)
			-- upvalues: (ref) v_u_263
			if p279 == v_u_263 or p279.UserInputType == Enum.UserInputType.MouseButton1 then
				v_u_263 = nil
			end
		end
		table.insert(v277, v278:Connect(v280))
		local function v284() -- name: changed
			-- upvalues: (ref) v_u_215, (ref) v_u_121, (ref) v_u_214, (ref) v_u_209
			task.defer(function()
				-- upvalues: (ref) v_u_215, (ref) v_u_121, (ref) v_u_214, (ref) v_u_209
				if v_u_215 then
					v_u_121 = v_u_214()
					local v281 = v_u_209
					local v282, v283 = pcall(v281)
					if not v282 then
						warn("[HelmetRoom] " .. tostring(v283))
					end
				end
			end)
		end
		local v285 = v_u_215.conns
		local v286 = v_u_221.ChildAdded
		table.insert(v285, v286:Connect(v284))
		local v287 = v_u_215.conns
		local v288 = v_u_221.ChildRemoved
		table.insert(v287, v288:Connect(v284))
	end
end
v_u_220 = function() -- name: close
	-- upvalues: (ref) v_u_215, (copy) v_u_24, (copy) v_u_5, (copy) v_u_219, (copy) v_u_2, (copy) v_u_16
	if v_u_215 then
		local v290 = v_u_215
		v_u_215 = nil
		v_u_24.Enabled = false
		for _, v291 in v290.conns do
			v291:Disconnect()
		end
		for v292 in v290.guis do
			if not v292.Parent then
				continue
			end
			v292.Enabled = true
		end
		v_u_5.Enabled = v290.prompts
		local v293 = v_u_219()
		if v293 then
			v293:Enable()
		end
		v_u_2:UnbindAction("HelmetRoomFreeze")
		local v294 = v_u_16.Character
		if v294 then
			v294 = v_u_16.Character:FindFirstChildOfClass("Humanoid")
		end
		if v294 and v294.WalkSpeed == 0 then
			v294.WalkSpeed = v290.walkSpeed or 16
		end
		local v295 = workspace.CurrentCamera
		local v296
		if v290.cameraType == Enum.CameraType.Scriptable then
			v296 = Enum.CameraType.Custom
		else
			v296 = v290.cameraType
		end
		v295.CameraType = v296
		local v297 = v_u_16.Character
		if v297 then
			v297 = v_u_16.Character:FindFirstChildOfClass("Humanoid")
		end
		if v297 then
			v295.CameraSubject = v297
		end
	end
end
v48.Activated:Connect(v_u_220)
v66.Activated:Connect(v_u_220)
v_u_65.Activated:Connect(function()
	-- upvalues: (ref) v_u_120, (ref) v_u_121, (copy) v_u_1, (copy) v_u_18, (copy) v_u_14
	if not v_u_120 and v_u_121 then
		v_u_120 = true
		local v298 = v_u_1.invoke
		local v299 = v_u_18
		local v300, v301, v302 = pcall(v298, v299, "Remove")
		v_u_120 = false
		if v300 and (v301 and v302) then
			v_u_14.show(v302, "ok")
		end
	end
end)
v68.Activated:Connect(function()
	-- upvalues: (ref) v_u_215
	if v_u_215 then
		local v303 = v_u_215
		v303.targetYaw = v303.targetYaw - 0.7853981633974483
	end
end)
v69.Activated:Connect(function()
	-- upvalues: (ref) v_u_215
	if v_u_215 then
		local v304 = v_u_215
		v304.targetYaw = v304.targetYaw + 0.7853981633974483
	end
end)
v_u_5.PromptTriggered:Connect(function(p305)
	-- upvalues: (copy) v_u_11, (copy) v_u_289
	if p305.Name == v_u_11.PROMPT then
		v_u_289()
	end
end)
v_u_16.CharacterRemoving:Connect(v_u_220)
local v_u_306 = RaycastParams.new()
v_u_306.FilterType = Enum.RaycastFilterType.Include
local function v_u_310() -- name: myVisor
	-- upvalues: (copy) v_u_16
	local v307 = v_u_16.Character
	for _, v308 in not v307 and {} or v307:GetChildren() do
		if not (v308:IsA("Model") and v308:GetAttribute("HelmetName")) then
			continue
		end
		local v309 = v308:FindFirstChild("Handle")
		if v309 then
			v309 = v309:FindFirstChild("Visor")
		end
		return v309
	end
	return nil
end
local v_u_311 = {}
v_u_9.InputBegan:Connect(function(p312, p313)
	-- upvalues: (copy) v_u_311
	if not p313 and (p312.UserInputType == Enum.UserInputType.MouseButton1 or p312.UserInputType == Enum.UserInputType.Touch) then
		v_u_311[p312] = Vector2.new(p312.Position.X, p312.Position.Y)
	end
end)
v_u_9.InputEnded:Connect(function(p314)
	-- upvalues: (copy) v_u_311, (copy) v_u_310, (copy) v_u_306, (copy) v_u_1, (copy) v_u_18
	local v315 = v_u_311[p314]
	v_u_311[p314] = nil
	if v315 then
		local v316 = Vector2.new(p314.Position.X, p314.Position.Y)
		local v317 = v_u_310()
		if v317 and (v316 - v315).Magnitude <= 12 then
			local v318 = workspace.CurrentCamera:ScreenPointToRay(v316.X, v316.Y)
			v_u_306.FilterDescendantsInstances = { v317 }
			if workspace:Raycast(v318.Origin, v318.Direction * 80, v_u_306) then
				task.spawn(function()
					-- upvalues: (ref) v_u_1, (ref) v_u_18
					local v319 = v_u_1.invoke
					local v320 = v_u_18
					pcall(v319, v320, "Visor")
				end)
			end
		end
	else
		return
	end
end)