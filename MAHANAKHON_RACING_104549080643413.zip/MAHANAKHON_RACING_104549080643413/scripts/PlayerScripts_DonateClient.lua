-- Path: Players/ygggggg55551/PlayerScripts/DonateClient
-- Class: LocalScript  true/Enum.RunContext.Legacy
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = require(game:GetService("ReplicatedStorage"):WaitForChild("UiOwn")).Instance
local v_u_2 = game:GetService("MarketplaceService")
local v3 = game:GetService("Players")
local v4 = game:GetService("ProximityPromptService")
local v5 = game:GetService("ReplicatedStorage")
local v_u_6 = require(v5:WaitForChild("GameShared"))
local v_u_7 = v3.LocalPlayer
local v_u_8 = nil
local function v_u_18() -- name: build
	-- upvalues: (ref) v_u_8, (copy) v_u_1, (copy) v_u_7, (copy) v_u_6, (copy) v_u_2
	v_u_8 = v_u_1.new("ScreenGui")
	v_u_8.Name = "Donate"
	v_u_8.ResetOnSpawn = false
	v_u_8.DisplayOrder = 7
	v_u_8.Parent = v_u_7:WaitForChild("PlayerGui")
	local v9 = v_u_1.new("Frame")
	v9.AnchorPoint = Vector2.new(0.5, 0.5)
	v9.Position = UDim2.fromScale(0.5, 0.5)
	v9.Size = UDim2.fromOffset(340, #v_u_6.DONATE_PRODUCTS * 60 + 110)
	v9.BackgroundColor3 = Color3.fromRGB(18, 19, 24)
	v9.BackgroundTransparency = 0.05
	v9.Parent = v_u_8
	v_u_1.new("UICorner", v9).CornerRadius = UDim.new(0, 14)
	local v10 = v_u_1.new("UIScale", v9)
	local v11 = (workspace.CurrentCamera.ViewportSize.Y - 40) / v9.Size.Y.Offset
	v10.Scale = math.clamp(v11, 0.6, 1)
	local v12 = v_u_1.new("TextLabel")
	v12.BackgroundTransparency = 1
	v12.Position = UDim2.fromOffset(16, 10)
	v12.Size = UDim2.new(1, -90, 0, 40)
	v12.Font = Enum.Font.GothamBlack
	v12.TextSize = 22
	v12.TextXAlignment = Enum.TextXAlignment.Left
	v12.TextColor3 = Color3.fromRGB(255, 90, 170)
	v12.Text = "Donate to the map"
	v12.Parent = v9
	local v13 = v_u_1.new("TextButton")
	v13.AnchorPoint = Vector2.new(1, 0)
	v13.Position = UDim2.new(1, -10, 0, 10)
	v13.Size = UDim2.fromOffset(60, 40)
	v13.BackgroundColor3 = Color3.fromRGB(50, 52, 60)
	v13.Font = Enum.Font.GothamBold
	v13.TextSize = 18
	v13.TextColor3 = Color3.new(1, 1, 1)
	v13.Text = "Close"
	v13.Parent = v9
	v_u_1.new("UICorner", v13).CornerRadius = UDim.new(0, 8)
	v13.Activated:Connect(function()
		-- upvalues: (ref) v_u_8
		v_u_8.Enabled = false
	end)
	for v14, v_u_15 in v_u_6.DONATE_PRODUCTS do
		local v16 = v_u_1.new("TextButton")
		v16.Position = UDim2.fromOffset(16, 60 + (v14 - 1) * 60)
		v16.Size = UDim2.new(1, -32, 0, 50)
		v16.BackgroundColor3 = Color3.fromRGB(40, 140, 80)
		v16.Font = Enum.Font.GothamBold
		v16.TextSize = 20
		v16.TextColor3 = Color3.new(1, 1, 1)
		v16.Text = ("Donate %d R$"):format(v_u_15.robux)
		v16.Parent = v9
		v_u_1.new("UICorner", v16).CornerRadius = UDim.new(0, 10)
		v16.Activated:Connect(function()
			-- upvalues: (ref) v_u_2, (ref) v_u_7, (copy) v_u_15
			v_u_2:PromptProductPurchase(v_u_7, v_u_15.id)
		end)
	end
	local v17 = v_u_1.new("TextLabel")
	v17.BackgroundTransparency = 1
	v17.AnchorPoint = Vector2.new(0, 1)
	v17.Position = UDim2.new(0, 16, 1, -8)
	v17.Size = UDim2.new(1, -32, 0, 36)
	v17.Font = Enum.Font.Gotham
	v17.TextSize = 14
	v17.TextWrapped = true
	v17.TextColor3 = Color3.fromRGB(170, 172, 178)
	v17.Text = "Donations show on the supporters board at AUTOWORKS"
	v17.Parent = v9
end
v4.PromptTriggered:Connect(function(p19)
	-- upvalues: (copy) v_u_6, (ref) v_u_8, (copy) v_u_18
	if p19:GetAttribute("Donate") and #v_u_6.DONATE_PRODUCTS > 0 then
		if not v_u_8 then
			v_u_18()
		end
		v_u_8.Enabled = true
	end
end)