-- Path: StarterPlayer/PlayerModule/PlayerScriptsLoader
-- Class: Script  true/Enum.RunContext.Client
-- Decompiled by BALL KUN Universal Map Dump

require(script.Parent:WaitForChild("PlayerModuleInternal")).new():start()