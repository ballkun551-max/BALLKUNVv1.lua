-- Path: Players/ygggggg55551/PlayerScripts/TuneShopClient
-- Class: LocalScript  true/Enum.RunContext.Legacy
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = require(game:GetService("ReplicatedStorage"):WaitForChild("UiOwn")).Instance
local v_u_2 = require(game:GetService("ReplicatedStorage"):WaitForChild("NetSeal"))
local v_u_3 = game:GetService("CollectionService")
local v4 = game:GetService("Players")
local v5 = game:GetService("ProximityPromptService")
local v_u_6 = game:GetService("ReplicatedStorage")
local v_u_7 = require(v_u_6:WaitForChild("GameShared"))
local v_u_8 = require(v_u_6:WaitForChild("GameUI"):WaitForChild("Toast"))
local v_u_9 = require(v_u_6:WaitForChild("GameUI"):WaitForChild("Skin"))
local v_u_10 = v4.LocalPlayer
local v_u_11 = v_u_6:WaitForChild("GameRemotes"):WaitForChild("TuneShop")
local v_u_12 = v_u_1.new("ScreenGui")
v_u_12.Name = "TuneShop"
v_u_12.ResetOnSpawn = false
v_u_12.DisplayOrder = 6
v_u_12.Enabled = false
v_u_12.Parent = v_u_10:WaitForChild("PlayerGui")
local v13 = v_u_1.new("Frame")
v13.AnchorPoint = Vector2.new(0.5, 0.5)
v13.Position = UDim2.fromScale(0.5, 0.5)
v13.Size = UDim2.fromOffset(360, 380)
v13.BackgroundColor3 = Color3.fromRGB(20, 21, 24)
v13.BackgroundTransparency = 0.08
v13.Parent = v_u_12
v_u_1.new("UICorner", v13).CornerRadius = UDim.new(0, 14)
local v14 = v_u_1.new("TextLabel")
v14.BackgroundTransparency = 1
v14.Position = UDim2.fromOffset(16, 10)
v14.Size = UDim2.new(1, -90, 0, 34)
v14.Font = Enum.Font.GothamBlack
v14.TextSize = 22
v14.TextXAlignment = Enum.TextXAlignment.Left
v14.TextColor3 = Color3.fromRGB(240, 196, 20)
v14.Text = "Pick a vehicle to tune"
v14.Parent = v13
local v15 = v_u_1.new("TextButton")
v15.Name = "Close"
v15.AnchorPoint = Vector2.new(1, 0)
v15.Position = UDim2.new(1, -10, 0, 10)
v15.Size = UDim2.fromOffset(60, 36)
v15.BackgroundColor3 = Color3.fromRGB(60, 62, 68)
v15.Font = Enum.Font.GothamBold
v15.TextSize = 16
v15.TextColor3 = Color3.new(1, 1, 1)
v15.Text = "Close"
v15.Parent = v13
v_u_1.new("UICorner", v15).CornerRadius = UDim.new(0, 8)
v15.Activated:Connect(function()
	-- upvalues: (copy) v_u_12
	v_u_12.Enabled = false
end)
local v_u_16 = v_u_1.new("ScrollingFrame")
v_u_16.Position = UDim2.fromOffset(12, 56)
v_u_16.Size = UDim2.new(1, -24, 1, -68)
v_u_16.BackgroundTransparency = 1
v_u_16.BorderSizePixel = 0
v_u_16.ScrollBarThickness = 6
v_u_16.AutomaticCanvasSize = Enum.AutomaticSize.Y
v_u_16.CanvasSize = UDim2.new()
v_u_16.Parent = v13
local v17 = v_u_1.new("UIListLayout")
v17.Padding = UDim.new(0, 8)
v17.Parent = v_u_16
local v_u_18 = false
local function v_u_22() -- name: myVehicles
	-- upvalues: (copy) v_u_10
	local v19 = workspace:FindFirstChild("SpawnedVehicles")
	local v20 = {}
	for _, v21 in not v19 and {} or v19:GetChildren() do
		if not v21:IsA("Model") or v21:GetAttribute("OwnerUserId") ~= v_u_10.UserId then
			continue
		end
		table.insert(v20, v21)
	end
	return v20
end
local function v_u_29(p23, p24) -- name: seatOn
	-- upvalues: (copy) v_u_6, (copy) v_u_2, (copy) v_u_10, (copy) v_u_8
	if p24 == "bike" then
		local v25 = v_u_6:FindFirstChild("PCX160Remote")
		if v25 then
			v_u_2.fire(v25, "Mount", p23, "Drive")
		end
	else
		local v26 = v_u_6:FindFirstChild("CarRemote")
		if v26 then
			v_u_2.fire(v26, "Enter", p23, "Driver")
		end
	end
	local v27 = v_u_10.Character
	if v27 then
		v27 = v_u_10.Character:FindFirstChildOfClass("Humanoid")
	end
	local v28 = os.clock()
	while v27 and os.clock() - v28 < 4 do
		if v27.SeatPart and v27.SeatPart:IsDescendantOf(p23) then
			task.wait(0.6)
			v_u_10:SetAttribute("TuneHub", true)
			return
		end
		task.wait(0.1)
	end
	v_u_8.show("Couldn\'t get on. Walk to it, press E, then Tune", "info")
end
local function v_u_37(p30) -- name: choose
	-- upvalues: (ref) v_u_18, (copy) v_u_2, (copy) v_u_11, (copy) v_u_8, (copy) v_u_12, (copy) v_u_29
	if v_u_18 then
		return
	else
		v_u_18 = true
		local v31 = v_u_2.invoke
		local v32 = v_u_11
		local v33, v34, v35, v36 = pcall(v31, v32, "Bring", p30)
		v_u_18 = false
		if v33 then
			v_u_8.show(v35 or "", v34 and "ok" or "error")
			if v34 then
				v_u_12.Enabled = false
				task.spawn(v_u_29, p30, v36)
			end
		else
			v_u_8.show("Failed", "error")
		end
	end
end
local function v_u_50() -- name: open
	-- upvalues: (copy) v_u_16, (copy) v_u_22, (copy) v_u_8, (copy) v_u_7, (copy) v_u_1, (copy) v_u_9, (copy) v_u_10, (copy) v_u_37, (copy) v_u_12
	for _, v38 in v_u_16:GetChildren() do
		if not v38:IsA("GuiObject") then
			continue
		end
		v38:Destroy()
	end
	local v39 = v_u_22()
	if #v39 == 0 then
		v_u_8.show("No vehicle out yet. Spawn one first (key button, G)", "info")
	else
		for v40, v_u_41 in v39 do
			local v42 = v_u_7.vehicle(v_u_41:GetAttribute("VehicleId") or "")
			local v43 = v_u_1.new("TextButton")
			v43.LayoutOrder = v40
			v43.Size = UDim2.new(1, -8, 0, 52)
			v43.BackgroundColor3 = v_u_9.IDLE
			v43.Font = Enum.Font.GothamBold
			v43.TextSize = 18
			v43.TextColor3 = Color3.new(1, 1, 1)
			v43.TextXAlignment = Enum.TextXAlignment.Left
			local v44 = v_u_10.Character
			if v44 then
				v44 = v_u_10.Character:FindFirstChild("HumanoidRootPart")
			end
			local v45
			if v44 then
				local v46 = (v_u_41:GetPivot().Position - v44.Position).Magnitude
				v45 = math.floor(v46)
			else
				v45 = 0
			end
			local v47 = "   "
			local v48
			if v42 then
				v48 = v42.th
			else
				v48 = v_u_41:GetAttribute("DisplayName") or v_u_41.Name
			end
			local v49 = v45 * 0.28
			v43.Text = v47 .. v48 .. ("   \194\183 %d m away"):format((math.floor(v49)))
			v43.Parent = v_u_16
			v_u_1.new("UICorner", v43).CornerRadius = UDim.new(0, 10)
			v43.Activated:Connect(function()
				-- upvalues: (ref) v_u_37, (copy) v_u_41
				v_u_37(v_u_41)
			end)
		end
		v_u_12.Enabled = true
	end
end
v_u_9.apply(v_u_12)
v5.PromptTriggered:Connect(function(p51)
	-- upvalues: (copy) v_u_3, (copy) v_u_50
	if v_u_3:HasTag(p51, "TuneKiosk") then
		v_u_50()
	end
end)