-- Path: ReplicatedStorage/GameUI/QuestApp
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = require(game:GetService("ReplicatedStorage"):WaitForChild("NetSeal"))
local v_u_2 = game:GetService("HttpService")
local v3 = game:GetService("Players")
local v_u_4 = game:GetService("ReplicatedStorage")
local v_u_5 = game:GetService("TweenService")
local v_u_6 = require(v_u_4:WaitForChild("GameShared"))
local v_u_7 = require(v_u_4:WaitForChild("QuestShared"))
local v_u_8 = require(script.Parent:WaitForChild("Theme"))
local v_u_9 = require(script.Parent:WaitForChild("Icons"))
local v_u_10 = require(script.Parent:WaitForChild("Toast"))
local v11 = {}
local v_u_12 = Color3.new(1, 1, 1)
local v_u_13 = Color3.fromRGB(28, 30, 36)
local v_u_14 = Color3.fromRGB(112, 116, 128)
local v_u_15 = Color3.fromRGB(243, 244, 247)
local v_u_16 = Color3.fromRGB(226, 228, 234)
local v_u_17 = Color3.fromRGB(255, 176, 30)
local v_u_18 = Color3.fromRGB(236, 72, 120)
local v_u_19 = Color3.fromRGB(214, 140, 0)
local v_u_20 = Color3.fromRGB(22, 170, 100)
local v_u_21 = TweenInfo.new(0.3, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
local v_u_22 = { "daily", "weekly" }
local v_u_23 = v3.LocalPlayer
local function v_u_41(p24, p25, p26, p27, p28, p29, p30, p31, p32, p33) -- name: label
	-- upvalues: (copy) v_u_8
	local v34 = v_u_8.text
	local v35 = {
		["Text"] = p25
	}
	local v36
	if p32 then
		v36 = v_u_8.FONT_BOLD
	else
		v36 = v_u_8.FONT
	end
	v35.FontFace = v36
	v35.TextSize = p30
	v35.TextColor3 = p31
	v35.TextXAlignment = Enum.TextXAlignment.Left
	v35.TextTruncate = Enum.TextTruncate.AtEnd
	v35.Position = UDim2.new(0, p26, 0, p27)
	local v37
	if p28 then
		v37 = UDim2.fromOffset(p28, p29)
	else
		v37 = UDim2.new(1, -p26 - 8, 0, p29)
	end
	v35.Size = v37
	v35.Parent = p24
	local v38 = v34(v35)
	for v39, v40 in p33 or {} do
		v38[v39] = v40
	end
	return v38
end
local function v_u_55(p42, p43, p44, p45, p46, p47) -- name: badge
	-- upvalues: (copy) v_u_12, (copy) v_u_8, (copy) v_u_9
	local v48 = {
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_12,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromOffset(p46, p47),
		["Size"] = UDim2.fromOffset(p45, p45),
		["Parent"] = p42
	}
	local v49 = v_u_8.new("Frame", v48)
	v_u_8.corner(v49, p45 * 0.3)
	local v50 = {
		["Rotation"] = 135,
		["Color"] = nil,
		["Parent"] = nil,
		["Color"] = ColorSequence.new(p44:Lerp(v_u_12, 0.2), p44:Lerp(Color3.new(0, 0, 0), 0.2)),
		["Parent"] = v49
	}
	v_u_8.new("UIGradient", v50)
	local v51 = v_u_9.make
	local v52 = v_u_12
	local v53 = p45 * 0.58
	local v54 = v51(p43, v52, (math.floor(v53)))
	v54.AnchorPoint = Vector2.new(0.5, 0.5)
	v54.Position = UDim2.fromScale(0.5, 0.5)
	v54.Parent = v49
	return v49
end
local function v_u_63(p56, p57, p58) -- name: card
	-- upvalues: (copy) v_u_8, (copy) v_u_12
	local v59 = {
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.92,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = Color3.new(0, 0, 0),
		["Position"] = UDim2.new(0, 14, 0, p57 + 3),
		["Size"] = UDim2.new(1, -28, 0, p58),
		["Parent"] = p56
	}
	local v60 = v_u_8.new("Frame", v59)
	v_u_8.corner(v60, 14)
	local v61 = {
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_12,
		["Position"] = UDim2.new(0, 14, 0, p57),
		["Size"] = UDim2.new(1, -28, 0, p58),
		["Parent"] = p56
	}
	local v62 = v_u_8.new("Frame", v61)
	v_u_8.corner(v62, 14)
	return v62
end
local function v_u_67(p64) -- name: pressable
	-- upvalues: (copy) v_u_8, (copy) v_u_5
	local v_u_65 = v_u_8.new("UIScale", {
		["Parent"] = p64
	})
	p64.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_5, (copy) v_u_65
		v_u_5:Create(v_u_65, TweenInfo.new(0.1), {
			["Scale"] = 0.92
		}):Play()
	end)
	for _, v66 in { p64.MouseButton1Up, p64.MouseLeave } do
		v66:Connect(function()
			-- upvalues: (ref) v_u_5, (copy) v_u_65
			v_u_5:Create(v_u_65, TweenInfo.new(0.1), {
				["Scale"] = 1
			}):Play()
		end)
	end
end
local function v_u_74(p68) -- name: timeLeft
	local v69 = math.floor(p68)
	local v70 = math.max(0, v69)
	local v71 = v70 // 86400
	local v72 = v70 % 86400 // 3600
	local v73 = v70 % 3600 // 60
	if v71 > 0 then
		return ("%dd %dh"):format(v71, v72)
	elseif v72 > 0 then
		return ("%dh %dm"):format(v72, v73)
	else
		return ("%dm %ds"):format(v73, v70 % 60)
	end
end
function v11.build(p75, p_u_76, p_u_77) -- name: build
	-- upvalues: (copy) v_u_15, (copy) v_u_8, (copy) v_u_12, (copy) v_u_17, (copy) v_u_18, (copy) v_u_9, (copy) v_u_41, (copy) v_u_16, (copy) v_u_22, (copy) v_u_13, (copy) v_u_14, (copy) v_u_7, (copy) v_u_63, (copy) v_u_55, (copy) v_u_6, (copy) v_u_19, (copy) v_u_67, (copy) v_u_4, (copy) v_u_1, (copy) v_u_10, (copy) v_u_5, (copy) v_u_74, (copy) v_u_23, (copy) v_u_2, (copy) v_u_20, (copy) v_u_21
	local v_u_78 = {}
	local v79 = {
		["Name"] = "QuestApp",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["Visible"] = false,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_15,
		["Size"] = UDim2.fromScale(1, 1),
		["Parent"] = p75
	}
	local v_u_80 = v_u_8.new("Frame", v79)
	local v_u_81 = v_u_8.new("UIScale", {
		["Parent"] = v_u_80
	})
	v_u_78.frame = v_u_80
	local v82 = {
		["Name"] = "Header",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_12,
		["Size"] = UDim2.new(1, 0, 0, 92),
		["Parent"] = v_u_80
	}
	local v83 = v_u_8.new("Frame", v82)
	local v84 = {
		["Rotation"] = 25,
		["Color"] = nil,
		["Parent"] = nil,
		["Color"] = ColorSequence.new(v_u_17, v_u_18),
		["Parent"] = v83
	}
	v_u_8.new("UIGradient", v84)
	local v85 = {
		["Name"] = "Back",
		["Text"] = "",
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Position"] = UDim2.fromOffset(4, 42),
		["Size"] = UDim2.fromOffset(30, 44),
		["Parent"] = v83
	}
	local v86 = v_u_8.new("TextButton", v85)
	local v87 = v_u_9.make("arrow", v_u_12, 20)
	v87.AnchorPoint = Vector2.new(0.5, 0.5)
	v87.Position = UDim2.fromScale(0.5, 0.5)
	v87.Parent = v86
	v86.Activated:Connect(function()
		-- upvalues: (copy) p_u_76
		p_u_76()
	end)
	v_u_41(v83, "Quests", 38, 40, nil, 26, 22, v_u_12, true)
	v_u_41(v83, "Deliver, stay online, drive - get paid", 38, 66, nil, 16, 12, v_u_12, false, {
		["TextTransparency"] = 0.12
	})
	local v88 = {
		["Name"] = "Tabs",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_16,
		["Position"] = UDim2.new(0, 14, 0, 104),
		["Size"] = UDim2.new(1, -28, 0, 36),
		["Parent"] = v_u_80
	}
	local v89 = v_u_8.new("Frame", v88)
	v_u_8.corner(v89, 18)
	local v90 = {
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_12,
		["Position"] = UDim2.fromOffset(3, 3),
		["Size"] = UDim2.new(0.5, -3, 1, -6),
		["Parent"] = v89
	}
	local v_u_91 = v_u_8.new("Frame", v90)
	v_u_8.corner(v_u_91, 15)
	local v_u_92 = {}
	local v_u_93 = nil
	for v94, v95 in v_u_22 do
		local v96 = {
			["Name"] = nil,
			["Text"] = "",
			["AutoButtonColor"] = false,
			["BackgroundTransparency"] = 1,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = 2,
			["Parent"] = nil,
			["Name"] = v95,
			["Position"] = UDim2.fromScale((v94 - 1) / 2, 0),
			["Size"] = UDim2.fromScale(0.5, 1),
			["Parent"] = v89
		}
		local v97 = v_u_8.new("TextButton", v96)
		local v98 = v_u_41(v97, v95 == "daily" and "Daily" or "Weekly", 0, 0, nil, 36, 14, v_u_13, true, {
			["TextXAlignment"] = nil,
			["Size"] = nil,
			["ZIndex"] = 2,
			["TextXAlignment"] = Enum.TextXAlignment.Center,
			["Size"] = UDim2.fromScale(1, 1)
		})
		local v99 = {
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Visible"] = false,
			["ZIndex"] = 3,
			["Parent"] = nil,
			["BackgroundColor3"] = Color3.fromRGB(232, 64, 64),
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.new(0.5, 34, 0.5, -6),
			["Size"] = UDim2.fromOffset(8, 8),
			["Parent"] = v97
		}
		local v100 = v_u_8.new("Frame", v99)
		v_u_8.corner(v100, 4)
		v_u_92[v95] = {
			["button"] = v97,
			["caption"] = v98,
			["dot"] = v100
		}
	end
	local v_u_101 = v_u_41(v_u_80, "", 18, 146, nil, 16, 12, v_u_14, false)
	local v_u_102 = {}
	local v_u_103 = {}
	for _, v_u_104 in v_u_22 do
		local v105 = v_u_7.PERIODS[v_u_104]
		local v106 = {
			["Name"] = nil,
			["BackgroundTransparency"] = 1,
			["BorderSizePixel"] = 0,
			["Position"] = nil,
			["Size"] = nil,
			["CanvasSize"] = nil,
			["ScrollBarThickness"] = 3,
			["ScrollBarImageColor3"] = nil,
			["ScrollingDirection"] = nil,
			["Visible"] = false,
			["Parent"] = nil,
			["Name"] = v_u_104,
			["Position"] = UDim2.fromOffset(0, 168),
			["Size"] = UDim2.new(1, 0, 1, -194),
			["CanvasSize"] = UDim2.fromOffset(0, #v105 * 90 + 6),
			["ScrollBarImageColor3"] = v_u_14,
			["ScrollingDirection"] = Enum.ScrollingDirection.Y,
			["Parent"] = v_u_80
		}
		local v107 = v_u_8.new("ScrollingFrame", v106)
		v_u_102[v_u_104] = v107
		v_u_103[v_u_104] = {}
		for v108, v_u_109 in v105 do
			local v110 = v_u_7.STATS[v_u_109.stat]
			local v111 = v_u_63(v107, (v108 - 1) * 90 + 2, 80)
			v_u_55(v111, v110.icon, v110.color, 40, 30, 30)
			v_u_41(v111, v_u_7.title(v_u_109), 58, 10, 112, 20, 14, v_u_13, true)
			v_u_41(v111, "\224\184\191" .. v_u_6.formatNumber(v_u_109.reward), 0, 10, nil, 20, 14, v_u_19, true, {
				["TextXAlignment"] = Enum.TextXAlignment.Right,
				["Position"] = UDim2.fromOffset(0, 10),
				["Size"] = UDim2.new(1, -12, 0, 20)
			})
			local v112 = {
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["BackgroundColor3"] = v_u_16,
				["Position"] = UDim2.fromOffset(58, 37),
				["Size"] = UDim2.new(1, -70, 0, 8),
				["Parent"] = v111
			}
			local v113 = v_u_8.new("Frame", v112)
			v_u_8.corner(v113, 4)
			local v114 = {
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["Parent"] = nil,
				["BackgroundColor3"] = v_u_12,
				["Size"] = UDim2.fromScale(0, 1),
				["Parent"] = v113
			}
			local v115 = v_u_8.new("Frame", v114)
			v_u_8.corner(v115, 4)
			local v116 = {
				["Color"] = ColorSequence.new(v110.color:Lerp(v_u_12, 0.25), v110.color),
				["Parent"] = v115
			}
			v_u_8.new("UIGradient", v116)
			local v117 = v_u_41(v111, "", 58, 52, 100, 18, 12, v_u_14, true)
			local v118 = {
				["Name"] = "Claim",
				["Text"] = "",
				["AutoButtonColor"] = false,
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["BackgroundColor3"] = v_u_12,
				["AnchorPoint"] = Vector2.new(1, 1),
				["Position"] = UDim2.new(1, -10, 1, -6),
				["Size"] = UDim2.fromOffset(84, 26),
				["Parent"] = v111
			}
			local v119 = v_u_8.new("TextButton", v118)
			v_u_8.corner(v119, 13)
			local v120 = v_u_8.new("UIGradient", {
				["Rotation"] = 90,
				["Parent"] = nil,
				["Parent"] = v119
			})
			local v121 = v_u_41(v119, "", 0, 0, nil, 26, 12, v_u_12, true, {
				["TextXAlignment"] = Enum.TextXAlignment.Center,
				["Size"] = UDim2.fromScale(1, 1)
			})
			v_u_67(v119)
			local v_u_122 = false
			v119.Activated:Connect(function()
				-- upvalues: (ref) v_u_122, (copy) v_u_103, (copy) v_u_104, (copy) v_u_109, (ref) v_u_93, (ref) v_u_4, (ref) v_u_6, (ref) v_u_7, (ref) v_u_1, (ref) v_u_10
				if not v_u_122 and v_u_103[v_u_104][v_u_109.id].state == "claim" then
					v_u_122 = true
					v_u_93 = v_u_93 or v_u_4:WaitForChild(v_u_6.REMOTES):WaitForChild(v_u_7.REMOTE)
					local v123 = v_u_1.invoke
					local v124 = v_u_93
					local v125 = v_u_104
					local v126 = v_u_109.id
					local v127, v128, v129 = pcall(v123, v124, "Claim", v125, v126)
					v_u_122 = false
					if v127 and v129 then
						v_u_10.show(v129, v128 and "ok" or "error")
					end
				end
			end)
			v_u_103[v_u_104][v_u_109.id] = {
				["quest"] = nil,
				["fill"] = nil,
				["amount"] = nil,
				["button"] = nil,
				["buttonFill"] = nil,
				["caption"] = nil,
				["state"] = nil,
				["quest"] = v_u_109,
				["fill"] = v115,
				["amount"] = v117,
				["button"] = v119,
				["buttonFill"] = v120,
				["caption"] = v121
			}
		end
	end
	local v_u_130 = "daily"
	local function v_u_138(p131, p132) -- name: selectTab
		-- upvalues: (ref) v_u_130, (copy) v_u_92, (ref) v_u_13, (ref) v_u_14, (copy) v_u_102, (ref) v_u_5, (copy) v_u_91
		v_u_130 = p131
		for v133, v134 in v_u_92 do
			local v135 = v134.caption
			local v136
			if v133 == p131 then
				v136 = v_u_13
			else
				v136 = v_u_14
			end
			v135.TextColor3 = v136
			v_u_102[v133].Visible = v133 == p131
		end
		local v137 = UDim2.new(p131 == "daily" and 0 or 0.5, 3, 0, 3)
		if p132 then
			v_u_5:Create(v_u_91, TweenInfo.new(0.2, Enum.EasingStyle.Quad), {
				["Position"] = v137
			}):Play()
		else
			v_u_91.Position = v137
		end
	end
	local v_u_139 = v_u_130
	local v_u_140 = nil
	for v_u_141, v142 in v_u_92 do
		v142.button.Activated:Connect(function()
			-- upvalues: (copy) v_u_138, (copy) v_u_141, (copy) v_u_78
			v_u_138(v_u_141, true)
			v_u_78.tick()
		end)
	end
	function v_u_78.tick() -- name: tick
		-- upvalues: (ref) v_u_140, (ref) v_u_139, (copy) v_u_101, (ref) v_u_74
		local v143 = v_u_140
		if v143 then
			v143 = v_u_140[v_u_139]
		end
		v_u_101.Text = not (v143 and v143.ends) and "Loading..." or ("Resets in %s"):format(v_u_74(v143.ends - os.time()))
	end
	local function v_u_175() -- name: refresh
		-- upvalues: (ref) v_u_140, (ref) v_u_23, (ref) v_u_2, (ref) v_u_22, (copy) v_u_103, (ref) v_u_7, (ref) v_u_20, (ref) v_u_12, (ref) v_u_16, (ref) v_u_14, (copy) v_u_92, (copy) v_u_78, (copy) p_u_77
		local v144 = v_u_23:GetAttribute("Quests")
		local v145
		if type(v144) == "string" then
			local v146 = v_u_2.JSONDecode
			local v147 = v_u_2
			local v148
			v148, v145 = pcall(v146, v147, v144)
			if not v148 or type(v145) ~= "table" then
				v145 = nil
			end
		else
			v145 = nil
		end
		v_u_140 = v145
		local v149 = 0
		for _, v150 in v_u_22 do
			local v151 = v_u_140
			if v151 then
				v151 = v_u_140[v150]
			end
			local v152
			if v151 then
				local v153 = v151.p
				v152 = type(v153) == "table" and (v151.p or {}) or {}
			else
				v152 = {}
			end
			local v154
			if v151 then
				local v155 = v151.c
				v154 = type(v155) == "table" and (v151.c or {}) or {}
			else
				v154 = {}
			end
			local v156 = 0
			for v157, v158 in v_u_103[v150] do
				local v159 = v158.quest
				local v160 = v152[v159.stat]
				local v161 = tonumber(v160) or 0
				local v162 = v159.goal
				local v163 = math.min(v161, v162)
				v158.fill.Size = UDim2.fromScale(v163 / v159.goal, 1)
				local v164 = v158.amount
				local v165 = "%s / %s %s"
				local v166
				if v159.stat == "km" then
					local v167 = v163 * 10
					v166 = ("%.1f"):format(math.floor(v167) / 10)
				else
					local v168 = math.floor(v163)
					v166 = tostring(v168)
				end
				local v169 = v159.stat
				local v170 = v159.goal
				local v171
				if v169 == "km" then
					local v172 = v170 * 10
					v171 = ("%.1f"):format(math.floor(v172) / 10)
				else
					local v173 = math.floor(v170)
					v171 = tostring(v173)
				end
				v164.Text = v165:format(v166, v171, v_u_7.STATS[v159.stat].unit)
				local v174 = v154[v157] and "claimed" or (v159.goal <= v163 and "claim" or "doing")
				v158.state = v174
				v158.button.Visible = v174 ~= "doing"
				if v174 == "claim" then
					v156 = v156 + 1
					v158.buttonFill.Color = ColorSequence.new(v_u_20:Lerp(v_u_12, 0.15), v_u_20)
					v158.caption.Text = "Claim"
					v158.caption.TextColor3 = v_u_12
				else
					if v174 ~= "claimed" then
						continue
					end
					v158.buttonFill.Color = ColorSequence.new(v_u_16, v_u_16)
					v158.caption.Text = "Claimed \226\156\147"
					v158.caption.TextColor3 = v_u_14
				end
			end
			v_u_92[v150].dot.Visible = v156 > 0
			v149 = v149 + v156
		end
		v_u_78.tick()
		if p_u_77 then
			p_u_77(v149)
		end
	end
	local v_u_176 = false
	function v_u_78.show() -- name: show
		-- upvalues: (ref) v_u_176, (copy) v_u_80, (copy) v_u_175, (copy) v_u_81, (ref) v_u_5, (ref) v_u_21
		v_u_176 = true
		v_u_80.Visible = true
		v_u_175()
		v_u_81.Scale = 0.92
		v_u_5:Create(v_u_81, v_u_21, {
			["Scale"] = 1
		}):Play()
	end
	function v_u_78.hide() -- name: hide
		-- upvalues: (ref) v_u_176, (copy) v_u_80
		v_u_176 = false
		v_u_80.Visible = false
	end
	function v_u_78.isShown() -- name: isShown
		-- upvalues: (ref) v_u_176
		return v_u_176
	end
	v_u_130 = "daily"
	local v_u_177 = v_u_176
	for v178, v179 in v_u_92 do
		local v180 = v179.caption
		local v181
		if v178 == "daily" then
			v181 = v_u_13
		else
			v181 = v_u_14
		end
		v180.TextColor3 = v181
		v_u_102[v178].Visible = v178 == "daily"
	end
	v_u_91.Position = UDim2.new(0, 3, 0, 3)
	v_u_23:GetAttributeChangedSignal("Quests"):Connect(v_u_175)
	v_u_175()
	task.spawn(function()
		-- upvalues: (copy) v_u_80, (ref) v_u_177, (copy) v_u_78
		while v_u_80.Parent do
			task.wait(1)
			if not v_u_177 then
				continue
			end
			v_u_78.tick()
		end
	end)
	return v_u_78
end
return v11