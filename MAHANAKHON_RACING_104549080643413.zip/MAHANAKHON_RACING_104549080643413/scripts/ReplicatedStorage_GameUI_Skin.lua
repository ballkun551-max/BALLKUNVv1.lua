-- Path: ReplicatedStorage/GameUI/Skin
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = require(game:GetService("ReplicatedStorage"):WaitForChild("UiOwn")).Instance
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("TweenService")
local v4 = v2:WaitForChild("GameUI")
local v_u_5 = require(v4:WaitForChild("Theme"))
local v_u_6 = require(v4:WaitForChild("Icons"))
local v_u_7 = {
	["PANEL"] = Color3.fromRGB(14, 15, 20),
	["IDLE"] = Color3.fromRGB(38, 40, 50),
	["SELECTED"] = v_u_5.YELLOW,
	["DISABLED"] = Color3.fromRGB(46, 48, 58),
	["DARK_TEXT"] = v_u_5.DARK_TEXT,
	["ACCENT"] = v_u_5.ACCENT
}
local v_u_8 = Color3.fromRGB(232, 234, 240)
local v_u_9 = Color3.fromRGB(148, 151, 165)
local v_u_10 = Color3.fromRGB(28, 29, 38)
local v_u_11 = Color3.fromRGB(9, 10, 14)
local v_u_12 = Font.new("rbxasset://fonts/families/BuilderSans.json", Enum.FontWeight.Bold)
local v_u_13 = Font.new("rbxasset://fonts/families/BuilderSans.json", Enum.FontWeight.Medium)
local v_u_14 = Font.new("rbxasset://fonts/families/Montserrat.json", Enum.FontWeight.Heavy)
local v_u_15 = TweenInfo.new(0.1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
local function v_u_19(p16) -- name: font
	-- upvalues: (copy) v_u_14, (copy) v_u_12, (copy) v_u_13
	local v17 = p16.FontFace
	if v17.Family:find("Gotham") then
		if v17.Weight.Value >= Enum.FontWeight.Heavy.Value and (p16.TextSize >= 20 and p16:IsA("TextLabel")) then
			p16.FontFace = v_u_14
			return
		end
		local v18
		if v17.Weight.Value >= Enum.FontWeight.SemiBold.Value then
			v18 = v_u_12
		else
			v18 = v_u_13
		end
		p16.FontFace = v18
	end
end
local function v_u_26(p20) -- name: tabLook
	-- upvalues: (copy) v_u_7, (copy) v_u_9, (copy) v_u_1
	p20.BackgroundTransparency = 1
	p20.AutoButtonColor = false
	local v21 = p20.BackgroundColor3 == v_u_7.SELECTED
	local v22
	if v21 then
		v22 = Color3.new(1, 1, 1)
	else
		v22 = v_u_9
	end
	p20.TextColor3 = v22
	local v23 = p20:FindFirstChild("SkinUnderline")
	if not v23 then
		v23 = v_u_1.new("Frame")
		v23.Name = "SkinUnderline"
		v23.BorderSizePixel = 0
		v23.BackgroundColor3 = v_u_7.ACCENT
		v23.AnchorPoint = Vector2.new(0.5, 1)
		v23.Position = UDim2.new(0.5, 0, 1, -3)
		v23.Size = UDim2.new(0.62, 0, 0, 3)
		v23.Parent = p20
		local v24 = v23:FindFirstChildOfClass("UICorner") or v_u_1.new("UICorner")
		v24.CornerRadius = UDim.new(0, 2)
		v24.Parent = v23
	end
	v23.Visible = v21
	local v25 = p20:FindFirstChildOfClass("UIStroke")
	if v25 then
		v25.Transparency = 1
	end
end
local function v_u_30(p27) -- name: press
	-- upvalues: (copy) v_u_1, (copy) v_u_3, (copy) v_u_15
	if not p27:GetAttribute("SkinPress") then
		p27:SetAttribute("SkinPress", true)
		local v_u_28 = v_u_1.new("UIScale")
		v_u_28.Parent = p27
		p27.MouseButton1Down:Connect(function()
			-- upvalues: (ref) v_u_3, (copy) v_u_28, (ref) v_u_15
			v_u_3:Create(v_u_28, v_u_15, {
				["Scale"] = 0.96
			}):Play()
		end)
		for _, v29 in { p27.MouseButton1Up, p27.MouseLeave } do
			v29:Connect(function()
				-- upvalues: (ref) v_u_3, (copy) v_u_28, (ref) v_u_15
				v_u_3:Create(v_u_28, v_u_15, {
					["Scale"] = 1
				}):Play()
			end)
		end
	end
end
local function v_u_35(p31) -- name: look
	-- upvalues: (copy) v_u_26, (copy) v_u_1, (copy) v_u_7, (copy) v_u_8, (copy) v_u_9, (copy) v_u_5
	if p31.Text == "" or p31:GetAttribute("SkinSkip") then
		return
	else
		local v32
		if p31.Name:match("^Tab%u") == nil then
			v32 = false
		else
			v32 = p31.Text ~= ""
		end
		if v32 then
			v_u_26(p31)
			return
		else
			if p31:GetAttribute("SkinSeeThrough") == nil then
				p31:SetAttribute("SkinSeeThrough", p31.BackgroundTransparency >= 0.99)
			end
			if not p31:GetAttribute("SkinSeeThrough") then
				local v33 = p31.BackgroundColor3
				local v34 = p31:FindFirstChild("SkinEdge")
				if not v34 then
					if p31:FindFirstChildOfClass("UIStroke") then
						v34 = nil
					else
						v34 = v_u_1.new("UIStroke")
						v34.Name = "SkinEdge"
						v34.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
						v34.Parent = p31
					end
				end
				if v33 == v_u_7.SELECTED then
					p31.BackgroundTransparency = 0
					p31.TextColor3 = v_u_7.DARK_TEXT
					p31:SetAttribute("SkinDark", true)
					if v34 then
						v34.Color = v_u_7.ACCENT
						v34.Thickness = 5
						v34.Transparency = 0.72
						return
					end
				else
					if p31:GetAttribute("SkinDark") then
						p31:SetAttribute("SkinDark", nil)
					end
					if v33 == v_u_7.IDLE then
						p31.BackgroundTransparency = 0.22
						p31.TextColor3 = v_u_8
					elseif v33 == v_u_7.DISABLED then
						p31.BackgroundTransparency = 0.75
						p31.TextColor3 = v_u_9
					else
						p31.BackgroundTransparency = 0
						p31.TextColor3 = v_u_5.readable(v33, Color3.new(1, 1, 1))
					end
					if v34 then
						v34.Color = Color3.new(1, 1, 1)
						v34.Thickness = 1
						v34.Transparency = v33 == v_u_7.IDLE and 0.93 or (v33 == v_u_7.DISABLED and 0.86 or 1)
					end
				end
			end
		end
	end
end
local function v_u_39(p_u_36) -- name: closeKey
	-- upvalues: (copy) v_u_1, (copy) v_u_6, (copy) v_u_9, (copy) v_u_5
	if not p_u_36:GetAttribute("SkinClose") then
		p_u_36:SetAttribute("SkinClose", true)
		p_u_36:SetAttribute("SkinSkip", true)
		p_u_36.Text = ""
		p_u_36.AutoButtonColor = false
		p_u_36.BackgroundColor3 = Color3.new(1, 1, 1)
		p_u_36.BackgroundTransparency = 0.94
		p_u_36.Size = UDim2.fromOffset(36, 36)
		p_u_36.Position = p_u_36.Position + UDim2.fromOffset(16, 4)
		local v37 = p_u_36:FindFirstChildOfClass("UICorner") or v_u_1.new("UICorner")
		v37.CornerRadius = UDim.new(0, 18)
		v37.Parent = p_u_36
		local v38 = v_u_6.make("close", v_u_9, 18)
		v38.Name = "X"
		v38.AnchorPoint = Vector2.new(0.5, 0.5)
		v38.Position = UDim2.fromScale(0.5, 0.5)
		v38.Parent = p_u_36
		p_u_36.MouseEnter:Connect(function()
			-- upvalues: (copy) p_u_36, (ref) v_u_5
			p_u_36.BackgroundColor3 = v_u_5.RED
			p_u_36.BackgroundTransparency = 0.2
		end)
		p_u_36.MouseLeave:Connect(function()
			-- upvalues: (copy) p_u_36
			p_u_36.BackgroundColor3 = Color3.new(1, 1, 1)
			p_u_36.BackgroundTransparency = 0.94
		end)
	end
end
function v_u_7.glass(p40) -- name: glass
	-- upvalues: (copy) v_u_1, (copy) v_u_10, (copy) v_u_11
	if not p40:GetAttribute("SkinPanel") then
		p40:SetAttribute("SkinPanel", true)
		p40.BackgroundColor3 = Color3.new(1, 1, 1)
		p40.BackgroundTransparency = 0.1
		if not p40:FindFirstChildOfClass("UIGradient") then
			local v41 = v_u_1.new("UIGradient")
			v41.Name = "SkinGlass"
			v41.Rotation = 90
			v41.Color = ColorSequence.new(v_u_10, v_u_11)
			v41.Parent = p40
		end
		local v42 = p40:FindFirstChildOfClass("UICorner") or v_u_1.new("UICorner")
		v42.CornerRadius = UDim.new(0, 14)
		v42.Parent = p40
		if not p40:FindFirstChildOfClass("UIStroke") then
			local v43 = v_u_1.new("UIStroke")
			v43.Name = "SkinHair"
			v43.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
			v43.Parent = p40
		end
		for _, v44 in p40:GetChildren() do
			if not v44:IsA("UIStroke") then
				continue
			end
			v44.Color = Color3.new(1, 1, 1)
			v44.Transparency = 0.9
		end
	end
end
v_u_7.decorate = v_u_7.glass
local function v_u_49(p_u_45, p46) -- name: one
	-- upvalues: (copy) v_u_19, (copy) v_u_39, (copy) v_u_1, (copy) v_u_30, (copy) v_u_35, (copy) v_u_7
	if p_u_45:IsA("TextLabel") or (p_u_45:IsA("TextButton") or p_u_45:IsA("TextBox")) then
		v_u_19(p_u_45)
		if not p_u_45:GetAttribute("SkinWatched") then
			p_u_45:SetAttribute("SkinWatched", true)
			p_u_45:GetPropertyChangedSignal("FontFace"):Connect(function()
				-- upvalues: (ref) v_u_19, (copy) p_u_45
				v_u_19(p_u_45)
			end)
		end
	end
	if p_u_45:IsA("TextButton") then
		if p_u_45.Name == "Close" and p_u_45.Text ~= "" then
			v_u_39(p_u_45)
		end
		if p_u_45.Text == "" then
			if p_u_45.Name:sub(1, 6) == "Swatch" then
				v_u_30(p_u_45)
			end
		elseif not p_u_45:GetAttribute("SkinSkip") then
			local v47
			if p_u_45.Name:match("^Tab%u") == nil then
				v47 = false
			else
				v47 = p_u_45.Text ~= ""
			end
			if not v47 then
				local v48 = p_u_45:FindFirstChildOfClass("UICorner") or v_u_1.new("UICorner")
				v48.CornerRadius = UDim.new(0, 9)
				v48.Parent = p_u_45
			end
			v_u_30(p_u_45)
		end
		v_u_35(p_u_45)
		if not p_u_45:GetAttribute("SkinInk") then
			p_u_45:SetAttribute("SkinInk", true)
			p_u_45:GetPropertyChangedSignal("BackgroundColor3"):Connect(function()
				-- upvalues: (ref) v_u_35, (copy) p_u_45
				v_u_35(p_u_45)
			end)
		end
	end
	if p_u_45:IsA("Frame") and (p_u_45.Parent == p46 and p_u_45.BackgroundTransparency < 0.5) then
		v_u_7.glass(p_u_45)
	end
end
function v_u_7.apply(p_u_50) -- name: apply
	-- upvalues: (copy) v_u_49
	for _, v51 in p_u_50:GetDescendants() do
		v_u_49(v51, p_u_50)
	end
	p_u_50.DescendantAdded:Connect(function(p52)
		-- upvalues: (ref) v_u_49, (copy) p_u_50
		task.defer(v_u_49, p52, p_u_50)
	end)
	p_u_50:GetPropertyChangedSignal("Enabled"):Connect(function()
		-- upvalues: (copy) p_u_50, (ref) v_u_49
		if p_u_50.Enabled then
			for _, v53 in p_u_50:GetDescendants() do
				v_u_49(v53, p_u_50)
			end
		end
	end)
end
return v_u_7