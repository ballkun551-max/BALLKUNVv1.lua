-- Path: ReplicatedStorage/GameUI/Poses
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = {}
local v_u_2 = CFrame.Angles
local v_u_3 = math.sin
local function v_u_8(...) -- name: merge
	local v4 = {}
	for _, v5 in { ... } do
		for v6, v7 in v5 do
			v4[v6] = v7
		end
	end
	return v4
end
local function v_u_9(_) -- name: crouch
	-- upvalues: (copy) v_u_2
	return {
		["Root"] = nil,
		["LowerTorso"] = nil,
		["RightHip"] = nil,
		["RightKnee"] = nil,
		["RightAnkle"] = nil,
		["LeftHip"] = nil,
		["LeftKnee"] = nil,
		["LeftAnkle"] = nil,
		["Waist"] = nil,
		["Root"] = CFrame.new(0, -1.55, 0),
		["RightHip"] = v_u_2(1.35, 0, 0.05),
		["RightKnee"] = v_u_2(-2.05, 0, 0),
		["RightAnkle"] = v_u_2(0.7, 0, 0),
		["LeftHip"] = v_u_2(0.55, 0, -0.05),
		["LeftKnee"] = v_u_2(-2.3, 0, 0),
		["LeftAnkle"] = v_u_2(0.2, 0, 0),
		["Waist"] = v_u_2(0.32, 0, 0)
	}
end
v_u_1.list = {
	["crossArms"] = function(p10) -- name: crossArms
		-- upvalues: (copy) v_u_2, (copy) v_u_3
		return {
			["Root"] = v_u_2(0, 0, 0.04),
			["Waist"] = v_u_2(-0.06, 0, 0) * v_u_2(v_u_3(p10 * 1.7) * 0.018, 0, 0),
			["Neck"] = v_u_2(-0.14, 0.18, 0),
			["RightShoulder"] = v_u_2(0.5, 0, -0.05) * v_u_2(0, 0.95, 0),
			["RightElbow"] = v_u_2(1.95, 0, 0),
			["LeftShoulder"] = v_u_2(0.42, 0, 0.05) * v_u_2(0, -0.95, 0),
			["LeftElbow"] = v_u_2(1.85, 0, 0),
			["RightHip"] = v_u_2(0, 0, 0.1),
			["LeftHip"] = v_u_2(0.05, 0, -0.04),
			["RightKnee"] = v_u_2(-0.05, 0, 0)
		}
	end,
	["holdBox"] = function(p11) -- name: holdBox
		-- upvalues: (copy) v_u_2, (copy) v_u_3
		return {
			["Waist"] = v_u_2(-0.04, 0.12, 0) * v_u_2(v_u_3(p11 * 1.7) * 0.018, 0, 0),
			["Neck"] = v_u_2(0.05, -0.2, 0.05),
			["RightShoulder"] = v_u_2(0.85, 0, 0) * v_u_2(0, 0.45, 0),
			["RightElbow"] = v_u_2(1.15, 0, 0),
			["LeftShoulder"] = v_u_2(0.85, 0, 0) * v_u_2(0, -0.45, 0),
			["LeftElbow"] = v_u_2(1.15, 0, 0),
			["LeftHip"] = v_u_2(0.12, 0, 0),
			["LeftKnee"] = v_u_2(-0.18, 0, 0)
		}
	end,
	["wrenchShoulder"] = function(p12) -- name: wrenchShoulder
		-- upvalues: (copy) v_u_8, (copy) v_u_2, (copy) v_u_3
		return v_u_8({
			["LeftShoulder"] = v_u_2(-0.2, 0, -0.62) * v_u_2(0, -2.2, 0),
			["LeftElbow"] = v_u_2(1.75, 0, 0),
			["LeftWrist"] = v_u_2(0, 0, 0.3)
		}, {
			["Waist"] = v_u_2(-0.03, -0.1, 0) * v_u_2(v_u_3(p12 * 1.7) * 0.018, 0, 0),
			["Neck"] = v_u_2(-0.08, 0.12, -0.05),
			["RightShoulder"] = v_u_2(0, 0, 1.25) * v_u_2(0, -1.5, 0),
			["RightElbow"] = v_u_2(2.1, 0, 0),
			["RightWrist"] = v_u_2(0.3, 0, 0),
			["RightHip"] = v_u_2(0, 0, 0.12),
			["RightKnee"] = v_u_2(-0.12, 0, 0)
		})
	end,
	["bagShoulder"] = function(p13) -- name: bagShoulder
		-- upvalues: (copy) v_u_8, (copy) v_u_2, (copy) v_u_3
		return v_u_8({
			["LeftShoulder"] = v_u_2(-0.2, 0, -0.62) * v_u_2(0, -2.2, 0),
			["LeftElbow"] = v_u_2(1.75, 0, 0),
			["LeftWrist"] = v_u_2(0, 0, 0.3)
		}, {
			["Waist"] = v_u_2(0, 0, -0.06) * v_u_2(v_u_3(p13 * 1.7) * 0.018, 0, 0),
			["Neck"] = v_u_2(-0.1, -0.1, 0.06),
			["RightShoulder"] = v_u_2(0, 0, 1.35) * v_u_2(0, -1.5, 0),
			["RightElbow"] = v_u_2(1.95, 0, 0),
			["LeftHip"] = v_u_2(0, 0, -0.08)
		})
	end,
	["phone"] = function(p14) -- name: phone
		-- upvalues: (copy) v_u_2, (copy) v_u_3
		return {
			["Waist"] = v_u_2(0.06, 0, 0) * v_u_2(v_u_3(p14 * 1.7) * 0.018, 0, 0),
			["Neck"] = v_u_2(0.38, 0.05, 0),
			["RightShoulder"] = v_u_2(0.75, 0, 0) * v_u_2(0, 0.55, 0),
			["RightElbow"] = v_u_2(1.6, 0, 0),
			["RightWrist"] = v_u_2(-0.3, 0, 0),
			["LeftShoulder"] = v_u_2(-0.18, 0, -0.12) * v_u_2(0, -0.4, 0),
			["LeftElbow"] = v_u_2(0.35, 0, 0),
			["RightHip"] = v_u_2(0.14, 0, 0.04),
			["RightKnee"] = v_u_2(-0.3, 0, 0),
			["RightAnkle"] = v_u_2(0.12, 0, 0)
		}
	end,
	["bagSide"] = function(p15) -- name: bagSide
		-- upvalues: (copy) v_u_8, (copy) v_u_2, (copy) v_u_3
		return v_u_8({
			["LeftShoulder"] = v_u_2(-0.2, 0, -0.62) * v_u_2(0, -2.2, 0),
			["LeftElbow"] = v_u_2(1.75, 0, 0),
			["LeftWrist"] = v_u_2(0, 0, 0.3)
		}, {
			["Waist"] = v_u_2(0, -0.08, 0) * v_u_2(v_u_3(p15 * 1.7) * 0.018, 0, 0),
			["Neck"] = v_u_2(-0.05, 0.15, 0),
			["RightShoulder"] = v_u_2(0.1, 0, 0.12),
			["RightElbow"] = v_u_2(0.2, 0, 0),
			["RightHip"] = v_u_2(0, 0, 0.12),
			["LeftHip"] = v_u_2(0.05, 0, -0.04),
			["LeftKnee"] = v_u_2(-0.12, 0, 0)
		})
	end,
	["carryParcel"] = function(p16) -- name: carryParcel
		-- upvalues: (copy) v_u_2, (copy) v_u_3
		return {
			["Waist"] = v_u_2(-0.04, 0, 0) * v_u_2(v_u_3(p16 * 1.7) * 0.018, 0, 0),
			["Neck"] = v_u_2(0.05, -0.15, 0),
			["RightShoulder"] = v_u_2(0.35, 0, 0),
			["RightElbow"] = v_u_2(1.25, 0, 0),
			["LeftShoulder"] = v_u_2(0.35, 0, 0),
			["LeftElbow"] = v_u_2(1.25, 0, 0),
			["LeftHip"] = v_u_2(0.1, 0, 0),
			["LeftKnee"] = v_u_2(-0.15, 0, 0)
		}
	end,
	["showBag"] = function(p17) -- name: showBag
		-- upvalues: (copy) v_u_2, (copy) v_u_3
		return {
			["Waist"] = v_u_2(-0.06, 0.18, 0) * v_u_2(v_u_3(p17 * 1.7) * 0.018, 0, 0),
			["Neck"] = v_u_2(-0.12, 0.12, 0),
			["RightShoulder"] = v_u_2(1.25, 0, 0.2),
			["RightElbow"] = v_u_2(0.5, 0, 0),
			["RightWrist"] = v_u_2(-1.55, 0, 0),
			["LeftShoulder"] = v_u_2(1, 0, -0.25) * v_u_2(0, -0.3, 0),
			["LeftElbow"] = v_u_2(1.45, 0, 0),
			["RightHip"] = v_u_2(0, 0, 0.18),
			["LeftHip"] = v_u_2(0.12, 0, -0.18),
			["LeftKnee"] = v_u_2(-0.15, 0, 0)
		}
	end,
	["offerParcel"] = function(p18) -- name: offerParcel
		-- upvalues: (copy) v_u_2, (copy) v_u_3
		return {
			["Waist"] = v_u_2(0.14, 0, 0) * v_u_2(v_u_3(p18 * 1.7) * 0.018, 0, 0),
			["Neck"] = v_u_2(-0.18, 0, 0),
			["RightShoulder"] = v_u_2(1, 0, 0),
			["RightElbow"] = v_u_2(0.6, 0, 0),
			["LeftShoulder"] = v_u_2(1, 0, 0),
			["LeftElbow"] = v_u_2(0.6, 0, 0),
			["RightHip"] = v_u_2(-0.1, 0, 0.08),
			["LeftHip"] = v_u_2(0.25, 0, -0.08),
			["LeftKnee"] = v_u_2(-0.3, 0, 0)
		}
	end,
	["wrenchReady"] = function(p19) -- name: wrenchReady
		-- upvalues: (copy) v_u_3, (copy) v_u_8, (copy) v_u_2
		local v20 = v_u_3(p19 * 2.2) * 0.05
		return v_u_8({
			["LeftShoulder"] = v_u_2(-0.2, 0, -0.62) * v_u_2(0, -2.2, 0),
			["LeftElbow"] = v_u_2(1.75, 0, 0),
			["LeftWrist"] = v_u_2(0, 0, 0.3)
		}, {
			["Waist"] = v_u_2(-0.04, 0.2, 0) * v_u_2(v_u_3(p19 * 1.7) * 0.018, 0, 0),
			["Neck"] = v_u_2(-0.1, -0.18, 0),
			["RightShoulder"] = v_u_2(v20 + 0.9, 0, 0.5),
			["RightElbow"] = v_u_2(1.85 - v20, 0, 0),
			["RightWrist"] = v_u_2(0.2, 0, 0),
			["RightHip"] = v_u_2(0, 0, 0.14),
			["LeftHip"] = v_u_2(0, 0, -0.1)
		})
	end,
	["selfie"] = function(p21) -- name: selfie
		-- upvalues: (copy) v_u_2, (copy) v_u_3
		return {
			["Waist"] = v_u_2(-0.08, -0.2, 0.05) * v_u_2(v_u_3(p21 * 1.7) * 0.018, 0, 0),
			["Neck"] = v_u_2(-0.12, -0.3, 0.18),
			["RightShoulder"] = v_u_2(1.55, 0, 0.55) * v_u_2(0, 0.6, 0),
			["RightElbow"] = v_u_2(0.25, 0, 0),
			["RightWrist"] = v_u_2(-0.5, 0, 0),
			["LeftShoulder"] = v_u_2(1.3, 0, -0.3) * v_u_2(0, -0.9, 0),
			["LeftElbow"] = v_u_2(2.2, 0, 0),
			["LeftHip"] = v_u_2(0.15, 0, 0),
			["LeftKnee"] = v_u_2(-0.35, 0, 0),
			["LeftAnkle"] = v_u_2(0.2, 0, 0)
		}
	end,
	["shadesTouch"] = function(p22) -- name: shadesTouch
		-- upvalues: (copy) v_u_8, (copy) v_u_2, (copy) v_u_3
		return v_u_8({
			["LeftShoulder"] = v_u_2(-0.2, 0, -0.62) * v_u_2(0, -2.2, 0),
			["LeftElbow"] = v_u_2(1.75, 0, 0),
			["LeftWrist"] = v_u_2(0, 0, 0.3)
		}, {
			["Waist"] = v_u_2(-0.05, 0.18, 0) * v_u_2(v_u_3(p22 * 1.7) * 0.018, 0, 0),
			["Neck"] = v_u_2(-0.12, -0.15, 0),
			["RightShoulder"] = v_u_2(1.15, 0, 0.35) * v_u_2(0, 0.9, 0),
			["RightElbow"] = v_u_2(2.35, 0, 0),
			["RightWrist"] = v_u_2(0.2, 0, 0),
			["RightHip"] = v_u_2(0, 0, 0.14),
			["LeftHip"] = v_u_2(0, 0, -0.1)
		})
	end,
	["point"] = function(p23) -- name: point
		-- upvalues: (copy) v_u_8, (copy) v_u_2, (copy) v_u_3
		return v_u_8({
			["LeftShoulder"] = v_u_2(-0.2, 0, -0.62) * v_u_2(0, -2.2, 0),
			["LeftElbow"] = v_u_2(1.75, 0, 0),
			["LeftWrist"] = v_u_2(0, 0, 0.3)
		}, {
			["Waist"] = v_u_2(0.08, -0.22, 0) * v_u_2(v_u_3(p23 * 1.7) * 0.018, 0, 0),
			["Neck"] = v_u_2(-0.05, 0.22, 0),
			["RightShoulder"] = v_u_2(1.45, 0, 0.12),
			["RightElbow"] = v_u_2(0.12, 0, 0),
			["RightHip"] = v_u_2(0.12, 0, 0.16),
			["RightKnee"] = v_u_2(-0.15, 0, 0),
			["LeftHip"] = v_u_2(-0.05, 0, -0.14)
		})
	end,
	["flex"] = function(p24) -- name: flex
		-- upvalues: (copy) v_u_3, (copy) v_u_2
		local v25 = v_u_3(p24 * 2.4) * 0.06
		return {
			["Waist"] = v_u_2(-0.08, 0, 0) * v_u_2(v_u_3(p24 * 1.7) * 0.018, 0, 0),
			["Neck"] = v_u_2(-0.15, 0, 0),
			["RightShoulder"] = v_u_2(0, 0, v25 + 1.45) * v_u_2(0, -1.5, 0),
			["RightElbow"] = v_u_2(1.7, 0, 0),
			["LeftShoulder"] = v_u_2(0, 0, -1.45 - v25) * v_u_2(0, 1.5, 0),
			["LeftElbow"] = v_u_2(1.7, 0, 0),
			["RightHip"] = v_u_2(0, 0, 0.18),
			["LeftHip"] = v_u_2(0, 0, -0.18)
		}
	end,
	["bagThumbsUp"] = function(p26) -- name: bagThumbsUp
		-- upvalues: (copy) v_u_2, (copy) v_u_3
		return {
			["Waist"] = v_u_2(-0.05, 0.15, 0) * v_u_2(v_u_3(p26 * 1.7) * 0.018, 0, 0),
			["Neck"] = v_u_2(-0.12, -0.12, 0.05),
			["RightShoulder"] = v_u_2(0, 0, 1.35) * v_u_2(0, -1.5, 0),
			["RightElbow"] = v_u_2(1.95, 0, 0),
			["LeftShoulder"] = v_u_2(1.1, 0, -0.25) * v_u_2(0, -0.3, 0),
			["LeftElbow"] = v_u_2(1.4, 0, 0),
			["RightHip"] = v_u_2(0, 0, 0.2),
			["LeftHip"] = v_u_2(0.1, 0, -0.2),
			["LeftKnee"] = v_u_2(-0.15, 0, 0)
		}
	end,
	["squat"] = function(p27) -- name: squat
		-- upvalues: (copy) v_u_2, (copy) v_u_3
		return {
			["Root"] = CFrame.new(0, -1.75, 0),
			["Waist"] = v_u_2(0.3, 0, 0) * v_u_2(v_u_3(p27 * 1.7) * 0.018, 0, 0),
			["Neck"] = v_u_2(-0.35, 0, 0),
			["RightHip"] = v_u_2(1.7, 0, 0.4),
			["RightKnee"] = v_u_2(-2.45, 0, 0),
			["RightAnkle"] = v_u_2(0.75, 0, 0),
			["LeftHip"] = v_u_2(1.7, 0, -0.4),
			["LeftKnee"] = v_u_2(-2.45, 0, 0),
			["LeftAnkle"] = v_u_2(0.75, 0, 0),
			["RightShoulder"] = v_u_2(0.7, 0, 0.15),
			["RightElbow"] = v_u_2(1, 0, 0),
			["LeftShoulder"] = v_u_2(0.7, 0, -0.15),
			["LeftElbow"] = v_u_2(1, 0, 0)
		}
	end,
	["leanBack"] = function(p28) -- name: leanBack
		-- upvalues: (copy) v_u_2, (copy) v_u_3
		return {
			["Root"] = v_u_2(0, 0.15, 0),
			["Waist"] = v_u_2(-0.16, 0, 0) * v_u_2(v_u_3(p28 * 1.7) * 0.018, 0, 0),
			["Neck"] = v_u_2(0.05, -0.3, 0.08),
			["RightShoulder"] = v_u_2(0.5, 0, -0.05) * v_u_2(0, 0.95, 0),
			["RightElbow"] = v_u_2(1.95, 0, 0),
			["LeftShoulder"] = v_u_2(0.42, 0, 0.05) * v_u_2(0, -0.95, 0),
			["LeftElbow"] = v_u_2(1.85, 0, 0),
			["RightHip"] = v_u_2(0.05, 0, -0.22),
			["RightKnee"] = v_u_2(-0.12, 0, 0),
			["LeftHip"] = v_u_2(0, 0, 0.05)
		}
	end,
	["bolts"] = function(p29) -- name: bolts
		-- upvalues: (copy) v_u_3, (copy) v_u_8, (copy) v_u_9, (copy) v_u_2
		local v30 = v_u_3(p29 * 9)
		return v_u_8(v_u_9(p29), {
			["RightShoulder"] = v_u_2(v30 * 0.18 + 1.25, 0, 0.1) * v_u_2(0, 0.3, 0),
			["RightElbow"] = v_u_2(v30 * 0.3 + 0.55, 0, 0),
			["LeftShoulder"] = v_u_2(1.1, 0, -0.1) * v_u_2(0, -0.3, 0),
			["LeftElbow"] = v_u_2(0.5, 0, 0),
			["Neck"] = v_u_2(0.2, 0, 0)
		})
	end,
	["gauge"] = function(p31) -- name: gauge
		-- upvalues: (copy) v_u_8, (copy) v_u_9, (copy) v_u_2, (copy) v_u_3
		return v_u_8(v_u_9(p31), {
			["RightShoulder"] = v_u_2(1, 0, 0.1),
			["RightElbow"] = v_u_2(v_u_3(p31 * 3) * 0.08 + 0.7, 0, 0),
			["LeftShoulder"] = v_u_2(0.9, 0, -0.15),
			["LeftElbow"] = v_u_2(0.9, 0, 0),
			["Neck"] = v_u_2(0.3, 0, 0)
		})
	end,
	["scrub"] = function(p32) -- name: scrub
		-- upvalues: (copy) v_u_8, (copy) v_u_2, (copy) v_u_3
		local v33 = p32 * 6
		return v_u_8({
			["LeftShoulder"] = v_u_2(-0.2, 0, -0.62) * v_u_2(0, -2.2, 0),
			["LeftElbow"] = v_u_2(1.75, 0, 0),
			["LeftWrist"] = v_u_2(0, 0, 0.3)
		}, {
			["Waist"] = v_u_2(0.12, v_u_3(v33) * 0.08, 0),
			["Neck"] = v_u_2(0.05, 0, 0),
			["RightShoulder"] = v_u_2(v_u_3(v33) * 0.3 + 1.35, 0, math.cos(v33) * 0.25 + 0.25),
			["RightElbow"] = v_u_2(v_u_3(v33 + 1) * 0.2 + 0.35, 0, 0),
			["RightHip"] = v_u_2(0.1, 0, 0.08),
			["LeftHip"] = v_u_2(-0.05, 0, -0.08)
		})
	end,
	["pour"] = function(p34) -- name: pour
		-- upvalues: (copy) v_u_2, (copy) v_u_3
		return {
			["Waist"] = v_u_2(0.35, 0, 0),
			["Neck"] = v_u_2(0.25, 0, 0),
			["RightShoulder"] = v_u_2(1.45, 0, 0.1),
			["RightElbow"] = v_u_2(0.55, 0, 0),
			["RightWrist"] = v_u_2(0, 0, -0.6 - v_u_3(p34 * 2) * 0.1),
			["LeftShoulder"] = v_u_2(1, 0, -0.1) * v_u_2(0, -0.4, 0),
			["LeftElbow"] = v_u_2(0.6, 0, 0),
			["RightHip"] = v_u_2(-0.1, 0, 0),
			["LeftHip"] = v_u_2(0.25, 0, 0),
			["LeftKnee"] = v_u_2(-0.3, 0, 0)
		}
	end,
	["mash"] = function(p35) -- name: mash
		-- upvalues: (copy) v_u_3, (copy) v_u_2
		local v36 = v_u_3(p35 * 7)
		return {
			["Waist"] = v_u_2(0.3, v36 * 0.25, 0),
			["Neck"] = v_u_2(0.15, -v36 * 0.1, 0),
			["RightShoulder"] = v_u_2(v36 * 0.35 + 0.95, 0, 0.1) * v_u_2(0, 0.4, 0),
			["RightElbow"] = v_u_2(0.6, 0, 0),
			["LeftShoulder"] = v_u_2(0.95 - v36 * 0.35, 0, -0.1) * v_u_2(0, -0.4, 0),
			["LeftElbow"] = v_u_2(0.6, 0, 0),
			["RightHip"] = v_u_2(0.25, 0, 0.1),
			["RightKnee"] = v_u_2(-0.4, 0, 0),
			["LeftHip"] = v_u_2(0.2, 0, -0.1),
			["LeftKnee"] = v_u_2(-0.35, 0, 0)
		}
	end,
	["stack"] = function(p37) -- name: stack
		-- upvalues: (copy) v_u_3, (copy) v_u_2
		local v38 = v_u_3(p37 * 4)
		local v39 = {}
		local v40 = v38 * 0.1 + 0.3
		v39.Root = CFrame.new(0, -v40, 0)
		v39.Waist = v_u_2(v38 * 0.15 + 0.55, 0, 0)
		v39.Neck = v_u_2(-0.1, 0, 0)
		v39.RightShoulder = v_u_2(v38 * 0.35 + 1.1, 0, 0.1)
		v39.RightElbow = v_u_2(0.4, 0, 0)
		v39.LeftShoulder = v_u_2(0.9 - v38 * 0.2, 0, -0.1)
		v39.LeftElbow = v_u_2(0.5, 0, 0)
		v39.RightHip = v_u_2(0.45, 0, 0.1)
		v39.RightKnee = v_u_2(-0.7, 0, 0)
		v39.LeftHip = v_u_2(0.4, 0, -0.1)
		v39.LeftKnee = v_u_2(-0.65, 0, 0)
		return v39
	end,
	["carry"] = function(_) -- name: carry
		-- upvalues: (copy) v_u_2
		return {
			["Waist"] = v_u_2(-0.08, 0, 0),
			["RightShoulder"] = v_u_2(0.55, 0, 0) * v_u_2(0, 0.5, 0),
			["RightElbow"] = v_u_2(1.3, 0, 0),
			["LeftShoulder"] = v_u_2(0.55, 0, 0) * v_u_2(0, -0.5, 0),
			["LeftElbow"] = v_u_2(1.3, 0, 0)
		}
	end
}
v_u_1.PARTIAL = {
	["carry"] = true
}
local v_u_41 = setmetatable({}, {
	["__mode"] = "k"
})
local function v_u_46(p42) -- name: motors
	-- upvalues: (copy) v_u_41
	local v43 = v_u_41[p42]
	if v43 then
		return v43
	end
	local v44 = {}
	for _, v45 in p42:GetDescendants() do
		if not (v45:IsA("Motor6D") or v45:IsA("AnimationConstraint")) then
			continue
		end
		v44[v45.Name] = v45
	end
	v_u_41[p42] = v44
	return v44
end
function v_u_1.apply(p47, p48, p49) -- name: apply
	-- upvalues: (copy) v_u_1, (copy) v_u_46
	local v50 = v_u_1.list[p48]
	if not v50 then
		return false
	end
	local v51 = v_u_46(p47)
	local v52 = v50(p49)
	local v53 = v_u_1.PARTIAL[p48]
	for v54, v55 in v51 do
		local v56 = v52[v54]
		if not v56 and v53 then
			continue
		end
		v55.Transform = v56 or CFrame.identity
	end
	return true
end
function v_u_1.applyBlend(p57, p58, p59, p60, p61) -- name: applyBlend
	-- upvalues: (copy) v_u_1, (copy) v_u_46
	local v62 = v_u_1.list[p58]
	local v63 = v_u_1.list[p59]
	if not (v62 and v63) then
		return v_u_1.apply(p57, p59 or p58, p61)
	end
	local v64 = v62(p61)
	local v65 = v63(p61)
	for v66, v67 in v_u_46(p57) do
		v67.Transform = (v64[v66] or CFrame.identity):Lerp(v65[v66] or CFrame.identity, p60)
	end
	return true
end
function v_u_1.clear(p68) -- name: clear
	-- upvalues: (copy) v_u_46
	for _, v69 in v_u_46(p68) do
		v69.Transform = CFrame.identity
	end
end
return v_u_1