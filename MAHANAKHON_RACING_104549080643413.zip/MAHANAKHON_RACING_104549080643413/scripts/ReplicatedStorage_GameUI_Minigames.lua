-- Path: ReplicatedStorage/GameUI/Minigames
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game:GetService("UserInputService")
local v_u_5 = require(script.Parent:WaitForChild("Theme"))
require(script.Parent:WaitForChild("Icons"))
local v6 = {}
local v_u_7 = Color3.fromRGB(70, 210, 110)
local v_u_8 = Color3.fromRGB(230, 70, 60)
local v_u_9 = Color3.new(1, 1, 1)
local v_u_10 = v_u_5.TEXT_DIM
Color3.fromRGB(24, 25, 28)
local v_u_11 = nil
local function v_u_14(p12, p13) -- name: new
	-- upvalues: (copy) v_u_5
	return v_u_5.new(p12, p13)
end
local function v_u_28(p15, p16, p17, p18, p19, p20, p21, p22, p23, p24) -- name: text
	-- upvalues: (copy) v_u_5, (copy) v_u_9
	local v25 = v_u_5.text
	local v26 = {
		["Text"] = nil,
		["TextSize"] = nil,
		["FontFace"] = nil,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["TextWrapped"] = true,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Text"] = p16,
		["TextSize"] = p21
	}
	local v27
	if p23 then
		v27 = v_u_5.FONT_BOLD
	else
		v27 = v_u_5.FONT
	end
	v26.FontFace = v27
	v26.TextColor3 = p22 or v_u_9
	v26.TextXAlignment = p24 or Enum.TextXAlignment.Left
	v26.Position = UDim2.fromOffset(p17, p18)
	v26.Size = UDim2.fromOffset(p19, p20)
	v26.Parent = p15
	return v25(v26)
end
local function v_u_35(p29, p30, p31, p32, p33, p34) -- name: bigButton
	-- upvalues: (copy) v_u_5
	return v_u_5.button({
		["text"] = nil,
		["grad"] = "gold",
		["textSize"] = 20,
		["radius"] = 12,
		["position"] = nil,
		["size"] = nil,
		["parent"] = nil,
		["text"] = p30,
		["position"] = UDim2.fromOffset(p31, p32),
		["size"] = UDim2.fromOffset(p33, p34),
		["parent"] = p29
	})
end
local function v_u_39(p36, p37, p38) -- name: shade
	-- upvalues: (copy) v_u_14
	return v_u_14("UIGradient", {
		["Rotation"] = p37 or 90,
		["Color"] = ColorSequence.new(Color3.new(1, 1, 1), Color3.new(p38 or 0.62, p38 or 0.62, p38 or 0.66)),
		["Parent"] = p36
	})
end
local v_u_40 = {
	["bolts"] = { "settings", "blue" },
	["scrub"] = { "zap", "cyan" },
	["paint"] = { "brush", "orange" },
	["gauge"] = { "gauge", "blue" },
	["pour"] = { "zap", "blue" },
	["mash"] = { "home", "orange" },
	["stack"] = { "home", "orange" },
	["swirl"] = { "star", "red" },
	["scoop"] = { "star", "red" },
	["juice"] = { "star", "red" }
}
local function v_u_92(p41, p42, p_u_43, p44) -- name: window
	-- upvalues: (copy) v_u_1, (copy) v_u_5, (copy) v_u_40, (copy) v_u_28, (copy) v_u_9, (copy) v_u_10, (copy) v_u_3, (ref) v_u_11
	local v45 = v_u_1.LocalPlayer
	local v_u_46 = v_u_5.screen("Minigame", 30, v45:WaitForChild("PlayerGui"))
	v_u_46.IgnoreGuiInset = true
	local v47 = {
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.4,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = Color3.fromRGB(4, 6, 12),
		["Size"] = UDim2.fromScale(1, 1),
		["Parent"] = v_u_46
	}
	v_u_5.new("Frame", v47)
	local v48 = v_u_5.panel({
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.5),
		["Size"] = UDim2.fromOffset(460, 380),
		["Parent"] = v_u_46
	})
	v48.UICorner.CornerRadius = UDim.new(0, 18)
	local v49 = v_u_5.autoScale(v48)
	if v_u_5.isTouch() then
		local v50 = v49.Scale
		v49.Scale = math.max(v50, 0.95)
		v48.Position = UDim2.new(0.5, 0, 0.5, 20)
	end
	local v51 = v_u_40[p44] or { "star", "gold" }
	v_u_5.badge(v48, v51[1], v51[2], 44).Position = UDim2.fromOffset(16, 14)
	v_u_28(v48, p41, 70, 12, 330, 26, 20, v_u_9, true).FontFace = v_u_5.FONT_DISPLAY
	local v52 = v_u_28(v48, p42, 70, 38, 330, 30, 13, v_u_10)
	v52.TextYAlignment = Enum.TextYAlignment.Top
	local v53 = v_u_5.closeButton(v48)
	v53.Position = UDim2.new(1, -12, 0, 14)
	local v54 = {
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["ClipsDescendants"] = true,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = Color3.new(1, 1, 1),
		["Position"] = UDim2.fromOffset(16, 78),
		["Size"] = UDim2.fromOffset(428, 230),
		["Parent"] = v48
	}
	local v_u_55 = v_u_5.new("Frame", v54)
	v_u_5.corner(v_u_55, 14)
	local v56 = {
		["Rotation"] = 90,
		["Color"] = nil,
		["Parent"] = nil,
		["Color"] = ColorSequence.new(Color3.fromRGB(34, 37, 48), Color3.fromRGB(16, 17, 23)),
		["Parent"] = v_u_55
	}
	v_u_5.new("UIGradient", v56)
	v_u_5.border(v_u_55, Color3.new(1, 1, 1), 0.9, 1)
	v_u_55:GetPropertyChangedSignal("BackgroundColor3"):Connect(function()
		-- upvalues: (copy) v_u_55
		local v57 = v_u_55:FindFirstChildOfClass("UIGradient")
		if v57 then
			v57:Destroy()
		end
	end)
	local v58 = {
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = Color3.fromRGB(20, 22, 30),
		["Position"] = UDim2.fromOffset(16, 328),
		["Size"] = UDim2.new(1, -86, 0, 14),
		["Parent"] = v48
	}
	local v59 = v_u_5.new("Frame", v58)
	v_u_5.corner(v59, 7)
	v_u_5.border(v59, Color3.new(1, 1, 1), 0.88, 1)
	local v60 = {
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = Color3.new(1, 1, 1),
		["Size"] = UDim2.fromScale(0, 1),
		["Parent"] = v59
	}
	local v_u_61 = v_u_5.new("Frame", v60)
	v_u_5.corner(v_u_61, 7)
	v_u_5.gradient(v_u_61, "green")
	v_u_5.gloss(v_u_61, 7, 0.3)
	local v_u_62 = v_u_28(v48, "0%", 394, 324, 50, 22, 15, v_u_5.GREEN_TEXT, true, Enum.TextXAlignment.Right)
	v_u_61:GetPropertyChangedSignal("Size"):Connect(function()
		-- upvalues: (copy) v_u_62, (copy) v_u_61
		local v63 = v_u_62
		local v64 = v_u_61.Size.X.Scale * 100 + 0.5
		v63.Text = ("%d%%"):format((math.floor(v64)))
	end)
	local v_u_65 = v_u_28(v48, "", 16, 348, 428, 22, 15, v_u_9, true)
	v_u_65.FontFace = v_u_5.FONT_HEAVY
	local v66 = v49.Scale
	v49.Scale = v66 * 0.9
	v_u_3:Create(v49, v_u_5.POP, {
		["Scale"] = v66
	}):Play()
	local v_u_67 = {}
	local v_u_68 = false
	local function v90(p_u_69) -- name: finish
		-- upvalues: (ref) v_u_68, (copy) v_u_67, (copy) v_u_65, (ref) v_u_5, (copy) v_u_61, (copy) v_u_55, (ref) v_u_28, (ref) v_u_9, (ref) v_u_3, (copy) v_u_46, (copy) p_u_43, (ref) v_u_11
		if not v_u_68 then
			v_u_68 = true
			for _, v70 in v_u_67 do
				v70:Disconnect()
			end
			if p_u_69 then
				local v71 = p_u_69 >= 0.9 and 3 or (p_u_69 >= 0.6 and 2 or 1)
				v_u_65.Text = v71 == 3 and "Excellent work!" or (v71 == 2 and "Good job!" or "Done")
				v_u_65.TextColor3 = v_u_5.YELLOW
				v_u_61.Size = UDim2.fromScale(1, 1)
				local v72 = {
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = 0.25,
					["BorderSizePixel"] = 0,
					["Size"] = nil,
					["ZIndex"] = 20,
					["Parent"] = nil,
					["BackgroundColor3"] = Color3.fromRGB(6, 8, 14),
					["Size"] = UDim2.fromScale(1, 1),
					["Parent"] = v_u_55
				}
				local v73 = v_u_5.new("Frame", v72)
				v_u_5.corner(v73, 14)
				local v74 = v_u_28(v73, "DONE!", 0, 34, 428, 44, 40, v_u_9, true, Enum.TextXAlignment.Center)
				v74.FontFace = v_u_5.FONT_DISPLAY
				v74.ZIndex = 21
				local v75 = {
					["Rotation"] = 90,
					["Color"] = nil,
					["Parent"] = nil,
					["Color"] = ColorSequence.new(Color3.fromRGB(255, 240, 168), Color3.fromRGB(255, 176, 30)),
					["Parent"] = v74
				}
				v_u_5.new("UIGradient", v75)
				for v_u_76 = 1, 3 do
					local v77 = v_u_76 <= v71
					local v78 = v_u_28
					local v79 = "\226\152\133"
					local v80 = (v_u_76 - 1) * 60 + 124
					local v81 = 96
					local v82 = 60
					local v83 = 60
					local v84 = 56
					local v85
					if v77 then
						v85 = v_u_5.YELLOW
					else
						v85 = Color3.fromRGB(70, 72, 84)
					end
					local v86 = v78(v73, v79, v80, v81, v82, v83, v84, v85, true, Enum.TextXAlignment.Center)
					v86.ZIndex = 21
					local v87 = {
						["Color"] = nil,
						["Thickness"] = 2,
						["Parent"] = nil
					}
					local v88
					if v77 then
						v88 = Color3.fromRGB(120, 70, 0)
					else
						v88 = Color3.fromRGB(30, 30, 36)
					end
					v87.Color = v88
					v87.Parent = v86
					v_u_5.new("UIStroke", v87)
					local v_u_89 = v_u_5.new("UIScale", {
						["Scale"] = 0,
						["Parent"] = nil,
						["Parent"] = v86
					})
					task.delay(v_u_76 * 0.14 + 0.12, function()
						-- upvalues: (ref) v_u_3, (copy) v_u_89, (copy) v_u_76
						v_u_3:Create(v_u_89, TweenInfo.new(0.32, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
							["Scale"] = v_u_76 == 2 and 1.2 or 1
						}):Play()
					end)
				end
				task.delay(1.6, function()
					-- upvalues: (ref) v_u_46, (ref) p_u_43, (copy) p_u_69
					v_u_46:Destroy()
					p_u_43(p_u_69)
				end)
			else
				v_u_46:Destroy()
				p_u_43(nil)
			end
			v_u_11 = nil
		end
	end
	v53.Activated:Connect(function()
		-- upvalues: (ref) v_u_68, (copy) v_u_67, (copy) v_u_46, (copy) p_u_43, (ref) v_u_11
		if not v_u_68 then
			v_u_68 = true
			for _, v91 in v_u_67 do
				v91:Disconnect()
			end
			v_u_46:Destroy()
			p_u_43(nil)
			v_u_11 = nil
		end
	end)
	v_u_11 = {
		["finish"] = v90
	}
	return {
		["gui"] = v_u_46,
		["panel"] = v48,
		["area"] = v_u_55,
		["fill"] = v_u_61,
		["status"] = v_u_65,
		["hint"] = v52,
		["conns"] = v_u_67,
		["finish"] = v90
	}
end
local v_u_319 = {
	["bolts"] = function(p_u_93) -- name: bolts
		-- upvalues: (copy) v_u_5, (copy) v_u_39, (copy) v_u_7, (copy) v_u_8, (copy) v_u_2, (copy) v_u_9
		local v94 = p_u_93.area
		local v95 = {
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["BackgroundColor3"] = Color3.fromRGB(30, 30, 32),
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromOffset(214, 115),
			["Size"] = UDim2.fromOffset(210, 210),
			["Parent"] = v94
		}
		local v96 = v_u_5.new("Frame", v95)
		v_u_5.corner(v96, 105)
		local v97 = {
			["Color"] = nil,
			["Thickness"] = 4,
			["Parent"] = nil,
			["Color"] = Color3.fromRGB(12, 12, 14),
			["Parent"] = v96
		}
		v_u_5.new("UIStroke", v97)
		local v98 = {
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["BackgroundColor3"] = Color3.fromRGB(190, 194, 202),
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5, 0.5),
			["Size"] = UDim2.fromOffset(170, 170),
			["Parent"] = v96
		}
		local v99 = v_u_5.new("Frame", v98)
		v_u_5.corner(v99, 85)
		v_u_39(v99, 45, 0.5)
		local v100 = {
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["BackgroundColor3"] = Color3.fromRGB(120, 124, 132),
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5, 0.5),
			["Size"] = UDim2.fromOffset(46, 46),
			["Parent"] = v99
		}
		local v101 = v_u_5.new("Frame", v100)
		v_u_5.corner(v101, 23)
		v_u_39(v101, 225, 0.55)
		local v_u_102 = {}
		local v_u_103 = {
			1,
			3,
			5,
			2,
			4
		}
		for v104 = 1, 5 do
			local v105 = (v104 - 1) * 72 + -90
			local v106 = math.rad(v105)
			local v107 = {
				["Text"] = "",
				["AutoButtonColor"] = false,
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["BackgroundColor3"] = Color3.fromRGB(70, 72, 78),
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.fromOffset(math.cos(v106) * 70 * 0.62 + 214, math.sin(v106) * 70 * 0.62 + 115),
				["Size"] = UDim2.fromOffset(40, 40),
				["Parent"] = v94
			}
			local v108 = v_u_5.new("TextButton", v107)
			v_u_5.corner(v108, 20)
			v_u_39(v108, 45, 0.55)
			local v109 = {
				["ApplyStrokeMode"] = nil,
				["Color"] = nil,
				["Thickness"] = 4,
				["Transparency"] = 1,
				["Parent"] = nil,
				["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
				["Color"] = v_u_5.YELLOW,
				["Parent"] = v108
			}
			local v110 = v_u_5.new("UIStroke", v109)
			local v111 = v_u_5.text({
				["Text"] = "",
				["FontFace"] = nil,
				["TextSize"] = 18,
				["TextColor3"] = nil,
				["Size"] = nil,
				["ZIndex"] = 3,
				["Parent"] = nil,
				["FontFace"] = v_u_5.FONT_BOLD,
				["TextColor3"] = v_u_5.YELLOW,
				["Size"] = UDim2.fromScale(1, 1),
				["Parent"] = v108
			})
			local v112 = {
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["BackgroundColor3"] = v_u_7,
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.fromScale(0.5, 0.5),
				["Size"] = UDim2.fromScale(0, 0),
				["Parent"] = v108
			}
			local v113 = v_u_5.new("Frame", v112)
			v_u_5.corner(v113, 20)
			v_u_102[v104] = {
				["button"] = nil,
				["ring"] = nil,
				["inner"] = nil,
				["number"] = nil,
				["done"] = false,
				["button"] = v108,
				["ring"] = v110,
				["inner"] = v113,
				["number"] = v111
			}
		end
		local v_u_114 = 1
		local function v_u_123() -- name: light
			-- upvalues: (copy) v_u_102, (copy) v_u_103, (ref) v_u_114, (copy) p_u_93
			for v115, v116 in v_u_102 do
				local v117 = v_u_103[v_u_114] == v115
				v116.ring.Transparency = v117 and 0 or 1
				local v118 = v116.button
				local v119
				if v117 then
					v119 = Color3.fromRGB(96, 90, 60)
				elseif v116.done then
					v119 = Color3.fromRGB(50, 90, 60)
				else
					v119 = Color3.fromRGB(70, 72, 78)
				end
				v118.BackgroundColor3 = v119
				local v120 = v116.number
				local v121
				if v117 then
					local v122 = v_u_114
					v121 = tostring(v122)
				else
					v121 = ""
				end
				v120.Text = v121
			end
			p_u_93.fill.Size = UDim2.fromScale((v_u_114 - 1) / 5, 1)
			p_u_93.status.Text = ("Bolts %d / 5"):format(v_u_114 - 1)
		end
		v_u_123()
		local v_u_124 = v_u_114
		local v_u_125 = nil
		local v_u_126 = 0
		local v_u_127 = 0
		for v_u_128, v_u_129 in v_u_102 do
			v_u_129.button.InputBegan:Connect(function(p130)
				-- upvalues: (copy) v_u_129, (copy) v_u_103, (ref) v_u_124, (copy) v_u_128, (ref) v_u_125, (ref) v_u_126, (ref) v_u_127, (copy) p_u_93, (ref) v_u_8
				if (p130.UserInputType == Enum.UserInputType.MouseButton1 and true or p130.UserInputType == Enum.UserInputType.Touch) and not v_u_129.done then
					if v_u_103[v_u_124] == v_u_128 then
						v_u_125 = v_u_128
						v_u_126 = 0
					else
						v_u_127 = v_u_127 + 1
						p_u_93.status.Text = "Wrong one! Follow the star (the one with the yellow ring)"
						p_u_93.status.TextColor3 = v_u_8
					end
				else
					return
				end
			end)
			v_u_129.button.InputEnded:Connect(function(p131)
				-- upvalues: (ref) v_u_125, (copy) v_u_128
				if (p131.UserInputType == Enum.UserInputType.MouseButton1 and true or p131.UserInputType == Enum.UserInputType.Touch) and v_u_125 == v_u_128 then
					v_u_125 = nil
				end
			end)
		end
		local v132 = p_u_93.conns
		local v133 = v_u_2.RenderStepped
		local function v140(p134)
			-- upvalues: (ref) v_u_125, (ref) v_u_126, (copy) v_u_102, (ref) v_u_124, (copy) p_u_93, (ref) v_u_9, (ref) v_u_127, (copy) v_u_123
			if v_u_125 then
				v_u_126 = v_u_126 + p134
				local v135 = v_u_102[v_u_125]
				local v136 = v_u_126 / 0.3
				local v137 = math.clamp(v136, 0, 1)
				v135.inner.Size = UDim2.fromScale(v137, v137)
				if v137 >= 1 then
					v135.done = true
					v_u_125 = nil
					v_u_124 = v_u_124 + 1
					p_u_93.status.TextColor3 = v_u_9
					if v_u_124 > 5 then
						local v138 = p_u_93.finish
						local v139 = 1 - v_u_127 * 0.15
						v138((math.clamp(v139, 0, 1)))
						return
					end
					v_u_123()
				end
			end
		end
		table.insert(v132, v133:Connect(v140))
	end,
	["scrub"] = function(p_u_141, p142) -- name: scrub
		-- upvalues: (copy) v_u_5, (copy) v_u_39, (copy) v_u_4
		local v143 = p_u_141.area
		local v_u_144
		if p142 then
			v_u_144 = p142.paint
		else
			v_u_144 = p142
		end
		local v_u_145
		if v_u_144 then
			v_u_145 = Color3.fromRGB(190, 186, 176)
		else
			v_u_145 = Color3.fromRGB(120, 86, 50)
		end
		local v_u_146
		if v_u_144 then
			v_u_146 = p142.color or Color3.fromRGB(120, 190, 200)
		else
			v_u_146 = Color3.fromRGB(235, 240, 245)
		end
		if v_u_144 then
			v143.BackgroundColor3 = v_u_145
		else
			local v147 = {
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["BackgroundColor3"] = Color3.fromRGB(200, 40, 50),
				["Position"] = UDim2.fromOffset(30, 60),
				["Size"] = UDim2.fromOffset(368, 110),
				["Parent"] = v143
			}
			local v148 = v_u_5.new("Frame", v147)
			v_u_5.corner(v148, 30)
			v_u_39(v148, 90, 0.55)
			local v149 = {
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["BackgroundColor3"] = Color3.fromRGB(120, 170, 210),
				["Position"] = UDim2.fromOffset(90, 40),
				["Size"] = UDim2.fromOffset(200, 40),
				["Parent"] = v143
			}
			local v150 = v_u_5.new("Frame", v149)
			v_u_5.corner(v150, 14)
			v_u_39(v150, 90, 0.6)
			for _, v151 in { 80, 300 } do
				local v152 = {
					["BackgroundColor3"] = nil,
					["BorderSizePixel"] = 0,
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["Parent"] = nil,
					["BackgroundColor3"] = Color3.fromRGB(20, 20, 22),
					["AnchorPoint"] = Vector2.new(0.5, 0.5),
					["Position"] = UDim2.fromOffset(v151, 175),
					["Size"] = UDim2.fromOffset(60, 60),
					["Parent"] = v143
				}
				local v153 = v_u_5.new("Frame", v152)
				v_u_5.corner(v153, 30)
			end
		end
		local v154 = Random.new()
		local v_u_155 = {}
		for v156 = 0, 7 do
			for v157 = 0, 3 do
				local v158 = {
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = nil,
					["BorderSizePixel"] = 0,
					["Position"] = nil,
					["Size"] = nil,
					["Parent"] = nil,
					["BackgroundColor3"] = v_u_145,
					["BackgroundTransparency"] = v_u_144 and 0 or 0.05,
					["Position"] = UDim2.fromOffset(v156 * 53.5 + v154:NextNumber(-4, 4), v157 * 57.5 + v154:NextNumber(-4, 4)),
					["Size"] = UDim2.fromOffset(63.5, 67.5),
					["Parent"] = v143
				}
				local v159 = v_u_5.new("Frame", v158)
				v_u_5.corner(v159, 18)
				table.insert(v_u_155, {
					["frame"] = nil,
					["p"] = 0,
					["frame"] = v159
				})
			end
		end
		local v_u_160 = false
		local v_u_161 = os.clock()
		local function v_u_174(p162) -- name: rub
			-- upvalues: (copy) v_u_155, (copy) v_u_144, (copy) v_u_145, (copy) v_u_146, (copy) p_u_141, (copy) v_u_161
			local v163 = 0
			for _, v164 in v_u_155 do
				local v165 = v164.frame
				local v166 = v165.AbsolutePosition + v165.AbsoluteSize / 2
				if v164.p < 1 and (Vector2.new(p162.X, p162.Y) - v166).Magnitude < v165.AbsoluteSize.X * 0.75 then
					local v167 = v164.p + 0.2
					v164.p = math.min(1, v167)
					if v_u_144 then
						v165.BackgroundColor3 = v_u_145:Lerp(v_u_146, v164.p)
					else
						v165.BackgroundTransparency = 0.05 + v164.p * 0.95
					end
				end
				if v164.p < 1 then
					continue
				end
				v163 = v163 + 1
			end
			local v168 = v163 / #v_u_155
			p_u_141.fill.Size = UDim2.fromScale(v168, 1)
			local v169 = p_u_141.status
			local v170 = v168 * 100
			v169.Text = ("%d%%"):format((math.floor(v170)))
			if v168 >= 0.92 then
				local v171 = os.clock() - v_u_161
				local v172 = p_u_141.finish
				local v173 = 1 - (v171 - 8) / 24
				v172((math.clamp(v173, 0.5, 1)))
			end
		end
		v143.InputBegan:Connect(function(p175)
			-- upvalues: (ref) v_u_160, (copy) v_u_174
			if p175.UserInputType == Enum.UserInputType.MouseButton1 and true or p175.UserInputType == Enum.UserInputType.Touch then
				v_u_160 = true
				v_u_174(p175.Position)
			end
		end)
		local v176 = p_u_141.conns
		local v177 = v_u_4.InputEnded
		local function v179(p178)
			-- upvalues: (ref) v_u_160
			if p178.UserInputType == Enum.UserInputType.MouseButton1 and true or p178.UserInputType == Enum.UserInputType.Touch then
				v_u_160 = false
			end
		end
		table.insert(v176, v177:Connect(v179))
		local v180 = p_u_141.conns
		local v181 = v_u_4.InputChanged
		local function v183(p182)
			-- upvalues: (ref) v_u_160, (copy) v_u_174
			if v_u_160 and (p182.UserInputType == Enum.UserInputType.MouseMovement or p182.UserInputType == Enum.UserInputType.Touch) then
				v_u_174(p182.Position)
			end
		end
		table.insert(v180, v181:Connect(v183))
	end,
	["gauge"] = function(p_u_184) -- name: gauge
		-- upvalues: (copy) v_u_5, (copy) v_u_39, (copy) v_u_9, (copy) v_u_7, (copy) v_u_28, (copy) v_u_10, (copy) v_u_35, (copy) v_u_2, (copy) v_u_8, (copy) v_u_4
		local v185 = p_u_184.area
		local v186 = {
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["BackgroundColor3"] = Color3.fromRGB(60, 62, 72),
			["Position"] = UDim2.fromOffset(20, 70),
			["Size"] = UDim2.fromOffset(388, 40),
			["Parent"] = v185
		}
		local v187 = v_u_5.new("Frame", v186)
		v_u_5.corner(v187, 10)
		v_u_39(v187, 90, 0.5)
		for v188 = 1, 9 do
			local v189 = {
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.75,
				["BorderSizePixel"] = 0,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["BackgroundColor3"] = v_u_9,
				["Position"] = UDim2.new(v188 / 10, -1, 1, -10),
				["Size"] = UDim2.fromOffset(2, 8),
				["Parent"] = v187
			}
			v_u_5.new("Frame", v189)
		end
		local v190 = {
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["Parent"] = nil,
			["BackgroundColor3"] = v_u_7,
			["Size"] = UDim2.fromScale(0.16, 1),
			["Parent"] = v187
		}
		local v_u_191 = v_u_5.new("Frame", v190)
		v_u_5.corner(v_u_191, 8)
		v_u_39(v_u_191, 90, 0.6)
		local v192 = {
			["Color"] = nil,
			["Transparency"] = 0.4,
			["Thickness"] = 2,
			["Parent"] = nil,
			["Color"] = Color3.fromRGB(150, 255, 180),
			["Parent"] = v_u_191
		}
		v_u_5.new("UIStroke", v192)
		local v193 = {
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["BackgroundColor3"] = v_u_9,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0, 0.5),
			["Size"] = UDim2.fromOffset(6, 56),
			["Parent"] = v187
		}
		local v_u_194 = v_u_5.new("Frame", v193)
		v_u_5.corner(v_u_194, 3)
		v_u_28(v185, "Tire pressure (PSI)", 20, 40, 300, 22, 15, v_u_10)
		local v195 = v_u_35(v185, "Stop!", 134, 140, 160, 56)
		local v_u_196 = 0
		local v_u_197 = 1
		local v_u_198 = 0.9
		local v_u_199 = 0
		local v_u_200 = 0
		local v_u_201 = 0
		v_u_191.Position = UDim2.fromScale(0.2 + math.random() * 0.6, 0)
		v_u_198 = v_u_199 * 0.15 + 0.8
		p_u_184.status.Text = "Tires 0 / 4"
		local v202 = p_u_184.conns
		local v203 = v_u_2.RenderStepped
		local function v205(p204)
			-- upvalues: (ref) v_u_201, (ref) v_u_196, (ref) v_u_197, (ref) v_u_198, (copy) v_u_194
			if os.clock() >= v_u_201 then
				v_u_196 = v_u_196 + v_u_197 * v_u_198 * p204
				if v_u_196 > 1 then
					v_u_196 = 1
					v_u_197 = -1
				elseif v_u_196 < 0 then
					v_u_196 = 0
					v_u_197 = 1
				end
				v_u_194.Position = UDim2.fromScale(v_u_196, 0.5)
			end
		end
		table.insert(v202, v203:Connect(v205))
		local function v_u_209() -- name: press
			-- upvalues: (ref) v_u_201, (ref) v_u_200, (copy) v_u_191, (ref) v_u_196, (ref) v_u_199, (copy) p_u_184, (ref) v_u_7, (ref) v_u_198, (ref) v_u_8
			if os.clock() < v_u_201 then
				return
			else
				v_u_201 = os.clock() + 0.4
				v_u_200 = v_u_200 + 1
				local v206 = v_u_191.Position.X.Scale
				if v_u_196 >= v206 - 0.010309278350515464 and v_u_196 <= v206 + v_u_191.Size.X.Scale + 0.010309278350515464 then
					v_u_199 = v_u_199 + 1
					p_u_184.status.Text = ("Tires %d / 4  \226\156\147"):format(v_u_199)
					p_u_184.status.TextColor3 = v_u_7
					p_u_184.fill.Size = UDim2.fromScale(v_u_199 / 4, 1)
					if v_u_199 >= 4 then
						local v207 = p_u_184.finish
						local v208 = 4 / v_u_200
						v207((math.clamp(v208, 0, 1)))
					else
						v_u_191.Position = UDim2.fromScale(0.2 + math.random() * 0.6, 0)
						v_u_198 = v_u_199 * 0.15 + 0.8
					end
				else
					p_u_184.status.Text = ("Tires %d / 4  Missed! Try again"):format(v_u_199)
					p_u_184.status.TextColor3 = v_u_8
					return
				end
			end
		end
		v195.InputBegan:Connect(function(p210)
			-- upvalues: (copy) v_u_209
			if p210.UserInputType == Enum.UserInputType.MouseButton1 and true or p210.UserInputType == Enum.UserInputType.Touch then
				v_u_209()
			end
		end)
		local v211 = p_u_184.conns
		local v212 = v_u_4.InputBegan
		table.insert(v211, v212:Connect(function(p213, p214)
			-- upvalues: (copy) v_u_209
			if not p214 and p213.KeyCode == Enum.KeyCode.Space then
				v_u_209()
			end
		end))
	end,
	["pour"] = function(p_u_215) -- name: pour
		-- upvalues: (copy) v_u_5, (copy) v_u_39, (copy) v_u_9, (copy) v_u_28, (copy) v_u_35, (copy) v_u_4, (copy) v_u_2, (copy) v_u_8, (copy) v_u_7
		local v216 = p_u_215.area
		local v217 = {
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["BackgroundColor3"] = Color3.fromRGB(60, 64, 76),
			["Position"] = UDim2.fromOffset(40, 20),
			["Size"] = UDim2.fromOffset(110, 190),
			["Parent"] = v216
		}
		local v218 = v_u_5.new("Frame", v217)
		v_u_5.corner(v218, 12)
		local v219 = {
			["Color"] = nil,
			["Transparency"] = 0.5,
			["Thickness"] = 2,
			["Parent"] = nil,
			["Color"] = Color3.fromRGB(150, 160, 180),
			["Parent"] = v218
		}
		v_u_5.new("UIStroke", v219)
		local v220 = {
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["BackgroundColor3"] = Color3.fromRGB(214, 160, 30),
			["AnchorPoint"] = Vector2.new(0, 1),
			["Position"] = UDim2.fromScale(0, 1),
			["Size"] = UDim2.fromScale(1, 0),
			["Parent"] = v218
		}
		local v_u_221 = v_u_5.new("Frame", v220)
		v_u_5.corner(v_u_221, 10)
		v_u_39(v_u_221, 0, 0.7)
		local v_u_222 = 0.68 + math.random() * 0.1
		local v_u_223 = v_u_222 + 0.1
		for _, v224 in { v_u_222, v_u_223 } do
			local v225 = {
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["BackgroundColor3"] = v_u_9,
				["Position"] = UDim2.new(0, -8, 1 - v224, -1),
				["Size"] = UDim2.new(1, 16, 0, 3),
				["Parent"] = v218
			}
			v_u_5.new("Frame", v225)
		end
		v_u_28(v216, "MAX", 160, (1 - v_u_223) * 190 + 8, 60, 20, 14, v_u_9, true)
		v_u_28(v216, "MIN", 160, 190 * (1 - v_u_222) + 8, 60, 20, 14, v_u_9, true)
		local v226 = v_u_35(v216, "Hold to pour", 228, 80, 170, 70)
		local v_u_227 = 0
		local v_u_228 = false
		v226.InputBegan:Connect(function(p229)
			-- upvalues: (ref) v_u_228
			if p229.UserInputType == Enum.UserInputType.MouseButton1 and true or p229.UserInputType == Enum.UserInputType.Touch then
				v_u_228 = true
			end
		end)
		v226.InputEnded:Connect(function(p230)
			-- upvalues: (ref) v_u_228, (ref) v_u_227, (copy) v_u_222, (ref) v_u_223, (copy) p_u_215
			if p230.UserInputType == Enum.UserInputType.MouseButton1 and true or p230.UserInputType == Enum.UserInputType.Touch then
				if not v_u_228 then
					return
				end
				v_u_228 = false
				if v_u_222 <= v_u_227 then
					local v231 = v_u_227 <= v_u_223 and 1 or (v_u_227 <= v_u_223 + 0.08 and 0.6 or 0.3)
					p_u_215.finish(v231)
				end
			end
		end)
		local v232 = p_u_215.conns
		local v233 = v_u_4.InputEnded
		local function v236(p234)
			-- upvalues: (ref) v_u_228, (ref) v_u_227, (copy) v_u_222, (ref) v_u_223, (copy) p_u_215
			if p234.UserInputType == Enum.UserInputType.MouseButton1 and true or p234.UserInputType == Enum.UserInputType.Touch then
				if not v_u_228 then
					return
				end
				v_u_228 = false
				if v_u_222 <= v_u_227 then
					local v235 = v_u_227 <= v_u_223 and 1 or (v_u_227 <= v_u_223 + 0.08 and 0.6 or 0.3)
					p_u_215.finish(v235)
				end
			end
		end
		table.insert(v232, v233:Connect(v236))
		local v237 = p_u_215.conns
		local v238 = v_u_2.RenderStepped
		local function v246(p239)
			-- upvalues: (ref) v_u_228, (ref) v_u_227, (copy) v_u_221, (copy) p_u_215, (copy) v_u_222, (ref) v_u_223, (ref) v_u_8, (ref) v_u_7, (ref) v_u_9
			if v_u_228 then
				local v240 = v_u_227 + p239 * 0.28
				v_u_227 = math.min(1, v240)
				v_u_221.Size = UDim2.fromScale(1, v_u_227)
				local v241 = p_u_215.fill
				local v242 = UDim2.fromScale
				local v243 = v_u_227 / v_u_222
				v241.Size = v242(math.min(1, v243), 1)
				p_u_215.status.Text = v_u_223 < v_u_227 and "Overflowing! Let go" or (v_u_222 <= v_u_227 and "Just right! Let go" or "Keep pouring...")
				local v244 = p_u_215.status
				local v245
				if v_u_223 < v_u_227 then
					v245 = v_u_8
				elseif v_u_222 <= v_u_227 then
					v245 = v_u_7
				else
					v245 = v_u_9
				end
				v244.TextColor3 = v245
			end
		end
		table.insert(v237, v238:Connect(v246))
	end,
	["mash"] = function(p_u_247) -- name: mash
		-- upvalues: (copy) v_u_5, (copy) v_u_39, (copy) v_u_35, (copy) v_u_4, (copy) v_u_2
		local v248 = p_u_247.area
		local v249 = {
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["BackgroundColor3"] = Color3.fromRGB(240, 130, 30),
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromOffset(110, 115),
			["Size"] = UDim2.fromOffset(140, 140),
			["Parent"] = v248
		}
		local v250 = v_u_5.new("Frame", v249)
		v_u_5.corner(v250, 70)
		v_u_39(v250, 45, 0.6)
		local v251 = {
			["Color"] = nil,
			["Thickness"] = 4,
			["Parent"] = nil,
			["Color"] = Color3.fromRGB(120, 60, 10),
			["Parent"] = v250
		}
		v_u_5.new("UIStroke", v251)
		local v252 = {
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["BackgroundColor3"] = Color3.fromRGB(80, 80, 86),
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5, 0.5),
			["Size"] = UDim2.fromOffset(110, 14),
			["Parent"] = v250
		}
		local v_u_253 = v_u_5.new("Frame", v252)
		local v254 = v_u_35(v248, "Mix!", 238, 70, 160, 80)
		local v_u_255 = 0
		local v_u_256 = os.clock()
		local function v261() -- name: stir
			-- upvalues: (ref) v_u_255, (copy) v_u_253, (copy) p_u_247, (copy) v_u_256
			local v257 = v_u_255 + 0.07
			v_u_255 = math.min(1, v257)
			local v258 = v_u_253
			v258.Rotation = v258.Rotation + 35
			if v_u_255 >= 1 then
				p_u_247.fill.Size = UDim2.fromScale(1, 1)
				local v259 = p_u_247.finish
				local v260 = 1 - (os.clock() - v_u_256 - 4) / 12
				v259((math.clamp(v260, 0.4, 1)))
			end
		end
		v254.Activated:Connect(v261)
		local v262 = p_u_247.conns
		local v263 = v_u_4.InputBegan
		local function v270(p264, p265)
			-- upvalues: (ref) v_u_255, (copy) v_u_253, (copy) p_u_247, (copy) v_u_256
			if not p265 and p264.KeyCode == Enum.KeyCode.Space then
				local v266 = v_u_255 + 0.07
				v_u_255 = math.min(1, v266)
				local v267 = v_u_253
				v267.Rotation = v267.Rotation + 35
				if v_u_255 >= 1 then
					p_u_247.fill.Size = UDim2.fromScale(1, 1)
					local v268 = p_u_247.finish
					local v269 = 1 - (os.clock() - v_u_256 - 4) / 12
					v268((math.clamp(v269, 0.4, 1)))
				end
			end
		end
		table.insert(v262, v263:Connect(v270))
		local v271 = p_u_247.conns
		local v272 = v_u_2.RenderStepped
		local function v278(p273)
			-- upvalues: (ref) v_u_255, (copy) p_u_247, (copy) v_u_256
			local v274 = v_u_255 - p273 * 0.08
			v_u_255 = math.max(0, v274)
			p_u_247.fill.Size = UDim2.fromScale(v_u_255, 1)
			local v275 = os.clock() - v_u_256
			local v276 = p_u_247.status
			local v277 = v_u_255 * 100 + 0.5
			v276.Text = ("Mixed %d%%  (%.0f s)"):format(math.floor(v277), v275)
		end
		table.insert(v271, v272:Connect(v278))
	end,
	["stack"] = function(p_u_279) -- name: stack
		-- upvalues: (copy) v_u_5, (copy) v_u_39, (copy) v_u_35, (copy) v_u_2, (copy) v_u_8, (copy) v_u_3, (copy) v_u_9, (copy) v_u_4
		local v_u_280 = p_u_279.area
		local function v_u_287(p281, p282, p283) -- name: brick
			-- upvalues: (copy) v_u_280, (ref) v_u_5, (ref) v_u_39
			local v284 = {
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["BackgroundColor3"] = p283 or Color3.fromRGB(176, 84, 52),
				["Position"] = UDim2.fromOffset(p281, p282),
				["Size"] = UDim2.fromOffset(90, 22),
				["Parent"] = v_u_280
			}
			local v285 = v_u_5.new("Frame", v284)
			v_u_5.corner(v285, 3)
			local v286 = {
				["Color"] = nil,
				["Thickness"] = 2,
				["Parent"] = nil,
				["Color"] = Color3.fromRGB(220, 210, 190),
				["Parent"] = v285
			}
			v_u_5.new("UIStroke", v286)
			v_u_39(v285, 90, 0.7)
			return v285
		end
		v_u_287(169, 202)
		local v_u_288 = 0
		local v_u_289 = 0
		local v_u_290 = 169
		local v_u_291 = 0
		local v_u_292 = 0
		local v_u_293 = v_u_287(0, 178)
		local v_u_294 = 0
		local v_u_295 = 1
		local v_u_296 = 160
		local v297 = v_u_35(v_u_280, "Place", 328, 10, 90, 40)
		local v298 = p_u_279.conns
		local v299 = v_u_2.RenderStepped
		local function v301(p300)
			-- upvalues: (ref) v_u_294, (ref) v_u_295, (ref) v_u_296, (ref) v_u_293
			v_u_294 = v_u_294 + v_u_295 * v_u_296 * p300
			if v_u_294 > 338 then
				v_u_294 = 338
				v_u_295 = -1
			elseif v_u_294 < 0 then
				v_u_294 = 0
				v_u_295 = 1
			end
			v_u_293.Position = UDim2.fromOffset(v_u_294, v_u_293.Position.Y.Offset)
		end
		table.insert(v298, v299:Connect(v301))
		local function v_u_313() -- name: place
			-- upvalues: (ref) v_u_292, (ref) v_u_294, (ref) v_u_290, (ref) v_u_291, (ref) v_u_293, (ref) v_u_8, (ref) v_u_3, (copy) p_u_279, (ref) v_u_288, (copy) v_u_287, (ref) v_u_295, (ref) v_u_9, (ref) v_u_289, (ref) v_u_296
			if os.clock() - v_u_292 < 0.25 then
				return
			else
				v_u_292 = os.clock()
				local v302 = v_u_294 - v_u_290
				local v303 = math.abs(v302)
				if v303 > 31.499999999999996 then
					v_u_291 = v_u_291 + 1
					local v_u_304 = v_u_293
					v_u_304.BackgroundColor3 = v_u_8
					v_u_3:Create(v_u_304, TweenInfo.new(0.5), {
						["Position"] = UDim2.fromOffset(v_u_294 + (v_u_290 < v_u_294 and 40 or -40), 250),
						["Rotation"] = v_u_290 < v_u_294 and 40 or -40
					}):Play()
					task.delay(0.55, function()
						-- upvalues: (copy) v_u_304
						v_u_304:Destroy()
					end)
					p_u_279.status.Text = ("It fell! Line it up with the one below  %d / 6"):format(v_u_288)
					p_u_279.status.TextColor3 = v_u_8
					v_u_293 = v_u_287(0, v_u_304.Position.Y.Offset)
					v_u_294 = 0
					v_u_295 = 1
					return
				else
					p_u_279.status.TextColor3 = v_u_9
					local v305 = v_u_289
					local v306 = 1 - v303 / 90
					v_u_289 = v305 + math.clamp(v306, 0, 1)
					v_u_288 = v_u_288 + 1
					v_u_290 = v_u_294
					local v307 = v_u_293
					local v308
					if v303 < 22.5 then
						v308 = Color3.fromRGB(176, 84, 52)
					else
						v308 = Color3.fromRGB(150, 110, 90)
					end
					v307.BackgroundColor3 = v308
					p_u_279.fill.Size = UDim2.fromScale(v_u_288 / 6, 1)
					local v309 = p_u_279.status
					local v310
					if v303 < 22.5 then
						v310 = ("Perfect!  %d / 6"):format(v_u_288)
					else
						v310 = ("A bit off  %d / 6"):format(v_u_288)
					end
					v309.Text = v310
					if v_u_288 >= 6 then
						local v311 = p_u_279.finish
						local v312 = v_u_289 / 6 - v_u_291 * 0.1
						v311((math.clamp(v312, 0.1, 1)))
					else
						v_u_296 = v_u_296 + 25
						v_u_293 = v_u_287(0, v_u_293.Position.Y.Offset - 22 - 2)
						v_u_294 = 0
						v_u_295 = 1
					end
				end
			end
		end
		v297.Activated:Connect(v_u_313)
		v_u_280.InputBegan:Connect(function(p314)
			-- upvalues: (copy) v_u_313
			if p314.UserInputType == Enum.UserInputType.MouseButton1 and true or p314.UserInputType == Enum.UserInputType.Touch then
				v_u_313()
			end
		end)
		local v315 = p_u_279.conns
		local v316 = v_u_4.InputBegan
		table.insert(v315, v316:Connect(function(p317, p318)
			-- upvalues: (copy) v_u_313
			if not p318 and p317.KeyCode == Enum.KeyCode.Space then
				v_u_313()
			end
		end))
	end
}
local v_u_320 = {
	["vanilla"] = Color3.fromRGB(255, 247, 226),
	["strawberry"] = Color3.fromRGB(255, 178, 198)
}
local v_u_321 = Color3.fromRGB(222, 166, 86)
local v_u_322 = Color3.fromRGB(214, 22, 46)
local function v_u_340(p323, p324, p325, p326, p327) -- name: holder
	-- upvalues: (copy) v_u_9, (copy) v_u_5, (copy) v_u_39, (copy) v_u_322, (copy) v_u_28, (copy) v_u_321
	local v328 = {}
	if p324 == "cup" then
		local v329 = {
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = nil,
			["Parent"] = nil,
			["BackgroundColor3"] = v_u_9,
			["AnchorPoint"] = Vector2.new(0.5, 1),
			["Position"] = UDim2.fromOffset(p325, p326),
			["Size"] = UDim2.fromOffset(112, 74),
			["ZIndex"] = p327,
			["Parent"] = p323
		}
		local v330 = v_u_5.new("Frame", v329)
		v_u_5.corner(v330, 14)
		v_u_39(v330, 0, 0.8)
		local v331 = {
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = nil,
			["Parent"] = nil,
			["BackgroundColor3"] = v_u_322,
			["Position"] = UDim2.fromOffset(0, 26),
			["Size"] = UDim2.new(1, 0, 0, 20),
			["ZIndex"] = p327 + 1,
			["Parent"] = v330
		}
		v_u_28(v_u_5.new("Frame", v331), "MHNK", 0, 0, 112, 20, 14, v_u_9, true, Enum.TextXAlignment.Center).ZIndex = p327 + 2
		table.insert(v328, v330)
		return p326 - 74, v328
	else
		if p324 ~= "tall" then
			for v332 = 1, 8 do
				local v333 = 100 - (v332 - 1) * 11
				local v334 = {
					["BackgroundColor3"] = nil,
					["BorderSizePixel"] = 0,
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["ZIndex"] = nil,
					["Parent"] = nil
				}
				local v335
				if v332 % 2 == 0 then
					v335 = v_u_321:Lerp(Color3.new(0.4, 0.25, 0.1), 0.18)
				else
					v335 = v_u_321
				end
				v334.BackgroundColor3 = v335
				v334.AnchorPoint = Vector2.new(0.5, 1)
				v334.Position = UDim2.fromOffset(p325, p326 - (8 - v332) * 11)
				v334.Size = UDim2.fromOffset(v333, 12)
				v334.ZIndex = p327
				v334.Parent = p323
				local v336 = v_u_5.new("Frame", v334)
				v_u_5.corner(v336, 5)
				table.insert(v328, v336)
			end
			return p326 - 88, v328
		end
		local v337 = {
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.35,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = nil,
			["Parent"] = nil,
			["BackgroundColor3"] = Color3.fromRGB(205, 232, 248),
			["AnchorPoint"] = Vector2.new(0.5, 1),
			["Position"] = UDim2.fromOffset(p325, p326),
			["Size"] = UDim2.fromOffset(86, 150),
			["ZIndex"] = p327,
			["Parent"] = p323
		}
		local v338 = v_u_5.new("Frame", v337)
		v_u_5.corner(v338, 12)
		local v339 = {
			["Color"] = nil,
			["Transparency"] = 0.3,
			["Thickness"] = 2,
			["Parent"] = nil,
			["Color"] = v_u_9,
			["Parent"] = v338
		}
		v_u_5.new("UIStroke", v339)
		table.insert(v328, v338)
		return p326 - 150, v328, v338
	end
end
function v_u_319.swirl(p_u_341, p342) -- name: swirl
	-- upvalues: (copy) v_u_320, (copy) v_u_5, (copy) v_u_39, (copy) v_u_28, (copy) v_u_322, (copy) v_u_340, (copy) v_u_9, (copy) v_u_4, (copy) v_u_2, (copy) v_u_7
	local v343 = p342 or {}
	local v344 = p_u_341.area
	local v345 = v_u_320[v343.flavor or "vanilla"] or v_u_320.vanilla
	local v346 = {
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = Color3.fromRGB(206, 210, 218),
		["AnchorPoint"] = Vector2.new(0.5, 0),
		["Position"] = UDim2.fromOffset(214, -10),
		["Size"] = UDim2.fromOffset(170, 40),
		["Parent"] = v344
	}
	local v347 = v_u_5.new("Frame", v346)
	v_u_5.corner(v347, 10)
	v_u_39(v347, 90, 0.72)
	v_u_28(v347, "SOFT SERVE", 0, 12, 170, 18, 13, v_u_322, true, Enum.TextXAlignment.Center)
	local v348 = {
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = Color3.fromRGB(150, 156, 164),
		["AnchorPoint"] = Vector2.new(0.5, 0),
		["Position"] = UDim2.fromOffset(214, 28),
		["Size"] = UDim2.fromOffset(28, 20),
		["Parent"] = v344
	}
	local v349 = v_u_5.new("Frame", v348)
	v_u_5.corner(v349, 6)
	local v350 = v_u_340(v344, v343.cup and "cup" or "cone", 214, 222, 2)
	local v351 = {
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Visible"] = false,
		["ZIndex"] = 1,
		["Parent"] = nil,
		["BackgroundColor3"] = v345,
		["AnchorPoint"] = Vector2.new(0.5, 0),
		["Position"] = UDim2.fromOffset(214, 46)
	}
	local v352 = UDim2.fromOffset
	local v353 = v350 - 46
	v351.Size = v352(12, (math.max(0, v353)))
	v351.Parent = v344
	local v_u_354 = v_u_5.new("Frame", v351)
	v_u_5.corner(v_u_354, 6)
	local v_u_355 = {}
	for v356, v357 in {
		108,
		96,
		82,
		66,
		48,
		26
	} do
		local v358 = {
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Visible"] = false,
			["ZIndex"] = nil,
			["Parent"] = nil,
			["BackgroundColor3"] = v345,
			["AnchorPoint"] = Vector2.new(0.5, 1),
			["Position"] = UDim2.fromOffset(214, v350 + 8 - (v356 - 1) * 14),
			["Size"] = UDim2.fromOffset(v357, 24),
			["ZIndex"] = 3 + v356,
			["Parent"] = v344
		}
		local v359 = v_u_5.new("Frame", v358)
		v_u_5.corner(v359, 12)
		local v360 = {
			["Color"] = nil,
			["Thickness"] = 1.5,
			["Parent"] = nil,
			["Color"] = v345:Lerp(Color3.fromRGB(150, 110, 70), 0.3),
			["Parent"] = v359
		}
		v_u_5.new("UIStroke", v360)
		v_u_39(v359, 90, 0.85)
		v_u_355[v356] = v359
	end
	local v361 = {
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 10,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromOffset(214, v350 - 26),
		["Size"] = UDim2.fromOffset(140, 140),
		["Parent"] = v344
	}
	local v_u_362 = v_u_5.new("Frame", v361)
	v_u_5.corner(v_u_362, 70)
	local v363 = {
		["Color"] = nil,
		["Thickness"] = 2,
		["Transparency"] = 0.35,
		["Parent"] = nil,
		["Color"] = Color3.fromRGB(255, 214, 96),
		["Parent"] = v_u_362
	}
	local v_u_364 = v_u_5.new("UIStroke", v363)
	local v365 = {
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Size"] = nil,
		["ZIndex"] = 11,
		["Parent"] = nil,
		["BackgroundColor3"] = Color3.fromRGB(255, 214, 96),
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Size"] = UDim2.fromOffset(18, 18),
		["Parent"] = v_u_362
	}
	local v_u_366 = v_u_5.new("Frame", v365)
	v_u_5.corner(v_u_366, 9)
	local v367 = {
		["Color"] = nil,
		["Thickness"] = 2,
		["Parent"] = nil,
		["Color"] = v_u_9,
		["Parent"] = v_u_366
	}
	v_u_5.new("UIStroke", v367)
	local v_u_368 = 0
	local v_u_369 = false
	local v_u_370 = false
	local v_u_371 = nil
	local v_u_372 = 0
	local v_u_373 = 0
	local v_u_374 = 0
	v344.InputBegan:Connect(function(p375)
		-- upvalues: (ref) v_u_369, (ref) v_u_371, (copy) v_u_362
		if p375.UserInputType == Enum.UserInputType.MouseButton1 and true or p375.UserInputType == Enum.UserInputType.Touch then
			v_u_369 = true
			local v376 = p375.Position
			local v377 = v_u_362.AbsolutePosition + v_u_362.AbsoluteSize / 2
			local v378 = v376.Y - v377.Y
			local v379 = v376.X - v377.X
			v_u_371 = math.atan2(v378, v379)
		end
	end)
	local v380 = p_u_341.conns
	local v381 = v_u_4.InputChanged
	local function v391(p382)
		-- upvalues: (ref) v_u_369, (copy) v_u_362, (ref) v_u_371, (ref) v_u_372
		if v_u_369 and (p382.UserInputType == Enum.UserInputType.MouseMovement or p382.UserInputType == Enum.UserInputType.Touch) then
			local v383 = p382.Position
			local v384 = v_u_362.AbsolutePosition + v_u_362.AbsoluteSize / 2
			local v385 = v383.Y - v384.Y
			local v386 = v383.X - v384.X
			local v387 = math.atan2(v385, v386)
			if v_u_371 then
				local v388 = v387 - v_u_371
				if v388 > 3.141592653589793 then
					v388 = v388 - 6.283185307179586
				elseif v388 < -3.141592653589793 then
					v388 = v388 + 6.283185307179586
				end
				local v389 = v_u_372
				local v390 = math.abs(v388)
				v_u_372 = v389 + math.min(v390, 0.8)
			end
			v_u_371 = v387
		end
	end
	table.insert(v380, v381:Connect(v391))
	local v392 = p_u_341.conns
	local v393 = v_u_4.InputEnded
	local function v395(p394)
		-- upvalues: (ref) v_u_369, (ref) v_u_371, (ref) v_u_370
		if p394.UserInputType == Enum.UserInputType.MouseButton1 and true or p394.UserInputType == Enum.UserInputType.Touch then
			v_u_369 = false
			v_u_371 = nil
		elseif p394.KeyCode == Enum.KeyCode.Space then
			v_u_370 = false
		end
	end
	table.insert(v392, v393:Connect(v395))
	local v396 = p_u_341.conns
	local v397 = v_u_4.InputBegan
	local function v400(p398, p399)
		-- upvalues: (ref) v_u_370
		if not p399 and p398.KeyCode == Enum.KeyCode.Space then
			v_u_370 = true
		end
	end
	table.insert(v396, v397:Connect(v400))
	local v401 = p_u_341.conns
	local v402 = v_u_2.RenderStepped
	local function v416(p403)
		-- upvalues: (ref) v_u_369, (ref) v_u_370, (ref) v_u_372, (ref) v_u_374, (ref) v_u_373, (ref) v_u_368, (copy) v_u_354, (copy) v_u_355, (ref) v_u_371, (copy) v_u_366, (copy) v_u_364, (copy) p_u_341, (ref) v_u_9, (ref) v_u_7
		local v404 = v_u_369 or v_u_370
		local v405 = v_u_372 / math.max(p403, 0.001)
		v_u_372 = 0
		if v404 then
			v_u_374 = v_u_374 + p403
			if v405 > 1.5 then
				v_u_373 = v_u_373 + p403
			end
			local v406 = v_u_368 + p403 * (math.min(v405, 8) * 0.03 + 0.16)
			v_u_368 = math.min(1, v406)
		end
		v_u_354.Visible = v404
		for v407, v408 in v_u_355 do
			v408.Visible = v_u_368 >= (v407 - 0.6) / #v_u_355
		end
		local v409 = os.clock()
		local v410
		if v404 and v_u_371 then
			v410 = v_u_371
		else
			v410 = v409 * 3
		end
		v_u_366.Position = UDim2.new(0.5, math.cos(v410) * 70, 0.5, math.sin(v410) * 70)
		local v411 = v_u_364
		local v412
		if v404 then
			v412 = 0.15
		else
			local v413 = v409 * 4
			v412 = math.sin(v413) * 0.15 + 0.35
		end
		v411.Transparency = v412
		p_u_341.fill.Size = UDim2.fromScale(v_u_368, 1)
		if v404 then
			if v405 < 1.5 then
				p_u_341.status.Text = "\224\184\167\224\184\153\224\184\148\224\185\137\224\184\167\224\184\162! \224\185\132\224\184\173\224\184\149\224\184\180\224\184\161\224\184\136\224\184\176\224\184\130\224\184\182\224\185\137\224\184\153\224\185\128\224\184\163\224\185\135\224\184\167\224\184\129\224\184\167\224\185\136\224\184\178"
				p_u_341.status.TextColor3 = Color3.fromRGB(255, 214, 96)
			else
				local v414 = p_u_341.status
				local v415 = v_u_368 * 100
				v414.Text = ("\224\185\132\224\184\173\224\184\149\224\184\180\224\184\161\224\184\129\224\184\179\224\184\165\224\184\177\224\184\135\224\184\130\224\184\182\224\185\137\224\184\153\226\128\166 %d%%"):format((math.floor(v415)))
				p_u_341.status.TextColor3 = v_u_7
			end
		else
			p_u_341.status.Text = "\224\184\129\224\184\148\224\184\132\224\185\137\224\184\178\224\184\135\224\185\131\224\184\153\224\184\129\224\184\163\224\184\173\224\184\154 \224\185\129\224\184\165\224\185\137\224\184\167\224\184\165\224\184\178\224\184\129\224\184\167\224\184\153\224\185\128\224\184\155\224\185\135\224\184\153\224\184\167\224\184\135\224\184\129\224\184\165\224\184\161"
			p_u_341.status.TextColor3 = v_u_9
		end
		if v_u_368 >= 1 then
			p_u_341.finish(v_u_373 >= v_u_374 * 0.4 and 1 or 0.7)
		end
	end
	table.insert(v401, v402:Connect(v416))
end
local v_u_417 = {
	["pearl"] = {
		["th"] = "\224\185\132\224\184\130\224\185\136\224\184\161\224\184\184\224\184\129",
		["size"] = 24,
		["color"] = nil,
		["shine"] = true,
		["count"] = 14,
		["color"] = Color3.fromRGB(58, 34, 24)
	},
	["orange"] = {
		["th"] = "\224\184\170\224\185\137\224\184\161",
		["size"] = 40,
		["color"] = nil,
		["inner"] = nil,
		["count"] = 8,
		["color"] = Color3.fromRGB(255, 148, 28),
		["inner"] = Color3.fromRGB(255, 204, 120)
	},
	["strawberry"] = {
		["th"] = "\224\184\170\224\184\149\224\184\163\224\184\173\224\184\167\224\185\140\224\185\128\224\184\154\224\184\173\224\184\163\224\185\140\224\184\163\224\184\181",
		["size"] = 34,
		["color"] = nil,
		["leaf"] = true,
		["count"] = 8,
		["color"] = Color3.fromRGB(222, 32, 52)
	}
}
local function v_u_434(p418, p419, p420, p421, p422) -- name: topping
	-- upvalues: (copy) v_u_417, (copy) v_u_5, (copy) v_u_9
	local v423 = v_u_417[p419] or v_u_417.pearl
	local v424 = {
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = v423.color,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromOffset(p420, p421),
		["Size"] = UDim2.fromOffset(v423.size, v423.size),
		["ZIndex"] = p422,
		["Parent"] = p418
	}
	local v425 = v_u_5.new("Frame", v424)
	v_u_5.corner(v425, v423.size / 2)
	if v423.inner then
		local v426 = {
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = nil,
			["Parent"] = nil,
			["BackgroundColor3"] = v423.inner,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5, 0.5),
			["Size"] = UDim2.fromScale(0.7, 0.7),
			["ZIndex"] = p422 + 1,
			["Parent"] = v425
		}
		local v427 = v_u_5.new("Frame", v426)
		v_u_5.corner(v427, v423.size)
		for v428 = 0, 2 do
			local v429 = {
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.3,
				["BorderSizePixel"] = 0,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Rotation"] = nil,
				["ZIndex"] = nil,
				["Parent"] = nil,
				["BackgroundColor3"] = v_u_9,
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.fromScale(0.5, 0.5),
				["Size"] = UDim2.new(0.9, 0, 0, 2),
				["Rotation"] = v428 * 60,
				["ZIndex"] = p422 + 2,
				["Parent"] = v425
			}
			v_u_5.new("Frame", v429)
		end
	end
	if v423.shine then
		local v430 = {
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.55,
			["BorderSizePixel"] = 0,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = nil,
			["Parent"] = nil,
			["BackgroundColor3"] = v_u_9,
			["Position"] = UDim2.fromScale(0.22, 0.18),
			["Size"] = UDim2.fromScale(0.3, 0.3),
			["ZIndex"] = p422 + 1,
			["Parent"] = v425
		}
		local v431 = v_u_5.new("Frame", v430)
		v_u_5.corner(v431, 6)
	end
	if v423.leaf then
		local v432 = {
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = nil,
			["Parent"] = nil,
			["BackgroundColor3"] = Color3.fromRGB(60, 170, 70),
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5, 0.05),
			["Size"] = UDim2.fromScale(0.6, 0.25),
			["ZIndex"] = p422 + 1,
			["Parent"] = v425
		}
		local v433 = v_u_5.new("Frame", v432)
		v_u_5.corner(v433, 6)
	end
	return v425
end
function v_u_319.scoop(p_u_435, p436) -- name: scoop
	-- upvalues: (copy) v_u_417, (copy) v_u_5, (copy) v_u_39, (copy) v_u_28, (copy) v_u_9, (copy) v_u_340, (copy) v_u_320, (copy) v_u_3, (copy) v_u_7, (copy) v_u_434, (copy) v_u_4
	local v437 = p436 or {}
	local v_u_438 = p_u_435.area
	local v439 = not v_u_417[v437.item] and "pearl" or v437.item
	local v_u_440 = v_u_417[v439]
	local v441 = v437.count
	local v442 = tonumber(v441) or 3
	local v443 = math.floor(v442)
	local v_u_444 = math.max(1, v443)
	local v445 = {
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = Color3.fromRGB(76, 80, 88),
		["Position"] = UDim2.fromOffset(16, 34),
		["Size"] = UDim2.fromOffset(196, 168),
		["Parent"] = v_u_438
	}
	local v_u_446 = v_u_5.new("Frame", v445)
	v_u_5.corner(v_u_446, 14)
	v_u_39(v_u_446, 90, 0.7)
	local v447 = {
		["Color"] = nil,
		["Thickness"] = 2,
		["Transparency"] = 0.3,
		["Parent"] = nil,
		["Color"] = Color3.fromRGB(200, 205, 214),
		["Parent"] = v_u_446
	}
	v_u_5.new("UIStroke", v447)
	v_u_28(v_u_438, "\224\184\150\224\184\178\224\184\148" .. v_u_440.th, 16, 8, 196, 22, 15, v_u_9, true, Enum.TextXAlignment.Center)
	local v448 = v437.tall and "tall" or (v437.cup and "cup" or "cone")
	local v449 = v_u_340(v_u_438, v448, 318, 220, 2)
	if v448 ~= "tall" then
		local v450
		if v439 == "strawberry" then
			v450 = v_u_320.strawberry
		else
			v450 = v_u_320.vanilla
		end
		for v451, v452 in {
			104,
			84,
			58,
			30
		} do
			local v453 = {
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["ZIndex"] = nil,
				["Parent"] = nil,
				["BackgroundColor3"] = v450,
				["AnchorPoint"] = Vector2.new(0.5, 1),
				["Position"] = UDim2.fromOffset(318, v449 + 8 - (v451 - 1) * 14),
				["Size"] = UDim2.fromOffset(v452, 24),
				["ZIndex"] = 3 + v451,
				["Parent"] = v_u_438
			}
			local v454 = v_u_5.new("Frame", v453)
			v_u_5.corner(v454, 12)
			v_u_39(v454, 90, 0.86)
		end
	end
	local v_u_455 = v448 == "tall" and 190 or v449 - 40
	v_u_28(v_u_438, ("\224\185\131\224\184\170\224\185\136\224\185\131\224\184\171\224\185\137\224\184\132\224\184\163\224\184\154 %d"):format(v_u_444), 248, 4, 140, 22, 15, v_u_9, true, Enum.TextXAlignment.Center)
	local v_u_456 = 0
	local v_u_457 = false
	local function v_u_465(p458) -- name: addOne
		-- upvalues: (ref) v_u_457, (ref) v_u_456, (copy) v_u_444, (copy) v_u_438, (copy) v_u_440, (ref) v_u_3, (copy) v_u_455, (copy) p_u_435, (ref) v_u_7, (ref) v_u_9
		if not v_u_457 and (v_u_444 > v_u_456 and (p458 and p458.Parent)) then
			v_u_457 = true
			v_u_456 = v_u_456 + 1
			local v459 = p458.AbsolutePosition + p458.AbsoluteSize / 2 - v_u_438.AbsolutePosition
			local v460 = v_u_438.AbsoluteSize.X / 428
			p458.Parent = v_u_438
			p458.Position = UDim2.fromOffset(v459.X / v460, v459.Y / v460)
			p458.ZIndex = 20
			for _, v461 in p458:GetChildren() do
				if not v461:IsA("GuiObject") then
					continue
				end
				v461.ZIndex = 21
			end
			local v462 = 318 + (v_u_456 - (v_u_444 + 1) / 2) * (v_u_440.size * 0.8)
			v_u_3:Create(p458, TweenInfo.new(0.28, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
				["Position"] = UDim2.fromOffset(v462, v_u_455 - v_u_456 % 2 * 6)
			}):Play()
			p_u_435.fill.Size = UDim2.fromScale(v_u_456 / v_u_444, 1)
			p_u_435.status.Text = ("\224\185\131\224\184\170\224\185\136%s\224\185\129\224\184\165\224\185\137\224\184\167 %d / %d"):format(v_u_440.th, v_u_456, v_u_444)
			local v463 = p_u_435.status
			local v464
			if v_u_444 <= v_u_456 then
				v464 = v_u_7
			else
				v464 = v_u_9
			end
			v463.TextColor3 = v464
			task.delay(0.3, function()
				-- upvalues: (ref) v_u_457, (ref) v_u_456, (ref) v_u_444, (ref) p_u_435
				v_u_457 = false
				if v_u_444 <= v_u_456 then
					p_u_435.finish(1)
				end
			end)
		end
	end
	local v_u_466 = {}
	for v467 = 1, v_u_440.count do
		local v468 = v_u_440.size > 30 and 4 or 5
		local v469 = (v467 - 1) % v468
		local v470 = (v467 - 1) // v468
		local v_u_471 = v_u_434(v_u_446, v439, v469 * (166 / (v468 - 1)) * 0.92 + 30 + math.random(-4, 4), 30 + v470 * (v_u_440.size + 14) + math.random(-3, 3), 3)
		local v472 = {
			["Text"] = "",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["ZIndex"] = 9,
			["Parent"] = nil,
			["Size"] = UDim2.fromScale(1.3, 1.3),
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5, 0.5),
			["Parent"] = v_u_471
		}
		local v_u_473 = v_u_5.new("TextButton", v472)
		v_u_473.Activated:Connect(function()
			-- upvalues: (copy) v_u_473, (copy) v_u_465, (copy) v_u_471
			v_u_473:Destroy()
			v_u_465(v_u_471)
		end)
		table.insert(v_u_466, v_u_471)
	end
	p_u_435.status.Text = ("\224\185\129\224\184\149\224\184\176%s\224\185\131\224\184\153\224\184\150\224\184\178\224\184\148 \224\185\131\224\184\170\224\185\136\224\185\131\224\184\171\224\185\137\224\184\132\224\184\163\224\184\154 %d"):format(v_u_440.th, v_u_444)
	local v474 = p_u_435.conns
	local v475 = v_u_4.InputBegan
	table.insert(v474, v475:Connect(function(p476, p477)
		-- upvalues: (copy) v_u_466, (copy) v_u_446, (copy) v_u_465
		if not p477 and p476.KeyCode == Enum.KeyCode.Space then
			for _, v478 in v_u_466 do
				if v478.Parent ~= v_u_446 then
					continue
				end
				local v479 = v478:FindFirstChildOfClass("TextButton")
				if v479 then
					v479:Destroy()
				end
				v_u_465(v478)
				return
			end
		end
	end))
end
function v_u_319.juice(p_u_480) -- name: juice
	-- upvalues: (copy) v_u_340, (copy) v_u_5, (copy) v_u_39, (copy) v_u_434, (copy) v_u_9, (copy) v_u_28, (copy) v_u_35, (copy) v_u_4, (copy) v_u_2, (copy) v_u_8, (copy) v_u_7
	local v481 = p_u_480.area
	local v482, _, v483 = v_u_340(v481, "tall", 110, 218, 2)
	local v484 = {
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.1,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 3,
		["Parent"] = nil,
		["BackgroundColor3"] = Color3.fromRGB(255, 150, 40),
		["AnchorPoint"] = Vector2.new(0, 1),
		["Position"] = UDim2.fromScale(0, 1),
		["Size"] = UDim2.fromScale(1, 0),
		["Parent"] = v483
	}
	local v_u_485 = v_u_5.new("Frame", v484)
	v_u_5.corner(v_u_485, 10)
	v_u_39(v_u_485, 90, 0.8)
	v_u_434(v483, "orange", 42, 114, 4).Size = UDim2.fromOffset(30, 30)
	v_u_434(v483, "orange", 58, 100, 4).Size = UDim2.fromOffset(30, 30)
	local v_u_486 = 0.66 + math.random() * 0.1
	local v_u_487 = v_u_486 + 0.12
	for _, v488 in { v_u_486, v_u_487 } do
		local v489 = {
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = 6,
			["Parent"] = nil,
			["BackgroundColor3"] = v_u_9,
			["Position"] = UDim2.new(0, -8, 1 - v488, -1),
			["Size"] = UDim2.new(1, 16, 0, 3),
			["Parent"] = v483
		}
		v_u_5.new("Frame", v489)
	end
	v_u_28(v481, "MAX", 162, v482 + 150 * (1 - v_u_487) - 10, 60, 20, 14, v_u_9, true)
	v_u_28(v481, "MIN", 162, v482 + 150 * (1 - v_u_486) - 10, 60, 20, 14, v_u_9, true)
	local v490 = v_u_35(v481, "\224\184\129\224\184\148\224\184\132\224\185\137\224\184\178\224\184\135\224\185\128\224\184\158\224\184\183\224\185\136\224\184\173\224\185\128\224\184\151", 228, 80, 170, 70)
	local v_u_491 = 0
	local v_u_492 = false
	v490.InputBegan:Connect(function(p493)
		-- upvalues: (ref) v_u_492
		if p493.UserInputType == Enum.UserInputType.MouseButton1 and true or p493.UserInputType == Enum.UserInputType.Touch then
			v_u_492 = true
		end
	end)
	v490.InputEnded:Connect(function(p494)
		-- upvalues: (ref) v_u_492, (ref) v_u_491, (copy) v_u_486, (copy) p_u_480, (copy) v_u_487
		if p494.UserInputType == Enum.UserInputType.MouseButton1 and true or p494.UserInputType == Enum.UserInputType.Touch then
			if not v_u_492 then
				return
			end
			v_u_492 = false
			if v_u_486 <= v_u_491 then
				p_u_480.finish(v_u_491 <= v_u_487 and 1 or (v_u_491 <= v_u_487 + 0.08 and 0.6 or 0.3))
			end
		end
	end)
	local v495 = p_u_480.conns
	local v496 = v_u_4.InputEnded
	local function v498(p497)
		-- upvalues: (ref) v_u_492, (ref) v_u_491, (copy) v_u_486, (copy) p_u_480, (copy) v_u_487
		if p497.UserInputType == Enum.UserInputType.MouseButton1 and true or p497.UserInputType == Enum.UserInputType.Touch then
			if not v_u_492 then
				return
			end
			v_u_492 = false
			if v_u_486 <= v_u_491 then
				p_u_480.finish(v_u_491 <= v_u_487 and 1 or (v_u_491 <= v_u_487 + 0.08 and 0.6 or 0.3))
			end
		end
	end
	table.insert(v495, v496:Connect(v498))
	local v499 = p_u_480.conns
	local v500 = v_u_2.RenderStepped
	local function v508(p501)
		-- upvalues: (ref) v_u_492, (ref) v_u_491, (copy) v_u_485, (copy) p_u_480, (copy) v_u_486, (copy) v_u_487, (ref) v_u_8, (ref) v_u_7, (ref) v_u_9
		if v_u_492 then
			local v502 = v_u_491 + p501 * 0.28
			v_u_491 = math.min(1, v502)
			v_u_485.Size = UDim2.fromScale(1, v_u_491)
			local v503 = p_u_480.fill
			local v504 = UDim2.fromScale
			local v505 = v_u_491 / v_u_486
			v503.Size = v504(math.min(1, v505), 1)
			p_u_480.status.Text = v_u_487 < v_u_491 and "\224\184\165\224\185\137\224\184\153\224\185\129\224\184\165\224\185\137\224\184\167! \224\184\155\224\184\165\224\185\136\224\184\173\224\184\162\224\185\128\224\184\165\224\184\162" or (v_u_486 <= v_u_491 and "\224\184\158\224\184\173\224\184\148\224\184\181\224\185\129\224\184\165\224\185\137\224\184\167 \224\184\155\224\184\165\224\185\136\224\184\173\224\184\162\224\185\132\224\184\148\224\185\137" or "\224\184\129\224\184\179\224\184\165\224\184\177\224\184\135\224\185\128\224\184\151\226\128\166")
			local v506 = p_u_480.status
			local v507
			if v_u_487 < v_u_491 then
				v507 = v_u_8
			elseif v_u_486 <= v_u_491 then
				v507 = v_u_7
			else
				v507 = v_u_9
			end
			v506.TextColor3 = v507
		end
	end
	table.insert(v499, v500:Connect(v508))
	p_u_480.status.Text = "\224\184\129\224\184\148\224\184\155\224\184\184\224\185\136\224\184\161\224\184\132\224\185\137\224\184\178\224\184\135\224\185\132\224\184\167\224\185\137\224\185\128\224\184\158\224\184\183\224\185\136\224\184\173\224\185\128\224\184\151\224\184\138\224\184\178\224\184\170\224\185\137\224\184\161"
end
local v_u_509 = {
	["bolts"] = "Hold the bolt with the yellow ring until it turns green, in a star pattern",
	["scrub"] = "Hold and rub back and forth until it\'s all clean",
	["paint"] = "Hold and drag to paint the whole wall",
	["gauge"] = "Press Stop! (or Space) when the needle is in the green, for all 4 tires",
	["pour"] = "Hold to pour the oil, let go between MIN and MAX",
	["mash"] = "Tap Mix! fast (or Space) to fill the bar",
	["stack"] = "Press Place (or tap / Space) to line up 6 bricks; too far off and they fall",
	["swirl"] = "\224\184\129\224\184\148\224\184\132\224\185\137\224\184\178\224\184\135\224\185\131\224\184\153\224\184\129\224\184\163\224\184\173\224\184\154\224\185\129\224\184\165\224\185\137\224\184\167\224\184\165\224\184\178\224\184\129\224\184\167\224\184\153\224\185\128\224\184\155\224\185\135\224\184\153\224\184\167\224\184\135\224\184\129\224\184\165\224\184\161 \224\185\132\224\184\173\224\184\149\224\184\180\224\184\161\224\184\136\224\184\176\224\184\130\224\184\182\224\185\137\224\184\153\224\185\128\224\184\155\224\185\135\224\184\153\224\184\138\224\184\177\224\185\137\224\184\153 \224\185\134 (\224\184\167\224\184\153\224\185\128\224\184\163\224\185\135\224\184\167 = \224\185\128\224\184\149\224\185\135\224\184\161\224\185\132\224\184\167)",
	["scoop"] = "\224\185\129\224\184\149\224\184\176\224\184\151\224\185\135\224\184\173\224\184\155\224\184\155\224\184\180\224\185\137\224\184\135\224\185\131\224\184\153\224\184\150\224\184\178\224\184\148 \224\185\131\224\184\170\224\185\136\224\184\165\224\184\135\224\184\150\224\185\137\224\184\167\224\184\162\224\185\131\224\184\171\224\185\137\224\184\132\224\184\163\224\184\154\224\184\149\224\184\178\224\184\161\224\184\173\224\184\173\224\185\128\224\184\148\224\184\173\224\184\163\224\185\140",
	["juice"] = "\224\184\129\224\184\148\224\184\132\224\185\137\224\184\178\224\184\135\224\185\128\224\184\158\224\184\183\224\185\136\224\184\173\224\185\128\224\184\151\224\184\138\224\184\178\224\184\170\224\185\137\224\184\161 \224\184\155\224\184\165\224\185\136\224\184\173\224\184\162\224\185\128\224\184\161\224\184\183\224\185\136\224\184\173\224\184\163\224\184\176\224\184\148\224\184\177\224\184\154\224\184\173\224\184\162\224\184\185\224\185\136\224\184\163\224\184\176\224\184\171\224\184\167\224\185\136\224\184\178\224\184\135 MIN \224\184\129\224\184\177\224\184\154 MAX"
}
function v6.play(p510, p511, p512, p513) -- name: play
	-- upvalues: (ref) v_u_11, (copy) v_u_92, (copy) v_u_509, (copy) v_u_319
	if v_u_11 then
		v_u_11.finish(nil)
	end
	local v514 = p510 == "scrub" and (p513 and p513.paint) and "paint" or p510
	local v515 = v_u_92(p511, v_u_509[v514] or "", p512, v514)
	v_u_319[p510](v515, p513)
end
function v6.isOpen() -- name: isOpen
	-- upvalues: (ref) v_u_11
	return v_u_11 ~= nil
end
function v6.close() -- name: close
	-- upvalues: (ref) v_u_11
	if v_u_11 then
		v_u_11.finish(nil)
	end
end
return v6