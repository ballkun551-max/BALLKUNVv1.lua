-- Path: Players/ygggggg55551/PlayerScripts/PCX160Client/TuckAnim
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

game:GetService("Players")
local v_u_1 = game:GetService("ReplicatedStorage")
local v_u_2 = {
	["FOLDER"] = "TuckPoses",
	["CODE_POSE"] = "Code",
	["DEFAULT_POSE"] = "v2"
}
local v_u_3 = {
	["Head"] = true,
	["UpperTorso"] = true,
	["LowerTorso"] = true
}
local v_u_4 = {
	["LeftUpperLeg"] = true,
	["LeftLowerLeg"] = true,
	["LeftFoot"] = true,
	["RightUpperLeg"] = true,
	["RightLowerLeg"] = true,
	["RightFoot"] = true
}
local v_u_5 = setmetatable({}, {
	["__mode"] = "k"
})
local v_u_6 = setmetatable({}, {
	["__mode"] = "k"
})
local v_u_7 = setmetatable({}, {
	["__mode"] = "k"
})
function v_u_2.list() -- name: list
	-- upvalues: (copy) v_u_1, (copy) v_u_2
	local v8 = v_u_1:FindFirstChild(v_u_2.FOLDER)
	local v9 = {}
	local v10 = {}
	if v8 then
		for _, v11 in v8:GetChildren() do
			if not v11:IsA("KeyframeSequence") or (v11:GetAttribute("Kind") == "Park" or v10[v11:GetAttribute("Pose") or v11.Name]) then
				continue
			end
			v10[v11:GetAttribute("Pose") or v11.Name] = true
			local v12 = {
				["name"] = v11:GetAttribute("Pose") or v11.Name,
				["label"] = v11:GetAttribute("Label") or (v11:GetAttribute("Pose") or v11.Name),
				["order"] = v11:GetAttribute("Order") or 99
			}
			table.insert(v9, v12)
		end
	end
	table.sort(v9, function(p13, p14)
		if p13.order == p14.order then
			return p13.name < p14.name
		else
			return p13.order < p14.order
		end
	end)
	return v9
end
function v_u_2.exists(p15) -- name: exists
	-- upvalues: (copy) v_u_1, (copy) v_u_2
	local v16 = v_u_1:FindFirstChild(v_u_2.FOLDER)
	if type(p15) ~= "string" or not v16 then
		return false
	end
	for _, v17 in v16:GetChildren() do
		if not v17:IsA("KeyframeSequence") or (v17:GetAttribute("Kind") == "Park" or (v17:GetAttribute("Pose") or v17.Name) ~= p15) then
			continue
		end
		return true
	end
	return false
end
function v_u_2.choice(p18) -- name: choice
	-- upvalues: (copy) v_u_2
	if p18 then
		p18 = p18:GetAttribute("TuckPose")
	end
	if p18 == v_u_2.CODE_POSE then
		return v_u_2.CODE_POSE
	elseif v_u_2.exists(p18) then
		return p18
	elseif v_u_2.exists(v_u_2.DEFAULT_POSE) then
		return v_u_2.DEFAULT_POSE
	else
		local v19 = v_u_2.list()
		if v19[1] then
			return v19[1].name
		else
			return v_u_2.CODE_POSE
		end
	end
end
function v_u_2.selected(p20) -- name: selected
	-- upvalues: (copy) v_u_2
	local v21 = v_u_2.choice(p20)
	if v21 == v_u_2.CODE_POSE then
		return nil
	else
		return v21
	end
end
function v_u_2.forBike(p22, p23) -- name: forBike
	-- upvalues: (copy) v_u_1, (copy) v_u_2
	local v24 = v_u_1:FindFirstChild(v_u_2.FOLDER)
	if not (p22 and (v24 and p23)) then
		return nil
	end
	local v25 = p23:GetAttribute("VehicleId") or p23.Name
	local v26 = nil
	for _, v27 in v24:GetChildren() do
		if not v27:IsA("KeyframeSequence") or (v27:GetAttribute("Kind") == "Park" or (v27:GetAttribute("Pose") or v27.Name) ~= p22) then
			continue
		end
		local v28 = v27:GetAttribute("VehicleIds")
		if type(v28) == "string" and v28 ~= "" then
			for _, v29 in v28:split(",") do
				if v29:match("^%s*(.-)%s*$") ~= v25 then
					continue
				end
				return v27.Name
			end
		else
			v26 = v26 or v27.Name
		end
	end
	return v26
end
function v_u_2.parkFor(p30) -- name: parkFor
	-- upvalues: (copy) v_u_1, (copy) v_u_2
	local v31 = v_u_1:FindFirstChild(v_u_2.FOLDER)
	if not (v31 and p30) then
		return nil
	end
	local v32 = p30:GetAttribute("VehicleId") or p30.Name
	for _, v33 in v31:GetChildren() do
		if not v33:IsA("KeyframeSequence") or v33:GetAttribute("Kind") ~= "Park" then
			continue
		end
		local v34 = v33:GetAttribute("VehicleIds")
		if type(v34) ~= "string" then
			continue
		end
		for _, v35 in v34:split(",") do
			if v35:match("^%s*(.-)%s*$") ~= v32 then
				continue
			end
			return v33.Name
		end
	end
	return nil
end
function v_u_2.anchor(p36) -- name: anchor
	-- upvalues: (copy) v_u_1, (copy) v_u_2
	local v37 = v_u_1:FindFirstChild(v_u_2.FOLDER)
	if v37 then
		if type(p36) == "string" then
			v37 = v37:FindFirstChild(p36)
		else
			v37 = false
		end
	end
	if not (v37 and v37:IsA("KeyframeSequence")) then
		v37 = nil
	end
	if v37 then
		v37 = v37:GetAttribute("AnchorOffset")
	end
	return typeof(v37) ~= "Vector3" and Vector3.new(0, 1.6, 0.6) or v37
end
local function v_u_45(p38) -- name: posesOf
	-- upvalues: (copy) v_u_5
	local v39 = v_u_5[p38]
	if v39 then
		return v39
	end
	local v40 = nil
	for _, v41 in p38:GetChildren() do
		if not v41:IsA("Keyframe") or v40 and v41.Time >= v40.Time then
			continue
		end
		v40 = v41
	end
	local v42 = {}
	if v40 then
		for _, v43 in v40:GetDescendants() do
			if not v43:IsA("Pose") or v43.Weight <= 0 then
				continue
			end
			local v44 = {
				["part"] = v43.Name,
				["cf"] = v43.CFrame
			}
			table.insert(v42, v44)
		end
	end
	v_u_5[p38] = v42
	return v42
end
local function v_u_53(p46) -- name: jointsOf
	-- upvalues: (copy) v_u_6
	local v47 = v_u_6[p46]
	if v47 then
		local v48 = false
		for _, v49 in v47 do
			if v49:IsDescendantOf(p46) then
				continue
			end
			v48 = true
		end
		if not v48 then
			return v47
		end
	end
	local v50 = {}
	for _, v51 in p46:GetDescendants() do
		local v52 = nil
		if v51:IsA("Motor6D") then
			v52 = v51.Part1
		elseif v51:IsA("AnimationConstraint") then
			v52 = v51.Attachment1
			if v52 then
				v52 = v51.Attachment1.Parent
			end
		end
		if not v52 or (not v52:IsA("BasePart") or (not v51.Enabled or v50[v52.Name])) then
			continue
		end
		v50[v52.Name] = v51
	end
	v_u_6[p46] = v50
	return v50
end
function v_u_2.play(p54, p55, p56, p57) -- name: play
	-- upvalues: (copy) v_u_1, (copy) v_u_2, (copy) v_u_53, (copy) v_u_7, (copy) v_u_45, (copy) v_u_4, (copy) v_u_3
	local v58 = v_u_1:FindFirstChild(v_u_2.FOLDER)
	if v58 then
		if type(p55) == "string" then
			v58 = v58:FindFirstChild(p55)
		else
			v58 = false
		end
	end
	if not (v58 and v58:IsA("KeyframeSequence")) then
		v58 = nil
	end
	local v59
	if p54 then
		v59 = p54.Parent
	else
		v59 = p54
	end
	if not (v58 and v59) then
		return nil
	end
	local v60 = typeof(p56) ~= "number" and 1 or p56
	local v61 = math.clamp(v60, 0, 1)
	local v62 = v_u_53(v59)
	local v63 = v_u_7[p54]
	if not v63 then
		v63 = {}
		v_u_7[p54] = v63
	end
	local v64 = {}
	for _, v65 in v_u_45(v58) do
		if p57 and v_u_4[v65.part] then
			continue
		end
		local v66 = v62[v65.part]
		if not v66 then
			continue
		end
		local v67
		if v_u_3[v65.part] or v61 >= 1 then
			v67 = v65.cf
		else
			v67 = v66.Transform:Lerp(v65.cf, v61)
		end
		v66.Transform = v67
		v64[v66] = true
		v63[v66] = true
	end
	for v68 in v63 do
		if v64[v68] then
			continue
		end
		v68.Transform = CFrame.identity
		v63[v68] = nil
	end
	return true
end
function v_u_2.stop(p69) -- name: stop
	-- upvalues: (copy) v_u_7
	local v70
	if p69 then
		v70 = v_u_7[p69]
	else
		v70 = p69
	end
	if v70 then
		for v71 in v70 do
			if not v71.Parent then
				continue
			end
			v71.Transform = CFrame.identity
		end
		v_u_7[p69] = nil
	end
end
return v_u_2