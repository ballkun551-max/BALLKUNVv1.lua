-- Path: ReplicatedStorage/GameShared
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = {}
local v_u_2 = require(script.Parent:WaitForChild("EcuShared"))
local v_u_3 = require(game:GetService("ReplicatedStorage"):WaitForChild("CareShared"))
local v_u_4 = require(game:GetService("ReplicatedStorage"):WaitForChild("PistonShared"))
local v_u_5 = require(game:GetService("ReplicatedStorage"):WaitForChild("PartsShared"))
v_u_1.REMOTES = "GameRemotes"
v_u_1.START_CASH = 5000
v_u_1.SPAWN_COOLDOWN = 5
v_u_1.MAX_SPAWNED = 1
v_u_1.VIP_MAX_OUT = 3
v_u_1.DELETE_HOLD = 1
v_u_1.STUDS_PER_KM = 3571.428571428571
v_u_1.ODO_INTERVAL = 2
v_u_1.VEHICLES = {
	{
		["id"] = "PCX160",
		["th"] = "City Scooter 160",
		["en"] = "City Scooter 160",
		["category"] = "Scooter",
		["categoryTh"] = "Scooter",
		["price"] = 45000,
		["seats"] = 2,
		["starter"] = true,
		["thumb"] = "rbxassetid://103709608362968"
	},
	{
		["id"] = "TYPER23",
		["th"] = "Hatchback R",
		["en"] = "Hatchback R",
		["category"] = "Car",
		["categoryTh"] = "Car",
		["price"] = 380000,
		["seats"] = 4,
		["starter"] = true,
		["thumb"] = "rbxassetid://113646756594788"
	},
	{
		["id"] = "VESPA_S",
		["th"] = "Classic Scooter S 150",
		["en"] = "Classic Scooter S 150",
		["category"] = "Scooter",
		["categoryTh"] = "Scooter",
		["price"] = 149000,
		["seats"] = 2,
		["starter"] = true,
		["thumb"] = "rbxassetid://102034289245717"
	},
	{
		["id"] = "FK8",
		["th"] = "Hatchback R Classic",
		["en"] = "Hatchback R Classic",
		["category"] = "Car",
		["categoryTh"] = "Car",
		["price"] = 320000,
		["seats"] = 4,
		["starter"] = true,
		["thumb"] = "rbxassetid://138324452093706"
	},
	{
		["id"] = "FK8T",
		["th"] = "Hatchback R Tuned",
		["en"] = "Hatchback R Tuned",
		["category"] = "Car",
		["categoryTh"] = "Car",
		["price"] = 350000,
		["seats"] = 4,
		["starter"] = true,
		["thumb"] = "rbxassetid://90362106998649"
	},
	{
		["id"] = "FL5B",
		["th"] = "Hatchback R Black",
		["en"] = "Hatchback R Black",
		["category"] = "Car",
		["categoryTh"] = "Car",
		["price"] = 600000,
		["seats"] = 4,
		["forSale"] = true,
		["robux"] = 999,
		["product"] = 3728569278,
		["thumb"] = "rbxassetid://113884390553959"
	},
	{
		["id"] = "DMAXMUX",
		["th"] = "Pickup Cab4 X",
		["en"] = "Pickup Cab4 X",
		["category"] = "Car",
		["categoryTh"] = "Car",
		["price"] = 500000,
		["seats"] = 4,
		["forSale"] = true,
		["robux"] = 899,
		["product"] = 3730652001,
		["thumb"] = "rbxassetid://77144105770185"
	},
	{
		["id"] = "G20LCI",
		["th"] = "Sport Sedan 340",
		["en"] = "Sport Sedan 340",
		["category"] = "Car",
		["categoryTh"] = "Car",
		["price"] = 600000,
		["seats"] = 4,
		["forSale"] = true,
		["robux"] = 999,
		["product"] = 3730651893,
		["thumb"] = "rbxassetid://132190396713464"
	},
	{
		["id"] = "XMAX",
		["th"] = "Maxi Scooter 300",
		["en"] = "Maxi Scooter 300",
		["category"] = "Scooter",
		["categoryTh"] = "Scooter",
		["price"] = 185000,
		["seats"] = 2,
		["starter"] = true,
		["thumb"] = "rbxassetid://71455818939457"
	},
	{
		["id"] = "SPORT155",
		["th"] = "Sport Scooter 155",
		["en"] = "Sport Scooter 155",
		["category"] = "Scooter",
		["categoryTh"] = "Scooter",
		["price"] = 79000,
		["seats"] = 2,
		["starter"] = true,
		["thumb"] = "rbxassetid://98491771454105"
	},
	{
		["id"] = "MAXI250",
		["th"] = "Maxi Scooter 250",
		["en"] = "Maxi Scooter 250",
		["category"] = "Scooter",
		["categoryTh"] = "Scooter",
		["price"] = 165000,
		["seats"] = 2,
		["starter"] = true,
		["thumb"] = "rbxassetid://123004117376187"
	},
	{
		["id"] = "TOURER350",
		["th"] = "Tourer 350",
		["en"] = "Tourer 350",
		["category"] = "Scooter",
		["categoryTh"] = "Scooter",
		["price"] = 189000,
		["seats"] = 2,
		["starter"] = true,
		["thumb"] = "rbxassetid://88578164064542"
	},
	{
		["id"] = "TOURER350B",
		["th"] = "Tourer 350 Black",
		["en"] = "Tourer 350 Black",
		["category"] = "Scooter",
		["categoryTh"] = "Scooter",
		["price"] = 199000,
		["seats"] = 2,
		["private"] = true,
		["thumb"] = "rbxassetid://97147949088998"
	},
	{
		["id"] = "TOURER350GT",
		["th"] = "Tourer 350 GT",
		["en"] = "Tourer 350 GT",
		["category"] = "Scooter",
		["categoryTh"] = "Scooter",
		["price"] = 100000,
		["seats"] = 2,
		["forSale"] = true,
		["robux"] = 197,
		["product"] = 3728944718,
		["thumb"] = "rbxassetid://82530744279116"
	},
	{
		["id"] = "CITY150",
		["th"] = "City Scooter 150 R17",
		["en"] = "City Scooter 150 R17",
		["category"] = "Scooter",
		["categoryTh"] = "Scooter",
		["price"] = 55000,
		["seats"] = 2,
		["starter"] = true,
		["thumb"] = "rbxassetid://107494959812465"
	},
	{
		["id"] = "FLAT150",
		["th"] = "Flat Drag 150",
		["en"] = "Flat Drag 150",
		["category"] = "Scooter",
		["categoryTh"] = "Scooter",
		["price"] = 72000,
		["seats"] = 2,
		["starter"] = true,
		["thumb"] = "rbxassetid://84351680111127"
	},
	{
		["id"] = "STREET160",
		["th"] = "Street Scooter 160",
		["en"] = "Street Scooter 160",
		["category"] = "Scooter",
		["categoryTh"] = "Scooter",
		["price"] = 75000,
		["seats"] = 2,
		["starter"] = true,
		["thumb"] = "rbxassetid://117111375227212"
	},
	{
		["id"] = "PCX160SA",
		["th"] = "Metro 160 Shadow",
		["en"] = "Metro 160 Shadow",
		["category"] = "Scooter",
		["categoryTh"] = "Scooter",
		["price"] = 79000,
		["seats"] = 2,
		["starter"] = true,
		["thumb"] = "rbxassetid://110211295754704"
	},
	{
		["id"] = "NMAX20",
		["th"] = "Midi Max 155",
		["en"] = "Midi Max 155",
		["category"] = "Scooter",
		["categoryTh"] = "Scooter",
		["price"] = 85000,
		["seats"] = 2,
		["starter"] = true,
		["thumb"] = "rbxassetid://127835246152022"
	},
	{
		["id"] = "XMAX23G",
		["th"] = "Grand Max 300 Shadow",
		["en"] = "Grand Max 300 Shadow",
		["category"] = "Scooter",
		["categoryTh"] = "Scooter",
		["price"] = 115000,
		["seats"] = 2,
		["starter"] = true,
		["thumb"] = "rbxassetid://105950874393760"
	},
	{
		["id"] = "XMAX23W",
		["th"] = "Grand Max 300 X",
		["en"] = "Grand Max 300 X",
		["category"] = "Scooter",
		["categoryTh"] = "Scooter",
		["price"] = 125000,
		["seats"] = 2,
		["starter"] = true,
		["thumb"] = "rbxassetid://117546543675727"
	},
	{
		["id"] = "XMAX23F",
		["th"] = "Grand Max 300 Flame",
		["en"] = "Grand Max 300 Flame",
		["category"] = "Scooter",
		["categoryTh"] = "Scooter",
		["price"] = 120000,
		["seats"] = 2,
		["private"] = true,
		["thumb"] = "rbxassetid://113276700335554"
	},
	{
		["id"] = "GIORNO23",
		["th"] = "Retro Round 125 Plus",
		["en"] = "Retro Round 125 Plus",
		["category"] = "Scooter",
		["categoryTh"] = "Scooter",
		["price"] = 62000,
		["seats"] = 2,
		["starter"] = true,
		["thumb"] = "rbxassetid://99204838064915"
	},
	{
		["id"] = "GIORNO22",
		["th"] = "Retro Round 125 Classic",
		["en"] = "Retro Round 125 Classic",
		["category"] = "Scooter",
		["categoryTh"] = "Scooter",
		["price"] = 0,
		["seats"] = 2,
		["pass"] = "GiornoClassic"
	},
	{
		["id"] = "GIORNO25D",
		["th"] = "Retro Round 125 Custom Blue",
		["en"] = "Retro Round 125 Custom Blue",
		["category"] = "Scooter",
		["categoryTh"] = "Scooter",
		["price"] = 0,
		["seats"] = 2,
		["pass"] = "GiornoCustom",
		["thumb"] = "rbxassetid://72095683439196"
	},
	{
		["id"] = "GIORNO25T",
		["th"] = "Retro Round 125 Custom Green",
		["en"] = "Retro Round 125 Custom Green",
		["category"] = "Scooter",
		["categoryTh"] = "Scooter",
		["price"] = 0,
		["seats"] = 2,
		["pass"] = "GiornoCustom",
		["thumb"] = "rbxassetid://122392821107645"
	},
	{
		["id"] = "LEAD25",
		["th"] = "Family Box 125 S",
		["en"] = "Family Box 125 S",
		["category"] = "Scooter",
		["categoryTh"] = "Scooter",
		["price"] = 59000,
		["seats"] = 2,
		["starter"] = true,
		["thumb"] = "rbxassetid://74796308318255"
	},
	{
		["id"] = "LEAD25G",
		["th"] = "Family Box 125 Ghost",
		["en"] = "Family Box 125 Ghost",
		["category"] = "Scooter",
		["categoryTh"] = "Scooter",
		["price"] = 69000,
		["seats"] = 2,
		["starter"] = true,
		["thumb"] = "rbxassetid://107598048353348"
	},
	{
		["id"] = "LEAD25F",
		["th"] = "Family Box 125 Green Flame",
		["en"] = "Family Box 125 Green Flame",
		["category"] = "Scooter",
		["categoryTh"] = "Scooter",
		["price"] = 0,
		["seats"] = 2,
		["pass"] = "LeadGreen",
		["thumb"] = "rbxassetid://81073159232393"
	},
	{
		["id"] = "STYLO160G",
		["th"] = "Retro Style 160 R",
		["en"] = "Retro Style 160 R",
		["category"] = "Scooter",
		["categoryTh"] = "Scooter",
		["price"] = 0,
		["seats"] = 2,
		["pass"] = "Skylo160",
		["thumb"] = "rbxassetid://79871509359501"
	},
	{
		["id"] = "FILANO24",
		["th"] = "Retro Grand 125",
		["en"] = "Retro Grand 125",
		["category"] = "Scooter",
		["categoryTh"] = "Scooter",
		["price"] = 100000,
		["seats"] = 2,
		["forSale"] = true,
		["robux"] = 197,
		["product"] = 3729924317,
		["thumb"] = "rbxassetid://108242378694136"
	},
	{
		["id"] = "FINO115",
		["th"] = "Retro Mini 115",
		["en"] = "Retro Mini 115",
		["category"] = "Scooter",
		["categoryTh"] = "Scooter",
		["price"] = 46000,
		["seats"] = 2,
		["starter"] = true,
		["thumb"] = "rbxassetid://135674631299161"
	},
	{
		["id"] = "CHER74",
		["th"] = "Sport Step Drag 150",
		["en"] = "Sport Step Drag 150",
		["category"] = "Scooter",
		["categoryTh"] = "Scooter",
		["price"] = 55000,
		["seats"] = 2,
		["starter"] = true,
		["thumb"] = "rbxassetid://86800518641099"
	},
	{
		["id"] = "CHER150",
		["th"] = "Sport Step Drag 150 Blue",
		["en"] = "Sport Step Drag 150 Blue",
		["category"] = "Scooter",
		["categoryTh"] = "Scooter",
		["price"] = 55000,
		["seats"] = 2,
		["starter"] = true,
		["thumb"] = "rbxassetid://74540864365806"
	},
	{
		["id"] = "CHER72",
		["th"] = "Sport Step Drag 150 Black",
		["en"] = "Sport Step Drag 150 Black",
		["category"] = "Scooter",
		["categoryTh"] = "Scooter",
		["price"] = 55000,
		["seats"] = 2,
		["starter"] = true,
		["thumb"] = "rbxassetid://99031414771980"
	},
	{
		["id"] = "LEAD23V",
		["th"] = "Family Box 125 V",
		["en"] = "Family Box 125 V",
		["category"] = "Scooter",
		["categoryTh"] = "Scooter",
		["price"] = 62000,
		["seats"] = 2,
		["private"] = true,
		["thumb"] = "rbxassetid://122929149810639"
	},
	{
		["id"] = "LEAD23",
		["th"] = "Family Box 125 23",
		["en"] = "Family Box 125 23",
		["category"] = "Scooter",
		["categoryTh"] = "Scooter",
		["price"] = 139000,
		["seats"] = 2,
		["forSale"] = true,
		["robux"] = 225,
		["product"] = 3733592970
	},
	{
		["id"] = "DREAM_RACE",
		["th"] = "Classic Step 125 Racer",
		["en"] = "Classic Step 125 Racer",
		["category"] = "Scooter",
		["categoryTh"] = "Scooter",
		["price"] = 48000,
		["seats"] = 2,
		["starter"] = true,
		["thumb"] = "rbxassetid://108295222307658"
	},
	{
		["id"] = "DREAM_DRAG",
		["th"] = "Classic Step Drag 125",
		["en"] = "Classic Step Drag 125",
		["category"] = "Scooter",
		["categoryTh"] = "Scooter",
		["price"] = 52000,
		["seats"] = 2,
		["starter"] = true,
		["thumb"] = "rbxassetid://121357686443822"
	},
	{
		["id"] = "WAVE_STREET",
		["th"] = "Village Step 110 Street",
		["en"] = "Village Step 110 Street",
		["category"] = "Scooter",
		["categoryTh"] = "Scooter",
		["price"] = 42000,
		["seats"] = 2,
		["starter"] = true,
		["thumb"] = "rbxassetid://101408356821657"
	},
	{
		["id"] = "WAVE_BARE",
		["th"] = "Village Step 110 Bare",
		["en"] = "Village Step 110 Bare",
		["category"] = "Scooter",
		["categoryTh"] = "Scooter",
		["price"] = 40000,
		["seats"] = 2,
		["starter"] = true,
		["thumb"] = "rbxassetid://128351941582274"
	},
	{
		["id"] = "WAVE_SILVER",
		["th"] = "Village Step 100 Silver",
		["en"] = "Village Step 100 Silver",
		["category"] = "Scooter",
		["categoryTh"] = "Scooter",
		["price"] = 38000,
		["seats"] = 2,
		["starter"] = true,
		["thumb"] = "rbxassetid://128363731380153"
	},
	{
		["id"] = "WAVE_KAGE",
		["th"] = "Village Step 125 Kage",
		["en"] = "Village Step 125 Kage",
		["category"] = "Scooter",
		["categoryTh"] = "Scooter",
		["price"] = 50000,
		["seats"] = 2,
		["starter"] = true,
		["thumb"] = "rbxassetid://102932058510409"
	},
	{
		["id"] = "WAVE_110I",
		["th"] = "Village Step 110i Drag",
		["en"] = "Village Step 110i Drag",
		["category"] = "Scooter",
		["categoryTh"] = "Scooter",
		["price"] = 46000,
		["seats"] = 2,
		["starter"] = true,
		["thumb"] = "rbxassetid://116988639995900"
	},
	{
		["id"] = "WAVE_WHITE",
		["th"] = "Village Step 125 White",
		["en"] = "Village Step 125 White",
		["category"] = "Scooter",
		["categoryTh"] = "Scooter",
		["price"] = 47000,
		["seats"] = 2,
		["starter"] = true,
		["thumb"] = "rbxassetid://138331409187512"
	},
	{
		["id"] = "WAVE125S",
		["th"] = "Village Step 125 S",
		["en"] = "Village Step 125 S",
		["category"] = "Scooter",
		["categoryTh"] = "Scooter",
		["price"] = 49000,
		["seats"] = 2,
		["starter"] = true,
		["thumb"] = "rbxassetid://89410414691187"
	},
	{
		["id"] = "SPORT_STEP",
		["th"] = "Sport Step 125",
		["en"] = "Sport Step 125",
		["category"] = "Scooter",
		["categoryTh"] = "Scooter",
		["price"] = 55000,
		["seats"] = 2,
		["starter"] = true,
		["thumb"] = "rbxassetid://123317932695182"
	}
}
v_u_1.LOOK_PATTERNS = {
	"^Paint",
	"^Finish",
	"^Carbon_",
	"^DRL",
	"^Tint$",
	"^Exhaust$",
	"^RainbowOn$",
	"^Underglow$",
	"^ShowMirrors$",
	"^ShieldOff$",
	"^TailLightOn$",
	"^LowerLevel$",
	"^LowerFront$",
	"^LowerRear$",
	"^Plate",
	"^ShieldColor$",
	"^ShieldTransparency$",
	"^TintColor_",
	"^TintClear_",
	"^EngineLevel$",
	"^BrakeLevel$",
	"^EngineOwned$",
	"^BrakeOwned$",
	"^TuneOwned$",
	"^Ecu",
	"^Fuel$",
	"^EngineHealth$",
	"^PistonBore$",
	"^Cam360$",
	"^CamParts$",
	"^PartWheel$",
	"^PartExhaust$",
	"^PartShock$",
	"^PartRadiator$",
	"^PartSeat$",
	"^PartEngineCover$",
	"^PartRoundCover$",
	"^PartExhaustSound$",
	"^PartEngineSound$",
	"^BlinkRate$",
	"^SignalColor$",
	"^PopTune",
	"^Stickers$",
	"^Rung",
	"^Acc_"
}
v_u_1.UPGRADES = {
	["Engine"] = {
		{
			["th"] = "Stock",
			["accel"] = 1,
			["top"] = 1,
			["price"] = 0
		},
		{
			["th"] = "Stage 1",
			["accel"] = 1.15,
			["top"] = 1.05,
			["price"] = 5000
		},
		{
			["th"] = "Stage 2",
			["accel"] = 1.32,
			["top"] = 1.1,
			["price"] = 15000
		},
		{
			["th"] = "Stage 3",
			["accel"] = 1.5,
			["top"] = 1.18,
			["price"] = 30000
		}
	},
	["Brake"] = {
		{
			["th"] = "Stock",
			["brake"] = 1,
			["price"] = 0
		},
		{
			["th"] = "Sport pads",
			["brake"] = 1.2,
			["price"] = 1000
		},
		{
			["th"] = "Big discs",
			["brake"] = 1.4,
			["price"] = 2500
		},
		{
			["th"] = "Race brakes",
			["brake"] = 1.65,
			["price"] = 6000
		}
	}
}
v_u_1.TUNE_PRICES = {
	["Paint"] = 750,
	["Finish"] = nil,
	["Light"] = nil,
	["Underglow"] = 3000,
	["Carbon"] = 1250,
	["BikeCarbon"] = 5000,
	["Tint"] = 500,
	["Lower"] = 4000,
	["Exhaust"] = nil,
	["Accessory"] = 2500,
	["ShieldColor"] = 500,
	["ShieldClear"] = 500,
	["PopTune"] = 5000,
	["Finish"] = {
		["Gloss"] = 0,
		["Matte"] = 500,
		["Chrome"] = 3000
	},
	["Light"] = {
		["Rainbow"] = 0,
		["Solid"] = 750,
		["Gradient"] = 1500,
		["Mode"] = 2500
	},
	["Exhaust"] = {
		["Stock"] = 0,
		["Sport"] = 6000,
		["Carbon"] = 12500,
		["Racing"] = 25000
	}
}
v_u_1.TUNE_PATTERNS = {
	"^Paint",
	"^Finish",
	"^Carbon_",
	"^DRLStyle$",
	"^DRLColor",
	"^DRLMode$",
	"^DRLModeR$",
	"^DRLModeRear$",
	"^DRLSpeed$",
	"^DRLSplit$",
	"^Tint$",
	"^Exhaust$",
	"^Underglow$",
	"^LowerLevel$",
	"^LowerFront$",
	"^LowerRear$",
	"^PartWheel$",
	"^PartExhaust$",
	"^PartShock$",
	"^PartRadiator$",
	"^PartSeat$",
	"^PartEngineCover$",
	"^PartRoundCover$",
	"^PartExhaustSound$",
	"^PartEngineSound$",
	"^Stickers$",
	"^Acc_",
	"^ShieldColor$",
	"^ShieldTransparency$",
	"^TintColor_",
	"^TintClear_",
	"^PopTuneOn$"
}
v_u_1.BUILD_ATTRIBUTES = {
	["DRLModel"] = true,
	["DRLStrip"] = true,
	["DRLGuideDiameter"] = true,
	["DRLGuideTrim"] = true
}
function v_u_1.isTuneAttribute(p6) -- name: isTuneAttribute
	-- upvalues: (copy) v_u_1
	if v_u_1.BUILD_ATTRIBUTES[p6] then
		return false
	end
	for _, v7 in v_u_1.TUNE_PATTERNS do
		if not p6:match(v7) then
			continue
		end
		return true
	end
	return false
end
v_u_1.SHIELD_CLEAR_MAX = 0.9
v_u_1.PER_CHANGE = {
	"ShieldColor_",
	"ShieldClear_",
	"TintColor_",
	"TintClear_"
}
function v_u_1.shieldColorKey(p8) -- name: shieldColorKey
	local v9 = p8.R * 255
	local v10 = math.round(v9)
	local v11 = p8.G * 255
	local v12 = math.round(v11)
	local v13 = p8.B * 255
	return ("ShieldColor_%02x%02x%02x"):format(v10, v12, (math.round(v13)))
end
function v_u_1.shieldClearKey(p14) -- name: shieldClearKey
	local v15 = p14 * 100
	local v16 = math.round(v15)
	return "ShieldClear_" .. tostring(v16)
end
v_u_1.TINT_GROUPS = {
	{
		["id"] = "Plate",
		["th"] = "\224\185\129\224\184\156\224\185\136\224\184\153\224\185\131\224\184\170"
	}
}
function v_u_1.tintLabel(p17) -- name: tintLabel
	-- upvalues: (copy) v_u_1
	for _, v18 in v_u_1.TINT_GROUPS do
		if v18.id ~= p17 then
			continue
		end
		return v18.th
	end
	return p17
end
function v_u_1.tintColorKey(p19, p20) -- name: tintColorKey
	local v21 = p20.R * 255
	local v22 = math.round(v21)
	local v23 = p20.G * 255
	local v24 = math.round(v23)
	local v25 = p20.B * 255
	return ("TintColor_%s_%02x%02x%02x"):format(p19, v22, v24, (math.round(v25)))
end
function v_u_1.tintClearKey(p26, p27) -- name: tintClearKey
	local v28 = p27 * 100
	local v29 = math.round(v28)
	return "TintClear_" .. p26 .. "_" .. tostring(v29)
end
function v_u_1.tuneItems(p30) -- name: tuneItems
	-- upvalues: (copy) v_u_1, (copy) v_u_5
	local v31 = v_u_1.TUNE_PRICES
	local v32 = {}
	for v33, v34 in p30:GetAttributes() do
		local v35 = v33:match("^Paint(%a+)$")
		if v35 and (v35 ~= "ShockBody" and (v35 ~= "WholeShock" and typeof(v34) == "Color3")) then
			local v36 = "Paint_" .. v35
			local v37 = v31.Paint
			local v38 = v35 .. " paint"
			if v37 and v37 > 0 then
				v32[v36] = {
					["price"] = nil,
					["label"] = nil,
					["level"] = nil,
					["price"] = v37,
					["label"] = v38
				}
			end
			local v39 = p30:GetAttribute("Finish" .. v35)
			if type(v39) == "string" and v31.Finish[v39] then
				local v40 = "Finish_" .. v39
				local v41 = v31.Finish[v39]
				local v42 = v39 .. " finish"
				if v41 and v41 > 0 then
					v32[v40] = {
						["price"] = nil,
						["label"] = nil,
						["level"] = nil,
						["price"] = v41,
						["label"] = v42
					}
				end
			end
		end
		local v43 = v33:match("^Acc_(.+)$")
		if v43 and v34 == true then
			local v44 = v31.Accessory
			local v45 = require
			local v46 = game:GetService("ReplicatedStorage")
			local v47, v48 = pcall(v45, v46:FindFirstChild("PCX160Shared"))
			local v49 = v47 and (v48 and v48.accessory)
			if v49 then
				v49 = v48.accessory(v43)
			end
			if v49 and v49.price then
				v44 = v49.price
			end
			local v50 = p30:GetAttribute("AccPrice_" .. v43)
			if typeof(v50) ~= "number" then
				v50 = v44
			end
			local v51 = "Acc_" .. v43
			local v52 = p30:GetAttribute("AccLabel_" .. v43) or v43
			local v53 = tostring(v52)
			if v50 and v50 > 0 then
				v32[v51] = {
					["price"] = nil,
					["label"] = nil,
					["level"] = nil,
					["price"] = v50,
					["label"] = v53
				}
			end
		end
		local v54 = v33:match("^Carbon_(.+)$")
		if not v54 or v34 ~= true then
			continue
		end
		local v55 = p30:GetAttribute("CarbonPrice_" .. v54)
		local v56 = "Carbon_" .. v54
		if typeof(v55) ~= "number" then
			if p30:GetAttribute("VehicleTag") == "PCX160" then
				v55 = v31.BikeCarbon
			else
				v55 = v31.Carbon
			end
		end
		local v57 = "Carbon " .. v54:lower()
		if not v55 or v55 <= 0 then
			continue
		end
		v32[v56] = {
			["price"] = nil,
			["label"] = nil,
			["level"] = nil,
			["price"] = v55,
			["label"] = v57
		}
	end
	local v58 = p30:GetAttribute("DRLStyle")
	if type(v58) == "string" and v31.Light[v58] then
		local v59 = "Light_" .. v58
		local v60 = v31.Light[v58]
		local v61 = v58 .. " lights"
		if v60 and v60 > 0 then
			v32[v59] = {
				["price"] = nil,
				["label"] = nil,
				["level"] = nil,
				["price"] = v60,
				["label"] = v61
			}
		end
	end
	local v62 = p30:GetAttribute("Exhaust")
	if type(v62) == "string" and (p30:GetAttribute("VehicleTag") ~= "PCX160" and (p30:GetAttribute("FixedExhaust") == nil and v31.Exhaust[v62])) then
		local v63 = "Exhaust_" .. v62
		local v64 = v31.Exhaust[v62]
		local v65 = v62 .. " exhaust"
		if v64 and v64 > 0 then
			v32[v63] = {
				["price"] = nil,
				["label"] = nil,
				["level"] = nil,
				["price"] = v64,
				["label"] = v65
			}
		end
	end
	if p30:GetAttribute("Underglow") == true then
		local v66 = v31.Underglow
		if v66 and v66 > 0 then
			v32.Underglow = {
				["price"] = nil,
				["label"] = "Underglow",
				["level"] = nil,
				["price"] = v66
			}
		end
	end
	local v67 = tonumber(p30:GetAttribute("Tint")) or 0
	if v67 > 0 then
		local v68 = v31.Tint * v67
		if v68 and v68 > 0 then
			v32.Tint = {
				["price"] = nil,
				["label"] = "Window tint",
				["level"] = nil,
				["price"] = v68,
				["level"] = v67
			}
		end
	end
	local v69 = p30:GetAttribute("ShieldColor")
	if typeof(v69) == "Color3" then
		local v70 = v_u_1.shieldColorKey(v69)
		local v71 = v31.ShieldColor
		if v71 and v71 > 0 then
			v32[v70] = {
				["price"] = nil,
				["label"] = "\224\184\170\224\184\181\224\184\138\224\184\180\224\184\167",
				["level"] = nil,
				["price"] = v71
			}
		end
	end
	local v72 = p30:GetAttribute("ShieldTransparency")
	if type(v72) == "number" then
		local v73 = v_u_1.shieldClearKey(v72)
		local v74 = v31.ShieldClear
		if v74 and v74 > 0 then
			v32[v73] = {
				["price"] = nil,
				["label"] = "\224\184\132\224\184\167\224\184\178\224\184\161\224\185\131\224\184\170\224\184\138\224\184\180\224\184\167",
				["level"] = nil,
				["price"] = v74
			}
		end
	end
	for v75, v76 in p30:GetAttributes() do
		local v77 = v75:match("^TintColor_(.+)$")
		if v77 and typeof(v76) == "Color3" then
			local v78 = v_u_1.tintColorKey(v77, v76)
			local v79 = v31.ShieldColor
			local v80 = "\224\184\170\224\184\181" .. v_u_1.tintLabel(v77)
			if v79 and v79 > 0 then
				v32[v78] = {
					["price"] = nil,
					["label"] = nil,
					["level"] = nil,
					["price"] = v79,
					["label"] = v80
				}
			end
		end
		local v81 = v75:match("^TintClear_(.+)$")
		if not v81 or type(v76) ~= "number" then
			continue
		end
		local v82 = v_u_1.tintClearKey(v81, v76)
		local v83 = v31.ShieldClear
		local v84 = "\224\184\132\224\184\167\224\184\178\224\184\161\224\185\131\224\184\170" .. v_u_1.tintLabel(v81)
		if not v83 or v83 <= 0 then
			continue
		end
		v32[v82] = {
			["price"] = nil,
			["label"] = nil,
			["level"] = nil,
			["price"] = v83,
			["label"] = v84
		}
	end
	if p30:GetAttribute("PopTuneOn") == true and v_u_5.popTuneTunable(p30) then
		local v85 = v31.PopTune
		if v85 and v85 > 0 then
			v32.PopTune = {
				["price"] = nil,
				["label"] = "\224\184\136\224\184\185\224\184\153\224\184\162\224\184\180\224\184\135",
				["level"] = nil,
				["price"] = v85
			}
		end
	end
	for _, v86 in v_u_5.SLOTS do
		local v87 = v_u_5.KITS[p30:GetAttribute(v86.attr) or ""]
		if not v87 then
			continue
		end
		local v88 = "Part_" .. p30:GetAttribute(v86.attr)
		local v89 = v87.price
		local v90 = v87.th
		if not v89 or v89 <= 0 then
			continue
		end
		v32[v88] = {
			["price"] = nil,
			["label"] = nil,
			["level"] = nil,
			["price"] = v89,
			["label"] = v90
		}
	end
	for _, v91 in {
		"LowerFront",
		"LowerRear",
		"LowerLevel",
		"SpawnLowerFront",
		"SpawnLowerRear",
		"SpawnLowerLevel"
	} do
		if (tonumber(p30:GetAttribute(v91)) or 0) <= 0 then
			continue
		end
		local v92 = v31.Lower
		if v92 and v92 > 0 then
			v32.Lower = {
				["price"] = nil,
				["label"] = "Lowering kit",
				["level"] = nil,
				["price"] = v92
			}
		end
	end
	local v93 = p30:GetAttribute("Stickers")
	if type(v93) == "string" and v93 ~= "" then
		local v94 = game:GetService("ReplicatedStorage"):FindFirstChild("StickerCatalog")
		local v95 = require
		local v96, v97 = pcall(v95, v94)
		local v98 = game:GetService("HttpService").JSONDecode
		local v99 = game:GetService("HttpService")
		local v100, v101 = pcall(v98, v99, v93)
		if v96 and (v100 and type(v101) == "table") then
			for _, v102 in v101 do
				local v103
				if type(v102) == "table" then
					v103 = v97.get(v102.s)
				else
					v103 = false
				end
				if not v103 then
					continue
				end
				local v104 = "Sticker_" .. v103.id
				local v105 = v103.price
				local v106 = "Sticker " .. v103.name
				if not v105 or v105 <= 0 then
					continue
				end
				v32[v104] = {
					["price"] = nil,
					["label"] = nil,
					["level"] = nil,
					["price"] = v105,
					["label"] = v106
				}
			end
		end
	end
	return v32
end
function v_u_1.tuneOwned(p107) -- name: tuneOwned
	local v108 = p107 and p107:GetAttribute("TuneOwned") or ""
	local v109 = {}
	for v110 in tostring(v108):gmatch("[^,]+") do
		local v111, v112 = v110:match("^(.-)=(%d+)$")
		if v111 then
			v109[v111] = tonumber(v112)
		else
			v109[v110] = true
		end
	end
	return v109
end
function v_u_1.tuneOwnedText(p113) -- name: tuneOwnedText
	local v114 = {}
	for v117, v116 in p113 do
		if type(v116) == "number" then
			local v117 = v117 .. "=" .. v116
		end
		table.insert(v114, v117)
	end
	table.sort(v114)
	return table.concat(v114, ",")
end
function v_u_1.tuneCost(p118, p119, p120, p121) -- name: tuneCost
	-- upvalues: (copy) v_u_1
	if not p121 then
		return p118[p119] and 0 or p120
	end
	local v122 = p118[p119]
	local v123 = tonumber(v122) or 0
	return v123 >= p121 and 0 or v_u_1.TUNE_PRICES.Tint * (p121 - v123)
end
function v_u_1.tuneDue(p124, p125) -- name: tuneDue
	-- upvalues: (copy) v_u_1
	local v126 = p125 or v_u_1.tuneOwned(p124)
	local v127 = 0
	local v128 = {}
	for v129, v130 in v_u_1.tuneItems(p124) do
		local v131 = v_u_1.tuneCost(v126, v129, v130.price, v130.level)
		if v131 <= 0 then
			continue
		end
		v127 = v127 + v131
		local v132 = v130.label
		table.insert(v128, v132)
	end
	table.sort(v128)
	return v127, v128
end
function v_u_1.tuneOwnAll(p133, p134) -- name: tuneOwnAll
	-- upvalues: (copy) v_u_1
	local v135 = p134 or v_u_1.tuneOwned(p133)
	local v136 = v_u_1.tuneItems(p133)
	for v137, v138 in v136 do
		local v139
		if v138.level then
			local v140 = v135[v137]
			local v141 = tonumber(v140) or 0
			local v142 = v138.level
			v139 = math.max(v141, v142)
		else
			v139 = true
		end
		v135[v137] = v139
	end
	for _, v143 in v_u_1.PER_CHANGE do
		for v144 in v135 do
			if v144:sub(1, #v143) ~= v143 or v136[v144] then
				continue
			end
			v135[v144] = nil
		end
	end
	return v135
end
function v_u_1.tunePriceText(p145, p146, p147) -- name: tunePriceText
	-- upvalues: (copy) v_u_1
	return (not p147 or p147 <= 0) and "Free" or (v_u_1.tuneOwned(p145)[p146] and "Owned" or v_u_1.priceText(p147))
end
function v_u_1.priceText(p148) -- name: priceText
	-- upvalues: (copy) v_u_1
	return (not p148 or p148 <= 0) and "Free" or "\224\184\191" .. v_u_1.formatNumber(p148)
end
v_u_1.DONATE_PRODUCTS = {}
v_u_1.PASS_PERKS = {
	["VIP"] = {
		["pay"] = 1.5,
		["cooldown"] = 0
	},
	["X2Money"] = {
		["pay"] = 2
	}
}
function v_u_1.hasPass(p149, p150) -- name: hasPass
	return p149:GetAttribute("Pass_" .. p150) == true
end
local v_u_151 = {
	["Owner"] = true,
	["Admin"] = true,
	["Developer"] = true
}
function v_u_1.passLocked(p152, p153) -- name: passLocked
	-- upvalues: (copy) v_u_1, (copy) v_u_151
	local v154 = require
	local v155 = game:GetService("ReplicatedStorage"):WaitForChild("GameUI")
	local v156, v157 = pcall(v154, v155:WaitForChild("StoreConfig"))
	if not v156 then
		return false
	end
	for _, v158 in v157.GAMEPASSES do
		if v158.key ~= p153 then
			continue
		end
		local v159 = v158.id
		if type(v159) ~= "number" then
			local v160 = v158.product
			if type(v160) ~= "number" then
				local v161
				if v158.soon == true then
					v161 = not v_u_151[p152:GetAttribute("Rank")]
				else
					v161 = false
				end
				return v161
			end
		end
		return not v_u_1.hasPass(p152, p153)
	end
	return false
end
function v_u_1.passName(p162) -- name: passName
	local v163 = require
	local v164 = game:GetService("ReplicatedStorage"):WaitForChild("GameUI")
	local v165, v166 = pcall(v163, v164:WaitForChild("StoreConfig"))
	for _, v167 in not v165 and {} or v166.GAMEPASSES do
		if v167.key ~= p162 then
			continue
		end
		return v167.name
	end
	return p162
end
function v_u_1.payBoost(p168, p169) -- name: payBoost
	-- upvalues: (copy) v_u_1
	local v170 = 1
	for v171, v172 in v_u_1.PASS_PERKS do
		if not (v172.pay and v_u_1.hasPass(p168, v171)) then
			continue
		end
		v170 = v170 + (v172.pay - 1)
	end
	local v173 = p169 * v170 + 0.5
	return math.floor(v173)
end
function v_u_1.spawnLimits(p174) -- name: spawnLimits
	-- upvalues: (copy) v_u_1, (copy) v_u_151
	local v175 = v_u_1.MAX_SPAWNED
	local v176 = v_u_1.SPAWN_COOLDOWN
	for v177, v178 in v_u_1.PASS_PERKS do
		if not v_u_1.hasPass(p174, v177) then
			continue
		end
		local v179 = v178.max or 0
		v175 = math.max(v175, v179)
		local v180 = v178.cooldown or v176
		v176 = math.min(v176, v180)
	end
	if v_u_1.hasPass(p174, "VIP") or v_u_151[p174:GetAttribute("Rank") or ""] then
		local v181 = p174:GetAttribute("VipVehiclesOut")
		if type(v181) == "number" and v181 == v181 then
			local v182 = math.floor(v181)
			local v183 = v_u_1.VIP_MAX_OUT
			local v184 = math.clamp(v182, 1, v183)
			v175 = math.max(v175, v184)
		end
	end
	return v175, v176
end
function v_u_1.upgradeOwned(p185, p186) -- name: upgradeOwned
	local v187 = p185:GetAttribute(p186 .. "Owned") or 0
	local v188 = p185:GetAttribute(p186 .. "Level") or 0
	return math.max(v187, v188)
end
function v_u_1.upgradeCost(p189, p190, p191) -- name: upgradeCost
	-- upvalues: (copy) v_u_1
	local v192 = 0
	for v193 = v_u_1.upgradeOwned(p189, p190) + 1, p191 do
		v192 = v192 + v_u_1.UPGRADES[p190][v193 + 1].price
	end
	return v192
end
function v_u_1.upgradeScales(p194) -- name: upgradeScales
	-- upvalues: (copy) v_u_1, (copy) v_u_2, (copy) v_u_4, (copy) v_u_3
	local v195 = v_u_1.UPGRADES.Engine[(p194:GetAttribute("EngineLevel") or 0) + 1] or v_u_1.UPGRADES.Engine[1]
	local v196 = v_u_1.UPGRADES.Brake[(p194:GetAttribute("BrakeLevel") or 0) + 1] or v_u_1.UPGRADES.Brake[1]
	local v197 = v_u_2.gain(p194)
	local v198 = p194:GetAttribute("AdminSpeed")
	local v199 = (typeof(v198) ~= "number" or v198 <= 0) and 1 or v198
	local v200, v201 = v_u_4.scales(p194)
	local v202 = p194:GetAttribute("BaseAccel")
	local v203 = (typeof(v202) ~= "number" or v202 <= 0) and 1 or v202
	local v204 = v195.top * v197 * v199 * v201
	local v205 = p194:GetAttribute("MaxSpeed")
	if typeof(v205) == "number" and (v205 > 0 and p194:GetAttribute("SpeedCapExempt") ~= true) then
		local v206 = v_u_4.capKmh(p194) or v_u_2.TOP_KMH
		local v207 = v_u_2.TOP_KMH
		local v208 = math.min(v206, v207) / v_u_2.KMH_PER_STUD / v205
		v204 = math.min(v204, v208)
	end
	local v209 = v_u_3.healthPower(p194)
	return v195.accel * v197 * v199 * v209 * v200 * v203, v196.brake, v204
end
function v_u_1.driveTop(p210, p211, p212) -- name: driveTop
	-- upvalues: (copy) v_u_3, (copy) v_u_2, (copy) v_u_4
	local v213 = v_u_3.healthTop(p210)
	local v214 = (p210:GetAttribute("MaxSpeed") or 100) * p211 * (p212 or 1)
	if p210:GetAttribute("SpeedCapExempt") == true then
		return v214 * v213
	end
	local v215
	if p212 and p212 > 1 then
		v215 = v_u_2.TUCK_TOP_KMH
	else
		v215 = v_u_2.TOP_KMH
	end
	local v216 = v_u_4.capKmh
	local v217
	if p212 == nil then
		v217 = false
	else
		v217 = p212 > 1
	end
	local v218 = v216(p210, v217)
	if v218 then
		v215 = math.min(v215, v218)
	end
	local v219 = v_u_2.ABS_KMH
	local v220 = math.min(v215, v219) / v_u_2.KMH_PER_STUD
	return math.min(v214, v220) * v213
end
function v_u_1.topKmh(p221) -- name: topKmh
	-- upvalues: (copy) v_u_1, (copy) v_u_2
	local v222 = p221:GetAttribute("MaxSpeed")
	if typeof(v222) ~= "number" or v222 <= 0 then
		return nil
	end
	local _, _, v223 = v_u_1.upgradeScales(p221)
	return v222 * v223 * v_u_2.KMH_PER_STUD
end
v_u_1.ADMIN_SPEEDS = {
	0.25,
	0.5,
	0.75,
	1,
	1.25,
	1.5,
	2,
	3
}
v_u_1.TUNE_HINT = "Tune at a tuning shop: AUTOWORKS East or West (ring roads) or by the drag strip"
function v_u_1.tuneBays() -- name: tuneBays
	local v224 = {}
	local v225 = workspace:FindFirstChild("Map")
	local v226
	if v225 then
		v226 = v225:FindFirstChild("Landmarks")
	else
		v226 = v225
	end
	local v227 = {}
	if v226 then
		v226 = v226:FindFirstChild("Garage")
	end
	__set_list(v227, 1, {v226})
	if v225 then
		v225 = v225:FindFirstChild("TuneShops")
	end
	for _, v228 in not v225 and {} or v225:GetChildren() do
		table.insert(v227, v228)
	end
	for _, v229 in v227 do
		local v230 = v229:GetAttribute("TuneBay")
		if typeof(v230) ~= "CFrame" then
			continue
		end
		local v231 = { v230, v229:GetAttribute("TuneBayRadius") or 16, v229:GetAttribute("TuneKiosk") }
		table.insert(v224, v231)
	end
	return v224
end
function v_u_1.tuneBay(p232) -- name: tuneBay
	-- upvalues: (copy) v_u_1
	local v233 = (1 / 0)
	local v234 = nil
	local v235 = 0
	for _, v236 in v_u_1.tuneBays() do
		local v237 = not p232 and 0 or (v236[1].Position - p232).Magnitude
		if v237 >= v233 then
			continue
		end
		v234 = v236[1]
		v235 = v236[2]
		v233 = v237
	end
	return v234, v235
end
function v_u_1.inTuneBay(p238) -- name: inTuneBay
	-- upvalues: (copy) v_u_1
	if not (p238 and p238.Parent) then
		return false
	end
	local v239 = p238:GetPivot().Position
	local v240, v241 = v_u_1.tuneBay(v239)
	if not v240 then
		return false
	end
	local v242 = v239 - v240.Position
	local v243 = v242.X
	local v244 = v242.Z
	local v245
	if Vector3.new(v243, 0, v244).Magnitude <= v241 then
		local v246 = v242.Y
		v245 = math.abs(v246) < 12
	else
		v245 = false
	end
	return v245
end
function v_u_1.atExhaustShop(p247) -- name: atExhaustShop
	if not (p247 and p247.Parent) then
		return false
	end
	local v248 = workspace:FindFirstChild("Map")
	if v248 then
		v248 = v248:FindFirstChild("TuneShops")
	end
	local v249 = p247:GetPivot().Position
	for _, v250 in not v248 and {} or v248:GetChildren() do
		local v251 = v250:GetAttribute("TuneBay")
		if v250:GetAttribute("ExhaustTones") ~= true or typeof(v251) ~= "CFrame" then
			continue
		end
		local v252 = v249 - v251.Position
		local v253 = v252.X
		local v254 = v252.Z
		if Vector3.new(v253, 0, v254).Magnitude > (v250:GetAttribute("TuneBayRadius") or 16) + 2 then
			continue
		end
		local v255 = v252.Y
		if math.abs(v255) >= 12 then
			continue
		end
		return true
	end
	return false
end
function v_u_1.vehicle(p256) -- name: vehicle
	-- upvalues: (copy) v_u_1
	for _, v257 in v_u_1.VEHICLES do
		if v257.id ~= p256 then
			continue
		end
		return v257
	end
	return nil
end
function v_u_1.isLookAttribute(p258) -- name: isLookAttribute
	-- upvalues: (copy) v_u_1
	if v_u_1.BUILD_ATTRIBUTES[p258] then
		return false
	end
	for _, v259 in v_u_1.LOOK_PATTERNS do
		if not p258:match(v259) then
			continue
		end
		return true
	end
	return false
end
function v_u_1.encodeValue(p260) -- name: encodeValue
	local v261 = typeof(p260)
	if v261 == "Color3" then
		local v262 = {}
		local v263 = {}
		local v264 = p260.R * 255
		local v265 = math.round(v264)
		local v266 = p260.G * 255
		local v267 = math.round(v266)
		local v268 = p260.B * 255
		__set_list(v263, 1, {v265, v267, (math.round(v268))})
		v262.c = v263
		return v262
	elseif v261 == "boolean" or (v261 == "number" or v261 == "string") then
		return p260
	else
		return nil
	end
end
function v_u_1.encodeLook(p269) -- name: encodeLook
	-- upvalues: (copy) v_u_1
	local v270 = {}
	local v271 = p269:GetAttribute("TuneBaseline")
	local v272
	if type(v271) == "string" then
		local v273 = game:GetService("HttpService").JSONDecode
		local v274 = game:GetService("HttpService")
		local v275, v276 = pcall(v273, v274, v271)
		v272 = (not v275 or type(v276) ~= "table") and {} or v276
	else
		v272 = nil
	end
	for v277, v278 in p269:GetAttributes() do
		if not v_u_1.isLookAttribute(v277) or v272 and v_u_1.isTuneAttribute(v277) then
			continue
		end
		v270[v277] = v_u_1.encodeValue(v278)
	end
	for v279, v280 in v272 or {} do
		if type(v279) ~= "string" or not v_u_1.isTuneAttribute(v279) then
			continue
		end
		v270[v279] = v280
	end
	return v270
end
function v_u_1.decodeValue(p281) -- name: decodeValue
	if type(p281) == "table" then
		local v282 = p281.c
		if type(v282) == "table" then
			local v283 = Color3.fromRGB
			local v284 = p281.c[1]
			local v285 = tonumber(v284) or 0
			local v286 = p281.c[2]
			local v287 = tonumber(v286) or 0
			local v288 = p281.c[3]
			return v283(v285, v287, tonumber(v288) or 0)
		end
	end
	return p281
end
function v_u_1.formatNumber(p289) -- name: formatNumber
	local v290 = math.abs(p289) + 0.5
	local v291 = math.floor(v290)
	local v292 = tostring(v291):reverse():gsub("(%d%d%d)", "%1,"):reverse()
	if v292:sub(1, 1) == "," then
		v292 = v292:sub(2)
	end
	return (p289 < 0 and "-" or "") .. v292
end
function v_u_1.formatCash(p293) -- name: formatCash
	-- upvalues: (copy) v_u_1
	return "\224\184\191 " .. v_u_1.formatNumber(p293)
end
return v_u_1