-- Path: Players/ygggggg55551/PlayerScripts/SkyDancerClient
-- Class: LocalScript  true/Enum.RunContext.Legacy
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = game:GetService("CollectionService")
local v2 = game:GetService("RunService")
local v_u_3 = CFrame.Angles(0, 0, 1.5707963267948966)
local v_u_4 = {}
local v_u_5 = {}
local v_u_6 = {}
local function v_u_26(p7) -- name: setup
	-- upvalues: (copy) v_u_4
	if v_u_4[p7] then
		return
	else
		local v8 = p7:GetAttribute("Base")
		local v9 = p7:GetAttribute("Segments")
		if typeof(v8) == "CFrame" and type(v9) == "number" then
			local v10 = p7:GetAttribute("Step") or 1.2
			local v11 = p7:GetAttribute("ArmSegments") or 5
			local v12 = {
				["model"] = nil,
				["base"] = nil,
				["N"] = nil,
				["step"] = nil,
				["shoulder"] = nil,
				["armN"] = nil,
				["armStep"] = nil,
				["segs"] = nil,
				["arms"] = nil,
				["head"] = nil,
				["hair"] = nil,
				["phase"] = nil,
				["last"] = 0,
				["model"] = p7,
				["base"] = v8,
				["N"] = v9,
				["step"] = v10,
				["shoulder"] = p7:GetAttribute("Shoulder") or 11,
				["armN"] = v11,
				["armStep"] = p7:GetAttribute("ArmStep") or 1.05,
				["segs"] = {},
				["arms"] = {
					["L"] = {},
					["R"] = {}
				},
				["head"] = {},
				["hair"] = {},
				["phase"] = (v8.X * 0.37 + v8.Z * 0.11) % 10
			}
			for v13 = 1, v9 do
				v12.segs[v13] = p7:FindFirstChild(("Seg%02d"):format(v13))
			end
			for _, v14 in { "L", "R" } do
				for v15 = 1, v11 do
					v12.arms[v14][v15] = p7:FindFirstChild(("Arm%s%d"):format(v14, v15))
				end
			end
			local v16 = v8 * CFrame.new(0, v10 * v9, 0)
			for _, v17 in { "Dome", "Face" } do
				local v18 = p7:FindFirstChild(v17)
				if not v18 then
					continue
				end
				local v19 = v12.head
				local v20 = {
					["part"] = v18,
					["off"] = v16:ToObjectSpace(v18.CFrame)
				}
				table.insert(v19, v20)
			end
			for v21 = 1, 12 do
				local v22 = p7:FindFirstChild("Hair" .. v21)
				if not v22 then
					continue
				end
				local v23 = v12.hair
				local v24 = {
					["part"] = v22,
					["off"] = v16:ToObjectSpace(v22.CFrame),
					["k"] = v21
				}
				table.insert(v23, v24)
			end
			for _, v25 in v12.segs do
				if v25 then
					continue
				end
				return
			end
			v_u_4[p7] = v12
		end
	end
end
local function v_u_91(p27, p28) -- name: pose
	-- upvalues: (copy) v_u_5, (copy) v_u_6, (copy) v_u_3
	table.clear(v_u_5)
	table.clear(v_u_6)
	local v29 = p28 % 8.5
	local v30
	if v29 < 1.7 then
		local v31 = v29 / 1.7 * 3.141592653589793
		v30 = math.sin(v31)
	else
		v30 = 0
	end
	local v32 = p28 / 8.5
	local v33 = math.floor(v32) * 2.39
	local v34 = p27.base
	local v35 = nil
	for v36 = 1, p27.N do
		local v37 = v36 / p27.N
		local v38 = (0.035 + 0.09 * v37) * (1 - v30 * 0.5)
		local v39 = 2.3 * p28 + v36 * 0.45
		local v40 = math.sin(v39)
		local v41 = 5.3 * p28 + v36 * 1.1
		local v42 = v38 * (v40 + math.sin(v41) * 0.55)
		local v43 = 1.7 * p28 + v36 * 0.38 + 1.3
		local v44 = math.sin(v43)
		local v45 = 4.4 * p28 - v36 * 0.9
		local v46 = v38 * (v44 + math.sin(v45) * 0.55)
		local v47 = (v37 - 0.3) / 0.7
		local v48 = v30 * math.clamp(v47, 0, 1) * 0.36
		local v49 = v42 + math.cos(v33) * v48
		local v50 = v46 + math.sin(v33) * v48
		local v51 = v34 * CFrame.Angles(v49, 0, v50)
		local v52 = p27.segs[v36]
		local v53 = v51 * CFrame.new(0, p27.step / 2, 0) * v_u_3
		if v52 then
			local v54 = v_u_5
			table.insert(v54, v52)
			local v55 = v_u_6
			table.insert(v55, v53)
		end
		if v36 == p27.shoulder then
			v35 = v51 * CFrame.new(0, p27.step / 2, 0)
		end
		v34 = v51 * CFrame.new(0, p27.step, 0)
	end
	for _, v56 in p27.head do
		local v57 = v56.part
		local v58 = v34 * v56.off
		if not v57 then
			continue
		end
		local v59 = v_u_5
		table.insert(v59, v57)
		local v60 = v_u_6
		table.insert(v60, v58)
	end
	for _, v61 in p27.hair do
		local v62 = v61.part
		local v63 = v34 * v61.off
		local v64 = CFrame.Angles
		local v65 = 9 * p28 + v61.k
		local v66 = math.sin(v65) * 0.25
		local v67 = 11 * p28 + v61.k * 1.7
		local v68 = v63 * v64(v66, 0, math.sin(v67) * 0.3)
		if not v62 then
			continue
		end
		local v69 = v_u_5
		table.insert(v69, v62)
		local v70 = v_u_6
		table.insert(v70, v68)
	end
	for _, v71 in { "L", "R" } do
		local v72 = v71 == "L" and -1 or 1
		local v73 = v71 == "L" and 0 or 2.1
		local v74 = 5.6 * p28 + v73
		local v75 = math.sin(v74) * 0.6632251157578453 + 1.0821041362364843
		local v76 = 13 * p28 + v73
		local v77 = v75 + math.sin(v76) * 0.24434609527920614 - v30 * 0.9599310885968813
		local v78 = 3.1 * p28 + v73 * 1.3
		local v79 = math.sin(v78) * 0.4363323129985824
		local v80 = v35 * CFrame.new(v72 * 0.9, 0, 0) * CFrame.Angles(v79, 0, -v72 * v77)
		for v81 = 1, p27.armN do
			local v82 = 7.5 * p28 + v81 * 0.85 + v73
			local v83 = math.sin(v82) * 0.32 * (v81 / p27.armN)
			local v84 = 6.1 * p28 + v81 * 1.3 + v73
			local v85 = math.sin(v84) * 0.2
			local v86 = v80 * CFrame.Angles(v85, 0, -v72 * v83)
			local v87 = p27.arms[v71][v81]
			local v88 = v86 * CFrame.new(0, p27.armStep / 2, 0) * v_u_3
			if v87 then
				local v89 = v_u_5
				table.insert(v89, v87)
				local v90 = v_u_6
				table.insert(v90, v88)
			end
			v80 = v86 * CFrame.new(0, p27.armStep, 0)
		end
	end
	workspace:BulkMoveTo(v_u_5, v_u_6, Enum.BulkMoveMode.FireCFrameChanged)
end
for _, v92 in v_u_1:GetTagged("SkyDancer") do
	task.spawn(v_u_26, v92)
end
v_u_1:GetInstanceAddedSignal("SkyDancer"):Connect(function(p93)
	-- upvalues: (copy) v_u_26
	task.defer(v_u_26, p93)
end)
v_u_1:GetInstanceRemovedSignal("SkyDancer"):Connect(function(p94)
	-- upvalues: (copy) v_u_4
	v_u_4[p94] = nil
end)
v2.RenderStepped:Connect(function()
	-- upvalues: (copy) v_u_4, (copy) v_u_91
	local v95 = workspace.CurrentCamera
	if v95 then
		local v96 = os.clock()
		for v97, v98 in v_u_4 do
			if v97.Parent then
				local v99 = v98.base.Position
				local v100 = (v95.CFrame.Position - v99).Magnitude
				if v100 > 420 then
					continue
				end
				local _, v101 = v95:WorldToViewportPoint(v99 + Vector3.new(0, 10, 0))
				if not v101 and v100 > 40 or (v100 < 220 and 0.03333333333333333 or 0.08333333333333333) > v96 - v98.last then
					continue
				end
				v98.last = v96
				v_u_91(v98, v96 + v98.phase)
			else
				v_u_4[v97] = nil
			end
		end
	end
end)
workspace.DescendantAdded:Connect(function(p102)
	-- upvalues: (copy) v_u_1, (copy) v_u_4, (copy) v_u_26
	if p102:IsA("BasePart") and p102.Name:match("^Seg%d") then
		local v103 = p102.Parent
		if v103 and (v_u_1:HasTag(v103, "SkyDancer") and not v_u_4[v103]) then
			task.defer(v_u_26, v103)
		end
	end
end)