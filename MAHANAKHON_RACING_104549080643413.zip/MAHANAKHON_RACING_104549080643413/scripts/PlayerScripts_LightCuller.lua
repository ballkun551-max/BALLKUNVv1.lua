-- Path: Players/ygggggg55551/PlayerScripts/LightCuller
-- Class: LocalScript  true/Enum.RunContext.Legacy
-- Decompiled by BALL KUN Universal Map Dump

game:GetService("Players")
local v_u_1 = game:GetService("Lighting")
local v2 = game:GetService("CollectionService")
local v_u_3 = {}
local v_u_4 = v_u_1:GetAttribute("LowGfx") == true
local v_u_5 = 0
local v_u_6 = setmetatable({}, {
	["__mode"] = "k"
})
local function v11(p_u_7) -- name: track
	-- upvalues: (copy) v_u_3, (copy) v_u_6, (ref) v_u_4, (ref) v_u_5
	if not v_u_3[p_u_7] and (not v_u_6[p_u_7] and p_u_7:IsA("Light")) then
		local v_u_8 = {
			["on"] = p_u_7.Enabled
		}
		v_u_8.conn = p_u_7:GetPropertyChangedSignal("Enabled"):Connect(function()
			-- upvalues: (ref) v_u_4, (ref) v_u_5, (copy) p_u_7, (copy) v_u_8, (ref) v_u_6, (ref) v_u_3
			if not v_u_4 and os.clock() >= v_u_5 then
				if p_u_7.Enabled ~= v_u_8.on then
					v_u_6[p_u_7] = true
					local v9 = p_u_7
					local v10 = v_u_3[v9]
					if v10 then
						v10.conn:Disconnect()
						v_u_3[v9] = nil
					end
				end
			end
		end)
		v_u_3[p_u_7] = v_u_8
	end
end
local function v_u_23(p12) -- name: step
	-- upvalues: (ref) v_u_4, (ref) v_u_5, (copy) v_u_3
	if v_u_4 or os.clock() < v_u_5 then
		return
	else
		local v13 = workspace.CurrentCamera
		if v13 then
			local v14 = v13.CFrame.Position
			for v15, v16 in v_u_3 do
				local v17 = v15.Parent
				local v18
				if v17 then
					if v17:IsA("Attachment") then
						v18 = v17.WorldPosition
					elseif v17:IsA("BasePart") then
						v18 = v17.Position
					else
						v18 = nil
					end
				else
					v18 = nil
				end
				if not v18 then
					continue
				end
				local v19 = v15.Range * 12
				local v20 = math.clamp(v19, 200, 500)
				local v21 = (v18 - v14).Magnitude
				local v22
				if v16.on then
					v22 = v21 <= v20
				else
					v22 = v21 <= v20 * 0.9
				end
				if v22 == v16.on and (not p12 or v15.Enabled == v22) then
					continue
				end
				v16.on = v22
				v15.Enabled = v22
			end
		end
	end
end
v_u_1:GetAttributeChangedSignal("LowGfx"):Connect(function()
	-- upvalues: (ref) v_u_4, (copy) v_u_1, (ref) v_u_5, (copy) v_u_3, (copy) v_u_23
	v_u_4 = v_u_1:GetAttribute("LowGfx") == true
	v_u_5 = os.clock() + 1.5
	if not v_u_4 then
		task.delay(1.6, function()
			-- upvalues: (ref) v_u_4, (ref) v_u_3, (ref) v_u_23
			if not v_u_4 then
				for v24, v25 in v_u_3 do
					v25.on = v24.Enabled
				end
				v_u_23(true)
			end
		end)
	end
end)
v2:GetInstanceAddedSignal("FarCullLight"):Connect(v11)
v2:GetInstanceRemovedSignal("FarCullLight"):Connect(function(p26) -- name: forget
	-- upvalues: (copy) v_u_3
	local v27 = v_u_3[p26]
	if v27 then
		v27.conn:Disconnect()
		v_u_3[p26] = nil
	end
end)
for _, v28 in v2:GetTagged("FarCullLight") do
	v11(v28)
end
while true do
	task.wait(0.5)
	v_u_23(false)
end