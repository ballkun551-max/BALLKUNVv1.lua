-- Path: Players/ygggggg55551/PlayerScripts/VehicleCare
-- Class: LocalScript  true/Enum.RunContext.Legacy
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = require(game:GetService("ReplicatedStorage"):WaitForChild("NetSeal"))
local v2 = game:GetService("Players")
game:GetService("ProximityPromptService")
local v3 = game:GetService("ReplicatedStorage")
local v4 = game:GetService("RunService")
local v_u_5 = require(v3:WaitForChild("GameShared"))
local v_u_6 = require(v3:WaitForChild("CareShared"))
local v7 = v3:WaitForChild("GameUI")
local v_u_8 = require(v7:WaitForChild("Theme"))
local v_u_9 = require(v7:WaitForChild("Toast"))
local v_u_10 = require(v7:WaitForChild("Icons"))
local v_u_11 = require(v7:WaitForChild("Dash"))
local v_u_12 = v2.LocalPlayer
local v_u_13 = v3:WaitForChild(v_u_5.REMOTES)
local v_u_14 = v_u_8.isTouch()
local v_u_15 = Color3.fromRGB(255, 84, 84)
Color3.fromRGB(80, 230, 120)
Color3.fromRGB(255, 190, 60)
local v16 = v_u_8.screen("VehicleCare", 8, v_u_12:WaitForChild("PlayerGui"))
local function v_u_22(...) -- name: call
	-- upvalues: (copy) v_u_13, (copy) v_u_6, (copy) v_u_1
	local v17 = v_u_13:FindFirstChild(v_u_6.REMOTE)
	if v17 then
		local v18 = v_u_1.invoke
		local v19, v20, v21 = pcall(v18, v17, ...)
		if v19 then
			return v20, v21
		else
			return false, "Couldn\'t reach the server"
		end
	else
		return false, "Not ready"
	end
end
local v_u_23 = v_u_14 and 248 or 260
local v_u_24 = v_u_14 and 42 or 52
local v_u_25 = v_u_14 and 26 or 30
local v_u_26 = v_u_14 and 5 or 6
local v_u_27 = v_u_8.LCD_UNLIT
local v_u_28 = v_u_8.ACCENT
local v_u_29 = Color3.fromRGB(96, 226, 140)
local v_u_30 = Color3.fromRGB(255, 176, 52)
local v31
if v_u_14 then
	v31 = v_u_8.new("ScreenGui", {
		["Name"] = "VehicleCareTop",
		["ResetOnSpawn"] = false,
		["ScreenInsets"] = nil,
		["ZIndexBehavior"] = nil,
		["DisplayOrder"] = 8,
		["Parent"] = nil,
		["ScreenInsets"] = Enum.ScreenInsets.TopbarSafeInsets,
		["ZIndexBehavior"] = Enum.ZIndexBehavior.Sibling,
		["Parent"] = v_u_12.PlayerGui
	})
else
	v31 = v16
end
local v32 = v_u_8.new
local v33 = "Frame"
local v34 = {
	["Name"] = "Gauge",
	["BackgroundColor3"] = nil,
	["BackgroundTransparency"] = 0.08,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Visible"] = false,
	["Parent"] = nil,
	["BackgroundColor3"] = v_u_8.PANEL,
	["AnchorPoint"] = Vector2.new(1, 1)
}
local v35
if v_u_14 then
	v35 = UDim2.new(1, -8, 1, -4)
else
	v35 = UDim2.new(1, -v_u_8.EDGE, 1, -v_u_8.EDGE)
end
v34.Position = v35
v34.Size = UDim2.fromOffset(v_u_23, v_u_24)
v34.Parent = v31
local v_u_36 = v32(v33, v34)
v_u_8.corner(v_u_36, v_u_14 and 10 or 12)
local v_u_37 = v_u_8.border(v_u_36, Color3.new(1, 1, 1), 0.88, 1)
local v38 = v_u_8.new("Frame", {
	["Name"] = "Accent",
	["BackgroundColor3"] = nil,
	["BorderSizePixel"] = 0,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["BackgroundColor3"] = v_u_8.ACCENT,
	["AnchorPoint"] = Vector2.new(0.5, 0),
	["Position"] = UDim2.new(0.5, 0, 0, 0),
	["Size"] = UDim2.new(1, -24, 0, 2),
	["Parent"] = v_u_36
})
v_u_8.corner(v38, 1)
v_u_8.new("Frame", {
	["BackgroundColor3"] = nil,
	["BackgroundTransparency"] = 0.9,
	["BorderSizePixel"] = 0,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["BackgroundColor3"] = Color3.new(1, 1, 1),
	["AnchorPoint"] = Vector2.new(0.5, 0.5),
	["Position"] = UDim2.fromScale(0.5, 0.5),
	["Size"] = UDim2.new(0, 1, 1, -14),
	["Parent"] = v_u_36
})
local function v_u_67(p39, p40) -- name: pumpGlyph
	-- upvalues: (copy) v_u_8
	local v_u_41 = v_u_8.DARK_TEXT
	local v_u_42 = v_u_8.new("Frame", {
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.5),
		["Size"] = UDim2.fromOffset(p40, p40),
		["Parent"] = p39
	})
	local v_u_43 = p40 / 18
	local function v62(p44, p45, p46, p47, p48, p49) -- name: r
		-- upvalues: (ref) v_u_8, (copy) v_u_41, (copy) v_u_43, (copy) v_u_42
		local v50 = v_u_8.new
		local v51 = {
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = nil,
			["BorderSizePixel"] = 0,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["BackgroundColor3"] = p48 or v_u_41,
			["BackgroundTransparency"] = p49 or 0
		}
		local v52 = UDim2.fromOffset
		local v53 = p44 * v_u_43 + 0.5
		local v54 = math.floor(v53)
		local v55 = p45 * v_u_43 + 0.5
		v51.Position = v52(v54, (math.floor(v55)))
		local v56 = UDim2.fromOffset
		local v57 = p46 * v_u_43 + 0.5
		local v58 = math.floor(v57)
		local v59 = math.max(1, v58)
		local v60 = p47 * v_u_43 + 0.5
		local v61 = math.floor(v60)
		v51.Size = v56(v59, (math.max(1, v61)))
		v51.Parent = v_u_42
		return v50("Frame", v51)
	end
	local v63 = v62(2, 2, 9, 14)
	local v64 = v_u_8.corner
	local v65 = 1.5 * v_u_43
	local v66 = math.floor(v65)
	v64(v63, (math.max(1, v66)))
	v62(3.6, 3.8, 5.8, 4, v_u_8.ACCENT)
	v62(1, 16, 11, 2)
	v62(11, 6, 3, 2)
	v62(13.5, 6, 2, 8)
	v62(12.5, 3, 2, 3.5)
	return v_u_42
end
local function v92(p68, p69, p70) -- name: half
	-- upvalues: (copy) v_u_8, (copy) v_u_36, (copy) v_u_14, (copy) v_u_25, (copy) v_u_67, (copy) v_u_10, (copy) v_u_26, (copy) v_u_27
	local v71 = v_u_8.new("Frame", {
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Position"] = UDim2.fromScale((p68 - 1) * 0.5, 0),
		["Size"] = UDim2.fromScale(0.5, 1),
		["Parent"] = v_u_36
	})
	local v72 = v_u_14 and 7 or 8
	v_u_8.new("UIPadding", {
		["PaddingLeft"] = UDim.new(0, v72),
		["PaddingRight"] = UDim.new(0, v72),
		["PaddingTop"] = UDim.new(0, v_u_14 and 7 or 9),
		["PaddingBottom"] = UDim.new(0, v_u_14 and 7 or 9),
		["Parent"] = v71
	})
	local v73 = v_u_8.new("Frame", {
		["Name"] = "Tile",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_8.ACCENT,
		["AnchorPoint"] = Vector2.new(0, 0.5),
		["Position"] = UDim2.fromScale(0, 0.5),
		["Size"] = UDim2.fromOffset(v_u_25, v_u_25),
		["Parent"] = v71
	})
	v_u_8.corner(v73, v_u_14 and 7 or 9)
	if p70 == "pump" then
		local v74 = v_u_67
		local v75 = v_u_25 * 0.62
		v74(v73, (math.floor(v75)))
	else
		local v76 = v_u_10.make
		local v77 = v_u_8.DARK_TEXT
		local v78 = v_u_25 * 0.66
		local v79 = math.floor(v78)
		local v80, v81 = pcall(v76, p70, v77, v79)
		if v80 and v81 then
			v81.AnchorPoint = Vector2.new(0.5, 0.5)
			v81.Position = UDim2.fromScale(0.5, 0.5)
			v81.Parent = v73
		end
	end
	local v82 = v_u_8.new("Frame", {
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Position"] = UDim2.new(0, v_u_25 + (v_u_14 and 6 or 7), 0, 0),
		["Size"] = UDim2.new(1, -(v_u_25 + (v_u_14 and 6 or 7)), 1, 0),
		["Parent"] = v71
	})
	v_u_8.text({
		["Text"] = nil,
		["TextSize"] = 10,
		["FontFace"] = nil,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["TextYAlignment"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Text"] = p69,
		["FontFace"] = v_u_8.FONT_HEAVY,
		["TextColor3"] = v_u_8.TEXT_DIM,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["TextYAlignment"] = Enum.TextYAlignment.Top,
		["Size"] = UDim2.new(0.55, 0, 0, 12),
		["Parent"] = v82
	})
	local v83 = v_u_8.text({
		["Text"] = "",
		["TextSize"] = nil,
		["FontFace"] = nil,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["TextYAlignment"] = nil,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["TextSize"] = v_u_14 and 14 or 16,
		["FontFace"] = v_u_8.FONT_DISPLAY,
		["TextColor3"] = v_u_8.TEXT,
		["TextXAlignment"] = Enum.TextXAlignment.Right,
		["TextYAlignment"] = Enum.TextYAlignment.Top,
		["AnchorPoint"] = Vector2.new(1, 0),
		["Position"] = UDim2.new(1, 0, 0, -2),
		["Size"] = UDim2.new(0.5, 0, 0, v_u_14 and 15 or 18),
		["Parent"] = v82
	})
	local v84 = v_u_8.new("Frame", {
		["Name"] = "Bar",
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0, 1),
		["Position"] = UDim2.fromScale(0, 1),
		["Size"] = UDim2.new(1, 0, 0, v_u_26),
		["Parent"] = v82
	})
	if v_u_14 then
		v_u_8.new("UIListLayout", {
			["FillDirection"] = Enum.FillDirection.Horizontal,
			["Padding"] = UDim.new(0, 2),
			["SortOrder"] = Enum.SortOrder.LayoutOrder,
			["Parent"] = v84
		})
	end
	local v85 = {}
	for v86 = 1, 10 do
		local v87 = v_u_8.new
		local v88 = "Frame"
		local v89 = {
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["LayoutOrder"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["BackgroundColor3"] = v_u_27,
			["LayoutOrder"] = v86
		}
		local v90
		if v_u_14 then
			v90 = UDim2.new()
		else
			v90 = UDim2.new((v86 - 1) / 10, (v86 - 1) * 2 / 10, 0, 0)
		end
		v89.Position = v90
		v89.Size = UDim2.new(0.1, -1.8, 1, 0)
		v89.Parent = v84
		local v91 = v87(v88, v89)
		v_u_8.corner(v91, 2)
		v85[v86] = v91
	end
	return {
		["pct"] = v83,
		["segs"] = v85,
		["tile"] = v73
	}
end
local v_u_93 = v92(1, "FUEL", "pump")
local v_u_94 = v92(2, "ENGINE", "shield")
local v95 = v_u_8.button
local v96 = {
	["name"] = "Repair",
	["text"] = "Repair",
	["icon"] = "key",
	["grad"] = "gold",
	["textSize"] = 14,
	["anchor"] = nil,
	["position"] = nil,
	["size"] = nil,
	["parent"] = nil
}
local v97
if v_u_14 then
	v97 = Vector2.new(1, 0)
else
	v97 = Vector2.new(0.5, 0)
end
v96.anchor = v97
local v98
if v_u_14 then
	v98 = UDim2.new(1, -8, 1, 6)
else
	v98 = UDim2.new(0.5, 0, 0, 138)
end
v96.position = v98
v96.size = UDim2.fromOffset(210, 36)
v96.parent = v31
local v_u_99 = v95(v96)
v_u_99.Visible = false
if v_u_8.isPhone() then
	v_u_8.new("UIScale", {
		["Scale"] = v_u_8.PHONE_SHRINK,
		["Parent"] = v_u_36
	})
	local v100 = UDim2.new
	local v101 = v_u_24 * (1 - v_u_8.PHONE_SHRINK) / 2
	v_u_36.Position = v100(1, -8, 1, -4 - math.floor(v101))
	local v102 = v_u_8.new("Frame", {
		["Name"] = "RepairHolder",
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["AnchorPoint"] = v_u_99.AnchorPoint,
		["Position"] = v_u_99.Position,
		["Size"] = v_u_99.Size,
		["Parent"] = v31
	})
	v_u_8.new("UIScale", {
		["Scale"] = v_u_8.PHONE_SHRINK,
		["Parent"] = v102
	})
	v_u_99.AnchorPoint = Vector2.zero
	v_u_99.Position = UDim2.new()
	v_u_99.Parent = v102
end
local v_u_103 = require(v7:WaitForChild("ControlLayout"))
if v_u_14 then
	local v_u_104 = v_u_36.Position
	local v_u_105 = v_u_36:FindFirstChildOfClass("UIScale") or v_u_8.new("UIScale", {
		["Name"] = "CareScale",
		["Parent"] = nil,
		["Parent"] = v_u_36
	})
	local v_u_106 = v_u_105.Scale
	v_u_103.register("hud.care", v_u_36, "\224\184\153\224\185\137\224\184\179\224\184\161\224\184\177\224\184\153 / \224\185\128\224\184\132\224\184\163\224\184\183\224\185\136\224\184\173\224\184\135", false, {
		["apply"] = function(p107, p108, p109) -- name: apply
			-- upvalues: (copy) v_u_36, (copy) v_u_104, (copy) v_u_105, (copy) v_u_106
			v_u_36.Position = v_u_104 + UDim2.fromOffset(p107, p108)
			v_u_105.Scale = v_u_106 * p109
		end
	})
end
local v_u_110
if v_u_14 then
	v_u_110 = nil
else
	v_u_110 = v_u_8.new("UIScale", {
		["Name"] = "CareScale",
		["Parent"] = nil,
		["Parent"] = v_u_36
	})
end
local v_u_111 = nil
local function v_u_125() -- name: placeOnKeyboard
	-- upvalues: (copy) v_u_11, (copy) v_u_23, (copy) v_u_8, (copy) v_u_110, (copy) v_u_36, (copy) v_u_24, (ref) v_u_111
	local v112 = v_u_11.frame()
	local v113
	if v112 and v112.AbsoluteSize.X > 0 then
		v113 = v112.AbsoluteSize.X / v_u_23
	else
		local v114 = workspace.CurrentCamera
		local v115 = v_u_8.scaleFor
		local v116
		if v114 then
			v116 = v114.ViewportSize
		else
			v116 = Vector2.new(1920, 1080)
		end
		v113 = v115(v116)
	end
	local v117 = v_u_110.Scale - v113
	if math.abs(v117) > 0.001 then
		v_u_110.Scale = v113
	end
	local v118 = v_u_8.EDGE + (not v112 and 0 or v112.AbsoluteSize.Y + 8 * v113)
	local v119 = UDim2.new
	local v120 = -v_u_8.EDGE
	local v121 = v118 + 0.5
	local v122 = v119(1, v120, 1, -math.floor(v121))
	if v_u_36.Position ~= v122 then
		v_u_36.Position = v122
	end
	local v123 = (v_u_24 + 8) * v113
	if v_u_111 == nil then
		v_u_111 = v123
		v_u_11.liftKeys(v123)
		return
	else
		local v124 = v_u_111 - v123
		if math.abs(v124) > 0.01 then
			v_u_111 = v123
			v_u_11.liftKeys(v123)
		end
	end
end
if not v_u_14 then
	v_u_125()
end
local function v_u_144(p126, p127, p128) -- name: show
	-- upvalues: (copy) v_u_8, (copy) v_u_30, (copy) v_u_29, (copy) v_u_28, (copy) v_u_27
	local v129 = math.clamp(p127, 0, 100)
	local v130 = v129 < 15
	local v131
	if v130 then
		v131 = v_u_8.RED
	elseif p128 == "engine" then
		if v129 < 50 then
			v131 = v_u_30
		else
			v131 = v_u_29
		end
	else
		v131 = v_u_28
	end
	local v132 = v129 / 10 - 0.001
	local v133 = math.ceil(v132)
	local v134
	if v130 then
		local v135 = os.clock() * 7
		v134 = (math.sin(v135) * 0.5 + 0.5) * 0.65 + 0.35
	else
		v134 = 1
	end
	for v136, v137 in p126.segs do
		if v136 <= v133 then
			v137.BackgroundColor3 = v131
			v137.BackgroundTransparency = 1 - v134
		else
			v137.BackgroundColor3 = v_u_27
			v137.BackgroundTransparency = 0
		end
	end
	local v138 = p126.tile
	local v139
	if v130 then
		v139 = v_u_8.RED
	else
		v139 = v_u_8.ACCENT
	end
	v138.BackgroundColor3 = v139
	local v140 = p126.pct
	local v141 = v129 + 0.5
	v140.Text = ("%d%%"):format((math.floor(v141)))
	local v142 = p126.pct
	local v143
	if v130 then
		v143 = Color3.fromRGB(255, 110, 110)
	else
		v143 = v_u_8.TEXT
	end
	v142.TextColor3 = v143
end
local function v_u_146() -- name: ridden
	-- upvalues: (copy) v_u_12
	local v145 = v_u_12.Character
	if v145 then
		v145 = v_u_12.Character:FindFirstChildOfClass("Humanoid")
	end
	if v145 then
		v145 = v145.SeatPart
	end
	if v145 then
		v145 = v145:FindFirstAncestorWhichIsA("Model")
	end
	while v145 and (v145.Parent and v145.Parent.Name ~= "SpawnedVehicles") do
		v145 = v145.Parent:FindFirstAncestorWhichIsA("Model")
	end
	if v145 and (v145.Parent and v145.Parent.Name == "SpawnedVehicles") then
		return v145
	else
		return nil
	end
end
local v_u_147 = nil
v_u_99.Activated:Connect(function()
	-- upvalues: (ref) v_u_147, (copy) v_u_22, (copy) v_u_9
	if v_u_147 then
		local v148, v149 = v_u_22("Repair", v_u_147)
		v_u_9.show(v149 or "", v148 and "ok" or "error")
	end
end)
local v_u_150 = 0
v4.Heartbeat:Connect(function()
	-- upvalues: (ref) v_u_150, (copy) v_u_146, (copy) v_u_14, (copy) v_u_125, (copy) v_u_36, (copy) v_u_103, (copy) v_u_99, (copy) v_u_6, (copy) v_u_144, (copy) v_u_93, (copy) v_u_94, (copy) v_u_37, (copy) v_u_15, (copy) v_u_12, (ref) v_u_147, (copy) v_u_5, (copy) v_u_8
	local v151 = os.clock()
	if v151 - v_u_150 < 0.1 then
		return
	else
		v_u_150 = v151
		local v152 = v_u_146()
		if v152 and not v_u_14 then
			v_u_125()
		end
		v_u_36.Visible = v152 ~= nil and true or v_u_103.isEditing()
		if v152 then
			local v153 = v_u_6.fuel(v152)
			local v154 = v_u_6.health(v152)
			v_u_144(v_u_93, v153, "fuel")
			v_u_144(v_u_94, v154, "engine")
			local v155 = v153 < 15 and true or v154 < 15
			local v156 = v_u_37
			local v157
			if v155 then
				v157 = v_u_15
			else
				v157 = Color3.new(1, 1, 1)
			end
			v156.Color = v157
			local v158 = v_u_37
			local v159
			if v155 then
				local v160 = os.clock() * 6
				v159 = (math.sin(v160) * 0.5 + 0.5) * 0.6 + 0.2
			else
				v159 = 0.88
			end
			v158.Transparency = v159
			local v161 = v152:GetAttribute("OwnerUserId") == v_u_12.UserId
			local v162 = v_u_6.repairCost(v152)
			v_u_147 = v152
			local v163 = v_u_99
			if v161 then
				if v162 > 0 then
					v161 = v_u_5.inTuneBay(v152)
				else
					v161 = false
				end
			end
			v163.Visible = v161
			if v_u_99.Visible then
				v_u_8.setButton(v_u_99, "gold", ("Repair engine  %s"):format(v_u_5.formatCash(v162)), Color3.new(1, 1, 1))
			end
		else
			v_u_99.Visible = false
		end
	end
end)
local v_u_164 = v_u_8.new("Frame", {
	["Name"] = "Work",
	["BackgroundColor3"] = nil,
	["BackgroundTransparency"] = 0.15,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Visible"] = false,
	["Parent"] = nil,
	["BackgroundColor3"] = Color3.fromRGB(12, 14, 20),
	["AnchorPoint"] = Vector2.new(0.5, 0.5),
	["Position"] = UDim2.fromScale(0.5, 0.66),
	["Size"] = UDim2.fromOffset(v_u_14 and 260 or 320, 64),
	["Parent"] = v16
})
v_u_8.corner(v_u_164, 14)
v_u_8.border(v_u_164, v_u_8.ACCENT, 0.4, 1.5)
local v_u_165 = v_u_8.text({
	["Text"] = "",
	["TextSize"] = 16,
	["FontFace"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["TextXAlignment"] = nil,
	["Parent"] = nil,
	["FontFace"] = v_u_8.FONT_BOLD,
	["Position"] = UDim2.fromOffset(14, 8),
	["Size"] = UDim2.new(1, -70, 0, 22),
	["TextXAlignment"] = Enum.TextXAlignment.Left,
	["Parent"] = v_u_164
})
local v_u_166 = v_u_8.text({
	["Text"] = "",
	["TextSize"] = 15,
	["FontFace"] = nil,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["TextXAlignment"] = nil,
	["Parent"] = nil,
	["FontFace"] = v_u_8.FONT_DIGITS,
	["AnchorPoint"] = Vector2.new(1, 0),
	["Position"] = UDim2.new(1, -14, 0, 8),
	["Size"] = UDim2.fromOffset(60, 22),
	["TextXAlignment"] = Enum.TextXAlignment.Right,
	["Parent"] = v_u_164
})
local v167 = v_u_8.new("Frame", {
	["BackgroundColor3"] = Color3.fromRGB(40, 44, 56),
	["Position"] = UDim2.fromOffset(14, 38),
	["Size"] = UDim2.new(1, -28, 0, 12),
	["Parent"] = v_u_164
})
v_u_8.corner(v167, 6)
local v_u_168 = v_u_8.new("Frame", {
	["BackgroundColor3"] = v_u_8.ACCENT,
	["Size"] = UDim2.fromScale(0, 1),
	["Parent"] = v167
})
v_u_8.corner(v_u_168, 6)
v4.RenderStepped:Connect(function()
	-- upvalues: (copy) v_u_12, (copy) v_u_164, (copy) v_u_168, (copy) v_u_165, (copy) v_u_166
	local v169 = v_u_12:GetAttribute("BusyUntil")
	local v170 = v_u_12:GetAttribute("BusyStart")
	if typeof(v169) == "number" and typeof(v170) == "number" then
		v_u_164.Visible = true
		local v171 = workspace:GetServerTimeNow()
		local v172 = v171 - v170
		local v173 = v169 - v170
		local v174 = v172 / math.max(0.1, v173)
		local v175 = math.clamp(v174, 0, 1)
		v_u_168.Size = UDim2.fromScale(v175, 1)
		v_u_165.Text = v_u_12:GetAttribute("Busy") or "Working\226\128\166"
		local v176 = v_u_166
		local v177 = v169 - v171
		v176.Text = ("%.1fs"):format((math.max(0, v177)))
	else
		v_u_164.Visible = false
	end
end)