-- Path: ReplicatedStorage/EcuShared
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = game:GetService("HttpService")
local v_u_6 = {
	["REMOTE"] = "Ecu",
	["GAIN_MIN"] = 0.6,
	["GAIN_MAX"] = 2,
	["TOP_KMH"] = 330,
	["TUCK_TOP_KMH"] = 340,
	["ABS_KMH"] = 350,
	["KMH_PER_STUD"] = 1.008,
	["SEND_COOLDOWN"] = 2,
	["SHARE_PRICE"] = 5000,
	["BORROWED"] = "borrowed",
	["CODE_CHARS"] = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789",
	["CODE_LENGTH"] = 8,
	["CODE_COOLDOWN"] = 3,
	["cleanCode"] = function(p2) -- name: cleanCode
		-- upvalues: (copy) v_u_6
		if type(p2) ~= "string" or #p2 > 40 then
			return nil
		end
		local v3 = p2:upper():gsub("[^%w]", "")
		if #v3 ~= v_u_6.CODE_LENGTH then
			return nil
		end
		for v4 = 1, #v3 do
			if v_u_6.CODE_CHARS:find(v3:sub(v4, v4), 1, true) then
				continue
			end
			return nil
		end
		return v3
	end,
	["formatCode"] = function(p5) -- name: formatCode
		return p5:sub(1, 4) .. "-" .. p5:sub(5)
	end
}
local v7 = {
	"1k",
	"2k",
	"3k",
	"4k",
	"5k",
	"6k",
	"7k",
	"8k",
	"9k",
	"10k",
	"10800"
}
v_u_6.TABLES = {
	{
		["key"] = "Air",
		["label"] = "AIR",
		["sub"] = "\224\184\173\224\184\178\224\184\129\224\184\178\224\184\168",
		["xs"] = nil,
		["axis"] = "Revolutions Per Minute",
		["min"] = 0,
		["max"] = 2,
		["step"] = 0.01,
		["tol"] = 0.16,
		["fmt"] = "%.2f",
		["base"] = 1,
		["recipeMin"] = 0.6,
		["recipeMax"] = 1.6,
		["xs"] = v7
	},
	{
		["key"] = "Fuel",
		["label"] = "Fuel - Petrol",
		["xs"] = nil,
		["axis"] = "Revolutions Per Minute",
		["min"] = 0.6,
		["max"] = 1.6,
		["step"] = 0.01,
		["tol"] = 0.16,
		["fmt"] = "%.2f",
		["base"] = 1,
		["xs"] = v7
	},
	{
		["key"] = "Afr",
		["label"] = "AFR",
		["xs"] = nil,
		["axis"] = "Revolutions Per Minute",
		["min"] = 9,
		["max"] = 17,
		["step"] = 0.1,
		["tol"] = 1.3,
		["fmt"] = "%.1f",
		["textbook"] = 12.8,
		["xs"] = v7
	},
	{
		["key"] = "Tps",
		["label"] = "TPS Petrol",
		["xs"] = nil,
		["axis"] = "TPS",
		["min"] = 0.6,
		["max"] = 1.6,
		["step"] = 0.01,
		["tol"] = 0.16,
		["fmt"] = "%.2f",
		["base"] = 1,
		["xs"] = {
			"0%",
			"10%",
			"20%",
			"30%",
			"40%",
			"50%",
			"60%",
			"70%",
			"80%",
			"90%",
			"100%"
		}
	},
	{
		["key"] = "Oil",
		["label"] = "Oil compensation",
		["xs"] = nil,
		["axis"] = "Revolutions Per Minute",
		["min"] = 0,
		["max"] = 1,
		["step"] = 0.01,
		["tol"] = 0.16,
		["fmt"] = "%.2f",
		["xs"] = v7
	},
	{
		["key"] = "Ign",
		["label"] = "IGN Explosion Point",
		["xs"] = nil,
		["axis"] = "Revolutions Per Minute",
		["min"] = 5,
		["max"] = 45,
		["step"] = 0.1,
		["tol"] = 6,
		["fmt"] = "%.1f\194\176",
		["xs"] = v7
	},
	{
		["key"] = "Idle",
		["label"] = "IDLE",
		["sub"] = "\224\185\128\224\184\148\224\184\180\224\184\153\224\184\171\224\184\173\224\184\154",
		["xs"] = nil,
		["axis"] = "Revolutions Per Minute",
		["min"] = 0.6,
		["max"] = 1.6,
		["step"] = 0.005,
		["tol"] = 0.16,
		["fmt"] = "%.3f",
		["base"] = 1,
		["xs"] = v7
	},
	{
		["key"] = "Speed",
		["label"] = "SPEED",
		["sub"] = "\224\184\132\224\184\167\224\184\178\224\184\161\224\185\132\224\184\167",
		["xs"] = nil,
		["axis"] = "Revolutions Per Minute",
		["min"] = 0,
		["max"] = 2,
		["step"] = 0.01,
		["tol"] = 0.16,
		["fmt"] = "%.2f",
		["recipeMin"] = 0.6,
		["recipeMax"] = 1.6,
		["xs"] = v7
	}
}
v_u_6.POINTS = #v7
v_u_6.BANDS = {
	{ 1, 4 },
	{ 5, 8 },
	{ 9, 11 }
}
function v_u_6.table(p8) -- name: table
	-- upvalues: (copy) v_u_6
	for _, v9 in v_u_6.TABLES do
		if v9.key ~= p8 then
			continue
		end
		return v9
	end
	return nil
end
function v_u_6.stockFile() -- name: stockFile
	-- upvalues: (copy) v_u_6
	local v10 = {}
	for _, v11 in v_u_6.TABLES do
		local v12 = {}
		for v13 = 1, v_u_6.POINTS do
			if v11.key == "Afr" then
				v12[v13] = 13.5
			elseif v11.key == "Oil" or v11.key == "Speed" then
				v12[v13] = 0
			elseif v11.key == "Ign" then
				v12[v13] = (v13 - 1) * 1.2 + 14
			else
				v12[v13] = 1
			end
		end
		v10[v11.key] = v12
	end
	return v10
end
function v_u_6.clean(p14) -- name: clean
	-- upvalues: (copy) v_u_6
	if type(p14) ~= "table" then
		return nil
	end
	local v15 = nil
	local v16 = {}
	for _, v17 in v_u_6.TABLES do
		local v18 = p14[v17.key]
		if v18 == nil then
			v15 = v15 or v_u_6.stockFile()
			v18 = v15[v17.key]
		end
		if type(v18) ~= "table" or #v18 ~= v_u_6.POINTS then
			return nil
		end
		local v19 = {}
		for v20 = 1, v_u_6.POINTS do
			local v21 = v18[v20]
			local v22 = tonumber(v21)
			if not v22 or v22 ~= v22 then
				return nil
			end
			local v23 = v22 / v17.step
			local v24 = math.round(v23) * v17.step
			local v25 = v17.min
			local v26 = v17.max
			v19[v20] = math.clamp(v24, v25, v26)
		end
		v16[v17.key] = v19
	end
	return v16
end
function v_u_6.sum(p27) -- name: sum
	-- upvalues: (copy) v_u_6
	local v28 = 7
	for _, v29 in v_u_6.TABLES do
		local v30
		if type(p27) == "table" then
			v30 = p27[v29.key]
		else
			v30 = false
		end
		for v31 = 1, v_u_6.POINTS do
			local v32
			if type(v30) == "table" then
				local v33 = v30[v31]
				v32 = tonumber(v33) or 0
			else
				v32 = 0
			end
			local v34 = v32 ~= v32 and 0 or v32
			local v35 = v28 * 31
			local v36 = math.clamp(v34, -1000000, 1000000) / v29.step
			v28 = (v35 + math.round(v36) + v31) % 2147483647
		end
	end
	return v28
end
function v_u_6.encode(p37) -- name: encode
	-- upvalues: (copy) v_u_1
	return v_u_1:JSONEncode(p37)
end
function v_u_6.decode(p38) -- name: decode
	-- upvalues: (copy) v_u_1
	if type(p38) == "string" and p38 ~= "" then
		local v39 = v_u_1.JSONDecode
		local v40 = v_u_1
		local v41, v42 = pcall(v39, v40, p38)
		if v41 then
			return v42
		else
			return nil
		end
	else
		return nil
	end
end
v_u_6.FULL_AT = 1
function v_u_6.gainFor(p43) -- name: gainFor
	-- upvalues: (copy) v_u_6
	if p43 < 0.5 then
		return v_u_6.GAIN_MIN + (1 - v_u_6.GAIN_MIN) * p43 / 0.5
	end
	local v44 = (p43 - 0.5) / (v_u_6.FULL_AT - 0.5)
	local v45 = math.min(v44, 1)
	return 1 + (v_u_6.GAIN_MAX - 1) * v45 * v45
end
function v_u_6.qualityFor(p46) -- name: qualityFor
	-- upvalues: (copy) v_u_6
	if p46 <= 1 then
		local v47 = (p46 - v_u_6.GAIN_MIN) / (1 - v_u_6.GAIN_MIN)
		return math.clamp(v47, 0, 1) * 0.5
	end
	local v48 = (p46 - 1) / (v_u_6.GAIN_MAX - 1)
	local v49 = math.clamp(v48, 0, 1)
	return 0.5 + math.sqrt(v49) * (v_u_6.FULL_AT - 0.5)
end
v_u_6.SOUND_SETTINGS = {
	["Idle"] = {
		["attribute"] = "EcuIdleSpeed",
		["min"] = 0.7,
		["max"] = 1.6,
		["step"] = 0.05
	},
	["Rev"] = {
		["attribute"] = "EcuRevSpeed",
		["min"] = 0.5,
		["max"] = 2,
		["step"] = 0.05
	}
}
function v_u_6.snapSetting(p50, p51) -- name: snapSetting
	-- upvalues: (copy) v_u_6
	local v52 = v_u_6.SOUND_SETTINGS[p50]
	local v53 = p51 / v52.step
	local v54 = math.round(v53) * v52.step
	local v55 = v52.min
	local v56 = v52.max
	local v57 = math.clamp(v54, v55, v56)
	return tonumber(("%.2f"):format(v57))
end
function v_u_6.soundSetting(p58, p59) -- name: soundSetting
	-- upvalues: (copy) v_u_6
	local v60 = v_u_6.SOUND_SETTINGS[p59]
	local v61 = p58:GetAttribute(v60.attribute)
	if typeof(v61) ~= "number" or v61 ~= v61 then
		return 1
	end
	local v62 = v60.min
	local v63 = v60.max
	return math.clamp(v61, v62, v63)
end
function v_u_6.idleSpeed(p64) -- name: idleSpeed
	-- upvalues: (copy) v_u_6
	return v_u_6.soundSetting(p64, "Idle")
end
v_u_6.GOOD = 0.87
v_u_6.NEAR = 0.45
function v_u_6.gain(p65) -- name: gain
	-- upvalues: (copy) v_u_6
	local v66 = p65:GetAttribute("EcuGain")
	if typeof(v66) ~= "number" then
		return 1
	end
	local v67 = v_u_6.GAIN_MIN
	local v68 = v_u_6.GAIN_MAX
	return math.clamp(v66, v67, v68)
end
return v_u_6