-- Path: ReplicatedStorage/GameUI/UiCheckView
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = require(game:GetService("ReplicatedStorage"):WaitForChild("NetSeal"))
local v_u_2 = game:GetService("Players")
local v_u_3 = game:GetService("ReplicatedStorage")
local v_u_4 = require(v_u_3:WaitForChild("GameShared"))
local v_u_5 = require(v_u_3:WaitForChild("UiGuardShared"))
local v_u_6 = require(script.Parent:WaitForChild("Theme"))
local v_u_7 = require(script.Parent:WaitForChild("Toast"))
local v_u_8 = Color3.fromRGB(255, 70, 70)
local v_u_9 = {}
local v_u_10 = nil
local v_u_11 = nil
local function v_u_49() -- name: build
	-- upvalues: (copy) v_u_2, (copy) v_u_6, (copy) v_u_8, (ref) v_u_11, (copy) v_u_7, (copy) v_u_3, (copy) v_u_4, (copy) v_u_1, (ref) v_u_10, (copy) v_u_9
	local v12 = v_u_2.LocalPlayer
	local v13 = v_u_6.screen("UiCheckView", 70, v12:WaitForChild("PlayerGui"))
	local v14 = v_u_6.window({
		["name"] = "UiCheckWindow",
		["gui"] = nil,
		["icon"] = "shield",
		["grad"] = "purple",
		["title"] = "Check UI",
		["sub"] = "",
		["max"] = nil,
		["keepOpen"] = true,
		["gui"] = v13,
		["max"] = Vector2.new(1180, 760)
	})
	local v15 = v14.body
	local v16 = v_u_6.new("Frame", {
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Parent"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 40),
		["Parent"] = v15
	})
	local v17 = v_u_6.text({
		["Text"] = "",
		["TextSize"] = 15,
		["TextXAlignment"] = nil,
		["TextTruncate"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["TextTruncate"] = Enum.TextTruncate.AtEnd,
		["Size"] = UDim2.new(1, -406, 1, 0),
		["Parent"] = v16
	})
	local v18 = v_u_6.button({
		["text"] = "Refresh",
		["icon"] = "zap",
		["grad"] = "dark",
		["textSize"] = 15,
		["anchor"] = nil,
		["position"] = nil,
		["size"] = nil,
		["parent"] = nil,
		["anchor"] = Vector2.new(1, 0),
		["position"] = UDim2.new(1, -136, 0, 0),
		["size"] = UDim2.new(0, 128, 1, 0),
		["parent"] = v16
	})
	local v19 = v_u_6.button({
		["text"] = "Flagged",
		["icon"] = "shield",
		["grad"] = "red",
		["textSize"] = 15,
		["anchor"] = nil,
		["position"] = nil,
		["size"] = nil,
		["parent"] = nil,
		["anchor"] = Vector2.new(1, 0),
		["position"] = UDim2.fromScale(1, 0),
		["size"] = UDim2.new(0, 128, 1, 0),
		["parent"] = v16
	})
	local v20 = v_u_6.button({
		["text"] = "Ban",
		["icon"] = "lock",
		["grad"] = "red",
		["textSize"] = 15,
		["anchor"] = nil,
		["position"] = nil,
		["size"] = nil,
		["parent"] = nil,
		["anchor"] = Vector2.new(1, 0),
		["position"] = UDim2.new(1, -272, 0, 0),
		["size"] = UDim2.new(0, 128, 1, 0),
		["parent"] = v16
	})
	local v_u_21 = v_u_6.panel({
		["Name"] = "BanBox",
		["Visible"] = false,
		["Active"] = true,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 20,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.5),
		["Size"] = UDim2.fromOffset(480, 268),
		["Parent"] = v14.panel
	})
	v_u_6.padding(v_u_21, 16)
	v_u_21.BackgroundTransparency = 0
	local v_u_22 = v_u_6.text({
		["Text"] = "\224\185\129\224\184\154\224\184\153\224\184\150\224\184\178\224\184\167\224\184\163",
		["TextSize"] = 20,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["TextTruncate"] = nil,
		["Size"] = nil,
		["ZIndex"] = 21,
		["Parent"] = nil,
		["TextColor3"] = v_u_8,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["TextTruncate"] = Enum.TextTruncate.AtEnd,
		["Size"] = UDim2.new(1, 0, 0, 28),
		["Parent"] = v_u_21
	})
	local v23 = v_u_6.text({
		["Text"] = "\224\184\151\224\184\177\224\185\137\224\184\135\224\185\128\224\184\129\224\184\161 \224\184\151\224\184\184\224\184\129\224\185\128\224\184\139\224\184\180\224\184\163\224\185\140\224\184\159 \224\184\163\224\184\167\224\184\161\224\185\132\224\184\173\224\184\148\224\184\181\224\184\170\224\184\179\224\184\163\224\184\173\224\184\135\224\184\151\224\184\181\224\185\136 Roblox \224\184\136\224\184\177\224\184\154\224\185\132\224\184\148\224\185\137\224\184\167\224\185\136\224\184\178\224\185\128\224\184\155\224\185\135\224\184\153\224\184\132\224\184\153\224\185\128\224\184\148\224\184\181\224\184\162\224\184\167\224\184\129\224\184\177\224\184\153 \194\183 \224\184\155\224\184\165\224\184\148\224\185\132\224\184\148\224\185\137\224\184\151\224\184\181\224\185\136 Admin \226\134\146 Unban\n\224\184\130\224\185\137\224\184\173\224\184\132\224\184\167\224\184\178\224\184\161\224\184\151\224\184\181\224\185\136\224\184\132\224\184\153\224\185\130\224\184\148\224\184\153\224\185\129\224\184\154\224\184\153\224\184\136\224\184\176\224\185\128\224\184\171\224\185\135\224\184\153:",
		["TextSize"] = 14,
		["TextColor3"] = nil,
		["TextWrapped"] = true,
		["TextXAlignment"] = nil,
		["TextYAlignment"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 21,
		["Parent"] = nil,
		["TextColor3"] = v_u_6.TEXT_DIM,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["TextYAlignment"] = Enum.TextYAlignment.Top,
		["Position"] = UDim2.fromOffset(0, 32),
		["Size"] = UDim2.new(1, 0, 0, 40),
		["Parent"] = v_u_21
	})
	local v_u_24 = v_u_6.new("TextBox", {
		["Name"] = "Reason",
		["Text"] = "\224\184\149\224\184\163\224\184\167\224\184\136\224\184\158\224\184\154\224\185\130\224\184\155\224\184\163: \224\185\129\224\184\154\224\184\153\224\184\150\224\184\178\224\184\167\224\184\163",
		["PlaceholderText"] = "\224\184\158\224\184\180\224\184\161\224\184\158\224\185\140\224\184\130\224\185\137\224\184\173\224\184\132\224\184\167\224\184\178\224\184\161\224\184\151\224\184\181\224\185\136\224\184\136\224\184\176\224\185\131\224\184\171\224\185\137\224\184\130\224\184\182\224\185\137\224\184\153",
		["ClearTextOnFocus"] = false,
		["MultiLine"] = true,
		["TextWrapped"] = true,
		["TextSize"] = 16,
		["TextColor3"] = nil,
		["PlaceholderColor3"] = nil,
		["FontFace"] = nil,
		["TextXAlignment"] = nil,
		["TextYAlignment"] = nil,
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 21,
		["Parent"] = nil,
		["TextColor3"] = v_u_6.TEXT,
		["PlaceholderColor3"] = v_u_6.TEXT_DIM,
		["FontFace"] = v23.FontFace,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["TextYAlignment"] = Enum.TextYAlignment.Top,
		["BackgroundColor3"] = Color3.fromRGB(14, 16, 24),
		["Position"] = UDim2.fromOffset(0, 78),
		["Size"] = UDim2.new(1, 0, 0, 86),
		["Parent"] = v_u_21
	})
	v_u_6.corner(v_u_24, 10)
	v_u_6.padding(v_u_24, 10, 8)
	local v25 = v_u_6.button({
		["text"] = "\224\185\129\224\184\154\224\184\153\224\184\150\224\184\178\224\184\167\224\184\163",
		["icon"] = "lock",
		["grad"] = "red",
		["textSize"] = 16,
		["anchor"] = nil,
		["position"] = nil,
		["size"] = nil,
		["parent"] = nil,
		["anchor"] = Vector2.new(1, 1),
		["position"] = UDim2.fromScale(1, 1),
		["size"] = UDim2.new(0.5, -6, 0, 44),
		["parent"] = v_u_21
	})
	local v26 = v_u_6.button({
		["text"] = "\224\184\162\224\184\129\224\185\128\224\184\165\224\184\180\224\184\129",
		["grad"] = "dark",
		["textSize"] = 16,
		["anchor"] = nil,
		["position"] = nil,
		["size"] = nil,
		["parent"] = nil,
		["anchor"] = Vector2.new(0, 1),
		["position"] = UDim2.fromScale(0, 1),
		["size"] = UDim2.new(0.5, -6, 0, 44),
		["parent"] = v_u_21
	})
	for _, v27 in { v25, v26 } do
		v27.ZIndex = 21
		for _, v28 in v27:GetDescendants() do
			if not v28:IsA("GuiObject") then
				continue
			end
			v28.ZIndex = 22
		end
	end
	local v_u_29 = false
	v20.Activated:Connect(function()
		-- upvalues: (ref) v_u_11, (ref) v_u_7, (copy) v_u_22, (copy) v_u_21
		if v_u_11 then
			local v30 = v_u_22
			local v31 = v_u_11.name
			v30.Text = ("\224\185\129\224\184\154\224\184\153\224\184\150\224\184\178\224\184\167\224\184\163 \194\183 %s"):format((tostring(v31)))
			v_u_21.Visible = true
		else
			v_u_7.show("\224\185\128\224\184\155\224\184\180\224\184\148\224\184\148\224\184\185\224\184\136\224\184\173\224\184\130\224\184\173\224\184\135\224\184\132\224\184\153\224\184\151\224\184\181\224\185\136\224\184\136\224\184\176\224\185\129\224\184\154\224\184\153\224\184\129\224\185\136\224\184\173\224\184\153", "error")
		end
	end)
	v26.Activated:Connect(function()
		-- upvalues: (copy) v_u_21
		v_u_21.Visible = false
	end)
	v25.Activated:Connect(function()
		-- upvalues: (ref) v_u_11, (ref) v_u_29, (ref) v_u_3, (ref) v_u_4, (ref) v_u_1, (copy) v_u_24, (ref) v_u_7, (copy) v_u_21, (ref) v_u_10, (ref) v_u_8
		if v_u_11 and not v_u_29 then
			v_u_29 = true
			local v32 = v_u_11
			local v33 = v_u_3:WaitForChild(v_u_4.REMOTES):WaitForChild("Admin")
			local v34 = v_u_1.invoke
			local v35 = v32.id
			local v36 = v_u_24.Text
			local v37, v38, v39 = pcall(v34, v33, "Ban", v35, 0, v36)
			v_u_29 = false
			local v40 = not v37 and "Ban failed" or tostring(v39)
			local v41 = v_u_7.show
			local v42 = v32.name
			v41(("%s: %s"):format(tostring(v42), v40), v37 and v38 and "info" or "error")
			if v37 and v38 then
				v_u_21.Visible = false
				local v43 = v_u_10.status
				local v44 = v32.name
				v43.Text = ("\240\159\148\168 %s: %s"):format(tostring(v44), v40)
				v_u_10.status.TextColor3 = v_u_8
			end
		end
	end)
	local v45 = v_u_6.new("Frame", {
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Position"] = UDim2.fromOffset(0, 50),
		["Size"] = UDim2.new(0.66, -8, 1, -50),
		["Parent"] = v15
	})
	local v46 = v_u_6.new("Frame", {
		["Name"] = "Screen",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["ClipsDescendants"] = true,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = Color3.fromRGB(40, 46, 58),
		["AnchorPoint"] = Vector2.new(0.5, 0),
		["Position"] = UDim2.fromScale(0.5, 0),
		["Size"] = UDim2.fromScale(1, 1),
		["Parent"] = v45
	})
	v_u_6.border(v46, Color3.new(1, 1, 1), 0.7, 1)
	local v47 = v_u_6.new("UIAspectRatioConstraint", {
		["AspectRatio"] = 1.7777777777777777,
		["Parent"] = nil,
		["Parent"] = v46
	})
	local v48 = v_u_6.new("ScrollingFrame", {
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["CanvasSize"] = nil,
		["AutomaticCanvasSize"] = nil,
		["ScrollBarThickness"] = 5,
		["Parent"] = nil,
		["Position"] = UDim2.new(0.66, 8, 0, 50),
		["Size"] = UDim2.new(0.34, -8, 1, -50),
		["CanvasSize"] = UDim2.new(),
		["AutomaticCanvasSize"] = Enum.AutomaticSize.Y,
		["Parent"] = v15
	})
	v_u_6.new("UIListLayout", {
		["Padding"] = UDim.new(0, 4),
		["SortOrder"] = Enum.SortOrder.LayoutOrder,
		["Parent"] = v48
	})
	v_u_10 = {
		["gui"] = v13,
		["window"] = v14,
		["status"] = v17,
		["screen"] = v46,
		["aspect"] = v47,
		["side"] = v48,
		["banBox"] = v_u_21
	}
	v18.Activated:Connect(function()
		-- upvalues: (ref) v_u_11, (ref) v_u_9
		if v_u_11 then
			v_u_9.open(v_u_11.id, v_u_11.name)
		end
	end)
	v19.Activated:Connect(function()
		-- upvalues: (ref) v_u_9
		v_u_9.flagged()
	end)
end
local function v_u_52(p50) -- name: clear
	for _, v51 in p50:GetChildren() do
		if not v51:IsA("GuiObject") then
			continue
		end
		v51:Destroy()
	end
end
local function v_u_57(p53, p54, p55, p56) -- name: line
	-- upvalues: (copy) v_u_6, (ref) v_u_10
	return v_u_6.text({
		["Text"] = nil,
		["TextSize"] = nil,
		["TextColor3"] = nil,
		["TextWrapped"] = true,
		["TextXAlignment"] = nil,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = nil,
		["Parent"] = nil,
		["Text"] = p53,
		["TextSize"] = p56 or 14,
		["TextColor3"] = p54 or v_u_6.TEXT,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["Size"] = UDim2.new(1, -6, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y,
		["LayoutOrder"] = p55,
		["Parent"] = v_u_10.side
	})
end
local function v_u_72(p58, p59) -- name: flagLines
	-- upvalues: (copy) v_u_57, (copy) v_u_8, (copy) v_u_6
	if p58.silent then
		p59 = p59 + 1
		v_u_57("\226\154\160\239\184\143 The check stopped answering on their machine while they kept playing (stopped by an exploit?)", v_u_8, p59)
	end
	for v60 = #p58.flags, 1, -1 do
		local v61 = p58.flags[v60]
		local v62 = p59 + 1
		local v63 = v_u_57
		local v64 = "%s  %s%s"
		local v65 = os.date("%H:%M", v61.at)
		local v66 = v61.name
		local v67
		if v61.exploit then
			local v68 = v61.word
			v67 = "  \194\183 exploit (" .. tostring(v68) .. "): banned"
		else
			v67 = v61.soft and "  \194\183 hidden behind or inside the game\'s UI: not kicked, your call" or (not v61.word and "  \194\183 risky" or "  \194\183 risky (" .. v61.word .. ")")
		end
		local v69 = v64:format(v65, v66, v67)
		local v70
		if v61.exploit then
			v70 = v_u_8
		elseif v61.word then
			v70 = Color3.fromRGB(255, 160, 60)
		else
			v70 = v_u_6.YELLOW
		end
		v63(v69, v70, v62)
		p59 = v62 + 1
		v_u_57(("   %d parts, %d buttons \194\183 %s"):format(v61.parts, v61.buttons, table.concat(v61.texts, " / ")), v_u_6.TEXT_DIM, p59, 13)
		local v71 = v61.strike
		if type(v71) ~= "string" then
			continue
		end
		p59 = p59 + 1
		v_u_57("   \240\159\148\168 " .. v61.strike, v_u_8, p59, 13)
	end
	return p59
end
local function v_u_110(p73) -- name: drawScreen
	-- upvalues: (copy) v_u_52, (ref) v_u_10, (copy) v_u_6, (copy) v_u_8
	v_u_52(v_u_10.screen)
	local v74 = v_u_10.aspect
	local v75 = p73.w
	local v76 = math.max(v75, 1)
	local v77 = p73.h
	v74.AspectRatio = v76 / math.max(v77, 1)
	for _, v78 in p73.boxes do
		local v79, v80 = v78:match("^([%d%.,%-]+)|(.*)$")
		local v81, v82, v83, v84, v85, v86, v87, v88 = (v79 or ""):match("^(%-?%d+),(%-?%d+),(%d+),(%d+),(%d+),([%d%.]+),(%d),(%d+)$")
		if not v81 then
			continue
		end
		local v89 = tonumber(v81)
		local v90 = tonumber(v82)
		local v91 = tonumber(v83)
		local v92 = tonumber(v84)
		local v93 = tonumber(v85)
		local v94 = tonumber(v86)
		local v95 = tonumber(v87)
		local v96 = tonumber(v88)
		local v97 = p73.guis[v96]
		if v97 then
			v97 = not v97.known
		end
		local v98 = v_u_6.new
		local v99 = {
			["BorderSizePixel"] = 0,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = nil,
			["Parent"] = nil
		}
		local v100 = Color3.fromRGB
		local v101 = v93 / 65536
		local v102 = math.floor(v101) % 256
		local v103 = v93 / 256
		v99.BackgroundColor3 = v100(v102, math.floor(v103) % 256, v93 % 256)
		local v104 = math.max(v94, v97 and 0.2 or 0.45)
		v99.BackgroundTransparency = math.clamp(v104, 0, 0.95)
		v99.Position = UDim2.fromScale(v89 / p73.w, v90 / p73.h)
		v99.Size = UDim2.fromScale(v91 / p73.w, v92 / p73.h)
		v99.ZIndex = v97 and 3 or 2
		v99.Parent = v_u_10.screen
		local v105 = v98("Frame", v99)
		if v97 then
			local v106 = {
				["Color"] = nil,
				["Thickness"] = 1.5,
				["Parent"] = nil,
				["Color"] = v_u_8,
				["Parent"] = v105
			}
			v_u_6.new("UIStroke", v106)
		elseif v95 == 4 then
			v_u_6.new("UIStroke", {
				["Color"] = nil,
				["Transparency"] = 0.7,
				["Thickness"] = 1,
				["Parent"] = nil,
				["Color"] = Color3.new(1, 1, 1),
				["Parent"] = v105
			})
		end
		if not v80 or v80 == "" then
			continue
		end
		local v107 = v_u_6.text
		local v108 = {
			["Text"] = nil,
			["TextScaled"] = true,
			["TextColor3"] = nil,
			["Size"] = nil,
			["ZIndex"] = 4,
			["Parent"] = nil,
			["Text"] = v80
		}
		local v109
		if v97 then
			v109 = Color3.new(1, 1, 1)
		else
			v109 = v_u_6.TEXT_DIM
		end
		v108.TextColor3 = v109
		v108.Size = UDim2.fromScale(1, 1)
		v108.Parent = v105
		v107(v108)
	end
end
function v_u_9.open(p111, p112) -- name: open
	-- upvalues: (ref) v_u_10, (copy) v_u_49, (ref) v_u_11, (copy) v_u_2, (copy) v_u_6, (copy) v_u_52, (copy) v_u_1, (copy) v_u_3, (copy) v_u_4, (copy) v_u_5, (copy) v_u_7, (copy) v_u_8, (copy) v_u_110, (copy) v_u_57, (copy) v_u_72
	if not v_u_10 then
		v_u_49()
	end
	v_u_11 = {
		["id"] = p111,
		["name"] = p112
	}
	v_u_10.banBox.Visible = false
	v_u_10.window.setOpen(true)
	v_u_10.window.title.Text = "Check UI \194\183 " .. tostring(p112)
	v_u_10.window.sub.Text = "What their game sees on their screen (an executor\'s own window can\'t be seen)"
	v_u_10.status.Text = v_u_2:GetPlayerByUserId(p111) and "Asking their game\226\128\166" or "Finding their server and asking their game\226\128\166 (up to ~15 s)"
	v_u_10.status.TextColor3 = v_u_6.TEXT
	v_u_52(v_u_10.side)
	v_u_52(v_u_10.screen)
	local v113 = v_u_1.invoke
	local v114 = v_u_3:WaitForChild(v_u_4.REMOTES):WaitForChild(v_u_5.CHECK_REMOTE)
	local v115, v116, v117 = pcall(v113, v114, "Snap", p111)
	if v115 and (v116 and type(v117) == "table") then
		local v118 = 0
		if v117.noAnswer then
			v_u_10.status.Text = "\226\154\160\239\184\143 Their game didn\'t answer (the check is stopped on their machine, or they\'re loading)"
			v_u_10.status.TextColor3 = v_u_8
		else
			local v119 = 0
			for _, v120 in v117.screen.guis do
				if v120.known then
					continue
				end
				v119 = v119 + 1
			end
			v_u_10.status.Text = ("%s%s \194\183 %d UIs on screen%s \194\183 heartbeat %s"):format(v117.name, v117.remote and " (other server)" or "", #v117.screen.guis, v119 <= 0 and ", all the game\'s" or (", %d not the game\'s"):format(v119), v117.beatAgo < 0 and "none yet" or v117.beatAgo .. " s ago")
			local v121 = v_u_10.status
			local v122
			if v119 > 0 or v117.silent then
				v122 = v_u_8
			else
				v122 = v_u_6.GREEN_TEXT
			end
			v121.TextColor3 = v122
			v_u_110(v117.screen)
			v118 = v118 + 1
			v_u_57("UIs on their screen", v_u_6.TEXT, v118, 16)
			for _, v123 in v117.screen.guis do
				v118 = v118 + 1
				local v124 = v_u_57
				local v125 = ("%s %s  \194\183 %d boxes%s"):format(v123.known and "\226\156\147" or "\226\154\160\239\184\143", v123.name, v123.shown, v123.enabled and "" or " (hidden)")
				local v126
				if v123.known then
					v126 = v_u_6.TEXT_DIM
				else
					v126 = v_u_8
				end
				v124(v125, v126, v118)
			end
		end
		local v127 = v118 + 1
		v_u_57("Found before", v_u_6.TEXT, v127, 16)
		local v128 = v_u_72(v117, v127)
		if #v117.flags == 0 and not v117.silent then
			local v129 = v128 + 1
			v_u_57("Nothing", v_u_6.TEXT_DIM, v129)
		end
	else
		v_u_10.status.Text = (not v115 or (type(v117) ~= "string" or not v117)) and "Couldn\'t check" or v117
		v_u_7.show(v_u_10.status.Text, "error")
	end
end
function v_u_9.flagged() -- name: flagged
	-- upvalues: (ref) v_u_10, (copy) v_u_49, (copy) v_u_6, (copy) v_u_52, (copy) v_u_1, (copy) v_u_3, (copy) v_u_4, (copy) v_u_5, (copy) v_u_8, (copy) v_u_9, (copy) v_u_72
	if not v_u_10 then
		v_u_49()
	end
	v_u_10.window.setOpen(true)
	v_u_10.window.title.Text = "Check UI \194\183 flagged in every server"
	v_u_10.window.sub.Text = "Players whose screen showed a UI that isn\'t the game\'s, or whose check stopped"
	v_u_10.status.Text = "Loading\226\128\166"
	v_u_10.status.TextColor3 = v_u_6.TEXT
	v_u_52(v_u_10.side)
	v_u_52(v_u_10.screen)
	local v130 = v_u_1.invoke
	local v131 = v_u_3:WaitForChild(v_u_4.REMOTES):WaitForChild(v_u_5.CHECK_REMOTE)
	local v132, v133, v134 = pcall(v130, v131, "Flags")
	if v132 and (v133 and type(v134) == "table") then
		v_u_10.status.Text = #v134 == 0 and "Nobody flagged in any server" or ("%d flagged in every server (last 30 min)"):format(#v134)
		local v135 = 0
		for _, v_u_136 in v134 do
			local v137 = v135 + 1
			local v138 = v_u_6.new("Frame", {
				["BackgroundColor3"] = v_u_6.CARD_DARK,
				["Size"] = UDim2.new(1, -6, 0, 40),
				["LayoutOrder"] = v137,
				["Parent"] = v_u_10.side
			})
			v_u_6.corner(v138, 10)
			local v139 = nil
			for _, v140 in v_u_136.flags do
				local v141 = v140.strike
				if type(v141) ~= "string" then
					continue
				end
				v139 = v140.strike
			end
			local v142 = v_u_6.text
			local v143 = {
				["Text"] = nil,
				["TextSize"] = 15,
				["TextColor3"] = nil,
				["TextXAlignment"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil
			}
			local v144 = v_u_136.name
			local v145
			if v139 then
				v145 = "  \240\159\148\168 " .. v139
			else
				v145 = v_u_136.suspect and "  \226\154\160\239\184\143 exploit words" or (v_u_136.silent and "  \226\154\160\239\184\143 check stopped" or "")
			end
			v143.Text = v144 .. v145 .. (v_u_136.remote and "  \194\183 other server" or "")
			local v146
			if v_u_136.suspect or v_u_136.silent then
				v146 = v_u_8
			else
				v146 = v_u_6.YELLOW
			end
			v143.TextColor3 = v146
			v143.TextXAlignment = Enum.TextXAlignment.Left
			v143.Position = UDim2.fromOffset(10, 0)
			v143.Size = UDim2.new(1, -110, 1, 0)
			v143.Parent = v138
			v142(v143)
			v_u_6.button({
				["text"] = "Check",
				["grad"] = "purple",
				["textSize"] = 14,
				["anchor"] = nil,
				["position"] = nil,
				["size"] = nil,
				["parent"] = nil,
				["anchor"] = Vector2.new(1, 0.5),
				["position"] = UDim2.new(1, -6, 0.5, 0),
				["size"] = UDim2.fromOffset(90, 30),
				["parent"] = v138
			}).Activated:Connect(function()
				-- upvalues: (ref) v_u_9, (copy) v_u_136
				v_u_9.open(v_u_136.id, v_u_136.name)
			end)
			v135 = v_u_72(v_u_136, v137)
		end
	else
		v_u_10.status.Text = (not v132 or (type(v134) ~= "string" or not v134)) and "Couldn\'t load" or v134
	end
end
return v_u_9