-- Path: ReplicatedStorage/GameUI/EcuEditors
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = require(game:GetService("ReplicatedStorage"):WaitForChild("UiOwn")).Instance
local v_u_2 = game:GetService("RunService")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = require(v3:WaitForChild("EcuShared"))
local v_u_5 = {}
local v_u_6 = Color3.new(1, 1, 1)
local v_u_7 = Color3.fromRGB(16, 18, 24)
local v_u_8 = Color3.fromRGB(30, 32, 42)
local v_u_9 = Color3.fromRGB(255, 196, 46)
local v_u_10 = Color3.fromRGB(248, 230, 44)
local v_u_11 = Color3.fromRGB(243, 191, 51)
local v_u_12 = Color3.fromRGB(158, 164, 182)
local v_u_13 = Color3.fromRGB(92, 228, 132)
local v_u_14 = Color3.fromRGB(88, 168, 255)
local v_u_15 = Color3.fromRGB(255, 50, 50)
local v_u_16 = Color3.fromRGB(255, 176, 40)
local v_u_17 = v_u_4.POINTS
local v_u_18 = { "\224\184\163\224\184\173\224\184\154\224\184\149\224\185\136\224\184\179", "\224\184\163\224\184\173\224\184\154\224\184\129\224\184\165\224\184\178\224\184\135", "\224\184\163\224\184\173\224\184\154\224\184\170\224\184\185\224\184\135" }
local function v_u_26(p19, p20) -- name: corner
	-- upvalues: (copy) v_u_1
	local v21 = {}
	local v22
	if p20 == "round" then
		v22 = UDim.new(1, 0)
	else
		v22 = UDim.new(0, p20)
	end
	v21.CornerRadius = v22
	local v23 = v_u_1.new("UICorner")
	for v24, v25 in v21 do
		v23[v24] = v25
	end
	v23.Parent = p19
end
local function v_u_39(p27, p28, p29, p30, p31, p32, p33) -- name: showMatch
	-- upvalues: (copy) v_u_6, (copy) v_u_12, (copy) v_u_13, (copy) v_u_16, (copy) v_u_15
	local v34 = type(p29) == "number"
	local v35
	if v34 then
		local v36 = p29 * 1000 + 0.5
		v35 = ("%.1f %%"):format(math.floor(v36) / 10)
	else
		v35 = "\224\185\129\224\184\159\224\184\165\224\184\138\224\185\128\224\184\158\224\184\183\224\185\136\224\184\173\224\184\167\224\184\177\224\184\148"
	end
	p27.Text = v35
	local v37
	if v34 then
		v37 = v_u_6
	else
		v37 = v_u_12
	end
	p27.TextColor3 = v37
	if v34 then
		p33 = p32
	end
	p27.FontFace = p33
	if v34 then
		p31 = p30
	end
	p27.TextSize = p31
	p28.Size = UDim2.fromScale(not v34 and 0 or p29, 1)
	local v38
	if v34 and p29 < 0.87 then
		if p29 >= 0.45 then
			v38 = v_u_16
		else
			v38 = v_u_15
		end
	else
		v38 = v_u_13
	end
	p28.BackgroundColor3 = v38
end
local function v_u_150(p_u_40, p_u_41) -- name: base
	-- upvalues: (copy) v_u_6, (copy) v_u_1, (copy) v_u_8, (copy) v_u_26
	local v_u_42 = {
		["frame"] = p_u_40,
		["ctx"] = p_u_41,
		["conns"] = {},
		["W"] = p_u_41.size.X,
		["H"] = p_u_41.size.Y
	}
	local v43 = p_u_41.style
	local v44 = v43.NUM
	local v45 = v43.NUM_HEAVY
	local v46 = v43.THAI
	v_u_42.NUM = v44
	v_u_42.HEAVY = v45
	v_u_42.THAI = v46
	function v_u_42.at(p47, p48) -- name: at
		-- upvalues: (copy) v_u_42
		return UDim2.fromScale(p47 / v_u_42.W, p48 / v_u_42.H)
	end
	function v_u_42.box(p49, p50, p51, p52) -- name: box
		-- upvalues: (copy) v_u_42
		return UDim2.fromScale(p49 / v_u_42.W, p50 / v_u_42.H), UDim2.fromScale(p51 / v_u_42.W, p52 / v_u_42.H)
	end
	function v_u_42.text(p53, p54, p55, p56, p57, p58) -- name: text
		-- upvalues: (ref) v_u_6, (ref) v_u_1
		local v59 = {
			["BackgroundTransparency"] = 1,
			["FontFace"] = nil,
			["Text"] = nil,
			["TextSize"] = nil,
			["TextColor3"] = nil,
			["TextXAlignment"] = nil,
			["FontFace"] = p55,
			["Text"] = p54,
			["TextSize"] = p56,
			["TextColor3"] = p57 or v_u_6,
			["TextXAlignment"] = Enum.TextXAlignment.Center
		}
		local v60 = v_u_1.new("TextLabel")
		for v61, v62 in v59 do
			v60[v61] = v62
		end
		v60.Parent = p53
		for v63, v64 in p58 or {} do
			v60[v63] = v64
		end
		return v60
	end
	function v_u_42.label(p65, p66, p67, p68, p69, p70, p71, p72) -- name: label
		-- upvalues: (copy) v_u_42, (copy) p_u_40
		local v73 = v_u_42.text(p_u_40, p65, p66, p67, p68, p72)
		v73.AnchorPoint = Vector2.new(0.5, 0.5)
		v73.Position = v_u_42.at(p69, p70)
		v73.Size = UDim2.fromOffset(p71 or 120, p67 + 6)
		return v73
	end
	function v_u_42.card(p74, p75, p76, p77, p78) -- name: card
		-- upvalues: (copy) v_u_42, (ref) v_u_8, (copy) p_u_40, (ref) v_u_1, (ref) v_u_26, (ref) v_u_6
		local v79, v80 = v_u_42.box(p74, p75, p76, p77)
		local v81 = {
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.12,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = p78 or v_u_8,
			["Position"] = v79,
			["Size"] = v80
		}
		local v82 = p_u_40
		local v83 = v_u_1.new("Frame")
		for v84, v85 in v81 do
			v83[v84] = v85
		end
		v83.Parent = v82
		v_u_26(v83, 10)
		local v86 = {
			["Color"] = nil,
			["Transparency"] = 0.6,
			["Thickness"] = 2,
			["Color"] = v_u_6
		}
		local v87 = v_u_1.new("UIStroke")
		for v88, v89 in v86 do
			v87[v88] = v89
		end
		v87.Parent = v83
		return v83
	end
	function v_u_42.press(p90, p91, p92, p93, p_u_94, p95, p_u_96) -- name: press
		-- upvalues: (copy) v_u_42, (copy) p_u_40, (ref) v_u_1, (copy) p_u_41
		local v97, v98 = v_u_42.box(p90, p91, p92, p93)
		local v99 = p_u_40
		local v100 = v_u_1.new("TextButton")
		for v101, v102 in {
			["Text"] = "",
			["AutoButtonColor"] = false,
			["BackgroundTransparency"] = 1,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = nil,
			["Position"] = v97,
			["Size"] = v98,
			["ZIndex"] = p95 or 6
		} do
			v100[v101] = v102
		end
		v100.Parent = v99
		v100.InputBegan:Connect(function(p103)
			-- upvalues: (copy) p_u_96, (ref) p_u_41, (copy) p_u_94
			if (p103.UserInputType == Enum.UserInputType.MouseButton1 and true or p103.UserInputType == Enum.UserInputType.Touch) and (p_u_96 or not p_u_41.veiled()) then
				p_u_94(p103)
			end
		end)
		return v100
	end
	function v_u_42.circle(p104, p105, p106, p107, p108) -- name: circle
		-- upvalues: (copy) v_u_42, (copy) p_u_40, (ref) v_u_1, (ref) v_u_26
		local v109 = {
			["BackgroundColor3"] = p107,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = v_u_42.at(p104, p105),
			["Size"] = UDim2.fromOffset(p106, p106),
			["ZIndex"] = p108 or 2
		}
		local v110 = p_u_40
		local v111 = v_u_1.new("Frame")
		for v112, v113 in v109 do
			v111[v112] = v113
		end
		v111.Parent = v110
		v_u_26(v111, "round")
		return v111
	end
	function v_u_42.needle(p114, p115, p116, p117, p118, p119) -- name: needle
		-- upvalues: (copy) v_u_42, (copy) p_u_40, (ref) v_u_1, (ref) v_u_26
		local v120 = {
			["BackgroundTransparency"] = 1,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = v_u_42.at(p114, p115),
			["Size"] = UDim2.fromOffset(p117, p116 * 2),
			["ZIndex"] = p119 or 3
		}
		local v121 = p_u_40
		local v122 = v_u_1.new("Frame")
		for v123, v124 in v120 do
			v122[v123] = v124
		end
		v122.Parent = v121
		local v125 = {
			["BorderSizePixel"] = 0,
			["BackgroundColor3"] = nil,
			["Size"] = nil,
			["ZIndex"] = nil,
			["BackgroundColor3"] = p118,
			["Size"] = UDim2.new(1, 0, 0.5, 0),
			["ZIndex"] = p119 or 3
		}
		local v126 = v_u_1.new("Frame")
		for v127, v128 in v125 do
			v126[v127] = v128
		end
		v126.Parent = v122
		v_u_26(v126, "round")
		return v122
	end
	function v_u_42.tick(p129, p130, p131, p132, p133, p134, p135, p136) -- name: tick
		-- upvalues: (copy) v_u_42, (copy) p_u_40, (ref) v_u_1
		local v137 = math.rad(p133)
		local v138 = (p131 + p132) / 2
		local v139 = {
			["BorderSizePixel"] = 0,
			["BackgroundColor3"] = nil,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Rotation"] = nil,
			["ZIndex"] = nil,
			["BackgroundColor3"] = p135,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = v_u_42.at(p129 + v138 * math.sin(v137), p130 - v138 * math.cos(v137)),
			["Size"] = UDim2.fromOffset(p134, p132 - p131),
			["Rotation"] = p133,
			["ZIndex"] = p136 or 2
		}
		local v140 = p_u_40
		local v141 = v_u_1.new("Frame")
		for v142, v143 in v139 do
			v141[v142] = v143
		end
		v141.Parent = v140
		return v141
	end
	function v_u_42.polar(p144, p145, p146, p147) -- name: polar
		local v148 = math.rad(p147)
		return p144 + p146 * math.sin(v148), p145 - p146 * math.cos(v148)
	end
	function v_u_42.destroy() -- name: destroy
		-- upvalues: (copy) v_u_42
		for _, v149 in v_u_42.conns do
			v149:Disconnect()
		end
	end
	return v_u_42
end
local function v_u_202(p151, p_u_152, p153, p154, p155, p156) -- name: chipsRow
	-- upvalues: (copy) v_u_17, (copy) v_u_7, (copy) v_u_1, (copy) v_u_26, (copy) v_u_6, (copy) v_u_12, (copy) v_u_4, (copy) v_u_18, (copy) v_u_11, (copy) v_u_9
	local v_u_157 = p151.ctx
	local v158 = (p151.W - 8 * (v_u_17 - 1)) / v_u_17
	local v_u_159 = {}
	for v_u_160 = 1, v_u_17 do
		local v161 = (v_u_160 - 1) * (v158 + 8)
		local v162, v163 = p151.box(v161, p153, v158, p154)
		local v164 = {
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.1,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_7,
			["Position"] = v162,
			["Size"] = v163
		}
		local v165 = p151.frame
		local v166 = v_u_1.new("Frame")
		for v167, v168 in v164 do
			v166[v167] = v168
		end
		v166.Parent = v165
		v_u_26(v166, 8)
		local v169 = {
			["Color"] = nil,
			["Transparency"] = 0.6,
			["Thickness"] = 2,
			["Color"] = v_u_6
		}
		local v170 = v_u_1.new("UIStroke")
		for v171, v172 in v169 do
			v170[v171] = v172
		end
		v170.Parent = v166
		p151.text(v166, p_u_152.xs[v_u_160], p151.NUM, 16, v_u_12, {
			["Position"] = UDim2.fromScale(0, 0.08),
			["Size"] = UDim2.fromScale(1, 0.32)
		})
		local v173 = p151.text(v166, "", p151.HEAVY, 22, v_u_6, {
			["Position"] = UDim2.fromScale(0, 0.42),
			["Size"] = UDim2.fromScale(1, 0.45)
		})
		p151.press(v161, p153, v158, p154, function()
			-- upvalues: (copy) v_u_157, (copy) v_u_160
			v_u_157.setPick(v_u_160)
			v_u_157.redraw()
		end)
		v_u_159[v_u_160] = {
			["stroke"] = v170,
			["value"] = v173
		}
	end
	local v_u_174 = {}
	for v175, v176 in v_u_4.BANDS do
		local v177 = (v176[1] - 1) * (v158 + 8)
		local v178 = (v176[2] - 1) * (v158 + 8) + v158
		local v179, v180 = p151.box(v177, p155, v178 - v177, p156)
		local v181 = {
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.25,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_7,
			["Position"] = v179,
			["Size"] = v180
		}
		local v182 = p151.frame
		local v183 = v_u_1.new("Frame")
		for v184, v185 in v181 do
			v183[v184] = v185
		end
		v183.Parent = v182
		v_u_26(v183, 8)
		local v186 = {
			["Color"] = nil,
			["Transparency"] = 0.75,
			["Thickness"] = 2,
			["Color"] = v_u_6
		}
		local v187 = v_u_1.new("UIStroke")
		for v188, v189 in v186 do
			v187[v188] = v189
		end
		v187.Parent = v183
		v_u_174[v175] = {
			["frame"] = v183,
			["stroke"] = v187,
			["text"] = p151.text(v183, "", p151.THAI, 20, v_u_12, {
				["Size"] = UDim2.fromScale(1, 1)
			}),
			["name"] = v_u_18[v175]
		}
	end
	return {
		["chips"] = v_u_159,
		["strips"] = v_u_174,
		["update"] = function() -- name: update
			-- upvalues: (copy) v_u_157, (copy) v_u_159, (copy) p_u_152, (ref) v_u_11, (ref) v_u_6, (ref) v_u_9
			local v190 = v_u_157.values()
			local v191 = v_u_157.pick()
			for v192, v193 in v_u_159 do
				v193.value.Text = v_u_157.veiled() and "\226\128\162\226\128\162" or p_u_152.fmt:format(v190[v192])
				local v194 = v193.value
				local v195
				if v_u_157.changed(v192) then
					v195 = v_u_11
				else
					v195 = v_u_6
				end
				v194.TextColor3 = v195
				local v196 = v193.stroke
				local v197
				if v192 == v191 then
					v197 = v_u_9
				else
					v197 = v_u_6
				end
				v196.Color = v197
				v193.stroke.Transparency = v192 == v191 and 0 or 0.6
				v193.stroke.Thickness = v192 == v191 and 4 or 2
			end
		end,
		["setBand"] = function(p198, p199, p200) -- name: setBand
			-- upvalues: (copy) v_u_174, (ref) v_u_12
			local v201 = v_u_174[p198]
			v201.text.Text = p199
			v201.text.TextColor3 = p200
			v201.stroke.Color = p200
			v201.stroke.Transparency = p200 == v_u_12 and 0.75 or 0.2
		end
	}
end
local function v_u_268(p_u_203, p_u_204, p_u_205, p206) -- name: soundSlider
	-- upvalues: (copy) v_u_4, (copy) v_u_13, (copy) v_u_12, (copy) v_u_1, (copy) v_u_26, (copy) v_u_6, (copy) v_u_10
	local v_u_207 = p_u_203.ctx
	local v208 = p_u_203.frame
	local v209 = v_u_4.SOUND_SETTINGS[p_u_204]
	local v_u_210 = v209.min
	local v_u_211 = v209.max
	p_u_203.label(p206, p_u_203.THAI, 24, v_u_13, 70, p_u_205, 140)
	p_u_203.label("\224\184\138\224\185\137\224\184\178", p_u_203.THAI, 22, v_u_12, 190, p_u_205, 60)
	p_u_203.label("\224\185\128\224\184\163\224\185\135\224\184\167", p_u_203.THAI, 22, v_u_12, 940, p_u_205, 60)
	local v212, v213 = p_u_203.box(230, p_u_205 - 8, 670, 16)
	local v214 = {
		["BorderSizePixel"] = 0,
		["BackgroundColor3"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = Color3.fromRGB(4, 20, 10),
		["Position"] = v212,
		["Size"] = v213
	}
	local v215 = v_u_1.new("Frame")
	for v216, v217 in v214 do
		v215[v216] = v217
	end
	v215.Parent = v208
	v_u_26(v215, "round")
	local v218 = {
		["Color"] = nil,
		["Transparency"] = 0.5,
		["Thickness"] = 2,
		["Color"] = v_u_13
	}
	local v219 = v_u_1.new("UIStroke")
	for v220, v221 in v218 do
		v219[v220] = v221
	end
	v219.Parent = v215
	local v222 = {
		["BorderSizePixel"] = 0,
		["BackgroundColor3"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = v_u_13,
		["Size"] = UDim2.fromScale(0.5, 1)
	}
	local v_u_223 = v_u_1.new("Frame")
	for v224, v225 in v222 do
		v_u_223[v224] = v225
	end
	v_u_223.Parent = v215
	v_u_26(v_u_223, "round")
	local v226 = {
		["Color"] = ColorSequence.new(Color3.fromRGB(20, 120, 40), v_u_13)
	}
	local v227 = v_u_1.new("UIGradient")
	for v228, v229 in v226 do
		v227[v228] = v229
	end
	v227.Parent = v_u_223
	local v230 = 230 + 670 * (1 - v_u_210) / (v_u_211 - v_u_210)
	local v231, v232 = p_u_203.box(v230 - 1.5, p_u_205 - 16, 3, 32)
	local v233 = {
		["BorderSizePixel"] = 0,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.4,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 2,
		["BackgroundColor3"] = v_u_6,
		["Position"] = v231,
		["Size"] = v232
	}
	local v234 = v_u_1.new("Frame")
	for v235, v236 in v233 do
		v234[v235] = v236
	end
	v234.Parent = v208
	local v237 = {
		["BackgroundColor3"] = nil,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 3,
		["BackgroundColor3"] = Color3.fromRGB(220, 255, 220),
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = p_u_203.at(v230, p_u_205),
		["Size"] = UDim2.fromOffset(30, 44)
	}
	local v_u_238 = v_u_1.new("Frame")
	for v239, v240 in v237 do
		v_u_238[v239] = v240
	end
	v_u_238.Parent = v208
	v_u_26(v_u_238, 10)
	local v241 = {
		["Color"] = nil,
		["Thickness"] = 4,
		["Color"] = v_u_13
	}
	local v242 = v_u_1.new("UIStroke")
	for v243, v244 in v241 do
		v242[v243] = v244
	end
	v242.Parent = v_u_238
	local v_u_245 = p_u_203.label("", p_u_203.HEAVY, 26, v_u_13, 1030, p_u_205, 180)
	p_u_203.label("\224\184\155\224\184\163\224\184\177\224\184\154\224\185\129\224\184\132\224\185\136\224\185\128\224\184\170\224\184\181\224\184\162\224\184\135 \194\183 \224\185\132\224\184\161\224\185\136\224\184\161\224\184\181\224\184\156\224\184\165\224\184\149\224\185\136\224\184\173\224\184\132\224\184\167\224\184\178\224\184\161\224\185\128\224\184\163\224\185\135\224\184\167", p_u_203.THAI, 22, v_u_10, 565, p_u_205 + 36, 670)
	local function v_u_248() -- name: draw
		-- upvalues: (copy) v_u_207, (copy) p_u_204, (copy) v_u_210, (copy) v_u_211, (copy) v_u_238, (copy) p_u_203, (copy) p_u_205, (copy) v_u_223, (copy) v_u_245
		local v246 = v_u_207.soundSetting(p_u_204)
		local v247 = (v246 - v_u_210) / (v_u_211 - v_u_210)
		v_u_238.Position = p_u_203.at(230 + 670 * v247, p_u_205)
		v_u_223.Size = UDim2.fromScale(v247, 1)
		v_u_245.Text = ("x%.2f"):format(v246)
	end
	local v_u_249 = nil
	v_u_249 = p_u_203.press(200, p_u_205 - 26, 730, 52, function(p250)
		-- upvalues: (ref) v_u_249, (copy) v_u_207, (copy) p_u_204, (copy) v_u_210, (copy) v_u_211, (copy) v_u_248
		local function v259(p251) -- name: to
			-- upvalues: (ref) v_u_249, (ref) v_u_207, (ref) p_u_204, (ref) v_u_210, (ref) v_u_211, (ref) v_u_248
			local v252 = v_u_249.AbsolutePosition.X + v_u_249.AbsoluteSize.X * 30 / 730
			local v253 = v_u_249.AbsoluteSize.X * 670 / 730
			local v254 = v_u_207.setSoundSetting
			local v255 = p_u_204
			local v256 = v_u_210
			local v257 = v_u_211 - v_u_210
			local v258 = (p251.X - v252) / v253
			v254(v255, v256 + v257 * math.clamp(v258, 0, 1))
			v_u_248()
		end
		local v260 = p250.Position
		local v261 = v_u_249.AbsolutePosition.X + v_u_249.AbsoluteSize.X * 30 / 730
		local v262 = v_u_249.AbsoluteSize.X * 670 / 730
		local v263 = v_u_207.setSoundSetting
		local v264 = p_u_204
		local v265 = v_u_210
		local v266 = v_u_211 - v_u_210
		local v267 = (v260.X - v261) / v262
		v263(v264, v265 + v266 * math.clamp(v267, 0, 1))
		v_u_248()
		v_u_207.beginDrag(v259)
	end, nil, true)
	v_u_249.Name = p_u_204 .. "Speed"
	return v_u_248
end
function v_u_5.Faders(p269, p_u_270) -- name: Faders
	-- upvalues: (copy) v_u_150, (copy) v_u_17, (copy) v_u_11, (copy) v_u_1, (copy) v_u_6, (copy) v_u_26, (copy) v_u_10, (copy) v_u_9, (copy) v_u_7, (copy) v_u_12
	local v_u_271 = v_u_150(p269, p_u_270)
	local v_u_272 = p_u_270.t()
	local v_u_273 = v_u_271.W / v_u_17
	local v_u_274 = {}
	if v_u_272.base then
		local v275 = (v_u_272.base - v_u_272.min) / (v_u_272.max - v_u_272.min)
		local v276 = 462 - 392 * math.clamp(v275, 0, 1)
		for v277 = 0, 56 do
			local v278, v279 = v_u_271.box(v277 * v_u_271.W / 57, v276 - 1, v_u_271.W / 114, 2)
			local v280 = {
				["BorderSizePixel"] = 0,
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.45,
				["Position"] = nil,
				["Size"] = nil,
				["BackgroundColor3"] = v_u_11,
				["Position"] = v278,
				["Size"] = v279
			}
			local v281 = v_u_1.new("Frame")
			for v282, v283 in v280 do
				v281[v282] = v283
			end
			v281.Parent = p269
		end
		v_u_271.label(("%g"):format(v_u_272.base), v_u_271.NUM, 15, v_u_11, 18, v276 - 12, 40)
	end
	for v_u_284 = 1, v_u_17 do
		local v285 = (v_u_284 - 0.5) * v_u_273
		local v_u_286 = {
			["value"] = v_u_271.label("", v_u_271.HEAVY, 22, v_u_6, v285, 34, v_u_273)
		}
		local v287, v288 = v_u_271.box(v285 - 7, 70, 14, 392)
		local v289 = {
			["BorderSizePixel"] = 0,
			["BackgroundColor3"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = Color3.fromRGB(10, 3, 0),
			["Position"] = v287,
			["Size"] = v288
		}
		local v290 = v_u_1.new("Frame")
		for v291, v292 in v289 do
			v290[v291] = v292
		end
		v290.Parent = p269
		v_u_286.track = v290
		v_u_26(v_u_286.track, "round")
		local v293 = {
			["Color"] = nil,
			["Transparency"] = 0.7,
			["Thickness"] = 1.5,
			["Color"] = v_u_6
		}
		local v294 = v_u_286.track
		local v295 = v_u_1.new("UIStroke")
		for v296, v297 in v293 do
			v295[v296] = v297
		end
		v295.Parent = v294
		local v298 = {
			["BorderSizePixel"] = 0,
			["BackgroundColor3"] = nil,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_6,
			["AnchorPoint"] = Vector2.new(0, 1),
			["Position"] = UDim2.fromScale(0, 1),
			["Size"] = UDim2.fromScale(1, 0.5)
		}
		local v299 = v_u_286.track
		local v300 = v_u_1.new("Frame")
		for v301, v302 in v298 do
			v300[v301] = v302
		end
		v300.Parent = v299
		v_u_286.fill = v300
		v_u_26(v_u_286.fill, "round")
		local v303 = {
			["Rotation"] = 90,
			["Color"] = nil,
			["Color"] = ColorSequence.new(v_u_10, v_u_9)
		}
		local v304 = v_u_286.fill
		local v305 = v_u_1.new("UIGradient")
		for v306, v307 in v303 do
			v305[v306] = v307
		end
		v305.Parent = v304
		for v308 = 0, 10 do
			local v309 = v308 * 392 / 10 + 70
			local v310 = v308 % 5 == 0
			for _, v311 in { -1, 1 } do
				local v312, v313 = v_u_271.box(v285 + v311 * 13 - (v311 < 0 and (v310 and 12 or 8) or 0), v309 - 1, v310 and 12 or 8, 2)
				local v314 = {
					["BorderSizePixel"] = 0,
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["BackgroundColor3"] = v_u_6,
					["BackgroundTransparency"] = v310 and 0.35 or 0.65,
					["Position"] = v312,
					["Size"] = v313
				}
				local v315 = v_u_1.new("Frame")
				for v316, v317 in v314 do
					v315[v316] = v317
				end
				v315.Parent = p269
			end
		end
		local v318 = {
			["BackgroundColor3"] = nil,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = 3,
			["BackgroundColor3"] = v_u_6,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = v_u_271.at(v285, 70),
			["Size"] = UDim2.fromOffset(66, 34)
		}
		local v319 = v_u_1.new("Frame")
		for v320, v321 in v318 do
			v319[v320] = v321
		end
		v319.Parent = p269
		v_u_286.knob = v319
		v_u_26(v_u_286.knob, 8)
		local v322 = {
			["Rotation"] = 90,
			["Color"] = nil,
			["Color"] = ColorSequence.new(Color3.fromRGB(255, 255, 255), Color3.fromRGB(150, 150, 150))
		}
		local v323 = v_u_286.knob
		local v324 = v_u_1.new("UIGradient")
		for v325, v326 in v322 do
			v324[v325] = v326
		end
		v324.Parent = v323
		local v327 = {
			["BorderSizePixel"] = 0,
			["BackgroundColor3"] = nil,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = 3,
			["BackgroundColor3"] = v_u_7,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5, 0.5),
			["Size"] = UDim2.new(0.8, 0, 0, 4)
		}
		local v328 = v_u_286.knob
		local v329 = v_u_1.new("Frame")
		for v330, v331 in v327 do
			v329[v330] = v331
		end
		v329.Parent = v328
		local v332 = {
			["Thickness"] = 0,
			["Color"] = nil,
			["Color"] = v_u_9
		}
		local v333 = v_u_286.knob
		local v334 = v_u_1.new("UIStroke")
		for v335, v336 in v332 do
			v334[v335] = v336
		end
		v334.Parent = v333
		v_u_286.knobStroke = v334
		local v337 = v_u_271.label
		local v338 = v_u_272.xs[v_u_284]
		local v339 = v338:match("^(%d+)k$")
		if v339 then
			local v340 = tonumber(v339) * 1000
			v338 = tostring(v340)
		end
		v_u_286.rpm = v337(v338, v_u_271.NUM, 17, v_u_12, v285, 498, v_u_273)
		v_u_271.press(v285 - v_u_273 / 2, 36, v_u_273, 460, function(p341)
			-- upvalues: (copy) p_u_270, (copy) v_u_284, (copy) v_u_286, (copy) v_u_272
			p_u_270.setPick(v_u_284)
			local function v348(p342) -- name: to
				-- upvalues: (ref) v_u_286, (ref) p_u_270, (ref) v_u_284, (ref) v_u_272
				local v343 = (p342.Y - v_u_286.track.AbsolutePosition.Y) / v_u_286.track.AbsoluteSize.Y
				local v344 = p_u_270.set
				local v345 = v_u_284
				local v346 = v_u_272
				local v347 = 1 - v343
				v344(v345, v346.min + (v346.max - v346.min) * math.clamp(v347, 0, 1))
			end
			local v349 = (p341.Position.Y - v_u_286.track.AbsolutePosition.Y) / v_u_286.track.AbsoluteSize.Y
			local v350 = p_u_270.set
			local v351 = v_u_284
			local v352 = v_u_272
			local v353 = 1 - v349
			v350(v351, v352.min + (v352.max - v352.min) * math.clamp(v353, 0, 1))
			p_u_270.beginDrag(v348)
			p_u_270.redraw()
		end)
		v_u_274[v_u_284] = v_u_286
	end
	function v_u_271.update() -- name: update
		-- upvalues: (copy) p_u_270, (copy) v_u_274, (copy) v_u_272, (copy) v_u_271, (copy) v_u_273, (ref) v_u_11, (ref) v_u_6, (ref) v_u_9, (ref) v_u_12
		local v354 = p_u_270.values()
		local v355 = p_u_270.pick()
		for v356, v357 in v_u_274 do
			local v358 = v_u_272
			local v359 = (v354[v356] - v358.min) / (v358.max - v358.min)
			local v360 = math.clamp(v359, 0, 1)
			v357.knob.Position = v_u_271.at((v356 - 0.5) * v_u_273, 462 - 392 * v360)
			v357.fill.Size = UDim2.fromScale(1, v360)
			v357.value.Text = p_u_270.veiled() and "\226\128\162\226\128\162" or v_u_272.fmt:format(v354[v356])
			local v361 = v357.value
			local v362
			if p_u_270.changed(v356) then
				v362 = v_u_11
			else
				v362 = v_u_6
			end
			v361.TextColor3 = v362
			v357.knobStroke.Thickness = v356 == v355 and 4 or (p_u_270.changed(v356) and 3 or 0)
			local v363 = v357.knobStroke
			local v364
			if v356 == v355 then
				v364 = v_u_9
			else
				v364 = v_u_11
			end
			v363.Color = v364
			local v365 = v357.rpm
			local v366
			if v356 == v355 then
				v366 = v_u_6
			else
				v366 = v_u_12
			end
			v365.TextColor3 = v366
		end
	end
	return v_u_271
end
local function v_u_373(p367, p368) -- name: heat
	-- upvalues: (copy) v_u_14, (copy) v_u_13, (copy) v_u_15
	local v369 = (p368 - p367.min) / (p367.max - p367.min)
	local v370 = math.clamp(v369, 0, 1)
	local v371
	if p367.base then
		local v372 = (p367.base - p367.min) / (p367.max - p367.min)
		v371 = math.clamp(v372, 0, 1)
	else
		v371 = 0.5
	end
	if v370 <= v371 then
		return v_u_14:Lerp(v_u_13, v370 / v371)
	else
		return v_u_13:Lerp(v_u_15, (v370 - v371) / (1 - v371))
	end
end
function v_u_5.Cells(p374, p_u_375) -- name: Cells
	-- upvalues: (copy) v_u_150, (copy) v_u_17, (copy) v_u_12, (copy) v_u_7, (copy) v_u_1, (copy) v_u_26, (copy) v_u_13, (copy) v_u_11, (copy) v_u_6, (copy) v_u_4, (copy) v_u_18, (copy) v_u_373, (copy) v_u_9, (copy) v_u_39
	local v_u_376 = v_u_150(p374, p_u_375)
	local v_u_377 = p_u_375.t()
	local v378 = (v_u_376.W - 8 * (v_u_17 - 1)) / v_u_17
	local v_u_379 = {
		["a"] = p_u_375.pick(),
		["b"] = p_u_375.pick()
	}
	function v_u_376.selection() -- name: selection
		-- upvalues: (copy) v_u_379
		local v380 = v_u_379.a
		local v381 = v_u_379.b
		local v382 = math.min(v380, v381)
		local v383 = v_u_379.a
		local v384 = v_u_379.b
		local v385 = {}
		for v386 = v382, math.max(v383, v384) do
			table.insert(v385, v386)
		end
		return v385
	end
	local v_u_387 = {}
	for v388 = 1, v_u_17 do
		local v389 = (v388 - 1) * (v378 + 8)
		local v390 = v_u_376.label
		local v391 = v_u_377.xs[v388]
		local v392 = v391:match("^(%d+)k$")
		if v392 then
			local v393 = tonumber(v392) * 1000
			v391 = tostring(v393)
		end
		v390(v391, v_u_376.NUM, 17, v_u_12, v389 + v378 / 2, 20, v378)
		local v394, v395 = v_u_376.box(v389, 44, v378, 220)
		local v396 = {
			["BackgroundColor3"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["ClipsDescendants"] = true,
			["BackgroundColor3"] = v_u_7,
			["Position"] = v394,
			["Size"] = v395
		}
		local v397 = v_u_1.new("Frame")
		for v398, v399 in v396 do
			v397[v398] = v399
		end
		v397.Parent = p374
		v_u_26(v397, 8)
		local v400 = {
			["BorderSizePixel"] = 0,
			["BackgroundColor3"] = nil,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_13,
			["AnchorPoint"] = Vector2.new(0, 1),
			["Position"] = UDim2.fromScale(0, 1),
			["Size"] = UDim2.fromScale(1, 0.5)
		}
		local v401 = v_u_1.new("Frame")
		for v402, v403 in v400 do
			v401[v402] = v403
		end
		v401.Parent = v397
		local v404 = {
			["Rotation"] = 90,
			["Transparency"] = nil,
			["Transparency"] = NumberSequence.new(0.15, 0.55)
		}
		local v405 = v_u_1.new("UIGradient")
		for v406, v407 in v404 do
			v405[v406] = v407
		end
		v405.Parent = v401
		local v408 = {
			["BackgroundColor3"] = nil,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = 2,
			["Visible"] = false,
			["BackgroundColor3"] = v_u_11,
			["AnchorPoint"] = Vector2.new(0.5, 0),
			["Position"] = UDim2.new(0.5, 0, 0, 10),
			["Size"] = UDim2.fromOffset(16, 16)
		}
		local v409 = v_u_1.new("Frame")
		for v410, v411 in v408 do
			v409[v410] = v411
		end
		v409.Parent = v397
		v_u_26(v409, "round")
		local v412 = {
			["Color"] = nil,
			["Transparency"] = 0.6,
			["Thickness"] = 2,
			["Color"] = v_u_6
		}
		local v413 = v_u_1.new("UIStroke")
		for v414, v415 in v412 do
			v413[v414] = v415
		end
		v413.Parent = v397
		v_u_387[v388] = {
			["level"] = v401,
			["mark"] = v409,
			["stroke"] = v413
		}
	end
	local v_u_416 = nil
	v_u_416 = v_u_376.press(0, 44, v_u_376.W, 220, function(p417)
		-- upvalues: (ref) v_u_416, (ref) v_u_17, (copy) v_u_379, (copy) p_u_375, (copy) v_u_376, (copy) v_u_377
		local v_u_418 = Vector2.new(p417.Position.X, p417.Position.Y)
		local v419 = (v_u_418.X - v_u_416.AbsolutePosition.X) / v_u_416.AbsoluteSize.X * v_u_17
		local v420 = math.floor(v419) + 1
		local v421 = v_u_17
		local v_u_422 = math.clamp(v420, 1, v421)
		local v423 = v_u_379.a
		local v424 = v_u_379.b
		local v_u_425
		if math.min(v423, v424) <= v_u_422 then
			local v426 = v_u_379.a
			local v427 = v_u_379.b
			if v_u_422 <= math.max(v426, v427) then
				v_u_425 = v_u_379.a ~= v_u_379.b
			else
				v_u_425 = false
			end
		else
			v_u_425 = false
		end
		if not v_u_425 then
			local v428 = v_u_379
			v_u_379.a = v_u_422
			v428.b = v_u_422
		end
		p_u_375.setPick(v_u_422)
		local v_u_429 = {}
		for _, v430 in v_u_376.selection() do
			v_u_429[v430] = p_u_375.values()[v430]
		end
		local v_u_431 = nil
		p_u_375.beginDrag(function(p432)
			-- upvalues: (copy) v_u_418, (ref) v_u_431, (copy) v_u_425, (ref) v_u_379, (ref) v_u_416, (ref) v_u_17, (ref) p_u_375, (ref) v_u_377, (copy) v_u_429
			local v433 = Vector2.new(p432.X, p432.Y) - v_u_418
			local v434, v435, v436, v437, v438
			if v_u_431 then
				if v_u_431 == "run" and not v_u_425 then
					v434 = v_u_379
					v435 = (p432.X - v_u_416.AbsolutePosition.X) / v_u_416.AbsoluteSize.X * v_u_17
					v436 = math.floor(v435) + 1
					v437 = v_u_17
					v434.b = math.clamp(v436, 1, v437)
					p_u_375.setPick(v_u_379.b)
					p_u_375.redraw()
				elseif v_u_431 == "value" then
					v438 = (v_u_377.max - v_u_377.min) / (v_u_416.AbsoluteSize.Y * 1.5)
					for v448, v449 in v_u_429 do
						p_u_375.set(v448, v449 - v433.Y * v438)
					end
				end
			else
				local v441 = v433.Y
				local v442
				if math.abs(v441) > 10 then
					local v443 = v433.Y
					local v444 = math.abs(v443)
					local v445 = v433.X
					if math.abs(v445) < v444 then
						v_u_431 = "value"
						if v_u_431 == "run" and not v_u_425 then
							v434 = v_u_379
							v435 = (p432.X - v_u_416.AbsolutePosition.X) / v_u_416.AbsoluteSize.X * v_u_17
							v436 = math.floor(v435) + 1
							v437 = v_u_17
							v434.b = math.clamp(v436, 1, v437)
							p_u_375.setPick(v_u_379.b)
							p_u_375.redraw()
						elseif v_u_431 == "value" then
							v438 = (v_u_377.max - v_u_377.min) / (v_u_416.AbsoluteSize.Y * 1.5)
							for v448, v449 in v_u_429 do
								p_u_375.set(v448, v449 - v433.Y * v438)
							end
						end
					end
					v442 = v433.X
					if math.abs(v442) > 10 then
						v_u_431 = "run"
					end
				else
					v442 = v433.X
					if math.abs(v442) > 10 then
						v_u_431 = "run"
					end
				end
				if v_u_431 == "run" and not v_u_425 then
					v434 = v_u_379
					v435 = (p432.X - v_u_416.AbsolutePosition.X) / v_u_416.AbsoluteSize.X * v_u_17
					v436 = math.floor(v435) + 1
					v437 = v_u_17
					v434.b = math.clamp(v436, 1, v437)
					p_u_375.setPick(v_u_379.b)
					p_u_375.redraw()
				elseif v_u_431 == "value" then
					v438 = (v_u_377.max - v_u_377.min) / (v_u_416.AbsoluteSize.Y * 1.5)
					for v448, v449 in v_u_429 do
						p_u_375.set(v448, v449 - v433.Y * v438)
					end
				end
			end
		end, function()
			-- upvalues: (copy) v_u_425, (ref) v_u_431, (ref) v_u_379, (copy) v_u_422, (ref) p_u_375
			if v_u_425 and not v_u_431 then
				local v450 = v_u_379
				local v451 = v_u_422
				v_u_379.a = v_u_422
				v450.b = v451
				p_u_375.redraw()
			end
		end)
		p_u_375.redraw()
	end)
	local v_u_452 = {}
	for v453, v454 in v_u_4.BANDS do
		local v455 = (v454[1] - 1) * (v378 + 8)
		local v456 = (v454[2] - 1) * (v378 + 8) + v378
		local v457 = v_u_376.card(v455, 282, v456 - v455, 180)
		v_u_376.text(v457, ("%s  %s\226\128\147%s"):format(v_u_18[v453], v_u_377.xs[v454[1]], v_u_377.xs[v454[2]]), v_u_376.THAI, 21, v_u_12, {
			["Position"] = UDim2.fromScale(0, 0.06),
			["Size"] = UDim2.fromScale(1, 0.2)
		})
		local v458 = v_u_376.text(v457, "", v_u_376.HEAVY, 40, v_u_6, {
			["Position"] = UDim2.fromScale(0, 0.3),
			["Size"] = UDim2.fromScale(1, 0.32)
		})
		local v459 = {
			["BorderSizePixel"] = 0,
			["BackgroundColor3"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = Color3.fromRGB(10, 3, 0),
			["Position"] = UDim2.fromScale(0.08, 0.74),
			["Size"] = UDim2.fromScale(0.84, 0.1)
		}
		local v460 = v_u_1.new("Frame")
		for v461, v462 in v459 do
			v460[v461] = v462
		end
		v460.Parent = v457
		v_u_26(v460, "round")
		local v463 = {
			["BorderSizePixel"] = 0,
			["BackgroundColor3"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_13,
			["Size"] = UDim2.fromScale(0, 1)
		}
		local v464 = v_u_1.new("Frame")
		for v465, v466 in v463 do
			v464[v465] = v466
		end
		v464.Parent = v460
		v_u_26(v464, "round")
		v_u_452[v453] = {
			["pct"] = v458,
			["fill"] = v464
		}
	end
	v_u_376.label("\224\184\165\224\184\178\224\184\129\224\184\139\224\185\137\224\184\178\224\184\162-\224\184\130\224\184\167\224\184\178: \224\185\128\224\184\165\224\184\183\224\184\173\224\184\129\224\184\171\224\184\165\224\184\178\224\184\162\224\184\138\224\185\136\224\184\173\224\184\135  \194\183  \224\184\165\224\184\178\224\184\129\224\184\130\224\184\182\224\185\137\224\184\153-\224\184\165\224\184\135: \224\184\155\224\184\163\224\184\177\224\184\154\224\184\138\224\185\136\224\184\173\224\184\135\224\184\151\224\184\181\224\185\136\224\185\128\224\184\165\224\184\183\224\184\173\224\184\129  \194\183  \224\184\155\224\184\184\224\185\136\224\184\161 \194\177 \224\184\155\224\184\163\224\184\177\224\184\154\224\184\151\224\184\177\224\185\137\224\184\135\224\184\138\224\185\136\224\184\167\224\184\135\224\184\151\224\184\181\224\185\136\224\185\128\224\184\165\224\184\183\224\184\173\224\184\129", v_u_376.THAI, 22, v_u_12, v_u_376.W / 2, 506, v_u_376.W)
	function v_u_376.update() -- name: update
		-- upvalues: (copy) p_u_375, (copy) v_u_379, (copy) v_u_387, (copy) v_u_377, (ref) v_u_373, (ref) v_u_9, (ref) v_u_6, (copy) v_u_452, (ref) v_u_39, (copy) v_u_376
		local v467 = p_u_375.values()
		local v468 = p_u_375.pick()
		local v469 = v_u_379.a
		local v470 = v_u_379.b
		local v471, v472, v473, v474, v475, v476, v477, v478, v479, v480, v481, v482, v483, v484, v485, v486
		if v468 < math.min(v469, v470) then
			v471 = v_u_379
			v_u_379.a = v468
			v471.b = v468
			for v497, v498 in v_u_387 do
				v472 = v_u_377
				v473 = (v467[v497] - v472.min) / (v472.max - v472.min)
				v474 = math.clamp(v473, 0, 1)
				v498.level.Size = UDim2.fromScale(1, v474)
				v498.level.BackgroundColor3 = v_u_373(v_u_377, v467[v497])
				v498.mark.Visible = p_u_375.changed(v497)
				v475 = v_u_379.a
				v476 = v_u_379.b
				if math.min(v475, v476) <= v497 then
					v477 = v_u_379.a
					v478 = v_u_379.b
					v479 = v497 <= math.max(v477, v478)
				else
					v479 = false
				end
				v480 = v498.stroke
				if v497 == v468 then
					v481 = v_u_9
				else
					v481 = v_u_6
				end
				v480.Color = v481
				v498.stroke.Transparency = (v479 or v497 == v468) and 0 or 0.6
				v498.stroke.Thickness = (v479 or v497 == v468) and 4 or 2
			end
			v482 = p_u_375.hint()
			for v499, v500 in v_u_452 do
				v483 = v_u_39
				v484 = v500.pct
				v485 = v500.fill
				if type(v482) == "table" then
					v486 = v482[v499]
				else
					v486 = nil
				end
				v483(v484, v485, v486, 40, 26, v_u_376.HEAVY, v_u_376.THAI)
			end
			return
		else
			local v491 = v_u_379.a
			local v492 = v_u_379.b
			if math.max(v491, v492) < v468 then
				v471 = v_u_379
				v_u_379.a = v468
				v471.b = v468
				for v497, v498 in v_u_387 do
					v472 = v_u_377
					v473 = (v467[v497] - v472.min) / (v472.max - v472.min)
					v474 = math.clamp(v473, 0, 1)
					v498.level.Size = UDim2.fromScale(1, v474)
					v498.level.BackgroundColor3 = v_u_373(v_u_377, v467[v497])
					v498.mark.Visible = p_u_375.changed(v497)
					v475 = v_u_379.a
					v476 = v_u_379.b
					if math.min(v475, v476) <= v497 then
						v477 = v_u_379.a
						v478 = v_u_379.b
						v479 = v497 <= math.max(v477, v478)
					else
						v479 = false
					end
					v480 = v498.stroke
					if v497 == v468 then
						v481 = v_u_9
					else
						v481 = v_u_6
					end
					v480.Color = v481
					v498.stroke.Transparency = (v479 or v497 == v468) and 0 or 0.6
					v498.stroke.Thickness = (v479 or v497 == v468) and 4 or 2
				end
				v482 = p_u_375.hint()
				for v499, v500 in v_u_452 do
					v483 = v_u_39
					v484 = v500.pct
					v485 = v500.fill
					if type(v482) == "table" then
						v486 = v482[v499]
					else
						v486 = nil
					end
					v483(v484, v485, v486, 40, 26, v_u_376.HEAVY, v_u_376.THAI)
				end
			else
				for v497, v498 in v_u_387 do
					v472 = v_u_377
					v473 = (v467[v497] - v472.min) / (v472.max - v472.min)
					v474 = math.clamp(v473, 0, 1)
					v498.level.Size = UDim2.fromScale(1, v474)
					v498.level.BackgroundColor3 = v_u_373(v_u_377, v467[v497])
					v498.mark.Visible = p_u_375.changed(v497)
					v475 = v_u_379.a
					v476 = v_u_379.b
					if math.min(v475, v476) <= v497 then
						v477 = v_u_379.a
						v478 = v_u_379.b
						v479 = v497 <= math.max(v477, v478)
					else
						v479 = false
					end
					v480 = v498.stroke
					if v497 == v468 then
						v481 = v_u_9
					else
						v481 = v_u_6
					end
					v480.Color = v481
					v498.stroke.Transparency = (v479 or v497 == v468) and 0 or 0.6
					v498.stroke.Thickness = (v479 or v497 == v468) and 4 or 2
				end
				v482 = p_u_375.hint()
				for v499, v500 in v_u_452 do
					v483 = v_u_39
					v484 = v500.pct
					v485 = v500.fill
					if type(v482) == "table" then
						v486 = v482[v499]
					else
						v486 = nil
					end
					v483(v484, v485, v486, 40, 26, v_u_376.HEAVY, v_u_376.THAI)
				end
			end
		end
	end
	return v_u_376
end
local v_u_501 = {
	["lean"] = { "\224\184\154\224\184\178\224\184\135\224\185\132\224\184\155 \226\150\188 \224\184\165\224\184\148\224\184\132\224\185\136\224\184\178\224\184\165\224\184\135", "\224\184\154\224\184\178\224\184\135 \226\150\188 \224\184\165\224\184\148", v_u_15 },
	["rich"] = { "\224\184\171\224\184\153\224\184\178\224\185\132\224\184\155 \226\150\178 \224\185\128\224\184\158\224\184\180\224\185\136\224\184\161\224\184\132\224\185\136\224\184\178\224\184\130\224\184\182\224\185\137\224\184\153", "\224\184\171\224\184\153\224\184\178 \226\150\178 \224\185\128\224\184\158\224\184\180\224\185\136\224\184\161", v_u_14 },
	["ok"] = { "\226\156\147 \224\184\149\224\184\163\224\184\135\224\185\129\224\184\165\224\185\137\224\184\167", "\226\156\147 \224\184\149\224\184\163\224\184\135", v_u_13 },
	["mix"] = { "\224\184\161\224\184\181\224\184\151\224\184\177\224\185\137\224\184\135\224\184\154\224\184\178\224\184\135\224\185\129\224\184\165\224\184\176\224\184\171\224\184\153\224\184\178", "\224\184\154\224\184\178\224\184\135+\224\184\171\224\184\153\224\184\178", v_u_16 }
}
function v_u_5.Gauge(p502, p_u_503) -- name: Gauge
	-- upvalues: (copy) v_u_150, (copy) v_u_14, (copy) v_u_13, (copy) v_u_15, (copy) v_u_6, (copy) v_u_11, (copy) v_u_9, (copy) v_u_12, (copy) v_u_1, (copy) v_u_202, (copy) v_u_4, (copy) v_u_501, (copy) v_u_18
	local v504 = v_u_150(p502, p_u_503)
	local v_u_505 = p_u_503.t()
	v504.card(0, 0, 560, 372)
	local v506 = v_u_505.min
	while v506 <= v_u_505.max + 1e-6 do
		local v507 = v506 - math.round(v506)
		local v508 = math.abs(v507) < 1e-6
		local v509 = v504.tick
		local v510 = 280
		local v511 = 262
		local v512 = 206 - (v508 and 30 or 18)
		local v513 = 206
		local v514 = (v506 - v_u_505.min) / (v_u_505.max - v_u_505.min)
		local v515 = -90 + 180 * math.clamp(v514, 0, 1)
		local v516 = v508 and 5 or 3
		local v517
		if v506 < 11.5 then
			v517 = v_u_14
		elseif v506 <= 14 then
			v517 = v_u_13
		else
			v517 = v_u_15
		end
		v509(v510, v511, v512, v513, v515, v516, v517)
		if v508 then
			local v518 = v504.polar
			local v519 = (v506 - v_u_505.min) / (v_u_505.max - v_u_505.min)
			local v520, v521 = v518(280, 262, 152, -90 + 180 * math.clamp(v519, 0, 1))
			local v522 = v504.label
			local v523 = math.round(v506)
			v522(tostring(v523), v504.NUM, 20, v_u_6, v520, v521, 40)
		end
		v506 = v506 + 0.25
	end
	if v_u_505.textbook then
		local v524 = v504.tick
		local v525 = (v_u_505.textbook - v_u_505.min) / (v_u_505.max - v_u_505.min)
		v524(280, 262, 162, 212, -90 + 180 * math.clamp(v525, 0, 1), 4, v_u_11, 3)
		local v526 = v504.polar
		local v527 = (v_u_505.textbook - v_u_505.min) / (v_u_505.max - v_u_505.min)
		local v528, v529 = v526(280, 262, 228, -90 + 180 * math.clamp(v527, 0, 1))
		v504.label(("%g"):format(v_u_505.textbook), v504.NUM, 16, v_u_11, v528, v529, 50)
	end
	local v_u_530 = v504.needle(280, 262, 172, 7, v_u_6, 4)
	v504.circle(280, 262, 34, v_u_6, 5)
	v504.circle(280, 262, 18, v_u_9, 6)
	v504.label("AFR", v504.NUM, 16, v_u_12, 280, 298, 80)
	local v_u_531 = v504.label("", v504.HEAVY, 40, v_u_6, 280, 336, 200)
	v504.card(580, 0, 550, 372)
	for v532 = 0, 32 do
		local v533 = v532 * 270 / 32 + -135
		v504.tick(855, 168, 122, (v532 % 4 == 0 and 28 or 20) + 112, v533, v532 % 4 == 0 and 4 or 2, v_u_6)
	end
	local v_u_534 = v504.circle(855, 168, 224, Color3.fromRGB(40, 43, 56), 2)
	local v535 = {
		["Rotation"] = 45,
		["Color"] = nil,
		["Color"] = ColorSequence.new(Color3.fromRGB(70, 74, 92), Color3.fromRGB(20, 22, 28))
	}
	local v536 = v_u_1.new("UIGradient")
	for v537, v538 in v535 do
		v536[v537] = v538
	end
	v536.Parent = v_u_534
	local v539 = {
		["Color"] = nil,
		["Thickness"] = 6,
		["Color"] = v_u_9
	}
	local v540 = v_u_1.new("UIStroke")
	for v541, v542 in v539 do
		v540[v541] = v542
	end
	v540.Parent = v_u_534
	v504.circle(855, 168, 164, Color3.fromRGB(30, 32, 42), 3)
	local v_u_543 = v504.needle(855, 168, 96, 12, v_u_9, 4)
	local v_u_544 = v504.label("", v504.NUM, 20, v_u_6, 855, 318, 300)
	local v_u_545 = v504.label("", v504.THAI, 21, v_u_12, 855, 350, 520)
	v504.press(713, 26, 284, 284, function(p546)
		-- upvalues: (copy) v_u_534, (copy) p_u_503, (copy) v_u_505
		local v_u_547 = v_u_534
		local v_u_548 = nil
		local function v_u_559(p549)
			-- upvalues: (copy) v_u_547, (ref) v_u_548
			local v550 = v_u_547
			local v551 = v550.AbsolutePosition + v550.AbsoluteSize / 2
			local v552 = Vector2.new(p549.X, p549.Y) - v551
			local v553 = v552.X
			local v554 = -v552.Y
			local v555 = math.atan2(v553, v554)
			local v556 = math.deg(v555)
			if v_u_548 then
				local v557 = v556 - v_u_548
				v556 = math.abs(v557) > 180 and (v_u_548 > 0 and 135 or -135) or v556
			end
			local v558 = math.clamp(v556, -135, 135)
			v_u_548 = v558
			return (v558 + 135) / 270
		end
		local function v565(p560) -- name: to
			-- upvalues: (ref) p_u_503, (ref) v_u_505, (copy) v_u_559
			local v561 = p_u_503.set
			local v562 = p_u_503.pick()
			local v563 = v_u_505
			local v564 = v_u_559(p560)
			v561(v562, v563.min + (v563.max - v563.min) * math.clamp(v564, 0, 1))
		end
		local v566 = p546.Position
		local v567 = p_u_503.set
		local v568 = p_u_503.pick()
		local v569 = v_u_505
		local v570 = v_u_559(v566)
		v567(v568, v569.min + (v569.max - v569.min) * math.clamp(v570, 0, 1))
		p_u_503.beginDrag(v565)
		p_u_503.redraw()
	end).Name = "Knob"
	local v_u_571 = v_u_202(v504, v_u_505, 438, 100, 386, 42)
	function v504.update() -- name: update
		-- upvalues: (copy) p_u_503, (copy) v_u_530, (copy) v_u_505, (copy) v_u_543, (copy) v_u_531, (ref) v_u_11, (ref) v_u_14, (ref) v_u_13, (ref) v_u_15, (copy) v_u_544, (copy) v_u_571, (ref) v_u_4, (ref) v_u_501, (ref) v_u_18, (ref) v_u_12, (copy) v_u_545
		local v572 = p_u_503.values()
		local v573 = p_u_503.pick()
		local v574 = v572[v573]
		local v575 = v_u_530
		local v576 = v_u_505
		local v577 = (v574 - v576.min) / (v576.max - v576.min)
		v575.Rotation = -90 + 180 * math.clamp(v577, 0, 1)
		local v578 = v_u_543
		local v579 = v_u_505
		local v580 = (v574 - v579.min) / (v579.max - v579.min)
		v578.Rotation = -135 + 270 * math.clamp(v580, 0, 1)
		v_u_531.Text = p_u_503.veiled() and "\226\128\162\226\128\162" or v_u_505.fmt:format(v574)
		local v581 = v_u_531
		local v582
		if p_u_503.changed(v573) then
			v582 = v_u_11
		elseif v574 < 11.5 then
			v582 = v_u_14
		elseif v574 <= 14 then
			v582 = v_u_13
		else
			v582 = v_u_15
		end
		v581.TextColor3 = v582
		local v583 = v_u_544
		local v584 = "%s rpm"
		local v585 = v_u_505.xs[v573]
		local v586 = v585:match("^(%d+)k$")
		if v586 then
			local v587 = tonumber(v586) * 1000
			v585 = tostring(v587)
		end
		v583.Text = v584:format(v585)
		v_u_571.update()
		local v588 = p_u_503.hint()
		for v589 = 1, #v_u_4.BANDS do
			local v590
			if type(v588) == "table" then
				v590 = v588[v589]
			else
				v590 = nil
			end
			local v591
			if type(v590) == "table" then
				local v592 = v590.d
				v591 = v590.m
				v590 = v592
			else
				if type(v590) ~= "string" then
					v590 = nil
				end
				v591 = nil
			end
			local v593 = v_u_501[v590]
			if v593 then
				local v594
				if type(v591) == "number" then
					local v595 = v591 * 1000 + 0.5
					v594 = (" %.1f%%"):format(math.floor(v595) / 10)
				else
					v594 = ""
				end
				v_u_571.setBand(v589, ("%s%s \194\183 %s"):format(v_u_18[v589], v594, v593[2]), v593[3])
			else
				v_u_571.setBand(v589, v_u_18[v589] .. ": \224\185\129\224\184\159\224\184\165\224\184\138\224\185\128\224\184\158\224\184\183\224\185\136\224\184\173\224\184\148\224\184\185\224\184\151\224\184\180\224\184\168\224\184\151\224\184\178\224\184\135", v_u_12)
			end
		end
		local v596
		if type(v588) == "table" then
			for v599, v598 in v_u_4.BANDS do
				if v598[1] > v573 or v573 > v598[2] then
					continue
				end
			end
			local v599 = 1
			v596 = v588[v599]
		else
			v596 = nil
		end
		if type(v596) == "table" then
			local v600 = v596.d
			local _ = v596.m
			v596 = v600
		elseif type(v596) ~= "string" then
			v596 = nil
		end
		local v601 = v_u_501[v596]
		local v602 = v_u_545
		local v603
		if v601 then
			local v604 = v_u_18
			for v607, v606 in v_u_4.BANDS do
				if v606[1] > v573 or v573 > v606[2] then
					continue
				end
			end
			local v607 = 1
			v603 = v604[v607] .. ": " .. v601[1]
		else
			v603 = "\224\185\129\224\184\159\224\184\165\224\184\138\224\185\129\224\184\165\224\185\137\224\184\167\224\184\136\224\184\176\224\184\154\224\184\173\224\184\129\224\184\167\224\185\136\224\184\178\224\184\154\224\184\178\224\184\135\224\184\171\224\184\163\224\184\183\224\184\173\224\184\171\224\184\153\224\184\178"
		end
		v602.Text = v603
		local v608 = v_u_545
		local v609
		if v601 then
			v609 = v601[3]
		else
			v609 = v_u_12
		end
		v608.TextColor3 = v609
	end
	return v504
end
function v_u_5.Graph(p610, p_u_611) -- name: Graph
	-- upvalues: (copy) v_u_150, (copy) v_u_6, (copy) v_u_1, (copy) v_u_17, (copy) v_u_268, (copy) v_u_11, (copy) v_u_26
	local v612 = v_u_150(p610, p_u_611)
	local v_u_613 = p_u_611.t()
	local v_u_614 = Color3.fromRGB(248, 255, 44)
	local v_u_615 = Color3.fromRGB(255, 196, 46)
	local v616, v617 = v612.box(104, 47, 1020, 396)
	local v618 = {
		["BackgroundColor3"] = v_u_6,
		["Position"] = v616,
		["Size"] = v617
	}
	local v619 = v_u_1.new("Frame")
	for v620, v621 in v618 do
		v619[v620] = v621
	end
	v619.Parent = p610
	local v622 = {
		["Rotation"] = -6,
		["Color"] = nil,
		["Color"] = ColorSequence.new(Color3.fromRGB(50, 53, 68), Color3.fromRGB(22, 24, 32))
	}
	local v623 = v_u_1.new("UIGradient")
	for v624, v625 in v622 do
		v623[v624] = v625
	end
	v623.Parent = v619
	local v_u_626 = v_u_1.new("Folder")
	for v627, v628 in {
		["Name"] = "Grid"
	} do
		v_u_626[v627] = v628
	end
	v_u_626.Parent = v619
	local v629 = {
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 2,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v630 = v_u_1.new("Frame")
	for v631, v632 in v629 do
		v630[v631] = v632
	end
	v630.Parent = v619
	local v633 = {
		["ApplyStrokeMode"] = nil,
		["Color"] = nil,
		["Thickness"] = 1,
		["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
		["Color"] = Color3.fromRGB(70, 74, 92)
	}
	local v634 = v_u_1.new("UIStroke")
	for v635, v636 in v633 do
		v634[v635] = v636
	end
	v634.Parent = v630
	local v637 = {
		["Name"] = "Plot",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 3,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v_u_638 = v_u_1.new("Frame")
	for v639, v640 in v637 do
		v_u_638[v639] = v640
	end
	v_u_638.Parent = v619
	for v641 = 0, 10 do
		local v642 = v_u_613.min + (v_u_613.max - v_u_613.min) * v641 / 10
		local v643 = v612.label
		local v644 = v_u_613.fmt:format(v642)
		local v645 = v612.NUM
		local v646 = v_u_6
		local v647 = (v642 - v_u_613.min) / (v_u_613.max - v_u_613.min)
		v643(v644, v645, 19, v646, 55, 47 + 396 * (1 - math.clamp(v647, 0, 1)), 84).TextXAlignment = Enum.TextXAlignment.Right
	end
	local v_u_648 = {}
	for v649 = 1, v_u_17 do
		local v650 = v612.label
		local v651 = v_u_613.xs[v649]
		local v652 = v651:match("^(%d+)k$")
		if v652 then
			local v653 = tonumber(v652) * 1000
			v651 = tostring(v653)
		end
		v_u_648[v649] = v650(v651, v612.NUM, 19, v_u_6, 104 + 1020 * (2 * v649 - 1) / 22, 25, 80)
	end
	function v612.rescale() -- name: rescale
		-- upvalues: (copy) p_u_611, (copy) v_u_626, (ref) v_u_6, (ref) v_u_1
		local v654 = p_u_611.scale()
		if v654 > 0.01 then
			v_u_626:ClearAllChildren()
			local v655 = 2.5 * v654 + 0.5
			local v656 = math.floor(v655)
			local v657 = math.max(1, v656)
			local v658 = v657 / (1020 * v654)
			local v659 = v657 / (396 * v654)
			for v660 = 1, 21 do
				local v661 = {
					["BorderSizePixel"] = 0,
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = 0.06,
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["BackgroundColor3"] = v_u_6,
					["AnchorPoint"] = Vector2.new(0.5, 0),
					["Position"] = UDim2.fromScale(v660 / 22, 0),
					["Size"] = UDim2.fromScale(v658, 1)
				}
				local v662 = v_u_626
				local v663 = v_u_1.new("Frame")
				for v664, v665 in v661 do
					v663[v664] = v665
				end
				v663.Parent = v662
			end
			for v666 = 1, 9 do
				local v667 = {
					["BorderSizePixel"] = 0,
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = 0.06,
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["BackgroundColor3"] = v_u_6,
					["AnchorPoint"] = Vector2.new(0, 0.5),
					["Position"] = UDim2.fromScale(0, v666 / 10),
					["Size"] = UDim2.fromScale(1, v659)
				}
				local v668 = v_u_626
				local v669 = v_u_1.new("Frame")
				for v670, v671 in v667 do
					v669[v670] = v671
				end
				v669.Parent = v668
			end
		end
	end
	v612.rescale()
	v612.press(88, 31, 1052, 428, function(p672)
		-- upvalues: (copy) v_u_638, (ref) v_u_17, (copy) v_u_613, (copy) p_u_611
		local v673 = p672.Position
		local v674 = (Vector2.new(v673.X, v673.Y) - v_u_638.AbsolutePosition) / v_u_638.AbsoluteSize
		local v675 = (v674.X * 22 + 1) / 2
		local v676 = math.round(v675)
		local v677 = v_u_17
		local v_u_678 = math.clamp(v676, 1, v677)
		local v679 = v_u_613
		local v680 = 1 - v674.Y
		local v681 = v679.min + (v679.max - v679.min) * math.clamp(v680, 0, 1)
		p_u_611.setPick(v_u_678)
		p_u_611.set(v_u_678, v681)
		p_u_611.beginDrag(function(p682)
			-- upvalues: (ref) v_u_638, (ref) v_u_17, (ref) v_u_613, (ref) p_u_611, (copy) v_u_678
			local v683 = (Vector2.new(p682.X, p682.Y) - v_u_638.AbsolutePosition) / v_u_638.AbsoluteSize
			local v684 = (v683.X * 22 + 1) / 2
			local v685 = math.round(v684)
			local v686 = v_u_17
			math.clamp(v685, 1, v686)
			local v687 = v_u_613
			local v688 = 1 - v683.Y
			local v689 = v687.min + (v687.max - v687.min) * math.clamp(v688, 0, 1)
			p_u_611.set(v_u_678, v689)
		end)
		p_u_611.redraw()
	end, 8)
	local v_u_690 = v_u_268(v612, "Rev", 488, "\224\184\132\224\184\177\224\184\153\224\185\128\224\184\163\224\185\136\224\184\135")
	function v612.update() -- name: update
		-- upvalues: (copy) v_u_690, (copy) v_u_638, (copy) p_u_611, (copy) v_u_648, (copy) v_u_613, (ref) v_u_11, (ref) v_u_1, (ref) v_u_17, (copy) v_u_614, (copy) v_u_615, (ref) v_u_6, (ref) v_u_26
		v_u_690()
		v_u_638:ClearAllChildren()
		local v691 = p_u_611.values()
		local v692 = p_u_611.pick()
		for v693, v694 in v_u_648 do
			v694.TextTransparency = v693 == v692 and 0 or 0.08
		end
		if v_u_613.textbook then
			local v695 = v_u_613
			local v696 = (v_u_613.textbook - v695.min) / (v695.max - v695.min)
			local v697 = 396 * (1 - math.clamp(v696, 0, 1))
			for v698 = 0, 40 do
				local v699 = {
					["BorderSizePixel"] = 0,
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = 0.3,
					["Position"] = nil,
					["Size"] = nil,
					["BackgroundColor3"] = v_u_11
				}
				local v700 = v698 * 1020 / 41
				local v701 = v697 - 1.5
				v699.Position = UDim2.fromScale(v700 / 1020, v701 / 396)
				v699.Size = UDim2.fromOffset(12.439024390243903, 3)
				local v702 = v_u_638
				local v703 = v_u_1.new("Frame")
				for v704, v705 in v699 do
					v703[v704] = v705
				end
				v703.Parent = v702
			end
		end
		for v706 = 1, v_u_17 - 1 do
			local v707 = Vector2.new
			local v708 = 1020 * (2 * v706 - 1) / 22
			local v709 = v_u_613
			local v710 = (v691[v706] - v709.min) / (v709.max - v709.min)
			local v711 = v707(v708, 396 * (1 - math.clamp(v710, 0, 1)))
			local v712 = Vector2.new
			local v713 = 1020 * (2 * (v706 + 1) - 1) / 22
			local v714 = v_u_613
			local v715 = (v691[v706 + 1] - v714.min) / (v714.max - v714.min)
			local v716 = v712(v713, 396 * (1 - math.clamp(v715, 0, 1)))
			local v717 = (v711 + v716) / 2
			local v718 = v716 - v711
			local v719 = v718.Y
			local v720 = v718.X
			local v721 = math.atan2(v719, v720)
			local v722 = math.deg(v721)
			local v723 = v_u_614
			local v724 = v_u_615
			local v725 = (v717.X / 1020 - 0.18) / 0.82
			local v726 = v723:Lerp(v724, (math.clamp(v725, 0, 1)))
			local v727 = {
				["BorderSizePixel"] = 0,
				["BackgroundColor3"] = nil,
				["BackgroundTransparency"] = 0.78,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Rotation"] = nil,
				["ZIndex"] = 2,
				["BackgroundColor3"] = v726,
				["AnchorPoint"] = Vector2.new(0.5, 0.5)
			}
			local v728 = v717.X
			local v729 = v717.Y
			v727.Position = UDim2.fromScale(v728 / 1020, v729 / 396)
			v727.Size = UDim2.fromOffset(v718.Magnitude + 4, 16)
			v727.Rotation = v722
			local v730 = v_u_638
			local v731 = v_u_1.new("Frame")
			for v732, v733 in v727 do
				v731[v732] = v733
			end
			v731.Parent = v730
			local v734 = {
				["BorderSizePixel"] = 0,
				["BackgroundColor3"] = nil,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Rotation"] = nil,
				["ZIndex"] = 3,
				["BackgroundColor3"] = v726,
				["AnchorPoint"] = Vector2.new(0.5, 0.5)
			}
			local v735 = v717.X
			local v736 = v717.Y
			v734.Position = UDim2.fromScale(v735 / 1020, v736 / 396)
			v734.Size = UDim2.fromOffset(v718.Magnitude + 2, 5)
			v734.Rotation = v722
			local v737 = v_u_638
			local v738 = v_u_1.new("Frame")
			for v739, v740 in v734 do
				v738[v739] = v740
			end
			v738.Parent = v737
		end
		for v741, v742 in v691 do
			local v743 = 1020 * (2 * v741 - 1) / 22
			local v744 = v_u_613
			local v745 = (v742 - v744.min) / (v744.max - v744.min)
			local v746 = 396 * (1 - math.clamp(v745, 0, 1))
			local v747 = v741 == v692
			if v747 then
				local v748 = {
					["BorderSizePixel"] = 0,
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = 0.88,
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["ZIndex"] = 1,
					["BackgroundColor3"] = v_u_6,
					["AnchorPoint"] = Vector2.new(0.5, 0),
					["Position"] = UDim2.fromScale(v743 / 1020, 0),
					["Size"] = UDim2.new(0, 34, 1, 0)
				}
				local v749 = v_u_638
				local v750 = v_u_1.new("Frame")
				for v751, v752 in v748 do
					v750[v751] = v752
				end
				v750.Parent = v749
				local v753 = {
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = 0.7,
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["ZIndex"] = 4,
					["BackgroundColor3"] = v_u_6,
					["AnchorPoint"] = Vector2.new(0.5, 0.5),
					["Position"] = UDim2.fromScale(v743 / 1020, v746 / 396),
					["Size"] = UDim2.fromOffset(44, 44)
				}
				local v754 = v_u_638
				local v755 = v_u_1.new("Frame")
				for v756, v757 in v753 do
					v755[v756] = v757
				end
				v755.Parent = v754
				v_u_26(v755, "round")
			end
			local v758 = v747 and 28 or 20
			local v759 = {
				["BackgroundColor3"] = nil,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["ZIndex"] = 5,
				["BackgroundColor3"] = v_u_6,
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.fromScale(v743 / 1020, v746 / 396),
				["Size"] = UDim2.fromOffset(v758, v758)
			}
			local v760 = v_u_638
			local v761 = v_u_1.new("Frame")
			for v762, v763 in v759 do
				v761[v762] = v763
			end
			v761.Parent = v760
			v_u_26(v761, "round")
			if v747 then
				local v764 = {
					["Color"] = nil,
					["Thickness"] = 5,
					["Color"] = v_u_615
				}
				local v765 = v_u_1.new("UIStroke")
				for v766, v767 in v764 do
					v765[v766] = v767
				end
				v765.Parent = v761
			else
				if not p_u_611.changed(v741) then
					break
				end
				local v768 = {
					["Color"] = nil,
					["Thickness"] = 3.5,
					["Color"] = v_u_11
				}
				local v769 = v_u_1.new("UIStroke")
				for v770, v771 in v768 do
					v769[v770] = v771
				end
				v769.Parent = v761
			end
		end
	end
	return v612
end
local v_u_772 = {
	{ 4, v_u_13 },
	{ 7, v_u_10 },
	{ 10, Color3.fromRGB(255, 196, 46) }
}
function v_u_5.Blocks(p773, p_u_774) -- name: Blocks
	-- upvalues: (copy) v_u_150, (copy) v_u_17, (copy) v_u_6, (copy) v_u_12, (copy) v_u_1, (copy) v_u_26, (copy) v_u_772, (copy) v_u_4, (copy) v_u_18, (copy) v_u_13, (copy) v_u_39, (copy) v_u_11
	local v_u_775 = v_u_150(p773, p_u_774)
	local v_u_776 = p_u_774.t()
	local v777 = v_u_775.W / v_u_17
	local v_u_778 = {}
	for v_u_779 = 1, v_u_17 do
		local v780 = (v_u_779 - 0.5) * v777
		local v_u_781 = {
			["blocks"] = {},
			["value"] = v_u_775.label("", v_u_775.HEAVY, 22, v_u_6, v780, 28, v777)
		}
		local v782 = v_u_775.label
		local v783 = v_u_776.xs[v_u_779]
		local v784 = v783:match("^(%d+)k$")
		if v784 then
			local v785 = tonumber(v784) * 1000
			v783 = tostring(v785)
		end
		v_u_781.rpm = v782(v783, v_u_775.NUM, 17, v_u_12, v780, 394, v777)
		local v786, v787 = v_u_775.box(v780 - v777 / 2 + 6, 48, v777 - 12, 332)
		local v788 = {
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 1,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_6,
			["Position"] = v786,
			["Size"] = v787
		}
		local v789 = v_u_1.new("Frame")
		for v790, v791 in v788 do
			v789[v790] = v791
		end
		v789.Parent = p773
		v_u_781.back = v789
		v_u_26(v_u_781.back, 10)
		for v792 = 1, 10 do
			local v793 = nil
			for _, v794 in v_u_772 do
				if v792 > v794[1] then
					continue
				end
				v793 = v794[2]
			end
			local v795 = 372 - v792 * 28 - (v792 - 1) * 4
			local v796, v797 = v_u_775.box(v780 - 30, v795, 60, 28)
			local v798 = {
				["BackgroundColor3"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["ClipsDescendants"] = true,
				["BackgroundColor3"] = Color3.fromRGB(50, 53, 68),
				["Position"] = v796,
				["Size"] = v797
			}
			local v799 = v_u_1.new("Frame")
			for v800, v801 in v798 do
				v799[v800] = v801
			end
			v799.Parent = p773
			v_u_26(v799, 5)
			local v802 = {
				["BorderSizePixel"] = 0,
				["BackgroundColor3"] = nil,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["BackgroundColor3"] = v793,
				["AnchorPoint"] = Vector2.new(0, 1),
				["Position"] = UDim2.fromScale(0, 1),
				["Size"] = UDim2.fromScale(1, 0)
			}
			local v803 = v_u_1.new("Frame")
			for v804, v805 in v802 do
				v803[v804] = v805
			end
			v803.Parent = v799
			v_u_26(v803, 5)
			v_u_781.blocks[v792] = v803
		end
		v_u_775.press(v780 - v777 / 2, 26, v777, 376, function(p806)
			-- upvalues: (copy) p_u_774, (copy) v_u_779, (copy) v_u_781, (copy) v_u_776
			p_u_774.setPick(v_u_779)
			local v807 = p806.Position
			local v808 = v_u_781.blocks[1].Parent
			local v809 = v_u_781.blocks[10].Parent
			local v810 = v808.AbsolutePosition.Y + v808.AbsoluteSize.Y
			local v811 = v810 - v807.Y
			local v812 = v810 - v809.AbsolutePosition.Y
			local v813 = v811 / math.max(v812, 1)
			local v814 = p_u_774.set
			local v815 = v_u_779
			local v816 = v_u_776
			local v817 = v813 * 10 - 1e-6
			local v818 = math.ceil(v817)
			local v819 = math.clamp(v818, 1, 10) / 10
			v814(v815, v816.min + (v816.max - v816.min) * math.clamp(v819, 0, 1))
			local v_u_820 = p806.Position.Y
			p_u_774.beginDrag(function(p821)
				-- upvalues: (copy) v_u_820, (ref) p_u_774, (ref) v_u_779, (ref) v_u_776, (ref) v_u_781
				local v822 = p821.Y - v_u_820
				if math.abs(v822) > 6 then
					local v823 = p_u_774.set
					local v824 = v_u_779
					local v825 = v_u_776
					local v826 = v_u_781.blocks[1].Parent
					local v827 = v_u_781.blocks[10].Parent
					local v828 = v826.AbsolutePosition.Y + v826.AbsoluteSize.Y
					local v829 = v828 - p821.Y
					local v830 = v828 - v827.AbsolutePosition.Y
					local v831 = v829 / math.max(v830, 1)
					v823(v824, v825.min + (v825.max - v825.min) * math.clamp(v831, 0, 1))
				end
			end)
			p_u_774.redraw()
		end)
		v_u_778[v_u_779] = v_u_781
	end
	local v_u_832 = {}
	for v833, v834 in v_u_4.BANDS do
		local v835 = (v834[1] - 1) * v777 + 6
		local v836 = v834[2] * v777 - 6
		local v837 = v_u_775.card(v835, 416, v836 - v835, 70)
		v_u_775.text(v837, ("%s  %s\226\128\147%s"):format(v_u_18[v833], v_u_776.xs[v834[1]], v_u_776.xs[v834[2]]), v_u_775.THAI, 19, v_u_12, {
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["Position"] = UDim2.new(0, 14, 0, 6),
			["Size"] = UDim2.new(0.6, 0, 0, 32)
		})
		local v838 = v_u_775.text(v837, "", v_u_775.HEAVY, 26, v_u_6, {
			["TextXAlignment"] = Enum.TextXAlignment.Right,
			["AnchorPoint"] = Vector2.new(1, 0),
			["Position"] = UDim2.new(1, -14, 0, 6),
			["Size"] = UDim2.new(0.4, 0, 0, 32)
		})
		local v839 = {
			["BorderSizePixel"] = 0,
			["BackgroundColor3"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = Color3.fromRGB(10, 3, 0),
			["Position"] = UDim2.new(0, 14, 0, 46),
			["Size"] = UDim2.new(1, -28, 0, 10)
		}
		local v840 = v_u_1.new("Frame")
		for v841, v842 in v839 do
			v840[v841] = v842
		end
		v840.Parent = v837
		v_u_26(v840, "round")
		local v843 = {
			["BorderSizePixel"] = 0,
			["BackgroundColor3"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_13,
			["Size"] = UDim2.fromScale(0, 1)
		}
		local v844 = v_u_1.new("Frame")
		for v845, v846 in v843 do
			v844[v845] = v846
		end
		v844.Parent = v840
		v_u_26(v844, "round")
		v_u_832[v833] = {
			["pct"] = v838,
			["fill"] = v844
		}
	end
	v_u_775.label("\224\185\129\224\184\149\224\184\176\224\184\138\224\185\136\224\184\173\224\184\135: \224\184\149\224\184\177\224\185\137\224\184\135\224\184\151\224\184\181\224\184\165\224\184\176 10%  \194\183  \224\184\165\224\184\178\224\184\129\224\184\130\224\184\182\224\185\137\224\184\153-\224\184\165\224\184\135: \224\184\155\224\184\163\224\184\177\224\184\154\224\184\165\224\184\176\224\185\128\224\184\173\224\184\181\224\184\162\224\184\148  \194\183  \224\184\155\224\184\184\224\185\136\224\184\161 \194\177 \224\184\155\224\184\163\224\184\177\224\184\154\224\184\151\224\184\181\224\184\165\224\184\176 1% / 10%", v_u_775.THAI, 22, v_u_12, v_u_775.W / 2, 522, v_u_775.W)
	function v_u_775.update() -- name: update
		-- upvalues: (copy) p_u_774, (copy) v_u_832, (ref) v_u_39, (copy) v_u_775, (copy) v_u_778, (copy) v_u_776, (ref) v_u_11, (ref) v_u_6, (ref) v_u_12
		local v847 = p_u_774.values()
		local v848 = p_u_774.pick()
		local v849 = p_u_774.hint()
		for v850, v851 in v_u_832 do
			local v852 = v_u_39
			local v853 = v851.pct
			local v854 = v851.fill
			local v855
			if type(v849) == "table" then
				v855 = v849[v850]
			else
				v855 = nil
			end
			v852(v853, v854, v855, 26, 20, v_u_775.HEAVY, v_u_775.THAI)
		end
		for v856, v857 in v_u_778 do
			local v858 = v_u_776
			local v859 = (v847[v856] - v858.min) / (v858.max - v858.min)
			local v860 = math.clamp(v859, 0, 1) * 10
			for v861, v862 in v857.blocks do
				local v863 = UDim2.fromScale
				local v864 = v860 - (v861 - 1)
				v862.Size = v863(1, (math.clamp(v864, 0, 1)))
			end
			v857.value.Text = p_u_774.veiled() and "\226\128\162\226\128\162" or v_u_776.fmt:format(v847[v856])
			local v865 = v857.value
			local v866
			if p_u_774.changed(v856) then
				v866 = v_u_11
			else
				v866 = v_u_6
			end
			v865.TextColor3 = v866
			v857.back.BackgroundTransparency = v856 == v848 and 0.86 or 1
			local v867 = v857.rpm
			local v868
			if v856 == v848 then
				v868 = v_u_6
			else
				v868 = v_u_12
			end
			v867.TextColor3 = v868
		end
	end
	return v_u_775
end
function v_u_5.Wheel(p869, p_u_870) -- name: Wheel
	-- upvalues: (copy) v_u_150, (copy) v_u_6, (copy) v_u_1, (copy) v_u_12, (copy) v_u_9, (copy) v_u_17, (copy) v_u_26, (copy) v_u_4, (copy) v_u_15, (copy) v_u_202, (copy) v_u_11, (copy) v_u_18, (copy) v_u_13
	local v871 = v_u_150(p869, p_u_870)
	local v_u_872 = p_u_870.t()
	v871.card(0, 0, 600, 372)
	local v_u_873 = v871.circle(300, 186, 324, Color3.fromRGB(16, 18, 24), 2)
	local v874 = {
		["Color"] = nil,
		["Transparency"] = 0.4,
		["Thickness"] = 3,
		["Color"] = v_u_6
	}
	local v875 = v_u_1.new("UIStroke")
	for v876, v877 in v874 do
		v875[v876] = v877
	end
	v875.Parent = v_u_873
	local v878 = v_u_872.min
	local v879 = math.ceil(v878)
	local v880 = v_u_872.max
	for v881 = v879, math.floor(v880) do
		local v882 = v881 % 5 == 0
		local v883 = v871.tick
		local v884 = 300
		local v885 = 186
		local v886 = 162 - (v882 and 26 or 14)
		local v887 = 160
		local v888 = (v881 - v_u_872.min) / (v_u_872.max - v_u_872.min)
		local v889 = -135 + 270 * math.clamp(v888, 0, 1)
		local v890 = v882 and 4 or 2
		local v891
		if v882 then
			v891 = v_u_6
		else
			v891 = v_u_12
		end
		v883(v884, v885, v886, v887, v889, v890, v891, 3)
		if not v882 then
			continue
		end
		local v892 = v871.polar
		local v893 = (v881 - v_u_872.min) / (v_u_872.max - v_u_872.min)
		local v894, v895 = v892(300, 186, 116, -135 + 270 * math.clamp(v893, 0, 1))
		v871.label(tostring(v881), v871.NUM, 18, v_u_6, v894, v895, 40, {
			["ZIndex"] = 3
		})
	end
	local v_u_896 = v871.needle(300, 186, 152, 8, v_u_9, 4)
	v871.circle(300, 186, 30, v_u_9, 5)
	local v_u_897 = v871.label("", v871.HEAVY, 38, v_u_6, 300, 268, 200, {
		["ZIndex"] = 3
	})
	local v_u_898 = v871.label("", v871.THAI, 18, v_u_12, 300, 304, 240, {
		["ZIndex"] = 3
	})
	v871.press(138, 24, 324, 324, function(p899)
		-- upvalues: (copy) v_u_873, (copy) p_u_870, (copy) v_u_872
		local v_u_900 = v_u_873
		local v_u_901 = nil
		local function v_u_912(p902)
			-- upvalues: (copy) v_u_900, (ref) v_u_901
			local v903 = v_u_900
			local v904 = v903.AbsolutePosition + v903.AbsoluteSize / 2
			local v905 = Vector2.new(p902.X, p902.Y) - v904
			local v906 = v905.X
			local v907 = -v905.Y
			local v908 = math.atan2(v906, v907)
			local v909 = math.deg(v908)
			if v_u_901 then
				local v910 = v909 - v_u_901
				v909 = math.abs(v910) > 180 and (v_u_901 > 0 and 135 or -135) or v909
			end
			local v911 = math.clamp(v909, -135, 135)
			v_u_901 = v911
			return (v911 + 135) / 270
		end
		local function v918(p913) -- name: to
			-- upvalues: (ref) p_u_870, (ref) v_u_872, (copy) v_u_912
			local v914 = p_u_870.set
			local v915 = p_u_870.pick()
			local v916 = v_u_872
			local v917 = v_u_912(p913)
			v914(v915, v916.min + (v916.max - v916.min) * math.clamp(v917, 0, 1))
		end
		local v919 = p899.Position
		local v920 = p_u_870.set
		local v921 = p_u_870.pick()
		local v922 = v_u_872
		local v923 = v_u_912(v919)
		v920(v921, v922.min + (v922.max - v922.min) * math.clamp(v923, 0, 1))
		p_u_870.beginDrag(v918)
		p_u_870.redraw()
	end).Name = "Wheel"
	v871.card(620, 0, 510, 372)
	v871.label("\224\184\151\224\184\177\224\185\137\224\184\135\224\185\129\224\184\156\224\184\153\224\184\151\224\184\181\224\185\136", v871.THAI, 21, v_u_12, 875, 26, 300)
	local v924 = 470 / v_u_17
	local v_u_925 = {}
	for v_u_926 = 1, v_u_17 do
		local v927 = 640 + (v_u_926 - 0.5) * v924
		local v928, v929 = v871.box(v927 - 13, 70, 26, 274)
		local v930 = {
			["BorderSizePixel"] = 0,
			["BackgroundColor3"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = Color3.fromRGB(10, 3, 0),
			["Position"] = v928,
			["Size"] = v929
		}
		local v931 = v_u_1.new("Frame")
		for v932, v933 in v930 do
			v931[v932] = v933
		end
		v931.Parent = p869
		v_u_26(v931, 4)
		local v934 = {
			["BorderSizePixel"] = 0,
			["BackgroundColor3"] = nil,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_9,
			["AnchorPoint"] = Vector2.new(0, 1),
			["Position"] = UDim2.fromScale(0, 1),
			["Size"] = UDim2.fromScale(1, 0.5)
		}
		local v935 = v_u_1.new("Frame")
		for v936, v937 in v934 do
			v935[v936] = v937
		end
		v935.Parent = v931
		v_u_26(v935, 4)
		v871.label(v_u_872.xs[v_u_926], v871.NUM, 13, v_u_12, v927, 358, v924)
		v871.press(v927 - v924 / 2, 70, v924, 298, function()
			-- upvalues: (copy) p_u_870, (copy) v_u_926
			p_u_870.setPick(v_u_926)
			p_u_870.redraw()
		end)
		v_u_925[v_u_926] = v935
	end
	local v_u_938 = {}
	for v939, v940 in v_u_4.BANDS do
		local v941 = 640 + (v940[1] - 1) * v924
		local v942 = 640 + v940[2] * v924
		v_u_938[v939] = v871.label("", v871.THAI, 18, v_u_15, (v941 + v942) / 2, 50, v942 - v941)
	end
	local v_u_943 = v_u_202(v871, v_u_872, 438, 100, 386, 42)
	function v871.update() -- name: update
		-- upvalues: (copy) p_u_870, (copy) v_u_896, (copy) v_u_872, (copy) v_u_897, (ref) v_u_11, (ref) v_u_6, (copy) v_u_898, (copy) v_u_925, (ref) v_u_9, (copy) v_u_943, (ref) v_u_4, (ref) v_u_18, (ref) v_u_15, (copy) v_u_938, (ref) v_u_13, (ref) v_u_12
		local v944 = p_u_870.values()
		local v945 = p_u_870.pick()
		local v946 = v_u_896
		local v947 = v_u_872
		local v948 = (v944[v945] - v947.min) / (v947.max - v947.min)
		v946.Rotation = -135 + 270 * math.clamp(v948, 0, 1)
		v_u_897.Text = p_u_870.veiled() and "\226\128\162\226\128\162" or v_u_872.fmt:format(v944[v945])
		local v949 = v_u_897
		local v950
		if p_u_870.changed(v945) then
			v950 = v_u_11
		else
			v950 = v_u_6
		end
		v949.TextColor3 = v950
		local v951 = v_u_898
		local v952 = "\224\184\173\224\184\135\224\184\168\224\184\178\224\185\132\224\184\159\224\185\129\224\184\129\224\185\136 \194\183 %s rpm"
		local v953 = v_u_872.xs[v945]
		local v954 = v953:match("^(%d+)k$")
		if v954 then
			local v955 = tonumber(v954) * 1000
			v953 = tostring(v955)
		end
		v951.Text = v952:format(v953)
		for v956, v957 in v_u_925 do
			local v958 = UDim2.fromScale
			local v959 = v_u_872
			local v960 = (v944[v956] - v959.min) / (v959.max - v959.min)
			v957.Size = v958(1, (math.clamp(v960, 0, 1)))
			local v961
			if v956 == v945 then
				v961 = v_u_6
			elseif p_u_870.changed(v956) then
				v961 = v_u_11
			else
				v961 = v_u_9
			end
			v957.BackgroundColor3 = v961
		end
		v_u_943.update()
		local v962 = p_u_870.hint()
		for v963 = 1, #v_u_4.BANDS do
			local v964
			if type(v962) == "table" then
				v964 = v962[v963]
			else
				v964 = nil
			end
			if v964 == true then
				v_u_943.setBand(v963, v_u_18[v963] .. ": \224\184\153\224\185\135\224\184\173\224\184\132! \224\185\132\224\184\159\224\185\129\224\184\129\224\185\136\224\185\132\224\184\155", v_u_15)
				v_u_938[v963].Text = "\224\184\153\224\185\135\224\184\173\224\184\132!"
			elseif v964 == false then
				v_u_943.setBand(v963, v_u_18[v963] .. ": \224\185\132\224\184\161\224\185\136\224\184\153\224\185\135\224\184\173\224\184\132", v_u_13)
				v_u_938[v963].Text = ""
			else
				v_u_943.setBand(v963, v_u_18[v963] .. ": \224\185\129\224\184\159\224\184\165\224\184\138\224\185\128\224\184\158\224\184\183\224\185\136\224\184\173\224\184\159\224\184\177\224\184\135\224\185\128\224\184\170\224\184\181\224\184\162\224\184\135\224\184\153\224\185\135\224\184\173\224\184\132", v_u_12)
				v_u_938[v963].Text = ""
			end
		end
	end
	return v871
end
function v_u_5.Knobs(p965, p_u_966) -- name: Knobs
	-- upvalues: (copy) v_u_150, (copy) v_u_13, (copy) v_u_1, (copy) v_u_2, (copy) v_u_268, (copy) v_u_17, (copy) v_u_12, (copy) v_u_6, (copy) v_u_9, (copy) v_u_11
	local v_u_967 = v_u_150(p965, p_u_966)
	local v_u_968 = p_u_966.t()
	local v969 = v_u_967.card(0, 0, v_u_967.W, 150, Color3.fromRGB(4, 20, 10))
	for v970 = 1, 9 do
		local v971 = {
			["BorderSizePixel"] = 0,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.88,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_13,
			["Position"] = UDim2.fromScale(v970 / 10, 0),
			["Size"] = UDim2.new(0, 1, 1, 0)
		}
		local v972 = v_u_1.new("Frame")
		for v973, v974 in v971 do
			v972[v973] = v974
		end
		v972.Parent = v969
	end
	for v975 = 1, 3 do
		local v976 = {
			["BorderSizePixel"] = 0,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_13,
			["BackgroundTransparency"] = v975 == 2 and 0.75 or 0.88,
			["Position"] = UDim2.fromScale(0, v975 / 4),
			["Size"] = UDim2.new(1, 0, 0, 1)
		}
		local v977 = v_u_1.new("Frame")
		for v978, v979 in v976 do
			v977[v978] = v979
		end
		v977.Parent = v969
	end
	v_u_967.text(v969, "\224\184\163\224\184\173\224\184\154\224\185\128\224\184\148\224\184\180\224\184\153\224\185\128\224\184\154\224\184\178", v_u_967.THAI, 22, v_u_13, {
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["Position"] = UDim2.fromOffset(16, 6),
		["Size"] = UDim2.fromOffset(300, 30)
	})
	local v_u_980 = v_u_967.text(v969, "", v_u_967.THAI, 22, v_u_13, {
		["TextXAlignment"] = Enum.TextXAlignment.Right,
		["AnchorPoint"] = Vector2.new(1, 0),
		["Position"] = UDim2.new(1, -16, 0, 6),
		["Size"] = UDim2.fromOffset(360, 30)
	})
	local v_u_981 = {}
	for v982 = 1, 64 do
		local v983 = {
			["BorderSizePixel"] = 0,
			["BackgroundColor3"] = nil,
			["AnchorPoint"] = nil,
			["Size"] = nil,
			["ZIndex"] = 3,
			["BackgroundColor3"] = v_u_13,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Size"] = UDim2.fromOffset(10, 4)
		}
		local v984 = v_u_1.new("Frame")
		for v985, v986 in v983 do
			v984[v985] = v986
		end
		v984.Parent = v969
		v_u_981[v982] = v984
	end
	local v_u_987 = 0
	local v_u_988 = 0
	local v989 = v_u_967.conns
	local v990 = v_u_2.RenderStepped
	local function v1016(p991)
		-- upvalues: (ref) v_u_988, (copy) p_u_966, (ref) v_u_987, (copy) v_u_967, (copy) v_u_981
		v_u_988 = v_u_988 + p991 * p_u_966.soundSetting("Idle")
		local v992 = p_u_966.match()
		local v993 = type(v992) == "number"
		local v994
		if v993 then
			local v995 = 1 - v992
			v994 = math.clamp(v995, 0, 1) ^ 0.6 * 60 + 2
		else
			v994 = 24
		end
		local v996 = v_u_987
		local v997 = v994 - v_u_987
		local v998 = p991 * 3
		v_u_987 = v996 + v997 * math.min(1, v998)
		local v999 = v_u_967.W
		local v1000 = nil
		for v1001 = 0, 64 do
			local v1002 = v999 * v1001 / 64
			local v1003 = v_u_988 * 5 + v1001 * 0.42
			local v1004 = math.sin(v1003)
			local v1005 = v1001 * 0.13 + v_u_988 * 1.3
			local v1006 = v_u_987 * (v1004 * (math.sin(v1005) * 0.35 + 0.65)) + 75
			local v1007 = v_u_988 * 23 + v1001 * 2.1
			local v1008 = v1006 + math.sin(v1007) * v_u_987 * 0.08
			local v1009 = Vector2.new(v1002, v1008)
			if v1000 then
				local v1010 = v_u_981[v1001]
				local v1011 = (v1000 + v1009) / 2
				local v1012 = v1009 - v1000
				v1010.Position = UDim2.fromScale(v1011.X / v999, v1011.Y / 150)
				v1010.Size = UDim2.fromOffset(v1012.Magnitude + 2, 4)
				local v1013 = v1012.Y
				local v1014 = v1012.X
				local v1015 = math.atan2(v1013, v1014)
				v1010.Rotation = math.deg(v1015)
				v1010.BackgroundTransparency = v993 and 0 or 0.7
			end
			v1000 = v1009
		end
	end
	table.insert(v989, v990:Connect(v1016))
	local v_u_1017 = v_u_268(v_u_967, "Idle", 184, "\224\185\128\224\184\148\224\184\180\224\184\153\224\185\128\224\184\154\224\184\178")
	local v1018 = v_u_967.W / v_u_17
	local v_u_1019 = {}
	for v_u_1020 = 1, v_u_17 do
		local v1021 = (v_u_1020 - 0.5) * v1018
		local v1022 = {}
		local v1023 = v_u_967.label
		local v1024 = v_u_968.xs[v_u_1020]
		local v1025 = v1024:match("^(%d+)k$")
		if v1025 then
			local v1026 = tonumber(v1025) * 1000
			v1024 = tostring(v1026)
		end
		v1022.rpm = v1023(v1024, v_u_967.NUM, 17, v_u_12, v1021, 248, v1018)
		for v1027 = 0, 8 do
			v_u_967.tick(v1021, 328, 50, (v1027 % 4 == 0 and 13 or 9) + 46, v1027 * 270 / 8 + -135, 2, v_u_6)
		end
		v1022.body = v_u_967.circle(v1021, 328, 92, Color3.fromRGB(40, 43, 56), 2)
		local v1028 = {
			["Rotation"] = 45,
			["Color"] = nil,
			["Color"] = ColorSequence.new(Color3.fromRGB(70, 74, 92), Color3.fromRGB(20, 22, 28))
		}
		local v1029 = v1022.body
		local v1030 = v_u_1.new("UIGradient")
		for v1031, v1032 in v1028 do
			v1030[v1031] = v1032
		end
		v1030.Parent = v1029
		local v1033 = {
			["Color"] = nil,
			["Thickness"] = 2,
			["Transparency"] = 0.5,
			["Color"] = v_u_6
		}
		local v1034 = v1022.body
		local v1035 = v_u_1.new("UIStroke")
		for v1036, v1037 in v1033 do
			v1035[v1036] = v1037
		end
		v1035.Parent = v1034
		v1022.stroke = v1035
		v1022.pointer = v_u_967.needle(v1021, 328, 38, 7, v_u_9, 4)
		v1022.value = v_u_967.label("", v_u_967.HEAVY, 22, v_u_6, v1021, 404, v1018)
		v_u_967.press(v1021 - v1018 / 2, 266, v1018, 124, function(p1038)
			-- upvalues: (copy) p_u_966, (copy) v_u_1020, (copy) v_u_968
			p_u_966.setPick(v_u_1020)
			local v_u_1039 = p1038.Position.Y
			local v_u_1040 = p_u_966.values()[v_u_1020]
			p_u_966.beginDrag(function(p1041)
				-- upvalues: (copy) v_u_1039, (ref) p_u_966, (ref) v_u_1020, (copy) v_u_1040, (ref) v_u_968
				local v1042 = p1041.Y - v_u_1039
				local v1043 = p_u_966.scale()
				local v1044 = v1042 / math.max(v1043, 0.01)
				p_u_966.set(v_u_1020, v_u_1040 - v1044 * (v_u_968.max - v_u_968.min) / 300)
			end)
			p_u_966.redraw()
		end)
		v_u_1019[v_u_1020] = v1022
	end
	v_u_967.label("\224\184\165\224\184\178\224\184\129\224\184\130\224\184\182\224\185\137\224\184\153-\224\184\165\224\184\135\224\184\154\224\184\153\224\184\155\224\184\184\224\185\136\224\184\161\224\185\128\224\184\158\224\184\183\224\185\136\224\184\173\224\184\171\224\184\161\224\184\184\224\184\153  \194\183  \224\184\132\224\184\165\224\184\183\224\185\136\224\184\153\224\184\162\224\184\180\224\185\136\224\184\135\224\184\153\224\184\180\224\185\136\224\184\135 \224\184\162\224\184\180\224\185\136\224\184\135\224\185\131\224\184\129\224\184\165\224\185\137\224\184\132\224\185\136\224\184\178\224\184\151\224\184\181\224\185\136\224\184\150\224\184\185\224\184\129 (\224\184\148\224\184\185\224\184\171\224\184\165\224\184\177\224\184\135\224\185\129\224\184\159\224\184\165\224\184\138)", v_u_967.THAI, 22, v_u_12, v_u_967.W / 2, 474, v_u_967.W)
	function v_u_967.update() -- name: update
		-- upvalues: (copy) v_u_1017, (copy) p_u_966, (copy) v_u_1019, (copy) v_u_968, (ref) v_u_11, (ref) v_u_6, (ref) v_u_9, (ref) v_u_12, (copy) v_u_980
		v_u_1017()
		local v1045 = p_u_966.values()
		local v1046 = p_u_966.pick()
		for v1047, v1048 in v_u_1019 do
			local v1049 = v1048.pointer
			local v1050 = v_u_968
			local v1051 = (v1045[v1047] - v1050.min) / (v1050.max - v1050.min)
			v1049.Rotation = -135 + 270 * math.clamp(v1051, 0, 1)
			v1048.value.Text = p_u_966.veiled() and "\226\128\162\226\128\162" or v_u_968.fmt:format(v1045[v1047])
			local v1052 = v1048.value
			local v1053
			if p_u_966.changed(v1047) then
				v1053 = v_u_11
			else
				v1053 = v_u_6
			end
			v1052.TextColor3 = v1053
			local v1054 = v1048.stroke
			local v1055
			if v1047 == v1046 then
				v1055 = v_u_9
			else
				v1055 = v_u_6
			end
			v1054.Color = v1055
			v1048.stroke.Thickness = v1047 == v1046 and 5 or 2
			v1048.stroke.Transparency = v1047 == v1046 and 0 or 0.5
			local v1056 = v1048.rpm
			local v1057
			if v1047 == v1046 then
				v1057 = v_u_6
			else
				v1057 = v_u_12
			end
			v1056.TextColor3 = v1057
		end
		local v1058 = p_u_966.match()
		local v1059 = v_u_980
		local v1060
		if type(v1058) == "number" then
			local v1061 = v1058 * 1000 + 0.5
			v1060 = ("\224\184\153\224\184\180\224\185\136\224\184\135 %.1f %%"):format(math.floor(v1061) / 10)
		else
			v1060 = "\224\185\129\224\184\159\224\184\165\224\184\138\224\185\128\224\184\158\224\184\183\224\185\136\224\184\173\224\184\148\224\184\185\224\184\163\224\184\173\224\184\154\224\185\128\224\184\148\224\184\180\224\184\153\224\185\128\224\184\154\224\184\178"
		end
		v1059.Text = v1060
	end
	return v_u_967
end
function v_u_5.SoundRows(p1062, p1063) -- name: SoundRows
	-- upvalues: (copy) v_u_150, (copy) v_u_268
	local v1064 = v_u_150(p1062, p1063)
	local v_u_1065 = v_u_268(v1064, "Rev", 330, "\224\184\132\224\184\177\224\184\153\224\185\128\224\184\163\224\185\136\224\184\135")
	local v_u_1066 = v_u_268(v1064, "Idle", 430, "\224\185\128\224\184\148\224\184\180\224\184\153\224\185\128\224\184\154\224\184\178")
	function v1064.update() -- name: update
		-- upvalues: (copy) v_u_1065, (copy) v_u_1066
		v_u_1065()
		v_u_1066()
	end
	v1064.update()
	return v1064
end
function v_u_5.new(p1067, p1068, p1069) -- name: new
	-- upvalues: (copy) v_u_5
	local v1070 = (v_u_5[p1067] or v_u_5.Graph)(p1068, p1069)
	v1070.update()
	return v1070
end
return v_u_5