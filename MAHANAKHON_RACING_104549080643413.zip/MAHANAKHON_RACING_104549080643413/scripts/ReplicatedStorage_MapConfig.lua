-- Path: ReplicatedStorage/MapConfig
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v1 = {
	["TELEPORTS"] = {
		{
			["id"] = "race",
			["group"] = "1v1 Race",
			["th"] = "1v1 Drag Race lobby (4 tracks)",
			["en"] = "Stand on a pad, bet, pick a ride, race 402 m",
			["foot"] = nil,
			["car"] = nil,
			["foot"] = CFrame.new(-11988, 1.7, 866, 1, 0, 0, 0, 1, 0, 0, 0, 1),
			["car"] = CFrame.new(-11964, 0.48, 866, 1, 0, 0, 0, 1, 0, 0, 0, 1)
		},
		{
			["id"] = "south",
			["group"] = "Charan Sanit Wong Rd.",
			["th"] = "Start of Charan Rd. (Tha Phra side)",
			["en"] = "South End",
			["foot"] = nil,
			["car"] = nil,
			["foot"] = CFrame.new(0, 0.8, -3432, -1, 0, -0, 0, 1, -0, 0, -0, -1),
			["car"] = CFrame.new(14, 0, -3462, -1, 0, -0, 0, 1, -0, 0, -0, -1)
		},
		{
			["id"] = "dragstrip",
			["group"] = "Drag Strip",
			["th"] = "Drag strip (start line) + AUTOWORKS",
			["en"] = "4-lane straight, 1600 m timed",
			["foot"] = nil,
			["car"] = nil,
			["foot"] = CFrame.new(-74, 0.8, -3480, 1, 0, 0, 0, 1, 0, 0, 0, 1),
			["car"] = CFrame.new(-34, 0, -3460, 1, 0, 0, 0, 1, 0, 0, 0, 1)
		},
		{
			["id"] = "tune_east",
			["group"] = "Tuning Shops",
			["th"] = "AUTOWORKS East (East Ring Road)",
			["en"] = "Tuning shop + dyno, north-east",
			["foot"] = nil,
			["car"] = nil,
			["foot"] = CFrame.new(1215.995, 2.115, 1602.655, 0, 0, -1, 0, 1, 0, 1, 0, 0),
			["car"] = CFrame.new(1215.995, 0.915, 1608.655, 0, 0, -1, 0, 1, 0, 1, 0, 0)
		},
		{
			["id"] = "tune_west",
			["group"] = "Tuning Shops",
			["th"] = "AUTOWORKS West (West Ring Road)",
			["en"] = "Tuning shop + dyno, south-west",
			["foot"] = nil,
			["car"] = nil,
			["foot"] = CFrame.new(-1215.995, 2.115, -2002.655, -0, 0, 1, 0, 1, 0, -1, 0, -0),
			["car"] = CFrame.new(-1215.995, 0.915, -2008.655, -0, 0, 1, 0, 1, 0, -1, 0, -0)
		},
		{
			["id"] = "tune_drag",
			["group"] = "Tuning Shops",
			["th"] = "AUTOWORKS Drag Strip (out of town)",
			["en"] = "Tuning shop + dyno, by the drag strip start",
			["foot"] = nil,
			["car"] = nil,
			["foot"] = CFrame.new(100.495, 2.115, -3602.345, 0, 0, -1, 0, 1, 0, 1, 0, 0),
			["car"] = CFrame.new(100.495, 0.915, -3596.345, 0, 0, -1, 0, 1, 0, 1, 0, 0)
		},
		{
			["id"] = "gas",
			["group"] = "Gas Station",
			["th"] = "SIAM OIL Gas Station",
			["en"] = "Fuel Station",
			["foot"] = nil,
			["car"] = nil,
			["foot"] = CFrame.new(122.625, 1.62, -396.95, 0, 0, -1, 0, 1, 0, 1, 0, 0),
			["car"] = CFrame.new(107.625, 0.82, -404.45, 0, 0, -1, 0, 1, 0, 1, 0, 0)
		},
		{
			["id"] = "gas_ring",
			["group"] = "Gas Station",
			["th"] = "Gas Station + Minimart (East Ring Road)",
			["en"] = "Ring Road Fuel Station",
			["foot"] = nil,
			["car"] = nil,
			["foot"] = CFrame.new(1030, 0.2, -300, 0, 0, 1, 0, 1, -0, -1, 0, -0),
			["car"] = CFrame.new(1050, 0, -300, 0, 0, 1, 0, 1, -0, -1, 0, -0)
		},
		{
			["id"] = "village",
			["group"] = "Village",
			["th"] = "Rom Mai 2 Village (car park)",
			["en"] = "Housing Estate",
			["foot"] = nil,
			["car"] = nil,
			["foot"] = CFrame.new(478, 0.25, 2598, 0, 0, -1, 0, 1, -0, 1, 0, -0),
			["car"] = CFrame.new(478, 0.25, 2578, 0, 0, -1, 0, 1, -0, 1, 0, -0)
		}
	}
}
return v1