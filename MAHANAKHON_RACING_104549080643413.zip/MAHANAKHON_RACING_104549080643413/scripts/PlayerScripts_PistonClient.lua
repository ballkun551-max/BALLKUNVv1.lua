-- Path: Players/ygggggg55551/PlayerScripts/PistonClient
-- Class: LocalScript  true/Enum.RunContext.Legacy
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = require(game:GetService("ReplicatedStorage"):WaitForChild("NetSeal"))
local v2 = game:GetService("Players")
local v3 = game:GetService("ProximityPromptService")
local v4 = game:GetService("ReplicatedStorage")
local v_u_5 = require(v4:WaitForChild("GameShared"))
local v_u_6 = require(v4:WaitForChild("PistonShared"))
local v7 = v4:WaitForChild("GameUI")
local v_u_8 = require(v7:WaitForChild("Theme"))
local v_u_9 = require(v7:WaitForChild("Toast"))
local v10 = require(v7:WaitForChild("Icons"))
local v_u_11 = v2.LocalPlayer
local v12 = v4:WaitForChild(v_u_5.REMOTES)
local v_u_13 = v12:WaitForChild(v_u_6.REMOTE)
local v14 = v12:WaitForChild("PistonOpen")
local v_u_15 = v_u_8.YELLOW
local v_u_16 = v_u_8.TEXT_DIM
local v_u_17 = v_u_8.screen("PistonShop", 20, v_u_11:WaitForChild("PlayerGui"))
local v_u_18 = {}
local function v_u_23(p19) -- name: readBag
	local v20 = {}
	for v21, v22 in p19 do
		if not (tonumber(v21) and tonumber(v22)) then
			continue
		end
		v20[tonumber(v21)] = tonumber(v22)
	end
	return v20
end
local function v_u_29() -- name: refreshBag
	-- upvalues: (copy) v_u_1, (copy) v_u_13, (ref) v_u_18, (copy) v_u_23
	local v24 = v_u_1.invoke
	local v25 = v_u_13
	local v26, v27, v28 = pcall(v24, v25, "Bag")
	if v26 and (v27 and type(v28) == "table") then
		v_u_18 = v_u_23(v28)
	end
end
local v_u_30 = {
	{
		["upTo"] = 62,
		["name"] = "STREET",
		["text"] = nil,
		["colors"] = nil,
		["text"] = Color3.new(1, 1, 1),
		["colors"] = { Color3.fromRGB(110, 190, 255), Color3.fromRGB(40, 110, 230) }
	},
	{
		["upTo"] = 75,
		["name"] = "RACE",
		["text"] = nil,
		["colors"] = nil,
		["text"] = v_u_8.DARK_TEXT,
		["colors"] = { Color3.fromRGB(255, 176, 84), Color3.fromRGB(236, 96, 30) }
	},
	{
		["upTo"] = (1 / 0),
		["name"] = "PRO",
		["text"] = nil,
		["colors"] = nil,
		["text"] = v_u_8.DARK_TEXT,
		["colors"] = v_u_8.GRAD.gold
	}
}
local v31 = v_u_6.TIERS[v_u_6.FULL_SIZE].accel - 1
local v32 = { Color3.fromRGB(48, 52, 70), Color3.fromRGB(26, 28, 38) }
local v_u_33 = { Color3.fromRGB(90, 92, 104), Color3.fromRGB(64, 66, 78) }
local v34 = { Color3.fromRGB(14, 16, 22), Color3.fromRGB(14, 16, 22) }
local function v_u_43(p35, p36, p37, p38, p39, p40) -- name: chip
	-- upvalues: (copy) v_u_8
	local v41 = p39 or 18
	local v42 = v_u_8.new("Frame", {
		["Name"] = "Chip",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = Color3.new(1, 1, 1),
		["Size"] = UDim2.fromOffset(0, v41),
		["AutomaticSize"] = Enum.AutomaticSize.X,
		["LayoutOrder"] = p40 or 0,
		["Parent"] = p35
	})
	v_u_8.corner(v42, v41 / 2)
	v_u_8.gradient(v42, p37)
	v_u_8.new("UIPadding", {
		["PaddingLeft"] = UDim.new(0, 8),
		["PaddingRight"] = UDim.new(0, 8),
		["Parent"] = v42
	})
	return v42, v_u_8.text({
		["Text"] = p36,
		["TextSize"] = v41 > 20 and 14 or 11,
		["FontFace"] = v_u_8.FONT_HEAVY,
		["TextColor3"] = p38,
		["Size"] = UDim2.fromScale(0, 1),
		["AutomaticSize"] = Enum.AutomaticSize.X,
		["Parent"] = v42
	})
end
local v44 = v_u_8.isTouch()
local v_u_45 = v_u_8.window({
	["gui"] = nil,
	["name"] = "PistonShopWindow",
	["title"] = "\224\184\163\224\185\137\224\184\178\224\184\153\224\184\165\224\184\185\224\184\129\224\184\170\224\184\185\224\184\154\224\184\139\224\184\180\224\185\136\224\184\135",
	["sub"] = "",
	["icon"] = "settings",
	["grad"] = "red",
	["size"] = nil,
	["max"] = nil,
	["gui"] = v_u_17,
	["size"] = Vector2.new(0.74, 0.86),
	["max"] = Vector2.new(1040, 720)
})
local v_u_46 = v_u_8.new("ScrollingFrame", {
	["BackgroundTransparency"] = 1,
	["BorderSizePixel"] = 0,
	["ScrollBarThickness"] = 5,
	["ScrollBarImageColor3"] = nil,
	["CanvasSize"] = nil,
	["AutomaticCanvasSize"] = nil,
	["ScrollingDirection"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["ScrollBarImageColor3"] = v_u_16,
	["CanvasSize"] = UDim2.new(),
	["AutomaticCanvasSize"] = Enum.AutomaticSize.Y,
	["ScrollingDirection"] = Enum.ScrollingDirection.Y,
	["Size"] = UDim2.new(1, 0, 1, -68),
	["Parent"] = v_u_45.body
})
local v_u_47 = v_u_8.new("UIGridLayout", {
	["CellSize"] = UDim2.new(0.2, -8, 0, 150),
	["CellPadding"] = UDim2.fromOffset(10, 10),
	["SortOrder"] = Enum.SortOrder.LayoutOrder,
	["Parent"] = v_u_46
})
v_u_8.padding(v_u_46, 2, 2)
local v_u_48 = v_u_45.panel:FindFirstChildOfClass("UIScale")
v_u_46:GetPropertyChangedSignal("AbsoluteSize"):Connect(function()
	-- upvalues: (copy) v_u_46, (copy) v_u_48, (copy) v_u_47
	local v49 = v_u_46.AbsoluteSize.Y
	local v50 = not v_u_48 and 1 or v_u_48.Scale
	local v51 = v49 / math.max(v50, 0.01)
	local v52 = v_u_47
	local v53 = UDim2.new
	local v54 = (v51 - 14) / 2
	local v55 = math.floor(v54)
	v52.CellSize = v53(0.2, -8, 0, (math.max(150, v55)))
end)
local v56 = v44 and 128 or 160
local v57 = v44 and 164 or 200
local v58 = -(v56 + v57 + 24)
local v59 = v_u_8.new("Frame", {
	["BackgroundColor3"] = nil,
	["BackgroundTransparency"] = 0.25,
	["BorderSizePixel"] = 0,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["BackgroundColor3"] = v_u_8.CARD_DARK,
	["AnchorPoint"] = Vector2.new(0, 1),
	["Position"] = UDim2.fromScale(0, 1),
	["Size"] = UDim2.new(1, 0, 0, 58),
	["Parent"] = v_u_45.body
})
v_u_8.corner(v59, 14)
v_u_8.border(v59, Color3.new(1, 1, 1), 0.9, 1)
v_u_8.padding(v59, 12, 6)
local v_u_60 = v_u_8.new("Frame", {
	["BackgroundTransparency"] = 1,
	["Size"] = nil,
	["ClipsDescendants"] = true,
	["Parent"] = nil,
	["Size"] = UDim2.new(1, v58, 0, 24),
	["Parent"] = v59
})
v_u_8.new("UIListLayout", {
	["FillDirection"] = Enum.FillDirection.Horizontal,
	["VerticalAlignment"] = Enum.VerticalAlignment.Center,
	["Padding"] = UDim.new(0, 6),
	["SortOrder"] = Enum.SortOrder.LayoutOrder,
	["Parent"] = v_u_60
})
local v61 = v10.make("bag", v_u_16, 18)
v61.LayoutOrder = -2
v61.Parent = v_u_60
v_u_8.text({
	["Text"] = "\224\184\129\224\184\163\224\184\176\224\185\128\224\184\155\224\185\139\224\184\178",
	["TextSize"] = 14,
	["FontFace"] = nil,
	["TextColor3"] = nil,
	["Size"] = nil,
	["AutomaticSize"] = nil,
	["LayoutOrder"] = -1,
	["Parent"] = nil,
	["FontFace"] = v_u_8.FONT_BOLD,
	["TextColor3"] = v_u_16,
	["Size"] = UDim2.fromScale(0, 1),
	["AutomaticSize"] = Enum.AutomaticSize.X,
	["Parent"] = v_u_60
})
local v_u_62 = v_u_8.text({
	["Text"] = "\224\184\162\224\184\177\224\184\135\224\184\167\224\185\136\224\184\178\224\184\135",
	["TextSize"] = 14,
	["TextColor3"] = nil,
	["Size"] = nil,
	["AutomaticSize"] = nil,
	["LayoutOrder"] = 0,
	["Parent"] = nil,
	["TextColor3"] = v_u_8.TEXT,
	["Size"] = UDim2.fromScale(0, 1),
	["AutomaticSize"] = Enum.AutomaticSize.X,
	["Parent"] = v_u_60
})
v_u_8.text({
	["Text"] = "\224\184\150\224\184\183\224\184\173\224\184\165\224\184\185\224\184\129\224\184\170\224\184\185\224\184\154 \224\185\129\224\184\165\224\185\137\224\184\167\224\184\129\224\184\148 E \224\184\151\224\184\181\224\185\136\224\184\163\224\184\150\224\184\130\224\184\173\224\184\135\224\184\132\224\184\184\224\184\147\224\185\128\224\184\158\224\184\183\224\185\136\224\184\173\224\185\131\224\184\170\224\185\136 (\224\185\131\224\184\138\224\185\137\224\185\128\224\184\167\224\184\165\224\184\178 5 \224\184\167\224\184\180)",
	["TextSize"] = 12,
	["TextColor3"] = nil,
	["TextXAlignment"] = nil,
	["TextTruncate"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["TextColor3"] = v_u_16,
	["TextXAlignment"] = Enum.TextXAlignment.Left,
	["TextTruncate"] = Enum.TextTruncate.AtEnd,
	["Position"] = UDim2.fromOffset(0, 28),
	["Size"] = UDim2.new(1, v58, 0, 16),
	["Parent"] = v59
})
local v63 = v_u_8.button({
	["text"] = "\224\184\165\224\184\185\224\184\129\224\185\132\224\184\171\224\184\153\224\185\131\224\184\170\224\185\136\224\184\132\224\184\177\224\184\153\224\185\132\224\184\171\224\184\153",
	["icon"] = "car",
	["grad"] = "blue",
	["textSize"] = 15,
	["size"] = nil,
	["anchor"] = nil,
	["position"] = nil,
	["parent"] = nil,
	["radius"] = 10,
	["size"] = UDim2.fromOffset(v57, 40),
	["anchor"] = Vector2.new(1, 0.5),
	["position"] = UDim2.new(1, -(v56 + 12), 0.5, 0),
	["parent"] = v59
})
local v64 = v_u_8.new("Frame", {
	["BackgroundColor3"] = nil,
	["BackgroundTransparency"] = 0.15,
	["BorderSizePixel"] = 0,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["BackgroundColor3"] = Color3.fromRGB(10, 12, 16),
	["AnchorPoint"] = Vector2.new(1, 0.5),
	["Position"] = UDim2.new(1, 0, 0.5, 0),
	["Size"] = UDim2.fromOffset(v56, 44),
	["Parent"] = v59
})
v_u_8.corner(v64, 10)
v_u_8.border(v64, v_u_8.GREEN_TEXT, 0.7, 1)
v_u_8.text({
	["Text"] = "\224\185\128\224\184\135\224\184\180\224\184\153\224\184\130\224\184\173\224\184\135\224\184\132\224\184\184\224\184\147",
	["TextSize"] = 11,
	["TextColor3"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["TextColor3"] = v_u_16,
	["Position"] = UDim2.fromOffset(0, 3),
	["Size"] = UDim2.new(1, 0, 0, 14),
	["Parent"] = v64
})
local v_u_65 = v_u_8.text({
	["Text"] = "",
	["TextSize"] = 18,
	["FontFace"] = nil,
	["TextColor3"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["TextScaled"] = true,
	["Parent"] = nil,
	["FontFace"] = v_u_8.FONT_DIGITS,
	["TextColor3"] = v_u_8.GREEN_TEXT,
	["Position"] = UDim2.fromOffset(6, 17),
	["Size"] = UDim2.new(1, -12, 0, 20),
	["Parent"] = v64
})
v_u_8.new("UITextSizeConstraint", {
	["MaxTextSize"] = 18,
	["MinTextSize"] = 9,
	["Parent"] = nil,
	["Parent"] = v_u_65
})
local function v_u_73() -- name: drawBag
	-- upvalues: (copy) v_u_60, (copy) v_u_6, (ref) v_u_18, (copy) v_u_30, (copy) v_u_43, (copy) v_u_62
	for _, v66 in v_u_60:GetChildren() do
		if v66.Name ~= "Chip" then
			continue
		end
		v66:Destroy()
	end
	local v67 = false
	for v68, v69 in v_u_6.SIZES do
		local v70 = v_u_18[v69] or 0
		if v70 <= 0 then
			continue
		end
		v67 = true
		for _, v72 in v_u_30 do
			if v69 > v72.upTo then
				continue
			end
		end
		local v72 = v_u_30[#v_u_30]
		v_u_43(v_u_60, ("%d \195\151%d"):format(v69, v70), v72.colors, v72.text, 22, v68)
	end
	v_u_62.Visible = not v67
end
local v_u_74 = v_u_18
local v_u_75 = {}
local function v_u_80(p76, p77, p78) -- name: card
	-- upvalues: (copy) v_u_8
	local v79 = v_u_8.new("Frame", {
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.05,
		["BorderSizePixel"] = 0,
		["LayoutOrder"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_8.CARD,
		["LayoutOrder"] = p77,
		["Size"] = UDim2.new(1, 0, 0, p78 or 0),
		["Parent"] = p76
	})
	v_u_8.corner(v79, 14)
	v_u_8.border(v79)
	return v79
end
for v81, v82 in v_u_6.SIZES do
	for _, v84 in v_u_30 do
		if v82 > v84.upTo then
			continue
		end
	end
	local v84 = v_u_30[#v_u_30]
	local v85 = v_u_6.TIERS[v82]
	local v86 = v84.name == "PRO"
	local v87 = v_u_8.new("Frame", {
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["LayoutOrder"] = nil,
		["ClipsDescendants"] = true,
		["Parent"] = nil,
		["BackgroundColor3"] = Color3.new(1, 1, 1),
		["LayoutOrder"] = v81,
		["Parent"] = v_u_46
	})
	v_u_8.corner(v87, 14)
	v_u_8.gradient(v87, v32)
	v_u_8.border(v87, v84.colors[1], v86 and 0.3 or 0.72, v86 and 2 or 1.5)
	local v88 = v_u_8.new("Frame", {
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = Color3.new(1, 1, 1),
		["Size"] = UDim2.new(1, 0, 0, 4),
		["Parent"] = v87
	})
	v_u_8.gradient(v88, v84.colors, 0)
	v_u_43(v87, v84.name, v84.colors, v84.text).Position = UDim2.fromOffset(8, 10)
	local v89, v90 = v_u_43(v87, "", v34, v_u_8.TEXT)
	v89.AnchorPoint = Vector2.new(1, 0)
	v89.Position = UDim2.new(1, -8, 0, 10)
	v90.RichText = true
	local v91 = v_u_8.new("Frame", {
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.new(0.5, 0, 0.5, -24),
		["Size"] = UDim2.fromOffset(0, 44),
		["AutomaticSize"] = Enum.AutomaticSize.X,
		["Parent"] = v87
	})
	v_u_8.new("UIListLayout", {
		["FillDirection"] = Enum.FillDirection.Horizontal,
		["VerticalAlignment"] = Enum.VerticalAlignment.Bottom,
		["Padding"] = UDim.new(0, 3),
		["SortOrder"] = Enum.SortOrder.LayoutOrder,
		["Parent"] = v91
	})
	local v92 = v_u_8.text
	local v93 = {
		["Text"] = nil,
		["TextSize"] = 42,
		["FontFace"] = nil,
		["TextColor3"] = nil,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = 1,
		["Parent"] = nil,
		["Text"] = tostring(v82),
		["FontFace"] = v_u_8.FONT_DISPLAY
	}
	local v94
	if v86 then
		v94 = v84.colors[1]
	else
		v94 = v_u_8.TEXT
	end
	v93.TextColor3 = v94
	v93.Size = UDim2.fromScale(0, 1)
	v93.AutomaticSize = Enum.AutomaticSize.X
	v93.Parent = v91
	local v95 = v92(v93)
	v_u_8.text({
		["Text"] = "\224\184\161\224\184\161.",
		["TextSize"] = 15,
		["FontFace"] = nil,
		["TextColor3"] = nil,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = 2,
		["Parent"] = nil,
		["FontFace"] = v_u_8.FONT_BOLD,
		["TextColor3"] = v_u_16,
		["Size"] = UDim2.fromOffset(0, 30),
		["AutomaticSize"] = Enum.AutomaticSize.X,
		["Parent"] = v91
	})
	local v96 = v85.accel - 1
	local v97 = v_u_8.text
	local v98 = {
		["Text"] = nil,
		["TextSize"] = 13,
		["FontFace"] = nil,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil
	}
	local v99 = v96 * 100 + 0.5
	v98.Text = ("\224\185\129\224\184\163\224\184\135 +%d%%"):format((math.floor(v99)))
	v98.FontFace = v_u_8.FONT_BOLD
	v98.TextColor3 = v_u_8.TEXT
	v98.TextXAlignment = Enum.TextXAlignment.Left
	v98.Position = UDim2.new(0, 10, 1, -72)
	v98.Size = UDim2.new(0.5, -10, 0, 16)
	v98.Parent = v87
	v97(v98)
	v_u_8.text({
		["Text"] = nil,
		["TextSize"] = 13,
		["FontFace"] = nil,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Text"] = ("\224\184\151\224\185\135\224\184\173\224\184\155 %d"):format(v85.tuck),
		["FontFace"] = v_u_8.FONT_BOLD,
		["TextColor3"] = v_u_16,
		["TextXAlignment"] = Enum.TextXAlignment.Right,
		["AnchorPoint"] = Vector2.new(1, 0),
		["Position"] = UDim2.new(1, -10, 1, -72),
		["Size"] = UDim2.new(0.5, -10, 0, 16),
		["Parent"] = v87
	})
	local v100 = v_u_8.new("Frame", {
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.88,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = Color3.new(1, 1, 1),
		["Position"] = UDim2.new(0, 10, 1, -53),
		["Size"] = UDim2.new(1, -20, 0, 5),
		["Parent"] = v87
	})
	v_u_8.corner(v100, 3)
	local v101 = v_u_8.new
	local v102 = {
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = Color3.new(1, 1, 1)
	}
	local v103 = UDim2.fromScale
	local v104 = v96 / v31
	v102.Size = v103(math.clamp(v104, 0.06, 1), 1)
	v102.Parent = v100
	local v105 = v101("Frame", v102)
	v_u_8.corner(v105, 3)
	v_u_8.gradient(v105, v84.colors, 0)
	local v106 = v_u_8.button
	local v107 = {
		["text"] = nil,
		["grad"] = "gold",
		["textSize"] = 15,
		["size"] = nil,
		["anchor"] = nil,
		["position"] = nil,
		["parent"] = nil,
		["radius"] = 10
	}
	local v108 = v_u_6.PRICES[v82]
	v107.text = "\224\184\139\224\184\183\224\185\137\224\184\173 " .. v_u_5.formatCash(v108)
	v107.size = UDim2.new(1, -16, 0, 34)
	v107.anchor = Vector2.new(0.5, 1)
	v107.position = UDim2.new(0.5, 0, 1, -8)
	v107.parent = v87
	local v109 = v106(v107)
	local v110 = v_u_8.new("Frame", {
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.2,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Rotation"] = -12,
		["Visible"] = false,
		["ZIndex"] = 5,
		["Parent"] = nil,
		["BackgroundColor3"] = Color3.fromRGB(24, 10, 14),
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.new(0.5, 0, 0.5, -24),
		["Size"] = UDim2.fromOffset(112, 36),
		["Parent"] = v87
	})
	v_u_8.corner(v110, 8)
	v_u_8.border(v110, v_u_8.RED, 0, 2.5)
	v_u_8.text({
		["Text"] = "\224\184\171\224\184\161\224\184\148\224\185\129\224\184\165\224\185\137\224\184\167",
		["TextSize"] = 20,
		["FontFace"] = nil,
		["TextColor3"] = nil,
		["Size"] = nil,
		["ZIndex"] = 6,
		["Parent"] = nil,
		["FontFace"] = v_u_8.FONT_HEAVY,
		["TextColor3"] = Color3.fromRGB(255, 96, 104),
		["Size"] = UDim2.fromScale(1, 1),
		["Parent"] = v110
	})
	v_u_75[v82] = {
		["frame"] = v87,
		["buy"] = v109,
		["stockLabel"] = v90,
		["stamp"] = v110,
		["sizeLabel"] = v95
	}
end
local v_u_111 = v_u_8.window({
	["gui"] = nil,
	["name"] = "PistonGuideWindow",
	["title"] = "\224\184\165\224\184\185\224\184\129\224\185\132\224\184\171\224\184\153\224\185\131\224\184\170\224\185\136\224\184\132\224\184\177\224\184\153\224\185\132\224\184\171\224\184\153\224\185\132\224\184\148\224\185\137\224\184\154\224\185\137\224\184\178\224\184\135",
	["sub"] = "\224\184\151\224\184\184\224\184\129\224\184\132\224\184\177\224\184\153\224\185\131\224\184\170\224\185\136\224\185\132\224\184\148\224\185\137\224\184\151\224\184\184\224\184\129\224\184\165\224\184\185\224\184\129 \224\184\162\224\184\129\224\185\128\224\184\167\224\185\137\224\184\153\224\184\170\224\184\129\224\184\185\224\185\138\224\184\149\224\185\128\224\184\149\224\184\173\224\184\163\224\185\140\224\184\132\224\184\177\224\184\153\224\185\131\224\184\171\224\184\141\224\185\136 (\224\185\131\224\184\170\224\185\136\224\185\132\224\184\148\224\185\137\224\185\129\224\184\132\224\185\136\224\185\131\224\184\171\224\184\141\224\185\136\224\184\129\224\184\167\224\185\136\224\184\178\224\184\165\224\184\185\224\184\129\224\185\128\224\184\148\224\184\180\224\184\161)  \194\183  \224\184\163\224\184\150\224\184\162\224\184\153\224\184\149\224\185\140\224\185\131\224\184\170\224\185\136\224\185\132\224\184\161\224\185\136\224\185\132\224\184\148\224\185\137",
	["icon"] = "settings",
	["grad"] = "blue",
	["size"] = nil,
	["max"] = nil,
	["zindex"] = 5,
	["gui"] = v_u_17,
	["size"] = Vector2.new(0.6, 0.8),
	["max"] = Vector2.new(880, 660)
})
local v_u_112 = v_u_8.new("ScrollingFrame", {
	["BackgroundTransparency"] = 1,
	["BorderSizePixel"] = 0,
	["ScrollBarThickness"] = 6,
	["CanvasSize"] = nil,
	["AutomaticCanvasSize"] = nil,
	["Size"] = nil,
	["ZIndex"] = 5,
	["Parent"] = nil,
	["CanvasSize"] = UDim2.new(),
	["AutomaticCanvasSize"] = Enum.AutomaticSize.Y,
	["Size"] = UDim2.fromScale(1, 1),
	["Parent"] = v_u_111.body
})
v_u_8.new("UIListLayout", {
	["Padding"] = UDim.new(0, 10),
	["SortOrder"] = Enum.SortOrder.LayoutOrder,
	["Parent"] = v_u_112
})
v_u_8.padding(v_u_112, 4, 4)
local function v_u_115() -- name: myVehicleId
	-- upvalues: (copy) v_u_11
	local v113 = workspace:FindFirstChild("SpawnedVehicles")
	for _, v114 in not v113 and {} or v113:GetChildren() do
		if v114:GetAttribute("OwnerUserId") ~= v_u_11.UserId then
			continue
		end
		return v114:GetAttribute("VehicleId")
	end
	return nil
end
local function v_u_171() -- name: drawGuide
	-- upvalues: (copy) v_u_112, (copy) v_u_115, (copy) v_u_5, (copy) v_u_6, (copy) v_u_8, (copy) v_u_15, (copy) v_u_16, (copy) v_u_30, (copy) v_u_111
	for _, v116 in v_u_112:GetChildren() do
		if not v116:IsA("GuiObject") then
			continue
		end
		v116:Destroy()
	end
	local v117 = v_u_115()
	local v_u_118 = {}
	local v119 = {}
	for _, v120 in v_u_5.VEHICLES do
		local v121 = v_u_6.stockBore(v120.id)
		if not v121 or v120.private then
			continue
		end
		local v122 = {}
		for _, v123 in v_u_6.SIZES do
			if not v_u_6.fits(v120.id, v123) then
				continue
			end
			table.insert(v122, v123)
		end
		local v124 = table.concat(v122, ",")
		if not v_u_118[v124] then
			v_u_118[v124] = {
				["sizes"] = v122,
				["names"] = {}
			}
			table.insert(v119, v124)
		end
		local v125 = v_u_118[v124].names
		local v126 = (v120.id == v117 and "\226\173\144 " or "") .. (v120.th or v120.id) .. (" (\224\185\128\224\184\148\224\184\180\224\184\161 %g)"):format(v121)
		table.insert(v125, v126)
	end
	table.sort(v119, function(p127, p128)
		-- upvalues: (copy) v_u_118
		return v_u_118[p127].sizes[1] < v_u_118[p128].sizes[1]
	end)
	local v_u_129 = v_u_8.new("Frame", {
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.05,
		["BorderSizePixel"] = 0,
		["LayoutOrder"] = 0,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["ZIndex"] = 5,
		["Parent"] = nil,
		["BackgroundColor3"] = Color3.fromRGB(30, 34, 48),
		["Size"] = UDim2.new(1, -8, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y,
		["Parent"] = v_u_112
	})
	v_u_8.corner(v_u_129, 14)
	v_u_8.border(v_u_129, v_u_15, 0.6, 1.2)
	v_u_8.padding(v_u_129, 14, 10)
	v_u_8.new("UIListLayout", {
		["Padding"] = UDim.new(0, 4),
		["SortOrder"] = Enum.SortOrder.LayoutOrder,
		["Parent"] = v_u_129
	})
	local function v141(p130, p131, p132, p133) -- name: row
		-- upvalues: (ref) v_u_8, (copy) v_u_129
		local v134 = v_u_8.new("Frame", {
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = nil,
			["BorderSizePixel"] = 0,
			["LayoutOrder"] = nil,
			["Size"] = nil,
			["ZIndex"] = 5,
			["Parent"] = nil,
			["BackgroundColor3"] = Color3.new(1, 1, 1),
			["BackgroundTransparency"] = p130 % 2 == 1 and 0.95 or 1,
			["LayoutOrder"] = p130,
			["Size"] = UDim2.new(1, 0, 0, 24),
			["Parent"] = v_u_129
		})
		v_u_8.corner(v134, 6)
		for v135, v136 in p131 do
			local v137 = v_u_8.text
			local v138 = {
				["Text"] = nil,
				["TextSize"] = 15,
				["FontFace"] = nil,
				["TextColor3"] = nil,
				["TextXAlignment"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["ZIndex"] = 5,
				["Parent"] = nil,
				["Text"] = v136
			}
			local v139
			if p133 then
				v139 = v_u_8.FONT_BOLD
			else
				v139 = v_u_8.FONT_DIGITS
			end
			v138.FontFace = v139
			v138.TextColor3 = p132
			local v140
			if v135 == 1 then
				v140 = Enum.TextXAlignment.Left
			else
				v140 = Enum.TextXAlignment.Center
			end
			v138.TextXAlignment = v140
			v138.Position = UDim2.fromScale((v135 - 1) * 0.25, 0)
			v138.Size = UDim2.fromScale(0.25, 1)
			v138.Parent = v134
			v137(v138)
		end
	end
	v141(1, {
		"\224\184\165\224\184\185\224\184\129 (\224\184\161\224\184\161.)",
		"\224\185\129\224\184\163\224\184\135\224\184\161\224\185\137\224\184\178",
		"\224\184\151\224\185\135\224\184\173\224\184\155",
		"\224\184\171\224\184\161\224\184\173\224\184\154"
	}, v_u_16, true)
	local v142 = {}
	local v143 = v_u_6.TIERS[0].cap
	local v144 = tostring(v143)
	local v145 = v_u_6.TIERS[0].tuck
	__set_list(v142, 1, {"\224\185\132\224\184\161\224\185\136\224\185\131\224\184\170\224\185\136", "+0%", v144, (tostring(v145))})
	v141(2, v142, v_u_16)
	for v146, v147 in v_u_6.SIZES do
		local v148 = v_u_6.TIERS[v147]
		local v149 = 2 + v146
		local v150 = {}
		local v151 = tostring(v147)
		local v152 = (v148.accel - 1) * 100 + 0.5
		local v153 = ("+%d%%"):format((math.floor(v152)))
		local v154 = v148.cap
		local v155 = tostring(v154)
		local v156 = v148.tuck
		__set_list(v150, 1, {v151, v153, v155, (tostring(v156))})
		local v157, v158
		if v147 >= 80 then
			v157 = v_u_15
			v158 = v141
		else
			v158 = v141
			for _, v160 in v_u_30 do
				if v147 > v160.upTo then
					continue
				end
			end
			local v160 = v_u_30[#v_u_30]
			v157 = v160.colors[1]
		end
		v141(v149, v150, v157)
		v141 = v158
	end
	v_u_8.text({
		["Text"] = "\224\185\128\224\184\171\224\184\161\224\184\183\224\184\173\224\184\153\224\184\129\224\184\177\224\184\153\224\184\151\224\184\184\224\184\129\224\184\132\224\184\177\224\184\153 \194\183 \224\184\151\224\185\135\224\184\173\224\184\155\224\184\132\224\184\183\224\184\173\224\185\128\224\184\158\224\184\148\224\184\178\224\184\153\224\184\149\224\184\173\224\184\153\224\184\136\224\184\185\224\184\153\224\185\132\224\184\148\224\185\130\224\184\153\224\185\136 x2 \224\185\128\224\184\149\224\185\135\224\184\161 (\224\184\163\224\184\184\224\185\136\224\184\153\224\184\151\224\184\181\224\185\136\224\185\128\224\184\132\224\184\163\224\184\183\224\185\136\224\184\173\224\184\135\224\185\128\224\184\165\224\185\135\224\184\129\224\184\173\224\184\178\224\184\136\224\185\132\224\184\155\224\185\132\224\184\161\224\185\136\224\184\150\224\184\182\224\184\135) \194\183 \224\184\171\224\184\161\224\184\173\224\184\154 340 \224\185\132\224\184\148\224\185\137\224\185\129\224\184\132\224\185\136\224\184\165\224\184\185\224\184\129 90",
		["TextSize"] = 13,
		["TextColor3"] = nil,
		["TextWrapped"] = true,
		["TextXAlignment"] = nil,
		["LayoutOrder"] = 99,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["ZIndex"] = 5,
		["Parent"] = nil,
		["TextColor3"] = v_u_16,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y,
		["Parent"] = v_u_129
	})
	for v161, v162 in v119 do
		local v163 = v_u_118[v162]
		local v164 = v_u_8.new("Frame", {
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.05,
			["BorderSizePixel"] = 0,
			["LayoutOrder"] = nil,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["ZIndex"] = 5,
			["Parent"] = nil,
			["BackgroundColor3"] = v_u_8.CARD,
			["LayoutOrder"] = v161,
			["Size"] = UDim2.new(1, -8, 0, 0),
			["AutomaticSize"] = Enum.AutomaticSize.Y,
			["Parent"] = v_u_112
		})
		v_u_8.corner(v164, 14)
		v_u_8.border(v164)
		v_u_8.padding(v164, 14, 10)
		v_u_8.new("UIListLayout", {
			["Padding"] = UDim.new(0, 8),
			["SortOrder"] = Enum.SortOrder.LayoutOrder,
			["Parent"] = v164
		})
		local v165 = v_u_8.new("Frame", {
			["BackgroundTransparency"] = 1,
			["LayoutOrder"] = 1,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["ZIndex"] = 5,
			["Parent"] = nil,
			["Size"] = UDim2.new(1, 0, 0, 0),
			["AutomaticSize"] = Enum.AutomaticSize.Y,
			["Parent"] = v164
		})
		v_u_8.new("UIListLayout", {
			["FillDirection"] = nil,
			["Wraps"] = true,
			["Padding"] = nil,
			["SortOrder"] = nil,
			["VerticalAlignment"] = nil,
			["Parent"] = nil,
			["FillDirection"] = Enum.FillDirection.Horizontal,
			["Padding"] = UDim.new(0, 6),
			["SortOrder"] = Enum.SortOrder.LayoutOrder,
			["VerticalAlignment"] = Enum.VerticalAlignment.Center,
			["Parent"] = v165
		})
		v_u_8.text({
			["Text"] = "\224\185\131\224\184\170\224\185\136\224\185\132\224\184\148\224\185\137",
			["TextSize"] = 15,
			["TextColor3"] = nil,
			["Size"] = nil,
			["LayoutOrder"] = 0,
			["ZIndex"] = 5,
			["Parent"] = nil,
			["TextColor3"] = v_u_16,
			["Size"] = UDim2.fromOffset(52, 30),
			["Parent"] = v165
		})
		for v166, v167 in v163.sizes do
			for _, v169 in v_u_30 do
				if v167 > v169.upTo then
					continue
				end
			end
			local v169 = v_u_30[#v_u_30]
			local v170 = v_u_8.new("Frame", {
				["BackgroundColor3"] = nil,
				["Size"] = nil,
				["LayoutOrder"] = nil,
				["ZIndex"] = 5,
				["Parent"] = nil,
				["BackgroundColor3"] = Color3.fromRGB(30, 33, 44),
				["Size"] = UDim2.fromOffset(58, 30),
				["LayoutOrder"] = v166,
				["Parent"] = v165
			})
			v_u_8.corner(v170, 8)
			v_u_8.new("UIStroke", {
				["Color"] = nil,
				["Transparency"] = 0.35,
				["Thickness"] = 1.2,
				["Parent"] = nil,
				["Color"] = v169.colors[1],
				["Parent"] = v170
			})
			v_u_8.text({
				["Text"] = nil,
				["TextSize"] = 17,
				["FontFace"] = nil,
				["TextColor3"] = nil,
				["Size"] = nil,
				["ZIndex"] = 5,
				["Parent"] = nil,
				["Text"] = tostring(v167),
				["FontFace"] = v_u_8.FONT_DIGITS,
				["TextColor3"] = v169.colors[1],
				["Size"] = UDim2.fromScale(1, 1),
				["Parent"] = v170
			})
		end
		v_u_8.text({
			["Text"] = nil,
			["TextSize"] = 15,
			["TextColor3"] = nil,
			["TextWrapped"] = true,
			["TextXAlignment"] = nil,
			["TextYAlignment"] = nil,
			["LayoutOrder"] = 2,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["ZIndex"] = 5,
			["Parent"] = nil,
			["Text"] = ("%d \224\184\163\224\184\184\224\185\136\224\184\153:  "):format(#v163.names) .. table.concat(v163.names, "  \194\183  "),
			["TextColor3"] = v_u_8.TEXT,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["TextYAlignment"] = Enum.TextYAlignment.Top,
			["Size"] = UDim2.new(1, 0, 0, 0),
			["AutomaticSize"] = Enum.AutomaticSize.Y,
			["Parent"] = v164
		})
	end
	v_u_111.sub.Text = v117 and "\226\173\144 = \224\184\163\224\184\150\224\184\151\224\184\181\224\185\136\224\184\132\224\184\184\224\184\147\224\185\128\224\184\173\224\184\178\224\184\173\224\184\173\224\184\129\224\184\161\224\184\178  \194\183  \224\184\151\224\184\184\224\184\129\224\184\132\224\184\177\224\184\153\224\185\131\224\184\170\224\185\136\224\185\132\224\184\148\224\185\137\224\184\151\224\184\184\224\184\129\224\184\165\224\184\185\224\184\129 \224\184\162\224\184\129\224\185\128\224\184\167\224\185\137\224\184\153\224\184\170\224\184\129\224\184\185\224\185\138\224\184\149\224\185\128\224\184\149\224\184\173\224\184\163\224\185\140\224\184\132\224\184\177\224\184\153\224\185\131\224\184\171\224\184\141\224\185\136 (\224\185\131\224\184\170\224\185\136\224\185\132\224\184\148\224\185\137\224\185\129\224\184\132\224\185\136\224\185\131\224\184\171\224\184\141\224\185\136\224\184\129\224\184\167\224\185\136\224\184\178\224\184\165\224\184\185\224\184\129\224\185\128\224\184\148\224\184\180\224\184\161)  \194\183  \224\184\163\224\184\150\224\184\162\224\184\153\224\184\149\224\185\140\224\185\131\224\184\170\224\185\136\224\185\132\224\184\161\224\185\136\224\185\132\224\184\148\224\185\137" or "\224\184\151\224\184\184\224\184\129\224\184\132\224\184\177\224\184\153\224\185\131\224\184\170\224\185\136\224\185\132\224\184\148\224\185\137\224\184\151\224\184\184\224\184\129\224\184\165\224\184\185\224\184\129 \224\184\162\224\184\129\224\185\128\224\184\167\224\185\137\224\184\153\224\184\170\224\184\129\224\184\185\224\185\138\224\184\149\224\185\128\224\184\149\224\184\173\224\184\163\224\185\140\224\184\132\224\184\177\224\184\153\224\185\131\224\184\171\224\184\141\224\185\136 (\224\185\131\224\184\170\224\185\136\224\185\132\224\184\148\224\185\137\224\185\129\224\184\132\224\185\136\224\185\131\224\184\171\224\184\141\224\185\136\224\184\129\224\184\167\224\185\136\224\184\178\224\184\165\224\184\185\224\184\129\224\185\128\224\184\148\224\184\180\224\184\161)  \194\183  \224\184\163\224\184\150\224\184\162\224\184\153\224\184\149\224\185\140\224\185\131\224\184\170\224\185\136\224\185\132\224\184\161\224\185\136\224\185\132\224\184\148\224\185\137"
end
v63.Activated:Connect(function()
	-- upvalues: (copy) v_u_171, (copy) v_u_17, (copy) v_u_111
	v_u_171()
	v_u_17.Enabled = true
	v_u_111.setOpen(true)
end)
local v_u_172 = false
local v_u_173 = nil
local function v_u_183() -- name: drawShop
	-- upvalues: (ref) v_u_173, (ref) v_u_74, (copy) v_u_23, (copy) v_u_11, (copy) v_u_75, (copy) v_u_6, (copy) v_u_8, (copy) v_u_33, (copy) v_u_16, (copy) v_u_5, (copy) v_u_73, (copy) v_u_65, (copy) v_u_45
	if v_u_173 then
		local v174 = v_u_173.bag
		if type(v174) == "table" then
			v_u_74 = v_u_23(v_u_173.bag)
		end
		local v175 = v_u_11:GetAttribute("Cash") or 0
		for _, v176 in v_u_173.items do
			local v177 = v_u_75[v176.size]
			local v178 = v176.left <= 0
			local v179 = v_u_6.PRICES[v176.size]
			v177.stockLabel.Text = v178 and "<font color=\"#FF6068\">\226\151\143</font> \224\184\171\224\184\161\224\184\148" or ("<font color=\"#60E896\">\226\151\143</font> \224\185\128\224\184\171\224\184\165\224\184\183\224\184\173 %d"):format(v176.left)
			v177.stamp.Visible = v178
			v177.sizeLabel.TextTransparency = v178 and 0.65 or 0
			if v178 then
				v_u_8.setButton(v177.buy, v_u_33, "\224\184\171\224\184\161\224\184\148", v_u_16)
			elseif v175 < v179 then
				v_u_8.setButton(v177.buy, "dark", v_u_5.formatCash(v179), Color3.fromRGB(255, 140, 140))
			else
				v_u_8.setButton(v177.buy, "gold", "\224\184\139\224\184\183\224\185\137\224\184\173 " .. v_u_5.formatCash(v179), v_u_8.DARK_TEXT)
			end
			v177.buy.Active = not v178
		end
		v_u_73()
		v_u_65.Text = v_u_5.formatCash(v175)
		local v180 = (v_u_173.closesAt or 0) - workspace:GetServerTimeNow()
		local v181 = math.floor(v180)
		local v182 = math.max(0, v181)
		v_u_45.sub.Text = ("\224\184\130\224\184\173\224\184\135\224\185\128\224\184\130\224\185\137\224\184\178\224\185\131\224\184\171\224\184\161\224\185\136\224\184\151\224\184\184\224\184\129\224\184\132\224\184\163\224\184\177\224\185\137\224\184\135\224\184\151\224\184\181\224\185\136\224\184\162\224\185\137\224\184\178\224\184\162\224\184\163\224\185\137\224\184\178\224\184\153  \194\183  \224\184\163\224\185\137\224\184\178\224\184\153\224\184\155\224\184\180\224\184\148\224\185\131\224\184\153 %d:%02d"):format(v182 // 60, v182 % 60)
	end
end
local v_u_184 = v_u_173
local v_u_185 = false
for v_u_186, v_u_187 in v_u_75 do
	v_u_187.buy.Activated:Connect(function()
		-- upvalues: (ref) v_u_185, (copy) v_u_187, (copy) v_u_1, (copy) v_u_13, (copy) v_u_186, (copy) v_u_9, (ref) v_u_184, (copy) v_u_183
		if not v_u_185 and v_u_187.buy.Active then
			v_u_185 = true
			local v188 = v_u_1.invoke
			local v189 = v_u_13
			local v190 = v_u_186
			local v191, v192, v193, v194 = pcall(v188, v189, "Buy", v190)
			v_u_185 = false
			if v191 and v193 then
				v_u_9.show(v193, v192 and "ok" or "error")
			end
			if v191 and (v192 and type(v194) == "table") then
				v_u_184 = v194
				v_u_183()
			end
		end
	end)
end
v14.OnClientEvent:Connect(function() -- name: openShop
	-- upvalues: (copy) v_u_1, (copy) v_u_13, (ref) v_u_184, (copy) v_u_183, (copy) v_u_17, (copy) v_u_45, (ref) v_u_172
	local v195 = v_u_1.invoke
	local v196 = v_u_13
	local v197, v198, v199 = pcall(v195, v196, "Shop")
	if v197 and (v198 and type(v199) == "table") then
		v_u_184 = v199
		v_u_183()
		v_u_17.Enabled = true
		v_u_45.setOpen(true)
		if not v_u_172 then
			v_u_172 = true
			task.spawn(function()
				-- upvalues: (ref) v_u_45, (ref) v_u_1, (ref) v_u_13, (ref) v_u_184, (ref) v_u_183, (ref) v_u_172
				while v_u_45.isOpen() do
					task.wait(1)
					local v200 = v_u_1.invoke
					local v201 = v_u_13
					local v202, v203, v204 = pcall(v200, v201, "Shop")
					if not (v202 and v203) then
						continue
					end
					if type(v204) == "table" then
						v_u_184 = v204
						v_u_183()
					else
						v_u_45.setOpen(false)
					end
				end
				v_u_172 = false
			end)
		end
	else
		return
	end
end)
local v_u_205 = v_u_8.window({
	["gui"] = nil,
	["name"] = "PistonFitWindow",
	["title"] = "\224\185\131\224\184\170\224\185\136\224\184\165\224\184\185\224\184\129\224\184\170\224\184\185\224\184\154",
	["sub"] = "",
	["icon"] = "settings",
	["grad"] = "gold",
	["size"] = nil,
	["max"] = nil,
	["gui"] = v_u_17,
	["size"] = Vector2.new(0.46, 0.7),
	["max"] = Vector2.new(620, 600)
})
local v_u_206 = v_u_8.new("ScrollingFrame", {
	["BackgroundTransparency"] = 1,
	["BorderSizePixel"] = 0,
	["ScrollBarThickness"] = 6,
	["CanvasSize"] = nil,
	["AutomaticCanvasSize"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["CanvasSize"] = UDim2.new(),
	["AutomaticCanvasSize"] = Enum.AutomaticSize.Y,
	["Size"] = UDim2.fromScale(1, 1),
	["Parent"] = v_u_205.body
})
v_u_8.new("UIListLayout", {
	["Padding"] = UDim.new(0, 8),
	["SortOrder"] = Enum.SortOrder.LayoutOrder,
	["Parent"] = v_u_206
})
local v_u_207 = nil
local v_u_208 = false
local function v_u_252() -- name: drawFit
	-- upvalues: (copy) v_u_206, (ref) v_u_207, (copy) v_u_6, (copy) v_u_5, (copy) v_u_205, (ref) v_u_74, (copy) v_u_80, (copy) v_u_30, (copy) v_u_8, (copy) v_u_33, (copy) v_u_16, (ref) v_u_208, (copy) v_u_1, (copy) v_u_13, (copy) v_u_9, (copy) v_u_23
	for _, v209 in v_u_206:GetChildren() do
		if not v209:IsA("GuiObject") then
			continue
		end
		v209:Destroy()
	end
	local v210 = v_u_207
	if v210 then
		local v211 = v210:GetAttribute("VehicleId") or v210.Name
		local v212 = v_u_6.stockBore(v211)
		local v213 = v210:GetAttribute("PistonBore")
		local v214 = v_u_5.vehicle(v211)
		local v215 = v_u_205.sub
		local v216 = "%s  \194\183  \224\184\165\224\184\185\224\184\129\224\185\128\224\184\148\224\184\180\224\184\161 %g \224\184\161\224\184\161.  \194\183  \224\184\149\224\184\173\224\184\153\224\184\153\224\184\181\224\185\137 %s"
		local v217
		if v214 then
			v217 = v214.th or v211
		else
			v217 = v211
		end
		v215.Text = v216:format(v217, v212 or 0, typeof(v213) ~= "number" and "\224\185\128\224\184\148\224\184\180\224\184\161" or ("%d \224\184\161\224\184\161."):format(v213))
		local v218 = 0
		for _, v_u_219 in v_u_6.SIZES do
			local v220 = v_u_74[v_u_219] or 0
			if v220 <= 0 then
				continue
			end
			v218 = v218 + 1
			local v221, v222 = v_u_6.canFit(v211, v_u_219, v213)
			local v223 = v_u_80(v_u_206, v218, 72)
			for _, v225 in v_u_30 do
				if v_u_219 > v225.upTo then
					continue
				end
			end
			local v225 = v_u_30[#v_u_30]
			local v226 = v_u_8.new("Frame", {
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["BackgroundColor3"] = Color3.new(1, 1, 1),
				["AnchorPoint"] = Vector2.new(0, 0.5),
				["Position"] = UDim2.new(0, 10, 0.5, 0),
				["Size"] = UDim2.fromOffset(52, 52),
				["Parent"] = v223
			})
			v_u_8.corner(v226, 12)
			v_u_8.gradient(v226, v225.colors)
			v_u_8.text({
				["Text"] = nil,
				["TextSize"] = 24,
				["FontFace"] = nil,
				["TextColor3"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["Text"] = tostring(v_u_219),
				["FontFace"] = v_u_8.FONT_DISPLAY,
				["TextColor3"] = v225.text,
				["Size"] = UDim2.fromScale(1, 1),
				["Parent"] = v226
			})
			v_u_8.text({
				["Text"] = nil,
				["RichText"] = true,
				["TextSize"] = 16,
				["FontFace"] = nil,
				["TextXAlignment"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["Text"] = ("\224\184\165\224\184\185\224\184\129 %d \224\184\161\224\184\161.  <font color=\"#9EA4B6\">\195\151%d \224\185\131\224\184\153\224\184\129\224\184\163\224\184\176\224\185\128\224\184\155\224\185\139\224\184\178</font>"):format(v_u_219, v220),
				["FontFace"] = v_u_8.FONT_BOLD,
				["TextXAlignment"] = Enum.TextXAlignment.Left,
				["Position"] = UDim2.fromOffset(74, 12),
				["Size"] = UDim2.new(1, -196, 0, 20),
				["Parent"] = v223
			})
			local v227 = (v_u_6.ratio(v211, v_u_219) - 1) * 100 + 0.5
			local v228 = math.floor(v227)
			local v229 = typeof(v213) ~= "number" and "" or ("  \194\183  \224\184\165\224\184\185\224\184\129 %d \224\185\128\224\184\148\224\184\180\224\184\161\224\184\151\224\184\180\224\185\137\224\184\135"):format(v213)
			local v230 = tonumber(v210:GetAttribute("EngineLevel")) or 0
			if v_u_219 == v_u_6.FULL_SIZE and v230 < v_u_6.PEAK_ENGINE then
				v229 = "  \194\183  \224\184\151\224\185\135\224\184\173\224\184\155\224\184\170\224\184\184\224\184\148\224\184\149\224\185\137\224\184\173\224\184\135\224\185\128\224\184\132\224\184\163\224\184\183\224\185\136\224\184\173\224\184\135 Stage 3" .. v229
			end
			local v231 = v_u_8.text
			local v232 = {
				["Text"] = nil,
				["TextSize"] = 14,
				["TextColor3"] = nil,
				["TextXAlignment"] = nil,
				["TextTruncate"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil
			}
			if v221 then
				local v233 = v_u_6.capKmhFor(v211, v_u_219, true, nil, v230) or 0
				v222 = ("\224\185\129\224\184\163\224\184\135\224\184\161\224\185\137\224\184\178 +%d%%  \194\183  \224\184\151\224\185\135\224\184\173\224\184\155\224\184\171\224\184\161\224\184\173\224\184\154 %d"):format(v228, (math.floor(v233))) .. v229
			end
			v232.Text = v222
			local v234
			if v221 then
				v234 = v_u_8.GREEN_TEXT
			else
				v234 = Color3.fromRGB(255, 120, 120)
			end
			v232.TextColor3 = v234
			v232.TextXAlignment = Enum.TextXAlignment.Left
			v232.TextTruncate = Enum.TextTruncate.AtEnd
			v232.Position = UDim2.fromOffset(74, 38)
			v232.Size = UDim2.new(1, -196, 0, 18)
			v232.Parent = v223
			v231(v232)
			local v235 = v_u_8.button
			local v236 = {
				["text"] = nil,
				["grad"] = nil,
				["textSize"] = 16,
				["textColor"] = nil,
				["anchor"] = nil,
				["position"] = nil,
				["size"] = nil,
				["parent"] = nil,
				["text"] = v221 and "\224\185\131\224\184\170\224\185\136\224\185\128\224\184\165\224\184\162" or "\224\185\131\224\184\170\224\185\136\224\185\132\224\184\161\224\185\136\224\185\132\224\184\148\224\185\137",
				["grad"] = v221 and "gold" or v_u_33
			}
			local v237
			if v221 then
				v237 = nil
			else
				v237 = v_u_16
			end
			v236.textColor = v237
			v236.anchor = Vector2.new(1, 0.5)
			v236.position = UDim2.new(1, -12, 0.5, 0)
			v236.size = UDim2.fromOffset(108, 42)
			v236.parent = v223
			local v238 = v235(v236)
			if not v221 then
				break
			end
			v238.Activated:Connect(function()
				-- upvalues: (ref) v_u_208, (ref) v_u_207, (ref) v_u_205, (ref) v_u_1, (ref) v_u_13, (copy) v_u_219, (ref) v_u_9, (ref) v_u_74, (ref) v_u_23
				if not v_u_208 and v_u_207 then
					v_u_208 = true
					local v239 = v_u_207
					v_u_205.setOpen(false)
					local v240 = v_u_1.invoke
					local v241 = v_u_13
					local v242 = v_u_219
					local v243, v244, v245 = pcall(v240, v241, "Fit", v239, v242)
					v_u_208 = false
					v_u_207 = nil
					if v243 and v245 then
						v_u_9.show(v245, v244 and "ok" or "error")
					end
					local v246 = v_u_1.invoke
					local v247 = v_u_13
					local v248, v249, v250 = pcall(v246, v247, "Bag")
					if v248 and (v249 and type(v250) == "table") then
						v_u_74 = v_u_23(v250)
					end
				end
			end)
		end
		if v218 == 0 then
			local v251 = v_u_80(v_u_206, 1, 60)
			v_u_8.text({
				["Text"] = "\224\185\132\224\184\161\224\185\136\224\184\161\224\184\181\224\184\165\224\184\185\224\184\129\224\185\131\224\184\153\224\184\129\224\184\163\224\184\176\224\185\128\224\184\155\224\185\139\224\184\178 \224\185\132\224\184\155\224\184\139\224\184\183\224\185\137\224\184\173\224\184\151\224\184\181\224\185\136\224\184\163\224\185\137\224\184\178\224\184\153\224\184\165\224\184\185\224\184\129\224\184\170\224\184\185\224\184\154\224\184\129\224\185\136\224\184\173\224\184\153",
				["TextSize"] = 16,
				["TextColor3"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["TextColor3"] = v_u_16,
				["Size"] = UDim2.fromScale(1, 1),
				["Parent"] = v251
			})
		end
	end
end
v3.PromptTriggered:Connect(function(p253)
	-- upvalues: (copy) v_u_1, (copy) v_u_13, (ref) v_u_74, (copy) v_u_23, (ref) v_u_207, (copy) v_u_252, (copy) v_u_17, (copy) v_u_205
	if p253.Name == "PistonFit" then
		local v254 = p253:FindFirstAncestorWhichIsA("Model")
		while v254 and not v254:GetAttribute("VehicleId") do
			local v255 = v254.Parent
			if v255 then
				v254 = v254.Parent:FindFirstAncestorWhichIsA("Model")
			else
				v254 = v255
			end
		end
		if v254 then
			local v256 = v_u_1.invoke
			local v257 = v_u_13
			local v258, v259, v260 = pcall(v256, v257, "Bag")
			if v258 and (v259 and type(v260) == "table") then
				v_u_74 = v_u_23(v260)
			end
			v_u_207 = v254
			v_u_252()
			v_u_17.Enabled = true
			v_u_205.setOpen(true)
		end
	else
		return
	end
end)
v_u_205.changed.Event:Connect(function(p261)
	-- upvalues: (ref) v_u_208, (ref) v_u_207
	if not (p261 or v_u_208) then
		v_u_207 = nil
	end
end)
task.spawn(function()
	-- upvalues: (copy) v_u_1, (copy) v_u_13, (ref) v_u_74, (copy) v_u_23, (copy) v_u_29, (copy) v_u_11, (ref) v_u_208
	local v262 = v_u_1.invoke
	local v263 = v_u_13
	local v264, v265, v266 = pcall(v262, v263, "Bag")
	if v264 and (v265 and type(v266) == "table") then
		v_u_74 = v_u_23(v266)
	end
	local v267 = os.clock()
	while true do
		task.wait(0.5)
		if os.clock() - v267 > 15 then
			v267 = os.clock()
			task.spawn(v_u_29)
		end
		local v268 = v_u_11.Character
		if v268 then
			v268 = v_u_11.Character:FindFirstChildOfClass("Humanoid")
		end
		local v269
		if v268 == nil then
			v269 = false
		else
			v269 = v268.SeatPart == nil
		end
		local v270 = v_u_11.Character
		if v270 then
			v270 = v_u_11.Character:FindFirstChildOfClass("Tool")
		end
		local v271
		if v270 == nil or v270:GetAttribute("PistonItem") ~= true then
			v271 = false
		else
			v271 = not v_u_208
		end
		local v272 = workspace:FindFirstChild("SpawnedVehicles")
		for _, v273 in not v272 and {} or v272:GetChildren() do
			local v274 = v273:FindFirstChild("Chassis")
			if v274 then
				v274 = v273.Chassis:FindFirstChild("PistonPoint")
			end
			if v274 then
				v274 = v274:FindFirstChild("PistonFit")
			end
			if not v274 then
				continue
			end
			local v275
			if v269 then
				if v271 then
					if v273:GetAttribute("OwnerUserId") == v_u_11.UserId then
						v275 = v273:GetAttribute("PistonFitting") == nil
					else
						v275 = false
					end
				else
					v275 = v271
				end
			else
				v275 = v269
			end
			v274.Enabled = v275
		end
	end
end)