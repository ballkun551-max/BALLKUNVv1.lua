-- Path: Players/ygggggg55551/PlayerScripts/DashcamClient
-- Class: LocalScript  true/Enum.RunContext.Legacy
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = require(game:GetService("ReplicatedStorage"):WaitForChild("NetSeal"))
local v2 = game:GetService("Players")
local v3 = game:GetService("ProximityPromptService")
local v4 = game:GetService("ReplicatedStorage")
local v5 = game:GetService("RunService")
local v_u_6 = game:GetService("UserInputService")
local v_u_7 = game:GetService("ContextActionService")
local v_u_8 = game:GetService("GuiService")
local v_u_9 = require(v4:WaitForChild("GameShared"))
local v_u_10 = require(v4:WaitForChild("ShopShared"))
local v_u_11 = require(v4:WaitForChild("Cam360Shared"))
local v_u_12 = require(v4:WaitForChild("DashcamShared"))
local v13 = v4:WaitForChild("GameUI")
local v_u_14 = require(v13:WaitForChild("Theme"))
local v_u_15 = require(v13:WaitForChild("Toast"))
local v_u_16 = require(v13:WaitForChild("Icons"))
v4:WaitForChild(v_u_12.PARTS_FOLDER)
local v_u_17 = v2.LocalPlayer
local v_u_18 = v4:WaitForChild(v_u_9.REMOTES):WaitForChild(v_u_12.REMOTE)
local v_u_19 = { Color3.fromRGB(70, 72, 84), Color3.fromRGB(52, 54, 64) }
local v_u_20 = v_u_14.YELLOW
local v21 = Color3.fromRGB(255, 120, 190)
local v22 = Color3.fromRGB(255, 150, 40)
local v23 = Color3.fromRGB(90, 180, 255)
local v_u_24 = Color3.fromRGB(110, 220, 140)
local v_u_25 = Color3.fromRGB(14, 18, 26)
local v_u_26 = Color3.fromRGB(70, 60, 30)
local v_u_27 = v_u_12.MAX_PARTS
local v_u_28 = v_u_6.TouchEnabled
if v_u_28 then
	v_u_28 = not v_u_6.MouseEnabled
end
local v_u_29 = nil
local function v_u_32(p30) -- name: vehicleName
	-- upvalues: (copy) v_u_9
	local v31 = v_u_9.vehicle
	if v31 then
		v31 = v_u_9.vehicle(p30:GetAttribute("VehicleId") or "")
	end
	return v31 and v31.th or (p30:GetAttribute("BikeName") or p30:GetAttribute("DisplayName") or (p30:GetAttribute("VehicleId") or p30.Name))
end
local function v45(p33, p34) -- name: picture
	-- upvalues: (copy) v_u_14, (copy) v_u_12
	local v35 = v_u_14.new("ViewportFrame", {
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Ambient"] = nil,
		["LightColor"] = nil,
		["LightDirection"] = Vector3.new(-0.6, -1, -0.4),
		["Parent"] = nil,
		["Size"] = UDim2.fromScale(1, 1),
		["Ambient"] = Color3.fromRGB(190, 190, 200),
		["LightColor"] = Color3.new(1, 1, 1),
		["Parent"] = p33
	})
	local v36 = v_u_12.makeModel(p34, 1)
	if not v36 then
		return v35
	end
	v36.Parent = v35
	local v37, v38 = v36:GetBoundingBox()
	local v39 = Instance.new("Camera")
	v39.FieldOfView = 30
	v39.Parent = v35
	v35.CurrentCamera = v39
	local v40 = v38.X
	local v41 = v38.Y
	local v42 = v38.Z
	local v43 = math.max(v40, v41, v42)
	local v44 = (Vector3.new(-0.57357645, 0.35, -0.81915206)).Unit
	v39.CFrame = CFrame.lookAt(v37.Position + v44 * v43 * 2.4, v37.Position)
	return v35
end
local v46 = v_u_14.screen("DashcamShop", 20, v_u_17:WaitForChild("PlayerGui"))
local v_u_47 = v_u_14.window({
	["gui"] = nil,
	["name"] = "DashcamShopWindow",
	["title"] = nil,
	["sub"] = "\224\184\163\224\185\137\224\184\178\224\184\153\224\184\129\224\184\165\224\185\137\224\184\173\224\184\135\224\184\149\224\184\180\224\184\148\224\184\163\224\184\150 \194\183 \224\185\128\224\184\132\224\184\178\224\184\153\224\185\140\224\185\128\224\184\149\224\184\173\224\184\163\224\185\140\224\184\130\224\184\178\224\184\162",
	["icon"] = "camera",
	["grad"] = "red",
	["dock"] = "right",
	["dockSize"] = nil,
	["touchDockSize"] = nil,
	["max"] = nil,
	["gui"] = v46,
	["title"] = v_u_12.NAME,
	["dockSize"] = Vector2.new(0.3, 0.6),
	["touchDockSize"] = Vector2.new(0.52, 0.9),
	["max"] = Vector2.new(470, 540)
})
local v48 = v_u_14.new("ScrollingFrame", {
	["BackgroundTransparency"] = 1,
	["BorderSizePixel"] = 0,
	["ScrollBarThickness"] = 4,
	["CanvasSize"] = nil,
	["AutomaticCanvasSize"] = nil,
	["ScrollingDirection"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["CanvasSize"] = UDim2.new(),
	["AutomaticCanvasSize"] = Enum.AutomaticSize.Y,
	["ScrollingDirection"] = Enum.ScrollingDirection.Y,
	["Size"] = UDim2.fromScale(1, 1),
	["Parent"] = v_u_47.body
})
v_u_14.new("UIListLayout", {
	["Padding"] = UDim.new(0, 10),
	["SortOrder"] = Enum.SortOrder.LayoutOrder,
	["Parent"] = v48
})
v_u_14.new("UIPadding", {
	["PaddingTop"] = UDim.new(0, 4),
	["PaddingRight"] = UDim.new(0, 6),
	["PaddingBottom"] = UDim.new(0, 10),
	["Parent"] = v48
})
local v49 = v_u_14.new("Frame", {
	["BackgroundColor3"] = nil,
	["BackgroundTransparency"] = 0.3,
	["BorderSizePixel"] = 0,
	["Size"] = nil,
	["LayoutOrder"] = 0,
	["Parent"] = nil,
	["BackgroundColor3"] = v_u_14.CARD_DARK,
	["Size"] = UDim2.new(1, 0, 0, 52),
	["Parent"] = v48
})
v_u_14.corner(v49, 12)
v_u_14.border(v49, Color3.new(1, 1, 1), 0.9, 1)
local v50 = v_u_16.make("scooter", v_u_14.TEXT_DIM, 22)
v50.AnchorPoint = Vector2.new(0, 0.5)
v50.Position = UDim2.new(0, 12, 0.5, 0)
v50.Parent = v49
v_u_14.text({
	["Text"] = "\224\184\139\224\184\183\224\185\137\224\184\173\224\184\129\224\184\165\224\185\137\224\184\173\224\184\135\224\184\151\224\184\181\224\185\136\224\184\153\224\184\181\224\185\136 \194\183 \224\184\149\224\184\180\224\184\148\224\184\149\224\184\177\224\185\137\224\184\135: \224\184\130\224\184\181\224\185\136\224\184\163\224\184\150\224\185\128\224\184\130\224\185\137\224\184\178\224\184\138\224\185\136\224\184\173\224\184\135\224\184\149\224\184\180\224\184\148\224\184\149\224\184\177\224\185\137\224\184\135\224\184\130\224\185\137\224\184\178\224\184\135\224\184\163\224\185\137\224\184\178\224\184\153 \224\185\129\224\184\165\224\185\137\224\184\167\224\184\129\224\184\148\224\184\155\224\184\184\224\185\136\224\184\161 \224\184\149\224\184\180\224\184\148\224\184\129\224\184\165\224\185\137\224\184\173\224\184\135",
	["TextSize"] = 14,
	["TextColor3"] = nil,
	["TextXAlignment"] = nil,
	["TextWrapped"] = true,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["TextColor3"] = v_u_14.TEXT_DIM,
	["TextXAlignment"] = Enum.TextXAlignment.Left,
	["Position"] = UDim2.fromOffset(44, 0),
	["Size"] = UDim2.new(1, -54, 1, 0),
	["Parent"] = v49
})
local v_u_51 = false
local v_u_52 = {}
local v_u_53 = {}
local v_u_54 = nil
local function v_u_61(p55, ...) -- name: call
	-- upvalues: (ref) v_u_51, (copy) v_u_1, (copy) v_u_18, (copy) v_u_15, (ref) v_u_54
	if v_u_51 then
		return false
	end
	v_u_51 = true
	local v56 = v_u_1.invoke
	local v57 = v_u_18
	local v58, v59, v60 = pcall(v56, v57, p55, ...)
	v_u_51 = false
	if v58 then
		if v60 then
			v_u_15.show(v60, v59 and "ok" or "error")
		end
	else
		v_u_15.show("\224\185\128\224\184\138\224\184\183\224\185\136\224\184\173\224\184\161\224\184\149\224\185\136\224\184\173\224\185\132\224\184\161\224\185\136\224\185\132\224\184\148\224\185\137 \224\184\165\224\184\173\224\184\135\224\185\131\224\184\171\224\184\161\224\185\136", "error")
		v59 = false
	end
	v_u_54()
	return v59 == true
end
local v_u_62 = v_u_51
for v63, v_u_64 in v_u_12.CAMERAS do
	if v_u_64.hidden then
		continue
	end
	local v65 = v_u_10.item(v_u_64.item)
	local v66 = v_u_14.new("Frame", {
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.15,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["LayoutOrder"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_14.CARD_DARK,
		["Size"] = UDim2.new(1, 0, 0, 170),
		["LayoutOrder"] = 100 + v63,
		["Parent"] = v48
	})
	v_u_14.corner(v66, 14)
	v_u_14.border(v66, Color3.new(1, 1, 1), 0.88, 1)
	local v67 = v_u_14.new("Frame", {
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = Color3.new(1, 1, 1),
		["Position"] = UDim2.fromOffset(12, 12),
		["Size"] = UDim2.fromOffset(48, 48),
		["Parent"] = v66
	})
	v_u_14.corner(v67, 12)
	v_u_14.new("UIGradient", {
		["Rotation"] = 90,
		["Color"] = nil,
		["Parent"] = nil,
		["Color"] = ColorSequence.new(Color3.fromRGB(235, 60, 60), Color3.fromRGB(160, 20, 30)),
		["Parent"] = v67
	})
	local v68 = v_u_16.make("camera", Color3.new(1, 1, 1), 28)
	v68.AnchorPoint = Vector2.new(0.5, 0.5)
	v68.Position = UDim2.fromScale(0.5, 0.5)
	v68.Parent = v67
	v_u_14.text({
		["Text"] = nil,
		["TextSize"] = 19,
		["FontFace"] = nil,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Text"] = v_u_64.th,
		["FontFace"] = v_u_14.FONT_HEAVY,
		["TextColor3"] = v_u_14.TEXT,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["Position"] = UDim2.fromOffset(72, 12),
		["Size"] = UDim2.new(1, -84, 0, 24),
		["Parent"] = v66
	})
	local v69 = v_u_14.text({
		["Text"] = "",
		["TextSize"] = 14,
		["FontFace"] = nil,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["FontFace"] = v_u_14.FONT_BOLD,
		["TextColor3"] = v_u_14.TEXT_DIM,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["Position"] = UDim2.fromOffset(72, 38),
		["Size"] = UDim2.new(1, -84, 0, 20),
		["Parent"] = v66
	})
	v_u_14.text({
		["Text"] = nil,
		["TextSize"] = 13,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["TextWrapped"] = true,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Text"] = v_u_64.line,
		["TextColor3"] = v_u_14.TEXT_DIM,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["Position"] = UDim2.fromOffset(12, 68),
		["Size"] = UDim2.new(1, -24, 0, 36),
		["Parent"] = v66
	})
	local v70 = v_u_14.button({
		["name"] = "Buy",
		["text"] = nil,
		["grad"] = "gold",
		["textSize"] = 16,
		["position"] = nil,
		["size"] = nil,
		["parent"] = nil,
		["radius"] = 10,
		["text"] = "\224\184\139\224\184\183\224\185\137\224\184\173  " .. v_u_9.formatCash(v65 and (v65.price or 0) or 0),
		["position"] = UDim2.new(0, 12, 1, -54),
		["size"] = UDim2.new(1, -24, 0, 42),
		["parent"] = v66
	})
	v70.Activated:Connect(function()
		-- upvalues: (copy) v_u_61, (copy) v_u_64
		v_u_61("Buy", v_u_64.id)
	end)
	local v71 = v_u_14.new("Frame", {
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Position"] = UDim2.new(0, 12, 1, -54),
		["Size"] = UDim2.new(1, -24, 0, 42),
		["Parent"] = v66
	})
	v_u_14.new("UIListLayout", {
		["FillDirection"] = Enum.FillDirection.Horizontal,
		["Padding"] = UDim.new(0, 8),
		["SortOrder"] = Enum.SortOrder.LayoutOrder,
		["Parent"] = v71
	})
	local v72 = {}
	for _, v73 in v_u_64.mounts do
		local v74 = {
			["id"] = v73.id,
			["th"] = v73.th
		}
		table.insert(v72, v74)
	end
	table.insert(v72, {
		["id"] = "Off",
		["th"] = "\224\184\150\224\184\173\224\184\148"
	})
	local v75 = {}
	for v76, v_u_77 in v72 do
		local v78 = v_u_14.button({
			["name"] = nil,
			["text"] = nil,
			["grad"] = "dark",
			["textSize"] = 14,
			["size"] = nil,
			["parent"] = nil,
			["radius"] = 10,
			["name"] = v_u_77.id,
			["text"] = v_u_77.th,
			["size"] = UDim2.new(1 / #v72, (#v72 - 1) * -8 / #v72, 1, 0),
			["parent"] = v71
		})
		v78.LayoutOrder = v76
		v78.Activated:Connect(function()
			-- upvalues: (copy) v_u_61, (copy) v_u_64, (copy) v_u_77
			v_u_61("Mount", v_u_64.id, v_u_77.id)
		end)
		v75[v_u_77.id] = v78
	end
	v_u_52[v63] = {
		["cam"] = v_u_64,
		["price"] = v65 and v65.price or 0,
		["status"] = v69,
		["buy"] = v70,
		["row"] = v71,
		["buttons"] = v75
	}
end
v_u_14.text({
	["Text"] = "\224\184\129\224\184\165\224\185\137\224\184\173\224\184\135\224\184\149\224\184\180\224\184\148\224\185\132\224\184\148\224\185\137\224\184\151\224\184\184\224\184\129\224\184\136\224\184\184\224\184\148 \224\184\151\224\184\184\224\184\129\224\184\132\224\184\177\224\184\153",
	["TextSize"] = 15,
	["FontFace"] = nil,
	["TextColor3"] = nil,
	["TextXAlignment"] = nil,
	["Size"] = nil,
	["LayoutOrder"] = 1,
	["Parent"] = nil,
	["FontFace"] = v_u_14.FONT_BOLD,
	["TextColor3"] = v_u_14.TEXT,
	["TextXAlignment"] = Enum.TextXAlignment.Left,
	["Size"] = UDim2.new(1, 0, 0, 22),
	["Parent"] = v48
})
for v79, v_u_80 in v_u_12.PARTS do
	local v81 = v_u_14.new("Frame", {
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.15,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["LayoutOrder"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_14.CARD_DARK,
		["Size"] = UDim2.new(1, 0, 0, 148),
		["LayoutOrder"] = 1 + v79,
		["Parent"] = v48
	})
	v_u_14.corner(v81, 14)
	v_u_14.border(v81, Color3.new(1, 1, 1), 0.88, 1)
	local v82 = v_u_14.new("Frame", {
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["ClipsDescendants"] = true,
		["Parent"] = nil,
		["BackgroundColor3"] = Color3.fromRGB(28, 30, 40),
		["Position"] = UDim2.fromOffset(12, 12),
		["Size"] = UDim2.fromOffset(66, 66),
		["Parent"] = v81
	})
	v_u_14.corner(v82, 12)
	v_u_14.new("UIGradient", {
		["Rotation"] = 90,
		["Color"] = nil,
		["Parent"] = nil,
		["Color"] = ColorSequence.new(Color3.fromRGB(96, 102, 128), Color3.fromRGB(26, 28, 38)),
		["Parent"] = v82
	})
	v45(v82, v_u_80.id)
	v_u_14.text({
		["Text"] = nil,
		["TextSize"] = 18,
		["FontFace"] = nil,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Text"] = v_u_80.th,
		["FontFace"] = v_u_14.FONT_HEAVY,
		["TextColor3"] = v_u_14.TEXT,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["Position"] = UDim2.fromOffset(90, 12),
		["Size"] = UDim2.new(1, -102, 0, 22),
		["Parent"] = v81
	})
	local v83 = v_u_14.text({
		["Text"] = "",
		["TextSize"] = 14,
		["FontFace"] = nil,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["FontFace"] = v_u_14.FONT_BOLD,
		["TextColor3"] = v_u_14.TEXT_DIM,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["Position"] = UDim2.fromOffset(90, 36),
		["Size"] = UDim2.new(1, -102, 0, 18),
		["Parent"] = v81
	})
	v_u_14.text({
		["Text"] = nil,
		["TextSize"] = 12,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["TextWrapped"] = true,
		["TextYAlignment"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Text"] = v_u_80.line,
		["TextColor3"] = v_u_14.TEXT_DIM,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["TextYAlignment"] = Enum.TextYAlignment.Top,
		["Position"] = UDim2.fromOffset(90, 58),
		["Size"] = UDim2.new(1, -102, 0, 30),
		["Parent"] = v81
	})
	local v84 = v_u_14.button
	local v85 = {
		["name"] = "Buy",
		["text"] = nil,
		["grad"] = "gold",
		["textSize"] = 16,
		["position"] = nil,
		["size"] = nil,
		["parent"] = nil,
		["radius"] = 10
	}
	local v86 = v_u_9.formatCash
	local v87 = v_u_10.item(v_u_80.item)
	v85.text = "\224\184\139\224\184\183\224\185\137\224\184\173  " .. v86(v87 and v87.price or 0)
	v85.position = UDim2.new(0, 12, 1, -52)
	v85.size = UDim2.new(1, -24, 0, 40)
	v85.parent = v81
	local v88 = v84(v85)
	v88.Activated:Connect(function()
		-- upvalues: (copy) v_u_61, (copy) v_u_80
		v_u_61("Buy", v_u_80.id)
	end)
	v_u_53[v79] = {
		["p"] = v_u_80,
		["status"] = v83,
		["buy"] = v88,
		["note"] = v_u_14.text({
			["Text"] = "\224\184\149\224\184\180\224\184\148\224\184\149\224\184\177\224\185\137\224\184\135: \224\184\130\224\184\181\224\185\136\224\184\163\224\184\150\224\185\128\224\184\130\224\185\137\224\184\178\224\184\138\224\185\136\224\184\173\224\184\135\224\184\149\224\184\180\224\184\148\224\184\149\224\184\177\224\185\137\224\184\135\224\184\130\224\185\137\224\184\178\224\184\135\224\184\163\224\185\137\224\184\178\224\184\153 \224\185\129\224\184\165\224\185\137\224\184\167\224\184\129\224\184\148\224\184\155\224\184\184\224\185\136\224\184\161 \224\184\149\224\184\180\224\184\148\224\184\129\224\184\165\224\185\137\224\184\173\224\184\135",
			["TextSize"] = 13,
			["FontFace"] = nil,
			["TextColor3"] = nil,
			["TextWrapped"] = true,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["FontFace"] = v_u_14.FONT_BOLD,
			["TextColor3"] = v_u_14.GREEN_TEXT,
			["Position"] = UDim2.new(0, 12, 1, -48),
			["Size"] = UDim2.new(1, -24, 0, 32),
			["Parent"] = v81
		})
	}
end
v_u_54 = function() -- name: refresh
	-- upvalues: (copy) v_u_12, (copy) v_u_17, (copy) v_u_52, (copy) v_u_10, (copy) v_u_9, (copy) v_u_14, (copy) v_u_11, (copy) v_u_19, (copy) v_u_53, (ref) v_u_29
	local v89 = v_u_12.vehicleInBay(v_u_17.UserId)
	for _, v90 in v_u_52 do
		local v91 = v_u_10.count(v_u_17, v90.cam.item) > 0
		v90.status.Text = v91 and "\224\184\130\224\184\173\224\184\135\224\184\132\224\184\184\224\184\147\224\185\129\224\184\165\224\185\137\224\184\167" or v_u_9.formatCash(v90.price)
		local v92 = v90.status
		local v93
		if v91 then
			v93 = v_u_14.GREEN_TEXT
		else
			v93 = v_u_14.YELLOW
		end
		v92.TextColor3 = v93
		v90.buy.Visible = not v91
		v90.row.Visible = v91
		local v94
		if v89 then
			v94 = v89:GetAttribute(v_u_11.ATTRIBUTE)
		else
			v94 = v89
		end
		for v95, v96 in v90.buttons do
			local v97
			if v89 == nil then
				v97 = false
			elseif v95 == "Off" then
				v97 = v94 == nil
			else
				v97 = v94 == v95
			end
			local v98 = v_u_14.setButton
			local v99 = v97 and "gold" or (v89 and "dark" or v_u_19)
			local v100 = nil
			local v101
			if v97 then
				v101 = v_u_14.DARK_TEXT
			elseif v89 then
				v101 = v_u_14.TEXT
			else
				v101 = v_u_14.TEXT_DIM
			end
			v98(v96, v99, v100, v101)
		end
	end
	for _, v102 in v_u_53 do
		local v103 = v_u_10.count(v_u_17, v102.p.item) > 0
		local v104 = v102.status
		local v105
		if v103 then
			v105 = "\224\184\130\224\184\173\224\184\135\224\184\132\224\184\184\224\184\147\224\185\129\224\184\165\224\185\137\224\184\167 \194\183 \224\184\149\224\184\180\224\184\148\224\185\132\224\184\148\224\185\137\224\184\151\224\184\184\224\184\129\224\184\132\224\184\177\224\184\153"
		else
			local v106 = v_u_9.formatCash
			local v107 = v102.p
			local v108 = v_u_10.item(v107.item)
			v105 = v106(v108 and v108.price or 0)
		end
		v104.Text = v105
		local v109 = v102.status
		local v110
		if v103 then
			v110 = v_u_14.GREEN_TEXT
		else
			v110 = v_u_14.YELLOW
		end
		v109.TextColor3 = v110
		v102.buy.Visible = not v103
		v102.note.Visible = v103
	end
	if v_u_29 then
		v_u_29.refresh()
	end
end
local function v_u_114() -- name: open
	-- upvalues: (ref) v_u_29, (copy) v_u_17, (ref) v_u_54, (copy) v_u_47
	if v_u_29 and v_u_29.isOpen() then
		return
	else
		local v111 = v_u_17.Character
		if v111 then
			v111 = v_u_17.Character:FindFirstChild("HumanoidRootPart")
		end
		if v111 then
			local v_u_112 = v111.Position
			v_u_54()
			if not v_u_47.isOpen() then
				v_u_47.setOpen(true)
				task.spawn(function()
					-- upvalues: (ref) v_u_47, (ref) v_u_17, (copy) v_u_112, (ref) v_u_54
					while v_u_47.isOpen() do
						task.wait(0.5)
						local v113 = v_u_17.Character
						if v113 then
							v113 = v_u_17.Character:FindFirstChild("HumanoidRootPart")
						end
						if not v113 or (v113.Position - v_u_112).Magnitude > 30 then
							v_u_47.setOpen(false)
							return
						end
						v_u_54()
					end
				end)
			end
		else
			return
		end
	end
end
local function v_u_118() -- name: hasCameras
	-- upvalues: (copy) v_u_12, (copy) v_u_10, (copy) v_u_17
	for _, v115 in v_u_12.PARTS do
		if v_u_10.count(v_u_17, v115.item) <= 0 then
			continue
		end
		return true
	end
	local v116 = v_u_12.vehicleInBay(v_u_17.UserId)
	local v117
	if v116 == nil then
		v117 = false
	else
		v117 = #v_u_12.read(v116) > 0
	end
	return v117
end
local function v_u_125() -- name: updatePrompts
	-- upvalues: (ref) v_u_29, (copy) v_u_118, (copy) v_u_12
	local v119 = workspace:FindFirstChild("Map")
	if v119 then
		v119 = v119:FindFirstChild("CamShop")
	end
	if v119 then
		local v120
		if v_u_29 == nil then
			v120 = false
		else
			v120 = v_u_29.isOpen()
		end
		local v121 = not v120
		if v121 then
			v121 = v_u_118()
		end
		for _, v122 in v119:GetChildren() do
			local v123 = v122:IsA("BasePart")
			if v123 then
				v123 = v122:FindFirstChild(v_u_12.PROMPT)
			end
			if not (v123 and v123:IsA("ProximityPrompt")) then
				continue
			end
			local v124
			if v122.Name == "DashcamCounterPrompt" then
				v124 = not v120
			else
				v124 = v121
			end
			if v123.Enabled == v124 then
				continue
			end
			v123.Enabled = v124
		end
	end
end
v3.PromptTriggered:Connect(function(p126)
	-- upvalues: (copy) v_u_12, (copy) v_u_114
	if p126.Name == v_u_12.PROMPT and (p126.Parent and p126.Parent.Name == "DashcamCounterPrompt") then
		v_u_114()
	end
end)
local v127 = v_u_14.screen("DashcamRideIn", 6, v_u_17:WaitForChild("PlayerGui"))
local v_u_128 = v_u_14.button({
	["name"] = "FitCameras",
	["text"] = "\224\184\149\224\184\180\224\184\148\224\184\129\224\184\165\224\185\137\224\184\173\224\184\135",
	["icon"] = "camera",
	["grad"] = "gold",
	["textSize"] = 22,
	["anchor"] = nil,
	["position"] = nil,
	["size"] = nil,
	["parent"] = nil,
	["radius"] = 14,
	["anchor"] = Vector2.new(0.5, 0),
	["position"] = UDim2.new(0.5, 0, 0, 70),
	["size"] = UDim2.fromOffset(240, 58),
	["parent"] = v127
})
v_u_128.Visible = false
v_u_128.Activated:Connect(function()
	-- upvalues: (copy) v_u_12, (copy) v_u_17, (ref) v_u_29, (copy) v_u_15
	local v129 = v_u_12.driven(v_u_17)
	if not v129 or (v129:GetAttribute("OwnerUserId") ~= v_u_17.UserId or not v_u_12.inBay(v129:GetPivot().Position)) then
		v129 = nil
	end
	if v129 and v_u_29 then
		local v130 = v129:FindFirstChild("Chassis") or v129.PrimaryPart
		if v130 and v130.AssemblyLinearVelocity.Magnitude > 3 then
			v_u_15.show("\224\184\171\224\184\162\224\184\184\224\184\148\224\184\163\224\184\150\224\184\129\224\185\136\224\184\173\224\184\153 \224\185\129\224\184\165\224\185\137\224\184\167\224\184\132\224\185\136\224\184\173\224\184\162\224\184\149\224\184\180\224\184\148\224\184\129\224\184\165\224\185\137\224\184\173\224\184\135", "info")
		else
			v_u_29.open(nil)
		end
	else
		return
	end
end)
v_u_17.AttributeChanged:Connect(function(p131)
	-- upvalues: (copy) v_u_47, (ref) v_u_29, (ref) v_u_54
	if (v_u_47.isOpen() or v_u_29 and v_u_29.isOpen()) and (p131 == "Cash" or p131:sub(1, 5) == "Item_") then
		v_u_54()
	end
end)
task.spawn(function()
	-- upvalues: (copy) v_u_125, (copy) v_u_12, (copy) v_u_17, (ref) v_u_29, (copy) v_u_118, (copy) v_u_128
	while true do
		task.wait(0.3)
		v_u_125()
		local v132 = false
		local v133 = v_u_12.driven(v_u_17)
		if not v133 or (v133:GetAttribute("OwnerUserId") ~= v_u_17.UserId or not v_u_12.inBay(v133:GetPivot().Position)) then
			v133 = nil
		end
		if v133 ~= nil then
			local v134 = v_u_29
			if v134 then
				v134 = v_u_29.isOpen()
			end
			v132 = not v134
			if v132 then
				v132 = v_u_118()
			end
		end
		if v_u_128.Visible == v132 then
			continue
		end
		v_u_128.Visible = v132
	end
end)
local v_u_135 = v_u_14.screen("DashcamEditor", 9, v_u_17:WaitForChild("PlayerGui"))
v_u_135.Enabled = false
local v_u_136 = {
	{
		["key"] = "select",
		["label"] = "\224\185\128\224\184\165\224\184\183\224\184\173\224\184\129",
		["keyCode"] = nil,
		["keyCode"] = Enum.KeyCode.One
	},
	{
		["key"] = "move",
		["label"] = "\224\185\128\224\184\132\224\184\165\224\184\183\224\185\136\224\184\173\224\184\153\224\184\162\224\185\137\224\184\178\224\184\162",
		["keyCode"] = nil,
		["keyCode"] = Enum.KeyCode.Two
	},
	{
		["key"] = "height",
		["label"] = "\224\184\130\224\184\182\224\185\137\224\184\153\224\184\165\224\184\135",
		["keyCode"] = nil,
		["keyCode"] = Enum.KeyCode.Three
	},
	{
		["key"] = "rotate",
		["label"] = "\224\184\171\224\184\161\224\184\184\224\184\153",
		["keyCode"] = nil,
		["keyCode"] = Enum.KeyCode.Four
	},
	{
		["key"] = "tilt",
		["label"] = "\224\185\128\224\184\137\224\184\181\224\184\162\224\184\135",
		["keyCode"] = nil,
		["keyCode"] = Enum.KeyCode.Five
	},
	{
		["key"] = "scale",
		["label"] = "\224\184\155\224\184\163\224\184\177\224\184\154\224\184\130\224\184\153\224\184\178\224\184\148",
		["keyCode"] = nil,
		["keyCode"] = Enum.KeyCode.Six
	}
}
local v_u_137 = nil
local v_u_138 = "select"
local v_u_139 = nil
local v_u_140 = nil
local v_u_141 = false
local v_u_142 = nil
local v_u_143 = nil
local v_u_144 = nil
local function v_u_152(p145, p146, p147, p148, p149, p150, p151) -- name: bar
	-- upvalues: (copy) v_u_14
	return v_u_14.new("Frame", {
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Rotation"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = p149,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.new(0.5, p150 or 0, 0.5, p151 or 0),
		["Size"] = UDim2.fromOffset(p146, p147),
		["Rotation"] = p148 or 0,
		["Parent"] = p145
	})
end
local v_u_153 = v_u_14.panel({
	["Name"] = "Panel",
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["AnchorPoint"] = Vector2.new(0, 0.5),
	["Position"] = UDim2.new(0, 16, 0.5, 0),
	["Size"] = UDim2.fromOffset(300, 596),
	["Parent"] = v_u_135
})
v_u_14.autoScale(v_u_153, v_u_14.PHONE_SHRINK)
local v154
if v_u_14.isTouch() then
	local v155 = v_u_14.new("ScrollingFrame", {
		["Name"] = "Body",
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["CanvasSize"] = nil,
		["ScrollBarThickness"] = 3,
		["ScrollingDirection"] = nil,
		["ElasticBehavior"] = nil,
		["Parent"] = nil,
		["Position"] = UDim2.fromOffset(0, 60),
		["Size"] = UDim2.new(1, 0, 1, -128),
		["CanvasSize"] = UDim2.fromOffset(0, 464),
		["ScrollingDirection"] = Enum.ScrollingDirection.Y,
		["ElasticBehavior"] = Enum.ElasticBehavior.Never,
		["Parent"] = v_u_153
	})
	v154 = v_u_14.new("Frame", {
		["Name"] = "Sheet",
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Position"] = UDim2.fromOffset(0, -60),
		["Size"] = UDim2.new(1, 0, 0, 524),
		["Parent"] = v155
	})
else
	v154 = v_u_153
end
local function v163() -- name: fitPanel
	-- upvalues: (copy) v_u_14, (copy) v_u_135, (copy) v_u_8, (copy) v_u_153
	local v156 = workspace.CurrentCamera
	if v156 and v_u_14.isTouch() then
		local v157 = v_u_14.scaleFor(v156.ViewportSize, v_u_14.PHONE_SHRINK)
		local v158 = v_u_135.AbsoluteSize.Y
		if v158 <= 0 then
			v158 = v156.ViewportSize.Y - v_u_8:GetGuiInset().Y
		end
		local v159 = v_u_153
		local v160 = UDim2.fromOffset
		local v161 = (v158 - 16) / math.max(v157, 0.1)
		local v162 = math.floor(v161)
		v159.Size = v160(300, (math.clamp(v162, 248, 596)))
	end
end
v163()
v_u_135:GetPropertyChangedSignal("AbsoluteSize"):Connect(v163)
local v164, _, v_u_165 = v_u_14.header(v_u_153, "camera", "gold", "\224\184\149\224\184\180\224\184\148\224\184\129\224\184\165\224\185\137\224\184\173\224\184\135", "")
v164.Position = UDim2.fromOffset(14, 12)
v164.Size = UDim2.new(1, -100, 0, 46)
local v_u_166 = v_u_14.text({
	["Text"] = nil,
	["TextSize"] = 13,
	["FontFace"] = nil,
	["BackgroundTransparency"] = 0,
	["BackgroundColor3"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["Text"] = "0 / " .. v_u_27,
	["FontFace"] = v_u_14.FONT_BOLD,
	["BackgroundColor3"] = v_u_14.CARD,
	["Position"] = UDim2.fromOffset(218, 22),
	["Size"] = UDim2.fromOffset(66, 26),
	["Parent"] = v_u_153
})
v_u_14.corner(v_u_166, 13)
v_u_14.text({
	["Text"] = "\224\185\128\224\184\165\224\184\183\224\184\173\224\184\129\224\184\129\224\184\165\224\185\137\224\184\173\224\184\135 \224\185\129\224\184\165\224\185\137\224\184\167\224\184\132\224\184\165\224\184\180\224\184\129\224\184\149\224\184\163\224\184\135\224\184\151\224\184\181\224\185\136\224\184\136\224\184\176\224\184\149\224\184\180\224\184\148\224\184\154\224\184\153\224\184\163\224\184\150",
	["TextSize"] = 13,
	["FontFace"] = nil,
	["TextColor3"] = nil,
	["TextXAlignment"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["FontFace"] = v_u_14.FONT_BOLD,
	["TextColor3"] = v_u_14.TEXT_DIM,
	["TextXAlignment"] = Enum.TextXAlignment.Left,
	["Position"] = UDim2.fromOffset(16, 66),
	["Size"] = UDim2.new(1, -32, 0, 18),
	["Parent"] = v154
})
local v_u_167 = nil
local v_u_168 = {}
for v169, v_u_170 in v_u_12.PARTS do
	local v171 = v_u_14.new("TextButton", {
		["Name"] = nil,
		["Text"] = "",
		["AutoButtonColor"] = true,
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Name"] = v_u_170.id,
		["BackgroundColor3"] = v_u_14.CARD_DARK,
		["Position"] = UDim2.fromOffset(16 + (v169 - 1) * 138, 88),
		["Size"] = UDim2.fromOffset(130, 132),
		["Parent"] = v154
	})
	v_u_14.corner(v171, 12)
	local v172 = v_u_14.new("UIStroke", {
		["Color"] = nil,
		["Thickness"] = 2,
		["Enabled"] = false,
		["ApplyStrokeMode"] = nil,
		["Parent"] = nil,
		["Color"] = v_u_20,
		["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
		["Parent"] = v171
	})
	local v173 = v_u_14.new("Frame", {
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["ClipsDescendants"] = true,
		["Parent"] = nil,
		["BackgroundColor3"] = Color3.fromRGB(28, 30, 40),
		["Position"] = UDim2.fromOffset(4, 4),
		["Size"] = UDim2.new(1, -8, 0, 80),
		["Parent"] = v171
	})
	v_u_14.corner(v173, 9)
	v_u_14.new("UIGradient", {
		["Rotation"] = 90,
		["Color"] = nil,
		["Parent"] = nil,
		["Color"] = ColorSequence.new(Color3.fromRGB(96, 102, 128), Color3.fromRGB(26, 28, 38)),
		["Parent"] = v173
	})
	local v174 = v45(v173, v_u_170.id)
	v_u_14.text({
		["Text"] = nil,
		["TextSize"] = 13,
		["FontFace"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Text"] = v_u_170.th,
		["FontFace"] = v_u_14.FONT_BOLD,
		["Position"] = UDim2.fromOffset(4, 86),
		["Size"] = UDim2.new(1, -8, 0, 20),
		["Parent"] = v171
	})
	local v175 = v_u_14.text({
		["Text"] = "",
		["TextSize"] = 11,
		["FontFace"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["FontFace"] = v_u_14.FONT_BOLD,
		["Position"] = UDim2.fromOffset(4, 107),
		["Size"] = UDim2.new(1, -8, 0, 18),
		["Parent"] = v171
	})
	v171.Activated:Connect(function()
		-- upvalues: (ref) v_u_167, (copy) v_u_170
		v_u_167(v_u_170)
	end)
	v_u_168[v_u_170.id] = {
		["button"] = v171,
		["edge"] = v172,
		["status"] = v175,
		["p"] = v_u_170,
		["vp"] = v174
	}
end
v_u_14.text({
	["Text"] = "\224\184\154\224\184\153\224\184\163\224\184\150\224\184\132\224\184\177\224\184\153\224\184\153\224\184\181\224\185\137",
	["TextSize"] = 13,
	["FontFace"] = nil,
	["TextColor3"] = nil,
	["TextXAlignment"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["FontFace"] = v_u_14.FONT_BOLD,
	["TextColor3"] = v_u_14.TEXT_DIM,
	["TextXAlignment"] = Enum.TextXAlignment.Left,
	["Position"] = UDim2.fromOffset(16, 228),
	["Size"] = UDim2.new(1, -32, 0, 18),
	["Parent"] = v154
})
local v_u_176 = v_u_14.new("ScrollingFrame", {
	["BackgroundColor3"] = nil,
	["BorderSizePixel"] = 0,
	["Position"] = nil,
	["Size"] = nil,
	["ScrollBarThickness"] = 4,
	["CanvasSize"] = nil,
	["AutomaticCanvasSize"] = nil,
	["Parent"] = nil,
	["BackgroundColor3"] = v_u_14.CARD_DARK,
	["Position"] = UDim2.fromOffset(16, 250),
	["Size"] = UDim2.new(1, -32, 0, 104),
	["CanvasSize"] = UDim2.new(),
	["AutomaticCanvasSize"] = Enum.AutomaticSize.Y,
	["Parent"] = v154
})
v_u_14.corner(v_u_176, 10)
v_u_14.new("UIPadding", {
	["PaddingTop"] = UDim.new(0, 5),
	["PaddingLeft"] = UDim.new(0, 5),
	["PaddingRight"] = UDim.new(0, 5),
	["PaddingBottom"] = UDim.new(0, 5),
	["Parent"] = v_u_176
})
v_u_14.new("UIListLayout", {
	["Padding"] = UDim.new(0, 4),
	["SortOrder"] = Enum.SortOrder.LayoutOrder,
	["Parent"] = v_u_176
})
local v_u_177 = v_u_14.text({
	["Text"] = "\224\184\162\224\184\177\224\184\135\224\185\132\224\184\161\224\185\136\224\184\161\224\184\181\224\184\129\224\184\165\224\185\137\224\184\173\224\184\135 \194\183 \224\185\128\224\184\165\224\184\183\224\184\173\224\184\129\224\184\129\224\184\165\224\185\137\224\184\173\224\184\135\224\184\148\224\185\137\224\184\178\224\184\153\224\184\154\224\184\153 \224\185\129\224\184\165\224\185\137\224\184\167\224\184\132\224\184\165\224\184\180\224\184\129\224\184\154\224\184\153\224\184\163\224\184\150",
	["TextSize"] = 12,
	["TextColor3"] = nil,
	["TextWrapped"] = true,
	["Size"] = nil,
	["LayoutOrder"] = 0,
	["Parent"] = nil,
	["TextColor3"] = v_u_14.TEXT_DIM,
	["Size"] = UDim2.new(1, 0, 0, 40),
	["Parent"] = v_u_176
})
local v_u_178 = v_u_14.text({
	["Text"] = "",
	["TextSize"] = 12,
	["TextColor3"] = nil,
	["TextWrapped"] = true,
	["TextXAlignment"] = nil,
	["TextYAlignment"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["TextColor3"] = v_u_14.TEXT_DIM,
	["TextXAlignment"] = Enum.TextXAlignment.Left,
	["TextYAlignment"] = Enum.TextYAlignment.Top,
	["Position"] = UDim2.fromOffset(16, 362),
	["Size"] = UDim2.new(1, -32, 0, 32),
	["Parent"] = v154
})
local v_u_179 = {}
local v180 = v_u_14.new("Frame", {
	["Name"] = "FieldOfView",
	["BackgroundTransparency"] = 1,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["Position"] = UDim2.fromOffset(16, 398),
	["Size"] = UDim2.new(1, -32, 0, 122),
	["Parent"] = v154
})
v_u_14.text({
	["Text"] = "Field of view \194\183 \224\184\161\224\184\184\224\184\161\224\184\161\224\184\173\224\184\135\224\184\129\224\184\165\224\185\137\224\184\173\224\184\135",
	["TextSize"] = 13,
	["FontFace"] = nil,
	["TextColor3"] = nil,
	["TextXAlignment"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["FontFace"] = v_u_14.FONT_BOLD,
	["TextColor3"] = v_u_14.TEXT_DIM,
	["TextXAlignment"] = Enum.TextXAlignment.Left,
	["Size"] = UDim2.new(1, -96, 0, 20),
	["Parent"] = v180
})
local v_u_181 = v_u_14.new("TextButton", {
	["Name"] = "Preview",
	["Text"] = "\224\184\148\224\184\185\224\184\149\224\184\177\224\184\167\224\184\173\224\184\162\224\185\136\224\184\178\224\184\135",
	["FontFace"] = nil,
	["TextSize"] = 12,
	["TextColor3"] = nil,
	["AutoButtonColor"] = true,
	["BackgroundColor3"] = nil,
	["BorderSizePixel"] = 0,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["FontFace"] = v_u_14.FONT_BOLD,
	["TextColor3"] = v_u_14.TEXT,
	["BackgroundColor3"] = v_u_14.CARD,
	["AnchorPoint"] = Vector2.new(1, 0),
	["Position"] = UDim2.new(1, 0, 0, -2),
	["Size"] = UDim2.fromOffset(92, 24),
	["Parent"] = v180
})
v_u_14.corner(v_u_181, 12)
v_u_181.Activated:Connect(function()
	-- upvalues: (copy) v_u_179
	if v_u_179.preview then
		v_u_179.preview()
	end
end)
local v182 = v_u_14.new("Frame", {
	["BackgroundTransparency"] = 1,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["Position"] = UDim2.fromOffset(0, 26),
	["Size"] = UDim2.new(1, 0, 0, 34),
	["Parent"] = v180
})
v_u_14.new("UIListLayout", {
	["FillDirection"] = Enum.FillDirection.Horizontal,
	["Padding"] = UDim.new(0, 4),
	["SortOrder"] = Enum.SortOrder.LayoutOrder,
	["Parent"] = v182
})
local v_u_183 = {}
local v_u_184 = nil
local v_u_185 = {
	["yaw"] = 0,
	["pitch"] = 0,
	["curYaw"] = 0,
	["curPitch"] = 0,
	["fovAdd"] = 0
}
local v_u_186 = false
for v187, v_u_188 in v_u_12.LENS do
	local v189 = v_u_14.new("TextButton", {
		["Name"] = nil,
		["Text"] = nil,
		["FontFace"] = nil,
		["TextSize"] = 10,
		["TextColor3"] = nil,
		["AutoButtonColor"] = true,
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["LayoutOrder"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Name"] = v_u_188.id,
		["Text"] = v_u_188.th,
		["FontFace"] = v_u_14.FONT_BOLD,
		["TextColor3"] = v_u_14.TEXT,
		["BackgroundColor3"] = v_u_14.CARD,
		["LayoutOrder"] = v187,
		["Size"] = UDim2.new(1 / #v_u_12.LENS, -4 * (#v_u_12.LENS - 1) / #v_u_12.LENS, 1, 0),
		["Parent"] = v182
	})
	v_u_14.corner(v189, 8)
	local v190 = v_u_14.new("UIStroke", {
		["Color"] = nil,
		["Thickness"] = 1.5,
		["Enabled"] = false,
		["ApplyStrokeMode"] = nil,
		["Parent"] = nil,
		["Color"] = v_u_20,
		["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
		["Parent"] = v189
	})
	v189.Activated:Connect(function()
		-- upvalues: (copy) v_u_179, (copy) v_u_188
		if v_u_179.lens then
			v_u_179.lens(v_u_188)
		end
	end)
	v_u_183[v_u_188.id] = {
		["chip"] = v189,
		["edge"] = v190
	}
end
local v_u_191 = nil
local function v210(p192, p193, p194, p_u_195) -- name: slider
	-- upvalues: (copy) v_u_14, (copy) v_u_20, (copy) v_u_6, (ref) v_u_191
	local v196 = v_u_14.new("Frame", {
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Position"] = UDim2.fromOffset(0, p193),
		["Size"] = UDim2.new(1, 0, 0, 26),
		["Parent"] = p192
	})
	v_u_14.text({
		["Text"] = nil,
		["TextSize"] = 12,
		["FontFace"] = nil,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Text"] = p194,
		["FontFace"] = v_u_14.FONT_BOLD,
		["TextColor3"] = v_u_14.TEXT_DIM,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["Size"] = UDim2.fromOffset(40, 26),
		["Parent"] = v196
	})
	local v197 = v_u_14.text({
		["Text"] = "",
		["TextSize"] = 14,
		["FontFace"] = nil,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["FontFace"] = v_u_14.FONT_BOLD,
		["TextColor3"] = v_u_14.TEXT,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["Position"] = UDim2.fromOffset(40, 0),
		["Size"] = UDim2.fromOffset(58, 26),
		["Parent"] = v196
	})
	local v_u_198 = v_u_14.new("Frame", {
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_14.CARD,
		["AnchorPoint"] = Vector2.new(0, 0.5),
		["Position"] = UDim2.new(0, 104, 0.5, 0),
		["Size"] = UDim2.new(1, -112, 0, 6),
		["Parent"] = v196
	})
	v_u_14.corner(v_u_198, 3)
	local v_u_199 = v_u_14.new("Frame", {
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_20,
		["Size"] = UDim2.fromScale(0, 1),
		["Parent"] = v_u_198
	})
	v_u_14.corner(v_u_199, 3)
	local v_u_200 = v_u_14.new("Frame", {
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 3,
		["Parent"] = nil,
		["BackgroundColor3"] = Color3.new(1, 1, 1),
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0, 0.5),
		["Size"] = UDim2.fromOffset(16, 16),
		["Parent"] = v_u_198
	})
	v_u_14.corner(v_u_200, 8)
	local v201 = {
		["Color"] = nil,
		["Thickness"] = 2,
		["Parent"] = nil,
		["Color"] = v_u_20,
		["Parent"] = v_u_200
	}
	v_u_14.new("UIStroke", v201)
	local v_u_208 = {
		["value"] = 0,
		["valueLabel"] = nil,
		["holder"] = nil,
		["valueLabel"] = v197,
		["holder"] = v196,
		["set"] = function(p202) -- name: set
			-- upvalues: (copy) v_u_208, (copy) v_u_199, (copy) v_u_200
			v_u_208.value = math.clamp(p202, 0, 1)
			v_u_199.Size = UDim2.fromScale(v_u_208.value, 1)
			v_u_200.Position = UDim2.fromScale(v_u_208.value, 0.5)
		end,
		["fromInput"] = function(p203) -- name: fromInput
			-- upvalues: (ref) v_u_6, (copy) v_u_208, (copy) v_u_198, (copy) p_u_195
			local v204
			if p203.UserInputType == Enum.UserInputType.Touch then
				v204 = p203.Position.X
			else
				v204 = v_u_6:GetMouseLocation().X
			end
			local v205 = v_u_208.set
			local v206 = v204 - v_u_198.AbsolutePosition.X
			local v207 = v_u_198.AbsoluteSize.X
			v205(v206 / math.max(1, v207))
			p_u_195(v_u_208.value)
		end
	}
	v_u_14.new("TextButton", {
		["Text"] = "",
		["BackgroundTransparency"] = 1,
		["AutoButtonColor"] = false,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 4,
		["Parent"] = nil,
		["Position"] = UDim2.new(0, -10, 0, -11),
		["Size"] = UDim2.new(1, 20, 0, 28),
		["Parent"] = v_u_198
	}).InputBegan:Connect(function(p209)
		-- upvalues: (ref) v_u_191, (copy) v_u_208
		if p209.UserInputType == Enum.UserInputType.MouseButton1 or p209.UserInputType == Enum.UserInputType.Touch then
			v_u_191 = {
				["s"] = v_u_208,
				["input"] = p209
			}
			v_u_208.fromInput(p209)
		end
	end)
	return v_u_208
end
v_u_6.InputChanged:Connect(function(p211)
	-- upvalues: (ref) v_u_191
	local v212 = v_u_191
	if v212 and (p211.UserInputType == Enum.UserInputType.MouseMovement or p211 == v212.input) then
		v212.s.fromInput(p211)
	end
end)
v_u_6.InputEnded:Connect(function(p213)
	-- upvalues: (ref) v_u_191
	local v214 = v_u_191
	if v214 and (p213.UserInputType == Enum.UserInputType.MouseButton1 or p213 == v214.input) then
		v_u_191 = nil
	end
end)
local v_u_216 = v210(v180, 66, "FOV", function(p215)
	-- upvalues: (copy) v_u_179
	if v_u_179.fov then
		v_u_179.fov(p215)
	end
end)
local v_u_218 = v210(v180, 96, "\224\185\128\224\184\165\224\184\153\224\184\170\224\185\140", function(p217)
	-- upvalues: (copy) v_u_179
	if v_u_179.curve then
		v_u_179.curve(p217)
	end
end)
local v_u_219 = v_u_14.text({
	["Text"] = "\224\184\132\224\184\165\224\184\180\224\184\129\224\184\151\224\184\181\224\185\136\224\184\129\224\184\165\224\185\137\224\184\173\224\184\135\224\184\154\224\184\153\224\184\163\224\184\150 \224\185\128\224\184\158\224\184\183\224\185\136\224\184\173\224\184\155\224\184\163\224\184\177\224\184\154\224\184\161\224\184\184\224\184\161\224\184\161\224\184\173\224\184\135\224\184\130\224\184\173\224\184\135\224\184\129\224\184\165\224\185\137\224\184\173\224\184\135\224\184\149\224\184\177\224\184\167\224\184\153\224\184\177\224\185\137\224\184\153",
	["TextSize"] = 12,
	["TextColor3"] = nil,
	["TextWrapped"] = true,
	["BackgroundTransparency"] = 0.05,
	["BackgroundColor3"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["ZIndex"] = 5,
	["Parent"] = nil,
	["TextColor3"] = v_u_14.TEXT_DIM,
	["BackgroundColor3"] = v_u_14.PANEL,
	["Position"] = UDim2.fromOffset(0, 24),
	["Size"] = UDim2.new(1, 0, 1, -24),
	["Parent"] = v180
})
v_u_14.new("Frame", {
	["BackgroundColor3"] = nil,
	["BorderSizePixel"] = 0,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["BackgroundColor3"] = Color3.fromRGB(78, 82, 102),
	["Position"] = UDim2.new(0, 16, 1, -68),
	["Size"] = UDim2.new(1, -32, 0, 1),
	["Parent"] = v_u_153
})
local v220 = v_u_14.button({
	["name"] = "Cancel",
	["text"] = "\224\184\162\224\184\129\224\185\128\224\184\165\224\184\180\224\184\129",
	["grad"] = "grey",
	["textSize"] = 15,
	["position"] = nil,
	["size"] = nil,
	["parent"] = nil,
	["radius"] = 10,
	["position"] = UDim2.new(0, 16, 1, -56),
	["size"] = UDim2.fromOffset(96, 42),
	["parent"] = v_u_153
})
local v221 = v_u_14.button({
	["name"] = "Save",
	["text"] = "\224\184\154\224\184\177\224\184\153\224\184\151\224\184\182\224\184\129",
	["grad"] = "gold",
	["textSize"] = 16,
	["position"] = nil,
	["size"] = nil,
	["parent"] = nil,
	["radius"] = 10,
	["position"] = UDim2.new(0, 120, 1, -56),
	["size"] = UDim2.new(1, -136, 0, 42),
	["parent"] = v_u_153
})
local v_u_222 = v_u_14.text({
	["Text"] = "",
	["TextSize"] = 14,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["AutomaticSize"] = nil,
	["BackgroundTransparency"] = 0.1,
	["BackgroundColor3"] = nil,
	["Parent"] = nil,
	["AnchorPoint"] = Vector2.new(0.5, 0),
	["Position"] = UDim2.new(0.5, 0, 0, 12),
	["Size"] = UDim2.fromOffset(0, 30),
	["AutomaticSize"] = Enum.AutomaticSize.X,
	["BackgroundColor3"] = v_u_14.PANEL,
	["Parent"] = v_u_135
})
v_u_14.corner(v_u_222, 15)
v_u_14.new("UIPadding", {
	["PaddingLeft"] = UDim.new(0, 14),
	["PaddingRight"] = UDim.new(0, 14),
	["Parent"] = v_u_222
})
if v_u_14.isPhone() then
	v_u_222.TextSize = 12
end
local v_u_223 = v_u_14.panel({
	["Name"] = "ToolBar",
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["AnchorPoint"] = Vector2.new(0.5, 1),
	["Position"] = UDim2.new(0.5, 0, 1, -14),
	["Size"] = UDim2.fromOffset(#v_u_136 * 70 + (#v_u_136 - 1) * 4 + 12, 66),
	["Parent"] = v_u_135
})
v_u_14.autoScale(v_u_223, v_u_14.PHONE_SHRINK)
v_u_14.new("UIPadding", {
	["PaddingLeft"] = UDim.new(0, 6),
	["PaddingRight"] = UDim.new(0, 6),
	["PaddingTop"] = UDim.new(0, 6),
	["PaddingBottom"] = UDim.new(0, 6),
	["Parent"] = v_u_223
})
v_u_14.new("UIListLayout", {
	["FillDirection"] = Enum.FillDirection.Horizontal,
	["Padding"] = UDim.new(0, 4),
	["SortOrder"] = Enum.SortOrder.LayoutOrder,
	["Parent"] = v_u_223
})
local v_u_224 = {}
local v_u_225 = v_u_191
local function v233(p226, p227, p228) -- name: toolIcon
	-- upvalues: (copy) v_u_14, (copy) v_u_152
	local v229 = v_u_14.new("Frame", {
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.new(0.5, 0, 0, 18),
		["Size"] = UDim2.fromOffset(22, 22),
		["Parent"] = p227
	})
	if p226 == "select" then
		v_u_14.new("ImageLabel", {
			["BackgroundTransparency"] = 1,
			["Image"] = "rbxasset://textures/Cursors/KeyboardMouse/ArrowCursor.png",
			["ScaleType"] = nil,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["ScaleType"] = Enum.ScaleType.Fit,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.new(0.5, 4, 0.5, 4),
			["Size"] = UDim2.fromOffset(30, 30),
			["Parent"] = v229
		})
		return v229
	elseif p226 == "move" then
		v_u_152(v229, 18, 2, 0, p228)
		v_u_152(v229, 18, 2, 90, p228)
		for _, v230 in {
			{ 45, 7.25, -1.75 },
			{ -45, 7.25, 1.75 },
			{ -45, -7.25, -1.75 },
			{ 45, -7.25, 1.75 },
			{ -45, -1.75, -7.25 },
			{ 45, 1.75, -7.25 },
			{ 45, -1.75, 7.25 },
			{ -45, 1.75, 7.25 }
		} do
			v_u_152(v229, 5, 2, v230[1], p228, v230[2], v230[3])
		end
		return v229
	elseif p226 == "height" then
		v_u_152(v229, 20, 2, 0, p228, 0, 9)
		v_u_152(v229, 14, 2, 90, p228, 0, -1)
		v_u_152(v229, 5, 2, -45, p228, -1.75, -6.75)
		v_u_152(v229, 5, 2, 45, p228, 1.75, -6.75)
		v_u_152(v229, 5, 2, 45, p228, -1.75, 4.25)
		v_u_152(v229, 5, 2, -45, p228, 1.75, 4.25)
		return v229
	elseif p226 == "rotate" then
		local v231 = v_u_14.new("Frame", {
			["BackgroundTransparency"] = 1,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5, 0.5),
			["Size"] = UDim2.fromOffset(16, 16),
			["Parent"] = v229
		})
		v_u_14.corner(v231, 8)
		v_u_14.new("UIStroke", {
			["Color"] = nil,
			["Thickness"] = 2,
			["Parent"] = nil,
			["Color"] = p228,
			["Parent"] = v231
		})
		v_u_152(v229, 5, 2, 45, p228, 2.2, -9.6)
		v_u_152(v229, 5, 2, -45, p228, 2.2, -6.4)
		return v229
	else
		if p226 ~= "tilt" then
			if p226 == "scale" then
				local v232 = {
					["Color"] = nil,
					["Thickness"] = 2,
					["Parent"] = nil,
					["Color"] = p228,
					["Parent"] = v_u_14.new("Frame", {
						["BackgroundTransparency"] = 1,
						["AnchorPoint"] = nil,
						["Position"] = nil,
						["Size"] = nil,
						["Parent"] = nil,
						["AnchorPoint"] = Vector2.new(0.5, 0.5),
						["Position"] = UDim2.new(0.5, -3, 0.5, 3),
						["Size"] = UDim2.fromOffset(11, 11),
						["Parent"] = v229
					})
				}
				v_u_14.new("UIStroke", v232)
				v_u_152(v229, 12, 2, -45, p228, 2.5, -2.5)
				v_u_152(v229, 6, 2, 0, p228, 6, -7)
				v_u_152(v229, 6, 2, 90, p228, 8, -5)
			end
			return v229
		end
		v_u_152(v229, 16, 2, 0, p228, 2, -6)
		v_u_152(v229, 16, 2, 0, p228, -2, 6)
		v_u_152(v229, 12.6, 2, 108.4, p228, -8, 0)
		v_u_152(v229, 12.6, 2, 108.4, p228, 8, 0)
		return v229
	end
end
local function v_u_240(p234) -- name: setTool
	-- upvalues: (ref) v_u_138, (copy) v_u_224, (copy) v_u_26, (copy) v_u_14
	v_u_138 = p234
	for v235, v236 in v_u_224 do
		local v237 = v235 == p234
		local v238 = v236.button
		local v239
		if v237 then
			v239 = v_u_26
		else
			v239 = v_u_14.CARD_DARK
		end
		v238.BackgroundColor3 = v239
		v236.edge.Enabled = v237
	end
end
for v241, v_u_242 in v_u_136 do
	local v243 = v_u_14.new("TextButton", {
		["Name"] = nil,
		["Text"] = "",
		["AutoButtonColor"] = true,
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["LayoutOrder"] = nil,
		["Parent"] = nil,
		["Name"] = v_u_242.key,
		["BackgroundColor3"] = v_u_14.CARD_DARK,
		["Size"] = UDim2.fromOffset(70, 54),
		["LayoutOrder"] = v241,
		["Parent"] = v_u_223
	})
	v_u_14.corner(v243, 9)
	local v244 = v_u_14.new("UIStroke", {
		["Color"] = nil,
		["Thickness"] = 1.5,
		["ApplyStrokeMode"] = nil,
		["Parent"] = nil,
		["Color"] = v_u_20,
		["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
		["Parent"] = v243
	})
	v233(v_u_242.key, v243, v_u_14.TEXT)
	v_u_14.text({
		["Text"] = nil,
		["TextSize"] = 11,
		["FontFace"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Text"] = v_u_242.label .. "  " .. v241,
		["FontFace"] = v_u_14.FONT_BOLD,
		["Position"] = UDim2.fromOffset(0, 34),
		["Size"] = UDim2.new(1, 0, 0, 16),
		["Parent"] = v243
	})
	v243.Activated:Connect(function()
		-- upvalues: (copy) v_u_240, (copy) v_u_242
		v_u_240(v_u_242.key)
	end)
	v_u_224[v_u_242.key] = {
		["button"] = v243,
		["edge"] = v244
	}
end
v_u_240("select")
local function v252() -- name: placeToolBar
	-- upvalues: (copy) v_u_223, (copy) v_u_153, (copy) v_u_135
	local v245 = v_u_223.AbsoluteSize.X / 2
	local v246 = v_u_153.AbsolutePosition.X + v_u_153.AbsoluteSize.X - v_u_135.AbsolutePosition.X + 12
	local v247 = v_u_135.AbsoluteSize.X / 2
	local v248 = v246 + v245
	local v249 = math.max(v247, v248)
	local v250 = v_u_223
	local v251
	if v_u_135.AbsoluteSize.X / 2 + 0.5 < v249 then
		v251 = UDim2.new(0, v249, 1, -14)
	else
		v251 = UDim2.new(0.5, 0, 1, -14)
	end
	v250.Position = v251
end
for _, v253 in { v_u_135, v_u_153, v_u_223 } do
	v253:GetPropertyChangedSignal("AbsoluteSize"):Connect(v252)
end
v252()
local v_u_254 = v_u_14.new("Frame", {
	["Name"] = "Gizmo",
	["BackgroundTransparency"] = 1,
	["Size"] = nil,
	["Visible"] = false,
	["Parent"] = nil,
	["Size"] = UDim2.fromScale(1, 1),
	["Parent"] = v_u_135
})
local function v260(p255, p256, p257, p258) -- name: knob
	-- upvalues: (copy) v_u_14, (copy) v_u_254
	local v259 = v_u_14.new("TextButton", {
		["Name"] = nil,
		["Text"] = "",
		["AutoButtonColor"] = false,
		["AnchorPoint"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["ZIndex"] = 6,
		["Visible"] = false,
		["Parent"] = nil,
		["Name"] = p255,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Size"] = UDim2.fromOffset(p257, p258 or p257),
		["BackgroundColor3"] = p256,
		["Parent"] = v_u_254
	})
	v_u_14.corner(v259, math.min(p257, p258 or p257) / 2)
	v_u_14.new("UIStroke", {
		["Color"] = nil,
		["Thickness"] = 2,
		["Parent"] = nil,
		["Color"] = Color3.new(1, 1, 1),
		["Parent"] = v259
	})
	return v259
end
local function v267(p261, p262, p263) -- name: chevron
	-- upvalues: (copy) v_u_14, (copy) v_u_152, (copy) v_u_25
	local v264 = v_u_14.new("Frame", {
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Rotation"] = nil,
		["ZIndex"] = 7,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.new(0.5, 0, 0.5, p263 or 0),
		["Size"] = UDim2.fromOffset(16, 16),
		["Rotation"] = p262,
		["Parent"] = p261
	})
	local v265 = v_u_152(v264, 8, 3, 45, v_u_25, 1, -2.6)
	local v266 = v_u_152(v264, 8, 3, -45, v_u_25, 1, 2.6)
	v265.ZIndex = 7
	v266.ZIndex = 7
	return v264
end
local v_u_268 = {}
local function v270() -- name: tag
	-- upvalues: (copy) v_u_14, (copy) v_u_254
	local v269 = v_u_14.text({
		["Text"] = "",
		["TextSize"] = 12,
		["FontFace"] = nil,
		["AnchorPoint"] = nil,
		["Size"] = nil,
		["BackgroundTransparency"] = 0.2,
		["BackgroundColor3"] = nil,
		["ZIndex"] = 7,
		["Visible"] = false,
		["Parent"] = nil,
		["FontFace"] = v_u_14.FONT_BOLD,
		["AnchorPoint"] = Vector2.new(0.5, 0),
		["Size"] = UDim2.fromOffset(170, 22),
		["BackgroundColor3"] = v_u_14.PANEL,
		["Parent"] = v_u_254
	})
	v_u_14.corner(v269, 6)
	return v269
end
local v_u_271 = {
	Vector3.new(1, 0, 0),
	Vector3.new(-1, 0, 0),
	Vector3.new(0, 0, -1),
	Vector3.new(0, 0, 1)
}
for v272 = 1, 4 do
	local v273 = v260("Move" .. v272, v_u_20, 30)
	v_u_268[v272] = {
		["button"] = v273,
		["arrow"] = v267(v273, 0)
	}
end
local v_u_274 = v260("Height", v21, 30, 50)
v267(v_u_274, -90, -11)
v267(v_u_274, 90, 11)
local v_u_275 = v260("HeightPlus", v21, 26)
local v_u_276 = v260("HeightMinus", v21, 26)
v_u_152(v_u_275, 12, 3, 0, v_u_25).ZIndex = 7
v_u_152(v_u_275, 12, 3, 90, v_u_25).ZIndex = 7
v_u_152(v_u_276, 12, 3, 0, v_u_25).ZIndex = 7
local v_u_277 = v270()
local v_u_278 = v260("Rotate", v22, 30)
local v279 = v_u_14.new("Frame", {
	["BackgroundTransparency"] = 1,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["ZIndex"] = 7,
	["Parent"] = nil,
	["AnchorPoint"] = Vector2.new(0.5, 0.5),
	["Position"] = UDim2.fromScale(0.5, 0.5),
	["Size"] = UDim2.fromOffset(12, 12),
	["Parent"] = v_u_278
})
v_u_14.corner(v279, 6)
v_u_14.new("UIStroke", {
	["Color"] = nil,
	["Thickness"] = 2,
	["Parent"] = nil,
	["Color"] = v_u_25,
	["Parent"] = v279
})
local v_u_280 = v260("RotateLeft", v22, 26)
local v_u_281 = v260("RotateRight", v22, 26)
v267(v_u_280, 180)
v267(v_u_281, 0)
local v_u_282 = v270()
local v_u_283 = v260("Tilt", v23, 34)
local v284 = v_u_14.new("Frame", {
	["BackgroundColor3"] = nil,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["BorderSizePixel"] = 0,
	["ZIndex"] = 7,
	["Parent"] = nil,
	["BackgroundColor3"] = v_u_25,
	["AnchorPoint"] = Vector2.new(0.5, 0.5),
	["Position"] = UDim2.fromScale(0.5, 0.5),
	["Size"] = UDim2.fromOffset(8, 8),
	["Parent"] = v_u_283
})
v_u_14.corner(v284, 4)
local v_u_285 = {}
for _, v286 in {
	{
		"left",
		180,
		-44,
		0
	},
	{
		"right",
		0,
		44,
		0
	},
	{
		"up",
		-90,
		0,
		-44
	},
	{
		"down",
		90,
		0,
		44
	}
} do
	local v287 = v260("Tilt" .. v286[1], v23, 26)
	v267(v287, v286[2])
	v_u_285[v286[1]] = {
		["button"] = v287,
		["off"] = Vector2.new(v286[3], v286[4])
	}
end
local v_u_288 = v_u_14.new("TextButton", {
	["Name"] = "TiltZero",
	["Text"] = "0",
	["FontFace"] = nil,
	["TextSize"] = 13,
	["TextColor3"] = nil,
	["AutoButtonColor"] = true,
	["AnchorPoint"] = nil,
	["Size"] = nil,
	["BackgroundColor3"] = nil,
	["BorderSizePixel"] = 0,
	["ZIndex"] = 6,
	["Visible"] = false,
	["Parent"] = nil,
	["FontFace"] = v_u_14.FONT_BOLD,
	["TextColor3"] = v_u_25,
	["AnchorPoint"] = Vector2.new(0.5, 0.5),
	["Size"] = UDim2.fromOffset(26, 26),
	["BackgroundColor3"] = Color3.fromRGB(230, 236, 245),
	["Parent"] = v_u_254
})
v_u_14.corner(v_u_288, 13)
local v_u_289 = v270()
local v_u_290 = v260("Scale", v_u_24, 34)
local v291 = {
	["Color"] = nil,
	["Thickness"] = 2,
	["Parent"] = nil,
	["Color"] = v_u_25,
	["Parent"] = v_u_14.new("Frame", {
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 7,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.5),
		["Size"] = UDim2.fromOffset(13, 13),
		["Parent"] = v_u_290
	})
}
v_u_14.new("UIStroke", v291)
local v_u_292 = v260("ScalePlus", v_u_24, 26)
local v_u_293 = v260("ScaleMinus", v_u_24, 26)
v_u_152(v_u_292, 12, 3, 0, v_u_25).ZIndex = 7
v_u_152(v_u_292, 12, 3, 90, v_u_25).ZIndex = 7
v_u_152(v_u_293, 12, 3, 0, v_u_25).ZIndex = 7
local v_u_294 = v270()
local v_u_295 = {}
local function v_u_300(p296) -- name: boxOf
	-- upvalues: (copy) v_u_295, (copy) v_u_12
	local v297 = v_u_295[p296]
	if not v297 then
		local v298, v299 = v_u_12.template(p296):GetBoundingBox()
		v297 = {
			["c"] = v298.Position,
			["size"] = v299
		}
		v_u_295[p296] = v297
	end
	return v297.c, v297.size
end
local function v_u_318(p301, p302) -- name: setWorld
	-- upvalues: (copy) v_u_12
	local v303 = p301.part.CFrame:ToObjectSpace(p302)
	local v304 = p301.part.Size / 2 + Vector3.new(1, 1, 1) * (v_u_12.REACH_OFF - 0.2)
	local v305 = v303.Position
	local v306 = CFrame.new
	local v307 = v305.X
	local v308 = -v304.X
	local v309 = v304.X
	local v310 = math.clamp(v307, v308, v309)
	local v311 = v305.Y
	local v312 = -v304.Y
	local v313 = v304.Y
	local v314 = math.clamp(v311, v312, v313)
	local v315 = v305.Z
	local v316 = -v304.Z
	local v317 = v304.Z
	p301.cf = v306(v310, v314, (math.clamp(v315, v316, v317))) * v303.Rotation
end
local function v_u_325(p319) -- name: anglesOf
	-- upvalues: (ref) v_u_137
	local v320 = v_u_137.seat or v_u_137.model.PrimaryPart
	local v321
	if v320 then
		v321 = v320.CFrame.Rotation
	else
		v321 = v_u_137.model:GetPivot().Rotation
	end
	local v322, v323, v324 = v321:ToObjectSpace((p319.part.CFrame * p319.cf).Rotation):ToEulerAnglesYXZ()
	return math.deg(v322), math.deg(v323), math.deg(v324)
end
local function v_u_335(p326, p327, p328, p329) -- name: setAngles
	-- upvalues: (copy) v_u_318, (ref) v_u_137
	local v330 = p326.part.CFrame * p326.cf
	local v331 = v_u_318
	local v332 = CFrame.new(v330.Position)
	local v333 = v_u_137.seat or v_u_137.model.PrimaryPart
	local v334
	if v333 then
		v334 = v333.CFrame.Rotation
	else
		v334 = v_u_137.model:GetPivot().Rotation
	end
	v331(p326, v332 * v334 * CFrame.fromEulerAnglesYXZ(math.rad(p327), math.rad(p328), (math.rad(p329))))
end
local function _(p336) -- name: centreOf
	-- upvalues: (copy) v_u_300
	local v337 = v_u_300(p336.c)
	return (p336.part.CFrame * p336.cf):PointToWorldSpace(v337 * p336.s)
end
local v_u_338 = {
	Vector3.new(1, 1, 1),
	Vector3.new(-1, 1, 1),
	Vector3.new(1, -1, 1),
	Vector3.new(-1, -1, 1),
	Vector3.new(1, 1, -1),
	Vector3.new(-1, 1, -1),
	Vector3.new(1, -1, -1),
	Vector3.new(-1, -1, -1)
}
local function v_u_357(p339, p340, p341, p342, p343, p344, p345) -- name: placeAt
	-- upvalues: (ref) v_u_137, (copy) v_u_300, (copy) v_u_338
	local v346 = CFrame.new(p341)
	local v347 = v_u_137.seat or v_u_137.model.PrimaryPart
	local v348
	if v347 then
		v348 = v347.CFrame.Rotation
	else
		v348 = v_u_137.model:GetPivot().Rotation
	end
	local v349 = v346 * v348 * CFrame.fromEulerAnglesYXZ(math.rad(p343 or 0), math.rad(p344 or 0), (math.rad(p345 or 0)))
	local v350, v351 = v_u_300(p339)
	local v352 = v350 * p340
	local v353 = v351 * p340
	local v354 = 0
	for _, v355 in v_u_338 do
		local v356 = p341 - v349:PointToWorldSpace(v352 + v353 / 2 * v355)
		v354 = math.max(v354, v356:Dot(p342))
	end
	return v349 + p342 * (v354 + 0.005)
end
local function v_u_361(p358) -- name: makeGhost
	-- upvalues: (copy) v_u_12, (ref) v_u_137
	local v359 = v_u_12.makeModel(p358.c, p358.s)
	for _, v360 in v359:GetDescendants() do
		if not v360:IsA("BasePart") then
			continue
		end
		v360.Anchored = true
		v360.CanQuery = true
	end
	v359:PivotTo(p358.part.CFrame * p358.cf)
	v359.Parent = v_u_137.ghosts
	p358.ghost = v359
end
local function v_u_373(p362) -- name: pick
	-- upvalues: (ref) v_u_137, (copy) v_u_185, (ref) v_u_140, (ref) v_u_143
	if p362 ~= v_u_137.sel then
		local v363 = v_u_185
		local v364 = v_u_185
		local v365 = v_u_185
		local v366 = v_u_185
		v_u_185.yaw = 0
		v363.pitch = 0
		v364.curYaw = 0
		v365.curPitch = 0
		v366.fovAdd = 0
	end
	if p362 == nil and (v_u_137.sel and v_u_140) then
		local v367 = v_u_140.ref.CFrame:PointToObjectSpace(v_u_140.cur.focus) - v_u_140.home
		local v368 = v_u_140
		local v369 = v_u_140.home
		if v367.Magnitude > v_u_140.reach then
			v367 = v367.Unit * v_u_140.reach
		end
		v368.free = v369 + v367
	end
	v_u_137.sel = p362
	local v370 = v_u_137 and v_u_137.sel
	if v370 then
		v370 = v_u_137.list[v_u_137.sel]
	end
	local v371 = v_u_137.hl
	local v372
	if v370 then
		v372 = v370.ghost or nil
	else
		v372 = nil
	end
	v371.Adornee = v372
	v_u_137.hl.Enabled = v370 ~= nil
	v_u_143()
end
local function v_u_378(p374) -- name: arm
	-- upvalues: (ref) v_u_137, (copy) v_u_12, (copy) v_u_24, (copy) v_u_373, (ref) v_u_143
	if v_u_137.preview then
		v_u_137.preview:Destroy()
		v_u_137.preview = nil
	end
	v_u_137.armed = p374
	if p374 then
		local v375 = v_u_12.makeModel(p374, 1)
		for _, v376 in v375:GetDescendants() do
			if not v376:IsA("BasePart") then
				continue
			end
			v376.Anchored = true
		end
		local v377 = Instance.new("Highlight")
		v377.FillColor = v_u_24
		v377.FillTransparency = 0.55
		v377.OutlineColor = Color3.new(1, 1, 1)
		v377.DepthMode = Enum.HighlightDepthMode.AlwaysOnTop
		v377.Parent = v375
		v_u_137.preview = v375
		v_u_373(nil)
	else
		v_u_143()
	end
end
local function v_u_389(p379) -- name: placeHere
	-- upvalues: (ref) v_u_137, (copy) v_u_27, (copy) v_u_318, (copy) v_u_357, (copy) v_u_361, (ref) v_u_143, (copy) v_u_373, (ref) v_u_140, (copy) v_u_15
	local v380 = v_u_137.armed
	local v381
	if v_u_27 <= #v_u_137.list then
		v381 = v_u_137.list[1]
	else
		v381 = nil
	end
	local v382 = {
		["c"] = nil,
		["part"] = nil,
		["cf"] = nil,
		["s"] = 1,
		["m"] = nil,
		["f"] = nil,
		["d"] = nil,
		["c"] = v380,
		["part"] = p379.Instance,
		["cf"] = CFrame.new()
	}
	local v383
	if v381 then
		v383 = v381.m
	else
		v383 = v381
	end
	v382.m = v383
	local v384
	if v381 then
		v384 = v381.f
	else
		v384 = v381
	end
	v382.f = v384
	local v385
	if v381 then
		v385 = v381.d
	else
		v385 = v381
	end
	v382.d = v385
	if v381 then
		if v381.ghost then
			v381.ghost:Destroy()
		end
		table.remove(v_u_137.list, 1)
		v_u_137.sel = nil
	end
	v_u_318(v382, (v_u_357(v380, 1, p379.Position, p379.Normal)))
	local v386 = v_u_137.list
	table.insert(v386, v382)
	v_u_361(v382)
	if v_u_137.preview then
		v_u_137.preview:Destroy()
		v_u_137.preview = nil
	end
	v_u_137.armed = nil
	v_u_143()
	v_u_373(#v_u_137.list)
	if v_u_140 then
		local v387 = v_u_140
		local v388 = v_u_140.dist
		v387.dist = math.min(v388, 6)
	end
	if v381 then
		v_u_15.show(("\224\184\162\224\185\137\224\184\178\224\184\162\224\184\129\224\184\165\224\185\137\224\184\173\224\184\135\224\184\161\224\184\178\224\184\149\224\184\163\224\184\135\224\184\153\224\184\181\224\185\137\224\185\129\224\184\165\224\185\137\224\184\167 \194\183 \224\184\149\224\184\180\224\184\148\224\185\132\224\184\148\224\185\137 %d \224\184\149\224\184\177\224\184\167\224\184\149\224\185\136\224\184\173\224\184\132\224\184\177\224\184\153"):format(v_u_27), "info")
	end
end
local function v_u_391(p390) -- name: pickTile
	-- upvalues: (ref) v_u_137, (copy) v_u_10, (copy) v_u_17, (copy) v_u_15, (ref) v_u_143, (copy) v_u_378
	if v_u_137 and p390 then
		if v_u_10.count(v_u_17, p390.item) <= 0 and not v_u_137.onIt[p390.id] then
			v_u_15.show(("\224\184\162\224\184\177\224\184\135\224\185\132\224\184\161\224\185\136\224\184\161\224\184\181%s \194\183 \224\184\139\224\184\183\224\185\137\224\184\173\224\185\132\224\184\148\224\185\137\224\184\151\224\184\181\224\185\136\224\185\128\224\184\132\224\184\178\224\184\153\224\185\140\224\185\128\224\184\149\224\184\173\224\184\163\224\185\140\224\185\131\224\184\153\224\184\163\224\185\137\224\184\178\224\184\153"):format(p390.th), "info")
			return
		elseif v_u_137.armed == p390.id then
			if v_u_137.preview then
				v_u_137.preview:Destroy()
				v_u_137.preview = nil
			end
			v_u_137.armed = nil
			v_u_143()
		else
			v_u_378(p390.id)
		end
	else
		return
	end
end
local function v_u_395() -- name: refreshHint
	-- upvalues: (ref) v_u_186, (copy) v_u_28, (copy) v_u_222, (ref) v_u_137, (copy) v_u_27, (ref) v_u_138
	if v_u_186 then
		local v392 = v_u_28 and "\224\184\148\224\184\185\224\184\149\224\184\177\224\184\167\224\184\173\224\184\162\224\185\136\224\184\178\224\184\135: \224\184\165\224\184\178\224\184\129\224\184\153\224\184\180\224\185\137\224\184\167 = \224\184\171\224\184\161\224\184\184\224\184\153\224\184\161\224\184\184\224\184\161\224\184\161\224\184\173\224\184\135 360 \194\183 \224\184\171\224\184\153\224\184\181\224\184\154\224\184\153\224\184\180\224\185\137\224\184\167 = \224\184\139\224\184\185\224\184\161" or "\224\184\148\224\184\185\224\184\149\224\184\177\224\184\167\224\184\173\224\184\162\224\185\136\224\184\178\224\184\135: \224\184\132\224\184\165\224\184\180\224\184\129\224\184\130\224\184\167\224\184\178\224\184\165\224\184\178\224\184\129 = \224\184\171\224\184\161\224\184\184\224\184\153\224\184\161\224\184\184\224\184\161\224\184\161\224\184\173\224\184\135 360 \194\183 \224\184\165\224\185\137\224\184\173\224\185\128\224\184\161\224\184\178\224\184\170\224\185\140 = \224\184\139\224\184\185\224\184\161"
		if v_u_222.Text ~= v392 then
			v_u_222.Text = v392
		end
	else
		local v393
		if v_u_137.armed then
			v393 = (v_u_28 and "\224\185\129\224\184\149\224\184\176" or "\224\184\132\224\184\165\224\184\180\224\184\129") .. "\224\184\154\224\184\153\224\184\163\224\184\150\224\184\149\224\184\163\224\184\135\224\184\151\224\184\181\224\185\136\224\184\136\224\184\176\224\184\149\224\184\180\224\184\148\224\184\129\224\184\165\224\185\137\224\184\173\224\184\135" .. (v_u_27 <= #v_u_137.list and " (\224\184\162\224\185\137\224\184\178\224\184\162\224\184\149\224\184\177\224\184\167\224\185\128\224\184\148\224\184\180\224\184\161\224\184\161\224\184\178\224\184\149\224\184\163\224\184\135\224\184\153\224\184\181\224\185\137)" or "")
		else
			v393 = not v_u_137.sel and "\224\185\128\224\184\165\224\184\183\224\184\173\224\184\129\224\184\129\224\184\165\224\185\137\224\184\173\224\184\135\224\184\151\224\184\178\224\184\135\224\184\139\224\185\137\224\184\178\224\184\162 \224\185\129\224\184\165\224\185\137\224\184\167\224\184\132\224\184\165\224\184\180\224\184\129\224\184\154\224\184\153\224\184\163\224\184\150 \194\183 \224\184\132\224\184\165\224\184\180\224\184\129\224\184\151\224\184\181\224\185\136\224\184\129\224\184\165\224\185\137\224\184\173\224\184\135\224\184\154\224\184\153\224\184\163\224\184\150\224\185\128\224\184\158\224\184\183\224\185\136\224\184\173\224\184\155\224\184\163\224\184\177\224\184\154" or ({
				["select"] = "\224\184\165\224\184\178\224\184\129\224\184\129\224\184\165\224\185\137\224\184\173\224\184\135\224\185\132\224\184\155\224\184\154\224\184\153\224\184\149\224\184\177\224\184\167\224\184\163\224\184\150\224\185\128\224\184\158\224\184\183\224\185\136\224\184\173\224\184\162\224\185\137\224\184\178\224\184\162 \194\183 \224\185\128\224\184\132\224\184\163\224\184\183\224\185\136\224\184\173\224\184\135\224\184\161\224\184\183\224\184\173\224\184\148\224\185\137\224\184\178\224\184\153\224\184\165\224\185\136\224\184\178\224\184\135\224\184\155\224\184\163\224\184\177\224\184\154\224\184\165\224\184\176\224\185\128\224\184\173\224\184\181\224\184\162\224\184\148",
				["move"] = "\224\184\165\224\184\178\224\184\129\224\184\165\224\184\185\224\184\129\224\184\168\224\184\163\224\184\170\224\184\181\224\184\151\224\184\173\224\184\135 = \224\185\128\224\184\165\224\184\183\224\185\136\224\184\173\224\184\153\224\184\171\224\184\153\224\185\137\224\184\178/\224\184\171\224\184\165\224\184\177\224\184\135/\224\184\139\224\185\137\224\184\178\224\184\162/\224\184\130\224\184\167\224\184\178 \194\183 \224\184\155\224\184\184\224\185\136\224\184\161\224\184\165\224\184\185\224\184\129\224\184\168\224\184\163\224\184\129\224\185\135\224\185\132\224\184\148\224\185\137",
				["height"] = "\224\184\165\224\184\178\224\184\129\224\184\155\224\184\184\224\185\136\224\184\161\224\184\138\224\184\161\224\184\158\224\184\185\224\184\130\224\184\182\224\185\137\224\184\153/\224\184\165\224\184\135 = \224\184\162\224\184\129\224\184\130\224\184\182\224\185\137\224\184\153/\224\184\165\224\184\135",
				["rotate"] = "\224\184\165\224\184\178\224\184\129\224\184\155\224\184\184\224\185\136\224\184\161\224\184\170\224\185\137\224\184\161\224\184\139\224\185\137\224\184\178\224\184\162/\224\184\130\224\184\167\224\184\178 = \224\184\171\224\184\161\224\184\184\224\184\153",
				["tilt"] = "\224\184\165\224\184\178\224\184\129\224\184\155\224\184\184\224\185\136\224\184\161\224\184\159\224\185\137\224\184\178 = \224\185\128\224\184\173\224\184\181\224\184\162\224\184\135/\224\185\128\224\184\135\224\184\162 \194\183 0 = \224\184\149\224\184\177\224\185\137\224\184\135\224\184\149\224\184\163\224\184\135",
				["scale"] = "\224\184\165\224\184\178\224\184\129\224\184\155\224\184\184\224\185\136\224\184\161\224\185\128\224\184\130\224\184\181\224\184\162\224\184\167\224\184\130\224\184\182\224\185\137\224\184\153/\224\184\165\224\184\135 = \224\185\131\224\184\171\224\184\141\224\185\136/\224\185\128\224\184\165\224\185\135\224\184\129"
			})[v_u_138]
		end
		local v394 = v393 .. (v_u_28 and "  \194\183  \224\184\165\224\184\178\224\184\129\224\184\153\224\184\180\224\185\137\224\184\167 = \224\184\171\224\184\161\224\184\184\224\184\153\224\184\161\224\184\184\224\184\161\224\184\161\224\184\173\224\184\135" or "  \194\183  \224\184\132\224\184\165\224\184\180\224\184\129\224\184\130\224\184\167\224\184\178\224\184\165\224\184\178\224\184\129 = \224\184\171\224\184\161\224\184\184\224\184\153\224\184\161\224\184\184\224\184\161\224\184\161\224\184\173\224\184\135 \194\183 \224\184\165\224\185\137\224\184\173\224\185\128\224\184\161\224\184\178\224\184\170\224\185\140 = \224\184\139\224\184\185\224\184\161")
		if v_u_222.Text ~= v394 then
			v_u_222.Text = v394
		end
	end
end
function v_u_179.lens(p396) -- name: lens
	-- upvalues: (ref) v_u_137, (ref) v_u_184
	local v397 = v_u_137 and (v_u_137 and v_u_137.sel)
	if v397 then
		v397 = v_u_137.list[v_u_137.sel]
	end
	if v397 then
		local v398 = p396.id
		local v399 = p396.f
		local v400 = p396.d
		v397.m = v398
		v397.f = v399
		v397.d = v400
		v_u_184()
	end
end
function v_u_179.fov(p401) -- name: fov
	-- upvalues: (ref) v_u_137, (copy) v_u_12, (ref) v_u_184
	local v402 = v_u_137 and (v_u_137 and v_u_137.sel)
	if v402 then
		v402 = v_u_137.list[v_u_137.sel]
	end
	if v402 then
		v402.m = v402.m or v_u_12.viewOf(v402)
		local v403 = (v_u_12.FOV_MIN + p401 * (v_u_12.FOV_MAX - v_u_12.FOV_MIN)) * 10 + 0.5
		v402.f = math.floor(v403) / 10
		v_u_184(true)
	end
end
function v_u_179.curve(p404) -- name: curve
	-- upvalues: (ref) v_u_137, (copy) v_u_12, (ref) v_u_184
	local v405 = v_u_137 and (v_u_137 and v_u_137.sel)
	if v405 then
		v405 = v_u_137.list[v_u_137.sel]
	end
	if v405 then
		v405.m = v405.m or v_u_12.viewOf(v405)
		local v406 = p404 * 100 + 0.5
		v405.d = math.floor(v406) / 100
		v_u_184(true)
	end
end
function v_u_179.preview() -- name: preview
	-- upvalues: (ref) v_u_137, (ref) v_u_186, (copy) v_u_185, (ref) v_u_184, (copy) v_u_395
	if v_u_137 then
		local v407 = not v_u_186
		if v407 and not v_u_186 then
			local v408 = v_u_185
			local v409 = v_u_185
			local v410 = v_u_185
			local v411 = v_u_185
			v_u_185.yaw = 0
			v408.pitch = 0
			v409.curYaw = 0
			v410.curPitch = 0
			v411.fovAdd = 0
		end
		if v407 then
			local v412 = v_u_137 and v_u_137.sel
			if v412 then
				v412 = v_u_137.list[v_u_137.sel]
			end
			v407 = v412 ~= nil
		end
		v_u_186 = v407
		if not v_u_186 and v_u_137 then
			local v413 = v_u_137.hl
			local v414 = v_u_137 and v_u_137.sel
			if v414 then
				v414 = v_u_137.list[v_u_137.sel]
			end
			v413.Enabled = v414 ~= nil
		end
		v_u_184()
		v_u_395()
	end
end
local function v_u_429(p415)
	-- upvalues: (ref) v_u_137, (copy) v_u_219, (ref) v_u_186, (copy) v_u_12, (copy) v_u_183, (copy) v_u_26, (copy) v_u_14, (ref) v_u_225, (copy) v_u_216, (copy) v_u_218, (copy) v_u_181
	local v416 = v_u_137 and v_u_137.sel
	if v416 then
		v416 = v_u_137.list[v_u_137.sel]
	end
	v_u_219.Visible = v416 == nil
	if not v416 and v_u_186 then
		v_u_186 = false
		if not v_u_186 and v_u_137 then
			local v417 = v_u_137.hl
			local v418 = v_u_137 and v_u_137.sel
			if v418 then
				v418 = v_u_137.list[v_u_137.sel]
			end
			v417.Enabled = v418 ~= nil
		end
	end
	local v419, v420, v421 = v_u_12.viewOf(v416)
	for v422, v423 in v_u_183 do
		local v424
		if v416 == nil then
			v424 = false
		else
			v424 = v419 == v422
		end
		v423.edge.Enabled = v424
		local v425 = v423.chip
		local v426
		if v424 then
			v426 = v_u_26
		else
			v426 = v_u_14.CARD
		end
		v425.BackgroundColor3 = v426
	end
	if not (p415 and v_u_225) then
		v_u_216.set((v420 - v_u_12.FOV_MIN) / (v_u_12.FOV_MAX - v_u_12.FOV_MIN))
		v_u_218.set(v421)
	end
	v_u_216.valueLabel.Text = ("%.1f\194\176"):format(v420)
	v_u_218.valueLabel.Text = ("%.2f"):format(v421)
	v_u_181.Text = v_u_186 and "\224\184\129\224\184\165\224\184\177\224\184\154\224\184\161\224\184\184\224\184\161\224\185\129\224\184\129\224\185\137\224\185\132\224\184\130" or "\224\184\148\224\184\185\224\184\149\224\184\177\224\184\167\224\184\173\224\184\162\224\185\136\224\184\178\224\184\135"
	local v427 = v_u_181
	local v428
	if v_u_186 then
		v428 = v_u_26
	else
		v428 = v_u_14.CARD
	end
	v427.BackgroundColor3 = v428
end
local function v_u_469() -- name: refreshPanel
	-- upvalues: (ref) v_u_137, (copy) v_u_165, (copy) v_u_32, (copy) v_u_166, (copy) v_u_27, (copy) v_u_168, (copy) v_u_10, (copy) v_u_17, (copy) v_u_26, (copy) v_u_14, (copy) v_u_20, (copy) v_u_176, (copy) v_u_177, (copy) v_u_12, (copy) v_u_16, (ref) v_u_469, (copy) v_u_373, (ref) v_u_140, (ref) v_u_429, (copy) v_u_178, (copy) v_u_395
	if v_u_137 then
		local v430 = v_u_165
		local v431 = v_u_32(v_u_137.model)
		v430.Text = tostring(v431)
		v_u_166.Text = ("%d / %d"):format(#v_u_137.list, v_u_27)
		for v432, v433 in v_u_168 do
			local v434 = v_u_10.count(v_u_17, v433.p.item) > 0
			local v435 = v434 or v_u_137.onIt[v432] == true
			local v436 = v_u_137.armed == v432
			v433.edge.Enabled = v436
			local v437 = v433.button
			local v438
			if v436 then
				v438 = v_u_26
			else
				v438 = v_u_14.CARD_DARK
			end
			v437.BackgroundColor3 = v438
			if v435 then
				v433.status.Text = v436 and "\224\184\132\224\184\165\224\184\180\224\184\129\224\184\154\224\184\153\224\184\163\224\184\150\224\185\128\224\184\158\224\184\183\224\185\136\224\184\173\224\184\149\224\184\180\224\184\148" or (v434 and "\224\184\130\224\184\173\224\184\135\224\184\132\224\184\184\224\184\147\224\185\129\224\184\165\224\185\137\224\184\167 \194\183 \224\185\129\224\184\149\224\184\176\224\185\128\224\184\158\224\184\183\224\185\136\224\184\173\224\184\149\224\184\180\224\184\148" or "\224\184\173\224\184\162\224\184\185\224\185\136\224\184\154\224\184\153\224\184\163\224\184\150\224\185\129\224\184\165\224\185\137\224\184\167 \194\183 \224\185\129\224\184\149\224\184\176\224\185\128\224\184\158\224\184\183\224\185\136\224\184\173\224\184\162\224\185\137\224\184\178\224\184\162")
				local v439 = v433.status
				local v440
				if v436 then
					v440 = v_u_20
				else
					v440 = v_u_14.GREEN_TEXT
				end
				v439.TextColor3 = v440
			else
				v433.status.Text = "\224\184\162\224\184\177\224\184\135\224\185\132\224\184\161\224\185\136\224\184\161\224\184\181 \194\183 \224\184\139\224\184\183\224\185\137\224\184\173\224\184\151\224\184\181\224\185\136\224\185\128\224\184\132\224\184\178\224\184\153\224\185\140\224\185\128\224\184\149\224\184\173\224\184\163\224\185\140"
				v433.status.TextColor3 = v_u_14.TEXT_DIM
			end
			v433.vp.ImageTransparency = v435 and 0 or 0.65
		end
		for _, v441 in v_u_176:GetChildren() do
			if not v441:IsA("GuiButton") then
				continue
			end
			v441:Destroy()
		end
		v_u_177.Visible = #v_u_137.list == 0
		for v_u_442, v443 in v_u_137.list do
			local v444 = v_u_12.part(v443.c)
			local v445 = v_u_14.new
			local v446 = "TextButton"
			local v447 = {
				["Name"] = nil,
				["Text"] = "",
				["AutoButtonColor"] = true,
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["LayoutOrder"] = nil,
				["Parent"] = nil,
				["Name"] = "Row" .. v_u_442
			}
			local v448
			if v_u_137.sel == v_u_442 then
				v448 = v_u_26
			else
				v448 = v_u_14.CARD
			end
			v447.BackgroundColor3 = v448
			v447.Size = UDim2.new(1, 0, 0, 30)
			v447.LayoutOrder = v_u_442
			v447.Parent = v_u_176
			local v449 = v445(v446, v447)
			v_u_14.corner(v449, 8)
			v_u_14.text({
				["Text"] = nil,
				["TextSize"] = 13,
				["FontFace"] = nil,
				["TextXAlignment"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["Text"] = ("%d. %s"):format(v_u_442, v444 and v444.th or v443.c),
				["FontFace"] = v_u_14.FONT_BOLD,
				["TextXAlignment"] = Enum.TextXAlignment.Left,
				["Position"] = UDim2.fromOffset(10, 0),
				["Size"] = UDim2.new(1, -90, 1, 0),
				["Parent"] = v449
			})
			v_u_14.text({
				["Text"] = nil,
				["TextSize"] = 12,
				["TextColor3"] = nil,
				["TextXAlignment"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["Text"] = ("x%.2f"):format(v443.s),
				["TextColor3"] = v_u_14.TEXT_DIM,
				["TextXAlignment"] = Enum.TextXAlignment.Right,
				["Position"] = UDim2.new(1, -84, 0, 0),
				["Size"] = UDim2.fromOffset(46, 30),
				["Parent"] = v449
			})
			local v450 = v_u_14.new("TextButton", {
				["Name"] = "Remove",
				["Text"] = "",
				["AutoButtonColor"] = true,
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["BackgroundColor3"] = v_u_14.RED,
				["AnchorPoint"] = Vector2.new(1, 0.5),
				["Position"] = UDim2.new(1, -4, 0.5, 0),
				["Size"] = UDim2.fromOffset(26, 22),
				["Parent"] = v449
			})
			v_u_14.corner(v450, 6)
			local v451 = v_u_16.make("close", Color3.new(1, 1, 1), 14)
			v451.AnchorPoint = Vector2.new(0.5, 0.5)
			v451.Position = UDim2.fromScale(0.5, 0.5)
			v451.Parent = v450
			v449.Activated:Connect(function()
				-- upvalues: (ref) v_u_137, (ref) v_u_469, (ref) v_u_373, (copy) v_u_442, (ref) v_u_140
				if v_u_137 then
					if v_u_137.preview then
						v_u_137.preview:Destroy()
						v_u_137.preview = nil
					end
					v_u_137.armed = nil
					v_u_469()
					v_u_373(v_u_442)
					if v_u_140 then
						local v452 = v_u_140
						local v453 = v_u_140.dist
						v452.dist = math.min(v453, 6)
					end
				end
			end)
			v450.Activated:Connect(function()
				-- upvalues: (copy) v_u_442, (ref) v_u_137, (ref) v_u_373
				local v454 = v_u_442
				local v455 = v_u_137
				if v455 then
					v455 = v_u_137.list[v454]
				end
				if v455 then
					if v455.ghost then
						v455.ghost:Destroy()
					end
					table.remove(v_u_137.list, v454)
					v_u_373(nil)
				end
			end)
		end
		v_u_429()
		local v456 = v_u_137 and v_u_137.sel
		if v456 then
			v456 = v_u_137.list[v_u_137.sel]
		end
		if v456 then
			local v457 = v_u_137.seat or v_u_137.model.PrimaryPart
			local v458
			if v457 then
				v458 = v457.CFrame.Rotation
			else
				v458 = v_u_137.model:GetPivot().Rotation
			end
			local v459, v460, v461 = v458:ToObjectSpace((v456.part.CFrame * v456.cf).Rotation):ToEulerAnglesYXZ()
			local v462 = math.deg(v459)
			local v463 = math.deg(v460)
			local v464 = math.deg(v461)
			local v465 = v_u_178
			local v466 = v456.s
			local v467 = math.round(v463)
			local v468 = -v464
			v465.Text = ("\224\184\130\224\184\153\224\184\178\224\184\148 x%.2f \194\183 \224\184\171\224\184\161\224\184\184\224\184\153 %d\194\176 \194\183 \224\185\128\224\184\173\224\184\181\224\184\162\224\184\135 %d\194\176 \194\183 \224\185\128\224\184\135\224\184\162 %d\194\176\n\224\184\149\224\184\180\224\184\148\224\184\151\224\184\181\224\185\136: %s"):format(v466, v467, math.round(v468), math.round(v462), v456.part.Name)
		else
			v_u_178.Text = "\224\184\132\224\184\165\224\184\180\224\184\129\224\184\151\224\184\181\224\185\136\224\184\129\224\184\165\224\185\137\224\184\173\224\184\135\224\184\154\224\184\153\224\184\163\224\184\150 (\224\184\171\224\184\163\224\184\183\224\184\173\224\185\131\224\184\153\224\184\163\224\184\178\224\184\162\224\184\129\224\184\178\224\184\163) \224\185\128\224\184\158\224\184\183\224\185\136\224\184\173\224\184\155\224\184\163\224\184\177\224\184\154\224\184\148\224\185\137\224\184\167\224\184\162\224\185\128\224\184\132\224\184\163\224\184\183\224\185\136\224\184\173\224\184\135\224\184\161\224\184\183\224\184\173\224\184\148\224\185\137\224\184\178\224\184\153\224\184\165\224\185\136\224\184\178\224\184\135"
		end
		v_u_395()
	end
end
local v_u_470 = v_u_469
local function v_u_473(p471) -- name: screenPoint
	-- upvalues: (copy) v_u_6, (copy) v_u_8
	if p471 and p471.UserInputType == Enum.UserInputType.Touch then
		return Vector2.new(p471.Position.X, p471.Position.Y)
	end
	local v472 = v_u_6:GetMouseLocation()
	return Vector2.new(v472.X, v472.Y) - v_u_8:GetGuiInset()
end
local function v_u_524() -- name: refreshGizmo
	-- upvalues: (ref) v_u_137, (ref) v_u_138, (ref) v_u_140, (ref) v_u_186, (copy) v_u_254, (copy) v_u_300, (copy) v_u_8, (copy) v_u_268, (copy) v_u_271, (copy) v_u_274, (copy) v_u_275, (copy) v_u_276, (copy) v_u_277, (copy) v_u_290, (copy) v_u_292, (copy) v_u_293, (copy) v_u_294, (copy) v_u_12, (copy) v_u_278, (copy) v_u_280, (copy) v_u_281, (copy) v_u_282, (copy) v_u_283, (copy) v_u_288, (copy) v_u_289, (copy) v_u_285
	local v474 = v_u_137 and v_u_137.sel
	if v474 then
		v474 = v_u_137.list[v_u_137.sel]
	end
	local v475 = v474 ~= nil and (v_u_138 ~= "select" and v_u_140 ~= nil) and not v_u_137.armed
	if v475 then
		v475 = not v_u_186
	end
	v_u_254.Visible = v475
	if v475 then
		local v476 = v_u_300(v474.c)
		local v477 = (v474.part.CFrame * v474.cf):PointToWorldSpace(v476 * v474.s)
		local v478, v479 = workspace.CurrentCamera:WorldToViewportPoint(v477)
		local v480 = Vector2.new(v478.X, v478.Y) - v_u_8:GetGuiInset()
		if v479 then
			local v481 = v_u_137.seat or v_u_137.model.PrimaryPart
			local v482
			if v481 then
				v482 = v481.CFrame.Rotation
			else
				v482 = v_u_137.model:GetPivot().Rotation
			end
			for v483, v484 in v_u_268 do
				local v485 = v477 + v482:VectorToWorldSpace(v_u_271[v483]) * 0.3
				local v486, _ = workspace.CurrentCamera:WorldToViewportPoint(v485)
				local v487 = Vector2.new(v486.X, v486.Y) - v_u_8:GetGuiInset() - v480
				local v488
				if v487.Magnitude > 2 then
					v488 = v487.Unit
				else
					v488 = Vector2.new(v483 % 2 == 1 and 1 or -1, v483 > 2 and (v483 == 3 and -0.3 or 0.3) or 0).Unit
				end
				local v489 = v480 + v488 * 72
				v484.button.Visible = v_u_138 == "move"
				v484.button.Position = UDim2.fromOffset(v489.X, v489.Y)
				local v490 = v484.arrow
				local v491 = v488.Y
				local v492 = v488.X
				local v493 = math.atan2(v491, v492)
				v490.Rotation = math.deg(v493)
			end
			local v494 = v480 + Vector2.new(86, 0)
			local v495 = v480 + Vector2.new(0, -86)
			local v496 = v_u_137.seat or v_u_137.model.PrimaryPart
			local v497
			if v496 then
				v497 = v496.CFrame.Rotation
			else
				v497 = v_u_137.model:GetPivot().Rotation
			end
			local v498, v499, v500 = v497:ToObjectSpace((v474.part.CFrame * v474.cf).Rotation):ToEulerAnglesYXZ()
			local v501 = math.deg(v498)
			local v502 = math.deg(v499)
			local v503 = math.deg(v500)
			local v504 = v_u_138 == "height"
			local v505 = v_u_275
			local v506 = v_u_276
			local v507 = v_u_277
			v_u_274.Visible = v504
			v505.Visible = v504
			v506.Visible = v504
			v507.Visible = v504
			v_u_274.Position = UDim2.fromOffset(v494.X, v494.Y)
			v_u_275.Position = UDim2.fromOffset(v494.X, v494.Y - 46)
			v_u_276.Position = UDim2.fromOffset(v494.X, v494.Y + 46)
			v_u_277.Position = UDim2.fromOffset(v494.X, v494.Y + 64)
			v_u_277.Text = "\224\184\165\224\184\178\224\184\129\224\184\130\224\184\182\224\185\137\224\184\153/\224\184\165\224\184\135 \194\183 PageUp / PageDown"
			local v508 = v_u_138 == "scale"
			local v509 = v_u_292
			local v510 = v_u_293
			local v511 = v_u_294
			v_u_290.Visible = v508
			v509.Visible = v508
			v510.Visible = v508
			v511.Visible = v508
			v_u_290.Position = UDim2.fromOffset(v494.X, v494.Y)
			v_u_292.Position = UDim2.fromOffset(v494.X, v494.Y - 46)
			v_u_293.Position = UDim2.fromOffset(v494.X, v494.Y + 46)
			v_u_294.Position = UDim2.fromOffset(v494.X, v494.Y + 64)
			local v512 = (v474.s - 1) / v_u_12.SCALE_STEP
			local v513 = math.round(v512)
			v_u_294.Text = ("\224\184\130\224\184\153\224\184\178\224\184\148 %s%d (\224\185\132\224\184\148\224\185\137 \194\1772 \224\184\149\224\184\180\224\185\138\224\184\129) \194\183 x%.1f"):format(v513 > 0 and "+" or "", v513, v474.s)
			local v514 = v_u_138 == "rotate"
			local v515 = v_u_280
			local v516 = v_u_281
			local v517 = v_u_282
			v_u_278.Visible = v514
			v515.Visible = v514
			v516.Visible = v514
			v517.Visible = v514
			v_u_278.Position = UDim2.fromOffset(v495.X, v495.Y)
			v_u_280.Position = UDim2.fromOffset(v495.X - 44, v495.Y)
			v_u_281.Position = UDim2.fromOffset(v495.X + 44, v495.Y)
			v_u_282.Position = UDim2.fromOffset(v495.X, v495.Y + 20)
			v_u_282.Text = ("\224\184\171\224\184\161\224\184\184\224\184\153 %d\194\176 \194\183 \224\184\165\224\184\178\224\184\129\224\184\139\224\185\137\224\184\178\224\184\162\224\184\130\224\184\167\224\184\178"):format((math.round(v502)))
			local v518 = v_u_138 == "tilt"
			local v519 = v_u_288
			local v520 = v_u_289
			v_u_283.Visible = v518
			v519.Visible = v518
			v520.Visible = v518
			v_u_283.Position = UDim2.fromOffset(v495.X, v495.Y)
			for _, v521 in v_u_285 do
				v521.button.Visible = v518
				v521.button.Position = UDim2.fromOffset(v495.X + v521.off.X, v495.Y + v521.off.Y)
			end
			v_u_288.Position = UDim2.fromOffset(v495.X + 44, v495.Y + 44)
			v_u_289.Position = UDim2.fromOffset(v495.X, v495.Y + 62)
			local v522 = v_u_289
			local v523 = -v503
			v522.Text = ("\224\185\128\224\184\173\224\184\181\224\184\162\224\184\135 %d\194\176 \194\183 \224\185\128\224\184\135\224\184\162 %d\194\176"):format(math.round(v523), (math.round(v501)))
		else
			v_u_254.Visible = false
		end
	else
		return
	end
end
local function v_u_530(p525) -- name: castGhost
	-- upvalues: (ref) v_u_137
	local v526 = workspace.CurrentCamera:ScreenPointToRay(p525.X, p525.Y)
	local v527 = workspace:Raycast(v526.Origin, v526.Direction * 300, v_u_137.ghostParams)
	if not v527 then
		return nil
	end
	for v528, v529 in v_u_137.list do
		if not (v529.ghost and v527.Instance:IsDescendantOf(v529.ghost)) then
			continue
		end
		return v528
	end
	return nil
end
for v_u_531, v532 in v_u_268 do
	local function v_u_548(p533, p534)
		-- upvalues: (copy) v_u_300, (copy) v_u_8, (ref) v_u_137, (copy) v_u_271, (copy) v_u_531, (ref) v_u_139, (copy) v_u_473
		local v535 = v_u_300(p534.c)
		local v536 = (p534.part.CFrame * p534.cf):PointToWorldSpace(v535 * p534.s)
		local v537, _ = workspace.CurrentCamera:WorldToViewportPoint(v536)
		local v538 = Vector2.new(v537.X, v537.Y) - v_u_8:GetGuiInset()
		local v539 = v_u_137.seat or v_u_137.model.PrimaryPart
		local v540
		if v539 then
			v540 = v539.CFrame.Rotation
		else
			v540 = v_u_137.model:GetPivot().Rotation
		end
		local v541 = v540:VectorToWorldSpace(v_u_271[v_u_531])
		local v542 = v536 + v541
		local v543, _ = workspace.CurrentCamera:WorldToViewportPoint(v542)
		local v544 = Vector2.new(v543.X, v543.Y) - v_u_8:GetGuiInset() - v538
		local v545 = {
			["kind"] = "move",
			["input"] = nil,
			["from"] = nil,
			["i"] = nil,
			["w0"] = nil,
			["dirW"] = nil,
			["sdir"] = nil,
			["pps"] = nil,
			["input"] = p533,
			["from"] = v_u_473(p533),
			["i"] = v_u_137.sel,
			["w0"] = p534.part.CFrame * p534.cf,
			["dirW"] = v541
		}
		local v546
		if v544.Magnitude > 0.001 then
			v546 = v544.Unit
		else
			v546 = Vector2.xAxis
		end
		v545.sdir = v546
		local v547 = v544.Magnitude
		v545.pps = math.max(v547, 4)
		v_u_139 = v545
	end
	v532.button.InputBegan:Connect(function(p549)
		-- upvalues: (ref) v_u_137, (copy) v_u_548
		if v_u_137 and (p549.UserInputType == Enum.UserInputType.MouseButton1 or p549.UserInputType == Enum.UserInputType.Touch) then
			local v550 = v_u_137 and v_u_137.sel
			if v550 then
				v550 = v_u_137.list[v_u_137.sel]
			end
			if v550 then
				v_u_548(p549, v550)
			end
		end
	end)
end
local function v_u_564(p551, p552)
	-- upvalues: (copy) v_u_300, (ref) v_u_137, (copy) v_u_8, (ref) v_u_139, (copy) v_u_473
	local v553 = v_u_300(p552.c)
	local v554 = (p552.part.CFrame * p552.cf):PointToWorldSpace(v553 * p552.s)
	local v555 = v_u_137.seat or v_u_137.model.PrimaryPart
	local v556
	if v555 then
		v556 = v555.CFrame.Rotation
	else
		v556 = v_u_137.model:GetPivot().Rotation
	end
	local v557 = v556.UpVector
	local v558 = v554 + v557
	local v559, _ = workspace.CurrentCamera:WorldToViewportPoint(v558)
	local v560 = Vector2.new(v559.X, v559.Y) - v_u_8:GetGuiInset()
	local v561, _ = workspace.CurrentCamera:WorldToViewportPoint(v554)
	local v562 = (v560 - (Vector2.new(v561.X, v561.Y) - v_u_8:GetGuiInset())).Magnitude
	local v563 = math.max(v562, 4)
	v_u_139 = {
		["kind"] = "height",
		["input"] = nil,
		["from"] = nil,
		["i"] = nil,
		["w0"] = nil,
		["upW"] = nil,
		["pps"] = nil,
		["input"] = p551,
		["from"] = v_u_473(p551),
		["i"] = v_u_137.sel,
		["w0"] = p552.part.CFrame * p552.cf,
		["upW"] = v557,
		["pps"] = v563
	}
end
v_u_274.InputBegan:Connect(function(p565)
	-- upvalues: (ref) v_u_137, (copy) v_u_564
	if v_u_137 and (p565.UserInputType == Enum.UserInputType.MouseButton1 or p565.UserInputType == Enum.UserInputType.Touch) then
		local v566 = v_u_137 and v_u_137.sel
		if v566 then
			v566 = v_u_137.list[v_u_137.sel]
		end
		if v566 then
			v_u_564(p565, v566)
		end
	end
end)
local function v_u_569(p567, p568)
	-- upvalues: (ref) v_u_139, (copy) v_u_473, (ref) v_u_137, (copy) v_u_325
	v_u_139 = {
		["kind"] = "rotate",
		["input"] = nil,
		["from"] = nil,
		["i"] = nil,
		["a0"] = nil,
		["input"] = p567,
		["from"] = v_u_473(p567),
		["i"] = v_u_137.sel,
		["a0"] = { v_u_325(p568) }
	}
end
v_u_278.InputBegan:Connect(function(p570)
	-- upvalues: (ref) v_u_137, (copy) v_u_569
	if v_u_137 and (p570.UserInputType == Enum.UserInputType.MouseButton1 or p570.UserInputType == Enum.UserInputType.Touch) then
		local v571 = v_u_137 and v_u_137.sel
		if v571 then
			v571 = v_u_137.list[v_u_137.sel]
		end
		if v571 then
			v_u_569(p570, v571)
		end
	end
end)
local function v_u_574(p572, p573)
	-- upvalues: (ref) v_u_139, (copy) v_u_473, (ref) v_u_137, (copy) v_u_325
	v_u_139 = {
		["kind"] = "tilt",
		["input"] = nil,
		["from"] = nil,
		["i"] = nil,
		["a0"] = nil,
		["input"] = p572,
		["from"] = v_u_473(p572),
		["i"] = v_u_137.sel,
		["a0"] = { v_u_325(p573) }
	}
end
v_u_283.InputBegan:Connect(function(p575)
	-- upvalues: (ref) v_u_137, (copy) v_u_574
	if v_u_137 and (p575.UserInputType == Enum.UserInputType.MouseButton1 or p575.UserInputType == Enum.UserInputType.Touch) then
		local v576 = v_u_137 and v_u_137.sel
		if v576 then
			v576 = v_u_137.list[v_u_137.sel]
		end
		if v576 then
			v_u_574(p575, v576)
		end
	end
end)
local function v_u_579(p577, p578)
	-- upvalues: (ref) v_u_139, (copy) v_u_473, (ref) v_u_137
	v_u_139 = {
		["kind"] = "scale",
		["input"] = nil,
		["from"] = nil,
		["i"] = nil,
		["s0"] = nil,
		["input"] = p577,
		["from"] = v_u_473(p577),
		["i"] = v_u_137.sel,
		["s0"] = p578.s
	}
end
v_u_290.InputBegan:Connect(function(p580)
	-- upvalues: (ref) v_u_137, (copy) v_u_579
	if v_u_137 and (p580.UserInputType == Enum.UserInputType.MouseButton1 or p580.UserInputType == Enum.UserInputType.Touch) then
		local v581 = v_u_137 and v_u_137.sel
		if v581 then
			v581 = v_u_137.list[v_u_137.sel]
		end
		if v581 then
			v_u_579(p580, v581)
		end
	end
end)
v_u_275.Activated:Connect(function()
	-- upvalues: (ref) v_u_137, (copy) v_u_318
	local v582 = v_u_137 and v_u_137.sel
	if v582 then
		v582 = v_u_137.list[v_u_137.sel]
	end
	if v582 then
		local v583 = v_u_318
		local v584 = v582.part.CFrame * v582.cf
		local v585 = v_u_137.seat or v_u_137.model.PrimaryPart
		local v586
		if v585 then
			v586 = v585.CFrame.Rotation
		else
			v586 = v_u_137.model:GetPivot().Rotation
		end
		v583(v582, v584 + v586:VectorToWorldSpace(Vector3.new(0, 1, 0)) * 0.02)
	end
end)
v_u_276.Activated:Connect(function()
	-- upvalues: (ref) v_u_137, (copy) v_u_318
	local v587 = v_u_137 and v_u_137.sel
	if v587 then
		v587 = v_u_137.list[v_u_137.sel]
	end
	if v587 then
		local v588 = v_u_318
		local v589 = v587.part.CFrame * v587.cf
		local v590 = v_u_137.seat or v_u_137.model.PrimaryPart
		local v591
		if v590 then
			v591 = v590.CFrame.Rotation
		else
			v591 = v_u_137.model:GetPivot().Rotation
		end
		v588(v587, v589 + v591:VectorToWorldSpace(Vector3.new(0, 1, 0)) * -0.02)
	end
end)
v_u_280.Activated:Connect(function()
	-- upvalues: (ref) v_u_137, (copy) v_u_335
	local v592 = v_u_137 and v_u_137.sel
	if v592 then
		v592 = v_u_137.list[v_u_137.sel]
	end
	if v592 then
		local v593 = v_u_137.seat or v_u_137.model.PrimaryPart
		local v594
		if v593 then
			v594 = v593.CFrame.Rotation
		else
			v594 = v_u_137.model:GetPivot().Rotation
		end
		local v595, v596, v597 = v594:ToObjectSpace((v592.part.CFrame * v592.cf).Rotation):ToEulerAnglesYXZ()
		local v598 = math.deg(v595)
		local v599 = math.deg(v596)
		local v600 = math.deg(v597)
		local v601 = v_u_335
		local v602 = v598 + 0
		v601(v592, math.clamp(v602, -85, 85), (v599 + 5 + 180) % 360 - 180, (v600 + 0 + 180) % 360 - 180)
	end
end)
v_u_281.Activated:Connect(function()
	-- upvalues: (ref) v_u_137, (copy) v_u_335
	local v603 = v_u_137 and v_u_137.sel
	if v603 then
		v603 = v_u_137.list[v_u_137.sel]
	end
	if v603 then
		local v604 = v_u_137.seat or v_u_137.model.PrimaryPart
		local v605
		if v604 then
			v605 = v604.CFrame.Rotation
		else
			v605 = v_u_137.model:GetPivot().Rotation
		end
		local v606, v607, v608 = v605:ToObjectSpace((v603.part.CFrame * v603.cf).Rotation):ToEulerAnglesYXZ()
		local v609 = math.deg(v606)
		local v610 = math.deg(v607)
		local v611 = math.deg(v608)
		local v612 = v_u_335
		local v613 = v609 + 0
		v612(v603, math.clamp(v613, -85, 85), (v610 + -5 + 180) % 360 - 180, (v611 + 0 + 180) % 360 - 180)
	end
end)
v_u_285.left.button.Activated:Connect(function()
	-- upvalues: (ref) v_u_137, (copy) v_u_335
	local v614 = v_u_137 and v_u_137.sel
	if v614 then
		v614 = v_u_137.list[v_u_137.sel]
	end
	if v614 then
		local v615 = v_u_137.seat or v_u_137.model.PrimaryPart
		local v616
		if v615 then
			v616 = v615.CFrame.Rotation
		else
			v616 = v_u_137.model:GetPivot().Rotation
		end
		local v617, v618, v619 = v616:ToObjectSpace((v614.part.CFrame * v614.cf).Rotation):ToEulerAnglesYXZ()
		local v620 = math.deg(v617)
		local v621 = math.deg(v618)
		local v622 = math.deg(v619)
		local v623 = v_u_335
		local v624 = v620 + 0
		v623(v614, math.clamp(v624, -85, 85), (v621 + 0 + 180) % 360 - 180, (v622 + 5 + 180) % 360 - 180)
	end
end)
v_u_285.right.button.Activated:Connect(function()
	-- upvalues: (ref) v_u_137, (copy) v_u_335
	local v625 = v_u_137 and v_u_137.sel
	if v625 then
		v625 = v_u_137.list[v_u_137.sel]
	end
	if v625 then
		local v626 = v_u_137.seat or v_u_137.model.PrimaryPart
		local v627
		if v626 then
			v627 = v626.CFrame.Rotation
		else
			v627 = v_u_137.model:GetPivot().Rotation
		end
		local v628, v629, v630 = v627:ToObjectSpace((v625.part.CFrame * v625.cf).Rotation):ToEulerAnglesYXZ()
		local v631 = math.deg(v628)
		local v632 = math.deg(v629)
		local v633 = math.deg(v630)
		local v634 = v_u_335
		local v635 = v631 + 0
		v634(v625, math.clamp(v635, -85, 85), (v632 + 0 + 180) % 360 - 180, (v633 + -5 + 180) % 360 - 180)
	end
end)
v_u_285.up.button.Activated:Connect(function()
	-- upvalues: (ref) v_u_137, (copy) v_u_335
	local v636 = v_u_137 and v_u_137.sel
	if v636 then
		v636 = v_u_137.list[v_u_137.sel]
	end
	if v636 then
		local v637 = v_u_137.seat or v_u_137.model.PrimaryPart
		local v638
		if v637 then
			v638 = v637.CFrame.Rotation
		else
			v638 = v_u_137.model:GetPivot().Rotation
		end
		local v639, v640, v641 = v638:ToObjectSpace((v636.part.CFrame * v636.cf).Rotation):ToEulerAnglesYXZ()
		local v642 = math.deg(v639)
		local v643 = math.deg(v640)
		local v644 = math.deg(v641)
		local v645 = v_u_335
		local v646 = v642 + 5
		v645(v636, math.clamp(v646, -85, 85), (v643 + 0 + 180) % 360 - 180, (v644 + 0 + 180) % 360 - 180)
	end
end)
v_u_285.down.button.Activated:Connect(function()
	-- upvalues: (ref) v_u_137, (copy) v_u_335
	local v647 = v_u_137 and v_u_137.sel
	if v647 then
		v647 = v_u_137.list[v_u_137.sel]
	end
	if v647 then
		local v648 = v_u_137.seat or v_u_137.model.PrimaryPart
		local v649
		if v648 then
			v649 = v648.CFrame.Rotation
		else
			v649 = v_u_137.model:GetPivot().Rotation
		end
		local v650, v651, v652 = v649:ToObjectSpace((v647.part.CFrame * v647.cf).Rotation):ToEulerAnglesYXZ()
		local v653 = math.deg(v650)
		local v654 = math.deg(v651)
		local v655 = math.deg(v652)
		local v656 = v_u_335
		local v657 = v653 + -5
		v656(v647, math.clamp(v657, -85, 85), (v654 + 0 + 180) % 360 - 180, (v655 + 0 + 180) % 360 - 180)
	end
end)
v_u_288.Activated:Connect(function()
	-- upvalues: (ref) v_u_137, (copy) v_u_318
	local v658 = v_u_137 and v_u_137.sel
	if v658 then
		v658 = v_u_137.list[v_u_137.sel]
	end
	if v658 then
		local v659 = v_u_137.seat or v_u_137.model.PrimaryPart
		local v660
		if v659 then
			v660 = v659.CFrame.Rotation
		else
			v660 = v_u_137.model:GetPivot().Rotation
		end
		local v661, v662, v663 = v660:ToObjectSpace((v658.part.CFrame * v658.cf).Rotation):ToEulerAnglesYXZ()
		math.deg(v661)
		local v664 = math.deg(v662)
		math.deg(v663)
		local v665 = v658.part.CFrame * v658.cf
		local v666 = v_u_318
		local v667 = CFrame.new(v665.Position)
		local v668 = v_u_137.seat or v_u_137.model.PrimaryPart
		local v669
		if v668 then
			v669 = v668.CFrame.Rotation
		else
			v669 = v_u_137.model:GetPivot().Rotation
		end
		v666(v658, v667 * v669 * CFrame.fromEulerAnglesYXZ(0, math.rad(v664), 0))
	end
end)
v_u_292.Activated:Connect(function()
	-- upvalues: (ref) v_u_137, (copy) v_u_12, (ref) v_u_470
	local v670 = v_u_137 and v_u_137.sel
	if v670 then
		v670 = v_u_137.list[v_u_137.sel]
	end
	if v670 then
		local v671 = v670.s + 1 * v_u_12.SCALE_STEP
		local v672 = v_u_12.SCALE_STEP
		local v673 = v671 / v672
		local v674 = math.round(v673) * v672
		local v675 = v_u_12.MIN_SCALE
		local v676 = v_u_12.MAX_SCALE
		v670.s = math.clamp(v674, v675, v676)
		if v670.ghost then
			v670.ghost:ScaleTo(v670.s)
		end
		v_u_470()
	end
end)
v_u_293.Activated:Connect(function()
	-- upvalues: (ref) v_u_137, (copy) v_u_12, (ref) v_u_470
	local v677 = v_u_137 and v_u_137.sel
	if v677 then
		v677 = v_u_137.list[v_u_137.sel]
	end
	if v677 then
		local v678 = v677.s + -1 * v_u_12.SCALE_STEP
		local v679 = v_u_12.SCALE_STEP
		local v680 = v678 / v679
		local v681 = math.round(v680) * v679
		local v682 = v_u_12.MIN_SCALE
		local v683 = v_u_12.MAX_SCALE
		v677.s = math.clamp(v681, v682, v683)
		if v677.ghost then
			v677.ghost:ScaleTo(v677.s)
		end
		v_u_470()
	end
end)
local function v_u_715(p684) -- name: updateDrag
	-- upvalues: (ref) v_u_139, (ref) v_u_137, (copy) v_u_473, (copy) v_u_325, (copy) v_u_12, (copy) v_u_318, (copy) v_u_357, (copy) v_u_335
	local v685 = v_u_139
	local v686 = v685 and v_u_137
	if v686 then
		v686 = v_u_137.list[v685.i]
	end
	if v686 then
		local v687 = v_u_473(p684)
		if v685.kind == "slide" then
			if not v685.started then
				if (v687 - v685.from).Magnitude < 6 then
					return
				end
				v685.started = true
				v685.a0 = { v_u_325(v686) }
			end
			local v688 = workspace.CurrentCamera:ScreenPointToRay(v687.X, v687.Y)
			local v689 = workspace:Raycast(v688.Origin, v688.Direction * 300, v_u_137.vehicleParams)
			if not (v689 and v_u_12.mountable(v689.Instance, v_u_137.model)) then
				v689 = nil
			end
			if v689 then
				v686.part = v689.Instance
				v_u_318(v686, (v_u_357(v686.c, v686.s, v689.Position, v689.Normal, v685.a0[1], v685.a0[2], v685.a0[3])))
				return
			end
		else
			if v685.kind == "move" then
				local v690 = v_u_318
				local v691 = v685.w0
				local v692 = v685.dirW
				local v693 = (v687 - v685.from):Dot(v685.sdir) / v685.pps / 0.005
				v690(v686, v691 + v692 * (math.round(v693) * 0.005))
				return
			end
			if v685.kind == "height" then
				local v694 = v_u_318
				local v695 = v685.w0
				local v696 = v685.upW
				local v697 = (v685.from.Y - v687.Y) / v685.pps / 0.005
				v694(v686, v695 + v696 * (math.round(v697) * 0.005))
				return
			end
			if v685.kind == "rotate" then
				local v698 = v_u_335
				local v699 = v685.a0[1]
				local v700 = (v685.a0[2] - (v687.X - v685.from.X) * 0.5) / 1
				v698(v686, v699, (math.round(v700) * 1 + 180) % 360 - 180, v685.a0[3])
				return
			end
			if v685.kind == "tilt" then
				local v701 = v_u_335
				local v702 = (v685.a0[1] + (v685.from.Y - v687.Y) / 3) / 1
				local v703 = math.round(v702) * 1
				local v704 = math.clamp(v703, -85, 85)
				local v705 = v685.a0[2]
				local v706 = (v685.a0[3] - (v687.X - v685.from.X) / 3) / 1
				v701(v686, v704, v705, (math.round(v706) * 1 + 180) % 360 - 180)
				return
			end
			if v685.kind == "scale" then
				local v707 = v685.s0
				local v708 = (v685.from.Y - v687.Y) / 40
				local v709 = v707 + math.round(v708) * v_u_12.SCALE_STEP
				local v710 = v_u_12.SCALE_STEP
				local v711 = v709 / v710
				local v712 = math.round(v711) * v710
				local v713 = v_u_12.MIN_SCALE
				local v714 = v_u_12.MAX_SCALE
				v686.s = math.clamp(v712, v713, v714)
				if v686.ghost then
					v686.ghost:ScaleTo(v686.s)
				end
			end
		end
	else
		v_u_139 = nil
	end
end
local v_u_716 = {}
local v_u_717 = RaycastParams.new()
v_u_717.FilterType = Enum.RaycastFilterType.Exclude
local function v_u_721(p718) -- name: hideRider
	-- upvalues: (copy) v_u_17
	local v719 = v_u_17.Character
	if v719 then
		for _, v720 in v719:GetDescendants() do
			if not (v720:IsA("BasePart") or v720:IsA("Decal")) then
				continue
			end
			v720.LocalTransparencyModifier = p718 and 1 or 0
		end
	end
end
local function v_u_744() -- name: camStart
	-- upvalues: (ref) v_u_137, (ref) v_u_140, (ref) v_u_716
	local v722 = workspace.CurrentCamera
	local v723 = v_u_137.model
	local v724, v725 = v723:GetBoundingBox()
	local v726 = v_u_137.seat or (v723.PrimaryPart or v723:FindFirstChildWhichIsA("BasePart", true))
	local v727 = v722.CFrame.Position - v724.Position
	local v728 = v725.X
	local v729 = v725.Y
	local v730 = v725.Z
	local v731 = math.max(v728, v729, v730) * 1.3
	local v732 = math.clamp(v731, 6, 28)
	local v733 = {
		["ref"] = nil,
		["home"] = nil,
		["homeDist"] = nil,
		["reach"] = nil,
		["yaw"] = nil,
		["pitch"] = 0.35,
		["dist"] = nil,
		["saved"] = nil,
		["ref"] = v726,
		["home"] = v726.CFrame:PointToObjectSpace(v724.Position),
		["homeDist"] = v732
	}
	local v734 = v725.X
	local v735 = v725.Y
	local v736 = v725.Z
	v733.reach = math.max(v734, v735, v736) * 0.65
	local v737 = v727.X
	local v738 = v727.Z
	v733.yaw = math.atan2(v737, v738)
	v733.dist = v732
	v733.saved = {
		["type"] = v722.CameraType,
		["subject"] = v722.CameraSubject,
		["fov"] = v722.FieldOfView
	}
	v_u_140 = v733
	v_u_140.free = v_u_140.home
	local v739 = v_u_140
	local v740 = {
		["yaw"] = nil,
		["pitch"] = 0.35,
		["dist"] = nil,
		["focus"] = nil,
		["yaw"] = v_u_140.yaw
	}
	local v741 = v727.Magnitude
	local v742 = v732 * 0.6
	local v743 = v732 * 1.6
	v740.dist = math.clamp(v741, v742, v743)
	v740.focus = v724.Position
	v739.cur = v740
	v_u_716 = {}
end
local function v_u_748() -- name: camStop
	-- upvalues: (ref) v_u_140, (ref) v_u_716, (ref) v_u_141, (copy) v_u_6, (copy) v_u_721
	if v_u_140 then
		local v745 = workspace.CurrentCamera
		v745.CameraType = v_u_140.saved.type
		v745.CameraSubject = v_u_140.saved.subject
		v745.FieldOfView = v_u_140.saved.fov
		for v746, v747 in v_u_716 do
			if not v746.Parent then
				continue
			end
			v746.LocalTransparencyModifier = v747
		end
		v_u_716 = {}
		v_u_140 = nil
		v_u_141 = false
		v_u_6.MouseBehavior = Enum.MouseBehavior.Default
		v_u_721(false)
	end
end
local function v_u_759(p749, p750) -- name: zoomBy
	-- upvalues: (ref) v_u_140, (ref) v_u_137, (copy) v_u_12
	if v_u_140 then
		local v751 = v_u_140.dist
		local v752 = v_u_140
		local v753 = v_u_140.dist * p749
		v752.dist = math.clamp(v753, 1.2, 30)
		local v754 = v_u_137 and v_u_137.sel
		if v754 then
			v754 = v_u_137.list[v_u_137.sel]
		end
		if v754 then
			return
		elseif v_u_140.dist >= v_u_140.homeDist * 0.97 then
			v_u_140.free = v_u_140.home
		else
			if p749 < 1 then
				if p750 then
					local v755 = workspace.CurrentCamera:ScreenPointToRay(p750.X, p750.Y)
					p750 = workspace:Raycast(v755.Origin, v755.Direction * 300, v_u_137.vehicleParams)
					if not (p750 and v_u_12.mountable(p750.Instance, v_u_137.model)) then
						p750 = nil
					end
				end
			else
				p750 = false
			end
			if p750 then
				local v756 = v_u_140.dist / v751
				local v757 = v_u_140.ref.CFrame:PointToWorldSpace(v_u_140.free)
				local v758 = v_u_140.ref.CFrame:PointToObjectSpace(p750.Position + (v757 - p750.Position) * v756) - v_u_140.home
				if v758.Magnitude > v_u_140.reach then
					v758 = v758.Unit * v_u_140.reach
				end
				v_u_140.free = v_u_140.home + v758
			end
		end
	else
		return
	end
end
local function v_u_771(p760, p761) -- name: clearView
	-- upvalues: (copy) v_u_17, (ref) v_u_137, (ref) v_u_716, (copy) v_u_717
	local v762 = { v_u_17.Character, v_u_137.ghosts }
	local v763 = workspace:FindFirstChild("SpawnedVehicles")
	if v763 then
		table.insert(v762, v763)
	end
	for v764 in v_u_716 do
		table.insert(v762, v764)
	end
	v_u_717.FilterDescendantsInstances = v762
	local v765 = p761.Position - p760
	for _ = 1, 5 do
		local v766 = workspace:Raycast(p760, v765, v_u_717)
		if not v766 then
			break
		end
		local v767 = v766.Instance
		v_u_717:AddToFilter(v767)
		if v766.Normal.Y >= 0.7 then
			local v768 = CFrame.new
			local v769 = v765.Unit
			local v770 = v766.Distance - 0.3
			return v768(p760 + v769 * math.max(v770, 0.5)) * p761.Rotation
		end
		if v_u_716[v767] == nil then
			v_u_716[v767] = v767.LocalTransparencyModifier
		end
		v767.LocalTransparencyModifier = 1
	end
	return p761
end
v5:BindToRenderStep("DashcamEditorCamera", Enum.RenderPriority.Camera.Value + 1, function(p772)
	-- upvalues: (ref) v_u_137, (ref) v_u_140, (ref) v_u_139, (copy) v_u_300, (copy) v_u_771, (copy) v_u_721, (ref) v_u_186, (copy) v_u_185, (copy) v_u_12, (copy) v_u_6, (copy) v_u_473, (copy) v_u_357, (ref) v_u_524, (copy) v_u_178
	if v_u_137 and (v_u_140 and v_u_140.ref.Parent) then
		local v773 = workspace.CurrentCamera
		v773.CameraType = Enum.CameraType.Scriptable
		v773.FieldOfView = 50
		local v774 = -math.min(p772, 0.1) * 12
		local v775 = 1 - math.exp(v774)
		local v776 = v_u_140.cur
		v776.yaw = v776.yaw + (v_u_140.yaw - v776.yaw) * v775
		v776.pitch = v776.pitch + (v_u_140.pitch - v776.pitch) * v775
		v776.dist = v776.dist + (v_u_140.dist - v776.dist) * v775
		local v777 = v776.focus
		local v778
		if v_u_139 and (v_u_139.kind == "slide" and v_u_139.started) then
			v778 = v_u_140.cur.focus
		else
			local v779 = v_u_137 and v_u_137.sel
			if v779 then
				v779 = v_u_137.list[v_u_137.sel]
			end
			if v779 then
				local v780 = v_u_300(v779.c)
				v778 = (v779.part.CFrame * v779.cf):PointToWorldSpace(v780 * v779.s)
			else
				v778 = v_u_140.ref.CFrame:PointToWorldSpace(v_u_140.free)
			end
		end
		v776.focus = v777:Lerp(v778, v775)
		local v781 = CFrame.new(v776.focus) * CFrame.Angles(0, v776.yaw, 0) * CFrame.Angles(-v776.pitch, 0, 0) * CFrame.new(0, 0, v776.dist)
		v773.CFrame = v_u_771(v776.focus, v781)
		v773.Focus = CFrame.new(v776.focus)
		v_u_721(true)
		local v782 = v_u_186 and (v_u_137 and v_u_137.sel)
		if v782 then
			v782 = v_u_137.list[v_u_137.sel]
		end
		if v782 and v782.part.Parent then
			local v783 = v782.part.CFrame * v782.cf
			local v784 = v783.LookVector
			local v785 = v773.ViewportSize
			local v786 = -math.min(p772, 0.1) * 10
			local v787 = 1 - math.exp(v786)
			local v788 = v_u_185
			v788.curYaw = v788.curYaw + (v_u_185.yaw - v_u_185.curYaw) * v787
			local v789 = v_u_185
			v789.curPitch = v789.curPitch + (v_u_185.pitch - v_u_185.curPitch) * v787
			local v790 = v_u_12.viewThrough
			local v791 = v785.X
			local v792 = v785.Y
			local v793 = v791 / math.max(v792, 1)
			local v794 = -v784.X
			local v795 = -v784.Z
			local v796 = math.atan2(v794, v795)
			local v797 = v784.Y
			local v798 = math.clamp(v797, -1, 1)
			local v799, v800 = v790(v782, v783, v793, v796, math.asin(v798), v_u_185.curYaw, v_u_185.curPitch, v_u_185.fovAdd)
			v773.CFrame = v799
			v773.Focus = CFrame.new(v799.Position)
			v773.FieldOfView = v800
			v_u_721(false)
			v_u_137.hl.Enabled = false
		else
			v782 = nil
		end
		for _, v801 in v_u_137.list do
			local v802 = v801 == v782
			if not (v801.ghost and (v802 or v801.lensHidden)) or v801.lensHidden == v802 then
				continue
			end
			v801.lensHidden = v802 and true or nil
			for _, v803 in v801.ghost:GetDescendants() do
				if not v803:IsA("BasePart") then
					continue
				end
				v803.LocalTransparencyModifier = v802 and 1 or 0
			end
		end
		for _, v804 in v_u_137.list do
			if not (v804.ghost and v804.part.Parent) then
				continue
			end
			v804.ghost:PivotTo(v804.part.CFrame * v804.cf)
		end
		if v_u_137.preview then
			local v805
			if v_u_6.MouseEnabled then
				local v806 = v_u_473()
				local v807 = workspace.CurrentCamera:ScreenPointToRay(v806.X, v806.Y)
				v805 = workspace:Raycast(v807.Origin, v807.Direction * 300, v_u_137.vehicleParams)
				if not (v805 and v_u_12.mountable(v805.Instance, v_u_137.model)) then
					v805 = nil
				end
			else
				v805 = nil
			end
			if v805 then
				v_u_137.preview:PivotTo((v_u_357(v_u_137.armed, 1, v805.Position, v805.Normal)))
				v_u_137.preview.Parent = v_u_137.ghosts
			else
				v_u_137.preview.Parent = nil
			end
		end
		v_u_524()
		local v808 = v_u_137 and v_u_137.sel
		if v808 then
			v808 = v_u_137.list[v_u_137.sel]
		end
		if v808 then
			local v809 = v_u_137 and v_u_137.sel
			if v809 then
				v809 = v_u_137.list[v_u_137.sel]
			end
			if not v809 then
				v_u_178.Text = "\224\184\132\224\184\165\224\184\180\224\184\129\224\184\151\224\184\181\224\185\136\224\184\129\224\184\165\224\185\137\224\184\173\224\184\135\224\184\154\224\184\153\224\184\163\224\184\150 (\224\184\171\224\184\163\224\184\183\224\184\173\224\185\131\224\184\153\224\184\163\224\184\178\224\184\162\224\184\129\224\184\178\224\184\163) \224\185\128\224\184\158\224\184\183\224\185\136\224\184\173\224\184\155\224\184\163\224\184\177\224\184\154\224\184\148\224\185\137\224\184\167\224\184\162\224\185\128\224\184\132\224\184\163\224\184\183\224\185\136\224\184\173\224\184\135\224\184\161\224\184\183\224\184\173\224\184\148\224\185\137\224\184\178\224\184\153\224\184\165\224\185\136\224\184\178\224\184\135"
				return
			end
			local v810 = v_u_137.seat or v_u_137.model.PrimaryPart
			local v811
			if v810 then
				v811 = v810.CFrame.Rotation
			else
				v811 = v_u_137.model:GetPivot().Rotation
			end
			local v812, v813, v814 = v811:ToObjectSpace((v809.part.CFrame * v809.cf).Rotation):ToEulerAnglesYXZ()
			local v815 = math.deg(v812)
			local v816 = math.deg(v813)
			local v817 = math.deg(v814)
			local v818 = v_u_178
			local v819 = v809.s
			local v820 = math.round(v816)
			local v821 = -v817
			v818.Text = ("\224\184\130\224\184\153\224\184\178\224\184\148 x%.2f \194\183 \224\184\171\224\184\161\224\184\184\224\184\153 %d\194\176 \194\183 \224\185\128\224\184\173\224\184\181\224\184\162\224\184\135 %d\194\176 \194\183 \224\185\128\224\184\135\224\184\162 %d\194\176\n\224\184\149\224\184\180\224\184\148\224\184\151\224\184\181\224\185\136: %s"):format(v819, v820, math.round(v821), math.round(v815), v809.part.Name)
		end
	end
end)
local function v_u_824(p822) -- name: overGui
	-- upvalues: (copy) v_u_17, (copy) v_u_153, (copy) v_u_223
	for _, v823 in v_u_17.PlayerGui:GetGuiObjectsAtPosition(p822.X, p822.Y) do
		if not v823:IsA("GuiButton") and (not v823:IsDescendantOf(v_u_153) and (not v823:IsDescendantOf(v_u_223) and (v823 ~= v_u_153 and v823 ~= v_u_223))) then
			continue
		end
		return true
	end
	return false
end
local function v_u_830(p825, p826) -- name: press
	-- upvalues: (ref) v_u_137, (copy) v_u_12, (copy) v_u_389, (copy) v_u_530, (copy) v_u_373, (ref) v_u_138, (ref) v_u_139
	if v_u_137.armed then
		local v827 = workspace.CurrentCamera:ScreenPointToRay(p825.X, p825.Y)
		local v828 = workspace:Raycast(v827.Origin, v827.Direction * 300, v_u_137.vehicleParams)
		if not (v828 and v_u_12.mountable(v828.Instance, v_u_137.model)) then
			v828 = nil
		end
		if v828 then
			v_u_389(v828)
		end
	else
		local v829 = v_u_530(p825)
		if v829 then
			if v_u_137.sel ~= v829 then
				v_u_373(v829)
			end
			if v_u_138 == "select" then
				v_u_139 = {
					["kind"] = "slide",
					["input"] = nil,
					["from"] = nil,
					["i"] = nil,
					["started"] = false,
					["input"] = p826,
					["from"] = p825,
					["i"] = v829
				}
				return
			end
		elseif v_u_137.sel then
			v_u_373(nil)
		end
	end
end
v_u_6.InputBegan:Connect(function(p831, p832)
	-- upvalues: (ref) v_u_137, (ref) v_u_140, (ref) v_u_141, (copy) v_u_6, (copy) v_u_473, (ref) v_u_186, (copy) v_u_824, (ref) v_u_139, (copy) v_u_830, (copy) v_u_530, (ref) v_u_142
	if v_u_137 and (v_u_140 and not p832) then
		local v833 = p831.UserInputType
		if v833 == Enum.UserInputType.MouseButton2 then
			v_u_141 = true
			v_u_6.MouseBehavior = Enum.MouseBehavior.LockCurrentPosition
		elseif v833 == Enum.UserInputType.MouseButton1 then
			local v834 = v_u_473(p831)
			if v_u_186 and not v_u_824(v834) then
				v_u_141 = true
				v_u_6.MouseBehavior = Enum.MouseBehavior.LockCurrentPosition
				return
			end
			if not (v_u_139 or v_u_824(v834)) then
				v_u_830(v834, p831)
				return
			end
		elseif v833 == Enum.UserInputType.Touch and not v_u_139 then
			local v835 = v_u_473(p831)
			if v_u_824(v835) then
				return
			end
			if not v_u_137.armed and (not v_u_186 and v_u_530(v835)) then
				v_u_830(v835, p831)
				return
			end
			v_u_141 = p831
			v_u_142 = {
				["input"] = p831,
				["from"] = v835,
				["t"] = os.clock()
			}
		end
	else
		return
	end
end)
v_u_6.InputChanged:Connect(function(p836, p837)
	-- upvalues: (ref) v_u_137, (ref) v_u_140, (ref) v_u_139, (copy) v_u_715, (ref) v_u_186, (copy) v_u_185, (copy) v_u_759, (copy) v_u_473, (ref) v_u_141
	if v_u_137 and v_u_140 then
		if v_u_139 and (p836.UserInputType == Enum.UserInputType.MouseMovement or p836 == v_u_139.input) then
			v_u_715(p836)
			return
		elseif p836.UserInputType == Enum.UserInputType.MouseWheel and not p837 then
			if v_u_186 then
				local v838 = v_u_185
				local v839 = v_u_185.fovAdd - p836.Position.Z * 6
				v838.fovAdd = math.clamp(v839, -60, 40)
			else
				v_u_759(0.88 ^ p836.Position.Z, v_u_473())
			end
		elseif v_u_141 and (v_u_141 == true and p836.UserInputType == Enum.UserInputType.MouseMovement or p836 == v_u_141) then
			local v840 = Vector2.new(p836.Delta.X, p836.Delta.Y)
			if p836.UserInputType == Enum.UserInputType.MouseMovement then
				local v841 = Vector2.new(p836.Position.X, p836.Position.Y)
				if v840.Magnitude < 0.001 and v_u_137.lastMouseAt then
					v840 = v841 - v_u_137.lastMouseAt
				end
				v_u_137.lastMouseAt = v841
			end
			if v_u_186 then
				local v842 = v_u_185
				v842.yaw = v842.yaw - v840.X * 0.004363323129985824
				local v843 = v_u_185
				local v844 = v_u_185.pitch - v840.Y * 0.004363323129985824
				v843.pitch = math.clamp(v844, -1.4835298641951802, 1.4835298641951802)
			else
				local v845 = v_u_140
				v845.yaw = v845.yaw - v840.X * 0.008
				local v846 = v_u_140
				local v847 = v_u_140.pitch + v840.Y * 0.006
				v846.pitch = math.clamp(v847, -0.25, 1.45)
			end
		else
			if p836.UserInputType == Enum.UserInputType.MouseMovement then
				v_u_137.lastMouseAt = Vector2.new(p836.Position.X, p836.Position.Y)
			end
			return
		end
	else
		return
	end
end)
v_u_6.InputEnded:Connect(function(p848)
	-- upvalues: (ref) v_u_137, (ref) v_u_139, (ref) v_u_470, (ref) v_u_141, (copy) v_u_6, (ref) v_u_142, (ref) v_u_186, (copy) v_u_473, (copy) v_u_830
	if v_u_137 then
		if v_u_139 and (p848.UserInputType == Enum.UserInputType.MouseButton1 or p848 == v_u_139.input) then
			v_u_139 = nil
			v_u_470()
		end
		if (p848.UserInputType == Enum.UserInputType.MouseButton2 or p848.UserInputType == Enum.UserInputType.MouseButton1) and v_u_141 == true then
			v_u_141 = false
			v_u_6.MouseBehavior = Enum.MouseBehavior.Default
		elseif v_u_141 and p848 == v_u_141 then
			v_u_141 = false
			local v849 = v_u_142
			v_u_142 = nil
			if v849 and (v849.input == p848 and (not v_u_186 and ((v_u_473(p848) - v849.from).Magnitude < 12 and os.clock() - v849.t < 0.4))) then
				v_u_830(v849.from, p848)
				v_u_139 = nil
			end
		end
	else
		return
	end
end)
v_u_6.TouchPinch:Connect(function(_, p850, _, p851, p852)
	-- upvalues: (ref) v_u_137, (ref) v_u_140, (ref) v_u_186, (copy) v_u_185, (copy) v_u_759
	if v_u_137 and (v_u_140 and (not p852 and (p851 == Enum.UserInputState.Change and p850 > 0))) then
		if v_u_186 then
			local v853 = v_u_185
			local v854 = v_u_185.fovAdd + (1 - math.clamp(p850, 0.97, 1.03)) * 60
			v853.fovAdd = math.clamp(v854, -60, 40)
			return
		end
		v_u_759(1 / math.clamp(p850, 0.97, 1.03), nil)
	end
end)
local v_u_855 = {
	Enum.KeyCode.One,
	Enum.KeyCode.Two,
	Enum.KeyCode.Three,
	Enum.KeyCode.Four,
	Enum.KeyCode.Five,
	Enum.KeyCode.Six,
	Enum.KeyCode.Left,
	Enum.KeyCode.Right,
	Enum.KeyCode.Up,
	Enum.KeyCode.Down,
	Enum.KeyCode.Comma,
	Enum.KeyCode.Period,
	Enum.KeyCode.PageUp,
	Enum.KeyCode.PageDown,
	Enum.KeyCode.Delete,
	Enum.KeyCode.Backspace,
	Enum.KeyCode.Minus,
	Enum.KeyCode.Equals
}
local function v_u_976(_, p856, p857) -- name: onKey
	-- upvalues: (ref) v_u_137, (copy) v_u_6, (copy) v_u_136, (copy) v_u_240, (ref) v_u_470, (copy) v_u_373, (copy) v_u_335, (copy) v_u_318, (copy) v_u_12, (ref) v_u_138
	if p856 ~= Enum.UserInputState.Begin or not v_u_137 then
		return Enum.ContextActionResult.Sink
	end
	local v858 = v_u_6:IsKeyDown(Enum.KeyCode.LeftShift) or v_u_6:IsKeyDown(Enum.KeyCode.RightShift)
	local v859 = p857.KeyCode
	for _, v860 in v_u_136 do
		if v860.keyCode ~= v859 then
			continue
		end
		v_u_240(v860.key)
		v_u_470()
		return Enum.ContextActionResult.Sink
	end
	local v861 = v858 and 0.1 or 0.02
	local v862 = v858 and 15 or 5
	local v863 = v859 == Enum.KeyCode.Left and -1 or (v859 == Enum.KeyCode.Right and 1 or 0)
	local v864 = v859 == Enum.KeyCode.Up and 1 or (v859 == Enum.KeyCode.Down and -1 or 0)
	if v859 == Enum.KeyCode.Delete or v859 == Enum.KeyCode.Backspace then
		if v_u_137.sel then
			local v865 = v_u_137.sel
			local v866 = v_u_137
			if v866 then
				v866 = v_u_137.list[v865]
			end
			if v866 then
				if v866.ghost then
					v866.ghost:Destroy()
				end
				table.remove(v_u_137.list, v865)
				v_u_373(nil)
			end
		end
	elseif v859 == Enum.KeyCode.Comma then
		local v867 = v_u_137 and v_u_137.sel
		if v867 then
			v867 = v_u_137.list[v_u_137.sel]
		end
		if v867 then
			local v868 = v_u_137.seat or v_u_137.model.PrimaryPart
			local v869
			if v868 then
				v869 = v868.CFrame.Rotation
			else
				v869 = v_u_137.model:GetPivot().Rotation
			end
			local v870, v871, v872 = v869:ToObjectSpace((v867.part.CFrame * v867.cf).Rotation):ToEulerAnglesYXZ()
			local v873 = math.deg(v870)
			local v874 = math.deg(v871)
			local v875 = math.deg(v872)
			local v876 = v_u_335
			local v877 = v873 + 0
			v876(v867, math.clamp(v877, -85, 85), (v874 + v862 + 180) % 360 - 180, (v875 + 0 + 180) % 360 - 180)
		end
	elseif v859 == Enum.KeyCode.Period then
		local v878 = -v862
		local v879 = v_u_137 and v_u_137.sel
		if v879 then
			v879 = v_u_137.list[v_u_137.sel]
		end
		if v879 then
			local v880 = v_u_137.seat or v_u_137.model.PrimaryPart
			local v881
			if v880 then
				v881 = v880.CFrame.Rotation
			else
				v881 = v_u_137.model:GetPivot().Rotation
			end
			local v882, v883, v884 = v881:ToObjectSpace((v879.part.CFrame * v879.cf).Rotation):ToEulerAnglesYXZ()
			local v885 = math.deg(v882)
			local v886 = math.deg(v883)
			local v887 = math.deg(v884)
			local v888 = v_u_335
			local v889 = v885 + 0
			v888(v879, math.clamp(v889, -85, 85), (v886 + v878 + 180) % 360 - 180, (v887 + 0 + 180) % 360 - 180)
		end
	elseif v859 == Enum.KeyCode.PageUp then
		local v890 = v_u_137 and v_u_137.sel
		if v890 then
			v890 = v_u_137.list[v_u_137.sel]
		end
		if v890 then
			local v891 = v_u_318
			local v892 = v890.part.CFrame * v890.cf
			local v893 = v_u_137.seat or v_u_137.model.PrimaryPart
			local v894
			if v893 then
				v894 = v893.CFrame.Rotation
			else
				v894 = v_u_137.model:GetPivot().Rotation
			end
			v891(v890, v892 + v894:VectorToWorldSpace(Vector3.new(0, 1, 0)) * v861)
		end
	elseif v859 == Enum.KeyCode.PageDown then
		local v895 = -v861
		local v896 = v_u_137 and v_u_137.sel
		if v896 then
			v896 = v_u_137.list[v_u_137.sel]
		end
		if v896 then
			local v897 = v_u_318
			local v898 = v896.part.CFrame * v896.cf
			local v899 = v_u_137.seat or v_u_137.model.PrimaryPart
			local v900
			if v899 then
				v900 = v899.CFrame.Rotation
			else
				v900 = v_u_137.model:GetPivot().Rotation
			end
			v897(v896, v898 + v900:VectorToWorldSpace(Vector3.new(0, 1, 0)) * v895)
		end
	elseif v859 == Enum.KeyCode.Equals then
		local v901 = v_u_137 and v_u_137.sel
		if v901 then
			v901 = v_u_137.list[v_u_137.sel]
		end
		if v901 then
			local v902 = v901.s + 1 * v_u_12.SCALE_STEP
			local v903 = v_u_12.SCALE_STEP
			local v904 = v902 / v903
			local v905 = math.round(v904) * v903
			local v906 = v_u_12.MIN_SCALE
			local v907 = v_u_12.MAX_SCALE
			v901.s = math.clamp(v905, v906, v907)
			if v901.ghost then
				v901.ghost:ScaleTo(v901.s)
			end
			v_u_470()
		end
	elseif v859 == Enum.KeyCode.Minus then
		local v908 = v_u_137 and v_u_137.sel
		if v908 then
			v908 = v_u_137.list[v_u_137.sel]
		end
		if v908 then
			local v909 = v908.s + -1 * v_u_12.SCALE_STEP
			local v910 = v_u_12.SCALE_STEP
			local v911 = v909 / v910
			local v912 = math.round(v911) * v910
			local v913 = v_u_12.MIN_SCALE
			local v914 = v_u_12.MAX_SCALE
			v908.s = math.clamp(v912, v913, v914)
			if v908.ghost then
				v908.ghost:ScaleTo(v908.s)
			end
			v_u_470()
		end
	elseif v_u_138 == "select" or v_u_138 == "move" then
		if v863 ~= 0 then
			local v915 = v863 * v861
			local v916 = v_u_137 and v_u_137.sel
			if v916 then
				v916 = v_u_137.list[v_u_137.sel]
			end
			if v916 then
				local v917 = v_u_318
				local v918 = v916.part.CFrame * v916.cf
				local v919 = v_u_137.seat or v_u_137.model.PrimaryPart
				local v920
				if v919 then
					v920 = v919.CFrame.Rotation
				else
					v920 = v_u_137.model:GetPivot().Rotation
				end
				v917(v916, v918 + v920:VectorToWorldSpace(Vector3.new(1, 0, 0)) * v915)
			end
		end
		if v864 ~= 0 then
			local v921 = -v864 * v861
			local v922 = v_u_137 and v_u_137.sel
			if v922 then
				v922 = v_u_137.list[v_u_137.sel]
			end
			if v922 then
				local v923 = v_u_318
				local v924 = v922.part.CFrame * v922.cf
				local v925 = v_u_137.seat or v_u_137.model.PrimaryPart
				local v926
				if v925 then
					v926 = v925.CFrame.Rotation
				else
					v926 = v_u_137.model:GetPivot().Rotation
				end
				v923(v922, v924 + v926:VectorToWorldSpace(Vector3.new(0, 0, 1)) * v921)
			end
		end
	elseif v_u_138 == "height" then
		if v864 ~= 0 then
			local v927 = v864 * v861
			local v928 = v_u_137 and v_u_137.sel
			if v928 then
				v928 = v_u_137.list[v_u_137.sel]
			end
			if v928 then
				local v929 = v_u_318
				local v930 = v928.part.CFrame * v928.cf
				local v931 = v_u_137.seat or v_u_137.model.PrimaryPart
				local v932
				if v931 then
					v932 = v931.CFrame.Rotation
				else
					v932 = v_u_137.model:GetPivot().Rotation
				end
				v929(v928, v930 + v932:VectorToWorldSpace(Vector3.new(0, 1, 0)) * v927)
			end
		end
	elseif v_u_138 == "rotate" then
		if v863 ~= 0 then
			local v933 = -v863 * v862
			local v934 = v_u_137 and v_u_137.sel
			if v934 then
				v934 = v_u_137.list[v_u_137.sel]
			end
			if v934 then
				local v935 = v_u_137.seat or v_u_137.model.PrimaryPart
				local v936
				if v935 then
					v936 = v935.CFrame.Rotation
				else
					v936 = v_u_137.model:GetPivot().Rotation
				end
				local v937, v938, v939 = v936:ToObjectSpace((v934.part.CFrame * v934.cf).Rotation):ToEulerAnglesYXZ()
				local v940 = math.deg(v937)
				local v941 = math.deg(v938)
				local v942 = math.deg(v939)
				local v943 = v_u_335
				local v944 = v940 + 0
				v943(v934, math.clamp(v944, -85, 85), (v941 + v933 + 180) % 360 - 180, (v942 + 0 + 180) % 360 - 180)
			end
		end
	elseif v_u_138 == "tilt" then
		if v863 ~= 0 then
			local v945 = -v863 * v862
			local v946 = v_u_137 and v_u_137.sel
			if v946 then
				v946 = v_u_137.list[v_u_137.sel]
			end
			if v946 then
				local v947 = v_u_137.seat or v_u_137.model.PrimaryPart
				local v948
				if v947 then
					v948 = v947.CFrame.Rotation
				else
					v948 = v_u_137.model:GetPivot().Rotation
				end
				local v949, v950, v951 = v948:ToObjectSpace((v946.part.CFrame * v946.cf).Rotation):ToEulerAnglesYXZ()
				local v952 = math.deg(v949)
				local v953 = math.deg(v950)
				local v954 = math.deg(v951)
				local v955 = v_u_335
				local v956 = v952 + 0
				v955(v946, math.clamp(v956, -85, 85), (v953 + 0 + 180) % 360 - 180, (v954 + v945 + 180) % 360 - 180)
			end
		end
		if v864 ~= 0 then
			local v957 = v864 * v862
			local v958 = v_u_137 and v_u_137.sel
			if v958 then
				v958 = v_u_137.list[v_u_137.sel]
			end
			if v958 then
				local v959 = v_u_137.seat or v_u_137.model.PrimaryPart
				local v960
				if v959 then
					v960 = v959.CFrame.Rotation
				else
					v960 = v_u_137.model:GetPivot().Rotation
				end
				local v961, v962, v963 = v960:ToObjectSpace((v958.part.CFrame * v958.cf).Rotation):ToEulerAnglesYXZ()
				local v964 = math.deg(v961)
				local v965 = math.deg(v962)
				local v966 = math.deg(v963)
				local v967 = v_u_335
				local v968 = v964 + v957
				v967(v958, math.clamp(v968, -85, 85), (v965 + 0 + 180) % 360 - 180, (v966 + 0 + 180) % 360 - 180)
			end
		end
	elseif v_u_138 == "scale" and v864 ~= 0 then
		local v969 = v_u_137 and v_u_137.sel
		if v969 then
			v969 = v_u_137.list[v_u_137.sel]
		end
		if v969 then
			local v970 = v969.s + v864 * v_u_12.SCALE_STEP
			local v971 = v_u_12.SCALE_STEP
			local v972 = v970 / v971
			local v973 = math.round(v972) * v971
			local v974 = v_u_12.MIN_SCALE
			local v975 = v_u_12.MAX_SCALE
			v969.s = math.clamp(v973, v974, v975)
			if v969.ghost then
				v969.ghost:ScaleTo(v969.s)
			end
			v_u_470()
		end
	end
	return Enum.ContextActionResult.Sink
end
local function v_u_977() -- name: holdWalk
	return Enum.ContextActionResult.Sink
end
local function v_u_980(p978) -- name: bindKeys
	-- upvalues: (copy) v_u_7, (copy) v_u_976, (copy) v_u_855, (copy) v_u_977
	if p978 then
		local v979 = v_u_855
		v_u_7:BindActionAtPriority("DashcamEditorKeys", v_u_976, false, Enum.ContextActionPriority.High.Value + 50, table.unpack(v979))
		v_u_7:BindActionAtPriority("DashcamEditorHoldWalk", v_u_977, false, Enum.ContextActionPriority.High.Value + 50, Enum.PlayerActions.CharacterForward, Enum.PlayerActions.CharacterBackward, Enum.PlayerActions.CharacterLeft, Enum.PlayerActions.CharacterRight, Enum.PlayerActions.CharacterJump)
	else
		v_u_7:UnbindAction("DashcamEditorKeys")
		v_u_7:UnbindAction("DashcamEditorHoldWalk")
	end
end
local function v997(p981) -- name: openEditor
	-- upvalues: (ref) v_u_137, (ref) v_u_391, (copy) v_u_12, (copy) v_u_17, (copy) v_u_15, (copy) v_u_47, (copy) v_u_20, (copy) v_u_361, (copy) v_u_1, (copy) v_u_18, (copy) v_u_125, (copy) v_u_744, (copy) v_u_980, (copy) v_u_240, (copy) v_u_135, (ref) v_u_470, (ref) v_u_144
	if v_u_137 then
		if p981 then
			v_u_391(v_u_12.part(p981))
		end
		return
	else
		local v982 = v_u_12.driven(v_u_17)
		if not v982 or (v982:GetAttribute("OwnerUserId") ~= v_u_17.UserId or not v_u_12.inBay(v982:GetPivot().Position)) then
			v982 = nil
		end
		if v982 then
			v_u_47.setOpen(false)
			v_u_137 = {
				["model"] = v982,
				["seat"] = v982:FindFirstChild("DriverSeat", true) or v982:FindFirstChild("VehicleSeat", true),
				["list"] = {},
				["parts"] = {},
				["query"] = {},
				["onIt"] = {}
			}
			for _, v983 in v982:GetDescendants() do
				if not (v983:IsA("BasePart") and v_u_12.mountable(v983, v982)) then
					continue
				end
				local v984 = v_u_137.parts
				table.insert(v984, v983)
				if v983.CanQuery then
					continue
				end
				v_u_137.query[v983] = true
				v983.CanQuery = true
			end
			v_u_137.vehicleParams = RaycastParams.new()
			v_u_137.vehicleParams.FilterType = Enum.RaycastFilterType.Include
			v_u_137.vehicleParams.FilterDescendantsInstances = v_u_137.parts
			v_u_137.ghosts = Instance.new("Folder")
			v_u_137.ghosts.Name = "DashcamEditorGhost"
			v_u_137.ghosts.Parent = workspace
			v_u_137.ghostParams = RaycastParams.new()
			v_u_137.ghostParams.FilterType = Enum.RaycastFilterType.Include
			v_u_137.ghostParams.FilterDescendantsInstances = { v_u_137.ghosts }
			v_u_137.hl = Instance.new("Highlight")
			v_u_137.hl.Name = "Picked"
			v_u_137.hl.FillColor = v_u_20
			v_u_137.hl.FillTransparency = 0.8
			v_u_137.hl.OutlineColor = v_u_20
			v_u_137.hl.DepthMode = Enum.HighlightDepthMode.AlwaysOnTop
			v_u_137.hl.Enabled = false
			v_u_137.hl.Parent = v_u_137.ghosts
			v982:SetAttribute(v_u_12.EDITING, true)
			for _, v985 in v_u_12.read(v982) do
				v_u_137.onIt[v985.c] = true
				local v986 = v_u_12.find(v982, v985.k)
				if not v986 then
					continue
				end
				local v987 = {
					["c"] = v985.c,
					["part"] = v986,
					["cf"] = v_u_12.offset(v985),
					["s"] = v985.s,
					["m"] = v985.m,
					["f"] = v985.f,
					["d"] = v985.d
				}
				local v988 = v_u_137.list
				table.insert(v988, v987)
				v_u_361(v987)
			end
			local v_u_989 = true
			task.spawn(function()
				-- upvalues: (ref) v_u_1, (ref) v_u_18, (copy) v_u_989
				local v990 = v_u_1.invoke
				local v991 = v_u_18
				local v992 = v_u_989
				pcall(v990, v991, "Hold", v992)
			end)
			v_u_125()
			v_u_137.tags = {}
			for _, v993 in v_u_17.Character and v_u_17.Character:GetDescendants() or {} do
				if not (v993:IsA("BillboardGui") and v993.Enabled) then
					continue
				end
				local v994 = v_u_137.tags
				table.insert(v994, v993)
				v993:SetAttribute("GameHid", true)
				v993.Enabled = false
			end
			v_u_744()
			v_u_980(true)
			v_u_240("select")
			v_u_135.Enabled = true
			if p981 then
				v_u_391(v_u_12.part(p981))
			end
			v_u_470()
			local v_u_995 = v_u_137
			task.spawn(function()
				-- upvalues: (ref) v_u_137, (copy) v_u_995, (ref) v_u_17, (ref) v_u_12, (ref) v_u_144, (ref) v_u_15
				if v_u_137 == v_u_995 then
					task.wait(0.5)
					if v_u_137 == v_u_995 then
						local v996 = v_u_17.Character
						if v996 then
							v996 = v_u_17.Character:FindFirstChildOfClass("Humanoid")
						end
						if v_u_995.model.Parent and (v_u_12.inBay(v_u_995.model:GetPivot().Position) and (v996 and (v996.Health > 0 and v_u_12.driven(v_u_17) == v_u_995.model))) then
							continue
						end
						v_u_144()
						v_u_15.show("\224\184\155\224\184\180\224\184\148\224\184\129\224\184\178\224\184\163\224\184\149\224\184\180\224\184\148\224\184\129\224\184\165\224\185\137\224\184\173\224\184\135\224\185\129\224\184\165\224\185\137\224\184\167 (\224\185\132\224\184\161\224\185\136\224\185\132\224\184\148\224\185\137\224\184\154\224\184\177\224\184\153\224\184\151\224\184\182\224\184\129)", "info")
						return
					end
				end
			end)
		else
			v_u_15.show("\224\184\130\224\184\182\224\185\137\224\184\153\224\184\163\224\184\150\224\184\130\224\184\173\224\184\135\224\184\132\224\184\184\224\184\147\224\185\131\224\184\153\224\184\138\224\185\136\224\184\173\224\184\135\224\184\149\224\184\180\224\184\148\224\184\149\224\184\177\224\185\137\224\184\135 (\224\184\130\224\185\137\224\184\178\224\184\135\224\184\163\224\185\137\224\184\178\224\184\153) \224\184\129\224\185\136\224\184\173\224\184\153", "error")
		end
	end
end
local function v_u_1005() -- name: closeEditor
	-- upvalues: (ref) v_u_137, (ref) v_u_139, (ref) v_u_142, (ref) v_u_186, (ref) v_u_225, (copy) v_u_7, (copy) v_u_748, (copy) v_u_12, (copy) v_u_1, (copy) v_u_18, (copy) v_u_125, (copy) v_u_135, (copy) v_u_254
	if v_u_137 then
		local v998 = v_u_137
		v_u_137 = nil
		v_u_139 = nil
		v_u_142 = nil
		v_u_186 = false
		v_u_225 = nil
		for _, v999 in v998.tags or {} do
			if not v999.Parent then
				continue
			end
			v999.Enabled = true
			v999:SetAttribute("GameHid", nil)
		end
		v_u_7:UnbindAction("DashcamEditorKeys")
		v_u_7:UnbindAction("DashcamEditorHoldWalk")
		v_u_748()
		for v_u_1000 in v998.query do
			if not v_u_1000.Parent then
				continue
			end
			pcall(function()
				-- upvalues: (copy) v_u_1000
				v_u_1000.CanQuery = false
			end)
		end
		if v998.preview then
			v998.preview:Destroy()
		end
		v998.ghosts:Destroy()
		if v998.model.Parent then
			v998.model:SetAttribute(v_u_12.EDITING, nil)
		end
		local v_u_1001 = false
		task.spawn(function()
			-- upvalues: (ref) v_u_1, (ref) v_u_18, (copy) v_u_1001
			local v1002 = v_u_1.invoke
			local v1003 = v_u_18
			local v1004 = v_u_1001
			pcall(v1002, v1003, "Hold", v1004)
		end)
		v_u_125()
		v_u_135.Enabled = false
		v_u_254.Visible = false
	end
end
v220.Activated:Connect(function()
	-- upvalues: (ref) v_u_1005
	v_u_1005()
end)
v221.Activated:Connect(function()
	-- upvalues: (ref) v_u_137, (ref) v_u_62, (copy) v_u_12, (copy) v_u_61, (ref) v_u_1005
	if v_u_137 and not v_u_62 then
		local v1006 = {}
		for _, v1007 in v_u_137.list do
			local v1008 = v_u_12.keyOf(v_u_137.model, v1007.part)
			if not v1008 then
				continue
			end
			local v1009 = v_u_12.entry(v1007.c, v1008, v1007.cf, v1007.s)
			local v1010 = v1007.m
			local v1011 = v1007.f
			local v1012 = v1007.d
			v1009.m = v1010
			v1009.f = v1011
			v1009.d = v1012
			table.insert(v1006, v1009)
		end
		if v_u_61("Fit", v_u_12.wire(v1006)) then
			v_u_1005()
		end
	end
end)
for _, v1013 in v_u_224 do
	v1013.button.Activated:Connect(function()
		-- upvalues: (ref) v_u_470
		v_u_470()
	end)
end
local _ = {
	["open"] = v997,
	["isOpen"] = function() -- name: isOpen
		-- upvalues: (ref) v_u_137
		return v_u_137 ~= nil
	end,
	["refresh"] = function() -- name: refresh
		-- upvalues: (ref) v_u_470
		v_u_470()
	end
}