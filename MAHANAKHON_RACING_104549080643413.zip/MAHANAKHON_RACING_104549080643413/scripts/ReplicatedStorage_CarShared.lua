-- Path: ReplicatedStorage/CarShared
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_21 = {
	["TAG"] = "GTACar",
	["REMOTE_NAME"] = "CarRemote",
	["DEFAULT_CAR_SCALE"] = 1.1,
	["SEAT_DROP"] = 0.15,
	["DEFAULT_MAX_SPEED"] = 160,
	["ACCEL"] = 14,
	["ACCEL_TAPER"] = 2.2,
	["BRAKE_DECEL"] = 58,
	["REVERSE_MAX"] = 22,
	["REVERSE_ACCEL"] = 8,
	["STOPPED_SPEED"] = 0.5,
	["DRIVE_FORCE_PER_MASS"] = 400,
	["KMH_PER_STUD"] = 1.008,
	["MAX_STEER"] = 0.5934119456780721,
	["MIN_STEER"] = 0.08726646259971647,
	["STEER_FADE_SPEED"] = 120,
	["STEER_RATE"] = 3.2,
	["STEERING_WHEEL_TURN"] = 1.7453292519943295,
	["ALIGN_TORQUE_PER_MASS"] = 3000,
	["FLIP_UP_Y"] = 0.65,
	["TILT_EASE_UP_Y"] = 0.87,
	["TILT_EASE_KEEP"] = 0.5,
	["MOUNT_DISTANCE"] = 18,
	["EXIT_COLLISION_GROUP"] = "CarExiting",
	["SUSP_TRAVEL"] = 0.38,
	["SUSP_EXTEND"] = 0.3,
	["SUSP_STIFFNESS"] = 150,
	["SUSP_DAMPING"] = 11,
	["SUSP_PITCH"] = 0.009,
	["SUSP_ROLL"] = 0.0045,
	["LOWER_LEVELS"] = 4,
	["LOWER_STEP"] = 0.075,
	["lowerDrops"] = function(p1) -- name: lowerDrops
		-- upvalues: (copy) v_u_21
		local v2 = p1:GetAttribute("LowerLevel")
		local v3 = tonumber(v2)
		local v4
		if v3 and v3 == v3 then
			local v5 = v_u_21.LOWER_LEVELS
			v4 = math.clamp(v3, 0, v5)
		else
			v4 = nil
		end
		local v6 = v4 or 0
		local v7
		if p1:GetAttribute("LowerSplit") == true then
			local v8 = p1:GetAttribute("LowerFront")
			local v9 = tonumber(v8)
			local v10
			if v9 and v9 == v9 then
				local v11 = v_u_21.LOWER_LEVELS
				v10 = math.clamp(v9, 0, v11)
			else
				v10 = nil
			end
			v7 = v10 or v6
			local v12 = p1:GetAttribute("LowerRear")
			local v13 = tonumber(v12)
			local v14
			if v13 and v13 == v13 then
				local v15 = v_u_21.LOWER_LEVELS
				v14 = math.clamp(v13, 0, v15)
			else
				v14 = nil
			end
			v6 = v14 or v6
		else
			v7 = v6
		end
		local v16 = p1:GetAttribute("LowerMaxFront")
		if typeof(v16) ~= "number" then
			v16 = p1:GetAttribute("LowerMax")
		end
		local v17
		if typeof(v16) == "number" then
			v17 = v16 / v_u_21.LOWER_LEVELS
		else
			v17 = v_u_21.LOWER_STEP
		end
		local v18 = v7 * v17
		local v19 = p1:GetAttribute("LowerMaxRear")
		if typeof(v19) ~= "number" then
			v19 = p1:GetAttribute("LowerMax")
		end
		local v20
		if typeof(v19) == "number" then
			v20 = v19 / v_u_21.LOWER_LEVELS
		else
			v20 = v_u_21.LOWER_STEP
		end
		return v18, v6 * v20
	end,
	["IMPACT_MIN_SPEED"] = 18,
	["IMPACT_SPEED_DROP"] = 12,
	["IMPACT_WINDOW"] = 0.15,
	["SCRAPE_MIN_SPEED"] = 10,
	["DOOR_OPEN"] = 1.0821041362364843,
	["DOOR_TIME"] = 1.4,
	["GEARS"] = {
		0.18,
		0.32,
		0.47,
		0.62,
		0.78,
		1
	},
	["IDLE_RPM"] = 900,
	["REDLINE_RPM"] = 7000,
	["INDICATOR_MODES"] = {
		["Off"] = true,
		["Left"] = true,
		["Right"] = true,
		["Hazard"] = true
	},
	["BLINK_PERIOD"] = 0.7,
	["BLINK_ON_TIME"] = 0.38,
	["DEFAULT_SOUNDS"] = {
		["SoundEngine"] = "80317022777602",
		["SoundStart"] = "5830481291",
		["SoundHorn"] = "127513531122725",
		["SoundBlinker"] = "103115521237862"
	},
	["PAINT_GROUPS"] = {
		"Body",
		"Accent",
		"Rim",
		"Caliper"
	}
}
local v22 = {
	["Gloss"] = {
		["material"] = nil,
		["reflectance"] = 0.08,
		["material"] = Enum.Material.SmoothPlastic
	},
	["Matte"] = {
		["material"] = nil,
		["reflectance"] = 0,
		["material"] = Enum.Material.SmoothPlastic
	},
	["Chrome"] = {
		["material"] = nil,
		["reflectance"] = 0.55,
		["material"] = Enum.Material.SmoothPlastic
	}
}
v_u_21.PAINT_FINISHES = v22
v_u_21.CARBON_KEYS = {
	"Bonnet",
	"Boot",
	"Wing",
	"Aero",
	"Doors",
	"Mirrors",
	"Fenders",
	"Pillars",
	"Lip",
	"Skirts",
	"Diffuser"
}
v_u_21.CARBON_LOOK = {
	["color"] = nil,
	["material"] = nil,
	["reflectance"] = 0.04,
	["texture"] = "rbxassetid://133957869806231",
	["textureColor"] = nil,
	["studsPerTile"] = 0.05,
	["color"] = Color3.fromRGB(10, 10, 12),
	["material"] = Enum.Material.SmoothPlastic,
	["textureColor"] = Color3.fromRGB(190, 192, 198)
}
local v23 = {
	[0] = {
		["color"] = nil,
		["transparency"] = 0.8,
		["color"] = Color3.fromRGB(150, 170, 180)
	},
	[1] = {
		["color"] = nil,
		["transparency"] = 0.62,
		["color"] = Color3.fromRGB(70, 80, 88)
	},
	[2] = {
		["color"] = nil,
		["transparency"] = 0.46,
		["color"] = Color3.fromRGB(38, 43, 48)
	},
	[3] = {
		["color"] = nil,
		["transparency"] = 0.3,
		["color"] = Color3.fromRGB(14, 16, 19)
	}
}
v_u_21.TINTS = v23
v_u_21.WINDOW_REFLECTANCE = 0.12
v_u_21.EXHAUSTS = {
	["Stock"] = {
		["volume"] = 1,
		["pitch"] = 1,
		["rumble"] = 0,
		["distortion"] = 0,
		["pops"] = 0,
		["flames"] = false,
		["low"] = 0,
		["high"] = 0
	},
	["Sport"] = {
		["volume"] = 1.3,
		["pitch"] = 0.94,
		["rumble"] = 0.45,
		["distortion"] = 0.12,
		["pops"] = 0.55,
		["flames"] = false,
		["low"] = 5,
		["high"] = 0
	},
	["Carbon"] = {
		["volume"] = 1.4,
		["pitch"] = 0.97,
		["rumble"] = 0.3,
		["distortion"] = 0.22,
		["pops"] = 0.8,
		["flames"] = false,
		["low"] = 2,
		["high"] = 5
	},
	["Racing"] = {
		["volume"] = 1.6,
		["pitch"] = 0.88,
		["rumble"] = 0.75,
		["distortion"] = 0.32,
		["pops"] = 1,
		["flames"] = true,
		["low"] = 6,
		["high"] = 3
	}
}
v_u_21.DEFAULT_ENGINE_SET = "Civic"
v_u_21.ENGINE_MAX_DISTANCE = 250
local v24 = {
	["Civic"] = {
		["volume"] = 1,
		["idle"] = nil,
		["points"] = nil,
		["idle"] = {
			["rpm"] = 900,
			["id"] = "88978625724045",
			["gain"] = 2.7
		},
		["points"] = {
			{
				["rpm"] = 1000,
				["on"] = "121229774422345",
				["onGain"] = 3.8
			},
			{
				["rpm"] = 2000,
				["on"] = "110949190034405",
				["off"] = "107080119125188",
				["onGain"] = 4.8,
				["offGain"] = 5.2
			},
			{
				["rpm"] = 3000,
				["on"] = "97200282228576",
				["off"] = "114443335063073",
				["onGain"] = 3.3,
				["offGain"] = 6.3
			},
			{
				["rpm"] = 4000,
				["on"] = "138609984202209",
				["off"] = "73650621886444",
				["onGain"] = 2,
				["offGain"] = 3.6
			},
			{
				["rpm"] = 5000,
				["on"] = "99202351421083",
				["off"] = "113163772440412",
				["onGain"] = 3,
				["offGain"] = 3.9
			},
			{
				["rpm"] = 6000,
				["on"] = "92800481766556",
				["off"] = "93089179491335",
				["onGain"] = 2.5,
				["offGain"] = 1.9
			},
			{
				["rpm"] = 7000,
				["on"] = "101042878678368",
				["off"] = "91964795086726",
				["onGain"] = 2.4,
				["offGain"] = 2.2
			}
		}
	}
}
v_u_21.ENGINE_SETS = v24
function v_u_21.engineSet(p25) -- name: engineSet
	-- upvalues: (copy) v_u_21
	local v26 = p25:GetAttribute("EngineSet") or v_u_21.DEFAULT_ENGINE_SET
	return v_u_21.ENGINE_SETS[v26]
end
v_u_21.DRL_STYLES = {
	["Rainbow"] = true,
	["Solid"] = true,
	["Gradient"] = true,
	["Mode"] = true
}
local v_u_27 = require(script.Parent:WaitForChild("LightModes"))
function v_u_21.modeColor(p28, p29, p30, p31, p32) -- name: modeColor
	-- upvalues: (copy) v_u_21, (copy) v_u_27
	local v33
	if p28:GetAttribute("DRLSplit") == true and p30 == "Right" then
		v33 = p28:GetAttribute("DRLModeR")
	else
		v33 = p28:GetAttribute("DRLMode")
	end
	if p32 then
		p32 = p28:GetAttribute("DRLModeRear")
	end
	if typeof(p32) ~= "number" then
		p32 = v33
	end
	local v34 = p28:GetAttribute("DRLColor") or v_u_21.DRL_DEFAULT_COLOR
	return v_u_27.sample(p32 or 1, p29, p30, p31 or workspace:GetServerTimeNow(), p28:GetAttribute("DRLSpeed"), v34, p28:GetAttribute("DRLColor2") or v34)
end
v_u_21.DRL_DEFAULT_COLOR = Color3.fromRGB(70, 140, 255)
function v_u_21.lightColor(p35, p36, p37, p38) -- name: lightColor
	-- upvalues: (copy) v_u_21
	local v39 = p35:GetAttribute("DRLStyle") or "Rainbow"
	local v40 = p35:GetAttribute("DRLColor") or v_u_21.DRL_DEFAULT_COLOR
	local v41 = p35:GetAttribute("DRLColor2") or v40
	local v42 = p37 <= 1 and 0 or (p36 - 1) / (p37 - 1)
	if v39 == "Mode" then
		local v43 = v42 < 0.5 and "Left" or "Right"
		local v44 = v_u_21.modeColor
		local v45 = v42 - 0.5
		return v44(p35, math.abs(v45) * 2, v43) or v40:Lerp(Color3.new(0, 0, 0), 0.85)
	end
	if v39 == "Solid" then
		return v40
	end
	if v39 ~= "Gradient" then
		return Color3.fromHSV((v42 * 0.75 - p38 * 0.35) % 1, 0.9, 1)
	end
	local v46 = 2 * ((v42 * 0.5 + p38 * 0.5) % 1) - 1
	local v47 = 1 - math.abs(v46)
	return v40:Lerp(v41, v47 * v47 * (3 - 2 * v47))
end
v_u_21.SOUND_EXHAUST_POP = "140725059135838"
function v_u_21.carbonKeyOf(p48) -- name: carbonKeyOf
	local v49 = p48:GetAttribute("CarbonKey")
	if v49 then
		return v49
	end
	if p48:GetAttribute("PaintGroup") == "Body" then
		if p48.Name:sub(1, 7) == "Bonnet_" then
			return "Bonnet"
		end
		if p48.Name:sub(1, 5) == "Boot_" then
			return "Boot"
		end
	end
	return nil
end
function v_u_21.carbonKeysOf(p50) -- name: carbonKeysOf
	-- upvalues: (copy) v_u_21
	local v51 = {}
	for _, v52 in p50:GetDescendants() do
		if not v52:IsA("BasePart") then
			continue
		end
		local v53 = v_u_21.carbonKeyOf(v52)
		if not v53 then
			continue
		end
		v51[v53] = true
	end
	return v51
end
local v_u_54 = {
	"vitres",
	"terieur",
	"window",
	"windscreen"
}
function v_u_21.isWindow(p55) -- name: isWindow
	-- upvalues: (copy) v_u_54
	local v56 = p55.Name:lower()
	if not v56:find("vehglass", 1, true) then
		return false
	end
	for _, v57 in v_u_54 do
		if not v56:find(v57, 1, true) then
			continue
		end
		return true
	end
	return false
end
function v_u_21.maxSteer(p58) -- name: maxSteer
	-- upvalues: (copy) v_u_21
	local v59 = math.abs(p58) / v_u_21.STEER_FADE_SPEED
	local v60 = math.min(1, v59)
	return v_u_21.MAX_STEER + (v_u_21.MIN_STEER - v_u_21.MAX_STEER) * v60
end
function v_u_21.stepSpeed(p61, p62, p63, p64, p65, p66) -- name: stepSpeed
	-- upvalues: (copy) v_u_21
	local v67 = v_u_21.BRAKE_DECEL * (p66 or 1)
	if p62 <= 0 then
		if p62 >= 0 then
			return v_u_21.coast(p61, p64)
		end
		if v_u_21.STOPPED_SPEED < p61 then
			local v68 = p61 - v67 * p64
			return math.max(v68, 0)
		end
		local v69 = p61 - v_u_21.REVERSE_ACCEL * p64
		local v70 = -v_u_21.REVERSE_MAX
		return math.max(v69, v70)
	end
	if p61 < -v_u_21.STOPPED_SPEED then
		local v71 = p61 + v67 * p64
		return math.min(v71, 0)
	end
	local v72 = v_u_21.ACCEL * (p65 or 1)
	local v73 = p61 / p63
	local v74 = 1 - math.clamp(v73, 0, 1) ^ v_u_21.ACCEL_TAPER
	local v75 = p61 + v72 * math.max(0.08, v74) * p62 * p64
	return math.min(v75, p63)
end
function v_u_21.coast(p76, p77) -- name: coast
	local v78 = 1.2 + 0.00025 * p76 * p76
	if p76 > 0 then
		local v79 = p76 - v78 * p77
		return math.max(v79, 0)
	end
	if p76 >= 0 then
		return 0
	end
	local v80 = p76 + (v78 + 2) * p77
	return math.min(v80, 0)
end
function v_u_21.brake(p81, p82) -- name: brake
	-- upvalues: (copy) v_u_21
	if p81 > 0 then
		local v83 = p81 - v_u_21.BRAKE_DECEL * p82
		return math.max(v83, 0)
	else
		local v84 = p81 + v_u_21.BRAKE_DECEL * p82
		return math.min(v84, 0)
	end
end
function v_u_21.yawRate(p85, p86, p87) -- name: yawRate
	return (p85 == 0 or p86 == 0) and 0 or p85 * math.tan(p86) / p87
end
function v_u_21.rpm(p88, p89, p90) -- name: rpm
	-- upvalues: (copy) v_u_21
	local v91 = math.abs(p88) / math.max(p89, 1)
	if p88 >= -0.3 then
		local v92 = 0
		for v93, v94 in v_u_21.GEARS do
			if v91 <= v94 or v93 == #v_u_21.GEARS then
				local v95 = (v91 - v92 * 0.6) / (v94 - v92 * 0.6)
				local v96 = math.clamp(v95, 0, 1)
				local v97 = v_u_21.IDLE_RPM + (v_u_21.REDLINE_RPM - v_u_21.IDLE_RPM) * v96
				if v93 == 1 and (p90 or 0) > 0 then
					v97 = math.max(v97, 2200)
				end
				return v97, v93
			end
			v92 = v94
		end
		return v_u_21.IDLE_RPM, 1
	end
	local v98 = v_u_21.IDLE_RPM
	local v99 = v_u_21.REDLINE_RPM - v_u_21.IDLE_RPM
	local v100 = v91 * 4
	return v98 + v99 * math.min(1, v100), "R"
end
function v_u_21.toKmh(p101) -- name: toKmh
	-- upvalues: (copy) v_u_21
	return p101 * v_u_21.KMH_PER_STUD
end
function v_u_21.alpha(p102, p103) -- name: alpha
	local v104 = -p102 * p103
	return 1 - math.exp(v104)
end
function v_u_21.alignTarget(p105, p106, p107) -- name: alignTarget
	-- upvalues: (copy) v_u_21
	if p105.UpVector.Y < v_u_21.FLIP_UP_Y then
		return p106
	end
	local v108 = v_u_21.flatRotation(p105):Inverse() * p105.Rotation
	if p107 or p105.UpVector.Y < v_u_21.TILT_EASE_UP_Y then
		v108 = CFrame.identity:Lerp(v108, v_u_21.TILT_EASE_KEEP)
	end
	return p106 * v108
end
function v_u_21.flatRotation(p109) -- name: flatRotation
	local v110 = p109.LookVector
	local v111 = v110.X
	local v112 = v110.Z
	local v113 = Vector3.new(v111, 0, v112)
	if v113.Magnitude < 0.001 then
		local v114 = -p109.UpVector
		local v115 = v110.Y
		local v116 = v114 * math.sign(v115)
		local v117 = v116.X
		local v118 = v116.Z
		v113 = Vector3.new(v117, 0, v118)
	end
	return CFrame.lookAt(Vector3.new(0, 0, 0), v113.Unit)
end
function v_u_21.carFromSeat(p119) -- name: carFromSeat
	-- upvalues: (copy) v_u_21
	if not (p119 and p119:IsA("Seat") or p119 and p119:IsA("VehicleSeat")) then
		return nil
	end
	local v120 = p119:FindFirstAncestorWhichIsA("Model")
	while v120 and not v120:HasTag(v_u_21.TAG) do
		local v121 = v120.Parent
		if v121 then
			v120 = v120.Parent:FindFirstAncestorWhichIsA("Model")
		else
			v120 = v121
		end
	end
	return v120
end
return v_u_21