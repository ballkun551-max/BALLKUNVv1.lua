-- Path: ReplicatedStorage/LightModes
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = {
	["SPEED_LEVELS"] = 20,
	["DEFAULT_SPEED"] = 10,
	["WELCOME_TIME"] = 2.4
}
local v_u_2 = Color3.new(1, 1, 1)
local v_u_3 = Color3.new(0, 0, 0)
local v_u_4 = Color3.fromRGB(255, 140, 0)
local v_u_5 = {
	{
		["id"] = "Rainbow",
		["label"] = "Rainbow"
	},
	{
		["id"] = "Custom",
		["label"] = "My colour"
	},
	{
		["id"] = "Duo",
		["label"] = "Two colours"
	},
	{
		["id"] = "Ice",
		["label"] = "Ice",
		["colors"] = nil,
		["colors"] = { Color3.fromRGB(220, 245, 255), Color3.fromRGB(0, 220, 255), Color3.fromRGB(30, 90, 255) }
	},
	{
		["id"] = "Fire",
		["label"] = "Fire",
		["colors"] = nil,
		["colors"] = { Color3.fromRGB(255, 20, 0), Color3.fromRGB(255, 110, 0), Color3.fromRGB(255, 210, 40) }
	},
	{
		["id"] = "Neon",
		["label"] = "Neon",
		["colors"] = nil,
		["colors"] = { Color3.fromRGB(255, 40, 200), Color3.fromRGB(0, 240, 255), Color3.fromRGB(140, 40, 255) }
	},
	{
		["id"] = "Ocean",
		["label"] = "Ocean",
		["colors"] = nil,
		["colors"] = { Color3.fromRGB(0, 60, 255), Color3.fromRGB(0, 200, 200), Color3.fromRGB(80, 255, 220) }
	},
	{
		["id"] = "Sunset",
		["label"] = "Sunset",
		["colors"] = nil,
		["colors"] = { Color3.fromRGB(255, 120, 0), Color3.fromRGB(255, 40, 120), Color3.fromRGB(120, 30, 255) }
	},
	{
		["id"] = "Police",
		["label"] = "Police",
		["colors"] = nil,
		["colors"] = { Color3.fromRGB(255, 10, 20), Color3.fromRGB(20, 40, 255) }
	},
	{
		["id"] = "Toxic",
		["label"] = "Toxic",
		["colors"] = nil,
		["colors"] = { Color3.fromRGB(120, 255, 0), Color3.fromRGB(0, 255, 120), Color3.fromRGB(230, 255, 0) }
	},
	{
		["id"] = "Galaxy",
		["label"] = "Galaxy",
		["colors"] = nil,
		["colors"] = {
			Color3.fromRGB(60, 0, 255),
			Color3.fromRGB(200, 0, 255),
			Color3.fromRGB(0, 120, 255),
			Color3.fromRGB(255, 255, 255)
		}
	},
	{
		["id"] = "Candy",
		["label"] = "Candy",
		["colors"] = nil,
		["colors"] = { Color3.fromRGB(255, 90, 170), Color3.fromRGB(120, 200, 255), Color3.fromRGB(255, 240, 120) }
	},
	{
		["id"] = "Gold",
		["label"] = "Gold",
		["colors"] = nil,
		["colors"] = { Color3.fromRGB(255, 190, 40), Color3.fromRGB(255, 240, 180), Color3.fromRGB(255, 130, 0) }
	},
	{
		["id"] = "Lava",
		["label"] = "Lava",
		["colors"] = nil,
		["colors"] = { Color3.fromRGB(255, 0, 0), Color3.fromRGB(255, 60, 0), Color3.fromRGB(160, 0, 40) }
	},
	{
		["id"] = "Cyber",
		["label"] = "Cyber",
		["colors"] = nil,
		["colors"] = { Color3.fromRGB(0, 255, 230), Color3.fromRGB(255, 0, 150), Color3.fromRGB(255, 230, 0) }
	},
	{
		["id"] = "Mint",
		["label"] = "Mint",
		["colors"] = nil,
		["colors"] = { Color3.fromRGB(150, 255, 210), Color3.fromRGB(0, 230, 160), Color3.fromRGB(200, 255, 255) }
	},
	{
		["id"] = "Tricolor",
		["label"] = "Red white blue",
		["colors"] = nil,
		["colors"] = { Color3.fromRGB(255, 20, 40), Color3.fromRGB(255, 255, 255), Color3.fromRGB(20, 50, 255) }
	},
	{
		["id"] = "Red",
		["label"] = "Red",
		["colors"] = nil,
		["colors"] = { Color3.fromRGB(255, 10, 20) }
	},
	{
		["id"] = "Blue",
		["label"] = "Blue",
		["colors"] = nil,
		["colors"] = { Color3.fromRGB(20, 60, 255) }
	},
	{
		["id"] = "IceBlue",
		["label"] = "Ice blue",
		["colors"] = nil,
		["colors"] = { Color3.fromRGB(0, 220, 255) }
	},
	{
		["id"] = "Green",
		["label"] = "Green",
		["colors"] = nil,
		["colors"] = { Color3.fromRGB(20, 255, 60) }
	},
	{
		["id"] = "White",
		["label"] = "White",
		["colors"] = nil,
		["colors"] = { Color3.fromRGB(235, 242, 255) }
	},
	{
		["id"] = "Purple",
		["label"] = "Purple",
		["colors"] = nil,
		["colors"] = { Color3.fromRGB(150, 40, 255) }
	},
	{
		["id"] = "Pink",
		["label"] = "Pink",
		["colors"] = nil,
		["colors"] = { Color3.fromRGB(255, 50, 190) }
	},
	{
		["id"] = "Orange",
		["label"] = "Orange",
		["colors"] = nil,
		["colors"] = { Color3.fromRGB(255, 100, 0) }
	},
	{
		["id"] = "Yellow",
		["label"] = "Yellow",
		["colors"] = nil,
		["colors"] = { Color3.fromRGB(255, 225, 0) }
	},
	{
		["id"] = "Amber",
		["label"] = "Amber",
		["colors"] = nil,
		["colors"] = { Color3.fromRGB(255, 150, 0) }
	},
	{
		["id"] = "Lime",
		["label"] = "Lime",
		["colors"] = nil,
		["colors"] = { Color3.fromRGB(170, 255, 0) }
	},
	{
		["id"] = "Magenta",
		["label"] = "Magenta",
		["colors"] = nil,
		["colors"] = { Color3.fromRGB(255, 0, 255) }
	},
	{
		["id"] = "RedBlue",
		["label"] = "Red / blue",
		["colors"] = nil,
		["colors"] = { Color3.fromRGB(255, 10, 20), Color3.fromRGB(20, 60, 255) }
	},
	{
		["id"] = "BlueWhite",
		["label"] = "Blue / white",
		["colors"] = nil,
		["colors"] = { Color3.fromRGB(20, 80, 255), Color3.fromRGB(235, 242, 255) }
	},
	{
		["id"] = "PinkCyan",
		["label"] = "Pink / cyan",
		["colors"] = nil,
		["colors"] = { Color3.fromRGB(255, 50, 190), Color3.fromRGB(0, 230, 255) }
	},
	{
		["id"] = "PurpleGold",
		["label"] = "Purple / gold",
		["colors"] = nil,
		["colors"] = { Color3.fromRGB(140, 30, 255), Color3.fromRGB(255, 190, 40) }
	},
	{
		["id"] = "GreenBlue",
		["label"] = "Green / blue",
		["colors"] = nil,
		["colors"] = { Color3.fromRGB(20, 255, 90), Color3.fromRGB(20, 80, 255) }
	},
	{
		["id"] = "RedWhite",
		["label"] = "Red / white",
		["colors"] = nil,
		["colors"] = { Color3.fromRGB(255, 20, 30), Color3.fromRGB(255, 255, 255) }
	}
}
v_u_1.PALETTES = v_u_5
local v_u_216 = {
	{
		["id"] = "Flow",
		["label"] = "Flow",
		["dirs"] = true,
		["f"] = nil,
		["f"] = function(p6, _, _, p7) -- name: f
			return p6 * 0.6 - p7 * 0.5, 1
		end
	},
	{
		["id"] = "Wipe",
		["label"] = "Color wipe",
		["dirs"] = true,
		["f"] = nil,
		["f"] = function(p8, _, _, p9) -- name: f
			local v10 = math.floor(p9)
			if p8 > p9 % 1 then
				v10 = v10 - 1
			end
			return v10 * 0.2, 1
		end
	},
	{
		["id"] = "Comet",
		["label"] = "Comet",
		["dirs"] = true,
		["f"] = nil,
		["f"] = function(p11, _, _, p12) -- name: f
			local v13 = p12 % 1 * 1.35 - p11
			if v13 < 0 or v13 > 0.35 then
				return nil
			else
				return p12 * 0.15 + p11 * 0.3, (1 - v13 / 0.35) ^ 1.6
			end
		end
	},
	{
		["id"] = "Meteor",
		["label"] = "Meteor rain",
		["dirs"] = true,
		["f"] = nil,
		["f"] = function(p14, _, _, p15) -- name: f
			for v16 = 0, 2 do
				local v17 = (p15 + v16 / 3) % 1 * 1.25 - p14
				if v17 < 0 or v17 >= 0.22 then
					continue
				end
				return v16 / 3 + p15 * 0.1, (1 - v17 / 0.22) ^ 1.4
			end
			return nil
		end
	},
	{
		["id"] = "Fill",
		["label"] = "Fill & drain",
		["dirs"] = true,
		["f"] = nil,
		["f"] = function(p18, _, _, p19) -- name: f
			local v20 = 2 * (p19 * 0.5 % 1) - 1
			local v21 = 1 - math.abs(v20)
			local v22 = math.clamp(v21, 0, 1)
			if v22 * v22 * (3 - 2 * v22) * 1.05 < p18 then
				return nil
			end
			local v23 = p18 * 0.5
			local v24 = p19 * 0.5
			return v23 + math.floor(v24) * 0.25, 1
		end
	},
	{
		["id"] = "Theater",
		["label"] = "Theater chase",
		["dirs"] = true,
		["f"] = nil,
		["f"] = function(p25, _, _, p26) -- name: f
			local v27 = p25 * 9 - p26 * 3
			if math.floor(v27) % 2 == 0 then
				return math.floor(p26) * 0.15 + p25 * 0.2, 1
			else
				return nil
			end
		end
	},
	{
		["id"] = "Wave",
		["label"] = "Wave",
		["dirs"] = true,
		["f"] = nil,
		["f"] = function(p28, _, _, p29) -- name: f
			local v30 = 6.283185307179586 * (p28 * 1.4 - p29)
			local v31 = math.sin(v30) * 0.5 + 0.5
			return p28 * 0.4 - p29 * 0.2, v31 * v31
		end
	},
	{
		["id"] = "Twin",
		["label"] = "Twin comets",
		["dirs"] = true,
		["f"] = nil,
		["f"] = function(p32, _, _, p33) -- name: f
			local v34 = p33 % 1 * 1.1
			for v35, v36 in { v34, 1.1 - v34 } do
				local v37 = v36 - p32
				local v38 = math.abs(v37)
				if v38 >= 0.14 then
					continue
				end
				return v35 * 0.5 + p33 * 0.1, (1 - v38 / 0.14) ^ 1.5
			end
			return nil
		end
	},
	{
		["id"] = "Dots",
		["label"] = "Running dots",
		["dirs"] = true,
		["f"] = nil,
		["f"] = function(p39, _, _, p40) -- name: f
			local v41 = (p39 * 3 - p40) % 1
			if v41 > 0.22 then
				return nil
			end
			local v42 = p39 * 3 - p40
			return math.floor(v42) * 0.33, 1 - v41 / 0.22 * 0.5
		end
	},
	{
		["id"] = "Ripple",
		["label"] = "Ripple",
		["dirs"] = true,
		["f"] = nil,
		["f"] = function(p43, _, _, p44) -- name: f
			local v45 = (p44 + 0) % 1
			local v46 = p43 - v45 * 1.2
			local v47 = math.abs(v46)
			local v48 = 1 - v45
			local v49 = 1 - v47 / 0.12
			local v50 = v48 * math.max(0, v49)
			local v51 = math.max(0, v50)
			local v52 = (p44 + 0.5) % 1
			local v53 = p43 - v52 * 1.2
			local v54 = math.abs(v53)
			local v55 = 1 - v52
			local v56 = 1 - v54 / 0.12
			local v57 = v55 * math.max(0, v56)
			local v58 = math.max(v51, v57)
			if v58 < 0.05 then
				return nil
			else
				return p44 * 0.2 + p43 * 0.2, v58
			end
		end
	},
	{
		["id"] = "Blocks",
		["label"] = "Color blocks",
		["dirs"] = true,
		["f"] = nil,
		["f"] = function(p59, _, _, p60) -- name: f
			local v61 = p59 * 4 - p60 * 2
			return math.floor(v61) * 0.25, 1
		end
	},
	{
		["id"] = "Stack",
		["label"] = "Stack",
		["dirs"] = true,
		["f"] = nil,
		["f"] = function(p62, _, _, p63) -- name: f
			local v64 = p63 * 8 % 8
			local v65 = math.floor(v64)
			local v66 = 1 - v65 / 8
			if v66 - 0.01 <= p62 then
				return (1 - p62) * 0.6 + math.floor(p63) * 0.2, 1
			else
				local v67 = p62 - v64 % 1 * v66
				if math.abs(v67) < 0.06 then
					return v65 / 8, 1
				else
					return nil
				end
			end
		end
	},
	{
		["id"] = "Bounce",
		["label"] = "Bouncing ball",
		["dirs"] = true,
		["f"] = nil,
		["f"] = function(p68, _, _, p69) -- name: f
			local v70 = 3.141592653589793 * p69
			local v71 = math.sin(v70)
			local v72 = p68 - math.abs(v71)
			local v73 = math.abs(v72)
			if v73 > 0.09 then
				return nil
			else
				return math.floor(p69) * 0.25, (1 - v73 / 0.09) ^ 1.2
			end
		end
	},
	{
		["id"] = "Rain",
		["label"] = "Rain",
		["dirs"] = true,
		["f"] = nil,
		["f"] = function(p74, _, p75, p76) -- name: f
			for v77 = 0, 3 do
				local v78 = p75 == "Left" and 1 or 2
				local v79 = v77 * 12.9898 + v78 * 78.233
				local v80 = math.sin(v79) * 43758.5453 % 1
				local v81 = (p76 * (0.8 + v80 * 0.6) + v80) % 1 * 1.2 - p74
				if v81 < 0 or v81 >= 0.12 then
					continue
				end
				return v77 * 0.25 + v80 * 0.1, (1 - v81 / 0.12) ^ 2
			end
			return nil
		end
	},
	{
		["id"] = "Zigzag",
		["label"] = "Zigzag",
		["dirs"] = true,
		["f"] = nil,
		["f"] = function(p82, _, _, p83) -- name: f
			local v84 = p82 * 12
			local v85 = math.floor(v84)
			local v86 = p83 * 4
			local v87
			if (v85 + math.floor(v86)) % 2 == 0 then
				v87 = v85 / 12 * 0.5 + p83 * 0.05
			else
				v87 = nil
			end
			return v87, 1
		end
	},
	{
		["id"] = "ChaseFill",
		["label"] = "Chase then fill",
		["dirs"] = true,
		["f"] = nil,
		["f"] = function(p88, _, _, p89) -- name: f
			local v90 = p89 % 1
			if v90 < 0.5 then
				local v91 = v90 * 2 * 1.2 - p88
				if v91 >= 0 and v91 < 0.18 then
					return p88 * 0.3, 1 - v91 / 0.18
				else
					return nil
				end
			elseif (v90 - 0.5) * 2 < p88 then
				return nil
			else
				return p88 * 0.3 + math.floor(p89) * 0.2, 1
			end
		end
	},
	{
		["id"] = "Spin",
		["label"] = "Color spin",
		["dirs"] = true,
		["f"] = nil,
		["f"] = function(p92, _, _, p93) -- name: f
			return p92 * 1 - p93 * 0.6, 1
		end
	},
	{
		["id"] = "SweepFlash",
		["label"] = "Sweep and flash",
		["dirs"] = true,
		["f"] = nil,
		["f"] = function(p94, _, _, p95) -- name: f
			local v96 = p95 % 1
			if v96 < 0.55 then
				local v97
				if p94 <= v96 / 0.5 then
					v97 = math.floor(p95) * 0.27
				else
					v97 = nil
				end
				return v97, 1
			elseif (v96 - 0.55) / 0.45 * 4 % 1 > 0.5 then
				return nil
			else
				return math.floor(p95) * 0.27, 1
			end
		end
	},
	{
		["id"] = "Scanner",
		["label"] = "Scanner",
		["dirs"] = false,
		["f"] = nil,
		["f"] = function(_, p98, p99, p100) -- name: f
			local v101
			if p99 == "Left" then
				v101 = 0.5 - p98 * 0.5
			else
				v101 = 0.5 + p98 * 0.5
			end
			local v102 = 2 * (p100 * 0.5 % 1) - 1
			local v103 = 1 - math.abs(v102)
			local v104 = v101 - v103
			local v105 = math.abs(v104)
			if v105 > 0.13 then
				return nil
			else
				return v103 * 0.5, (1 - v105 / 0.13) ^ 1.5
			end
		end
	},
	{
		["id"] = "Breath",
		["label"] = "Breathe",
		["dirs"] = false,
		["f"] = nil,
		["f"] = function(p106, _, _, p107) -- name: f
			local v108 = 3.141592653589793 * (p107 % 1)
			local v109 = math.sin(v108)
			return math.floor(p107) * 0.17 + p106 * 0.1, v109 * 0.94 * v109 + 0.06
		end
	},
	{
		["id"] = "Strobe",
		["label"] = "Strobe",
		["dirs"] = false,
		["f"] = nil,
		["f"] = function(_, _, _, p110) -- name: f
			local v111 = p110 * 2
			if v111 % 1 > 0.18 then
				return nil
			else
				return math.floor(v111) * 0.13, 1
			end
		end
	},
	{
		["id"] = "Twinkle",
		["label"] = "Twinkle",
		["dirs"] = false,
		["f"] = nil,
		["f"] = function(p112, p113, p114, p115) -- name: f
			local v116 = p113 * 24
			local v117 = math.floor(v116) + (p114 == "Left" and 100 or 0)
			local v118 = p115 * 3
			local v119 = math.floor(v118)
			local v120 = v117 * 12.9898 + v119 * 78.233
			local v121 = math.sin(v120) * 43758.5453 % 1
			if v121 < 0.55 then
				return p112 * 0.3 + p115 * 0.05, 0.12
			end
			local v122 = p115 * 3 % 1
			return v121 * 3, (1 - v122) ^ 0.7
		end
	},
	{
		["id"] = "Police",
		["label"] = "Alternate",
		["dirs"] = false,
		["f"] = nil,
		["f"] = function(_, _, p123, p124) -- name: f
			local v125 = p124 % 1
			if v125 < 0.5 == (p123 == "Left") then
				if v125 % 0.5 * 6 % 1 > 0.55 then
					return nil
				else
					return p123 == "Left" and 0 or 0.5, 1
				end
			else
				return nil
			end
		end
	},
	{
		["id"] = "Heartbeat",
		["label"] = "Heartbeat",
		["dirs"] = false,
		["f"] = nil,
		["f"] = function(p126, _, _, p127) -- name: f
			local v128 = p127 % 1
			local v129 = -((v128 - 0.1) / 0.05) ^ 2
			local v130 = math.exp(v129)
			local v131 = -((v128 - 0.32) / 0.06) ^ 2
			local v132 = math.exp(v131) * 0.8
			local v133 = math.max(v130, v132)
			return math.floor(p127) * 0.2 + p126 * 0.15, v133 * 0.95 + 0.05
		end
	},
	{
		["id"] = "Fire",
		["label"] = "Flicker",
		["dirs"] = false,
		["f"] = nil,
		["f"] = function(p134, p135, p136, p137) -- name: f
			local v138 = p135 * 24
			local v139 = math.floor(v138) + (p136 == "Left" and 50 or 0)
			local v140 = p137 * 8
			local v141 = math.floor(v140)
			local v142 = v139 * 12.9898 + v141 * 78.233
			local v143 = math.sin(v142) * 43758.5453 % 1
			local v144 = p137 * 8
			local v145 = math.floor(v144) + 1
			local v146 = v139 * 12.9898 + v145 * 78.233
			local v147 = v143 + (math.sin(v146) * 43758.5453 % 1 - v143) * (p137 * 8 % 1)
			return v147 * 0.35 + p134 * 0.1, 0.35 + 0.65 * v147
		end
	},
	{
		["id"] = "Sparkle",
		["label"] = "Sparkle",
		["dirs"] = false,
		["f"] = nil,
		["f"] = function(p148, p149, p150, p151) -- name: f
			local v152 = p149 * 24
			local v153 = math.floor(v152) + (p150 == "Left" and 70 or 0)
			local v154 = p151 * 6
			local v155 = math.floor(v154)
			local v156 = v153 * 12.9898 + v155 * 78.233
			if math.sin(v156) * 43758.5453 % 1 > 0.85 then
				return -1, 1
			else
				return p148 * 0.3 - p151 * 0.1, 0.45
			end
		end
	},
	{
		["id"] = "Cycle",
		["label"] = "Color cycle",
		["dirs"] = false,
		["f"] = nil,
		["f"] = function(_, _, _, p157) -- name: f
			return p157 * 0.25, 1
		end
	},
	{
		["id"] = "Glitch",
		["label"] = "Glitch",
		["dirs"] = false,
		["f"] = nil,
		["f"] = function(_, p158, p159, p160) -- name: f
			local v161 = p158 * 6
			local v162 = math.floor(v161) + (p159 == "Left" and 20 or 0)
			local v163 = p160 * 5
			local v164 = math.floor(v163)
			local v165 = v162 * 12.9898 + v164 * 78.233
			local v166 = math.sin(v165) * 43758.5453 % 1
			if v166 < 0.3 then
				return nil
			else
				local v167 = (v162 + 7) * 12.9898 + v164 * 78.233
				local v168 = math.sin(v167) * 43758.5453 % 1
				if v166 > 0.85 then
					return v168, 1
				else
					return v168, 0.7
				end
			end
		end
	},
	{
		["id"] = "Lightning",
		["label"] = "Lightning",
		["dirs"] = false,
		["f"] = nil,
		["f"] = function(p169, _, _, p170) -- name: f
			local v171 = p170 * 4
			local v172 = math.floor(v171)
			local v173 = p170 * 4 % 1
			local v174 = v172 * 12.9898 + 234.699
			if math.sin(v174) * 43758.5453 % 1 < 0.6 or v173 > 0.3 then
				return p169 * 0.2 + p170 * 0.05, 0.1
			else
				return -1, 1 - v173 / 0.3 * 0.4
			end
		end
	},
	{
		["id"] = "Triple",
		["label"] = "Triple flash",
		["dirs"] = false,
		["f"] = nil,
		["f"] = function(_, _, _, p175) -- name: f
			local v176 = p175 % 1 * 8
			if v176 >= 6 or v176 % 2 > 1 then
				return nil
			else
				return math.floor(p175) * 0.21, 1
			end
		end
	},
	{
		["id"] = "Halves",
		["label"] = "Half and half",
		["dirs"] = false,
		["f"] = nil,
		["f"] = function(p177, _, _, p178) -- name: f
			local v179 = math.floor(p178) % 2
			return ((p177 < 0.5 and 0 or 1) + v179) % 2 * 0.5, 1
		end
	},
	{
		["id"] = "Pulse",
		["label"] = "Gradient pulse",
		["dirs"] = false,
		["f"] = nil,
		["f"] = function(p180, _, _, p181) -- name: f
			local v182 = 6.283185307179586 * p181
			local v183 = math.cos(v182) * 0.5 + 0.5
			return p180 * 0.8 + p181 * 0.1, v183 * 0.85 + 0.15
		end
	},
	{
		["id"] = "Knight",
		["label"] = "Twin scanners",
		["dirs"] = false,
		["f"] = nil,
		["f"] = function(_, p184, p185, p186) -- name: f
			local v187
			if p185 == "Left" then
				v187 = 0.5 - p184 * 0.5
			else
				v187 = 0.5 + p184 * 0.5
			end
			local v188 = 2 * (p186 * 0.5 % 1) - 1
			local v189 = (1 - math.abs(v188)) * 0.5
			for v190, v191 in { v189, 1 - v189 } do
				local v192 = v187 - v191
				local v193 = math.abs(v192)
				if v193 >= 0.08 then
					continue
				end
				return v190 * 0.5, (1 - v193 / 0.08) ^ 1.5
			end
			return nil
		end
	},
	{
		["id"] = "PoliceStrobe",
		["label"] = "Double strobe",
		["dirs"] = false,
		["f"] = nil,
		["f"] = function(_, _, p194, p195) -- name: f
			local v196 = p195 % 1 * 8
			local v197 = math.floor(v196)
			if v197 < 4 == (p194 == "Left") and v197 % 2 ~= 1 then
				return p194 == "Left" and 0 or 0.5, 1
			else
				return nil
			end
		end
	},
	{
		["id"] = "Countdown",
		["label"] = "Countdown",
		["dirs"] = false,
		["f"] = nil,
		["f"] = function(p198, _, _, p199) -- name: f
			local v200 = p199 % 1 * 6
			local v201 = 1 - math.floor(v200) / 5
			if v201 < p198 then
				return nil
			else
				return (1 - v201) * 0.6, 1
			end
		end
	},
	{
		["id"] = "Candle",
		["label"] = "Ember",
		["dirs"] = false,
		["f"] = nil,
		["f"] = function(_, p202, p203, p204) -- name: f
			local v205 = p202 * 12
			local v206 = math.floor(v205) + (p203 == "Left" and 30 or 0)
			local v207 = p204 * 3
			local v208 = math.floor(v207)
			local v209 = v206 * 12.9898 + v208 * 78.233
			local v210 = 0.5 * (math.sin(v209) * 43758.5453 % 1)
			local v211 = v206 + 1
			local v212 = p204 * 7
			local v213 = math.floor(v212)
			local v214 = v211 * 12.9898 + v213 * 78.233
			local v215 = v210 + 0.5 * (math.sin(v214) * 43758.5453 % 1)
			return 0.05 + v215 * 0.25, 0.25 + 0.75 * v215 * v215
		end
	}
}
v_u_1.EFFECTS = v_u_216
v_u_1.RECOMMENDED = {}
local v_u_217 = {
	{
		["id"] = "Out",
		["label"] = "outward"
	},
	{
		["id"] = "In",
		["label"] = "inward"
	},
	{
		["id"] = "Across",
		["label"] = "across"
	},
	{
		["id"] = "Bounce",
		["label"] = "bounce"
	}
}
local v218 = {}
local v_u_219 = {}
local function v_u_235(p220, p221, p222, p223) -- name: paletteColor
	if p220.id == "Rainbow" then
		return Color3.fromHSV(p221 % 1, 0.92, 1)
	end
	if p220.id == "Custom" then
		return p222
	end
	if p220.id == "Duo" then
		local v224 = 2 * (p221 % 1) - 1
		local v225 = 1 - math.abs(v224)
		local v226 = math.clamp(v225, 0, 1)
		return p222:Lerp(p223, v226 * v226 * (3 - 2 * v226))
	end
	local v227 = p220.colors
	local v228 = #v227
	local v229 = p221 % 1 * v228
	local v230 = math.floor(v229)
	local v231 = v227[v230 % v228 + 1]
	local v232 = v227[(v230 + 1) % v228 + 1]
	local v233 = v229 - v230
	local v234 = math.clamp(v233, 0, 1)
	return v231:Lerp(v232, v234 * v234 * (3 - 2 * v234))
end
for _, v236 in {
	{
		"Rainbow Flow",
		"Flow",
		"Out",
		"Rainbow",
		9
	},
	{
		"Ice Comet",
		"Comet",
		"Out",
		"IceBlue",
		11
	},
	{
		"Police Scanner",
		"Knight",
		"-",
		"RedBlue",
		12
	},
	{
		"Neon Meteor",
		"Meteor",
		"Out",
		"Neon",
		10
	},
	{
		"Galaxy Stack",
		"Stack",
		"Out",
		"Galaxy",
		12
	},
	{
		"Cyber Twins",
		"Twin",
		"Out",
		"Cyber",
		11
	},
	{
		"Ocean Ripple",
		"Ripple",
		"Out",
		"Ocean",
		9
	},
	{
		"Sunset Wave",
		"Wave",
		"Out",
		"Sunset",
		8
	},
	{
		"Ice Wipe",
		"Wipe",
		"Out",
		"Ice",
		10
	},
	{
		"Knight Rider",
		"Scanner",
		"-",
		"Red",
		12
	},
	{
		"Rainbow Comet",
		"Comet",
		"Bounce",
		"Rainbow",
		10
	},
	{
		"Candy Dots",
		"Dots",
		"Across",
		"Candy",
		9
	},
	{
		"Double Strobe",
		"PoliceStrobe",
		"-",
		"RedBlue",
		13
	},
	{
		"Fire Flicker",
		"Fire",
		"-",
		"Fire",
		10
	},
	{
		"Purple Gold Spin",
		"Spin",
		"Out",
		"PurpleGold",
		9
	},
	{
		"Pink Cyan Zigzag",
		"Zigzag",
		"Out",
		"PinkCyan",
		8
	},
	{
		"Galaxy Lightning",
		"Lightning",
		"-",
		"Galaxy",
		10
	},
	{
		"Ice Sparkle",
		"Sparkle",
		"-",
		"Ice",
		10
	},
	{
		"Lava Heartbeat",
		"Heartbeat",
		"-",
		"Lava",
		8
	},
	{
		"Toxic Rain",
		"Rain",
		"Out",
		"Toxic",
		10
	},
	{
		"White Sweep Flash",
		"SweepFlash",
		"Out",
		"White",
		10
	},
	{
		"Amber Chase",
		"ChaseFill",
		"Out",
		"Amber",
		11
	},
	{
		"Rainbow Breathe",
		"Breath",
		"-",
		"Rainbow",
		7
	},
	{
		"Cyber Glitch",
		"Glitch",
		"-",
		"Cyber",
		10
	},
	{
		"Blue White Theater",
		"Theater",
		"Across",
		"BlueWhite",
		9
	},
	{
		"Rainbow Blocks",
		"Blocks",
		"Out",
		"Rainbow",
		8
	},
	{
		"Gold Ember",
		"Candle",
		"-",
		"Gold",
		9
	},
	{
		"My Color Comet",
		"Comet",
		"Out",
		"Custom",
		10
	}
} do
	local v239
	if v236[3] == "-" then
		v239 = 0
	else
		local v238 = v236[3]
		for v239, v240 in v_u_217 do
			if v240.id ~= v238 then
				continue
			end
		end
		error("LightModes: no " .. tostring(v238))
		v239 = nil
	end
	local v241 = v236[2]
	for v244, v243 in v_u_216 do
		if v243.id ~= v241 then
			continue
		end
	end
	error("LightModes: no " .. tostring(v241))
	local v244 = nil
	local v245 = v236[4]
	for v248, v247 in v_u_5 do
		if v247.id ~= v245 then
			continue
		end
	end
	error("LightModes: no " .. tostring(v245))
	local v248 = nil
	local v249 = v244 .. "/" .. v239 .. "/" .. v248
	if not v218[v249] then
		v218[v249] = true
		table.insert(v_u_219, {
			["effect"] = v244,
			["dir"] = v239,
			["palette"] = v248
		})
	end
	local v250 = v_u_1.RECOMMENDED
	local v251 = {
		["name"] = v236[1],
		["mode"] = #v_u_219,
		["speed"] = v236[5]
	}
	table.insert(v250, v251)
end
for v252 = 1, #v_u_5 do
	for v253, v254 in v_u_216 do
		if v254.dirs then
			for v255 = 1, #v_u_217 do
				local v256 = v253 .. "/" .. v255 .. "/" .. v252
				if v218[v256] then
					continue
				end
				v218[v256] = true
				table.insert(v_u_219, {
					["effect"] = v253,
					["dir"] = v255,
					["palette"] = v252
				})
			end
		else
			local v257 = v253 .. "/" .. 0 .. "/" .. v252
			if v218[v257] then
				continue
			end
			v218[v257] = true
			table.insert(v_u_219, {
				["effect"] = nil,
				["dir"] = 0,
				["palette"] = nil,
				["effect"] = v253,
				["palette"] = v252
			})
		end
	end
end
v_u_1.MODES = v_u_219
v_u_1.COUNT = #v_u_219
function v_u_1.clampMode(p258) -- name: clampMode
	-- upvalues: (copy) v_u_1
	local v259 = tonumber(p258) or 1
	local v260 = math.floor(v259)
	local v261 = v_u_1.COUNT
	return math.clamp(v260, 1, v261)
end
local v_u_262 = {}
for _, v263 in v_u_1.RECOMMENDED do
	v_u_262[v263.mode] = v263.name
end
function v_u_1.name(p264) -- name: name
	-- upvalues: (copy) v_u_1, (copy) v_u_262, (copy) v_u_219, (copy) v_u_216, (copy) v_u_217, (copy) v_u_5
	local v265 = v_u_1.clampMode(p264)
	if v_u_262[v265] then
		return "\226\152\133 " .. v_u_262[v265]
	end
	local v266 = v_u_219[v265]
	local v267 = v_u_216[v266.effect].label
	if v266.dir > 0 then
		v267 = v267 .. " " .. v_u_217[v266.dir].label
	end
	return v267 .. " \194\183 " .. v_u_5[v266.palette].label
end
function v_u_1.rate(p268) -- name: rate
	-- upvalues: (copy) v_u_1
	local v269 = tonumber(p268) or v_u_1.DEFAULT_SPEED
	local v270 = v_u_1.SPEED_LEVELS
	return 0.22 * 1.17 ^ (math.clamp(v269, 1, v270) - 1)
end
local function v_u_290(p271, p272, p273, p274, p275, p276, p277) -- name: sampleSharp
	-- upvalues: (copy) v_u_219, (copy) v_u_1, (copy) v_u_216, (copy) v_u_2, (copy) v_u_235, (copy) v_u_5, (copy) v_u_3
	local v278 = v_u_219[v_u_1.clampMode(p271)]
	local v279 = v_u_216[v278.effect]
	local v280 = p276 or Color3.fromRGB(70, 140, 255)
	local v281 = p277 or v280
	local v282
	if v278.dir == 2 then
		v282 = 1 - p272
	elseif v278.dir == 3 then
		if p273 == "Left" then
			v282 = 0.5 - p272 * 0.5
		else
			v282 = 0.5 + p272 * 0.5
		end
	else
		v282 = p272
	end
	local v283 = p274 * v_u_1.rate(p275)
	if v278.dir == 4 then
		local v284 = v283 * 0.5
		local v285 = math.floor(v284)
		local v286 = 2 * (v283 * 0.5 % 1) - 1
		v283 = v285 + (1 - math.abs(v286))
	end
	local v287, v288 = v279.f(v282, p272, p273, v283)
	if v287 == nil or (v288 == nil or v288 < 0.04) then
		return nil
	end
	local v289
	if v287 == -1 then
		v289 = v_u_2
	else
		v289 = v_u_235(v_u_5[v278.palette], v287, v280, v281)
	end
	return v289:Lerp(v_u_3, 1 - math.clamp(v288, 0, 1))
end
function v_u_1.welcome(p291, p292) -- name: welcome
	-- upvalues: (copy) v_u_1, (copy) v_u_4, (copy) v_u_2
	if p292 < 0 or v_u_1.WELCOME_TIME < p292 then
		return nil
	elseif p292 < 0.7 then
		if p291 <= p292 / 0.6 then
			return v_u_4
		else
			return nil
		end
	elseif p292 < 1.1 then
		return v_u_4
	elseif p292 < 1.8 then
		if p291 <= (p292 - 1.1) / 0.6 then
			return v_u_2
		else
			return v_u_4
		end
	else
		return v_u_2
	end
end
function v_u_1.sample(p293, p294, p295, p296, p297, p298, p299) -- name: sample
	-- upvalues: (copy) v_u_290
	local v300 = 0
	local v301 = 0
	local v302 = 0
	for _, v303 in {
		{ -0.035, 0.25 },
		{ 0, 0.5 },
		{ 0.035, 0.25 }
	} do
		local v304 = v_u_290
		local v305 = p294 + v303[1]
		local v306 = v304(p293, math.clamp(v305, 0, 1), p295, p296, p297, p298, p299)
		if not v306 then
			continue
		end
		v300 = v300 + v306.R * v303[2]
		v301 = v301 + v306.G * v303[2]
		v302 = v302 + v306.B * v303[2]
	end
	if v300 + v301 + v302 < 0.04 then
		return nil
	else
		return Color3.new(v300, v301, v302)
	end
end
return v_u_1