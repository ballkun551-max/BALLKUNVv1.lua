-- Path: Players/ygggggg55551/PlayerScripts/PCX160Client/Visuals
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = game:GetService("Players")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("SoundService")
local v_u_4 = game:GetService("AssetService")
local v_u_5 = require(v2:WaitForChild("PCX160Shared"))
local v_u_6 = require(v2:WaitForChild("VehicleFx"))
local v_u_7 = require(v2:WaitForChild("LightModes"))
local v_u_8 = Color3.fromRGB(200, 200, 200)
local v_u_9 = Color3.fromRGB(235, 242, 255)
local v_u_10 = Color3.fromRGB(205, 210, 218)
local v_u_11 = Color3.fromRGB(214, 218, 224)
local v_u_12 = Color3.fromRGB(26, 14, 0)
local v_u_13 = Color3.fromRGB(200, 0, 0)
local v_u_14 = Color3.fromRGB(255, 45, 45)
local v_u_15 = Color3.fromRGB(235, 240, 255)
local v_u_16 = Color3.fromRGB(235, 240, 255)
local v_u_17 = Color3.fromRGB(255, 20, 20)
local function v_u_20(p18) -- name: makeSmoke
	local v19 = Instance.new("ParticleEmitter")
	v19.Name = "PCX160_ExhaustSmoke"
	v19.Texture = "rbxasset://textures/particles/smoke_main.dds"
	v19.EmissionDirection = Enum.NormalId.Back
	v19.Color = ColorSequence.new(Color3.fromRGB(215, 215, 215), Color3.fromRGB(180, 180, 180))
	v19.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.82), NumberSequenceKeypoint.new(0.3, 0.86), NumberSequenceKeypoint.new(1, 1) })
	v19.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.25), NumberSequenceKeypoint.new(1, 1.6) })
	v19.Lifetime = NumberRange.new(0.8, 1.5)
	v19.Speed = NumberRange.new(1.5, 3)
	v19.SpreadAngle = Vector2.new(12, 12)
	v19.Acceleration = Vector3.new(0, 0.8, 0)
	v19.Drag = 1.5
	v19.RotSpeed = NumberRange.new(-40, 40)
	v19.Rotation = NumberRange.new(0, 360)
	v19.LightInfluence = 1
	v19.Rate = 0
	v19.Parent = p18
	return v19
end
local v_u_21 = {}
v_u_21.__index = v_u_21
local function v_u_26(p22, p23) -- name: anyAccOn
	for v25 in p23:gmatch("[^,%s]+") do
		if v25:sub(1, 7) ~= "Carbon_" then
			local v25 = "Acc_" .. v25
		end
		if p22:GetAttribute(v25) ~= true then
			continue
		end
		return true
	end
	return false
end
local v_u_27 = false
local function v_u_31(p28, p29, p30) -- name: rainbowColor
	return Color3.fromHSV((0.15 + (p28 - 1) * p30 - p29) % 1, 0.9, 1)
end
function v_u_21.new(p32) -- name: new
	-- upvalues: (copy) v_u_21, (copy) v_u_5, (copy) v_u_20, (copy) v_u_15
	local v33 = p32:WaitForChild("Chassis", 10)
	local v34 = p32:WaitForChild("VehicleSeat", 10)
	local v35 = p32:WaitForChild("SteerRoot", 10)
	if not (v33 and (v34 and v35)) then
		warn("PCX160: incomplete bike, skipping visuals:", p32:GetFullName())
		return nil
	end
	local v36 = v_u_21
	local v37 = setmetatable({}, v36)
	v37.model = p32
	v37.chassis = v33
	v37.seat = v34
	v37.steerMotor = v33:FindFirstChild("SteerMotor")
	v37.rearMotor = v33:FindFirstChild("RearWheelMotor")
	v37.frontMotor = v35:FindFirstChild("FrontWheelMotor")
	v37.gripRight = v35:FindFirstChild("GripRight")
	local v38 = v37.gripRight
	if v38 then
		v38 = v37.gripRight.CFrame
	end
	v37.gripRightBase = v38
	local v39 = p32:GetAttribute("RiderGripTilt")
	v37.gripTilt = typeof(v39) ~= "number" and 0 or math.rad(v39)
	local v40 = v33:FindFirstChild("Headlight")
	if v40 then
		v40 = v33.Headlight:FindFirstChild("HeadlightBeam")
	end
	v37.headlight = v40
	local v41 = v33:FindFirstChild("Taillight")
	if v41 then
		v41 = v33.Taillight:FindFirstChild("TaillightGlow")
	end
	v37.taillight = v41
	local v42 = v33:FindFirstChild("DRLGlowPoint")
	if v42 then
		v42 = v33.DRLGlowPoint:FindFirstChild("DRLGlow")
	end
	v37.drlGlow = v42
	v37.frontRadius = p32:GetAttribute("FrontWheelRadius") or 1
	v37.rearRadius = p32:GetAttribute("RearWheelRadius") or 1
	v37.frontAngle = 0
	v37.rearAngle = 0
	v37.frontSuspension = v35:FindFirstChild("FrontSuspensionMotor")
	v37.rearSuspension = v33:FindFirstChild("RearSuspensionMotor")
	v37.frontHub = v33:FindFirstChild("FrontWheelCenter")
	v37.rearHub = v33:FindFirstChild("RearWheelCenter")
	local v43 = v37.steerMotor
	local v44 = not v43 and 1 or v43.C0.UpVector.Y
	v37.forkY = math.max(v44, 0.5)
	v37.compF = 0
	v37.compR = 0
	v37.rayParams = RaycastParams.new()
	v37.rayParams.FilterType = Enum.RaycastFilterType.Exclude
	v37.rayParams.FilterDescendantsInstances = { p32 }
	v37.rayParams.IgnoreWater = true
	v37.visualSteer = 0
	v37.twist = 0
	v37.drlMode = nil
	v37.engineWas = p32:GetAttribute("EngineOn") == true
	v37.welcomeAt = nil
	v37.occupied = nil
	v37.mirrorsShown = nil
	v37.shieldShown = nil
	v37.ownedSounds = {}
	v37.ownedObjects = {}
	v37.tailLenses = {}
	v37.indicatorLamps = {}
	v37.tailState = nil
	v37.indicatorMode = "Off"
	v37.blinkStart = 0
	v37.blinkLit = false
	local v45 = p32:GetAttribute("SoundBlinker") or v_u_5.DEFAULT_BLINKER_SOUND
	local v46 = p32:GetAttribute("SoundIndicatorSwitch") or v_u_5.DEFAULT_SWITCH_SOUND
	v37.blinkClick = v37:makeSound("PCX160_BlinkerClick", v45, 2.6, v37.chassis)
	v37.switchClick = v37:makeSound("PCX160_IndicatorSwitch", v46, 2, v37.chassis)
	v37.blinkClick2D = v37:makeSound("PCX160_BlinkerClick2D", v45, 2.8, nil)
	v37.switchClick2D = v37:makeSound("PCX160_IndicatorSwitch2D", v46, 2, nil)
	local v47 = v33:FindFirstChild("ExhaustTip")
	local v48
	if v47 then
		v48 = v_u_20(v47)
	else
		v48 = v47
	end
	v37.smoke = v48
	v37.exhaustTip = v47
	local v49
	if v47 then
		v49 = v47.Position
	else
		v49 = v47
	end
	v37.tipBase = v49
	v37.tipAlts = {}
	if v47 then
		for v50, v51 in v47:GetAttributes() do
			local v52 = v50:match("^TipAt_(.+)$")
			if not v52 or typeof(v51) ~= "Vector3" then
				continue
			end
			local v53 = v37.tipAlts
			table.insert(v53, {
				["key"] = v52,
				["pos"] = v51
			})
		end
	end
	v37.bands = {}
	v37.maxBand = 1
	v37.rainbowTextures = {}
	v37.drlBeams = {}
	v37.guidePieces = {}
	v37.headTwins = {}
	v37.lensBase = {}
	v37.kickstandUp = {}
	v37.kickstandDown = {}
	v37.centerUp = {}
	v37.centerDown = {}
	v37.mirrors = {}
	v37.accessories = {}
	v37.accShown = {}
	v37.accHides = {}
	v37.rainbowSkins = {}
	v37.rainbowClear = {}
	v37.shields = {}
	v37.lidMotor = v33:FindFirstChild("SeatLidMotor")
	local v54 = v37.lidMotor
	if v54 then
		v54 = v37.lidMotor:GetAttribute("BaseC0") or v37.lidMotor.C0
	end
	v37.lidBase = v54
	v37.lidT = 0
	v37.bins = {}
	v37.frames = {}
	v37.frameOutline = {}
	for _, v55 in p32:GetDescendants() do
		if v55:IsA("BasePart") then
			if v55.Name == "DRLGuidePiece" then
				local v56 = v55:GetAttribute("T") or 0
				local v57 = v37.guidePieces
				local v58 = {
					["part"] = v55,
					["t0"] = v56,
					["t1"] = v56,
					["frosted"] = v55:GetAttribute("Frosted") == true
				}
				table.insert(v57, v58)
			end
			local v59 = v55:GetAttribute("DRLBand")
			if v59 then
				local v60 = v37.bands
				local v61 = {
					["part"] = v55,
					["index"] = v59,
					["twin"] = v55:GetAttribute("DRLTwin") == true,
					["skin"] = v55.Name == "LampSkin",
					["side"] = v55:GetAttribute("Side"),
					["customOnly"] = v55:GetAttribute("CustomOnly") == true,
					["whiteOnly"] = v55:GetAttribute("DRLWhiteOnly") == true,
					["stayLit"] = v55:GetAttribute("DRLStayLit") == true,
					["sweep"] = v55:GetAttribute("SignalSweep") == true
				}
				table.insert(v60, v61)
				local v62 = v37.maxBand
				v37.maxBand = math.max(v62, v59)
			end
			if v55:GetAttribute("LampRole") == "Head" and v55:GetAttribute("LightGlow") then
				local v63 = p32:FindFirstChild(v55.Name:gsub("_Glow$", ""), true)
				if not v63 or (v63 == v55 or not v63:IsA("BasePart")) then
					v63 = nil
				end
				local v64 = v55:GetAttribute("LitGlass")
				local v65
				if type(v64) == "string" then
					v65 = p32:FindFirstChild(v64, true) or nil
				else
					v65 = nil
				end
				if v65 and not v65:IsA("BasePart") then
					v65 = nil
				end
				local v66 = v55:GetAttribute("LitHalo")
				local v67
				if type(v66) == "string" then
					v67 = p32:FindFirstChild(v66, true) or nil
				else
					v67 = nil
				end
				local v68 = {}
				local v69 = {}
				if v67 then
					for _, v70 in v67:GetDescendants() do
						if not v70:IsA("SurfaceGui") then
							continue
						end
						table.insert(v68, v70)
					end
				end
				for _, v71 in v55:GetChildren() do
					if not v71:IsA("Light") then
						continue
					end
					table.insert(v69, v71)
				end
				local v72 = v55:GetAttribute("LitColor")
				local v73 = v37.headTwins
				local v74 = {
					["part"] = v55,
					["source"] = v63
				}
				if v63 then
					v63 = v63.Transparency
				end
				v74.sourceTransparency = v63
				v74.glass = v65
				if v65 then
					v65 = v65.Transparency
				end
				v74.glassTransparency = v65
				v74.glassLit = v55:GetAttribute("LitGlassTransparency")
				v74.glows = v68
				v74.lights = v69
				if typeof(v72) ~= "Color3" then
					v72 = v_u_15
				end
				v74.color = v72
				table.insert(v73, v74)
			elseif v55:GetAttribute("LampRole") == "Head" and v55.Name == "LampSkin" then
				local v75 = v37.headTwins
				table.insert(v75, {
					["part"] = v55
				})
			end
			local v76 = v55:GetAttribute("Kickstand")
			if v76 == "Up" then
				local v77 = v37.kickstandUp
				table.insert(v77, v55)
			elseif v76 == "Down" then
				local v78 = v37.kickstandDown
				table.insert(v78, v55)
			end
			local v79 = v55:GetAttribute("CenterStand")
			if v79 == "Up" then
				local v80 = v37.centerUp
				table.insert(v80, v55)
			elseif v79 == "Down" then
				local v81 = v37.centerDown
				table.insert(v81, v55)
			end
			if v55:GetAttribute("Mirror") then
				local v82 = v37.mirrors
				table.insert(v82, v55)
			end
			local v83 = v55:GetAttribute("RainbowClear")
			if type(v83) == "number" and v55:IsA("BasePart") then
				local v84 = v37.rainbowClear
				local v85 = {
					["part"] = v55,
					["base"] = v55.Transparency,
					["clear"] = v83,
					["onWhite"] = v55:GetAttribute("RainbowOnWhite") == true
				}
				table.insert(v84, v85)
			end
			local v86 = v55:GetAttribute("RainbowU")
			if type(v86) == "number" then
				local v87 = {
					["part"] = v55,
					["u"] = v86,
					["sweep"] = v55:GetAttribute("SweepU") or 0,
					["side"] = v55:GetAttribute("RainbowSide") or v55:GetAttribute("IndicatorSide"),
					["signal"] = v55:GetAttribute("IndicatorSide") ~= nil,
					["onWhite"] = v55:GetAttribute("RainbowOnWhite") == true,
					["signalSide"] = v55:GetAttribute("IndicatorSide")
				}
				local v88 = v37.rainbowSkins
				table.insert(v88, v87)
				v37.skinOf = v37.skinOf or {}
				v37.skinOf[v55] = v87
			end
			local v89 = v55:GetAttribute("RainbowLightU")
			local v90
			if type(v89) == "number" then
				v90 = v55:FindFirstChildWhichIsA("Light") or nil
			else
				v90 = nil
			end
			if v90 then
				v90.Enabled = false
				v37.rainbowLights = v37.rainbowLights or {}
				local v91 = v37.rainbowLights
				local v92 = {
					["light"] = v90,
					["u"] = v89,
					["side"] = v55:GetAttribute("RainbowSide") or v55:GetAttribute("Side")
				}
				table.insert(v91, v92)
			end
			local v93 = v55:GetAttribute("Accessory")
			local v94 = v55:GetAttribute("AccessoryHides")
			if type(v94) == "string" then
				if type(v93) == "string" then
					v37.accHides[v93] = v94
				else
					v93 = "Hide:" .. v94
				end
			end
			if type(v93) == "string" then
				v37.accessories[v93] = v37.accessories[v93] or {}
				local v95 = v37.accessories[v93]
				table.insert(v95, v55)
				local v96 = v55:GetAttribute("HideWhile")
				local v97 = v55:GetAttribute("OnlyWith")
				if type(v96) == "string" or type(v97) == "string" then
					v37.accRules = v37.accRules or {}
					local v98 = v37.accRules
					local v99 = {}
					local v100
					if type(v96) == "string" then
						v100 = v96
					else
						v100 = nil
					end
					v99.hide = v100
					local v101
					if type(v97) == "string" then
						v101 = v97
					else
						v101 = nil
					end
					v99.only = v101
					v98[v55] = v99
					v37.accRuleKeys = v37.accRuleKeys or {}
					v37.accRuleKeys[v93] = (v37.accRuleKeys[v93] or "") .. "," .. (type(v96) ~= "string" and "" or v96) .. "," .. (type(v97) ~= "string" and "" or v97)
				end
				for _, v102 in v55:GetChildren() do
					if not v102:IsA("Decal") then
						continue
					end
					local v103 = v37.accessories[v93]
					table.insert(v103, v102)
				end
			end
			if v55:GetAttribute("Windshield") then
				local v104 = v37.shields
				table.insert(v104, v55)
			end
			if v55:GetAttribute("SeatBin") then
				local v105 = v37.bins
				table.insert(v105, v55)
			end
			if v55:GetAttribute("DRLFrame") then
				v37.frames[v55:GetAttribute("DRLFrame")] = v55
				v55.Transparency = 1
			end
			if v55:GetAttribute("FrameOutline") then
				local v106 = v37.frameOutline
				table.insert(v106, v55)
			end
			if v55:GetAttribute("TailLens") then
				local v107 = v37.tailLenses
				table.insert(v107, v55)
				local v108 = v55:GetAttribute("LightGlow")
				if v108 then
					v108 = p32:FindFirstChild(v55.Name:gsub("_Glow$", ""), true)
					if not v108 or (v108 == v55 or not v108:IsA("BasePart")) then
						v108 = nil
					end
				end
				local v109 = v37.lensBase
				local v110 = {
					["color"] = v55:GetAttribute("BaseColor") or v55.Color,
					["material"] = Enum.Material[v55:GetAttribute("BaseMaterial") or "Glass"],
					["transparency"] = v55.Transparency,
					["glass"] = v55.Name:lower():find("glass", 1, true) ~= nil,
					["clearWhenLit"] = v55:GetAttribute("ClearWhenLit") == true,
					["solid"] = v55:GetAttribute("LitSolid") == true,
					["signalSide"] = v55:GetAttribute("IndicatorSide"),
					["source"] = v108
				}
				if v108 then
					v108 = v108.Transparency
				end
				v110.sourceTransparency = v108
				v109[v55] = v110
			end
			local v111 = v55:GetAttribute("IndicatorSide")
			if not v111 then
				continue
			end
			local v112 = v55:GetAttribute("LightGlow") and "glow" or (v55:IsA("MeshPart") and "lens" or (v55:GetAttribute("LightOnly") and "light" or "bulb"))
			local v113
			if v112 == "glow" then
				v113 = p32:FindFirstChild(v55.Name:gsub("_Glow$", ""), true)
				if not v113 or (v113 == v55 or not v113:IsA("BasePart")) then
					v113 = nil
				end
			else
				v113 = false
			end
			local v114 = v55:FindFirstChildWhichIsA("PointLight")
			if v114 then
				v114.Brightness = 0.6
				v114.Range = 2.5
			end
			local v115 = v55:GetAttribute("SweepU")
			if type(v115) == "number" then
				v37.hasSweepLamps = true
			else
				v115 = nil
			end
			local v116 = v37.indicatorLamps
			local v117 = {
				["part"] = v55,
				["side"] = v111,
				["kind"] = v112,
				["light"] = v114,
				["source"] = v113
			}
			if v113 then
				v113 = v113.Transparency
			end
			v117.sourceTransparency = v113
			v117.running = v55:GetAttribute("RunningLight") == true
			v117.u = v115
			v117.onWhite = v55:GetAttribute("RainbowOnWhite") == true
			table.insert(v116, v117)
		elseif v55:IsA("Beam") and v55:GetAttribute("HueFrom") then
			v55.Enabled = false
		elseif v55:IsA("Beam") and v55.Name == "DRLBeam" then
			local v118 = v37.drlBeams
			local v119 = {
				["beam"] = v55,
				["t0"] = v55:GetAttribute("T0") or 0,
				["t1"] = v55:GetAttribute("T1") or 1
			}
			table.insert(v118, v119)
		else
			if not v55:IsA("Texture") or v55.Name ~= "DRLRainbow" then
				continue
			end
			local v120 = v37.rainbowTextures
			local v121 = {
				["texture"] = v55,
				["base"] = v55:GetAttribute("BaseOffsetV") or v55.OffsetStudsV,
				["sign"] = v55:GetAttribute("ScrollSign") or 1
			}
			table.insert(v120, v121)
		end
	end
	for _, v122 in v37.bands do
		local v123 = v122.index - 1
		local v124 = v37.maxBand - 1
		v122.u = v123 / math.max(v124, 1)
	end
	v37:setupStrip()
	if v37.drlGlow then
		v37.drlGlow.Brightness = 0.35
		v37.drlGlow.Range = 3.5
	end
	if v37.taillight then
		v37.taillight.Range = 4
	end
	v37.tailReach = 0.1
	for _, v125 in v37.tailLenses do
		local v126 = v37.tailReach
		local v127 = v33.CFrame:PointToObjectSpace(v125.Position).X
		local v128 = math.abs(v127)
		v37.tailReach = math.max(v126, v128)
	end
	v37:setupLampMeshes()
	return v37
end
function v_u_21.setupStrip(p129) -- name: setupStrip
	-- upvalues: (copy) v_u_11
	local v130
	if p129.model:GetAttribute("CustomLightGuide") == true then
		v130 = #p129.guidePieces > 0
	else
		v130 = false
	end
	p129.customGuide = v130
	if p129.customGuide then
		for _, v131 in p129.guidePieces do
			v131.frosted = false
		end
	end
	if p129.model:GetAttribute("DRLModel") and not p129.customGuide then
		for _, v132 in p129.drlBeams do
			v132.beam.Enabled = false
		end
		for _, v133 in p129.guidePieces do
			v133.part.Transparency = 1
		end
		p129.drlBeams = {}
	elseif #p129.guidePieces > 0 then
		for _, v134 in p129.drlBeams do
			v134.beam.Enabled = false
		end
		p129.drlBeams = p129.guidePieces
	end
	p129.stripMode = #p129.drlBeams > 0
	local v135 = {
		["Left"] = { (1 / 0), (-1 / 0) },
		["Right"] = { (1 / 0), (-1 / 0) }
	}
	for _, v136 in p129.drlBeams do
		local v137
		if v136.part then
			v137 = p129.chassis.CFrame:PointToObjectSpace(v136.part.Position).X
			if v136.frosted then
				v136.part.Material = Enum.Material.SmoothPlastic
				v136.part.Color = v_u_11
				v136.part.Transparency = 0
			else
				v136.part.Transparency = 1
			end
		else
			local v138 = v136.beam
			local v139 = v138.Attachment0
			local v140 = v138.Attachment1
			v137 = ((not v139 and 0 or v139.Position.X) + (not v140 and 0 or v140.Position.X)) / 2
			v138.LightEmission = 1
			v138.LightInfluence = 0
			v138.Brightness = 2
			v138.ZOffset = 0.01
			local v141 = v138:GetAttribute("TracedWidth")
			if not v141 then
				v141 = v138.Width0
				v138:SetAttribute("TracedWidth", v141)
			end
			v138.Width0 = v141 * 0.7
			v138.Width1 = v141 * 0.7
		end
		v136.side = v137 < 0 and "Left" or "Right"
		local v142 = v136.part and v136.part:GetAttribute("SweepT")
		if v142 then
			v142 = v136.part:GetAttribute("Side")
		end
		if v142 == "Left" or v142 == "Right" then
			v136.side = v142
		end
		v136.out = math.abs(v137)
		local v143 = v135[v136.side]
		local v144 = v143[1]
		local v145 = v136.out
		local v146 = math.min(v144, v145)
		local v147 = v143[2]
		local v148 = v136.out
		local v149 = math.max(v147, v148)
		v143[1] = v146
		v143[2] = v149
	end
	for _, v150 in p129.drlBeams do
		local v151 = v135[v150.side]
		v150.u = v151[2] <= v151[1] and 0 or (v150.out - v151[1]) / (v151[2] - v151[1])
		local v152
		if v150.part and v150.part:GetAttribute("T") then
			v152 = v150.t0
		else
			v152 = v150.u
		end
		v150.place = v152
		local v153 = v150.part
		if v153 then
			v153 = v150.part:GetAttribute("SweepT")
		end
		if type(v153) ~= "number" then
			continue
		end
		v150.u = v153
	end
	if p129.customGuide then
		p129.stripMode = false
	end
end
local function v_u_161(p154, p155, p156, p157) -- name: setStripPiece
	-- upvalues: (copy) v_u_11
	if p154.part and p154.frosted then
		local v158
		if p155 then
			v158 = Enum.Material.Neon
		else
			v158 = Enum.Material.SmoothPlastic
		end
		if not p155 then
			p156 = v_u_11
		end
		if p154.drawnT ~= 0 then
			p154.part.Transparency = 0
			p154.drawnT = 0
		end
		if v158 ~= p154.drawnMaterial then
			p154.part.Material = v158
			p154.drawnMaterial = v158
		end
		if p156 ~= p154.drawnColor then
			p154.part.Color = p156
			p154.drawnColor = p156
		end
		return
	elseif p154.part then
		if p154.litT == nil then
			p154.litT = p154.part:GetAttribute("LitTransparency") or 0
			p154.litDim = p154.part:GetAttribute("LitDim") or false
		end
		local v159 = not p155 and 1 or p154.litT
		if v159 ~= p154.drawnT then
			p154.part.Transparency = v159
			p154.drawnT = v159
		end
		if p155 then
			if p154.litDim then
				p156 = p156:Lerp(Color3.new(0, 0, 0), p154.litDim)
			end
			if p156 ~= p154.drawnColor then
				p154.part.Color = p156
				p154.drawnColor = p156
			end
		end
	else
		if p155 ~= p154.drawnOn then
			p154.beam.Enabled = p155
			p154.drawnOn = p155
		end
		if p155 and (p156 ~= p154.drawnC0 or p157 ~= p154.drawnC1) then
			local v160 = Color3.new(1, 1, 1)
			p154.beam.Color = ColorSequence.new(p156:Lerp(v160, 0.15), p157:Lerp(v160, 0.15))
			p154.drawnC0 = p156
			p154.drawnC1 = p157
		end
	end
end
function v_u_21.modeSample(p162, p163, p164, p165, p166) -- name: modeSample
	-- upvalues: (copy) v_u_5, (copy) v_u_7
	local v167 = p162.model
	local v168
	if v167:GetAttribute("DRLSplit") == true and p164 == "Right" then
		v168 = v167:GetAttribute("DRLModeR")
	else
		v168 = v167:GetAttribute("DRLMode")
	end
	if p166 then
		p166 = v167:GetAttribute("DRLModeRear")
	end
	if typeof(p166) ~= "number" then
		p166 = v168
	end
	local v169 = v167:GetAttribute("DRLColor") or v_u_5.DRL_DEFAULT_COLOR
	return v_u_7.sample(p166 or 1, p163, p164, p165, v167:GetAttribute("DRLSpeed"), v169, v167:GetAttribute("DRLColor2") or v169)
end
function v_u_21.drawStrip(p170, p171) -- name: drawStrip
	-- upvalues: (copy) v_u_5, (copy) v_u_7, (copy) v_u_161, (copy) v_u_9
	local v172 = p170.indicatorMode
	local v173, v174 = v_u_5.blinkAt(p170.model, os.clock() - p170.blinkStart)
	local v175 = v174 / 0.55
	local v176 = math.clamp(v175, 0, 1)
	local v177 = p170.welcomeAt
	if v177 then
		v177 = os.clock() - p170.welcomeAt
	end
	if v177 and v_u_7.WELCOME_TIME < v177 then
		p170.welcomeAt = nil
		v177 = nil
	end
	local v178
	if p171 == nil then
		v178 = false
	else
		v178 = p170.model:GetAttribute("DRLStyle") == "Mode"
	end
	local v179 = workspace:GetServerTimeNow()
	local v180 = v_u_5.signalColor(p170.model)
	for _, v181 in p170.drlBeams do
		if v172 == "Hazard" or v172 == v181.side then
			local v182 = v_u_161
			local v183
			if v173 then
				v183 = v181.u <= v176
			else
				v183 = v173
			end
			v182(v181, v183, v180, v180)
		elseif v177 then
			local v184 = v_u_7.welcome(v181.place or v181.u, v177)
			v_u_161(v181, v184 ~= nil, v184, v184)
		elseif v178 then
			local v185 = p170:modeSample(v181.place or v181.u, v181.side, v179)
			v_u_161(v181, v185 ~= nil, v185, v185)
		elseif p171 then
			v_u_161(v181, true, p171(1 + v181.t0 * 17), p171(1 + v181.t1 * 17))
		else
			v_u_161(v181, true, v_u_9, v_u_9)
		end
	end
end
function v_u_21.signalLevel(p186) -- name: signalLevel
	-- upvalues: (copy) v_u_5
	local v187 = v_u_5.blinkRate(p186.model)
	if v_u_5.BLINK_RATE_MAX <= v187 then
		return 1
	end
	local v188 = v_u_5.BLINK_ON_TIME / v187
	local v189 = (os.clock() - p186.blinkStart) % (v_u_5.BLINK_PERIOD / v187)
	if v188 <= v189 then
		local v190 = v189 - v188
		local v191 = v188 * 0.3
		local v192 = v190 / math.max(v191, 0.001)
		return v192 >= 1 and 0 or 0.25 * (1 - v192) ^ 2
	end
	local v193 = v189 / v188
	local v194 = v193 / 0.28
	local v195 = (1 - v193) / 0.3 + 0.25
	local v196 = math.min(v194, 1, v195)
	local v197 = math.clamp(v196, 0, 1)
	return v197 * v197 * (3 - v197 * 2)
end
function v_u_21.signalSkins(p198) -- name: signalSkins
	-- upvalues: (copy) v_u_5, (copy) v_u_12, (copy) v_u_8
	local v199 = p198.indicatorMode
	local v200, v201 = v_u_5.blinkAt(p198.model, os.clock() - p198.blinkStart)
	local v202 = v201 / 0.55
	local v203 = math.clamp(v202, 0, 1)
	local v204 = v_u_5.signalColor(p198.model)
	for _, v205 in p198.bands do
		if not ((v205.skin or v205.sweep) and v205.side) then
			continue
		end
		v205.signalling = v199 == "Hazard" and true or v199 == v205.side
		if v205.signalling and (v205.sweep and not v205.skin) then
			v205.part.Material = Enum.Material.Neon
			v205.part.Transparency = 0
			v205.part.Color = v_u_12:Lerp(v204, p198:signalLevel())
			v205.signalled = true
		elseif v205.signalling then
			v205.part.Transparency = v200 and v205.u <= v203 and 0 or 1
			v205.part.Color = v204
			v205.signalled = true
		else
			if not v205.signalled then
				continue
			end
			v205.signalled = nil
			if v205.sweep and not v205.skin then
				local v206 = p198.drlMode
				local v207 = v206 ~= "off" and v205.whiteOnly
				if v207 then
					v207 = v206 == "custom"
				end
				local v208 = v205.part:GetAttribute("RainbowClear")
				local v209 = v205.part
				local v210
				if v207 then
					v210 = Enum.Material.SmoothPlastic
				else
					v210 = Enum.Material.Neon
				end
				v209.Material = v210
				local v211 = v205.part
				local v212
				if v207 then
					v212 = v_u_8
				else
					v212 = Color3.new(1, 1, 1)
				end
				v211.Color = v212
				v205.part.Transparency = (v206 ~= "custom" or type(v208) ~= "number") and (v205.customOnly and v206 ~= "custom" and 1 or 0) or v208
			else
				v205.part.Transparency = v205.customOnly and p198.drlMode ~= "custom" and 1 or 0
				v205.part.Color = Color3.new(1, 1, 1)
			end
		end
	end
end
function v_u_21.makeSound(p213, p214, p215, p216, p217) -- name: makeSound
	-- upvalues: (copy) v_u_3
	local v218 = Instance.new("Sound")
	v218.Name = p214
	local v219
	if tostring(p215):match("^%d+$") then
		v219 = "rbxassetid://" .. p215
	else
		v219 = tostring(p215)
	end
	v218.SoundId = v219
	v218.Volume = p216
	v218.RollOffMode = Enum.RollOffMode.InverseTapered
	v218.RollOffMinDistance = 8
	v218.RollOffMaxDistance = 45
	v218.Parent = p217 or v_u_3
	local v220 = p213.ownedSounds
	table.insert(v220, v218)
	return v218
end
function v_u_21.isLocalRider(p221) -- name: isLocalRider
	-- upvalues: (copy) v_u_1
	local v222 = p221.seat.Occupant
	local v223
	if v222 == nil then
		v223 = false
	else
		v223 = v_u_1.LocalPlayer.Character == v222.Parent
	end
	return v223
end
function v_u_21.click(p224, p225, p226, p227) -- name: click
	if not p224:isLocalRider() then
		p226 = p225
	end
	p226.PlaybackSpeed = p227
	p226.TimePosition = 0
	p226:Play()
end
function v_u_21.frontColor(p228, p229) -- name: frontColor
	local v230 = p228.chassis.CFrame:PointToObjectSpace(p229.Position).X
	local v231 = math.abs(v230) / p228.tailReach
	local v232 = math.clamp(v231, 0, 1)
	local v233 = p229:GetAttribute("TailAt")
	if type(v233) == "number" then
		v232 = math.clamp(v233, 0, 1)
	end
	if p228.model:GetAttribute("DRLStyle") == "Mode" then
		return p228:modeSample(v232, v230 < 0 and "Left" or "Right", workspace:GetServerTimeNow(), true)
	end
	local v234 = p228.frontPaint
	if v234 then
		local v235 = p228:paintBands()
		v234 = v234(v232 * (math.max(v235, 2) - 1) + 1)
	end
	return v234
end
function v_u_21.updateTailLight(p236, p237, p238, p239) -- name: updateTailLight
	-- upvalues: (copy) v_u_14, (copy) v_u_13, (copy) v_u_17
	local v240 = os.clock()
	local v241 = p237 and p238
	if v241 and (not p236.wasBraking and v240 - (p236.brakeReleased or (-1 / 0)) > 0.5) then
		p236.brakeStart = v240
	elseif not v241 and p236.wasBraking then
		p236.brakeReleased = v240
	end
	p236.wasBraking = v241
	local v242
	if p237 then
		if p236.model:GetAttribute("RainbowOn") == true then
			v242 = "front"
		elseif v241 then
			local v243 = v240 - (p236.brakeStart or 0)
			local v244
			if v243 < 0.42000000000000004 then
				local v245 = v243 / 0.07
				v244 = math.floor(v245) % 2 == 1
			else
				v244 = false
			end
			v242 = v244 and "off" or "brake"
		else
			v242 = p239 and "custom" or (p236.model:GetAttribute("TailLightOn") == true and "on" or "off")
		end
	else
		v242 = "off"
	end
	if v242 ~= p236.tailState or (v242 == "custom" or v242 == "front") then
		p236.tailState = v242
		if v242 == "brake" then
			p239 = v_u_14
		elseif v242 ~= "custom" then
			p239 = v_u_13
		end
		local v246 = p236.model:GetAttribute("Indicator") or "Off"
		for _, v247 in p236.tailLenses do
			local v248 = p236.lensBase[v247]
			if v248.signalSide and (v242 ~= "off" and (v246 == "Hazard" or (v246 == v248.signalSide or p236.wasFlashing))) then
				p236.tailState = nil
			else
				local v249
				if v242 == "front" then
					v249 = p236:frontColor(v247)
				else
					v249 = nil
				end
				local v250
				if v242 == "off" then
					v250 = true
				elseif v242 == "front" then
					v250 = v249 == nil and true or v247:GetAttribute("RainbowSkinned") == true
				else
					v250 = false
				end
				if v242 ~= "front" then
					v249 = p239
				end
				if v247:GetAttribute("LightGlow") then
					v247.Transparency = v250 and 1 or 0
					if v249 then
						v247.Color = v249
					end
					if not v248.source then
						continue
					end
					v248.source.Transparency = not v250 and 1 or v248.sourceTransparency
				elseif v250 then
					v247.Color = v248.color
					v247.Material = v248.material
					v247.Transparency = v248.transparency
				elseif (v242 == "custom" or v242 == "front" and v248.clearWhenLit) and v248.glass then
					v247.Material = Enum.Material.Glass
					v247.Transparency = 0.8
				else
					v247.Material = Enum.Material.Neon
					v247.Color = v249
					v247.Transparency = v248.solid and 0 or v248.transparency
				end
			end
		end
		if p236.taillight then
			local v251
			if v242 == "front" then
				v251 = p236:frontColor(p236.chassis)
			else
				v251 = nil
			end
			local v252 = p236.taillight
			local v253
			if v242 == "off" then
				v253 = false
			else
				local v254
				if v242 == "front" then
					v254 = v251 == nil
				else
					v254 = false
				end
				v253 = not v254
			end
			v252.Enabled = v253
			if v242 == "brake" then
				v241 = true
			elseif v242 ~= "front" then
				v241 = false
			end
			p236.taillight.Brightness = v241 and 2.4 or 0.8
			p236.taillight.Range = v241 and 7 or 4
			local v255 = p236.taillight
			if v242 ~= "custom" then
				p239 = v251 or v_u_17
			end
			v255.Color = p239
		end
	end
end
function v_u_21.paintBands(p256) -- name: paintBands
	return p256.maxBand <= 1 and p256.stripMode and 10 or p256.maxBand
end
function v_u_21.drlPainter(p_u_257) -- name: drlPainter
	-- upvalues: (copy) v_u_5, (copy) v_u_31
	local v258 = p_u_257.model
	local v259 = v258:GetAttribute("DRLStyle") or "Rainbow"
	local v_u_260 = v258:GetAttribute("DRLColor") or v_u_5.DRL_DEFAULT_COLOR
	local v_u_261 = v258:GetAttribute("DRLColor2") or v_u_260
	local v_u_262 = os.clock()
	if v259 == "Mode" then
		return function()
			-- upvalues: (copy) p_u_257, (copy) v_u_260
			return p_u_257:modeSample(0.5, "Right", workspace:GetServerTimeNow()) or v_u_260:Lerp(Color3.new(0, 0, 0), 0.85)
		end
	end
	if v259 == "Solid" then
		return function()
			-- upvalues: (copy) v_u_260
			return v_u_260
		end
	end
	if v259 == "Gradient" then
		local v263 = p_u_257:paintBands()
		local v_u_264 = math.max(v263, 2)
		return function(p265)
			-- upvalues: (copy) v_u_264, (copy) v_u_262, (copy) v_u_260, (copy) v_u_261
			local v266 = 2 * (((p265 - 1) / (v_u_264 - 1) * 1 - v_u_262 * 0.6) % 1) - 1
			local v267 = 1 - math.abs(v266)
			return v_u_260:Lerp(v_u_261, v267 * v267 * (3 - v267 * 2))
		end
	end
	local v_u_268 = v_u_262 * 0.55
	local v269 = p_u_257:paintBands() - 1
	local v_u_270 = 0.45 / math.max(v269, 1)
	return function(p271)
		-- upvalues: (ref) v_u_31, (copy) v_u_268, (copy) v_u_270
		return v_u_31(p271, v_u_268, v_u_270)
	end
end
function v_u_21.setupLampMeshes(p_u_272) -- name: setupLampMeshes
	-- upvalues: (ref) v_u_27
	p_u_272.lampMeshes = {}
	p_u_272.lampTextures = {}
	for _, v273 in p_u_272.model:GetDescendants() do
		if not (v273:IsA("BasePart") and v273:GetAttribute("LampSide")) then
			continue
		end
		local v274 = v273:FindFirstChild("LampSweep")
		local v275
		if v274 then
			v275 = v274:GetAttribute("SweepOffsetFrom")
		else
			v275 = v274
		end
		local v276
		if v274 then
			v276 = v274:GetAttribute("SweepOffsetTo")
		else
			v276 = v274
		end
		if v274 then
			v274.Transparency = 1
		end
		v273.Transparency = 1
		local v277 = p_u_272.lampTextures
		local v278 = {
			["part"] = v273,
			["side"] = v273:GetAttribute("LampSide"),
			["mask"] = v274
		}
		if typeof(v275) ~= "Vector2" then
			v275 = nil
		end
		v278.from = v275
		if typeof(v276) ~= "Vector2" then
			v276 = nil
		end
		v278.to = v276
		v278.light = v273:FindFirstChildWhichIsA("PointLight")
		table.insert(v277, v278)
	end
	for _, v_u_279 in p_u_272.model:GetDescendants() do
		if not (v_u_279:IsA("MeshPart") and v_u_279:GetAttribute("MeshSignalSide")) then
			continue
		end
		task.spawn(function()
			-- upvalues: (copy) p_u_272, (copy) v_u_279, (ref) v_u_27
			for v280 = 1, 3 do
				local v281 = p_u_272.buildLampMesh
				local v282 = p_u_272
				local v283 = v_u_279
				local v284, v285 = pcall(v281, v282, v283)
				if v284 then
					return
				end
				if v280 == 3 or not v_u_279.Parent then
					if not v_u_27 then
						v_u_27 = true
						warn("PCX160: lamp mesh not available, the whole-lamp glow lights instead:", v_u_279:GetFullName(), v285)
					end
					return
				end
				task.wait(3)
			end
		end)
	end
end
local function v_u_335(p286) -- name: aroundPlaces
	local v287 = false
	for _, v288 in p286 do
		if not v288.front then
			continue
		end
		v287 = true
	end
	local v289 = (1 / 0)
	local v290 = (-1 / 0)
	local v291 = (1 / 0)
	local v292 = (-1 / 0)
	for _, v293 in p286 do
		if not v293.front and v287 then
			continue
		end
		local v294 = v293.a
		v289 = math.min(v289, v294)
		local v295 = v293.a
		v290 = math.max(v290, v295)
		local v296 = v293.y
		v291 = math.min(v291, v296)
		local v297 = v293.y
		v292 = math.max(v292, v297)
	end
	local v298 = (v289 + v290) / 2
	local v299 = (v291 + v292) / 2
	local v300 = {}
	for _, v301 in p286 do
		local v302 = v301.y - v299
		local v303 = v301.a - v298
		v301.t = math.atan2(v302, v303)
		if not v301.front and v287 then
			continue
		end
		local v304 = v301.t
		table.insert(v300, v304)
	end
	table.sort(v300)
	local v305 = v300[#v300]
	local v306 = v300[1] + 6.283185307179586 - v300[#v300]
	for v307 = 2, #v300 do
		if v306 >= v300[v307] - v300[v307 - 1] then
			continue
		end
		v306 = v300[v307] - v300[v307 - 1]
		v305 = v300[v307 - 1]
	end
	local v308 = 6.283185307179586 - v306
	local v309 = math.max(v308, 1e-6)
	local v310 = {}
	for _, v311 in p286 do
		local v312 = (v305 - v311.t) % 6.283185307179586
		if v309 < v312 then
			v312 = v312 - v309 >= 6.283185307179586 - v312 and 0 or v309
		end
		v311.s = v312
		if not v311.front and v287 then
			continue
		end
		local v313 = v312 / v309 * 48
		local v314 = math.floor(v313)
		local v315 = math.clamp(v314, 0, 47)
		local v316 = v310[v315] or {
			["s"] = 0,
			["a"] = 0,
			["y"] = 0,
			["n"] = 0
		}
		v316.s = v316.s + v312
		v316.a = v316.a + v311.a
		v316.y = v316.y + v311.y
		v316.n = v316.n + 1
		v310[v315] = v316
	end
	local v317 = {}
	for v318 = 0, 47 do
		local v319 = v310[v318]
		if not v319 then
			continue
		end
		local v320 = {
			["s"] = nil,
			["a"] = nil,
			["y"] = nil,
			["len"] = 0,
			["s"] = v319.s / v319.n,
			["a"] = v319.a / v319.n,
			["y"] = v319.y / v319.n
		}
		local v321 = v317[#v317]
		if v321 then
			local v322 = v321.len
			local v323 = (v320.a - v321.a) ^ 2 + (v320.y - v321.y) ^ 2
			v320.len = v322 + math.sqrt(v323)
		end
		table.insert(v317, v320)
	end
	local v324 = #v317 <= 1 and 0 or v317[#v317].len
	for _, v325 in p286 do
		local v326 = 0
		if v324 > 0 then
			if v325.s <= v317[1].s then
				v326 = 0
			elseif v325.s >= v317[#v317].s then
				v326 = v324
			else
				for v327 = 2, #v317 do
					local v328 = v317[v327 - 1]
					local v329 = v317[v327]
					if v325.s > v329.s then
						continue
					end
					local v330 = v328.len
					local v331 = (v329.len - v328.len) * (v325.s - v328.s)
					local v332 = v329.s - v328.s
					v326 = v330 + v331 / math.max(v332, 1e-9)
				end
			end
		end
		local v333
		if v324 > 0 then
			local v334 = v326 / v324
			v333 = math.clamp(v334, 0, 1)
		else
			v333 = v325.s / v309
		end
		v325.u = v333
	end
end
function v_u_21.buildLampMesh(p336, p337) -- name: buildLampMesh
	-- upvalues: (copy) v_u_4, (copy) v_u_335, (copy) v_u_16, (copy) v_u_5
	local v338 = p337:GetAttribute("MeshSignalSide")
	local v339 = v338 == "Right" and 1 or -1
	local v_u_340 = v_u_4:CreateEditableMeshAsync(Content.fromUri(p337.MeshId))
	if p337.Parent and p336.model.Parent then
		local v341 = v_u_340:GetVertices()
		local v342 = Vector3.new(1, 1, 1) * (1 / 0)
		local v343 = Vector3.new(-1, -1, -1) * (1 / 0)
		for _, v344 in v341 do
			local v345 = v_u_340:GetPosition(v344)
			v342 = v342:Min(v345)
			v343 = v343:Max(v345)
		end
		local v346 = p337.Size / (v343 - v342)
		local v347 = (v343 + v342) / 2
		local v348 = p336.chassis.CFrame:ToObjectSpace(p337.CFrame)
		local v349 = {}
		for _, v350 in v_u_340:GetFaces() do
			local v351 = v_u_340:GetFaceVertices(v350)
			local v352 = v_u_340:GetPosition(v351[1])
			local v353 = v_u_340:GetPosition(v351[2])
			local v354 = v_u_340:GetPosition(v351[3])
			local v355 = (v353 - v352):Cross(v354 - v352)
			for _, v356 in v351 do
				v349[v356] = (v349[v356] or Vector3.new(0, 0, 0)) + v355
			end
		end
		local v357 = {}
		local v358 = (1 / 0)
		local v359 = (-1 / 0)
		for _, v360 in v341 do
			local v361 = v348:PointToWorldSpace((v_u_340:GetPosition(v360) - v347) * v346).X * v339
			v357[v360] = v361
			if v361 <= 0.05 then
				continue
			end
			v358 = math.min(v358, v361)
			v359 = math.max(v359, v361)
		end
		local v362 = v358 < v359
		assert(v362, "no lamp on its side")
		local v363
		if p337:GetAttribute("LampFlow") == "Around" then
			local v364 = {}
			for _, v365 in v341 do
				if v357[v365] <= 0.05 then
					continue
				end
				local v366 = v349[v365]
				local v367 = (not v366 or v366.Magnitude <= 1e-12) and Vector3.new(0, 0, 0) or v348:VectorToWorldSpace(v366 / v346)
				local v368 = {
					["v"] = v365,
					["a"] = v357[v365],
					["y"] = v348:PointToWorldSpace((v_u_340:GetPosition(v365) - v347) * v346).Y
				}
				local v369
				if v367.Magnitude > 1e-12 then
					v369 = v367.Unit.Z < -0.3
				else
					v369 = false
				end
				v368.front = v369
				table.insert(v364, v368)
			end
			v_u_335(v364)
			v363 = {}
			for _, v370 in v364 do
				v363[v370.v] = v370.u
			end
		else
			v363 = nil
		end
		local v371 = {}
		for v372 = 1, 96 do
			v371[v372] = v_u_340:AddColor(v_u_16, 1)
		end
		local v373 = {}
		local v374 = {}
		for _, v375 in v341 do
			local v376 = v_u_340:GetPosition(v375)
			local v377
			if v363 then
				v377 = v363[v375] or 0
			else
				local v378 = (v357[v375] - v358) / (v359 - v358)
				v377 = math.clamp(v378, 0, 1)
			end
			local v379 = v349[v375]
			local v380 = (not v379 or v379.Magnitude <= 1e-12) and Vector3.new(0, 0, 0) or v379.Unit
			local v381 = v377 * 96
			local v382 = math.floor(v381) + 1
			v374[v375] = math.clamp(v382, 1, 96)
			local v383 = {
				["v"] = nil,
				["p"] = nil,
				["sunk"] = nil,
				["u"] = nil,
				["bin"] = nil,
				["shown"] = true,
				["own"] = nil,
				["v"] = v375,
				["p"] = v376,
				["sunk"] = v376 - v380 * 0.012 / v346,
				["u"] = v377,
				["bin"] = v374[v375],
				["own"] = v357[v375] > 0.05
			}
			table.insert(v373, v383)
		end
		for _, v384 in v_u_340:GetFaces() do
			local v385 = v_u_340:GetFaceVertices(v384)
			v_u_340:SetFaceColors(v384, { v371[v374[v385[1]]], v371[v374[v385[2]]], v371[v374[v385[3]]] })
		end
		local v386 = v_u_4:CreateMeshPartAsync(Content.fromObject(v_u_340))
		if p337.Parent and p336.model.Parent then
			for _, v387 in v373 do
				if v387.own then
					continue
				end
				v_u_340:SetPosition(v387.v, v387.sunk)
				v387.shown = false
			end
			v386.Name = p337.Name .. "_LitMesh"
			v386.Size = p337.Size * 1.004
			v386.CFrame = p337.CFrame
			v386.Material = Enum.Material.Neon
			v386.Color = Color3.new(1, 1, 1)
			v386.Transparency = 1
			v386.Anchored = false
			v386.CanCollide = false
			v386.CanQuery = false
			v386.CanTouch = false
			v386.CastShadow = false
			v386.Massless = true
			local v388 = Instance.new("WeldConstraint")
			v388.Part0 = p337
			v388.Part1 = v386
			v388.Parent = v386
			local v389 = Instance.new("PointLight")
			v389.Color = v_u_5.signalColor(p336.model)
			v389.Brightness = 0.6
			v389.Range = 2.5
			v389.Shadows = false
			v389.Enabled = false
			v389.Parent = v386
			v386.Parent = p337.Parent
			v386.Destroying:Connect(function()
				-- upvalues: (copy) v_u_340
				v_u_340:Destroy()
			end)
			local v390 = p336.model:FindFirstChild(p337.Name .. "_Glow", true)
			if v390 then
				for v391 = #p336.indicatorLamps, 1, -1 do
					if p336.indicatorLamps[v391].part ~= v390 then
						continue
					end
					table.remove(p336.indicatorLamps, v391)
				end
				for _, v392 in p336.lampTextures do
					if v392.part ~= v390 then
						continue
					end
					v392.off = true
					if not v392.mask then
						continue
					end
					v392.mask.Transparency = 1
				end
				v390.Transparency = 1
				local v393 = v390:FindFirstChildWhichIsA("PointLight")
				if v393 then
					v393.Enabled = false
				end
			end
			local v394 = p336.lampMeshes
			table.insert(v394, {
				["part"] = v386,
				["em"] = v_u_340,
				["entries"] = v373,
				["colors"] = v371,
				["side"] = v338,
				["light"] = v389,
				["dark"] = {}
			})
		else
			v386:Destroy()
			v_u_340:Destroy()
		end
	else
		v_u_340:Destroy()
		return
	end
end
function v_u_21.lampState(p395, p396, p397) -- name: lampState
	-- upvalues: (copy) v_u_5
	local v398 = p395.indicatorMode or "Off"
	if p395.wasFlashing == true then
		return "amber", 1
	elseif v398 == "Hazard" or v398 == p396 then
		local v399, v400 = v_u_5.blinkAt(p395.model, os.clock() - (p395.blinkStart or 0))
		if not v399 then
			return "off", 1
		end
		local v401 = (v400 or 1) / 0.55
		return "amber", math.clamp(v401, 0, 1)
	elseif p397 == "custom" then
		return "custom", 1
	elseif p397 == "on" then
		return "white", 1
	else
		return "off", 1
	end
end
function v_u_21.updateLampTextures(p402, p403, p404) -- name: updateLampTextures
	-- upvalues: (copy) v_u_5, (copy) v_u_16
	local v405 = p402.lampTextures
	if v405 and #v405 ~= 0 then
		local v406 = p402.model:GetAttribute("DRLStyle") == "Mode"
		local v407 = p402:paintBands()
		local v408 = math.max(v407, 2)
		local v409 = workspace:GetServerTimeNow()
		for _, v410 in v405 do
			if v410.off then
				continue
			end
			local v411 = v410.part
			local v412 = v410.mask
			local v413, v414 = p402:lampState(v410.side, p403)
			if v410.light then
				v410.light.Enabled = v413 == "amber"
			end
			local v415 = nil
			if v413 == "amber" then
				v415 = v_u_5.signalColor(p402.model)
				if v412 then
					v412.Color3 = v415
				end
				if v410.light then
					v410.light.Color = v415
				end
			elseif v413 == "white" then
				v415 = v_u_16
			elseif v413 == "custom" then
				if v406 then
					v415 = p402:modeSample(0.5, v410.side or "Right", v409)
				elseif p404 then
					v415 = p404((v408 - 1) * 0.5 + 1)
				end
			end
			if v413 == "amber" and (v414 < 1 and (v412 and (v410.from and v410.to))) then
				local v416 = v410.from:Lerp(v410.to, v414)
				v412.OffsetStudsU = v416.X
				v412.OffsetStudsV = v416.Y
				v412.Transparency = 0
				v411.Transparency = 1
			else
				if v412 then
					v412.Transparency = 1
				end
				v411.Transparency = v415 and 0 or 1
				if not v415 then
					continue
				end
				v411.Color = v415
			end
		end
	end
end
function v_u_21.updateLampMeshes(p417, p418, p419, p420) -- name: updateLampMeshes
	-- upvalues: (copy) v_u_16, (copy) v_u_5
	local v421 = p417.lampMeshes
	if v421 and #v421 ~= 0 then
		local v422 = p417.model:GetAttribute("DRLStyle") == "Mode"
		local v423 = p417:paintBands()
		local v424 = math.max(v423, 2)
		local v425 = workspace:GetServerTimeNow()
		for _, v426 in v421 do
			local v427, v428 = p417:lampState(v426.side, p418)
			v426.part.Transparency = v427 == "off" and 1 or 0
			v426.light.Enabled = v427 == "amber"
			if v427 == "off" then
				v426.state = "off"
			else
				local v429 = #v426.colors
				local v430 = false
				if v427 == "custom" then
					if p420 or v426.state ~= "custom" then
						for v431, v432 in v426.colors do
							local v433 = (v431 - 0.5) / v429
							local v434
							if v422 then
								v434 = p417:modeSample(v433, v426.side, v425)
							elseif p419 then
								v434 = p419(1 + v433 * (v424 - 1))
							else
								v434 = v_u_16
							end
							v426.dark[v431] = v434 == nil
							if not v434 then
								continue
							end
							v426.em:SetColor(v432, v434)
						end
					end
					for v435 = 1, v429 do
						if not v426.dark[v435] then
							continue
						end
						v430 = true
					end
				else
					local v436
					if v427 == "amber" then
						v436 = v_u_5.signalColor(p417.model)
					else
						v436 = v_u_16
					end
					if v426.state ~= v427 or v426.tint ~= v436 then
						v426.tint = v436
						v426.light.Color = v436
						for v437, v438 in v426.colors do
							v426.dark[v437] = false
							v426.em:SetColor(v438, v436)
						end
					end
				end
				v426.state = v427
				if v428 >= 1 and (not v430 and v426.full) then
					continue
				end
				local v439
				if v428 >= 1 then
					v439 = not v430
				else
					v439 = false
				end
				v426.full = v439
				for _, v440 in v426.entries do
					if not v440.own then
						continue
					end
					local v441
					if v440.u <= v428 then
						v441 = not v426.dark[v440.bin]
					else
						v441 = false
					end
					if v441 == v440.shown then
						continue
					end
					v440.shown = v441
					local v442 = v426.em
					local v443 = v440.v
					local v444
					if v441 then
						v444 = v440.p
					else
						v444 = v440.sunk
					end
					v442:SetPosition(v443, v444)
				end
			end
		end
	end
end
function v_u_21.rainbowGlassParts(p445) -- name: rainbowGlassParts
	if p445.rainbowGlass == nil then
		p445.rainbowGlass = {}
		local v446 = p445.model:GetAttribute("RainbowGlass")
		if type(v446) == "string" then
			for v447 in v446:gmatch("[^,]+") do
				local v448 = p445.model:FindFirstChild(v447:match("^%s*(.-)%s*$"), true)
				if not (v448 and v448:IsA("BasePart")) then
					continue
				end
				local v449 = p445.rainbowGlass
				local v450 = {
					["part"] = v448,
					["transparency"] = v448.Transparency
				}
				table.insert(v449, v450)
			end
		end
	end
	return p445.rainbowGlass
end
function v_u_21.updateRainbowSkins(p451, p452, p453) -- name: updateRainbowSkins
	-- upvalues: (copy) v_u_5, (copy) v_u_16
	if p452 ~= p451.rainbowClearMode then
		p451.rainbowClearMode = p452
		for _, v454 in p451.rainbowClear do
			local v455
			if p452 == "custom" then
				v455 = true
			elseif p452 == "on" then
				v455 = v454.onWhite
			else
				v455 = false
			end
			local v456 = v454.part
			local v457
			if v455 then
				v457 = v454.clear
			else
				v457 = v454.base
			end
			v456.Transparency = v457
		end
	end
	local v458 = p451.rainbowSkins
	if #v458 == 0 and not p451.rainbowLights then
		return
	elseif p452 == "custom" then
		p451.rainbowSkinsOn = true
		p451.rainbowWhiteOn = nil
		p451.skinsWhite = false
		local v459 = p451.model:GetAttribute("RainbowGlassTransparency") or 1
		for _, v460 in p451:rainbowGlassParts() do
			v460.part.Transparency = v459
		end
		local v461 = p451.model:GetAttribute("DRLStyle") or "Rainbow"
		local v462 = p451.indicatorMode or "Off"
		local v463 = workspace:GetServerTimeNow()
		local v464 = os.clock() * 0.55
		local v465 = p451:paintBands()
		local v466 = math.max(v465, 2)
		for _, v467 in v458 do
			if v467.signal and (v462 == "Hazard" or (v462 == v467.signalSide or v467.signalSide == "Both" and v462 ~= "Off") or p451.wasFlashing) then
				v467.drawnT = nil
				v467.drawnColor = nil
			else
				local v468
				if v461 == "Rainbow" then
					v468 = Color3.fromHSV((0.15 + v467.u * 0.9 - v464) % 1, 0.9, 1)
				elseif v461 == "Mode" then
					v468 = p451:modeSample(v467.u, v467.side or "Right", v463, true)
				elseif p453 then
					v468 = p453(1 + v467.u * (v466 - 1))
				else
					v468 = p453
				end
				local v469 = v468 and 0 or 1
				if v469 ~= v467.drawnT then
					v467.part.Transparency = v469
					v467.drawnT = v469
				end
				if not v468 or v468 == v467.drawnColor then
					continue
				end
				v467.part.Color = v468
				v467.drawnColor = v468
			end
		end
		for _, v470 in p451.rainbowLights or {} do
			local v471
			if v462 == "Hazard" or v462 == v470.side then
				if p451.blinkLit and p451.model:GetAttribute("RainbowLightSignal") ~= false then
					v471 = v_u_5.signalColor(p451.model)
				else
					v471 = nil
				end
			elseif v461 == "Rainbow" then
				v471 = Color3.fromHSV((0.15 + v470.u * 0.9 - v464) % 1, 0.9, 1)
			elseif v461 == "Mode" then
				v471 = p451:modeSample(v470.u, v470.side or "Right", v463, true)
			elseif p453 then
				v471 = p453(1 + v470.u * (v466 - 1))
			else
				v471 = p453
			end
			v470.light.Enabled = v471 ~= nil
			if not v471 then
				continue
			end
			v470.light.Color = v471
		end
	else
		local v472 = p452 == "on"
		if p451.rainbowSkinsOn or v472 ~= p451.rainbowWhiteOn then
			p451.rainbowSkinsOn = false
			p451.rainbowWhiteOn = v472
			for _, v473 in p451.rainbowLights or {} do
				v473.light.Enabled = false
			end
			for _, v474 in p451:rainbowGlassParts() do
				v474.part.Transparency = v474.transparency
			end
			local v475 = v_u_5.signalColor(p451.model)
			for _, v476 in v458 do
				if v476.onWhite and (v472 and not v476.signal) then
					v476.part.Color = v_u_16
					v476.part.Transparency = 0
				else
					v476.part.Color = v475
					if not v476.signal or v476.onWhite then
						v476.part.Transparency = 1
					end
				end
				v476.drawnT = nil
				v476.drawnColor = nil
			end
			p451.skinsWhite = v472
			p451.blinkLit = nil
		end
	end
end
function v_u_21.updateIndicators(p477) -- name: updateIndicators
	-- upvalues: (copy) v_u_5, (copy) v_u_16
	local v478 = p477.model:GetAttribute("Indicator") or "Off"
	local v479 = os.clock()
	local v480 = false
	for _, v481 in p477.flashes or {} do
		if v481[1] > v479 or v479 >= v481[2] then
			continue
		end
		v480 = true
	end
	if v478 ~= p477.indicatorMode then
		p477.indicatorMode = v478
		p477.blinkStart = os.clock()
		p477.blinkLit = nil
		p477:click(p477.switchClick, p477.switchClick2D, v478 == "Off" and 0.85 or 1)
	end
	local v482, v483 = v_u_5.blinkAt(p477.model, os.clock() - p477.blinkStart)
	if v480 then
		v482 = v480
	elseif v478 == "Off" then
		v482 = false
	end
	local v484 = (v483 or 1) / 0.55
	local v485 = math.clamp(v484, 0, 1)
	local v486 = p477.hasSweepLamps == true and (v482 and not v480)
	if v486 then
		v486 = v485 < 1
	end
	local v487 = v_u_5.signalColor(p477.model)
	local v488 = v482 ~= p477.blinkLit and true or v480 ~= (p477.wasFlashing == true)
	if v488 or (v487 ~= p477.signalShown or (v486 or p477.sweepWas)) then
		p477.sweepWas = v486
		p477.signalShown = v487
		p477.wasFlashing = v480
		if v488 and (v478 ~= "Off" and (p477.blinkLit ~= nil and v479 - (p477.clickedAt or 0) >= 0.09)) then
			p477.clickedAt = v479
			p477:click(p477.blinkClick, p477.blinkClick2D, v482 and 1 or 0.82)
		end
		p477.blinkLit = v482
		for _, v489 in p477.indicatorLamps do
			local v490
			if v489.side == v478 then
				v490 = true
			elseif v489.side == "Both" then
				v490 = v478 == "Left" and true or v478 == "Right"
			else
				v490 = false
			end
			local v491
			if v482 then
				if v480 or (v478 == "Hazard" or v490) then
					v491 = v489.u == nil and true or (v480 or v489.u <= v485)
				else
					v491 = v490
				end
			else
				v491 = v482
			end
			local v492 = v489.part
			if v489.kind == "glow" then
				local v493 = not v491 and (v489.onWhite and (p477.skinsWhite == true and not v480))
				if v493 then
					if v478 == "Hazard" then
						v493 = false
					else
						v493 = not v490
					end
				end
				v492.Transparency = (v491 or v493) and 0 or 1
				local v494
				if v493 then
					v494 = v_u_16
				else
					v494 = v487
				end
				v492.Color = v494
				if v489.source then
					v489.source.Transparency = v491 and 1 or v489.sourceTransparency
				end
			elseif v489.kind == "lens" then
				if v491 then
					v492.Material = Enum.Material.Neon
					v492.Color = v487
				else
					v492.Material = Enum.Material[v492:GetAttribute("BaseMaterial") or "SmoothPlastic"]
					v492.Color = v492:GetAttribute("BaseColor") or v492.Color
				end
			elseif v489.kind == "bulb" then
				local v495 = v489.running and (v478 ~= "Hazard" and not v490)
				if v495 then
					v495 = p477.model:GetAttribute("EngineOn") == true
				end
				v492.Transparency = (v491 or v495) and 0 or 1
				local v496
				if v495 then
					v496 = v_u_16
				else
					v496 = v487
				end
				v492.Color = v496
			end
			if v489.light then
				v489.light.Enabled = v491
				v489.light.Color = v487
			end
			local v497 = p477.skinOf
			if v497 then
				v497 = p477.skinOf[v492]
			end
			if not v497 then
				continue
			end
			v497.drawnT = nil
			v497.drawnColor = nil
		end
	end
end
function v_u_21.groundCompression(p498, p499, p500) -- name: groundCompression
	-- upvalues: (copy) v_u_5
	local v501 = p500 + v_u_5.SUSP_EXTEND + 0.5
	local v502 = workspace
	local v503 = p499 + Vector3.new(0, 1, 0)
	local v504 = -(v501 + 1)
	local v505 = v502:Raycast(v503, Vector3.new(0, v504, 0), p498.rayParams)
	if v505 then
		return p500 - (p499.Y - v505.Position.Y)
	else
		return -v_u_5.SUSP_EXTEND
	end
end
function v_u_21.stepSuspension(p506, p507) -- name: stepSuspension
	-- upvalues: (copy) v_u_5
	local v508 = p506.chassis
	local v509, v510
	if (v508.Position - workspace.CurrentCamera.CFrame.Position).Magnitude < 300 and (p506.frontHub and (p506.rearHub and v508.CFrame.UpVector.Y > 0.75)) then
		local v511 = p506.seat.Occupant
		if v511 then
			v511 = v511.Parent
		end
		local v512 = p506.model:FindFirstChild("PassengerSeat")
		local v513 = v512 and v512.Occupant
		if v513 then
			v513 = v512.Occupant.Parent
		end
		if v511 ~= p506.rider or v513 ~= p506.pillion then
			p506.rider = v511
			p506.pillion = v513
			p506.rayParams.FilterDescendantsInstances = { p506.model, v511 or p506.model, v513 or p506.model }
		end
		local v514, v515 = v_u_5.lowerDrops(p506.model)
		local v516 = v508.CFrame
		local v517 = not p506.steerMotor and Vector3.new(0, 1, 0) or p506.steerMotor.C0.UpVector
		local v518 = p506.frontHub.WorldPosition + v516:VectorToWorldSpace(v517 * (v514 / p506.forkY))
		local v519 = p506.rearHub.WorldPosition + v516.UpVector * v515
		local v520, v521 = v_u_5.compressionTravel(p506.model)
		local v522 = p506:groundCompression(v518, p506.frontRadius)
		local v523 = -v_u_5.SUSP_EXTEND
		v509 = math.clamp(v522, v523, v520)
		local v524 = p506:groundCompression(v519, p506.rearRadius)
		local v525 = -v_u_5.SUSP_EXTEND
		v510 = math.clamp(v524, v525, v521)
	else
		v509 = 0
		v510 = 0
	end
	local v526 = v_u_5.alpha(35, p507)
	p506.compF = p506.compF + (v509 - p506.compF) * v526
	p506.compR = p506.compR + (v510 - p506.compR) * v526
	local v527 = p506.compF / p506.forkY
	local v528 = Vector3.new(0, v527, 0)
	local v529 = p506.compR
	local v530 = Vector3.new(0, v529, 0)
	local v531 = not p506.frontMotor and Vector3.new(0, 0, 0) or p506.frontMotor.C0:VectorToObjectSpace(v528)
	local v532 = not p506.rearMotor and Vector3.new(0, 0, 0) or p506.rearMotor.C0:VectorToObjectSpace(v530)
	if p506.frontSuspension then
		p506.frontSuspension.Transform = CFrame.new(p506.frontSuspension.C0:VectorToObjectSpace(v528))
	end
	if p506.rearSuspension then
		p506.rearSuspension.Transform = CFrame.new(p506.rearSuspension.C0:VectorToObjectSpace(v530))
	end
	return v531, v532
end
function v_u_21.updateScrape(p533) -- name: updateScrape
	-- upvalues: (copy) v_u_6
	local v534 = p533.chassis
	local v535 = p533.model:GetAttribute("CrashedAt") ~= nil
	local v536 = v534.AssemblyLinearVelocity
	local v537 = v536.X
	local v538 = v536.Z
	local v539 = Vector3.new(v537, 0, v538).Magnitude
	local v540 = 0
	local v541 = nil
	if v535 and (v539 > 4 and v534.CFrame.UpVector.Y < 0.75) then
		local v542 = workspace:Raycast(v534.Position, Vector3.new(0, -4, 0), p533.rayParams)
		if v542 then
			v541 = v542.Position + Vector3.new(0, 0.15, 0)
			local v543 = v539 / 60
			v540 = math.clamp(v543, 0.15, 1)
		end
	end
	if v540 > 0 and not p533.scraper then
		p533.scraper = v_u_6.scraper()
	end
	if p533.scraper then
		p533.scraper:update(v540, v541 or v534.Position, -v536.Unit)
		if v540 <= 0 and not v535 then
			p533.scraper:destroy()
			p533.scraper = nil
		end
	end
end
function v_u_21.forwardSpeed(p544) -- name: forwardSpeed
	return p544.chassis.Anchored and 0 or p544.chassis.AssemblyLinearVelocity:Dot(p544.chassis.CFrame.LookVector)
end
function v_u_21.stepJoints(p545, p546) -- name: stepJoints
	-- upvalues: (copy) v_u_5
	local v547 = p545:forwardSpeed()
	local v548 = p545.seat.Occupant ~= nil
	p545.frontAngle = (p545.frontAngle - v547 / p545.frontRadius * p546) % 6.283185307179586
	local v549 = v_u_5.freeRev(p545.model, p545.seat) * v_u_5.FREE_REV_SPIN
	p545.revSpin = (p545.revSpin or 0) + (v549 - (p545.revSpin or 0)) * v_u_5.alpha((p545.revSpin or 0) < v549 and 2.5 or 0.8, p546)
	p545.rearAngle = (p545.rearAngle - (v547 + p545.revSpin) / p545.rearRadius * p546) % 6.283185307179586
	local v550, v551 = p545:stepSuspension(p546)
	if p545.frontMotor then
		p545.frontMotor.Transform = CFrame.new(v550) * CFrame.Angles(p545.frontAngle, 0, 0)
	end
	if p545.rearMotor then
		p545.rearMotor.Transform = CFrame.new(v551) * CFrame.Angles(p545.rearAngle, 0, 0)
	end
	local v552 = (not v548 and 0 or p545.seat.SteerFloat) * v_u_5.maxSteer(v547)
	p545.visualSteer = p545.visualSteer + (v552 - p545.visualSteer) * v_u_5.alpha(10, p546)
	if p545.steerMotor then
		p545.steerMotor.Transform = CFrame.Angles(0, -p545.visualSteer, 0)
	end
	local v553
	if v548 then
		local v554 = p545.seat.ThrottleFloat
		v553 = math.max(v554, 0)
	else
		v553 = 0
	end
	p545.twist = p545.twist + (v553 - p545.twist) * v_u_5.alpha(14, p546)
	if p545.gripRight then
		local v555 = p545.gripRight
		local v556 = p545.gripRightBase
		local v557 = CFrame.Angles
		local v558 = p545.gripTilt
		local v559 = 0.8726646259971648 * p545.twist
		v555.CFrame = v556 * v557(math.max(v558, v559), 0, 0)
	end
end
local function v_u_563(p560, p561) -- name: setVisible
	for _, v562 in p560 do
		v562.Transparency = p561 and (v562:GetAttribute("BaseTransparency") or 0) or 1
	end
end
local function v_u_569(p564, p565, p566, p567) -- name: accPartShown
	-- upvalues: (copy) v_u_26
	if p567 and p564 then
		local v568 = not p564[p566] and p566.Parent
		if v568 then
			v568 = p564[p566.Parent]
		end
		if v568 then
			if v568.hide and v_u_26(p565, v568.hide) then
				return false
			else
				return (not v568.only or v_u_26(p565, v568.only)) and true or false
			end
		else
			return p567
		end
	else
		return p567
	end
end
function v_u_21.stepFrames(p570, p571) -- name: stepFrames
	local v572 = #p570.frames
	if v572 == 0 then
		return
	elseif p571 then
		if not p570.framesShown then
			p570.framesShown = true
			for _, v573 in p570.frameOutline do
				v573.Transparency = 1
			end
		end
		local v574 = p570.model:GetAttribute("DRLFrameStep") or 0.1
		local v575 = os.clock() / v574
		for v576, v577 in p570.frames do
			local v578 = (v575 - (v576 - 1)) % v572
			if v578 >= 1 then
				v578 = v578 >= 3 and 0 or 1 - (v578 - 1) / 2
			end
			v577.Transparency = 1 - v578
		end
	elseif p570.framesShown then
		p570.framesShown = false
		for _, v579 in p570.frames do
			v579.Transparency = 1
		end
		for _, v580 in p570.frameOutline do
			v580.Transparency = 0
		end
	end
end
function v_u_21.stepSeatLid(p581, p582) -- name: stepSeatLid
	local v583 = p581.model:GetAttribute("SeatOpen") == true and 1 or 0
	if p581.lidTarget ~= nil and v583 ~= p581.lidTarget then
		local v584 = p581.model:GetAttribute(v583 == 1 and "SoundSeatOpen" or "SoundSeatClose")
		if typeof(v584) == "string" and v584 ~= "" then
			p581.lidSounds = p581.lidSounds or {}
			local v585 = p581.lidSounds[v584] or p581:makeSound("PCX160_SeatLid", v584, 1.2, p581.chassis)
			p581.lidSounds[v584] = v585
			v585.TimePosition = 0
			v585:Play()
		end
	end
	p581.lidTarget = v583
	if p581.lidT ~= v583 then
		local v586 = p581.lidT < v583 and 1.5 or 2.4
		local v587 = p581.lidT
		local v588 = v583 - p581.lidT
		local v589 = v587 + math.sign(v588) * v586 * (p582 or 0.016666666666666666)
		p581.lidT = math.clamp(v589, 0, 1)
		local v590 = p581.lidT * p581.lidT * (3 - 2 * p581.lidT)
		local v591 = p581.model:GetAttribute("SeatLidAngle") or 70
		local v592 = math.rad(v591)
		p581.lidMotor.C0 = p581.lidBase * CFrame.Angles(-v592 * v590, 0, 0)
		local v593 = p581.lidT > 0.02
		if v593 ~= p581.binShown then
			p581.binShown = v593
			for _, v594 in p581.bins do
				v594.Transparency = v593 and 0 or 1
				local v595 = v594:FindFirstChildWhichIsA("PointLight")
				if not v595 then
					continue
				end
				v595.Enabled = v593
			end
		end
	end
end
function v_u_21.update(p596, p597) -- name: update
	-- upvalues: (copy) v_u_563, (copy) v_u_26, (copy) v_u_5, (copy) v_u_569, (copy) v_u_10, (copy) v_u_8, (copy) v_u_15, (copy) v_u_161
	local v598 = p596.model
	if p596.lidMotor then
		p596:stepSeatLid(p597)
	end
	local v599 = p596.seat.Occupant ~= nil
	local v600 = v598:GetAttribute("StandDown") == false and "Up" or (v598:GetAttribute("StandType") == "Center" and "Center" or "Side")
	local v601
	if v600 == "Center" then
		v601 = p596.chassis.Anchored
	else
		v601 = false
	end
	if v600 ~= p596.stand or v601 ~= p596.centerShown then
		p596.stand = v600
		p596.centerShown = v601
		v_u_563(p596.kickstandUp, v600 ~= "Side")
		v_u_563(p596.kickstandDown, v600 == "Side")
		for _, v602 in p596.centerUp do
			v602.Transparency = 1
		end
		v_u_563(p596.centerDown, v601)
	end
	local v603 = v598:GetAttribute("ShowMirrors") == true
	if v603 ~= p596.mirrorsShown then
		p596.mirrorsShown = v603
		v_u_563(p596.mirrors, v603)
	end
	for v604, v605 in p596.accessories do
		local v606 = v604:match("^Hide:(.+)$")
		local v607
		if v606 then
			v607 = v_u_26(v598, v606)
		else
			v607 = v598:GetAttribute("Acc_" .. v604) == true
		end
		local v608
		if v606 then
			v608 = nil
		else
			v608 = v_u_5.accessory(v604)
		end
		local v609
		if v606 == nil then
			if v608 == nil then
				v609 = false
			else
				v609 = v608.remove == true
			end
		else
			v609 = true
		end
		if v609 then
			v607 = not v607
		end
		local v610 = p596.accHides[v604]
		if v610 and v_u_26(v598, v610) then
			v607 = false
		end
		local v611 = p596.accRuleKeys
		if v611 then
			v611 = p596.accRuleKeys[v604]
		end
		local v612
		if v611 then
			local v613 = { (tostring(v607)) }
			for v615 in v611:gmatch("[^,%s]+") do
				if v615:sub(1, 7) ~= "Carbon_" then
					local v615 = "Acc_" .. v615
				end
				local v616 = v598:GetAttribute(v615) == true and "1" or "0"
				table.insert(v613, v616)
			end
			v612 = table.concat(v613)
		else
			v612 = v607
		end
		if v609 then
			local v617 = 0
			for _, v618 in v605 do
				if not v618:IsA("BasePart") then
					continue
				end
				v617 = v617 + #v618:GetChildren()
			end
			p596.accKids = p596.accKids or {}
			if v612 == p596.accShown[v604] and v617 == p596.accKids[v604] then
				break
			end
			p596.accShown[v604] = v612
			p596.accKids[v604] = v617
			for _, v619 in v605 do
				if not v619:IsA("BasePart") then
					continue
				end
				local v620 = v_u_569(p596.accRules, v598, v619, v607)
				v619.Transparency = v620 and (v619:GetAttribute("BaseTransparency") or 0) or 1
				for _, v621 in v619:GetChildren() do
					if not v621:IsA("Decal") then
						continue
					end
					if v621:GetAttribute("BaseTransparency") == nil then
						v621:SetAttribute("BaseTransparency", v621.Transparency)
					end
					v621.Transparency = not v620 and 1 or v621:GetAttribute("BaseTransparency")
				end
			end
		else
			if v612 == p596.accShown[v604] then
				continue
			end
			p596.accShown[v604] = v612
			if v611 then
				for _, v622 in v605 do
					v622.Transparency = v_u_569(p596.accRules, v598, v622, v607) and (v622:GetAttribute("BaseTransparency") or 0) or 1
				end
			else
				v_u_563(v605, v607)
			end
		end
	end
	if p596.exhaustTip then
		local v623 = p596.tipBase
		for _, v624 in p596.tipAlts do
			if v598:GetAttribute("Acc_" .. v624.key) ~= true then
				continue
			end
			v623 = v624.pos
		end
		if p596.exhaustTip.Position ~= v623 then
			p596.exhaustTip.Position = v623
		end
	end
	local v625 = v598:GetAttribute("ShieldOff") ~= true
	if v625 ~= p596.shieldShown then
		p596.shieldShown = v625
		v_u_563(p596.shields, v625)
	end
	local v626 = v598:GetAttribute("EngineOn") == true
	if v626 and not p596.engineWas then
		p596.welcomeAt = os.clock()
		local v627 = v598:GetAttribute("AnswerBackFlashes")
		if typeof(v627) == "string" then
			p596.flashes = {}
			for v628 in v627:gmatch("[%d%.]+") do
				local v629 = p596.welcomeAt + tonumber(v628)
				local v630 = p596.flashes
				local v631 = { v629, v629 + 0.22 }
				table.insert(v630, v631)
			end
		end
	end
	p596.engineWas = v626
	local v632 = v626 and (v598:GetAttribute("RainbowOn") == true and "custom" or "on") or "off"
	if v632 ~= p596.drlMode then
		p596.drlMode = v632
		p596.blinkLit = nil
		if p596.customGuide then
			p596.stripMode = v632 == "custom"
			if not p596.stripMode then
				for _, v633 in p596.drlBeams do
					v633.part.Transparency = 1
					v633.drawnT = nil
					v633.drawnColor = nil
					v633.drawnMaterial = nil
					v633.drawnOn = nil
					v633.drawnC0 = nil
					v633.drawnC1 = nil
				end
			end
		end
		for _, v634 in p596.bands do
			if v634.twin then
				v634.part.Material = Enum.Material.Neon
				v634.part.Transparency = v632 == "custom" and not p596.stripMode and 0.2 or 1
			elseif v634.skin then
				v634.part.Transparency = (v632 == "off" or v634.customOnly and v632 ~= "custom") and 1 or 0
				v634.part.Color = Color3.new(1, 1, 1)
			elseif p596.stripMode and not v634.stayLit then
				v634.part.Material = Enum.Material.SmoothPlastic
				local v635 = v634.part
				local v636
				if v632 == "on" then
					v636 = v_u_10
				else
					v636 = v_u_8
				end
				v635.Color = v636
			else
				local v637 = v632 ~= "off" and v634.whiteOnly
				if v637 then
					v637 = v632 == "custom"
				end
				local v638 = v634.part
				local v639
				if v637 then
					v639 = Enum.Material.SmoothPlastic
				else
					v639 = Enum.Material.Neon
				end
				v638.Material = v639
				local v640 = v634.part
				local v641
				if v637 then
					v641 = v_u_8
				else
					v641 = Color3.new(1, 1, 1)
				end
				v640.Color = v641
			end
		end
		if p596.headlight then
			p596.headlight.Enabled = v626
		end
		for _, v642 in p596.headTwins do
			local v643 = v642.part:GetAttribute("GlowTransparency")
			v642.part.Transparency = v626 and (v643 or 0) or 1
			v642.part.Color = v642.color or v_u_15
			for _, v644 in v642.glows or {} do
				v644.Enabled = v626
			end
			for _, v645 in v642.lights or {} do
				v645.Enabled = v626
			end
			if v642.source then
				v642.source.Transparency = v626 and not v643 and 1 or v642.sourceTransparency
			end
			if not v642.glass then
				break
			end
			local v646 = v642.glassLit
			if type(v646) ~= "number" then
				break
			end
			local v647 = v642.glass
			local v648
			if v626 then
				v648 = v642.glassLit
			else
				v648 = v642.glassTransparency
			end
			v647.Transparency = v648
		end
		if p596.drlGlow then
			p596.drlGlow.Enabled = v626
			p596.drlGlow.Color = Color3.new(1, 1, 1)
		end
		if v632 == "off" then
			for _, v649 in p596.drlBeams do
				v_u_161(v649, false)
			end
		end
		for _, v650 in p596.rainbowTextures do
			v650.texture.Transparency = 1
		end
		p596.rainbowShown = nil
	end
	local v651 = p596:forwardSpeed()
	local v652
	if v599 then
		v652 = p596.seat.ThrottleFloat < 0
	else
		v652 = v599
	end
	local v653
	if v599 then
		v653 = v651 < -0.5
	else
		v653 = v599
	end
	local v654 = nil
	p596.frontPaint = nil
	p596:updateIndicators()
	local v655 = workspace.CurrentCamera
	local v656 = v655 == nil and true or (p596.chassis.Position - v655.CFrame.Position).Magnitude < 260
	if v632 == "on" and (p596.stripMode and v656) then
		p596:drawStrip(nil)
	end
	if v632 ~= "off" and not p596.stripMode then
		p596:signalSkins()
	end
	if v632 == "custom" then
		local v657 = p596:drlPainter()
		p596.frontPaint = v657
		if v656 then
			local v658 = Color3.new(0, 0, 0)
			local v659 = v598:GetAttribute("DRLStyle") == "Mode"
			local v660 = workspace:GetServerTimeNow()
			for _, v661 in p596.bands do
				if v661.twin or (v661.signalling or v661.whiteOnly) then
					continue
				end
				local v662 = nil
				if v659 and (p596.maxBand <= 1 and not v661.skin) then
					local v663 = 0
					for v664 = 0, 8 do
						local v665 = p596:modeSample(v664 / 8, v661.side or "Right", v660)
						local v666
						if v665 then
							local v667 = v665.R
							local v668 = v665.G
							local v669 = v665.B
							v666 = math.max(v667, v668, v669) or 0
						else
							v666 = 0
						end
						if v663 >= v666 then
							continue
						end
						v662 = v665
						v663 = v666
					end
				elseif v659 then
					v662 = p596:modeSample(v661.u or 0, v661.side or "Right", v660)
				else
					v662 = v657(v661.index)
				end
				if v661.skin and v659 then
					v661.part.Transparency = v662 and 0 or 1
				end
				local v670 = v662 or v658
				local v671 = v661.part
				if p596.stripMode and not v661.stayLit then
					v670 = v670:Lerp(v658, 0.8)
				end
				v671.Color = v670
			end
		end
		local v672 = (v598:GetAttribute("DRLStyle") or "Rainbow") == "Rainbow"
		p596:stepFrames(v672 and v656)
		if v672 ~= p596.rainbowShown then
			p596.rainbowShown = v672
			for _, v673 in p596.rainbowTextures do
				v673.texture.Transparency = v672 and 0 or 1
			end
		end
		if v672 then
			local v674 = os.clock() * 0.55 % 1
			for _, v675 in p596.rainbowTextures do
				v675.texture.OffsetStudsV = v675.base + v675.sign * v674 * v675.texture.StudsPerTileV
			end
		end
		if p596.stripMode and v656 then
			p596:drawStrip(v657)
		end
		if v656 then
			p596:updateRainbowSkins(v632, v657)
		end
		p596:updateLampMeshes(v632, v657, v656)
		p596:updateLampTextures(v632, v657)
		local v676 = p596.maxBand / 2
		v654 = v657((math.ceil(v676)))
		if p596.drlGlow then
			p596.drlGlow.Color = v657(4):Lerp(Color3.new(1, 1, 1), 0.35)
		end
	end
	if v632 ~= "custom" then
		p596:stepFrames(false)
		p596:updateRainbowSkins(v632)
		p596:updateLampMeshes(v632, nil, v656)
		p596:updateLampTextures(v632)
	end
	local v677 = v652 or v653
	if v598:GetAttribute("TailLightOn") ~= true then
		v654 = nil
	end
	p596:updateTailLight(v626, v677, v654)
	p596:updateScrape()
	if p596.smoke then
		local v678
		if v599 then
			local v679 = p596.seat.ThrottleFloat
			v678 = math.max(v679, 0)
		else
			v678 = 0
		end
		p596.smoke.Rate = not v626 and 0 or v678 * 7 + 5
	end
end
function v_u_21.destroy(p680) -- name: destroy
	for _, v681 in p680.ownedSounds do
		v681:Destroy()
	end
	for _, v682 in p680.ownedObjects do
		v682:Destroy()
	end
	if p680.smoke then
		p680.smoke:Destroy()
	end
	if p680.scraper then
		p680.scraper:destroy()
		p680.scraper = nil
	end
	if p680.gripRight and p680.gripRightBase then
		p680.gripRight.CFrame = p680.gripRightBase
	end
end
return v_u_21