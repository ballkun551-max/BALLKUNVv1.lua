-- Path: ReplicatedStorage/ShopMechanicPose
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v1 = {}
local v_u_2 = {
	{
		"LowerTorso",
		"HumanoidRootPart",
		"RootRigAttachment",
		"root"
	},
	{
		"UpperTorso",
		"LowerTorso",
		"WaistRigAttachment",
		"waist"
	},
	{
		"Head",
		"UpperTorso",
		"NeckRigAttachment",
		"neck"
	},
	{
		"RightUpperArm",
		"UpperTorso",
		"RightShoulderRigAttachment",
		"rShoulder"
	},
	{
		"RightLowerArm",
		"RightUpperArm",
		"RightElbowRigAttachment",
		"rElbow"
	},
	{
		"RightHand",
		"RightLowerArm",
		"RightWristRigAttachment",
		"rWrist"
	},
	{
		"LeftUpperArm",
		"UpperTorso",
		"LeftShoulderRigAttachment",
		"lShoulder"
	},
	{
		"LeftLowerArm",
		"LeftUpperArm",
		"LeftElbowRigAttachment",
		"lElbow"
	},
	{
		"LeftHand",
		"LeftLowerArm",
		"LeftWristRigAttachment",
		"lWrist"
	},
	{
		"RightUpperLeg",
		"LowerTorso",
		"RightHipRigAttachment",
		"rHip"
	},
	{
		"RightLowerLeg",
		"RightUpperLeg",
		"RightKneeRigAttachment",
		"rKnee"
	},
	{
		"RightFoot",
		"RightLowerLeg",
		"RightAnkleRigAttachment",
		"rAnkle"
	},
	{
		"LeftUpperLeg",
		"LowerTorso",
		"LeftHipRigAttachment",
		"lHip"
	},
	{
		"LeftLowerLeg",
		"LeftUpperLeg",
		"LeftKneeRigAttachment",
		"lKnee"
	},
	{
		"LeftFoot",
		"LeftLowerLeg",
		"LeftAnkleRigAttachment",
		"lAnkle"
	}
}
local v_u_3 = {
	"RightFoot",
	"LeftFoot",
	"RightLowerLeg",
	"LeftLowerLeg"
}
function v1.rig(p4) -- name: rig
	-- upvalues: (copy) v_u_2, (copy) v_u_3
	local v5 = {
		["model"] = p4,
		["root"] = p4:FindFirstChild("HumanoidRootPart"),
		["joints"] = {},
		["followers"] = {},
		["sizes"] = {}
	}
	for _, v6 in v_u_2 do
		local v7 = p4:FindFirstChild(v6[1])
		local v8 = p4:FindFirstChild(v6[2])
		local v9
		if v8 then
			v9 = v8:FindFirstChild(v6[3])
		else
			v9 = v8
		end
		local v10
		if v7 then
			v10 = v7:FindFirstChild(v6[3])
		else
			v10 = v7
		end
		if not (v7 and (v8 and (v9 and v10))) then
			continue
		end
		local v11 = v5.joints
		local v12 = {
			["child"] = v7,
			["name"] = v6[1],
			["parent"] = v6[2],
			["key"] = v6[4],
			["c0"] = v9.CFrame,
			["c1inv"] = v10.CFrame:Inverse()
		}
		table.insert(v11, v12)
	end
	for _, v13 in v_u_3 do
		local v14 = p4:FindFirstChild(v13)
		if not v14 then
			continue
		end
		v5.sizes[v13] = v14.Size / 2
	end
	for _, v15 in p4:GetDescendants() do
		if not v15:IsA("BasePart") then
			continue
		end
		local v16 = v15:GetAttribute("Follow")
		local v17 = v15:GetAttribute("FollowOffset")
		if type(v16) ~= "string" or typeof(v17) ~= "CFrame" then
			continue
		end
		local v18 = v5.followers
		table.insert(v18, {
			["part"] = v15,
			["follow"] = v16,
			["offset"] = v17
		})
	end
	return v5
end
local v_u_19 = math.rad
function v1.solve(p20, p21, p22, p23) -- name: solve
	-- upvalues: (copy) v_u_19
	local v24 = {
		["HumanoidRootPart"] = p21
	}
	for _, v25 in p20.joints do
		local v26 = p22[v25.key]
		local v27
		if v26 then
			v27 = CFrame.Angles(v_u_19(v26[1] or 0), v_u_19(v26[2] or 0), (v_u_19(v26[3] or 0)))
		else
			v27 = CFrame.identity
		end
		v24[v25.name] = v24[v25.parent] * v25.c0 * v27 * v25.c1inv
	end
	if p23 then
		local v28 = (1 / 0)
		for v29, v30 in p20.sizes do
			local v31 = v24[v29]
			if not v31 then
				continue
			end
			for v32 = -1, 1, 2 do
				for v33 = -1, 1, 2 do
					local v34 = v32 * v30.X
					local v35 = v33 * v30.Y
					local v36 = -1 * v30.Z
					local v37 = (v31 * Vector3.new(v34, v35, v36)).Y
					local v38 = math.min(v28, v37)
					local v39 = v32 * v30.X
					local v40 = v33 * v30.Y
					local v41 = 1 * v30.Z
					local v42 = (v31 * Vector3.new(v39, v40, v41)).Y
					v28 = math.min(v38, v42)
				end
			end
		end
		local v43 = p23 - v28
		local v44 = Vector3.new(0, v43, 0)
		for v45, v46 in v24 do
			v24[v45] = v46 + v44
		end
	end
	local v47 = { p20.root }
	local v48 = { v24.HumanoidRootPart }
	for _, v49 in p20.joints do
		local v50 = v49.child
		table.insert(v47, v50)
		local v51 = v24[v49.name]
		table.insert(v48, v51)
	end
	for _, v52 in p20.followers do
		local v53 = v24[v52.follow]
		if not v53 then
			continue
		end
		local v54 = v52.part
		table.insert(v47, v54)
		local v55 = v53 * v52.offset
		table.insert(v48, v55)
	end
	return v47, v48
end
local v_u_56 = math.sin
v1.ANIMS = {}
function v1.ANIMS.wrench(p57) -- name: wrench
	-- upvalues: (copy) v_u_56
	local v58 = p57 % 5.5 < 4
	local v59 = v58 and 1 or 0.12
	local v60 = v_u_56(p57 * 2 * 3.141592653589793 * 1.3)
	return {
		["waist"] = { v_u_56(p57 * 1.7) * 2 + -30, 6, 0 },
		["neck"] = { v58 and -24 or -6, v58 and -8 or 14, 0 },
		["rShoulder"] = { v60 * 10 * v59 + 64, 0, v60 * 12 * v59 + -6 },
		["rElbow"] = { v_u_56(p57 * 2 * 3.141592653589793 * 1.3 + 0.8) * 22 * v59 + 36, 0, 0 },
		["rWrist"] = { 0, 0, v60 * 28 * v59 },
		["lShoulder"] = { v_u_56(p57 * 0.9) * 2 + 52, 0, 8 },
		["lElbow"] = { v_u_56(p57 * 1.1) * 3 + 46, 0, 0 },
		["rHip"] = { 98, -6, 0 },
		["rKnee"] = { -126, 0, 0 },
		["rAnkle"] = { 30, 0, 0 },
		["lHip"] = { 80, 10, 0 },
		["lKnee"] = { -118, 0, 0 },
		["lAnkle"] = { 36, 0, 0 }
	}
end
function v1.ANIMS.carry(p61) -- name: carry
	-- upvalues: (copy) v_u_56
	local v62 = v_u_56(p61 * 0.55)
	local v63 = v_u_56(p61 * 0.42 - 1)
	local v64 = math.max(0, v63)
	return {
		["waist"] = { v_u_56(p61 * 1.6) * 2 - v64 * 6, v62 * 14, 0 },
		["neck"] = { v64 * 8 + -16, v_u_56(p61 * 0.55 + 0.9) * 12, 0 },
		["rShoulder"] = { v64 * 20 + 36, 0, -14 },
		["rElbow"] = { 70 - v64 * 12, 0, 0 },
		["lShoulder"] = { v64 * 20 + 36, 0, 14 },
		["lElbow"] = { 70 - v64 * 12, 0, 0 },
		["lHip"] = { 3, 0, 0 },
		["lKnee"] = { -5, 0, 0 }
	}
end
return v1