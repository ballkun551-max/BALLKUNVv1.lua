-- Path: Players/ygggggg55551/PlayerScripts/ServerPanelClient
-- Class: LocalScript  true/Enum.RunContext.Legacy
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = require(game:GetService("ReplicatedStorage"):WaitForChild("NetSeal"))
local v_u_2 = game:GetService("Players")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("RunService")
local v5 = game:GetService("UserInputService")
local v6 = require(v3:WaitForChild("GameShared"))
local v_u_7 = require(v3:WaitForChild("RankShared"))
local v8 = v3:WaitForChild("GameUI")
local v_u_9 = require(v8:WaitForChild("Theme"))
local v_u_10 = require(v8:WaitForChild("Toast"))
local v_u_11 = v_u_2.LocalPlayer
local v_u_12 = v3:WaitForChild(v6.REMOTES):WaitForChild("ServerPanel")
local v_u_13 = v_u_9.isTouch()
local v_u_14 = v_u_13 and 64 or 60
local v_u_15 = v_u_13 and { 74, 74, 60 } or { 92, 92, 70 }
local v_u_16 = {
	["owner"] = "\224\185\128\224\184\136\224\185\137\224\184\178\224\184\130\224\184\173\224\184\135\224\185\128\224\184\139\224\184\180\224\184\163\224\185\140\224\184\159\224\184\167\224\184\181",
	["creator"] = "\224\184\132\224\184\163\224\184\181\224\185\128\224\184\173\224\185\128\224\184\149\224\184\173\224\184\163\224\185\140"
}
local v_u_17 = v_u_9.screen("ServerPanel", 60, v_u_11:WaitForChild("PlayerGui"))
local v_u_18 = v_u_9.button({
	["name"] = "ServerPanelOpen",
	["text"] = nil,
	["icon"] = "people",
	["grad"] = "gold",
	["textSize"] = 15,
	["anchor"] = nil,
	["position"] = nil,
	["size"] = nil,
	["parent"] = nil,
	["text"] = v_u_13 and "" or "\224\185\128\224\184\139\224\184\180\224\184\163\224\185\140\224\184\159",
	["anchor"] = Vector2.new(1, 0),
	["position"] = UDim2.new(1, -12, 0, v_u_13 and 56 or 12),
	["size"] = UDim2.fromOffset(v_u_13 and 46 or 100, 40),
	["parent"] = v_u_17
})
v_u_18.Visible = false
local v_u_19 = v_u_9.window({
	["name"] = "ServerPanelWindow",
	["gui"] = nil,
	["icon"] = "people",
	["grad"] = "gold",
	["title"] = "Server Panel",
	["sub"] = "",
	["size"] = nil,
	["max"] = nil,
	["gui"] = v_u_17,
	["size"] = Vector2.new(0.5, 0.8),
	["max"] = Vector2.new(680, 720)
})
local v20 = v_u_9.new("Frame", {
	["Name"] = "Search",
	["BackgroundColor3"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["BackgroundColor3"] = v_u_9.CARD_DARK,
	["Size"] = UDim2.new(1, -8, 0, 40),
	["Parent"] = v_u_19.body
})
v_u_9.corner(v20, 10)
local v_u_21 = v_u_9.border(v20, Color3.new(1, 1, 1), 0.82, 1.2)
local v_u_22 = v_u_9.new("TextBox", {
	["Name"] = "Box",
	["BackgroundTransparency"] = 1,
	["Text"] = "",
	["PlaceholderText"] = "\224\184\132\224\185\137\224\184\153\224\184\171\224\184\178\224\184\138\224\184\183\224\185\136\224\184\173\224\184\156\224\184\185\224\185\137\224\185\128\224\184\165\224\185\136\224\184\153",
	["PlaceholderColor3"] = nil,
	["ClearTextOnFocus"] = false,
	["FontFace"] = nil,
	["TextSize"] = 16,
	["TextColor3"] = nil,
	["TextXAlignment"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["PlaceholderColor3"] = Color3.fromRGB(110, 114, 130),
	["FontFace"] = v_u_9.FONT_BOLD,
	["TextColor3"] = v_u_9.TEXT,
	["TextXAlignment"] = Enum.TextXAlignment.Left,
	["Position"] = UDim2.fromOffset(12, 0),
	["Size"] = UDim2.new(1, -24, 1, 0),
	["Parent"] = v20
})
v_u_22.Focused:Connect(function()
	-- upvalues: (copy) v_u_21, (copy) v_u_9
	local v23 = v_u_21
	v_u_21.Color = v_u_9.YELLOW
	v23.Transparency = 0.2
end)
v_u_22.FocusLost:Connect(function()
	-- upvalues: (copy) v_u_21
	local v24 = v_u_21
	v_u_21.Color = Color3.new(1, 1, 1)
	v24.Transparency = 0.82
end)
local v_u_25 = v_u_9.new("ScrollingFrame", {
	["Name"] = "List",
	["BackgroundTransparency"] = 1,
	["BorderSizePixel"] = 0,
	["Position"] = nil,
	["Size"] = nil,
	["CanvasSize"] = nil,
	["AutomaticCanvasSize"] = nil,
	["ScrollingDirection"] = nil,
	["ScrollBarThickness"] = 5,
	["Parent"] = nil,
	["Position"] = UDim2.fromOffset(0, 50),
	["Size"] = UDim2.new(1, 0, 1, -50),
	["CanvasSize"] = UDim2.new(),
	["AutomaticCanvasSize"] = Enum.AutomaticSize.Y,
	["ScrollingDirection"] = Enum.ScrollingDirection.Y,
	["Parent"] = v_u_19.body
})
v_u_9.new("UIPadding", {
	["PaddingRight"] = UDim.new(0, 8),
	["PaddingBottom"] = UDim.new(0, 12),
	["Parent"] = v_u_25
})
v_u_9.new("UIListLayout", {
	["Padding"] = UDim.new(0, 8),
	["SortOrder"] = Enum.SortOrder.LayoutOrder,
	["Parent"] = v_u_25
})
local v_u_26 = v_u_9.text({
	["Name"] = "Empty",
	["Text"] = "\224\185\132\224\184\161\224\185\136\224\184\161\224\184\181\224\184\156\224\184\185\224\185\137\224\185\128\224\184\165\224\185\136\224\184\153\224\184\132\224\184\153\224\184\173\224\184\183\224\185\136\224\184\153\224\185\131\224\184\153\224\185\128\224\184\139\224\184\180\224\184\163\224\185\140\224\184\159\224\184\153\224\184\181\224\185\137",
	["TextSize"] = 15,
	["TextColor3"] = nil,
	["Size"] = nil,
	["LayoutOrder"] = 100000,
	["Visible"] = false,
	["Parent"] = nil,
	["TextColor3"] = v_u_9.TEXT_DIM,
	["Size"] = UDim2.new(1, 0, 0, 40),
	["Parent"] = v_u_25
})
local function v_u_28(p27) -- name: shieldOf
	-- upvalues: (copy) v_u_7, (copy) v_u_11
	return (v_u_7.isStaff(p27) or p27:GetAttribute("BanMenu") == true) and "\224\184\151\224\184\181\224\184\161\224\184\135\224\184\178\224\184\153" or (p27.UserId == workspace:GetAttribute("ServerPanelOwner") and "\224\185\128\224\184\136\224\185\137\224\184\178\224\184\130\224\184\173\224\184\135\224\185\128\224\184\139\224\184\180\224\184\163\224\185\140\224\184\159" or (p27:GetAttribute("ServerPanel") == "creator" and v_u_11:GetAttribute("ServerPanel") ~= "owner" and "\224\184\132\224\184\163\224\184\181\224\185\128\224\184\173\224\185\128\224\184\149\224\184\173\224\184\163\224\185\140" or nil))
end
local v_u_29 = 0
local v_u_30 = {}
local function v_u_34() -- name: paintMoves
	-- upvalues: (ref) v_u_29, (copy) v_u_30, (copy) v_u_9
	local v31 = v_u_29 - os.clock()
	local v32 = math.ceil(v31)
	for _, v33 in v_u_30 do
		if not v33[1].Parent then
			continue
		end
		if v32 > 0 then
			v_u_9.setButton(v33[1], "grey", ("\224\184\163\224\184\173 %d"):format(v32), v_u_9.TEXT_DIM)
		else
			v_u_9.setButton(v33[1], "gold", v33[2])
		end
	end
end
local v_u_35 = false
local v_u_36 = nil
local function v_u_50(p37, p38) -- name: act
	-- upvalues: (ref) v_u_35, (ref) v_u_29, (copy) v_u_10, (copy) v_u_1, (copy) v_u_12, (copy) v_u_34, (ref) v_u_36
	if v_u_35 then
		return
	elseif p37 == "Kick" or os.clock() >= v_u_29 then
		v_u_35 = true
		local v39 = p38.UserId
		local v40 = v_u_1.invoke
		local v41 = v_u_12
		local v42, v43, v44, v45 = pcall(v40, v41, p37, v39)
		local v46
		if v42 then
			v46 = v43 == true
		else
			v44 = "\224\184\149\224\184\180\224\184\148\224\184\149\224\185\136\224\184\173\224\185\128\224\184\139\224\184\180\224\184\163\224\185\140\224\184\159\224\185\128\224\184\167\224\184\173\224\184\163\224\185\140\224\185\132\224\184\161\224\185\136\224\185\132\224\184\148\224\185\137"
			v46 = false
			v45 = nil
		end
		v_u_35 = false
		if v44 then
			v_u_10.show(tostring(v44), v46 and "ok" or "error")
		end
		if p37 ~= "Kick" and (v46 or tonumber(v45)) then
			v_u_29 = os.clock() + (tonumber(v45) or 5)
			v_u_34()
			task.spawn(function()
				-- upvalues: (ref) v_u_29, (ref) v_u_34
				local v47 = v_u_29
				while v_u_29 == v47 and os.clock() < v_u_29 do
					task.wait(0.25)
					v_u_34()
				end
				v_u_34()
			end)
		end
		if v46 and p37 == "Kick" then
			task.delay(0.5, v_u_36)
		end
	else
		local v48 = v_u_10.show
		local v49 = v_u_29 - os.clock()
		v48(("\224\184\163\224\184\173\224\184\173\224\184\181\224\184\129 %d \224\184\167\224\184\180"):format((math.ceil(v49))), "error")
	end
end
local function v_u_74(p_u_51, p52) -- name: row
	-- upvalues: (copy) v_u_9, (copy) v_u_14, (copy) v_u_25, (copy) v_u_28, (copy) v_u_15, (copy) v_u_7, (copy) v_u_30, (copy) v_u_50, (ref) v_u_35, (copy) v_u_1, (copy) v_u_12, (copy) v_u_10, (ref) v_u_36
	local v53 = v_u_9.new("Frame", {
		["Name"] = nil,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.1,
		["Size"] = nil,
		["LayoutOrder"] = nil,
		["Parent"] = nil,
		["Name"] = "P_" .. p_u_51.UserId,
		["BackgroundColor3"] = v_u_9.CARD,
		["Size"] = UDim2.new(1, 0, 0, v_u_14),
		["LayoutOrder"] = p52,
		["Parent"] = v_u_25
	})
	v_u_9.corner(v53, 10)
	v_u_9.border(v53, Color3.new(1, 1, 1), 0.9, 1)
	local v54 = v_u_9.new("ImageLabel", {
		["Name"] = "Face",
		["BackgroundColor3"] = nil,
		["Size"] = nil,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Image"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_9.CARD_DARK,
		["Size"] = UDim2.fromOffset(44, 44),
		["AnchorPoint"] = Vector2.new(0, 0.5),
		["Position"] = UDim2.new(0, 8, 0.5, 0),
		["Image"] = ("rbxthumb://type=AvatarHeadShot&id=%d&w=48&h=48"):format(p_u_51.UserId),
		["Parent"] = v53
	})
	v_u_9.corner(v54, 8)
	local v55 = v_u_28(p_u_51)
	local v56 = v55 and 110 or v_u_15[1] + v_u_15[2] + v_u_15[3] + 20
	local v57 = p_u_51:GetAttribute("Rank")
	v_u_9.text({
		["Name"] = "Shown",
		["Text"] = nil,
		["TextSize"] = 17,
		["FontFace"] = nil,
		["TextXAlignment"] = nil,
		["TextTruncate"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Text"] = p_u_51.DisplayName,
		["FontFace"] = v_u_9.FONT_HEAVY,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["TextTruncate"] = Enum.TextTruncate.AtEnd,
		["Position"] = UDim2.new(0, 62, 0.5, -20),
		["Size"] = UDim2.new(1, -(70 + v56), 0, 22),
		["Parent"] = v53
	})
	v_u_9.text({
		["Name"] = "User",
		["Text"] = nil,
		["TextSize"] = 13,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["TextTruncate"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Text"] = "@" .. p_u_51.Name .. ((type(v57) ~= "string" or v57 == "Member") and "" or "  \194\183  " .. v_u_7.label(v57)),
		["TextColor3"] = v_u_9.TEXT_DIM,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["TextTruncate"] = Enum.TextTruncate.AtEnd,
		["Position"] = UDim2.new(0, 62, 0.5, 2),
		["Size"] = UDim2.new(1, -(70 + v56), 0, 18),
		["Parent"] = v53
	})
	local v58 = v_u_9.new("Frame", {
		["Name"] = "Actions",
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(1, 0.5),
		["Position"] = UDim2.new(1, -10, 0.5, 0),
		["Size"] = UDim2.fromOffset(v56, 40),
		["Parent"] = v53
	})
	v_u_9.new("UIListLayout", {
		["FillDirection"] = Enum.FillDirection.Horizontal,
		["HorizontalAlignment"] = Enum.HorizontalAlignment.Right,
		["VerticalAlignment"] = Enum.VerticalAlignment.Center,
		["Padding"] = UDim.new(0, 8),
		["SortOrder"] = Enum.SortOrder.LayoutOrder,
		["Parent"] = v58
	})
	if v55 then
		v_u_9.chip(v58, v55, v_u_9.GRAD.grey[1], {
			["Size"] = UDim2.fromOffset(0, 24)
		})
		return v53
	end
	local v59 = v_u_9.button({
		["name"] = "Goto",
		["text"] = "\224\184\167\224\184\178\224\184\155\224\185\132\224\184\155",
		["grad"] = "gold",
		["textSize"] = 15,
		["size"] = nil,
		["parent"] = nil,
		["size"] = UDim2.fromOffset(v_u_15[1], 38),
		["parent"] = v58
	})
	v59.LayoutOrder = 1
	local v60 = v_u_9.button({
		["name"] = "Bring",
		["text"] = "\224\184\148\224\184\182\224\184\135\224\184\161\224\184\178",
		["grad"] = "gold",
		["textSize"] = 15,
		["size"] = nil,
		["parent"] = nil,
		["size"] = UDim2.fromOffset(v_u_15[2], 38),
		["parent"] = v58
	})
	v60.LayoutOrder = 2
	local v_u_61 = v_u_9.button({
		["name"] = "Kick",
		["text"] = "\224\185\128\224\184\149\224\184\176",
		["grad"] = "red",
		["textSize"] = 15,
		["size"] = nil,
		["parent"] = nil,
		["size"] = UDim2.fromOffset(v_u_15[3], 38),
		["parent"] = v58
	})
	v_u_61.LayoutOrder = 3
	local v62 = v_u_30
	table.insert(v62, { v59, "\224\184\167\224\184\178\224\184\155\224\185\132\224\184\155" })
	local v63 = v_u_30
	table.insert(v63, { v60, "\224\184\148\224\184\182\224\184\135\224\184\161\224\184\178" })
	v59.Activated:Connect(function()
		-- upvalues: (ref) v_u_50, (copy) p_u_51
		v_u_50("Goto", p_u_51)
	end)
	v60.Activated:Connect(function()
		-- upvalues: (ref) v_u_50, (copy) p_u_51
		v_u_50("Bring", p_u_51)
	end)
	local v_u_64 = nil
	v_u_61.Activated:Connect(function()
		-- upvalues: (ref) v_u_64, (ref) v_u_9, (copy) v_u_61, (copy) p_u_51, (ref) v_u_35, (ref) v_u_1, (ref) v_u_12, (ref) v_u_10, (ref) v_u_36
		if v_u_64 and os.clock() - v_u_64 < 4 then
			v_u_64 = nil
			v_u_9.setButton(v_u_61, "red", "\224\185\128\224\184\149\224\184\176")
			local v65 = p_u_51
			if not v_u_35 then
				v_u_35 = true
				local v66 = v65.UserId
				local v67 = v_u_1.invoke
				local v68 = v_u_12
				local v69, v70, v71, _ = pcall(v67, v68, "Kick", v66)
				local v72
				if v69 then
					v72 = v70 == true
				else
					v71 = "\224\184\149\224\184\180\224\184\148\224\184\149\224\185\136\224\184\173\224\185\128\224\184\139\224\184\180\224\184\163\224\185\140\224\184\159\224\185\128\224\184\167\224\184\173\224\184\163\224\185\140\224\185\132\224\184\161\224\185\136\224\185\132\224\184\148\224\185\137"
					v72 = false
				end
				v_u_35 = false
				if v71 then
					v_u_10.show(tostring(v71), v72 and "ok" or "error")
				end
				if v72 then
					task.delay(0.5, v_u_36)
				end
			end
		else
			local v_u_73 = os.clock()
			v_u_64 = v_u_73
			v_u_9.setButton(v_u_61, "orange", "\224\184\162\224\184\183\224\184\153\224\184\162\224\184\177\224\184\153?")
			task.delay(4, function()
				-- upvalues: (ref) v_u_64, (copy) v_u_73, (ref) v_u_61, (ref) v_u_9
				if v_u_64 == v_u_73 and v_u_61.Parent then
					v_u_64 = nil
					v_u_9.setButton(v_u_61, "red", "\224\185\128\224\184\149\224\184\176")
				end
			end)
			return
		end
	end)
	return v53
end
v_u_36 = function(p75) -- name: build
	-- upvalues: (copy) v_u_25, (copy) v_u_30, (copy) v_u_22, (copy) v_u_2, (copy) v_u_11, (copy) v_u_4, (copy) v_u_74, (copy) v_u_26, (copy) v_u_19, (copy) v_u_16, (copy) v_u_34
	for _, v76 in v_u_25:GetChildren() do
		if not (v76:IsA("Frame") and v76.Name:match("^P_")) then
			continue
		end
		v76:Destroy()
	end
	table.clear(v_u_30)
	local v77 = string.lower((v_u_22.Text:gsub("^%s*@?", ""):gsub("%s*$", "")))
	local v78 = 0
	local v79 = {}
	for _, v80 in v_u_2:GetPlayers() do
		if v80 == v_u_11 or v80 == p75 then
			continue
		end
		v78 = v78 + 1
		if v77 ~= "" and not (string.lower(v80.Name):find(v77, 1, true) or string.lower(v80.DisplayName):find(v77, 1, true)) then
			continue
		end
		table.insert(v79, v80)
	end
	if v_u_4:IsStudio() then
		local v81 = workspace:GetAttribute("ZZPanelFake") or ""
		for v82, v83, v_u_84, v_u_85 in tostring(v81):gmatch("(%d+):([^:,]+):([^:,]*):([^:,]*)") do
			v78 = v78 + 1
			local v87 = {
				["UserId"] = tonumber(v82),
				["Name"] = v83,
				["DisplayName"] = v83,
				["GetAttribute"] = function(_, p86) -- name: GetAttribute
					-- upvalues: (copy) v_u_84, (copy) v_u_85
					if p86 == "Rank" then
						return v_u_84 == "" and "Member" or v_u_84
					elseif p86 == "ServerPanel" and v_u_85 ~= "" then
						return v_u_85
					else
						return nil
					end
				end
			}
			if v77 ~= "" and not string.lower(v83):find(v77, 1, true) then
				continue
			end
			table.insert(v79, v87)
		end
	end
	table.sort(v79, function(p88, p89)
		return string.lower(p88.DisplayName) < string.lower(p89.DisplayName)
	end)
	for v90, v91 in v79 do
		v_u_74(v91, v90)
	end
	v_u_26.Text = v78 == 0 and "\224\185\132\224\184\161\224\185\136\224\184\161\224\184\181\224\184\156\224\184\185\224\185\137\224\185\128\224\184\165\224\185\136\224\184\153\224\184\132\224\184\153\224\184\173\224\184\183\224\185\136\224\184\153\224\185\131\224\184\153\224\185\128\224\184\139\224\184\180\224\184\163\224\185\140\224\184\159\224\184\153\224\184\181\224\185\137" or "\224\185\132\224\184\161\224\185\136\224\184\158\224\184\154\224\184\138\224\184\183\224\185\136\224\184\173\224\184\153\224\184\181\224\185\137"
	v_u_26.Visible = #v79 == 0
	v_u_19.sub.Text = ("%s \194\183 \224\184\156\224\184\185\224\185\137\224\185\128\224\184\165\224\185\136\224\184\153 %d \224\184\132\224\184\153 \194\183 \224\184\167\224\184\178\224\184\155/\224\184\148\224\184\182\224\184\135 \224\184\132\224\184\185\224\184\165\224\184\148\224\184\178\224\184\167\224\184\153\224\185\140 %d \224\184\167\224\184\180"):format(v_u_16[v_u_11:GetAttribute("ServerPanel")] or "", v78, 5)
	v_u_34()
end
v_u_22:GetPropertyChangedSignal("Text"):Connect(function()
	-- upvalues: (copy) v_u_19, (ref) v_u_36
	if v_u_19.isOpen() then
		v_u_36()
	end
end)
v_u_18.Activated:Connect(function()
	-- upvalues: (copy) v_u_19, (copy) v_u_16, (copy) v_u_11, (ref) v_u_36
	local v92 = not v_u_19.isOpen()
	if v92 then
		if v_u_16[v_u_11:GetAttribute("ServerPanel")] == nil then
			v92 = false
		end
	end
	v_u_19.setOpen(v92)
	if v92 then
		v_u_36()
	end
end)
v_u_17:GetAttributeChangedSignal("Open"):Connect(function()
	-- upvalues: (copy) v_u_17, (copy) v_u_19, (copy) v_u_16, (copy) v_u_11, (ref) v_u_36
	local v93 = v_u_17:GetAttribute("Open") == true
	if v93 ~= v_u_19.isOpen() then
		if v93 then
			if v_u_16[v_u_11:GetAttribute("ServerPanel")] == nil then
				v93 = false
			end
		end
		v_u_19.setOpen(v93)
		if v93 then
			v_u_36()
		end
	end
end)
v_u_19.changed.Event:Connect(function(p94)
	-- upvalues: (copy) v_u_17
	v_u_17:SetAttribute("Open", p94)
end)
v5.InputBegan:Connect(function(p95, p96)
	-- upvalues: (copy) v_u_16, (copy) v_u_11, (copy) v_u_19, (ref) v_u_36
	if not p96 and p95.KeyCode == Enum.KeyCode.F4 and v_u_16[v_u_11:GetAttribute("ServerPanel")] ~= nil then
		local v97 = not v_u_19.isOpen()
		if v97 then
			if v_u_16[v_u_11:GetAttribute("ServerPanel")] == nil then
				v97 = false
			end
		end
		v_u_19.setOpen(v97)
		if v97 then
			v_u_36()
		end
	end
end)
local v_u_98 = {}
local function v_u_100(p99) -- name: watch
	-- upvalues: (copy) v_u_98, (copy) v_u_19, (ref) v_u_36
	if not v_u_98[p99] then
		v_u_98[p99] = { p99:GetAttributeChangedSignal("Rank"):Connect(function()
				-- upvalues: (ref) v_u_19, (ref) v_u_36
				if v_u_19.isOpen() then
					v_u_36(nil)
				end
			end), p99:GetAttributeChangedSignal("ServerPanel"):Connect(function()
				-- upvalues: (ref) v_u_19, (ref) v_u_36
				if v_u_19.isOpen() then
					v_u_36(nil)
				end
			end) }
	end
end
local v_u_101 = v_u_36
for _, v102 in v_u_2:GetPlayers() do
	v_u_100(v102)
end
v_u_2.PlayerAdded:Connect(function(p103)
	-- upvalues: (copy) v_u_100, (copy) v_u_19, (ref) v_u_101
	v_u_100(p103)
	if v_u_19.isOpen() then
		v_u_101(nil)
	end
end)
v_u_2.PlayerRemoving:Connect(function(p104)
	-- upvalues: (copy) v_u_98, (copy) v_u_19, (ref) v_u_101
	for _, v105 in v_u_98[p104] or {} do
		v105:Disconnect()
	end
	v_u_98[p104] = nil
	if v_u_19.isOpen() then
		v_u_101(p104)
	end
end)
workspace:GetAttributeChangedSignal("ServerPanelOwner"):Connect(function()
	-- upvalues: (copy) v_u_19, (ref) v_u_101
	if v_u_19.isOpen() then
		v_u_101(nil)
	end
end)
if v_u_4:IsStudio() then
	workspace:GetAttributeChangedSignal("ZZPanelFake"):Connect(function()
		-- upvalues: (copy) v_u_19, (ref) v_u_101
		if v_u_19.isOpen() then
			v_u_101(nil)
		end
	end)
end
local function v108() -- name: onMode
	-- upvalues: (copy) v_u_16, (copy) v_u_11, (copy) v_u_7, (copy) v_u_18, (copy) v_u_13, (copy) v_u_19, (ref) v_u_101
	local v106 = v_u_16[v_u_11:GetAttribute("ServerPanel")] ~= nil
	local v107 = v_u_7.isStaff(v_u_11) or v_u_11:GetAttribute("BanMenu") == true
	v_u_18.Position = UDim2.new(1, v107 and (v_u_13 and -120 or -240) or -12, 0, v_u_13 and 56 or 12)
	v_u_18.Visible = v106
	if not v106 and v_u_19.isOpen() then
		v_u_19.setOpen(false)
	end
	if v_u_19.isOpen() then
		v_u_101(nil)
	end
end
v_u_11:GetAttributeChangedSignal("ServerPanel"):Connect(v108)
v_u_11:GetAttributeChangedSignal("Rank"):Connect(v108)
v_u_11:GetAttributeChangedSignal("BanMenu"):Connect(v108)
v108()