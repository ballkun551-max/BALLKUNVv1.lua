-- Path: Players/ygggggg55551/PlayerScripts/CarClient/Camera
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = game:GetService("RunService")
local v_u_2 = game:GetService("UserInputService")
local v_u_3 = require(script.Parent:WaitForChild("Hands"))
local v_u_4 = CFrame.new(0, 0.3, 0.3)
local v_u_5 = {}
local v_u_6 = nil
local v_u_7 = false
local function v_u_10(p8) -- name: hideBody
	-- upvalues: (ref) v_u_6
	for _, v9 in v_u_6.character:GetDescendants() do
		if not (v9:IsA("BasePart") or (v9:IsA("Decal") or v9:IsA("Texture"))) then
			continue
		end
		v9.LocalTransparencyModifier = p8 and 1 or 0
	end
end
local function v_u_28(p11) -- name: update
	-- upvalues: (ref) v_u_6, (ref) v_u_7, (copy) v_u_2, (copy) v_u_4, (copy) v_u_3
	local v12 = v_u_6
	if v12 and v12.mode == "first" then
		local v13 = workspace.CurrentCamera
		local v14 = v12.character:FindFirstChild("Head")
		if v14 then
			local v15
			if v_u_7 then
				v15 = Vector2.zero
			elseif v_u_2.MouseEnabled and (not v_u_2.TouchEnabled or v_u_2.KeyboardEnabled) and v_u_2.MouseBehavior == Enum.MouseBehavior.LockCenter then
				v15 = v_u_2:GetMouseDelta()
				if v15.Magnitude > 250 then
					v15 = Vector2.zero
				end
			else
				v15 = Vector2.zero
			end
			local v16 = (v15.Magnitude > 0 or v12.touchDelta.Magnitude > 0) and true or v12.stick.Magnitude > 0
			v12.lookYaw = v12.lookYaw - (v15.X * 0.004363323129985824 + v12.touchDelta.X * 0.005235987755982988 + v12.stick.X * 2.6179938779914944 * p11)
			v12.lookPitch = v12.lookPitch - (v15.Y * 0.004363323129985824 + v12.touchDelta.Y * 0.005235987755982988 - v12.stick.Y * 2.6179938779914944 * p11)
			v12.touchDelta = Vector2.zero
			if v16 then
				v12.idle = 0
			else
				v12.idle = v12.idle + p11
				if v12.idle > 1.2 then
					local v17 = -1.5 * p11
					local v18 = 1 - math.exp(v17)
					v12.lookYaw = v12.lookYaw - v12.lookYaw * v18
					v12.lookPitch = v12.lookPitch - v12.lookPitch * v18
				end
			end
			local v19 = v12.lookYaw
			v12.lookYaw = math.clamp(v19, -1.9198621771937625, 1.9198621771937625)
			local v20 = v12.lookPitch
			v12.lookPitch = math.clamp(v20, -0.7853981633974483, 0.7853981633974483)
			local v21, v22, v23 = v12.chassis.CFrame:ToEulerAnglesYXZ()
			local v24 = v12.model:GetAttribute("DriverEye")
			local v25
			if typeof(v24) == "Vector3" then
				v25 = v12.chassis.CFrame:PointToWorldSpace(v24)
			else
				v25 = (CFrame.new(v14.Position) * v12.chassis.CFrame.Rotation * v_u_4).Position
			end
			if v13.CameraType ~= Enum.CameraType.Scriptable then
				v13.CameraType = Enum.CameraType.Scriptable
			end
			v13.CFrame = CFrame.new(v25) * CFrame.fromEulerAnglesYXZ(v21 + -0.20943951023931956 + v12.lookPitch, v22 + v12.lookYaw, v23 * 0.8)
			v13.FieldOfView = 90
			v_u_3.update()
			local v26 = v_u_2
			local v27
			if v_u_7 then
				v27 = Enum.MouseBehavior.Default
			else
				v27 = Enum.MouseBehavior.LockCenter
			end
			v26.MouseBehavior = v27
			v_u_2.MouseIconEnabled = v_u_7
		end
	else
		return
	end
end
local function v_u_35(p29) -- name: setMode
	-- upvalues: (ref) v_u_6, (copy) v_u_10, (copy) v_u_3, (copy) v_u_1, (copy) v_u_28, (copy) v_u_2
	local v30 = v_u_6
	local v31 = workspace.CurrentCamera
	v30.mode = p29
	if p29 == "first" then
		v30.lookYaw = 0
		v30.lookPitch = 0
		v30.idle = 0
		v31.CameraType = Enum.CameraType.Scriptable
		v_u_10(true)
		v30.added = v30.character.DescendantAdded:Connect(function(p32)
			if p32:IsA("BasePart") or (p32:IsA("Decal") or p32:IsA("Texture")) then
				p32.LocalTransparencyModifier = 1
			end
		end)
		v_u_3.start(v30.model, v30.character)
		v_u_1:BindToRenderStep("CarFirstPerson", Enum.RenderPriority.Camera.Value + 1, v_u_28)
	else
		local v33 = v_u_1.UnbindFromRenderStep
		local v34 = v_u_1
		pcall(v33, v34, "CarFirstPerson")
		v31.CameraType = Enum.CameraType.Custom
		v31.CameraSubject = v30.humanoid
		v31.FieldOfView = v30.savedFov
		v_u_2.MouseBehavior = Enum.MouseBehavior.Default
		v_u_2.MouseIconEnabled = true
		if v30.added then
			v30.added:Disconnect()
			v30.added = nil
		end
		v_u_10(false)
		v_u_3.stop()
	end
end
function v_u_5.start(p36, p37) -- name: start
	-- upvalues: (copy) v_u_5, (ref) v_u_6, (copy) v_u_2
	v_u_5.stop()
	v_u_6 = {
		["model"] = nil,
		["chassis"] = nil,
		["humanoid"] = nil,
		["character"] = nil,
		["savedFov"] = nil,
		["mode"] = "third",
		["lookYaw"] = 0,
		["lookPitch"] = 0,
		["idle"] = 0,
		["touchDelta"] = nil,
		["lookTouches"] = nil,
		["stick"] = nil,
		["model"] = p36,
		["chassis"] = p36.Chassis,
		["humanoid"] = p37,
		["character"] = p37.Parent,
		["savedFov"] = workspace.CurrentCamera.FieldOfView,
		["touchDelta"] = Vector2.zero,
		["lookTouches"] = {},
		["stick"] = Vector2.zero
	}
	v_u_6.inputChanged = v_u_2.InputChanged:Connect(function(p38, p39)
		-- upvalues: (ref) v_u_6
		if p38.KeyCode == Enum.KeyCode.Thumbstick2 then
			local v40 = Vector2.new(p38.Position.X, p38.Position.Y)
			local v41 = v_u_6
			if v40.Magnitude <= 0.15 then
				v40 = Vector2.zero
			end
			v41.stick = v40
		elseif p38.UserInputType == Enum.UserInputType.Touch and (not p39 and v_u_6.lookTouches[p38]) then
			local v42 = v_u_6
			v42.touchDelta = v42.touchDelta + Vector2.new(p38.Delta.X, p38.Delta.Y)
		end
	end)
	v_u_6.inputBegan = v_u_2.InputBegan:Connect(function(p43, p44)
		-- upvalues: (ref) v_u_6
		if p43.UserInputType == Enum.UserInputType.Touch and (not p44 and p43.Position.X > workspace.CurrentCamera.ViewportSize.X * 0.45) then
			v_u_6.lookTouches[p43] = true
		end
	end)
	v_u_6.inputEnded = v_u_2.InputEnded:Connect(function(p45)
		-- upvalues: (ref) v_u_6
		v_u_6.lookTouches[p45] = nil
	end)
end
function v_u_5.toggle() -- name: toggle
	-- upvalues: (ref) v_u_6, (copy) v_u_35
	if v_u_6 then
		v_u_35(v_u_6.mode == "first" and "third" or "first")
	end
end
function v_u_5.setMenuOpen(p46) -- name: setMenuOpen
	-- upvalues: (ref) v_u_7
	v_u_7 = p46 == true
end
function v_u_5.mode() -- name: mode
	-- upvalues: (ref) v_u_6
	return v_u_6 and v_u_6.mode or "third"
end
function v_u_5.stop() -- name: stop
	-- upvalues: (ref) v_u_6, (copy) v_u_1, (copy) v_u_2, (copy) v_u_10, (copy) v_u_3
	if v_u_6 then
		if v_u_6.mode == "first" then
			local v47 = v_u_6
			local v48 = workspace.CurrentCamera
			v47.mode = "third"
			local v49 = v_u_1.UnbindFromRenderStep
			local v50 = v_u_1
			pcall(v49, v50, "CarFirstPerson")
			v48.CameraType = Enum.CameraType.Custom
			v48.CameraSubject = v47.humanoid
			v48.FieldOfView = v47.savedFov
			v_u_2.MouseBehavior = Enum.MouseBehavior.Default
			v_u_2.MouseIconEnabled = true
			if v47.added then
				v47.added:Disconnect()
				v47.added = nil
			end
			v_u_10(false)
			v_u_3.stop()
		end
		v_u_6.inputChanged:Disconnect()
		v_u_6.inputBegan:Disconnect()
		v_u_6.inputEnded:Disconnect()
		v_u_6 = nil
	end
end
return v_u_5