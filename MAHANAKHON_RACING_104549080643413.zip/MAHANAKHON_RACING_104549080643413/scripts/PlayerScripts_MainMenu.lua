-- Path: Players/ygggggg55551/PlayerScripts/MainMenu
-- Class: LocalScript  true/Enum.RunContext.Legacy
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = require(game:GetService("ReplicatedStorage"):WaitForChild("NetSeal"))
local v_u_2 = game:GetService("CollectionService")
local v_u_3 = game:GetService("HttpService")
local v_u_4 = game:GetService("Lighting")
local v_u_5 = game:GetService("Players")
local v6 = game:GetService("ReplicatedFirst")
local v_u_7 = game:GetService("ReplicatedStorage")
local v_u_8 = game:GetService("RunService")
local v_u_9 = game:GetService("TweenService")
local v_u_10 = game:GetService("UserInputService")
local v_u_11 = require(v_u_7:WaitForChild("GameShared"))
local v12 = v_u_7:WaitForChild("GameUI")
local v_u_13 = require(v12:WaitForChild("Theme"))
local v_u_14 = require(v12:WaitForChild("Icons"))
local v_u_15 = require(v12:WaitForChild("Menu"))
local v_u_16 = require(v12:WaitForChild("JobPicker"))
local v_u_17 = require(v_u_7:WaitForChild("JobShared"))
local v_u_18 = require(v12:WaitForChild("Store"))
local v_u_19 = require(v12:WaitForChild("Toast"))
local v_u_20 = require(v_u_7:WaitForChild("RankShared"))
local v_u_21 = require(v12:WaitForChild("SoundMix"))
v_u_21.start()
local v_u_22 = v_u_13.isTouch()
local v_u_23 = v_u_5.LocalPlayer
local v_u_24 = v_u_7:WaitForChild(v_u_11.REMOTES)
local v_u_25 = v_u_13.ACCENT
local v_u_26 = Color3.new(1, 1, 1)
local v_u_27 = Color3.fromRGB(200, 204, 214)
local v_u_28 = Color3.fromRGB(16, 18, 24)
local v_u_29 = { Color3.fromRGB(96, 226, 96), Color3.fromRGB(28, 150, 52) }
local v_u_30 = { Color3.fromRGB(246, 84, 74), Color3.fromRGB(168, 24, 24) }
local v_u_31 = TweenInfo.new(0.25, Enum.EasingStyle.Quint, Enum.EasingDirection.Out)
local v_u_32 = v_u_13.GRAD.gold
local v_u_33 = { Color3.fromRGB(70, 74, 84), Color3.fromRGB(46, 48, 56) }
local v_u_34 = {
	{
		["key"] = "Shadows",
		["label"] = "Shadows",
		["default"] = true
	},
	{
		["key"] = "Reflection",
		["label"] = "Reflections",
		["default"] = true
	},
	{
		["key"] = "Bloom",
		["label"] = "Bloom",
		["default"] = true
	},
	{
		["key"] = "HideTrees",
		["label"] = "Hide trees",
		["default"] = false
	},
	{
		["key"] = "Blur",
		["label"] = "Depth of field",
		["default"] = true
	},
	{
		["key"] = "ColorCorrection",
		["label"] = "Color grading",
		["default"] = true
	},
	{
		["key"] = "SunRays",
		["label"] = "Sun rays",
		["default"] = true
	},
	{
		["key"] = "HideVehicles",
		["label"] = "Hide others\' vehicles",
		["default"] = false
	},
	{
		["key"] = "HideHeadUI",
		["label"] = "Hide Head UI",
		["default"] = false
	}
}
local v_u_35 = {}
local v_u_36 = {
	["Bloom"] = "BloomEffect",
	["SunRays"] = "SunRaysEffect",
	["ColorCorrection"] = "ColorCorrectionEffect",
	["Blur"] = "DepthOfFieldEffect"
}
local v_u_37 = {
	["TopBar"] = true,
	["LoadingScreen"] = true,
	["StoreWindow"] = true,
	["GameToast"] = true
}
for _, v38 in v_u_34 do
	v_u_35[v38.key] = v38.default
end
v_u_35.LowGfx = false
for _, v39 in v_u_21.KINDS do
	v_u_35[v39.key] = 1
end
local v_u_40 = {}
local function v_u_48(p41, p_u_42, p_u_43, p_u_44) -- name: hold
	-- upvalues: (copy) v_u_40
	v_u_40[p41] = v_u_40[p41] or {}
	for _, v45 in v_u_40[p41] do
		if v45.inst ~= p_u_42 or v45.prop ~= p_u_43 then
			continue
		end
		return
	end
	local v_u_46 = {
		["inst"] = p_u_42,
		["prop"] = p_u_43,
		["prev"] = p_u_42[p_u_43]
	}
	p_u_42[p_u_43] = p_u_44
	v_u_46.conn = p_u_42:GetPropertyChangedSignal(p_u_43):Connect(function()
		-- upvalues: (copy) p_u_42, (copy) p_u_43, (copy) p_u_44, (copy) v_u_46
		if p_u_42[p_u_43] ~= p_u_44 then
			v_u_46.prev = p_u_42[p_u_43]
			p_u_42[p_u_43] = p_u_44
		end
	end)
	local v47 = v_u_40[p41]
	table.insert(v47, v_u_46)
end
local function v_u_51(p49) -- name: release
	-- upvalues: (copy) v_u_40
	for _, v50 in v_u_40[p49] or {} do
		v50.conn:Disconnect()
		if not v50.inst.Parent then
			continue
		end
		v50.inst[v50.prop] = v50.prev
	end
	v_u_40[p49] = nil
end
local function v_u_55(p52) -- name: isTree
	local v53 = p52:FindFirstAncestorWhichIsA("Model")
	while v53 do
		local v54 = v53.Name
		if v54:find("Tree") or v54:sub(1, 5) == "Bush_" then
			return true
		end
		v53 = v53:FindFirstAncestorWhichIsA("Model")
	end
	return false
end
local function v_u_59(p56) -- name: isOthers
	-- upvalues: (copy) v_u_23
	local v57 = v_u_23.Character
	if v57 then
		v57 = v_u_23.Character:FindFirstChildOfClass("Humanoid")
	end
	if v57 then
		v57 = v57.SeatPart
	end
	local v58 = p56:IsA("Model")
	if v58 then
		if p56:GetAttribute("OwnerUserId") == v_u_23.UserId then
			v58 = false
		else
			if v57 then
				v57 = v57:IsDescendantOf(p56)
			end
			v58 = not v57
		end
	end
	return v58
end
local function v_u_63(p60, p61) -- name: setVehicle
	for _, v62 in p60:GetDescendants() do
		if not (v62:IsA("BasePart") or v62:IsA("Decal")) then
			continue
		end
		v62.LocalTransparencyModifier = p61 and 1 or 0
	end
end
local function v_u_68(p64) -- name: setHeadUI
	-- upvalues: (copy) v_u_5
	for _, v65 in v_u_5:GetPlayers() do
		local v66 = v65.Character
		if v66 then
			v66 = v65.Character:FindFirstChild("Head")
		end
		if v66 then
			v66 = v66:FindFirstChild("Nametag")
		end
		if not v66 then
			continue
		end
		local v67 = v66:IsA("BillboardGui")
		if v67 then
			v67 = v66.Name == "Nametag"
		end
		if not v67 then
			continue
		end
		if p64 then
			v66:SetAttribute("GameHid", true)
		end
		v66.Enabled = not p64
		if p64 then
			continue
		end
		v66:SetAttribute("GameHid", nil)
	end
end
local v_u_69 = {
	["Shadows"] = false,
	["Reflection"] = false,
	["Bloom"] = false,
	["Blur"] = false,
	["SunRays"] = false,
	["HideTrees"] = true
}
local v_u_70 = {
	["Shadows"] = true,
	["Reflection"] = true,
	["Bloom"] = true,
	["Blur"] = true,
	["SunRays"] = true,
	["HideTrees"] = false
}
local v_u_71 = setmetatable({}, {
	["__mode"] = "k"
})
local v_u_72 = 0
local function v_u_77(p73, p74) -- name: lowOne
	-- upvalues: (copy) v_u_71, (copy) v_u_2
	if not v_u_71[p73] then
		local v75 = nil
		local v76 = nil
		if p74 then
			if p73:IsA("Light") then
				if not v_u_2:HasTag(p73, "StreetLight") then
					v75 = "Enabled"
					v76 = false
				end
			elseif p73:IsA("ParticleEmitter") or (p73:IsA("Beam") or (p73:IsA("Fire") or (p73:IsA("Smoke") or p73:IsA("Sparkles")))) then
				v75 = "Enabled"
				v76 = false
			elseif p73:IsA("SurfaceGui") and (p73.MaxDistance == 0 or p73.MaxDistance > 100) then
				v75 = "MaxDistance"
				v76 = 100
			elseif p73:IsA("Texture") then
				v75 = "Transparency"
				v76 = 1
			end
		elseif p73:IsA("Light") and p73.Shadows then
			v75 = "Shadows"
			v76 = false
		end
		if v75 then
			v_u_71[p73] = { v75, p73[v75] }
			p73[v75] = v76
		end
	end
end
local function v_u_78() -- name: lowRoots
	return {
		{ workspace:FindFirstChild("Map"), true },
		{ workspace:FindFirstChild("SpawnedVehicles"), false }
	}
end
local function v_u_87(p79) -- name: setLow
	-- upvalues: (ref) v_u_72, (copy) v_u_4, (copy) v_u_51, (copy) v_u_71, (copy) v_u_48, (copy) v_u_78, (copy) v_u_77
	v_u_72 = v_u_72 + 1
	v_u_4:SetAttribute("LowGfx", p79 and true or nil)
	if p79 then
		local v80 = workspace.Terrain:FindFirstChildOfClass("Clouds")
		if v80 then
			v_u_48("LowGfx", v80, "Enabled", false)
		end
		local v_u_81 = v_u_72
		task.spawn(function()
			-- upvalues: (ref) v_u_78, (ref) v_u_77, (copy) v_u_81, (ref) v_u_72
			for _, v82 in v_u_78() do
				if not v82[1] then
					continue
				end
				for v83, v84 in v82[1]:GetDescendants() do
					v_u_77(v84, v82[2])
					if v83 % 5000 ~= 0 then
						continue
					end
					task.wait()
					if v_u_81 == v_u_72 then
						continue
					end
					return
				end
			end
		end)
	else
		v_u_51("LowGfx")
		for v85, v86 in v_u_71 do
			if not v85.Parent then
				continue
			end
			v85[v86[1]] = v86[2]
		end
		table.clear(v_u_71)
	end
end
local function v_u_98(p88) -- name: apply
	-- upvalues: (copy) v_u_35, (copy) v_u_36, (copy) v_u_51, (copy) v_u_4, (copy) v_u_48, (copy) v_u_55, (copy) v_u_68, (copy) v_u_87, (copy) v_u_63, (copy) v_u_59
	local v_u_89 = v_u_35[p88]
	local v90 = v_u_36[p88]
	if v90 then
		if v_u_89 then
			v_u_51(p88)
		else
			for _, v91 in v_u_4:GetChildren() do
				if not v91:IsA(v90) or v91.Name == "MenuBlur" then
					continue
				end
				v_u_48(p88, v91, "Enabled", false)
			end
		end
	elseif p88 == "Shadows" then
		if v_u_89 then
			v_u_51(p88)
		else
			v_u_48(p88, v_u_4, "GlobalShadows", false)
		end
	elseif p88 == "Reflection" then
		if v_u_89 then
			v_u_51(p88)
		else
			v_u_48(p88, v_u_4, "EnvironmentSpecularScale", 0)
		end
	elseif p88 == "HideTrees" then
		task.spawn(function()
			-- upvalues: (ref) v_u_55, (copy) v_u_89, (ref) v_u_35
			for v92, v93 in workspace:GetDescendants() do
				if v93:IsA("BasePart") and v_u_55(v93) then
					v93.LocalTransparencyModifier = v_u_89 and 1 or 0
				end
				if v92 % 4000 ~= 0 then
					continue
				end
				task.wait()
				if v_u_35.HideTrees == v_u_89 then
					continue
				end
				return
			end
		end)
		return
	elseif p88 == "HideHeadUI" then
		v_u_68(v_u_89)
		return
	elseif p88 == "LowGfx" then
		v_u_87(v_u_89)
	elseif p88 == "HideVehicles" then
		local v94 = workspace:FindFirstChild("SpawnedVehicles")
		for _, v95 in not v94 and {} or v94:GetChildren() do
			local v96 = v_u_63
			local v97
			if v_u_89 then
				v97 = v_u_59(v95)
			else
				v97 = v_u_89
			end
			v96(v95, v97)
		end
	end
end
v_u_4.ChildAdded:Connect(function(p99)
	-- upvalues: (copy) v_u_36, (copy) v_u_35, (copy) v_u_48
	for v100, v101 in v_u_36 do
		if v_u_35[v100] or (not p99:IsA(v101) or p99.Name == "MenuBlur") then
			continue
		end
		v_u_48(v100, p99, "Enabled", false)
	end
end)
workspace.DescendantAdded:Connect(function(p102)
	-- upvalues: (copy) v_u_35, (copy) v_u_55, (copy) v_u_78, (copy) v_u_77
	if v_u_35.HideTrees and (p102:IsA("BasePart") and v_u_55(p102)) then
		p102.LocalTransparencyModifier = 1
	else
		if v_u_35.HideHeadUI then
			local v103 = p102:IsA("BillboardGui")
			if v103 then
				v103 = p102.Name == "Nametag"
			end
			if v103 then
				p102:SetAttribute("GameHid", true)
				p102.Enabled = false
				return
			end
		end
		if v_u_35.LowGfx and (p102:IsA("Light") or (p102:IsA("ParticleEmitter") or (p102:IsA("Beam") or (p102:IsA("Fire") or (p102:IsA("Smoke") or (p102:IsA("Sparkles") or (p102:IsA("SurfaceGui") or p102:IsA("Texture")))))))) then
			for _, v104 in v_u_78() do
				if not (v104[1] and p102:IsDescendantOf(v104[1])) then
					continue
				end
				v_u_77(p102, v104[2])
				return
			end
		end
	end
end)
task.spawn(function()
	-- upvalues: (copy) v_u_35, (copy) v_u_59, (copy) v_u_63
	local v105 = workspace:WaitForChild("SpawnedVehicles", 30)
	if v105 then
		v105.ChildAdded:Connect(function(p106)
			-- upvalues: (ref) v_u_35, (ref) v_u_59, (ref) v_u_63
			task.wait(1)
			if v_u_35.HideVehicles and v_u_59(p106) then
				v_u_63(p106, true)
			end
		end)
	end
end)
local function v109(p107) -- name: watchSeat
	-- upvalues: (copy) v_u_35, (copy) v_u_98
	local v108 = p107:WaitForChild("Humanoid", 10)
	if v108 then
		v108:GetPropertyChangedSignal("SeatPart"):Connect(function()
			-- upvalues: (ref) v_u_35, (ref) v_u_98
			if v_u_35.HideVehicles then
				v_u_98("HideVehicles")
			end
		end)
	end
end
v_u_23.CharacterAdded:Connect(v109)
if v_u_23.Character then
	task.spawn(v109, v_u_23.Character)
end
local v_u_110 = false
local function v_u_116(p111) -- name: setGraphics
	-- upvalues: (copy) v_u_35, (copy) v_u_98, (copy) v_u_69, (copy) v_u_70, (ref) v_u_110, (copy) v_u_24, (copy) v_u_1
	v_u_35.LowGfx = p111
	v_u_98("LowGfx")
	local v112
	if p111 then
		v112 = v_u_69
	else
		v112 = v_u_70
	end
	for v113, v114 in v112 do
		if v_u_35[v113] == v114 then
			continue
		end
		v_u_35[v113] = v114
		v_u_98(v113)
	end
	if not v_u_110 then
		v_u_110 = true
		task.delay(1, function()
			-- upvalues: (ref) v_u_110, (ref) v_u_24, (ref) v_u_1, (ref) v_u_35
			v_u_110 = false
			local v115 = v_u_24:FindFirstChild("Settings")
			if v115 then
				v_u_1.fire(v115, v_u_35)
			end
		end)
	end
end
local v_u_117 = false
local function v131() -- name: loadSaved
	-- upvalues: (copy) v_u_3, (copy) v_u_23, (copy) v_u_34, (copy) v_u_35, (copy) v_u_98, (copy) v_u_21, (ref) v_u_117
	local v118 = v_u_3.JSONDecode
	local v119 = v_u_3
	local v120 = v_u_23:GetAttribute("Settings") or "{}"
	local v121, v122 = pcall(v118, v119, v120)
	if v121 and type(v122) == "table" then
		for _, v123 in v_u_34 do
			local v124 = v122[v123.key]
			if type(v124) ~= "boolean" or v122[v123.key] == v_u_35[v123.key] then
				continue
			end
			v_u_35[v123.key] = v122[v123.key]
			v_u_98(v123.key)
		end
		for _, v125 in v_u_21.KINDS do
			local v126 = v122[v125.key]
			if type(v126) ~= "number" then
				continue
			end
			local v127 = v_u_35
			local v128 = v125.key
			local v129 = v122[v125.key]
			v127[v128] = math.clamp(v129, 0, 1)
			v_u_21.set(v125.key, v_u_35[v125.key])
		end
		local v130 = v122.LowGfx
		if type(v130) == "boolean" then
			v_u_117 = true
			if v122.LowGfx ~= v_u_35.LowGfx then
				v_u_35.LowGfx = v122.LowGfx
				v_u_98("LowGfx")
			end
		end
	end
end
v_u_23:GetAttributeChangedSignal("Settings"):Connect(v131)
v131()
local v_u_132 = v_u_13.new("ScreenGui", {
	["Name"] = "MainMenu",
	["ResetOnSpawn"] = false,
	["IgnoreGuiInset"] = true,
	["ScreenInsets"] = nil,
	["ZIndexBehavior"] = nil,
	["DisplayOrder"] = 50,
	["Enabled"] = false,
	["Parent"] = nil,
	["ScreenInsets"] = Enum.ScreenInsets.None,
	["ZIndexBehavior"] = Enum.ZIndexBehavior.Sibling,
	["Parent"] = v_u_23:WaitForChild("PlayerGui")
})
local v_u_133 = v_u_13.new("CanvasGroup", {
	["BackgroundTransparency"] = 1,
	["Size"] = nil,
	["Parent"] = nil,
	["Size"] = UDim2.fromScale(1, 1),
	["Parent"] = v_u_132
})
local v134 = v_u_13.new("Frame", {
	["BackgroundColor3"] = nil,
	["BorderSizePixel"] = 0,
	["Size"] = nil,
	["Parent"] = nil,
	["BackgroundColor3"] = Color3.new(0, 0, 0),
	["Size"] = UDim2.fromScale(1, 1),
	["Parent"] = v_u_133
})
v_u_13.new("UIGradient", {
	["Transparency"] = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.2), NumberSequenceKeypoint.new(0.55, 0.45), NumberSequenceKeypoint.new(1, 0.7) }),
	["Parent"] = v134
})
local v_u_135 = v_u_13.new("Frame", {
	["BackgroundTransparency"] = 1,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["AnchorPoint"] = Vector2.new(0.5, 0.5),
	["Position"] = UDim2.fromScale(0.5, 0.5),
	["Size"] = UDim2.fromOffset(1280, 720),
	["Parent"] = v_u_133
})
local v_u_136 = v_u_13.new("UIScale", {
	["Parent"] = v_u_135
})
local function v_u_145() -- name: fit
	-- upvalues: (copy) v_u_136, (copy) v_u_135
	local v137 = workspace.CurrentCamera and workspace.CurrentCamera.ViewportSize or Vector2.new(1280, 720)
	local v138 = v137.Y < 600
	local v139 = v_u_136
	local v140
	if v138 then
		local v141 = v137.X / 1180
		local v142 = v137.Y / 620
		v140 = math.min(v141, v142)
	else
		local v143 = v137.X / 1280
		local v144 = v137.Y / 720
		v140 = math.min(v143, v144)
	end
	v139.Scale = v140
	v_u_135.Position = UDim2.new(0.5, 0, 0.5, v138 and 24 or 0)
end
v_u_145()
local function v_u_162(p146, p147, p148, p149, p150, p151, p152, p153, p154, p155) -- name: text
	-- upvalues: (copy) v_u_13, (copy) v_u_26
	local v156 = v_u_13.text
	local v157 = {
		["Text"] = nil,
		["FontFace"] = nil,
		["TextSize"] = nil,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["TextWrapped"] = true,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Text"] = p147
	}
	local v158
	if p154 then
		v158 = v_u_13.FONT_BOLD
	else
		v158 = v_u_13.FONT
	end
	v157.FontFace = v158
	v157.TextSize = p152
	v157.TextColor3 = p153 or v_u_26
	v157.TextXAlignment = Enum.TextXAlignment.Left
	v157.Position = UDim2.fromOffset(p148, p149)
	v157.Size = UDim2.fromOffset(p150, p151)
	v157.Parent = p146
	local v159 = v156(v157)
	for v160, v161 in p155 or {} do
		v159[v160] = v161
	end
	return v159
end
v_u_13.new("ImageLabel", {
	["BackgroundTransparency"] = 1,
	["Image"] = "rbxassetid://93559157614977",
	["ScaleType"] = nil,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["ScaleType"] = Enum.ScaleType.Fit,
	["AnchorPoint"] = Vector2.new(0.5, 0.5),
	["Position"] = UDim2.fromOffset(222, 160),
	["Size"] = UDim2.fromOffset(745, 340),
	["Parent"] = v_u_135
})
local v_u_163 = v_u_13.new("Frame", {
	["BackgroundTransparency"] = 1,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["Position"] = UDim2.fromOffset(440, 120),
	["Size"] = UDim2.fromOffset(780, 560),
	["Parent"] = v_u_135
})
local v_u_164 = v_u_117
local v_u_165 = v_u_110
local v_u_166 = {}
local v_u_167 = nil
local function v_u_188(p168, p169, p170, p171, p172, p173, p174, p175, p176) -- name: pill
	-- upvalues: (copy) v_u_13, (copy) v_u_26, (copy) v_u_162, (copy) v_u_14, (copy) v_u_9
	local v177 = v_u_13.new("TextButton", {
		["Text"] = "",
		["AutoButtonColor"] = false,
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_26,
		["Position"] = UDim2.fromOffset(p169, p170),
		["Size"] = UDim2.fromOffset(p171, p172),
		["Parent"] = p168
	})
	v_u_13.corner(v177, p172 / 2)
	local v178 = v_u_13.new("UIGradient", {
		["Color"] = nil,
		["Rotation"] = 90,
		["Parent"] = nil,
		["Color"] = ColorSequence.new(p173[1], p173[2]),
		["Parent"] = v177
	})
	local v179 = v_u_162
	local v180 = p172 * 0.45
	local v181 = v179(v177, p174, 0, 0, p171, p172, math.floor(v180), p175 or v_u_26, true, {
		["TextXAlignment"] = nil,
		["TextWrapped"] = false,
		["TextXAlignment"] = Enum.TextXAlignment.Center
	})
	if p176 then
		local v182 = v_u_14.make
		local v183 = p175 or v_u_26
		local v184 = p172 * 0.5
		local v185 = v182(p176, v183, (math.floor(v184)))
		v185.AnchorPoint = Vector2.new(0, 0.5)
		v185.Position = UDim2.new(0, p172 * 0.45, 0.5, 0)
		v185.Parent = v177
		v181.Position = UDim2.fromOffset(p172 * 0.3, 0)
	end
	v_u_13.new("UIStroke", {
		["ApplyStrokeMode"] = nil,
		["Color"] = nil,
		["Transparency"] = 0.6,
		["Thickness"] = 1.5,
		["Parent"] = nil,
		["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
		["Color"] = Color3.new(0, 0, 0),
		["Parent"] = v177
	})
	local v_u_186 = v_u_13.new("UIScale", {
		["Parent"] = v177
	})
	v177.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_9, (copy) v_u_186
		v_u_9:Create(v_u_186, TweenInfo.new(0.08), {
			["Scale"] = 0.95
		}):Play()
	end)
	for _, v187 in { v177.MouseButton1Up, v177.MouseLeave } do
		v187:Connect(function()
			-- upvalues: (ref) v_u_9, (copy) v_u_186
			v_u_9:Create(v_u_186, TweenInfo.new(0.08), {
				["Scale"] = 1
			}):Play()
		end)
	end
	return v177, v181, v178
end
local v_u_189 = nil
local function v_u_196(p190, p191, p192, p193, p194) -- name: card
	-- upvalues: (copy) v_u_13, (copy) v_u_28, (copy) v_u_26
	local v195 = v_u_13.new("Frame", {
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.25,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_28,
		["Position"] = UDim2.fromOffset(p191, p192),
		["Size"] = UDim2.fromOffset(p193, p194),
		["Parent"] = p190
	})
	v_u_13.corner(v195, 14)
	v_u_13.new("UIStroke", {
		["ApplyStrokeMode"] = nil,
		["Color"] = nil,
		["Transparency"] = 0.86,
		["Thickness"] = 1,
		["Parent"] = nil,
		["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
		["Color"] = v_u_26,
		["Parent"] = v195
	})
	return v195
end
for v197, v_u_198 in {
	{
		["id"] = "Home",
		["label"] = "Home",
		["th"] = "",
		["icon"] = "home"
	},
	{
		["id"] = "Play",
		["label"] = "Play",
		["th"] = "",
		["icon"] = "play"
	},
	{
		["id"] = "Jobs",
		["label"] = "Jobs",
		["th"] = "",
		["icon"] = "person"
	},
	{
		["id"] = "Store",
		["label"] = "Store",
		["th"] = "",
		["icon"] = "store"
	},
	{
		["id"] = "Settings",
		["label"] = "Settings",
		["th"] = "",
		["icon"] = "settings"
	},
	{
		["id"] = "Sound",
		["label"] = "Sound",
		["th"] = "",
		["icon"] = "sound"
	}
} do
	local v199 = 250 + (v197 - 1) * 64
	local v200 = v_u_13.new("TextButton", {
		["Text"] = "",
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Position"] = UDim2.fromOffset(54, v199),
		["Size"] = UDim2.fromOffset(300, 54),
		["Parent"] = v_u_135
	})
	local v_u_201 = v_u_13.new("Frame", {
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["Visible"] = false,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_25,
		["Position"] = UDim2.fromOffset(0, 10),
		["Size"] = UDim2.fromOffset(4, 34),
		["Parent"] = v200
	})
	v_u_13.corner(v_u_201, 2)
	local v202 = v_u_14.make(v_u_198.icon, v_u_26, 26)
	v202.Position = UDim2.fromOffset(18, 14)
	v202.Parent = v200
	local v_u_203 = v_u_162(v200, v_u_198.label, 58, 8, 230, 36, 30, v_u_26, true, {
		["TextWrapped"] = false
	})
	local v204 = {
		["button"] = v200,
		["bar"] = v_u_201,
		["icon"] = v202,
		["label"] = v_u_203,
		["th"] = v_u_162(v200, v_u_198.th, 58, 33, 230, 16, 14, v_u_27, false, {
			["TextWrapped"] = false
		})
	}
	v_u_166[v_u_198.id] = v204
	v200.MouseEnter:Connect(function()
		-- upvalues: (copy) v_u_201, (copy) v_u_203
		if not v_u_201.Visible then
			v_u_203.TextTransparency = 0.1
		end
	end)
	v200.MouseLeave:Connect(function()
		-- upvalues: (copy) v_u_201, (copy) v_u_203
		if not v_u_201.Visible then
			v_u_203.TextTransparency = 0.4
		end
	end)
	v200.Activated:Connect(function()
		-- upvalues: (ref) v_u_167, (copy) v_u_198
		v_u_167(v_u_198.id)
	end)
end
v_u_162(v_u_135, "MAHANAKHON RACING", 70, 660, 320, 20, 13, v_u_27, false, {
	["TextTransparency"] = 0.3
})
local function v_u_207(p205, p206) -- name: header
	-- upvalues: (copy) v_u_162, (copy) v_u_163, (copy) v_u_25, (copy) v_u_27
	v_u_162(v_u_163, p205, 0, 0, 780, 56, 48, v_u_25, true, {
		["TextWrapped"] = false
	})
	v_u_162(v_u_163, p206, 2, 60, 740, 46, 17, v_u_27, false)
end
local v_u_217 = {
	["Home"] = function() -- name: Home
		-- upvalues: (copy) v_u_207, (copy) v_u_23, (copy) v_u_11, (copy) v_u_7, (copy) v_u_13, (copy) v_u_26, (copy) v_u_163, (copy) v_u_162, (copy) v_u_188, (copy) v_u_32, (ref) v_u_167, (copy) v_u_17, (copy) v_u_196, (copy) v_u_14, (copy) v_u_27
		v_u_207("Welcome", v_u_23.DisplayName .. "  \194\183  Your money " .. v_u_11.formatCash(v_u_23:GetAttribute("Cash") or 0))
		local v208 = require(v_u_7:WaitForChild("GameUI"):WaitForChild("VehicleArt"))
		for v209, v210 in {
			{
				"Drive & Tune",
				"Bikes and cars: paint, RGB lights, plates. Press G to pick a vehicle",
				"FL5B",
				{ Color3.fromRGB(150, 92, 255), Color3.fromRGB(56, 18, 150) }
			},
			{
				"QuickRider",
				"Open your phone, deliver food, give rides and earn money",
				"LEAD25F",
				{ Color3.fromRGB(255, 132, 52), Color3.fromRGB(140, 36, 10) }
			},
			{
				"Explore the City",
				"Charan Rd., sois, villages, the hills. Ride there and look around",
				"G20LCI",
				{ Color3.fromRGB(26, 200, 180), Color3.fromRGB(6, 80, 92) }
			}
		} do
			local v211 = v_u_13.new("Frame", {
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["ClipsDescendants"] = true,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["BackgroundColor3"] = v_u_26,
				["Position"] = UDim2.fromOffset((v209 - 1) * 256, 120),
				["Size"] = UDim2.fromOffset(240, 184),
				["Parent"] = v_u_163
			})
			v_u_13.corner(v211, 10)
			v_u_13.new("UIGradient", {
				["Rotation"] = 125,
				["Color"] = nil,
				["Parent"] = nil,
				["Color"] = ColorSequence.new(v210[4][1], v210[4][2]),
				["Parent"] = v211
			})
			local v212 = v208.of(v210[3])
			if v212 then
				v_u_13.new("ImageLabel", {
					["BackgroundTransparency"] = 1,
					["Image"] = nil,
					["ScaleType"] = nil,
					["AnchorPoint"] = nil,
					["Position"] = nil,
					["Size"] = nil,
					["Parent"] = nil,
					["Image"] = v212,
					["ScaleType"] = Enum.ScaleType.Fit,
					["AnchorPoint"] = Vector2.new(1, 1),
					["Position"] = UDim2.new(1, -4, 1, -4),
					["Size"] = UDim2.fromOffset(170, 92),
					["Parent"] = v211
				})
			end
			v_u_162(v211, string.upper(v210[1]), 16, 14, 210, 24, 18, v_u_26, true)
			v_u_162(v211, v210[2], 16, 40, 208, 40, 13, v_u_26, false, {
				["TextYAlignment"] = nil,
				["TextTransparency"] = 0.12,
				["TextYAlignment"] = Enum.TextYAlignment.Top
			})
		end
		v_u_188(v_u_163, 0, 330, 260, 64, v_u_32, "Play Now", Color3.fromRGB(24, 22, 18), "play").Activated:Connect(function()
			-- upvalues: (ref) v_u_167
			v_u_167("Play")
		end)
		if v_u_23:GetAttribute("JobChosen") then
			local v213 = v_u_17.job(v_u_23:GetAttribute("Job") or v_u_17.DEFAULT) or v_u_17.JOBS[#v_u_17.JOBS]
			local v214 = v_u_196(v_u_163, 280, 330, 456, 64)
			local v215 = v_u_13.new("Frame", {
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["BackgroundColor3"] = v213.color,
				["Position"] = UDim2.fromOffset(12, 12),
				["Size"] = UDim2.fromOffset(40, 40),
				["Parent"] = v214
			})
			v_u_13.corner(v215, 10)
			local v216 = v_u_14.make(v213.icon, v_u_26, 24)
			v216.AnchorPoint = Vector2.new(0.5, 0.5)
			v216.Position = UDim2.fromScale(0.5, 0.5)
			v216.Parent = v215
			v_u_162(v214, "Your job", 64, 10, 200, 18, 13, v_u_27, false)
			v_u_162(v214, v213.th, 64, 28, 200, 26, 20, v_u_26, true, {
				["TextWrapped"] = false
			})
			v_u_188(v214, 286, 12, 156, 40, { Color3.fromRGB(70, 74, 84), Color3.fromRGB(46, 48, 56) }, "Change job", v_u_26).Activated:Connect(function()
				-- upvalues: (ref) v_u_167
				v_u_167("Jobs")
			end)
		end
	end
}
local v_u_218 = {}
function v_u_217.Settings() -- name: Settings
	-- upvalues: (copy) v_u_207, (copy) v_u_162, (copy) v_u_163, (copy) v_u_26, (copy) v_u_35, (copy) v_u_188, (copy) v_u_32, (copy) v_u_33, (copy) v_u_116, (ref) v_u_167, (copy) v_u_27, (copy) v_u_218, (copy) v_u_34, (copy) v_u_29, (copy) v_u_30, (copy) v_u_98, (ref) v_u_165, (copy) v_u_24, (copy) v_u_1, (copy) v_u_23, (copy) v_u_20, (copy) v_u_13
	v_u_207("Settings", "Tune the graphics for your device. Turning things off makes the game smoother")
	v_u_162(v_u_163, "Graphics", 0, 126, 140, 44, 20, v_u_26, true, {
		["TextYAlignment"] = Enum.TextYAlignment.Center
	})
	for v219, v_u_220 in {
		{ true, "Low", "mobile" },
		{ false, "High", "desktop" }
	} do
		local v221 = v_u_35.LowGfx == v_u_220[1]
		local v222 = v_u_188
		local v223 = v_u_163
		local v224 = 140 + (v219 - 1) * 166
		local v225 = 128
		local v226 = 150
		local v227 = 40
		local v228
		if v221 then
			v228 = v_u_32
		else
			v228 = v_u_33
		end
		local v229 = v_u_220[2]
		local v230
		if v221 then
			v230 = Color3.fromRGB(24, 22, 18)
		else
			v230 = v_u_26
		end
		v222(v223, v224, v225, v226, v227, v228, v229, v230, v_u_220[3]).Activated:Connect(function()
			-- upvalues: (ref) v_u_35, (copy) v_u_220, (ref) v_u_116, (ref) v_u_167
			if v_u_35.LowGfx ~= v_u_220[1] then
				v_u_116(v_u_220[1])
				v_u_167("Settings")
			end
		end)
	end
	v_u_162(v_u_163, "Low = Boost FPS: the map loads in as you ride. High: the map loaded around you first", 482, 126, 300, 44, 13, v_u_27, false, {
		["TextYAlignment"] = Enum.TextYAlignment.Center
	})
	table.clear(v_u_218)
	for v231, v_u_232 in v_u_34 do
		local v233 = (v231 - 1) / 5
		local v234 = math.floor(v233)
		local v235 = (v231 - 1) % 5
		local v236 = v234 * 360
		local v237 = 190 + v235 * 58
		local v238, v239, v240 = v_u_188(v_u_163, v236, v237, 92, 38, v_u_29, "On", v_u_26)
		v_u_162(v_u_163, v_u_232.label, v236 + 108, v237, 220, 38, 19, v_u_26, false, {
			["TextYAlignment"] = Enum.TextYAlignment.Center
		})
		local v_u_241 = {
			["caption"] = v239,
			["gradient"] = v240
		}
		v_u_218[v_u_232.key] = v_u_241
		local v242 = v_u_35[v_u_232.key]
		v_u_241.caption.Text = v242 and "On" or "Off"
		local v243 = v_u_241.gradient
		local v244 = ColorSequence.new
		local v245
		if v242 then
			v245 = v_u_29
		else
			v245 = v_u_30
		end
		local v246 = v245[1]
		local v247
		if v242 then
			v247 = v_u_29
		else
			v247 = v_u_30
		end
		v243.Color = v244(v246, v247[2])
		v238.Activated:Connect(function()
			-- upvalues: (ref) v_u_35, (copy) v_u_232, (copy) v_u_241, (ref) v_u_29, (ref) v_u_30, (ref) v_u_98, (ref) v_u_165, (ref) v_u_24, (ref) v_u_1
			v_u_35[v_u_232.key] = not v_u_35[v_u_232.key]
			local v248 = v_u_241
			local v249 = v_u_35[v_u_232.key]
			v248.caption.Text = v249 and "On" or "Off"
			local v250 = v248.gradient
			local v251 = ColorSequence.new
			local v252
			if v249 then
				v252 = v_u_29
			else
				v252 = v_u_30
			end
			local v253 = v252[1]
			local v254
			if v249 then
				v254 = v_u_29
			else
				v254 = v_u_30
			end
			v250.Color = v251(v253, v254[2])
			v_u_98(v_u_232.key)
			if not v_u_165 then
				v_u_165 = true
				task.delay(1, function()
					-- upvalues: (ref) v_u_165, (ref) v_u_24, (ref) v_u_1, (ref) v_u_35
					v_u_165 = false
					local v255 = v_u_24:FindFirstChild("Settings")
					if v255 then
						v_u_1.fire(v255, v_u_35)
					end
				end)
			end
		end)
	end
	v_u_162(v_u_163, "\240\159\145\145 Nametag colour", 0, 496, 300, 30, 20, v_u_26, true, {
		["TextWrapped"] = false
	})
	if v_u_23:GetAttribute("Rank") == "VIP" then
		local v256 = v_u_23:GetAttribute("TagColor") or v_u_20.RANKS.VIP.color
		for v257, v_u_258 in v_u_20.TAG_COLORS do
			local v259 = v_u_13.new("TextButton", {
				["Text"] = "",
				["AutoButtonColor"] = false,
				["BackgroundColor3"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["BackgroundColor3"] = v_u_258,
				["Position"] = UDim2.fromOffset(220 + (v257 - 1) * 46, 494),
				["Size"] = UDim2.fromOffset(36, 36),
				["Parent"] = v_u_163
			})
			v_u_13.corner(v259, 18)
			v_u_13.new("UIStroke", {
				["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
				["Color"] = v_u_26,
				["Transparency"] = v_u_258 == v256 and 0 or 0.7,
				["Thickness"] = v_u_258 == v256 and 3 or 1,
				["Parent"] = v259
			})
			v259.Activated:Connect(function()
				-- upvalues: (ref) v_u_24, (ref) v_u_1, (copy) v_u_258, (ref) v_u_167
				local v260 = v_u_24:FindFirstChild("TagColor")
				if v260 then
					v_u_1.fire(v260, v_u_258)
				end
				task.delay(0.3, v_u_167, "Settings")
			end)
		end
	else
		v_u_162(v_u_163, v_u_20.level(v_u_23:GetAttribute("Rank")) > v_u_20.level("VIP") and "Your rank has its own colour" or "VIPs pick the colour of their rank over their head (Store)", 220, 496, 520, 30, 15, v_u_27, false)
	end
	v_u_162(v_u_163, "Still laggy? Lower the graphics in Roblox\'s settings (the \226\152\176 menu)", 0, 550, 640, 44, 15, v_u_27, false)
end
function v_u_217.Sound() -- name: Sound
	-- upvalues: (copy) v_u_207, (copy) v_u_21, (copy) v_u_162, (copy) v_u_163, (copy) v_u_25, (copy) v_u_26, (copy) v_u_27, (copy) v_u_13, (copy) v_u_35, (copy) v_u_32, (copy) v_u_188, (copy) v_u_33, (copy) v_u_30, (copy) v_u_29, (ref) v_u_165, (copy) v_u_24, (copy) v_u_1, (copy) v_u_10
	v_u_207("Sound", "Turn each kind of sound up or down. Your levels are saved")
	for v261, v_u_262 in v_u_21.KINDS do
		local v263 = 128 + (v261 - 1) * 60
		local v264 = v_u_262.key == "VolMaster"
		local v265 = v_u_162
		local v266 = v_u_163
		local v267 = v_u_262.th
		local v268 = 0
		local v269 = 270
		local v270 = 22
		local v271 = v264 and 20 or 18
		local v272
		if v264 then
			v272 = v_u_25
		else
			v272 = v_u_26
		end
		v265(v266, v267, v268, v263, v269, v270, v271, v272, true, {
			["TextWrapped"] = false
		})
		v_u_162(v_u_163, v_u_262.en, 0, v263 + 23, 270, 18, 13, v_u_27, false, {
			["TextWrapped"] = false
		})
		local v_u_273 = v_u_13.new("TextButton", {
			["Text"] = "",
			["AutoButtonColor"] = false,
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["BackgroundColor3"] = Color3.fromRGB(46, 48, 56),
			["Position"] = UDim2.fromOffset(290, v263 + 12),
			["Size"] = UDim2.fromOffset(330, 14),
			["Parent"] = v_u_163
		})
		v_u_13.corner(v_u_273, 7)
		local v_u_274 = v_u_13.new("Frame", {
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["Parent"] = nil,
			["BackgroundColor3"] = v_u_26,
			["Size"] = UDim2.fromScale(v_u_35[v_u_262.key], 1),
			["Parent"] = v_u_273
		})
		v_u_13.corner(v_u_274, 7)
		v_u_13.new("UIGradient", {
			["Color"] = ColorSequence.new(v_u_32[1], v_u_32[2]),
			["Parent"] = v_u_274
		})
		local v_u_275 = v_u_13.new("Frame", {
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["ZIndex"] = 2,
			["Parent"] = nil,
			["BackgroundColor3"] = v_u_26,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(v_u_35[v_u_262.key], 0.5),
			["Size"] = UDim2.fromOffset(26, 26),
			["Parent"] = v_u_273
		})
		v_u_13.corner(v_u_275, 13)
		v_u_13.new("UIStroke", {
			["Color"] = nil,
			["Thickness"] = 2,
			["Parent"] = nil,
			["Color"] = Color3.fromRGB(240, 160, 20),
			["Parent"] = v_u_275
		})
		local v_u_276 = v_u_162(v_u_163, "", 636, v263 + 4, 64, 30, 18, v_u_26, true, {
			["TextWrapped"] = false
		})
		local v277, v_u_278, v_u_279 = v_u_188(v_u_163, 704, v263 + 2, 62, 34, v_u_33, "", v_u_26)
		local v_u_280 = v_u_35[v_u_262.key] <= 0 and 1 or v_u_35[v_u_262.key]
		local function v_u_289(p281) -- name: show
			-- upvalues: (copy) v_u_274, (copy) v_u_275, (copy) v_u_276, (copy) v_u_278, (copy) v_u_279, (ref) v_u_30, (ref) v_u_29
			v_u_274.Size = UDim2.fromScale(p281, 1)
			v_u_275.Position = UDim2.fromScale(p281, 0.5)
			local v282 = v_u_276
			local v283 = p281 * 100
			v282.Text = ("%d%%"):format((math.round(v283)))
			v_u_278.Text = p281 <= 0 and "Off" or "On"
			local v284 = v_u_279
			local v285 = ColorSequence.new
			local v286
			if p281 <= 0 then
				v286 = v_u_30
			else
				v286 = v_u_29
			end
			local v287 = v286[1]
			local v288
			if p281 <= 0 then
				v288 = v_u_30
			else
				v288 = v_u_29
			end
			v284.Color = v285(v287, v288[2])
		end
		v_u_289(v_u_35[v_u_262.key])
		local v_u_290 = nil
		v_u_273.InputBegan:Connect(function(p291)
			-- upvalues: (ref) v_u_290, (copy) v_u_273, (ref) v_u_280, (ref) v_u_35, (copy) v_u_262, (ref) v_u_21, (copy) v_u_289, (ref) v_u_165, (ref) v_u_24, (ref) v_u_1
			if p291.UserInputType == Enum.UserInputType.MouseButton1 or p291.UserInputType == Enum.UserInputType.Touch then
				v_u_290 = p291
				local v292 = p291.Position.X - v_u_273.AbsolutePosition.X
				local v293 = v_u_273.AbsoluteSize.X
				local v294 = v292 / math.max(v293, 1) * 20
				local v295 = math.round(v294) / 20
				local v296 = math.clamp(v295, 0, 1)
				if v296 > 0 then
					v_u_280 = v296
				end
				v_u_35[v_u_262.key] = v296
				v_u_21.set(v_u_262.key, v296)
				v_u_289(v296)
				if v_u_165 then
					return
				end
				v_u_165 = true
				task.delay(1, function()
					-- upvalues: (ref) v_u_165, (ref) v_u_24, (ref) v_u_1, (ref) v_u_35
					v_u_165 = false
					local v297 = v_u_24:FindFirstChild("Settings")
					if v297 then
						v_u_1.fire(v297, v_u_35)
					end
				end)
			end
		end)
		local v_u_305 = v_u_10.InputChanged:Connect(function(p298)
			-- upvalues: (ref) v_u_290, (copy) v_u_273, (ref) v_u_280, (ref) v_u_35, (copy) v_u_262, (ref) v_u_21, (copy) v_u_289, (ref) v_u_165, (ref) v_u_24, (ref) v_u_1
			if v_u_290 and (p298.UserInputType == Enum.UserInputType.MouseMovement or p298 == v_u_290) then
				local v299 = p298.Position.X - v_u_273.AbsolutePosition.X
				local v300 = v_u_273.AbsoluteSize.X
				local v301 = v299 / math.max(v300, 1) * 20
				local v302 = math.round(v301) / 20
				local v303 = math.clamp(v302, 0, 1)
				if v303 > 0 then
					v_u_280 = v303
				end
				v_u_35[v_u_262.key] = v303
				v_u_21.set(v_u_262.key, v303)
				v_u_289(v303)
				if v_u_165 then
					return
				end
				v_u_165 = true
				task.delay(1, function()
					-- upvalues: (ref) v_u_165, (ref) v_u_24, (ref) v_u_1, (ref) v_u_35
					v_u_165 = false
					local v304 = v_u_24:FindFirstChild("Settings")
					if v304 then
						v_u_1.fire(v304, v_u_35)
					end
				end)
			end
		end)
		local v_u_307 = v_u_10.InputEnded:Connect(function(p306)
			-- upvalues: (ref) v_u_290
			if v_u_290 and (p306 == v_u_290 or p306.UserInputType == Enum.UserInputType.MouseButton1) then
				v_u_290 = nil
			end
		end)
		v_u_273.Destroying:Connect(function()
			-- upvalues: (copy) v_u_305, (copy) v_u_307
			v_u_305:Disconnect()
			v_u_307:Disconnect()
		end)
		v277.Activated:Connect(function()
			-- upvalues: (ref) v_u_35, (copy) v_u_262, (ref) v_u_280, (ref) v_u_21, (copy) v_u_289, (ref) v_u_165, (ref) v_u_24, (ref) v_u_1
			local v308 = (v_u_35[v_u_262.key] > 0 and 0 or v_u_280) * 20
			local v309 = math.round(v308) / 20
			local v310 = math.clamp(v309, 0, 1)
			if v310 > 0 then
				v_u_280 = v310
			end
			v_u_35[v_u_262.key] = v310
			v_u_21.set(v_u_262.key, v310)
			v_u_289(v310)
			if not v_u_165 then
				v_u_165 = true
				task.delay(1, function()
					-- upvalues: (ref) v_u_165, (ref) v_u_24, (ref) v_u_1, (ref) v_u_35
					v_u_165 = false
					local v311 = v_u_24:FindFirstChild("Settings")
					if v311 then
						v_u_1.fire(v311, v_u_35)
					end
				end)
			end
		end)
	end
end
local v_u_312 = nil
local function v_u_320(p313) -- name: showPage
	-- upvalues: (copy) v_u_23, (copy) v_u_15, (ref) v_u_189, (copy) v_u_18, (ref) v_u_312, (copy) v_u_166, (copy) v_u_14, (copy) v_u_25, (copy) v_u_26, (copy) v_u_163, (copy) v_u_217, (copy) v_u_9, (copy) v_u_31
	if p313 == "Play" then
		if v_u_23:GetAttribute("JobChosen") then
			v_u_15.close()
		else
			v_u_189()
		end
	elseif p313 == "Jobs" then
		v_u_189()
		return
	elseif p313 == "Store" then
		v_u_18.open()
	else
		v_u_312 = p313
		for v314, v315 in v_u_166 do
			local v316 = v314 == p313
			v315.bar.Visible = v316
			v315.label.TextTransparency = v316 and 0 or 0.4
			v315.th.TextTransparency = v316 and 0.1 or 0.5
			local v317 = v_u_14.tint
			local v318 = v315.icon
			local v319
			if v316 then
				v319 = v_u_25
			else
				v319 = v_u_26
			end
			v317(v318, v319)
		end
		v_u_163:ClearAllChildren()
		v_u_217[p313]()
		v_u_163.Position = UDim2.fromOffset(470, 120)
		v_u_9:Create(v_u_163, v_u_31, {
			["Position"] = UDim2.fromOffset(440, 120)
		}):Play()
	end
end
local v_u_321 = Instance.new("BlurEffect")
v_u_321.Name = "MenuBlur"
v_u_321.Size = 0
v_u_321.Enabled = false
v_u_321.Parent = v_u_4
local v_u_322 = {}
local v_u_323 = nil
local function v_u_336(p324) -- name: cinematic
	-- upvalues: (ref) v_u_323, (copy) v_u_23, (copy) v_u_8
	local v_u_325 = workspace.CurrentCamera
	if v_u_323 then
		v_u_323:Disconnect()
		v_u_323 = nil
	end
	if p324 then
		local v326 = v_u_23.Character
		if v326 then
			v326 = v_u_23.Character:FindFirstChild("HumanoidRootPart")
		end
		local v_u_327
		if v326 then
			v_u_327 = v326.Position
		else
			v_u_327 = v_u_325.Focus.Position
		end
		local v_u_328 = math.random() * 3.141592653589793 * 2
		v_u_325.CameraType = Enum.CameraType.Scriptable
		v_u_323 = v_u_8.RenderStepped:Connect(function(p329)
			-- upvalues: (ref) v_u_328, (copy) v_u_327, (copy) v_u_325
			v_u_328 = v_u_328 + 0.06 * p329
			local v330 = v_u_327
			local v331 = v_u_328
			local v332 = math.cos(v331) * 26
			local v333 = v_u_328
			local v334 = math.sin(v333) * 26
			local v335 = v330 + Vector3.new(v332, 9, v334)
			v_u_325.CFrame = CFrame.lookAt(v335, v_u_327 + Vector3.new(0, 2, 0))
		end)
	else
		v_u_325.CameraType = Enum.CameraType.Custom
	end
end
local function v_u_345(p337, p338) -- name: setOpen
	-- upvalues: (copy) v_u_15, (ref) v_u_320, (copy) v_u_145, (copy) v_u_23, (copy) v_u_132, (copy) v_u_37, (copy) v_u_322, (copy) v_u_133, (copy) v_u_9, (copy) v_u_31, (copy) v_u_321, (copy) v_u_336, (ref) v_u_312, (ref) v_u_323
	if p337 == v_u_15.isOpen then
		if p337 and p338 then
			v_u_320(p338)
		end
		return
	else
		v_u_15.isOpen = p337
		if p337 then
			v_u_145()
			for _, v339 in v_u_23.PlayerGui:GetChildren() do
				if not v339:IsA("ScreenGui") or (v339 == v_u_132 or (v_u_37[v339.Name] or not v339.Enabled)) then
					continue
				end
				v339.Enabled = false
				local v340 = v_u_322
				table.insert(v340, v339)
			end
			v_u_132.Enabled = true
			v_u_133.GroupTransparency = 1
			v_u_9:Create(v_u_133, v_u_31, {
				["GroupTransparency"] = 0
			}):Play()
			v_u_321.Enabled = true
			v_u_9:Create(v_u_321, v_u_31, {
				["Size"] = 18
			}):Play()
			v_u_336(true)
			v_u_320(p338 or (v_u_312 or "Home"))
		else
			for _, v341 in v_u_322 do
				if not v341.Parent then
					continue
				end
				v341.Enabled = true
			end
			table.clear(v_u_322)
			local v342 = v_u_9:Create(v_u_133, v_u_31, {
				["GroupTransparency"] = 1
			})
			v342.Completed:Connect(function()
				-- upvalues: (ref) v_u_15, (ref) v_u_132
				if not v_u_15.isOpen then
					v_u_132.Enabled = false
				end
			end)
			v342:Play()
			local v343 = v_u_9:Create(v_u_321, v_u_31, {
				["Size"] = 0
			})
			v343.Completed:Connect(function()
				-- upvalues: (ref) v_u_15, (ref) v_u_321
				if not v_u_15.isOpen then
					v_u_321.Enabled = false
				end
			end)
			v343:Play()
			local v344 = workspace.CurrentCamera
			if v_u_323 then
				v_u_323:Disconnect()
				v_u_323 = nil
			end
			v344.CameraType = Enum.CameraType.Custom
		end
	end
end
local function _() -- name: openPicker
	-- upvalues: (copy) v_u_16, (copy) v_u_132, (copy) v_u_321, (ref) v_u_323, (copy) v_u_15, (copy) v_u_345, (copy) v_u_17, (copy) v_u_23, (copy) v_u_22, (copy) v_u_19, (copy) v_u_336, (ref) v_u_320
	if not v_u_16.isOpen then
		v_u_132.Enabled = false
		v_u_321.Enabled = false
		local v346 = workspace.CurrentCamera
		if v_u_323 then
			v_u_323:Disconnect()
			v_u_323 = nil
		end
		v346.CameraType = Enum.CameraType.Custom
		v_u_16.open(function(p347)
			-- upvalues: (ref) v_u_15, (ref) v_u_345, (ref) v_u_17, (ref) v_u_23, (ref) v_u_22, (ref) v_u_19, (ref) v_u_132, (ref) v_u_321, (ref) v_u_336, (ref) v_u_320
			if p347 or not v_u_15.isOpen then
				v_u_345(false)
				if p347 then
					local v348 = v_u_17.job(v_u_23:GetAttribute("Job") or "")
					local v349 = v_u_22 and "tap the key button" or "press G"
					if v348 and v348.id ~= v_u_17.DEFAULT then
						v_u_19.show(("%s: %s for a vehicle and drive to work"):format(v348.th, v349), "ok")
						return
					end
					v_u_19.show(("Free roam: %s for a vehicle and cruise the city"):format(v349), "ok")
				end
			else
				v_u_132.Enabled = true
				v_u_321.Enabled = true
				v_u_336(true)
				v_u_320("Home")
			end
		end)
	end
end
v_u_15.changed.Event:Connect(function(p350, p351)
	-- upvalues: (copy) v_u_345, (copy) v_u_23, (copy) v_u_19, (copy) v_u_15
	if p350 == "open" then
		v_u_345(true, p351)
		return
	end
	if p350 == "close" then
		local v352
		if v_u_23:GetAttribute("JobChosen") then
			v352 = true
		else
			v_u_19.show("Pick a job first: press Play", "info")
			v352 = false
		end
		if v352 then
			v_u_345(false)
			return
		end
	elseif v_u_15.isOpen then
		local v353
		if v_u_23:GetAttribute("JobChosen") then
			v353 = true
		else
			v_u_19.show("Pick a job first: press Play", "info")
			v353 = false
		end
		if not v353 then
			return
		end
		v_u_345(not v_u_15.isOpen)
	else
		v_u_345(not v_u_15.isOpen)
	end
end)
v_u_10.InputBegan:Connect(function(p354, p355)
	-- upvalues: (copy) v_u_15, (copy) v_u_16, (copy) v_u_18, (copy) v_u_23, (copy) v_u_19, (copy) v_u_345
	if not p355 and (p354.KeyCode == Enum.KeyCode.Escape and (v_u_15.isOpen and not (v_u_16.isOpen or v_u_18.isOpen))) then
		local v356
		if v_u_23:GetAttribute("JobChosen") then
			v356 = true
		else
			v_u_19.show("Pick a job first: press Play", "info")
			v356 = false
		end
		if v356 then
			v_u_345(false)
		end
	end
end)
if workspace.CurrentCamera then
	workspace.CurrentCamera:GetPropertyChangedSignal("ViewportSize"):Connect(v_u_145)
end
local v_u_357 = {
	{
		["low"] = true,
		["title"] = "LOW GRAPHICS",
		["sub"] = "Phones and older PCs",
		["icon"] = "mobile",
		["colors"] = nil,
		["lines"] = nil,
		["colors"] = { Color3.fromRGB(96, 226, 150), Color3.fromRGB(20, 140, 90) },
		["lines"] = { "Boost FPS: smoother, less heat and battery", "No shadows, map lights or effects", "The map loads in as you ride" }
	},
	{
		["low"] = false,
		["title"] = "HIGH GRAPHICS",
		["sub"] = "Computers",
		["icon"] = "desktop",
		["colors"] = nil,
		["lines"] = nil,
		["colors"] = v_u_13.GRAD.gold,
		["lines"] = { "Full shadows, lighting and effects", "The map loaded in full around you", "The best look: needs a strong PC" }
	}
}
local v358 = v6:FindFirstChild("Loading")
local v359 = os.clock()
local function v407() -- name: pickGraphics
	-- upvalues: (ref) v_u_164, (copy) v_u_35, (copy) v_u_22, (copy) v_u_13, (copy) v_u_23, (copy) v_u_9, (copy) v_u_133, (copy) v_u_31, (copy) v_u_321, (copy) v_u_15, (copy) v_u_162, (copy) v_u_25, (copy) v_u_27, (copy) v_u_116, (copy) v_u_19, (copy) v_u_357, (copy) v_u_28, (copy) v_u_26, (copy) v_u_14
	local v360
	if v_u_164 then
		v360 = v_u_35.LowGfx
	else
		v360 = v_u_22
	end
	local v_u_361 = v_u_13.new("ScreenGui", {
		["Name"] = "GraphicsPicker",
		["ResetOnSpawn"] = false,
		["IgnoreGuiInset"] = true,
		["ScreenInsets"] = nil,
		["ZIndexBehavior"] = nil,
		["DisplayOrder"] = 60,
		["Parent"] = nil,
		["ScreenInsets"] = Enum.ScreenInsets.None,
		["ZIndexBehavior"] = Enum.ZIndexBehavior.Sibling,
		["Parent"] = v_u_23.PlayerGui
	})
	local v_u_362 = v_u_13.new("CanvasGroup", {
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["GroupTransparency"] = 1,
		["Parent"] = nil,
		["Size"] = UDim2.fromScale(1, 1),
		["Parent"] = v_u_361
	})
	v_u_13.new("TextButton", {
		["Text"] = "",
		["AutoButtonColor"] = false,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.3,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = Color3.new(0, 0, 0),
		["Size"] = UDim2.fromScale(1, 1),
		["Parent"] = v_u_362
	})
	v_u_9:Create(v_u_133, v_u_31, {
		["GroupTransparency"] = 1
	}):Play()
	local v_u_363 = v_u_23.PlayerGui:FindFirstChild("TopBar")
	local v_u_364
	if v_u_363 == nil then
		v_u_364 = false
	else
		v_u_364 = v_u_363.Enabled
	end
	if v_u_364 then
		v_u_363.Enabled = false
	end
	local v_u_365 = game:GetService("StarterGui")
	local v366 = v_u_365.GetCoreGuiEnabled
	local v367 = Enum.CoreGuiType.Backpack
	local v_u_368, v369 = pcall(v366, v_u_365, v367)
	if v_u_368 then
		v_u_368 = v369 == true
	end
	if v_u_368 then
		local v370 = v_u_365.SetCoreGuiEnabled
		local v371 = Enum.CoreGuiType.Backpack
		pcall(v370, v_u_365, v371, false)
	end
	v_u_321.Enabled = true
	v_u_9:Create(v_u_321, v_u_31, {
		["Size"] = 40
	}):Play()
	local function v_u_375() -- name: restoreBehind
		-- upvalues: (copy) v_u_364, (copy) v_u_363, (copy) v_u_368, (copy) v_u_365, (ref) v_u_15, (ref) v_u_9, (ref) v_u_133, (ref) v_u_31, (ref) v_u_321
		if v_u_364 and v_u_363.Parent then
			v_u_363.Enabled = true
		end
		if v_u_368 then
			local v372 = v_u_365.SetCoreGuiEnabled
			local v373 = v_u_365
			local v374 = Enum.CoreGuiType.Backpack
			pcall(v372, v373, v374, true)
		end
		if v_u_15.isOpen then
			v_u_9:Create(v_u_133, v_u_31, {
				["GroupTransparency"] = 0
			}):Play()
			v_u_9:Create(v_u_321, v_u_31, {
				["Size"] = 18
			}):Play()
		end
	end
	local v376 = v_u_13.new("Frame", {
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.5),
		["Size"] = UDim2.fromOffset(860, 510),
		["Parent"] = v_u_362
	})
	local v_u_377 = v_u_13.new("UIScale", {
		["Parent"] = v376
	})
	local function v382() -- name: fitBox
		-- upvalues: (copy) v_u_377
		local v378 = workspace.CurrentCamera and workspace.CurrentCamera.ViewportSize or Vector2.new(1280, 720)
		local v379 = v_u_377
		local v380 = v378.X / 900
		local v381 = v378.Y / 540
		v379.Scale = math.min(v380, v381, 1.25)
	end
	local v383 = workspace.CurrentCamera and workspace.CurrentCamera.ViewportSize or Vector2.new(1280, 720)
	local v384 = v383.X / 900
	local v385 = v383.Y / 540
	v_u_377.Scale = math.min(v384, v385, 1.25)
	local v_u_386 = workspace.CurrentCamera
	if v_u_386 then
		v_u_386 = workspace.CurrentCamera:GetPropertyChangedSignal("ViewportSize"):Connect(v382)
	end
	local v387 = {
		["TextXAlignment"] = nil,
		["TextWrapped"] = false,
		["TextXAlignment"] = Enum.TextXAlignment.Center
	}
	v_u_162(v376, "CHOOSE YOUR GRAPHICS", 0, 0, 860, 48, 38, v_u_25, true, v387)
	v_u_162(v376, "Pick the one that fits your device", 0, 50, 860, 24, 17, v_u_27, false, v387)
	v_u_162(v376, "You can change it any time in Settings", 0, 480, 860, 24, 15, v_u_27, false, v387)
	local v_u_388 = false
	local function v_u_391(p389) -- name: choose
		-- upvalues: (ref) v_u_388, (ref) v_u_164, (ref) v_u_35, (ref) v_u_116, (ref) v_u_19, (copy) v_u_386, (copy) v_u_375, (ref) v_u_9, (copy) v_u_362, (ref) v_u_31, (copy) v_u_361
		if not v_u_388 then
			v_u_388 = true
			if not v_u_164 or v_u_35.LowGfx ~= p389 then
				v_u_116(p389)
			end
			v_u_164 = true
			v_u_19.show(p389 and "Low graphics: smoother and lighter on your device" or "High graphics: the full look", "ok")
			if v_u_386 then
				v_u_386:Disconnect()
			end
			v_u_375()
			local v390 = v_u_9:Create(v_u_362, v_u_31, {
				["GroupTransparency"] = 1
			})
			v390.Completed:Connect(function()
				-- upvalues: (ref) v_u_361
				v_u_361:Destroy()
			end)
			v390:Play()
		end
	end
	for v392, v_u_393 in v_u_357 do
		local v394 = v_u_393.low == v360
		local v395 = v_u_13.new("TextButton", {
			["Text"] = "",
			["AutoButtonColor"] = false,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0,
			["BorderSizePixel"] = 0,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["BackgroundColor3"] = v_u_28,
			["Position"] = UDim2.fromOffset((v392 - 1) * 450, 96),
			["Size"] = UDim2.fromOffset(410, 364),
			["Parent"] = v376
		})
		v_u_13.corner(v395, 10)
		v_u_13.new("Frame", {
			["Name"] = "Edge",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["BackgroundColor3"] = v_u_393.colors[1],
			["AnchorPoint"] = Vector2.new(0.5, 0),
			["Position"] = UDim2.fromScale(0.5, 0),
			["Size"] = UDim2.new(1, -20, 0, 2),
			["Parent"] = v395
		})
		local v396 = v_u_13.new
		local v397 = "UIStroke"
		local v398 = {
			["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border
		}
		local v399
		if v394 then
			v399 = v_u_25
		else
			v399 = v_u_26
		end
		v398.Color = v399
		v398.Transparency = v394 and 0 or 0.82
		v398.Thickness = v394 and 3 or 1.5
		v398.Parent = v395
		v396(v397, v398)
		local v_u_400 = v_u_13.new("UIScale", {
			["Parent"] = v395
		})
		local v401 = v_u_13.new("Frame", {
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.1,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["BackgroundColor3"] = Color3.fromRGB(10, 11, 15),
			["AnchorPoint"] = Vector2.new(0.5, 0),
			["Position"] = UDim2.new(0.5, 0, 0, 24),
			["Size"] = UDim2.fromOffset(112, 112),
			["Parent"] = v395
		})
		v_u_13.corner(v401, 12)
		v_u_13.new("UIStroke", {
			["ApplyStrokeMode"] = nil,
			["Color"] = nil,
			["Transparency"] = 0.2,
			["Thickness"] = 2,
			["Parent"] = nil,
			["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
			["Color"] = v_u_393.colors[1],
			["Parent"] = v401
		})
		local v402 = v_u_14.make(v_u_393.icon, v_u_393.colors[1], 64)
		v402.AnchorPoint = Vector2.new(0.5, 0.5)
		v402.Position = UDim2.fromScale(0.5, 0.5)
		v402.Parent = v401
		v_u_162(v395, v_u_393.title, 0, 148, 410, 36, 30, v_u_26, true, v387)
		v_u_162(v395, v_u_393.sub, 0, 184, 410, 22, 16, v_u_393.colors[1], true, v387)
		for v403, v404 in v_u_393.lines do
			v_u_162(v395, "\226\156\147  " .. v404, 0, 214 + (v403 - 1) * 26, 410, 24, 15, v_u_27, false, v387)
		end
		local v405 = v_u_13.new("Frame", {
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["BackgroundColor3"] = v_u_26,
			["Position"] = UDim2.fromOffset(30, 304),
			["Size"] = UDim2.fromOffset(350, 42),
			["Parent"] = v395
		})
		v_u_13.corner(v405, 6)
		v_u_13.new("UIGradient", {
			["Color"] = nil,
			["Rotation"] = 90,
			["Parent"] = nil,
			["Color"] = ColorSequence.new(v_u_393.colors[1], v_u_393.colors[2]),
			["Parent"] = v405
		})
		v_u_162(v405, v_u_393.low and "Play on LOW" or "Play on HIGH", 0, 0, 350, 42, 19, Color3.fromRGB(20, 22, 26), true, v387)
		if v394 then
			local v406 = v_u_13.new("Frame", {
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["BackgroundColor3"] = v_u_25,
				["AnchorPoint"] = Vector2.new(1, 0),
				["Position"] = UDim2.new(1, -14, 0, 14),
				["Size"] = UDim2.fromOffset(128, 26),
				["Parent"] = v395
			})
			v_u_13.corner(v406, 4)
			v_u_162(v406, v_u_164 and "LAST USED" or "RECOMMENDED", 0, 0, 128, 26, 13, Color3.fromRGB(24, 22, 18), true, v387)
		end
		v395.MouseEnter:Connect(function()
			-- upvalues: (ref) v_u_9, (copy) v_u_400
			v_u_9:Create(v_u_400, TweenInfo.new(0.12), {
				["Scale"] = 1.03
			}):Play()
		end)
		v395.MouseLeave:Connect(function()
			-- upvalues: (ref) v_u_9, (copy) v_u_400
			v_u_9:Create(v_u_400, TweenInfo.new(0.12), {
				["Scale"] = 1
			}):Play()
		end)
		v395.MouseButton1Down:Connect(function()
			-- upvalues: (ref) v_u_9, (copy) v_u_400
			v_u_9:Create(v_u_400, TweenInfo.new(0.08), {
				["Scale"] = 0.97
			}):Play()
		end)
		v395.Activated:Connect(function()
			-- upvalues: (copy) v_u_391, (copy) v_u_393
			v_u_391(v_u_393.low)
		end)
	end
	v_u_9:Create(v_u_362, v_u_31, {
		["GroupTransparency"] = 0
	}):Play()
end
while v358 and (not v358:GetAttribute("Done") and os.clock() - v359 < 30) do
	task.wait(0.1)
end
if not v_u_23.Character then
	v_u_23.CharacterAdded:Wait()
end
v_u_23.Character:WaitForChild("HumanoidRootPart", 10)
local v408, v409 = pcall(function()
	return game:GetService("TeleportService"):GetLocalPlayerTeleportData()
end)
if v408 and (type(v409) == "table" and (v409.raceHop == true and v_u_164)) then
	return
elseif v_u_8:IsStudio() and workspace:GetAttribute("StudioShowMenu") ~= true then
	if not v_u_164 then
		v_u_116(false)
		v_u_117 = true
	end
	local v410 = not v_u_23:GetAttribute("JobChosen") and v_u_24:WaitForChild("Job", 10)
	if v410 then
		local v411 = v_u_1.invoke
		local v412 = v_u_17.DEFAULT
		pcall(v411, v410, "Set", v412)
	end
else
	v_u_345(true, "Home")
	v407()
end