-- Path: Players/ygggggg55551/PlayerScripts/StickerEditorClient/AdminView
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = game:GetService("AssetService")
local v2 = {}
local v_u_3 = {
	{ "1:1", 1 },
	{ "4:3", 1.3333333333333333 },
	{ "3:2", 1.5 },
	{ "2:1", 2 },
	{ "3:1", 3 },
	{ "1:2", 0.5 }
}
local v_u_4 = Color3.fromRGB(70, 40, 46)
function v2.new(p5) -- name: new
	-- upvalues: (copy) v_u_3, (copy) v_u_1, (copy) v_u_4
	local v_u_6 = p5.C
	local v_u_7 = p5.new
	local v_u_8 = p5.corner
	local v_u_9 = p5.stroke
	local v_u_10 = p5.label
	local v_u_11 = p5.button
	local v_u_12 = p5.BOLD
	local v_u_13 = p5.MED
	local v_u_14 = p5.Catalog
	local v_u_15 = p5.Toast
	local v_u_16 = p5.invoke
	local v_u_17 = p5.priceText
	local v18 = {}
	local v_u_19 = v_u_7("ScrollingFrame", {
		["Name"] = "AdminView",
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Visible"] = false,
		["ScrollBarThickness"] = 4,
		["ScrollBarImageColor3"] = nil,
		["AutomaticCanvasSize"] = nil,
		["CanvasSize"] = nil,
		["ScrollingDirection"] = nil,
		["Position"] = p5.position,
		["Size"] = p5.size,
		["BackgroundColor3"] = v_u_6.well,
		["ScrollBarImageColor3"] = v_u_6.line,
		["AutomaticCanvasSize"] = Enum.AutomaticSize.Y,
		["CanvasSize"] = UDim2.new(),
		["ScrollingDirection"] = Enum.ScrollingDirection.Y
	}, p5.parent)
	v_u_8(v_u_19, 10)
	v_u_7("UIPadding", {
		["PaddingLeft"] = UDim.new(0, 10),
		["PaddingRight"] = UDim.new(0, 12),
		["PaddingTop"] = UDim.new(0, 10),
		["PaddingBottom"] = UDim.new(0, 12)
	}, v_u_19)
	v_u_7("UIListLayout", {
		["Padding"] = UDim.new(0, 8),
		["SortOrder"] = Enum.SortOrder.LayoutOrder
	}, v_u_19)
	v18.frame = v_u_19
	local v_u_20 = 0
	local function v27(p21, p22) -- name: caption
		-- upvalues: (copy) v_u_10, (copy) v_u_6, (copy) v_u_13, (ref) v_u_20
		local v23 = v_u_10
		local v24 = v_u_6.dim
		local v25 = v_u_13
		local v26 = {
			["Size"] = UDim2.new(1, 0, 0, 14)
		}
		v_u_20 = v_u_20 + 1
		v26.LayoutOrder = v_u_20
		v26.TextTruncate = Enum.TextTruncate.AtEnd
		return v23(p21, p22, 11, v24, v25, v26)
	end
	local function v33(p28, p29) -- name: box
		-- upvalues: (copy) v_u_7, (copy) v_u_6, (copy) v_u_13, (ref) v_u_20, (copy) v_u_8, (copy) v_u_9
		local v30 = v_u_7
		local v31 = {
			["Size"] = nil,
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["Text"] = "",
			["PlaceholderText"] = nil,
			["PlaceholderColor3"] = nil,
			["TextColor3"] = nil,
			["Font"] = nil,
			["TextSize"] = 13,
			["ClearTextOnFocus"] = false,
			["TextXAlignment"] = nil,
			["TextTruncate"] = nil,
			["LayoutOrder"] = nil,
			["Size"] = UDim2.new(1, 0, 0, 30),
			["BackgroundColor3"] = v_u_6.well,
			["PlaceholderText"] = p29,
			["PlaceholderColor3"] = Color3.fromRGB(98, 102, 118),
			["TextColor3"] = v_u_6.text,
			["Font"] = v_u_13,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["TextTruncate"] = Enum.TextTruncate.AtEnd
		}
		v_u_20 = v_u_20 + 1
		v31.LayoutOrder = v_u_20
		local v32 = v30("TextBox", v31, p28)
		v_u_8(v32, 6)
		v_u_9(v32, v_u_6.line, 1)
		v_u_7("UIPadding", {
			["PaddingLeft"] = UDim.new(0, 8),
			["PaddingRight"] = UDim.new(0, 8)
		}, v32)
		return v32
	end
	local function v38(p34) -- name: chipRow
		-- upvalues: (copy) v_u_7, (ref) v_u_20
		local v35 = v_u_7
		local v36 = {
			["Size"] = nil,
			["BackgroundTransparency"] = 1,
			["BorderSizePixel"] = 0,
			["ScrollBarThickness"] = 0,
			["LayoutOrder"] = nil,
			["ScrollingDirection"] = nil,
			["AutomaticCanvasSize"] = nil,
			["CanvasSize"] = nil,
			["Size"] = UDim2.new(1, 0, 0, 24)
		}
		v_u_20 = v_u_20 + 1
		v36.LayoutOrder = v_u_20
		v36.ScrollingDirection = Enum.ScrollingDirection.X
		v36.AutomaticCanvasSize = Enum.AutomaticSize.X
		v36.CanvasSize = UDim2.new()
		local v37 = v35("ScrollingFrame", v36, p34)
		v_u_7("UIListLayout", {
			["FillDirection"] = Enum.FillDirection.Horizontal,
			["Padding"] = UDim.new(0, 5),
			["SortOrder"] = Enum.SortOrder.LayoutOrder
		}, v37)
		return v37
	end
	local function v_u_43(p39, p40, p41) -- name: chip
		-- upvalues: (copy) v_u_7, (copy) v_u_12, (copy) v_u_6, (copy) v_u_8
		local v42 = v_u_7("TextButton", {
			["Text"] = nil,
			["Font"] = nil,
			["TextSize"] = 11,
			["TextColor3"] = nil,
			["BackgroundColor3"] = nil,
			["AutoButtonColor"] = true,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["LayoutOrder"] = nil,
			["Text"] = p40,
			["Font"] = v_u_12,
			["TextColor3"] = v_u_6.dim,
			["BackgroundColor3"] = v_u_6.btn,
			["Size"] = UDim2.fromOffset(0, 24),
			["AutomaticSize"] = Enum.AutomaticSize.X,
			["LayoutOrder"] = p41 or 0
		}, p39)
		v_u_8(v42, 12)
		v_u_7("UIPadding", {
			["PaddingLeft"] = UDim.new(0, 10),
			["PaddingRight"] = UDim.new(0, 10)
		}, v42)
		return v42
	end
	local v44 = {
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["LayoutOrder"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 36)
	}
	v_u_20 = v_u_20 + 1
	v44.LayoutOrder = v_u_20
	local v45 = v_u_7("Frame", v44, v_u_19)
	v_u_10(v45, "\224\184\171\224\184\165\224\184\177\224\184\135\224\184\154\224\185\137\224\184\178\224\184\153\224\184\170\224\184\149\224\184\180\224\185\138\224\184\129\224\185\128\224\184\129\224\184\173\224\184\163\224\185\140", 15, v_u_6.pink, v_u_12, {
		["Size"] = UDim2.new(1, 0, 0, 18)
	})
	local v_u_46 = v_u_10(v45, "\224\184\129\224\184\179\224\184\165\224\184\177\224\184\135\224\185\128\224\184\138\224\185\135\224\184\129\224\184\151\224\184\181\224\185\136\224\185\128\224\184\129\224\185\135\224\184\154\224\184\130\224\185\137\224\184\173\224\184\161\224\184\185\224\184\165...", 11, v_u_6.dim, v_u_13, {
		["Position"] = UDim2.fromOffset(0, 20),
		["Size"] = UDim2.new(1, 0, 0, 14),
		["TextTruncate"] = Enum.TextTruncate.AtEnd
	})
	local v47 = {
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = nil,
		["BackgroundColor3"] = v_u_6.card,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}
	v_u_20 = v_u_20 + 1
	v47.LayoutOrder = v_u_20
	local v48 = v_u_7("Frame", v47, v_u_19)
	v_u_8(v48, 10)
	v_u_7("UIPadding", {
		["PaddingLeft"] = UDim.new(0, 10),
		["PaddingRight"] = UDim.new(0, 10),
		["PaddingTop"] = UDim.new(0, 10),
		["PaddingBottom"] = UDim.new(0, 10)
	}, v48)
	v_u_7("UIListLayout", {
		["Padding"] = UDim.new(0, 6),
		["SortOrder"] = Enum.SortOrder.LayoutOrder
	}, v48)
	local v49 = v_u_6.text
	local v50 = {
		["Size"] = UDim2.new(1, 0, 0, 18)
	}
	v_u_20 = v_u_20 + 1
	v50.LayoutOrder = v_u_20
	v50.TextTruncate = Enum.TextTruncate.AtEnd
	local v_u_51 = v_u_10(v48, "\224\185\128\224\184\158\224\184\180\224\185\136\224\184\161\224\184\165\224\184\178\224\184\162\224\185\131\224\184\171\224\184\161\224\185\136", 13, v49, v_u_12, v50)
	local v52 = {
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["LayoutOrder"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 92)
	}
	v_u_20 = v_u_20 + 1
	v52.LayoutOrder = v_u_20
	local v53 = v_u_7("Frame", v52, v48)
	local v54 = v_u_7("Frame", {
		["Size"] = nil,
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = UDim2.fromOffset(92, 92),
		["BackgroundColor3"] = v_u_6.thumb
	}, v53)
	v_u_8(v54, 8)
	local v55 = v_u_7("Frame", {
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.5),
		["Size"] = UDim2.new(1, -12, 1, -12),
		["BackgroundColor3"] = Color3.fromRGB(70, 72, 86)
	}, v54)
	local v_u_56 = v_u_7("UIAspectRatioConstraint", {
		["AspectRatio"] = 1
	}, v55)
	local v_u_57 = v_u_7("ImageLabel", {
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ScaleType"] = nil,
		["Image"] = "",
		["Size"] = UDim2.fromScale(1, 1),
		["ScaleType"] = Enum.ScaleType.Stretch
	}, v55)
	local v_u_58 = v_u_10(v54, "\224\184\162\224\184\177\224\184\135\224\185\132\224\184\161\224\185\136\224\184\161\224\184\181\224\184\163\224\184\185\224\184\155", 11, v_u_6.dim, v_u_13, {
		["Size"] = nil,
		["TextXAlignment"] = nil,
		["ZIndex"] = 2,
		["Size"] = UDim2.fromScale(1, 1),
		["TextXAlignment"] = Enum.TextXAlignment.Center
	})
	local v59 = v_u_7("Frame", {
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["Position"] = UDim2.fromOffset(100, 0),
		["Size"] = UDim2.new(1, -100, 1, 0)
	}, v53)
	v_u_10(v59, "Image ID \224\184\171\224\184\163\224\184\183\224\184\173 Decal ID", 11, v_u_6.dim, v_u_13, {
		["Size"] = UDim2.new(1, 0, 0, 14)
	})
	local v_u_60 = v33(v59, "\224\185\128\224\184\138\224\185\136\224\184\153 1234567890")
	v_u_60.Position = UDim2.fromOffset(0, 18)
	local v_u_61 = v_u_11(v59, "\224\184\148\224\184\182\224\184\135\224\184\163\224\184\185\224\184\155", {
		["Position"] = nil,
		["Size"] = nil,
		["TextSize"] = 13,
		["Position"] = UDim2.fromOffset(0, 56),
		["Size"] = UDim2.new(1, 0, 0, 30)
	}, v_u_6.btn)
	v27(v48, "\224\184\138\224\184\183\224\185\136\224\184\173\224\184\165\224\184\178\224\184\162 (\224\185\130\224\184\138\224\184\167\224\185\140\224\185\131\224\184\153\224\184\163\224\185\137\224\184\178\224\184\153)")
	local v_u_62 = v33(v48, "\224\185\128\224\184\138\224\185\136\224\184\153 \224\185\130\224\184\165\224\185\130\224\184\129\224\185\137\224\184\151\224\184\181\224\184\161")
	v27(v48, "\224\184\171\224\184\161\224\184\167\224\184\148 (\224\184\138\224\184\183\224\185\136\224\184\173\224\185\129\224\184\151\224\185\135\224\184\154) \194\183 \224\184\129\224\184\148\224\184\138\224\184\183\224\185\136\224\184\173\224\184\148\224\185\137\224\184\178\224\184\153\224\184\165\224\185\136\224\184\178\224\184\135\224\185\128\224\184\158\224\184\183\224\185\136\224\184\173\224\185\131\224\184\138\224\185\137\224\184\171\224\184\161\224\184\167\224\184\148\224\185\128\224\184\148\224\184\180\224\184\161")
	local v_u_63 = v33(v48, "\224\185\128\224\184\138\224\185\136\224\184\153 \224\185\130\224\184\165\224\185\130\224\184\129\224\185\137 / \224\184\165\224\184\178\224\184\162\224\185\132\224\184\159 / \224\184\170\224\184\155\224\184\173\224\184\153\224\185\128\224\184\139\224\184\173\224\184\163\224\185\140")
	local v_u_64 = v38(v48)
	v27(v48, "\224\184\163\224\184\178\224\184\132\224\184\178 (\224\184\154\224\184\178\224\184\151) \194\183 0 = \224\184\159\224\184\163\224\184\181 \194\183 \224\184\136\224\185\136\224\184\178\224\184\162\224\184\132\224\184\163\224\184\177\224\185\137\224\184\135\224\185\128\224\184\148\224\184\181\224\184\162\224\184\167\224\184\149\224\185\136\224\184\173\224\184\132\224\184\177\224\184\153")
	local v_u_65 = v33(v48, "0")
	local v_u_66 = v27(v48, "\224\184\170\224\184\177\224\184\148\224\184\170\224\185\136\224\184\167\224\184\153\224\184\163\224\184\185\224\184\155 (\224\184\129\224\184\167\224\185\137\224\184\178\224\184\135 : \224\184\170\224\184\185\224\184\135)")
	local v67 = v38(v48)
	local v68 = v_u_20
	local v_u_69 = {}
	for v70, v71 in v_u_3 do
		v_u_69[v70] = v_u_43(v67, v71[1], v70)
	end
	local v72 = {
		["Text"] = "",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["LayoutOrder"] = nil,
		["AutoButtonColor"] = false,
		["Size"] = UDim2.new(1, 0, 0, 34)
	}
	v_u_20 = v68 + 1
	v72.LayoutOrder = v_u_20
	local v73 = v_u_7("TextButton", v72, v48)
	local v74 = v_u_7("Frame", {
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Position"] = UDim2.fromOffset(0, 7),
		["Size"] = UDim2.fromOffset(20, 20),
		["BackgroundColor3"] = v_u_6.well
	}, v73)
	v_u_8(v74, 5)
	local v_u_75 = v_u_9(v74, v_u_6.line, 1.5)
	local v_u_76 = v_u_7("Frame", {
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Visible"] = false,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.5),
		["Size"] = UDim2.fromOffset(10, 10),
		["BackgroundColor3"] = v_u_6.accent
	}, v74)
	v_u_8(v_u_76, 3)
	v_u_10(v73, "\224\185\131\224\184\171\224\185\137\224\184\156\224\184\185\224\185\137\224\185\128\224\184\165\224\185\136\224\184\153\224\185\128\224\184\165\224\184\183\224\184\173\224\184\129\224\184\170\224\184\181\224\185\132\224\184\148\224\185\137", 12, v_u_6.text, v_u_13, {
		["Position"] = UDim2.fromOffset(28, 1),
		["Size"] = UDim2.new(1, -28, 0, 16)
	})
	v_u_10(v73, "\224\184\165\224\184\178\224\184\162\224\184\149\224\185\137\224\184\173\224\184\135\224\185\128\224\184\155\224\185\135\224\184\153\224\184\170\224\184\181\224\184\130\224\184\178\224\184\167 / \224\185\128\224\184\151\224\184\178\224\184\173\224\185\136\224\184\173\224\184\153 \224\184\150\224\184\182\224\184\135\224\184\136\224\184\176\224\184\162\224\185\137\224\184\173\224\184\161\224\184\170\224\184\181\224\185\132\224\184\148\224\185\137\224\184\170\224\184\167\224\184\162", 10, v_u_6.dim, v_u_13, {
		["Position"] = UDim2.fromOffset(28, 18),
		["Size"] = UDim2.new(1, -28, 0, 14),
		["TextTruncate"] = Enum.TextTruncate.AtEnd
	})
	local v77 = {
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["LayoutOrder"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 34)
	}
	v_u_20 = v_u_20 + 1
	v77.LayoutOrder = v_u_20
	local v78 = v_u_7("Frame", v77, v48)
	local v_u_79 = v_u_11(v78, "\224\185\128\224\184\158\224\184\180\224\185\136\224\184\161\224\184\165\224\184\178\224\184\162", {
		["Size"] = nil,
		["TextSize"] = 13,
		["Size"] = UDim2.new(1, -78, 1, 0)
	}, v_u_6.good)
	local v80 = v_u_11(v78, "\224\184\165\224\185\137\224\184\178\224\184\135", {
		["Position"] = nil,
		["Size"] = nil,
		["TextSize"] = 13,
		["Position"] = UDim2.new(1, -72, 0, 0),
		["Size"] = UDim2.fromOffset(72, 34)
	}, v_u_6.btn)
	local v81 = v_u_6.text
	local v82 = {
		["Size"] = UDim2.new(1, 0, 0, 18)
	}
	v_u_20 = v_u_20 + 1
	v82.LayoutOrder = v_u_20
	local v_u_83 = v_u_10(v_u_19, "\224\184\165\224\184\178\224\184\162\224\185\131\224\184\153\224\184\163\224\185\137\224\184\178\224\184\153", 13, v81, v_u_12, v82)
	local v84 = {
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y
	}
	v_u_20 = v_u_20 + 1
	v84.LayoutOrder = v_u_20
	local v_u_85 = v_u_7("Frame", v84, v_u_19)
	v_u_7("UIListLayout", {
		["Padding"] = UDim.new(0, 5),
		["SortOrder"] = Enum.SortOrder.LayoutOrder
	}, v_u_85)
	local v_u_86 = v_u_10(v_u_85, "\224\184\162\224\184\177\224\184\135\224\185\132\224\184\161\224\185\136\224\184\161\224\184\181\224\184\165\224\184\178\224\184\162 \194\183 \224\185\128\224\184\158\224\184\180\224\185\136\224\184\161\224\184\136\224\184\178\224\184\129\224\184\159\224\184\173\224\184\163\224\185\140\224\184\161\224\184\148\224\185\137\224\184\178\224\184\153\224\184\154\224\184\153", 12, v_u_6.dim, v_u_13, {
		["Size"] = nil,
		["TextXAlignment"] = nil,
		["LayoutOrder"] = 0,
		["Size"] = UDim2.new(1, 0, 0, 30),
		["TextXAlignment"] = Enum.TextXAlignment.Center
	})
	local v_u_87 = {
		["id"] = nil,
		["image"] = nil,
		["aspect"] = 1,
		["tint"] = false
	}
	local v_u_88 = false
	local function v_u_99(p89, p90) -- name: setAspect
		-- upvalues: (copy) v_u_87, (copy) v_u_56, (ref) v_u_3, (copy) v_u_69, (copy) v_u_6, (copy) v_u_66
		v_u_87.aspect = math.clamp(p89, 0.1, 10)
		v_u_56.AspectRatio = v_u_87.aspect
		for v91, v92 in v_u_3 do
			local v93 = v92[2] - v_u_87.aspect
			local v94 = math.abs(v93) < 0.02
			local v95 = v_u_69[v91]
			local v96
			if v94 then
				v96 = v_u_6.accent
			else
				v96 = v_u_6.btn
			end
			v95.BackgroundColor3 = v96
			local v97 = v_u_69[v91]
			local v98
			if v94 then
				v98 = Color3.fromRGB(10, 20, 28)
			else
				v98 = v_u_6.dim
			end
			v97.TextColor3 = v98
		end
		v_u_66.Text = ("\224\184\170\224\184\177\224\184\148\224\184\170\224\185\136\224\184\167\224\184\153\224\184\163\224\184\185\224\184\155 (\224\184\129\224\184\167\224\185\137\224\184\178\224\184\135 : \224\184\170\224\184\185\224\184\135) \194\183 %.2f%s"):format(v_u_87.aspect, p90 and " \224\184\173\224\185\136\224\184\178\224\184\153\224\184\136\224\184\178\224\184\129\224\184\163\224\184\185\224\184\155\224\185\129\224\184\165\224\185\137\224\184\167" or "")
	end
	local function v_u_114() -- name: fetch
		-- upvalues: (copy) v_u_60, (ref) v_u_88, (copy) v_u_61, (copy) v_u_16, (copy) v_u_87, (copy) v_u_57, (copy) v_u_58, (copy) v_u_62, (copy) v_u_14, (ref) v_u_1, (copy) v_u_99, (copy) v_u_15
		local v100 = v_u_60.Text
		if not v_u_88 and v100:gsub("%s", "") ~= "" then
			v_u_88 = true
			v_u_61.Text = "\224\184\129\224\184\179\224\184\165\224\184\177\224\184\135\224\184\148\224\184\182\224\184\135..."
			local v101, v102 = v_u_16("lookup", v100)
			v_u_88 = false
			v_u_61.Text = "\224\184\148\224\184\182\224\184\135\224\184\163\224\184\185\224\184\155"
			if v101 and type(v102) == "table" then
				local v103 = v102.image
				if type(v103) == "string" then
					local v104 = v102.image
					v_u_87.image = v104
					v_u_57.Image = v104 or ""
					v_u_58.Visible = v104 == nil
					local v105 = v_u_60
					local v106 = v102.image
					v105.Text = v106:match("^rbxassetid://(%d+)$") or v106
					if v_u_62.Text == "" then
						local v107 = v102.name
						if type(v107) == "string" then
							v_u_62.Text = v_u_14.cut(v102.name, v_u_14.MAX_NAME)
						end
					end
					local v_u_108 = v102.image
					task.spawn(function()
						-- upvalues: (ref) v_u_1, (copy) v_u_108, (ref) v_u_87, (ref) v_u_99
						local function v109()
							-- upvalues: (ref) v_u_1, (ref) v_u_108
							return v_u_1:CreateEditableImageAsync(Content.fromUri(v_u_108))
						end
						local v110, v111 = pcall(v109)
						if v110 and v111 then
							local v112 = v111.Size
							local v113 = v111.Destroy
							pcall(v113, v111)
							if v_u_87.image == v_u_108 and v112.Y > 0 then
								v_u_99(v112.X / v112.Y, true)
							end
						end
					end)
					return
				end
			end
			v_u_15.show(type(v102) ~= "string" and "\224\184\148\224\184\182\224\184\135\224\184\163\224\184\185\224\184\155\224\185\132\224\184\161\224\185\136\224\185\132\224\184\148\224\185\137" or v102, "error")
		end
	end
	local function v125() -- name: save
		-- upvalues: (ref) v_u_88, (copy) v_u_87, (copy) v_u_60, (copy) v_u_15, (copy) v_u_62, (copy) v_u_79, (copy) v_u_16, (copy) v_u_63, (copy) v_u_65, (copy) v_u_57, (copy) v_u_58, (copy) v_u_99, (copy) v_u_76, (copy) v_u_75, (copy) v_u_6, (copy) v_u_51
		if v_u_88 then
			return
		else
			local v115 = v_u_87.image or v_u_60.Text
			if v115:gsub("%s", "") == "" then
				v_u_15.show("\224\185\131\224\184\170\224\185\136 Image ID \224\184\129\224\185\136\224\184\173\224\184\153", "error")
				return
			elseif v_u_62.Text:gsub("%s", "") == "" then
				v_u_15.show("\224\184\149\224\184\177\224\185\137\224\184\135\224\184\138\224\184\183\224\185\136\224\184\173\224\184\165\224\184\178\224\184\162\224\184\129\224\185\136\224\184\173\224\184\153", "error")
				return
			else
				v_u_88 = true
				local v116 = v_u_87.id
				v_u_79.Text = "\224\184\129\224\184\179\224\184\165\224\184\177\224\184\135\224\184\154\224\184\177\224\184\153\224\184\151\224\184\182\224\184\129..."
				local v117 = v_u_16
				local v118 = {
					["id"] = v_u_87.id,
					["image"] = v115,
					["name"] = v_u_62.Text,
					["category"] = v_u_63.Text
				}
				local v119 = v_u_65.Text:gsub("[^%d]", "")
				v118.price = tonumber(v119) or 0
				v118.aspect = v_u_87.aspect
				v118.tint = v_u_87.tint
				local v120, v121 = v117("save", v118)
				v_u_88 = false
				if v120 then
					v_u_15.show(v116 and "\224\185\129\224\184\129\224\185\137\224\184\165\224\184\178\224\184\162\224\185\129\224\184\165\224\185\137\224\184\167" or "\224\185\128\224\184\158\224\184\180\224\185\136\224\184\161\224\184\165\224\184\178\224\184\162\224\185\128\224\184\130\224\185\137\224\184\178\224\184\163\224\185\137\224\184\178\224\184\153\224\185\129\224\184\165\224\185\137\224\184\167", "info")
					v_u_87.id = nil
					v_u_87.image = nil
					v_u_57.Image = ""
					v_u_58.Visible = true
					local v122 = v_u_62
					local v123 = v_u_63
					local v124 = v_u_65
					v_u_60.Text = ""
					v122.Text = ""
					v123.Text = ""
					v124.Text = ""
					v_u_99(1)
					v_u_87.tint = false
					v_u_76.Visible = false
					v_u_75.Color = v_u_6.line
					v_u_51.Text = "\224\185\128\224\184\158\224\184\180\224\185\136\224\184\161\224\184\165\224\184\178\224\184\162\224\185\131\224\184\171\224\184\161\224\185\136"
					v_u_79.Text = "\224\185\128\224\184\158\224\184\180\224\185\136\224\184\161\224\184\165\224\184\178\224\184\162"
				else
					v_u_79.Text = v_u_87.id and "\224\184\154\224\184\177\224\184\153\224\184\151\224\184\182\224\184\129\224\184\129\224\184\178\224\184\163\224\185\129\224\184\129\224\185\137\224\185\132\224\184\130" or "\224\185\128\224\184\158\224\184\180\224\185\136\224\184\161\224\184\165\224\184\178\224\184\162"
					v_u_15.show(type(v121) ~= "string" and "\224\184\154\224\184\177\224\184\153\224\184\151\224\184\182\224\184\129\224\185\132\224\184\161\224\185\136\224\184\170\224\184\179\224\185\128\224\184\163\224\185\135\224\184\136" or v121, "error")
				end
			end
		end
	end
	v_u_60:GetPropertyChangedSignal("Text"):Connect(function()
		-- upvalues: (copy) v_u_87, (copy) v_u_60, (copy) v_u_57, (copy) v_u_58
		if v_u_87.image then
			local v126 = v_u_87.image
			if (v126:match("^rbxassetid://(%d+)$") or v126) ~= v_u_60.Text then
				v_u_87.image = nil
				v_u_57.Image = ""
				v_u_58.Visible = true
			end
		end
	end)
	v_u_60.FocusLost:Connect(function(p127)
		-- upvalues: (copy) v_u_114
		if p127 then
			v_u_114()
		end
	end)
	v_u_61.Activated:Connect(v_u_114)
	v_u_79.Activated:Connect(v125)
	v80.Activated:Connect(function() -- name: clearForm
		-- upvalues: (copy) v_u_87, (copy) v_u_57, (copy) v_u_58, (copy) v_u_60, (copy) v_u_62, (copy) v_u_63, (copy) v_u_65, (copy) v_u_99, (copy) v_u_76, (copy) v_u_75, (copy) v_u_6, (copy) v_u_51, (copy) v_u_79
		v_u_87.id = nil
		v_u_87.image = nil
		v_u_57.Image = ""
		v_u_58.Visible = true
		local v128 = v_u_62
		local v129 = v_u_63
		local v130 = v_u_65
		v_u_60.Text = ""
		v128.Text = ""
		v129.Text = ""
		v130.Text = ""
		v_u_99(1)
		v_u_87.tint = false
		v_u_76.Visible = false
		v_u_75.Color = v_u_6.line
		v_u_51.Text = "\224\185\128\224\184\158\224\184\180\224\185\136\224\184\161\224\184\165\224\184\178\224\184\162\224\185\131\224\184\171\224\184\161\224\185\136"
		v_u_79.Text = "\224\185\128\224\184\158\224\184\180\224\185\136\224\184\161\224\184\165\224\184\178\224\184\162"
	end)
	v73.Activated:Connect(function()
		-- upvalues: (copy) v_u_87, (copy) v_u_76, (copy) v_u_75, (copy) v_u_6
		local v131 = not v_u_87.tint
		v_u_87.tint = v131
		v_u_76.Visible = v131
		local v132 = v_u_75
		local v133
		if v131 then
			v133 = v_u_6.accent
		else
			v133 = v_u_6.line
		end
		v132.Color = v133
	end)
	local v_u_134 = v_u_88
	local function v_u_149(p135) -- name: editDesign
		-- upvalues: (copy) v_u_87, (copy) v_u_60, (copy) v_u_57, (copy) v_u_58, (copy) v_u_62, (copy) v_u_63, (copy) v_u_65, (copy) v_u_99, (copy) v_u_76, (copy) v_u_75, (copy) v_u_6, (copy) v_u_51, (copy) v_u_79, (copy) v_u_19
		v_u_87.id = p135.id
		local v136 = v_u_60
		local v137 = p135.image
		v136.Text = v137:match("^rbxassetid://(%d+)$") or v137
		local v138 = p135.image
		v_u_87.image = v138
		v_u_57.Image = v138 or ""
		v_u_58.Visible = v138 == nil
		local v139 = v_u_62
		local v140 = v_u_63
		local v141 = v_u_65
		local v142 = p135.name
		local v143 = p135.category
		local v144 = p135.price or 0
		local v145 = tostring(v144)
		v139.Text = v142
		v140.Text = v143
		v141.Text = v145
		v_u_99(p135.aspect or 1)
		local v146 = p135.tint == true
		v_u_87.tint = v146
		v_u_76.Visible = v146
		local v147 = v_u_75
		local v148
		if v146 then
			v148 = v_u_6.accent
		else
			v148 = v_u_6.line
		end
		v147.Color = v148
		v_u_51.Text = "\224\185\129\224\184\129\224\185\137\224\184\165\224\184\178\224\184\162: " .. p135.name
		v_u_79.Text = "\224\184\154\224\184\177\224\184\153\224\184\151\224\184\182\224\184\129\224\184\129\224\184\178\224\184\163\224\185\129\224\184\129\224\185\137\224\185\132\224\184\130"
		v_u_19.CanvasPosition = Vector2.zero
	end
	for v150, v_u_151 in v_u_3 do
		v_u_69[v150].Activated:Connect(function()
			-- upvalues: (copy) v_u_99, (copy) v_u_151
			v_u_99(v_u_151[2])
		end)
	end
	local v_u_152 = {}
	local v_u_153 = {}
	function v18.refresh() -- name: refresh
		-- upvalues: (copy) v_u_152, (copy) v_u_64, (copy) v_u_14, (copy) v_u_43, (copy) v_u_63, (copy) v_u_83, (copy) v_u_86, (copy) v_u_7, (copy) v_u_6, (copy) v_u_85, (copy) v_u_8, (copy) v_u_10, (copy) v_u_12, (copy) v_u_17, (copy) v_u_13, (copy) v_u_11, (ref) v_u_4, (copy) v_u_149, (ref) v_u_134, (copy) v_u_153, (copy) v_u_16, (copy) v_u_15, (copy) v_u_87, (copy) v_u_57, (copy) v_u_58, (copy) v_u_60, (copy) v_u_62, (copy) v_u_65, (copy) v_u_99, (copy) v_u_76, (copy) v_u_75, (copy) v_u_51, (copy) v_u_79
		for _, v154 in v_u_152 do
			v154:Destroy()
		end
		table.clear(v_u_152)
		for _, v155 in v_u_64:GetChildren() do
			if not v155:IsA("TextButton") then
				continue
			end
			v155:Destroy()
		end
		local v156 = {}
		for v157, v_u_158 in v_u_14.list do
			if v156[v_u_158.category] then
				continue
			end
			v156[v_u_158.category] = true
			v_u_43(v_u_64, v_u_158.category, v157).Activated:Connect(function()
				-- upvalues: (ref) v_u_63, (copy) v_u_158
				v_u_63.Text = v_u_158.category
			end)
		end
		v_u_64.Visible = next(v156) ~= nil
		v_u_83.Text = ("\224\184\165\224\184\178\224\184\162\224\185\131\224\184\153\224\184\163\224\185\137\224\184\178\224\184\153 (%d)"):format(#v_u_14.list)
		v_u_86.Visible = #v_u_14.list == 0
		for v159, v_u_160 in v_u_14.list do
			local v161 = v_u_7("Frame", {
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Size"] = nil,
				["LayoutOrder"] = nil,
				["BackgroundColor3"] = v_u_6.card,
				["Size"] = UDim2.new(1, 0, 0, 48),
				["LayoutOrder"] = v159
			}, v_u_85)
			v_u_8(v161, 8)
			local v162 = v_u_152
			table.insert(v162, v161)
			local v163 = v_u_7("Frame", {
				["Position"] = nil,
				["Size"] = nil,
				["BackgroundColor3"] = nil,
				["BorderSizePixel"] = 0,
				["Position"] = UDim2.fromOffset(6, 6),
				["Size"] = UDim2.fromOffset(36, 36),
				["BackgroundColor3"] = v_u_6.thumb
			}, v161)
			v_u_8(v163, 6)
			v_u_7("ImageLabel", {
				["BackgroundTransparency"] = 1,
				["Image"] = nil,
				["ScaleType"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Image"] = v_u_160.image,
				["ScaleType"] = Enum.ScaleType.Fit,
				["Position"] = UDim2.fromOffset(3, 3),
				["Size"] = UDim2.new(1, -6, 1, -6)
			}, v163)
			v_u_10(v161, v_u_160.name, 12, v_u_6.text, v_u_12, {
				["Position"] = UDim2.fromOffset(50, 7),
				["Size"] = UDim2.new(1, -156, 0, 16),
				["TextTruncate"] = Enum.TextTruncate.AtEnd
			})
			v_u_10(v161, v_u_160.category .. " \194\183 " .. ((v_u_160.price or 0) <= 0 and "\224\184\159\224\184\163\224\184\181" or v_u_17(v_u_160.price)) .. (v_u_160.tint and " \194\183 \224\184\162\224\185\137\224\184\173\224\184\161\224\184\170\224\184\181\224\185\132\224\184\148\224\185\137" or ""), 10, v_u_6.dim, v_u_13, {
				["Position"] = UDim2.fromOffset(50, 25),
				["Size"] = UDim2.new(1, -156, 0, 14),
				["TextTruncate"] = Enum.TextTruncate.AtEnd
			})
			if v_u_14.isBuiltin(v_u_160.id) then
				v_u_10(v161, "\224\184\173\224\184\162\224\184\185\224\185\136\224\185\131\224\184\153\224\185\130\224\184\132\224\185\137\224\184\148", 10, v_u_6.dim, v_u_13, {
					["Position"] = UDim2.new(1, -100, 0, 0),
					["Size"] = UDim2.new(0, 94, 1, 0),
					["TextXAlignment"] = Enum.TextXAlignment.Right
				})
			else
				local v164 = v_u_11(v161, "\224\185\129\224\184\129\224\185\137", {
					["Position"] = nil,
					["Size"] = nil,
					["TextSize"] = 12,
					["Position"] = UDim2.new(1, -104, 0.5, -13),
					["Size"] = UDim2.fromOffset(42, 26)
				}, v_u_6.btn)
				local v_u_165 = v_u_11(v161, "\224\184\165\224\184\154", {
					["Position"] = nil,
					["Size"] = nil,
					["TextSize"] = 12,
					["Position"] = UDim2.new(1, -58, 0.5, -13),
					["Size"] = UDim2.fromOffset(52, 26)
				}, v_u_4)
				v164.Activated:Connect(function()
					-- upvalues: (ref) v_u_149, (copy) v_u_160
					v_u_149(v_u_160)
				end)
				v_u_165.Activated:Connect(function()
					-- upvalues: (ref) v_u_134, (ref) v_u_153, (copy) v_u_160, (copy) v_u_165, (ref) v_u_16, (ref) v_u_15, (ref) v_u_87, (ref) v_u_57, (ref) v_u_58, (ref) v_u_60, (ref) v_u_62, (ref) v_u_63, (ref) v_u_65, (ref) v_u_99, (ref) v_u_76, (ref) v_u_75, (ref) v_u_6, (ref) v_u_51, (ref) v_u_79, (ref) v_u_4
					if not v_u_134 then
						local v166 = v_u_153[v_u_160.id]
						if v166 and os.clock() - v166 < 3 then
							v_u_153[v_u_160.id] = nil
							v_u_134 = true
							v_u_165.Text = "..."
							local v167, v168 = v_u_16("remove", v_u_160.id)
							v_u_134 = false
							if not v167 then
								local v169 = v_u_165
								local v170 = v_u_4
								v_u_165.Text = "\224\184\165\224\184\154"
								v169.BackgroundColor3 = v170
								v_u_15.show(type(v168) ~= "string" and "\224\184\165\224\184\154\224\185\132\224\184\161\224\185\136\224\184\170\224\184\179\224\185\128\224\184\163\224\185\135\224\184\136" or v168, "error")
								return
							end
							v_u_15.show("\224\185\128\224\184\173\224\184\178 " .. v_u_160.name .. " \224\184\173\224\184\173\224\184\129\224\184\136\224\184\178\224\184\129\224\184\163\224\185\137\224\184\178\224\184\153\224\185\129\224\184\165\224\185\137\224\184\167", "info")
							if v_u_87.id == v_u_160.id then
								v_u_87.id = nil
								v_u_87.image = nil
								v_u_57.Image = ""
								v_u_58.Visible = true
								local v171 = v_u_62
								local v172 = v_u_63
								local v173 = v_u_65
								v_u_60.Text = ""
								v171.Text = ""
								v172.Text = ""
								v173.Text = ""
								v_u_99(1)
								v_u_87.tint = false
								v_u_76.Visible = false
								v_u_75.Color = v_u_6.line
								v_u_51.Text = "\224\185\128\224\184\158\224\184\180\224\185\136\224\184\161\224\184\165\224\184\178\224\184\162\224\185\131\224\184\171\224\184\161\224\185\136"
								v_u_79.Text = "\224\185\128\224\184\158\224\184\180\224\185\136\224\184\161\224\184\165\224\184\178\224\184\162"
								return
							end
						else
							v_u_153[v_u_160.id] = os.clock()
							local v174 = v_u_165
							local v175 = v_u_165
							local v176 = v_u_6.danger
							v174.Text = "\224\184\162\224\184\183\224\184\153\224\184\162\224\184\177\224\184\153?"
							v175.BackgroundColor3 = v176
							task.delay(3, function()
								-- upvalues: (ref) v_u_165, (ref) v_u_153, (ref) v_u_160, (ref) v_u_4
								if v_u_165.Parent and (v_u_153[v_u_160.id] and os.clock() - v_u_153[v_u_160.id] >= 2.9) then
									v_u_153[v_u_160.id] = nil
									local v177 = v_u_165
									local v178 = v_u_4
									v_u_165.Text = "\224\184\165\224\184\154"
									v177.BackgroundColor3 = v178
								end
							end)
						end
					end
				end)
			end
		end
	end
	task.spawn(function()
		-- upvalues: (copy) v_u_16, (copy) v_u_46, (copy) v_u_6
		local v179 = nil
		local v180 = nil
		for _ = 1, 4 do
			v179, v180 = v_u_16("status")
			if v179 then
				break
			end
			task.wait(1)
		end
		if v179 and type(v180) == "table" then
			if v180.persistent then
				local v181 = v_u_46
				local v182 = v_u_46
				local v183 = v_u_6.good
				v181.Text = "\224\184\154\224\184\177\224\184\153\224\184\151\224\184\182\224\184\129\224\184\150\224\184\178\224\184\167\224\184\163 \194\183 \224\184\130\224\184\182\224\185\137\224\184\153\224\184\151\224\184\184\224\184\129\224\185\128\224\184\139\224\184\180\224\184\163\224\185\140\224\184\159\224\185\128\224\184\167\224\184\173\224\184\163\224\185\140\224\184\151\224\184\177\224\184\153\224\184\151\224\184\181"
				v182.TextColor3 = v183
			else
				local v184 = v_u_46
				local v185 = v_u_46
				local v186 = v_u_6.warn
				v184.Text = "\224\184\138\224\184\177\224\185\136\224\184\167\224\184\132\224\184\163\224\184\178\224\184\167 \194\183 \224\184\151\224\184\181\224\185\136\224\184\153\224\184\181\224\185\136\224\185\128\224\184\139\224\184\159\224\184\150\224\184\178\224\184\167\224\184\163\224\185\132\224\184\161\224\185\136\224\185\132\224\184\148\224\185\137 (\224\185\132\224\184\161\224\185\136\224\184\161\224\184\181 DataStore)"
				v185.TextColor3 = v186
			end
		else
			v_u_46.Text = "\224\185\128\224\184\138\224\185\135\224\184\129\224\184\151\224\184\181\224\185\136\224\185\128\224\184\129\224\185\135\224\184\154\224\184\130\224\185\137\224\184\173\224\184\161\224\184\185\224\184\165\224\185\132\224\184\161\224\185\136\224\185\132\224\184\148\224\185\137"
			return
		end
	end)
	v_u_87.id = nil
	v_u_87.image = nil
	v_u_57.Image = ""
	v_u_58.Visible = true
	v_u_60.Text = ""
	v_u_62.Text = ""
	v_u_63.Text = ""
	v_u_65.Text = ""
	v_u_99(1)
	v_u_87.tint = false
	v_u_76.Visible = false
	v_u_75.Color = v_u_6.line
	v_u_51.Text = "\224\185\128\224\184\158\224\184\180\224\185\136\224\184\161\224\184\165\224\184\178\224\184\162\224\185\131\224\184\171\224\184\161\224\185\136"
	v_u_79.Text = "\224\185\128\224\184\158\224\184\180\224\185\136\224\184\161\224\184\165\224\184\178\224\184\162"
	v18.refresh()
	return v18
end
return v2