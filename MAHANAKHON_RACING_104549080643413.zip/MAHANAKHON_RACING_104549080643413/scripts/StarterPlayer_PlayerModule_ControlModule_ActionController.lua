-- Path: StarterPlayer/PlayerModule/ControlModule/ActionController
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = {}
v_u_1.__index = v_u_1
function v_u_1.new() -- name: new
	-- upvalues: (copy) v_u_1
	local v2 = v_u_1
	local v3 = setmetatable({}, v2)
	v3.enabled = true
	return v3
end
function v_u_1.initializeActions(p_u_4) -- name: initializeActions
	p_u_4.connectionUtil:trackConnection("SERVER_AUTHORITY_CHANGED", p_u_4.eventBus:subscribe("SERVER_AUTHORITY_CHANGED"):Connect(function()
		-- upvalues: (copy) p_u_4
		p_u_4.controlModule.actions = {}
	end))
	if p_u_4.controlModule.actions.MoveAction and p_u_4.controlModule.actions.JumpAction then
		return
	elseif p_u_4.engineInterface.player then
		pcall(function()
			-- upvalues: (copy) p_u_4
			local v5 = script.Parent.Parent.InputContexts
			if p_u_4.isServerAuthority then
				v5 = p_u_4.engineInterface.player.InputContexts
			end
			local v6 = v5.CharacterContext
			p_u_4.controlModule.actions = {
				["MoveAction"] = v6.MoveAction,
				["JumpAction"] = v6.JumpAction
			}
			p_u_4.eventBus:publish("ACTIONS_RELOADED")
		end)
	end
end
function v_u_1.update(p7) -- name: update
	if p7.controlModule.actions.MoveAction and p7.controlModule.actions.JumpAction then
		local v8 = p7.playerModule.ControlModule
		p7.controlModule.actions.MoveAction.Enabled = v8.Enabled
		p7.controlModule.actions.JumpAction.Enabled = v8.Enabled
		p7.controlModule.moveVector = p7.controlModule.actions.MoveAction:GetState()
		p7.controlModule.isJumping = p7.controlModule.actions.JumpAction:GetState()
	end
end
function v_u_1.Enable(_, _) -- name: Enable end
return v_u_1