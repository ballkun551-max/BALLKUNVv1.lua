-- Path: Players/ygggggg55551/PlayerScripts/CarClient
-- Class: LocalScript  true/Enum.RunContext.Legacy
-- Decompiled by BALL KUN Universal Map Dump

local v1 = game:GetService("Players")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = require(v2:WaitForChild("CarShared"))
local v4 = require(script:WaitForChild("Visuals"))
local v_u_5 = require(script:WaitForChild("Driver"))
local v_u_6 = require(script:WaitForChild("Menu"))
local v7 = v1.LocalPlayer
v4.start()
v_u_6.start()
local function v_u_11(p8) -- name: onSeat
	-- upvalues: (copy) v_u_3, (copy) v_u_6, (copy) v_u_5
	local v9 = p8.SeatPart
	local v10 = v_u_3.carFromSeat(v9)
	v_u_6.setSeated(v9 ~= nil)
	if v10 and v9:IsA("VehicleSeat") then
		v_u_5.start(v10, p8, v9)
	else
		v_u_5.stop()
	end
end
local function v14(p12) -- name: onCharacter
	-- upvalues: (copy) v_u_5, (copy) v_u_11
	v_u_5.stop()
	local v_u_13 = p12:WaitForChild("Humanoid")
	v_u_13:GetPropertyChangedSignal("SeatPart"):Connect(function()
		-- upvalues: (ref) v_u_11, (copy) v_u_13
		v_u_11(v_u_13)
	end)
	v_u_11(v_u_13)
end
v7.CharacterAdded:Connect(v14)
if v7.Character then
	task.spawn(v14, v7.Character)
end