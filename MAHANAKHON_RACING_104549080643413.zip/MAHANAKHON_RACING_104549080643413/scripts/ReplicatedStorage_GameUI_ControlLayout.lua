-- Path: ReplicatedStorage/GameUI/ControlLayout
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = game:GetService("HttpService")
game:GetService("GuiService")
local v2 = game:GetService("Players")
local v_u_3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("RunService")
local v5 = game:GetService("UserInputService")
local v_u_6 = require(v_u_3:WaitForChild("NetSeal"))
local v_u_7 = require(v_u_3:WaitForChild("GameShared"))
local v_u_8 = require(script.Parent:WaitForChild("Theme"))
local v_u_9 = require(script.Parent:WaitForChild("Toast"))
local v_u_10 = {
	["changed"] = Instance.new("BindableEvent"),
	["REMOTE"] = "ControlLayout",
	["MIN_SCALE"] = 0.5,
	["MAX_SCALE"] = 2
}
local v_u_11 = v_u_8.YELLOW
local v_u_12 = v2.LocalPlayer
local v_u_13 = {}
local v_u_14 = {}
local v_u_15 = nil
local v_u_16 = false
local v_u_17 = false
local function v_u_22(p18) -- name: copy
	local v19 = {}
	for v20, v21 in p18 do
		v19[v20] = {
			["x"] = v21.x,
			["y"] = v21.y,
			["s"] = v21.s
		}
	end
	return v19
end
local function v_u_27(p23) -- name: valueOf
	-- upvalues: (ref) v_u_15, (ref) v_u_14
	local v24 = (v_u_15 or v_u_14)[p23]
	local v25 = not v24 and 0 or v24.x
	local v26 = not v24 and 0 or v24.y
	if v24 then
		return v25, v26, v24.s
	else
		return v25, v26, 1
	end
end
local function v_u_34(p28) -- name: apply
	-- upvalues: (copy) v_u_13, (ref) v_u_15, (ref) v_u_14
	local v29 = v_u_13[p28]
	if v29 then
		local v30 = (v_u_15 or v_u_14)[p28]
		local v31 = not v30 and 0 or v30.x
		local v32 = not v30 and 0 or v30.y
		local v33 = not v30 and 1 or v30.s
		if v29.custom then
			v29.custom(v31, v32, v33)
		else
			v29.gui.Position = v29.base + UDim2.fromOffset(v31, v32)
			v29.scale.Scale = v33
		end
	else
		return
	end
end
local function v_u_50(p35) -- name: decode
	-- upvalues: (copy) v_u_1, (copy) v_u_10
	local v36 = {}
	local v37 = v_u_1.JSONDecode
	local v38 = v_u_1
	local v39, v40 = pcall(v37, v38, p35)
	if v39 and type(v40) == "table" then
		for v41, v42 in v40 do
			if type(v41) ~= "string" or type(v42) ~= "table" then
				continue
			end
			local v43 = v42.x
			if type(v43) ~= "number" then
				continue
			end
			local v44 = v42.y
			if type(v44) ~= "number" then
				continue
			end
			local v45 = v42.s
			if type(v45) ~= "number" then
				continue
			end
			local v46 = {
				["x"] = v42.x,
				["y"] = v42.y
			}
			local v47 = v42.s
			local v48 = v_u_10.MIN_SCALE
			local v49 = v_u_10.MAX_SCALE
			v46.s = math.clamp(v47, v48, v49)
			v36[v41] = v46
		end
	end
	return v36
end
local function v53() -- name: readSaved
	-- upvalues: (copy) v_u_12, (ref) v_u_14, (copy) v_u_50, (ref) v_u_16, (copy) v_u_13, (copy) v_u_34
	local v51 = v_u_12:GetAttribute("ControlLayout")
	v_u_14 = type(v51) ~= "string" and {} or v_u_50(v51)
	if not v_u_16 then
		for v52 in v_u_13 do
			v_u_34(v52)
		end
	end
end
v_u_12:GetAttributeChangedSignal("ControlLayout"):Connect(v53)
v53()
function v_u_10.register(p_u_54, p_u_55, p56, p57, p58) -- name: register
	-- upvalues: (copy) v_u_13, (copy) v_u_8, (copy) v_u_34
	local v59 = v_u_13[p_u_54]
	if not v59 or v59.gui ~= p_u_55 then
		local v60
		if p58 then
			v60 = p58.apply
		else
			v60 = p58
		end
		local v61
		if v60 then
			v61 = nil
		else
			v61 = p_u_55:FindFirstChild("LayoutScale")
			if not (v61 and v61:IsA("UIScale")) then
				v61 = v_u_8.new("UIScale", {
					["Name"] = "LayoutScale",
					["Parent"] = nil,
					["Parent"] = p_u_55
				})
			end
		end
		local v62 = v_u_13
		local v63 = {
			["gui"] = p_u_55,
			["label"] = p56 or p_u_54,
			["base"] = p_u_55.Position,
			["scale"] = v61,
			["needsChild"] = p57,
			["custom"] = v60
		}
		local v64
		if p58 then
			v64 = p58.min
		else
			v64 = p58
		end
		v63.min = v64
		if p58 then
			p58 = p58.max
		end
		v63.max = p58
		v62[p_u_54] = v63
		p_u_55.Destroying:Connect(function()
			-- upvalues: (ref) v_u_13, (copy) p_u_54, (copy) p_u_55
			if v_u_13[p_u_54] and v_u_13[p_u_54].gui == p_u_55 then
				v_u_13[p_u_54] = nil
			end
		end)
		v_u_34(p_u_54)
	end
end
function v_u_10.isEditing() -- name: isEditing
	-- upvalues: (ref) v_u_16
	return v_u_16
end
local v_u_65 = nil
local v_u_66 = nil
local v_u_67 = nil
local v_u_68 = nil
local v_u_69 = nil
local v_u_70 = nil
local v_u_71 = {}
local v_u_72 = nil
local v_u_73 = nil
local v_u_74 = nil
local v_u_75 = false
local function v_u_86(p76, p77, p78, p79) -- name: set
	-- upvalues: (ref) v_u_15, (copy) v_u_13, (copy) v_u_10, (ref) v_u_17, (copy) v_u_34
	if v_u_15 then
		local v80 = v_u_13[p76]
		local v81 = p79 * 100 + 0.5
		local v82 = math.floor(v81) / 100
		local v83 = v80 and v80.min or v_u_10.MIN_SCALE
		local v84 = v80 and v80.max or v_u_10.MAX_SCALE
		local v85 = math.clamp(v82, v83, v84)
		v_u_15[p76] = (p77 ~= 0 or (p78 ~= 0 or v85 ~= 1)) and {
			["x"] = p77,
			["y"] = p78,
			["s"] = v85
		} or nil
		v_u_17 = true
		v_u_34(p76)
	end
end
local function v_u_91(p87) -- name: ancestorScale
	local v88 = p87.Parent
	local v89 = 1
	while v88 and not v88:IsA("LayerCollector") do
		for _, v90 in v88:GetChildren() do
			if not v90:IsA("UIScale") then
				continue
			end
			v89 = v89 * v90.Scale
		end
		v88 = v88.Parent
	end
	return math.max(v89, 0.01)
end
local function v_u_97(p92) -- name: onScreen
	-- upvalues: (copy) v_u_12
	local v93 = p92.gui
	local v94 = v93:FindFirstAncestorWhichIsA("LayerCollector")
	if not (v94 and (v94.Enabled and v93:IsDescendantOf(v_u_12.PlayerGui))) then
		return false
	end
	local v95 = v93
	while v93 and v93 ~= v94 do
		if v93:IsA("GuiObject") and not v93.Visible then
			return false
		end
		v93 = v93.Parent
	end
	if p92.needsChild and not v95:FindFirstChildWhichIsA("GuiObject") then
		return false
	end
	local v96
	if v95.AbsoluteSize.X > 2 then
		v96 = v95.AbsoluteSize.Y > 2
	else
		v96 = false
	end
	return v96
end
local function v_u_108() -- name: refreshBar
	-- upvalues: (ref) v_u_67, (copy) v_u_71, (ref) v_u_72, (copy) v_u_13, (ref) v_u_15, (ref) v_u_14, (ref) v_u_68
	if v_u_67 then
		for v98, v99 in v_u_71 do
			local v100 = v98 == v_u_72
			v99.BackgroundTransparency = v100 and 0.7 or 1
			local v101 = v99:FindFirstChild("Edge")
			if not v101 then
				continue
			end
			v101.Thickness = v100 and 3 or 1.5
			v101.Transparency = v100 and 0 or 0.25
		end
		local v102 = v_u_72
		if v102 then
			v102 = v_u_13[v_u_72]
		end
		if v102 then
			local v103 = (v_u_15 or v_u_14)[v_u_72]
			if v103 then
				local _ = v103.x
			end
			if v103 then
				local _ = v103.y
			end
			local v104 = not v103 and 1 or v103.s
			local v105 = v_u_68
			local v106 = v102.label
			local v107 = v104 * 100 + 0.5
			v105.Text = ("%s  \194\183  %d%%"):format(v106, (math.floor(v107)))
		else
			v_u_68.Text = "\224\184\151\224\184\184\224\184\129\224\184\155\224\184\184\224\185\136\224\184\161  \194\183  \224\185\129\224\184\149\224\184\176\224\184\155\224\184\184\224\185\136\224\184\161\224\185\128\224\184\158\224\184\183\224\185\136\224\184\173\224\185\128\224\184\165\224\184\183\224\184\173\224\184\129\224\184\151\224\184\181\224\184\165\224\184\176\224\184\155\224\184\184\224\185\136\224\184\161"
		end
	else
		return
	end
end
local function v_u_115(p109, p110) -- name: beginDrag
	-- upvalues: (copy) v_u_13, (ref) v_u_15, (ref) v_u_72, (copy) v_u_108, (ref) v_u_14, (ref) v_u_73, (copy) v_u_91, (ref) v_u_65
	local v111 = v_u_13[p109]
	if v111 and v_u_15 then
		v_u_72 = p109
		v_u_108()
		local v112 = (v_u_15 or v_u_14)[p109]
		local v113 = not v112 and 0 or v112.x
		local v114 = not v112 and 0 or v112.y
		if v112 then
			local _ = v112.s
		end
		v_u_73 = {
			["id"] = p109,
			["input"] = p110,
			["from"] = Vector2.new(p110.Position.X, p110.Position.Y),
			["x"] = v113,
			["y"] = v114,
			["k"] = v_u_91(v111.gui),
			["abs"] = v111.gui.AbsolutePosition - v_u_65.AbsolutePosition,
			["size"] = v111.gui.AbsoluteSize
		}
	end
end
local function v_u_120(p_u_116) -- name: makeHandle
	-- upvalues: (copy) v_u_8, (copy) v_u_11, (ref) v_u_66, (ref) v_u_73, (copy) v_u_115, (copy) v_u_71
	local v117 = {
		["Name"] = nil,
		["Text"] = "",
		["AutoButtonColor"] = false,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["Parent"] = nil,
		["Name"] = p_u_116,
		["BackgroundColor3"] = v_u_11,
		["Parent"] = v_u_66
	}
	local v118 = v_u_8.new("TextButton", v117)
	v_u_8.corner(v118, 10)
	v_u_8.new("UIStroke", {
		["Name"] = "Edge",
		["ApplyStrokeMode"] = nil,
		["Color"] = nil,
		["Thickness"] = 1.5,
		["Transparency"] = 0.25,
		["Parent"] = nil,
		["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
		["Color"] = v_u_11,
		["Parent"] = v118
	})
	v118.InputBegan:Connect(function(p119)
		-- upvalues: (ref) v_u_73, (ref) v_u_115, (copy) p_u_116
		if not v_u_73 and (p119.UserInputType == Enum.UserInputType.Touch or p119.UserInputType == Enum.UserInputType.MouseButton1) then
			v_u_115(p_u_116, p119)
		end
	end)
	v_u_71[p_u_116] = v118
	return v118
end
local function v_u_130() -- name: sync
	-- upvalues: (ref) v_u_65, (copy) v_u_13, (copy) v_u_71, (copy) v_u_97, (copy) v_u_120, (ref) v_u_72, (copy) v_u_108
	local v121 = v_u_65.AbsolutePosition
	local v122 = false
	for v123, v124 in v_u_13 do
		local v125 = v_u_71[v123]
		if v_u_97(v124) then
			if not v125 then
				v125 = v_u_120(v123)
				v122 = true
			end
			local v126 = v124.gui.AbsolutePosition - v121
			local v127 = v124.gui.AbsoluteSize
			v125.Position = UDim2.fromOffset(v126.X, v126.Y)
			v125.Size = UDim2.fromOffset(v127.X, v127.Y)
			v125.Visible = true
		else
			if not v125 then
				continue
			end
			v125.Visible = false
		end
	end
	for v128, v129 in v_u_71 do
		if v_u_13[v128] then
			continue
		end
		v129:Destroy()
		v_u_71[v128] = nil
		if v_u_72 == v128 then
			v_u_72 = nil
		end
		v122 = true
	end
	if v122 then
		v_u_108()
	end
end
local function v_u_134() -- name: shown
	-- upvalues: (copy) v_u_13, (copy) v_u_97
	local v131 = {}
	for v132, v133 in v_u_13 do
		if not v_u_97(v133) then
			continue
		end
		table.insert(v131, v132)
	end
	return v131
end
local function v_u_139(p135) -- name: resize
	-- upvalues: (ref) v_u_72, (copy) v_u_13, (copy) v_u_134, (ref) v_u_15, (ref) v_u_14, (copy) v_u_86, (copy) v_u_108
	local v136
	if v_u_72 and v_u_13[v_u_72] then
		v136 = { v_u_72 }
	else
		v136 = v_u_134()
	end
	for _, v137 in v136 do
		local v138 = (v_u_15 or v_u_14)[v137]
		v_u_86(v137, not v138 and 0 or v138.x, not v138 and 0 or v138.y, (not v138 and 1 or v138.s) + p135)
	end
	v_u_108()
end
local function v_u_146() -- name: save
	-- upvalues: (ref) v_u_75, (ref) v_u_15, (copy) v_u_3, (copy) v_u_7, (copy) v_u_10, (copy) v_u_9, (copy) v_u_6, (copy) v_u_22, (ref) v_u_14, (ref) v_u_17
	if v_u_75 or not v_u_15 then
		return
	else
		local v140 = v_u_3:FindFirstChild(v_u_7.REMOTES)
		if v140 then
			v140 = v140:FindFirstChild(v_u_10.REMOTE)
		end
		if v140 then
			v_u_75 = true
			local v141 = v_u_6.invoke
			local v142 = v_u_22(v_u_15)
			local v143, v144, v145 = pcall(v141, v140, v142)
			v_u_75 = false
			if v143 and v144 then
				v_u_14 = v_u_22(v_u_15)
				v_u_17 = false
				v_u_9.show("\224\184\154\224\184\177\224\184\153\224\184\151\224\184\182\224\184\129\224\184\149\224\184\179\224\185\129\224\184\171\224\184\153\224\185\136\224\184\135\224\184\155\224\184\184\224\185\136\224\184\161\224\185\129\224\184\165\224\185\137\224\184\167", "ok")
				v_u_10.close()
			else
				v_u_9.show((not v143 or type(v145) ~= "string") and "\224\184\154\224\184\177\224\184\153\224\184\151\224\184\182\224\184\129\224\185\132\224\184\161\224\185\136\224\185\132\224\184\148\224\185\137 \224\184\165\224\184\173\224\184\135\224\185\131\224\184\171\224\184\161\224\185\136\224\184\173\224\184\181\224\184\129\224\184\132\224\184\163\224\184\177\224\185\137\224\184\135" or v145, "error")
			end
		else
			v_u_9.show("\224\184\154\224\184\177\224\184\153\224\184\151\224\184\182\224\184\129\224\185\132\224\184\161\224\185\136\224\185\132\224\184\148\224\185\137 \224\184\165\224\184\173\224\184\135\224\185\131\224\184\171\224\184\161\224\185\136\224\184\173\224\184\181\224\184\129\224\184\132\224\184\163\224\184\177\224\185\137\224\184\135", "error")
			return
		end
	end
end
local function v_u_148() -- name: reset
	-- upvalues: (ref) v_u_15, (ref) v_u_17, (copy) v_u_13, (copy) v_u_34, (ref) v_u_72, (copy) v_u_108, (copy) v_u_9
	if v_u_15 then
		v_u_15 = {}
		v_u_17 = true
		for v147 in v_u_13 do
			v_u_34(v147)
		end
		v_u_72 = nil
		v_u_108()
		v_u_9.show("\224\184\155\224\184\184\224\185\136\224\184\161\224\184\129\224\184\165\224\184\177\224\184\154\224\185\128\224\184\155\224\185\135\224\184\153\224\184\132\224\185\136\224\184\178\224\185\128\224\184\163\224\184\180\224\185\136\224\184\161\224\184\149\224\185\137\224\184\153\224\185\129\224\184\165\224\185\137\224\184\167 \194\183 \224\184\129\224\184\148\224\184\154\224\184\177\224\184\153\224\184\151\224\184\182\224\184\129\224\185\128\224\184\158\224\184\183\224\185\136\224\184\173\224\185\128\224\184\129\224\185\135\224\184\154\224\185\132\224\184\167\224\185\137", "info")
	end
end
local function v_u_156() -- name: build
	-- upvalues: (ref) v_u_65, (copy) v_u_8, (copy) v_u_12, (ref) v_u_72, (copy) v_u_108, (ref) v_u_66, (ref) v_u_67, (ref) v_u_73, (ref) v_u_69, (ref) v_u_70, (ref) v_u_68, (copy) v_u_139, (copy) v_u_148, (copy) v_u_146, (copy) v_u_10
	v_u_65 = v_u_8.new("ScreenGui", {
		["Name"] = "ControlLayout",
		["ResetOnSpawn"] = false,
		["IgnoreGuiInset"] = true,
		["ScreenInsets"] = nil,
		["ZIndexBehavior"] = nil,
		["DisplayOrder"] = 70,
		["Enabled"] = false,
		["Parent"] = nil,
		["ScreenInsets"] = Enum.ScreenInsets.CoreUISafeInsets,
		["ZIndexBehavior"] = Enum.ZIndexBehavior.Sibling,
		["Parent"] = v_u_12:WaitForChild("PlayerGui")
	})
	v_u_8.new("TextButton", {
		["Name"] = "Blocker",
		["Text"] = "",
		["AutoButtonColor"] = false,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.55,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["ZIndex"] = 1,
		["Parent"] = nil,
		["BackgroundColor3"] = Color3.new(0, 0, 0),
		["Size"] = UDim2.fromScale(1, 1),
		["Parent"] = v_u_65
	}).Activated:Connect(function()
		-- upvalues: (ref) v_u_72, (ref) v_u_108
		v_u_72 = nil
		v_u_108()
	end)
	v_u_66 = v_u_8.new("Frame", {
		["Name"] = "Handles",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 2,
		["Parent"] = nil,
		["Size"] = UDim2.fromScale(1, 1),
		["Parent"] = v_u_65
	})
	v_u_67 = v_u_8.panel({
		["Name"] = "Bar",
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["ZIndex"] = 3,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0),
		["Position"] = UDim2.new(0.5, 0, 0, 8),
		["Size"] = UDim2.fromOffset(340, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y,
		["Parent"] = v_u_65
	})
	v_u_8.autoScale(v_u_67)
	v_u_8.padding(v_u_67, 12, 10)
	v_u_8.new("UIListLayout", {
		["Padding"] = UDim.new(0, 8),
		["SortOrder"] = Enum.SortOrder.LayoutOrder,
		["Parent"] = v_u_67
	})
	local v149 = v_u_8.new("TextButton", {
		["Name"] = "Title",
		["Text"] = "",
		["AutoButtonColor"] = false,
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["LayoutOrder"] = 1,
		["Parent"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 42),
		["Parent"] = v_u_67
	})
	v_u_8.text({
		["Text"] = "\224\184\155\224\184\163\224\184\177\224\184\154\224\184\155\224\184\184\224\185\136\224\184\161",
		["TextSize"] = 20,
		["FontFace"] = nil,
		["TextXAlignment"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["FontFace"] = v_u_8.FONT_HEAVY,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["Size"] = UDim2.new(1, 0, 0, 22),
		["Parent"] = v149
	})
	v_u_8.text({
		["Text"] = "\224\184\165\224\184\178\224\184\129\224\184\155\224\184\184\224\185\136\224\184\161\224\185\128\224\184\158\224\184\183\224\185\136\224\184\173\224\184\162\224\185\137\224\184\178\224\184\162 \194\183 \224\185\129\224\184\149\224\184\176\224\184\155\224\184\184\224\185\136\224\184\161\224\185\129\224\184\165\224\185\137\224\184\167\224\184\129\224\184\148 - / + \224\185\128\224\184\158\224\184\183\224\185\136\224\184\173\224\184\155\224\184\163\224\184\177\224\184\154\224\184\130\224\184\153\224\184\178\224\184\148",
		["TextSize"] = 15,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["TextTruncate"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["TextColor3"] = v_u_8.TEXT_DIM,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["TextTruncate"] = Enum.TextTruncate.AtEnd,
		["Position"] = UDim2.fromOffset(0, 23),
		["Size"] = UDim2.new(1, 0, 0, 18),
		["Parent"] = v149
	})
	v149.InputBegan:Connect(function(p150)
		-- upvalues: (ref) v_u_73, (ref) v_u_67
		if not v_u_73 and (p150.UserInputType == Enum.UserInputType.Touch or p150.UserInputType == Enum.UserInputType.MouseButton1) then
			v_u_73 = {
				["bar"] = true,
				["input"] = nil,
				["from"] = nil,
				["start"] = nil,
				["input"] = p150,
				["from"] = Vector2.new(p150.Position.X, p150.Position.Y),
				["start"] = v_u_67.Position
			}
		end
	end)
	local v151 = v_u_8.new("Frame", {
		["Name"] = "Size",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["LayoutOrder"] = 2,
		["Parent"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 42),
		["Parent"] = v_u_67
	})
	v_u_69 = v_u_8.button({
		["name"] = "Smaller",
		["text"] = "-",
		["grad"] = "dark",
		["textSize"] = 22,
		["size"] = nil,
		["parent"] = nil,
		["size"] = UDim2.fromOffset(52, 42),
		["parent"] = v151
	})
	v_u_70 = v_u_8.button({
		["name"] = "Bigger",
		["text"] = "+",
		["grad"] = "dark",
		["textSize"] = 22,
		["anchor"] = nil,
		["position"] = nil,
		["size"] = nil,
		["parent"] = nil,
		["anchor"] = Vector2.new(1, 0),
		["position"] = UDim2.fromScale(1, 0),
		["size"] = UDim2.fromOffset(52, 42),
		["parent"] = v151
	})
	v_u_68 = v_u_8.text({
		["Name"] = "Label",
		["Text"] = "",
		["TextSize"] = 17,
		["FontFace"] = nil,
		["TextTruncate"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["FontFace"] = v_u_8.FONT_BOLD,
		["TextTruncate"] = Enum.TextTruncate.AtEnd,
		["Position"] = UDim2.fromOffset(60, 0),
		["Size"] = UDim2.new(1, -120, 1, 0),
		["Parent"] = v151
	})
	v_u_69.Activated:Connect(function()
		-- upvalues: (ref) v_u_139
		v_u_139(-0.1)
	end)
	v_u_70.Activated:Connect(function()
		-- upvalues: (ref) v_u_139
		v_u_139(0.1)
	end)
	local v152 = v_u_8.new("Frame", {
		["Name"] = "Actions",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["LayoutOrder"] = 3,
		["Parent"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 42),
		["Parent"] = v_u_67
	})
	v_u_8.new("UIGridLayout", {
		["CellSize"] = UDim2.new(0.3333333333333333, -6, 1, 0),
		["CellPadding"] = UDim2.fromOffset(8, 0),
		["SortOrder"] = Enum.SortOrder.LayoutOrder,
		["Parent"] = v152
	})
	local v153 = v_u_8.button({
		["name"] = "Reset",
		["text"] = "\224\184\132\224\185\136\224\184\178\224\185\128\224\184\163\224\184\180\224\185\136\224\184\161\224\184\149\224\185\137\224\184\153",
		["grad"] = "dark",
		["textSize"] = 17,
		["parent"] = nil,
		["parent"] = v152
	})
	v153.LayoutOrder = 1
	local v154 = v_u_8.button({
		["name"] = "Save",
		["text"] = "\224\184\154\224\184\177\224\184\153\224\184\151\224\184\182\224\184\129",
		["grad"] = "green",
		["textSize"] = 17,
		["parent"] = nil,
		["parent"] = v152
	})
	v154.LayoutOrder = 2
	local v155 = v_u_8.button({
		["name"] = "Close",
		["text"] = "\224\184\155\224\184\180\224\184\148",
		["grad"] = "red",
		["textSize"] = 17,
		["parent"] = nil,
		["parent"] = v152
	})
	v155.LayoutOrder = 3
	v153.Activated:Connect(v_u_148)
	v154.Activated:Connect(function()
		-- upvalues: (ref) v_u_146
		task.spawn(v_u_146)
	end)
	v155.Activated:Connect(function()
		-- upvalues: (ref) v_u_10
		v_u_10.close()
	end)
end
local function v_u_176(p157) -- name: dragTo
	-- upvalues: (ref) v_u_73, (ref) v_u_67, (ref) v_u_65, (ref) v_u_15, (ref) v_u_14, (copy) v_u_86
	if v_u_73.bar then
		v_u_67.Position = v_u_73.start + UDim2.fromOffset(p157.X, p157.Y)
	else
		local v158 = v_u_65.AbsoluteSize
		local v159 = p157.X
		local v160 = -v_u_73.abs.X
		local v161 = v158.X - v_u_73.abs.X - v_u_73.size.X
		local v162 = math.max(v160, v161)
		local v163 = math.clamp(v159, v160, v162)
		local v164 = p157.Y
		local v165 = -v_u_73.abs.Y
		local v166 = v158.Y - v_u_73.abs.Y - v_u_73.size.Y
		local v167 = math.max(v165, v166)
		local v168 = math.clamp(v164, v165, v167)
		local v169 = (v_u_15 or v_u_14)[v_u_73.id]
		if v169 then
			local _ = v169.x
		end
		if v169 then
			local _ = v169.y
		end
		local v170 = not v169 and 1 or v169.s
		local v171 = v_u_86
		local v172 = v_u_73.id
		local v173 = (v_u_73.x + v163 / v_u_73.k) * 2 + 0.5
		local v174 = math.floor(v173) / 2
		local v175 = (v_u_73.y + v168 / v_u_73.k) * 2 + 0.5
		v171(v172, v174, math.floor(v175) / 2, v170)
	end
end
v5.InputChanged:Connect(function(p177)
	-- upvalues: (ref) v_u_16, (ref) v_u_73, (copy) v_u_176
	if v_u_16 then
		local v178
		if v_u_73 == nil then
			v178 = false
		elseif p177 == v_u_73.input then
			v178 = true
		elseif v_u_73.input.UserInputType == Enum.UserInputType.MouseButton1 then
			v178 = p177.UserInputType == Enum.UserInputType.MouseMovement
		else
			v178 = false
		end
		if v178 then
			v_u_176(Vector2.new(p177.Position.X, p177.Position.Y) - v_u_73.from)
		end
	end
end)
v5.InputEnded:Connect(function(p179)
	-- upvalues: (ref) v_u_73
	if v_u_73 and (p179 == v_u_73.input or v_u_73.input.UserInputType == Enum.UserInputType.MouseButton1 and p179.UserInputType == Enum.UserInputType.MouseButton1) then
		v_u_73 = nil
	end
end)
function v_u_10.open() -- name: open
	-- upvalues: (ref) v_u_16, (copy) v_u_8, (ref) v_u_65, (copy) v_u_156, (ref) v_u_15, (copy) v_u_22, (ref) v_u_14, (ref) v_u_17, (ref) v_u_72, (copy) v_u_10, (ref) v_u_74, (copy) v_u_4, (copy) v_u_130, (copy) v_u_108
	if not v_u_16 and v_u_8.isTouch() then
		if not (v_u_65 and v_u_65.Parent) then
			v_u_156()
		end
		v_u_15 = v_u_22(v_u_14)
		v_u_17 = false
		v_u_16 = true
		v_u_72 = nil
		v_u_65.Enabled = true
		v_u_10.changed:Fire(true)
		v_u_74 = v_u_4.RenderStepped:Connect(v_u_130)
		v_u_130()
		v_u_108()
	end
end
function v_u_10.close() -- name: close
	-- upvalues: (ref) v_u_16, (ref) v_u_17, (ref) v_u_73, (ref) v_u_72, (ref) v_u_15, (ref) v_u_74, (copy) v_u_71, (ref) v_u_65, (copy) v_u_13, (copy) v_u_34, (copy) v_u_10, (copy) v_u_9
	if v_u_16 then
		local v180 = v_u_17
		v_u_16 = false
		v_u_73 = nil
		v_u_72 = nil
		v_u_15 = nil
		if v_u_74 then
			v_u_74:Disconnect()
			v_u_74 = nil
		end
		for _, v181 in v_u_71 do
			v181:Destroy()
		end
		table.clear(v_u_71)
		v_u_65.Enabled = false
		for v182 in v_u_13 do
			v_u_34(v182)
		end
		v_u_10.changed:Fire(false)
		if v180 then
			v_u_9.show("\224\185\132\224\184\161\224\185\136\224\185\132\224\184\148\224\185\137\224\184\129\224\184\148\224\184\154\224\184\177\224\184\153\224\184\151\224\184\182\224\184\129 \224\184\155\224\184\184\224\185\136\224\184\161\224\184\129\224\184\165\224\184\177\224\184\154\224\185\132\224\184\155\224\184\151\224\184\181\224\185\136\224\185\128\224\184\148\224\184\180\224\184\161", "info")
		end
	end
end
function v_u_10.toggle() -- name: toggle
	-- upvalues: (ref) v_u_16, (copy) v_u_10
	if v_u_16 then
		v_u_10.close()
	else
		v_u_10.open()
	end
end
if v_u_4:IsStudio() then
	local v183 = Instance.new("BindableFunction")
	v183.Name = "ControlLayoutStudioTest"
	function v183.OnInvoke(p184, p185, p186, p187)
		-- upvalues: (copy) v_u_10, (ref) v_u_72, (copy) v_u_108, (copy) v_u_115, (ref) v_u_73, (copy) v_u_176, (copy) v_u_139, (copy) v_u_146, (ref) v_u_15, (ref) v_u_17, (copy) v_u_13, (copy) v_u_34, (copy) v_u_9, (ref) v_u_16, (copy) v_u_22, (ref) v_u_14, (copy) v_u_71, (copy) v_u_27, (copy) v_u_97, (ref) v_u_68
		if p184 == "open" then
			v_u_10.open()
		elseif p184 == "close" then
			v_u_10.close()
		elseif p184 == "pick" then
			v_u_72 = p185
			v_u_108()
		elseif p184 == "drag" then
			v_u_115(p185, {
				["Position"] = Vector3.new(0, 0, 0),
				["UserInputType"] = nil,
				["UserInputType"] = Enum.UserInputType.Touch
			})
			if v_u_73 then
				v_u_176(Vector2.new(p186, p187))
			end
			v_u_73 = nil
		elseif p184 == "size" then
			v_u_139(p185)
		elseif p184 == "save" then
			v_u_146()
		elseif p184 == "reset" and v_u_15 then
			v_u_15 = {}
			v_u_17 = true
			for v188 in v_u_13 do
				v_u_34(v188)
			end
			v_u_72 = nil
			v_u_108()
			v_u_9.show("\224\184\155\224\184\184\224\185\136\224\184\161\224\184\129\224\184\165\224\184\177\224\184\154\224\185\128\224\184\155\224\185\135\224\184\153\224\184\132\224\185\136\224\184\178\224\185\128\224\184\163\224\184\180\224\185\136\224\184\161\224\184\149\224\185\137\224\184\153\224\185\129\224\184\165\224\185\137\224\184\167 \194\183 \224\184\129\224\184\148\224\184\154\224\184\177\224\184\153\224\184\151\224\184\182\224\184\129\224\185\128\224\184\158\224\184\183\224\185\136\224\184\173\224\185\128\224\184\129\224\185\135\224\184\154\224\185\132\224\184\167\224\185\137", "info")
		end
		local v189 = {
			["editing"] = v_u_16,
			["dirty"] = v_u_17,
			["selected"] = v_u_72,
			["saved"] = v_u_22(v_u_14)
		}
		local v190
		if v_u_15 then
			v190 = v_u_22(v_u_15)
		else
			v190 = nil
		end
		v189.working = v190
		v189.controls = {}
		for v191, v192 in v_u_13 do
			local v193 = v_u_71[v191]
			local v194 = v189.controls
			local v195 = {
				["pos"] = v192.gui.AbsolutePosition,
				["size"] = v192.gui.AbsoluteSize
			}
			local v196
			if v192.scale then
				v196 = v192.scale.Scale
			else
				v196 = select(3, v_u_27(v191))
			end
			v195.scale = v196
			v195.shown = v_u_97(v192)
			v195.handle = v193 and (v193.Visible and {
				["pos"] = v193.AbsolutePosition,
				["size"] = v193.AbsoluteSize
			}) or nil
			v194[v191] = v195
		end
		local v197 = v_u_68
		if v197 then
			v197 = v_u_68.Text
		end
		v189.label = v197
		return v189
	end
	v183.Parent = v_u_12
end
return v_u_10