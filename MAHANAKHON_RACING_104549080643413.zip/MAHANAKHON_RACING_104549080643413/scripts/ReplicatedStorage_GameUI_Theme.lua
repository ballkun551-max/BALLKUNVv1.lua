-- Path: ReplicatedStorage/GameUI/Theme
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = require(game:GetService("ReplicatedStorage"):WaitForChild("UiOwn")).Instance
local v_u_2 = game:GetService("GuiService")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game:GetService("UserInputService")
local v_u_5 = {
	["PANEL"] = Color3.fromRGB(17, 18, 23),
	["PANEL_TRANSPARENCY"] = 0.02,
	["SIDEBAR"] = Color3.fromRGB(12, 13, 17),
	["CARD"] = Color3.fromRGB(29, 31, 38),
	["CARD_DARK"] = Color3.fromRGB(22, 23, 29),
	["CARD_HOVER"] = Color3.fromRGB(37, 39, 48),
	["TEXT"] = Color3.fromRGB(242, 243, 247),
	["TEXT_DIM"] = Color3.fromRGB(146, 150, 166),
	["ACCENT"] = Color3.fromRGB(232, 220, 56),
	["ACCENT_LIGHT"] = Color3.fromRGB(238, 228, 82),
	["ACCENT_DEEP"] = Color3.fromRGB(150, 136, 0)
}
v_u_5.YELLOW = v_u_5.ACCENT_LIGHT
v_u_5.GOLD = Color3.fromRGB(255, 196, 46)
v_u_5.GOLD_DARK = Color3.fromRGB(120, 72, 0)
v_u_5.LIME = Color3.fromRGB(76, 186, 84)
v_u_5.GREEN = Color3.fromRGB(22, 150, 92)
v_u_5.GREEN_TEXT = Color3.fromRGB(96, 232, 150)
v_u_5.BLUE = Color3.fromRGB(40, 122, 232)
v_u_5.RED = Color3.fromRGB(226, 48, 58)
v_u_5.ORANGE = Color3.fromRGB(255, 128, 32)
v_u_5.CYAN = Color3.fromRGB(70, 210, 255)
v_u_5.BORDER = Color3.new(1, 1, 1)
v_u_5.BORDER_TRANSPARENCY = 0.9
v_u_5.LCD = Color3.fromRGB(13, 15, 16)
v_u_5.LCD_UNLIT = Color3.fromRGB(44, 48, 56)
v_u_5.NIGHT_TEXT = Color3.fromRGB(150, 210, 255)
v_u_5.DARK_TEXT = Color3.fromRGB(24, 22, 10)
v_u_5.INK = Color3.fromRGB(16, 17, 22)
local v6 = { Color3.fromRGB(242, 232, 92), Color3.fromRGB(214, 190, 26) }
v_u_5.GRAD = {
	["gold"] = v6,
	["accent"] = v6,
	["money"] = { Color3.fromRGB(255, 226, 112), Color3.fromRGB(244, 150, 20) },
	["red"] = { Color3.fromRGB(255, 88, 88), Color3.fromRGB(204, 22, 44) },
	["green"] = { Color3.fromRGB(74, 222, 128), Color3.fromRGB(21, 140, 70) },
	["blue"] = { Color3.fromRGB(88, 168, 255), Color3.fromRGB(32, 94, 220) },
	["cyan"] = { Color3.fromRGB(96, 228, 255), Color3.fromRGB(18, 138, 210) },
	["purple"] = v6,
	["pink"] = { Color3.fromRGB(255, 116, 196), Color3.fromRGB(212, 38, 132) },
	["teal"] = { Color3.fromRGB(48, 214, 186), Color3.fromRGB(10, 136, 124) },
	["orange"] = { Color3.fromRGB(255, 176, 64), Color3.fromRGB(236, 104, 14) },
	["dark"] = { Color3.fromRGB(40, 42, 52), Color3.fromRGB(28, 30, 38) },
	["grey"] = { Color3.fromRGB(72, 75, 88), Color3.fromRGB(50, 53, 64) }
}
function v_u_5.accentOf(p7) -- name: accentOf
	-- upvalues: (copy) v_u_5
	if type(p7) ~= "table" then
		p7 = v_u_5.GRAD[p7 or "gold"] or v_u_5.GRAD.gold
	end
	return p7[1], p7[2]
end
function v_u_5.brandOf(p8) -- name: brandOf
	return p8 == "red" and "red" or "gold"
end
local v_u_9 = {
	["blue"] = true,
	["cyan"] = true,
	["purple"] = true,
	["pink"] = true,
	["teal"] = true,
	["orange"] = true
}
function v_u_5.buttonGrad(p10) -- name: buttonGrad
	-- upvalues: (copy) v_u_9
	if type(p10) == "string" and v_u_9[p10] then
		return "gold", true
	else
		return p10, false
	end
end
function v_u_5.lum(p11) -- name: lum
	return 0.299 * p11.R + 0.587 * p11.G + 0.114 * p11.B
end
function v_u_5.inkOn(p12) -- name: inkOn
	-- upvalues: (copy) v_u_5
	if 0.299 * p12.R + 0.587 * p12.G + 0.114 * p12.B > 0.62 then
		return v_u_5.INK
	else
		return Color3.new(1, 1, 1)
	end
end
function v_u_5.readable(p13, p14) -- name: readable
	-- upvalues: (copy) v_u_5
	if p14 == nil then
		return v_u_5.inkOn(p13)
	else
		local v15 = 0.299 * p13.R + 0.587 * p13.G + 0.114 * p13.B > 0.62
		if v15 and 0.299 * p14.R + 0.587 * p14.G + 0.114 * p14.B > 0.75 then
			return v_u_5.INK
		elseif v15 or 0.299 * p14.R + 0.587 * p14.G + 0.114 * p14.B >= 0.2 then
			return p14
		else
			return Color3.new(1, 1, 1)
		end
	end
end
v_u_5.FONT = Font.new("rbxasset://fonts/families/BuilderSans.json", Enum.FontWeight.Medium)
v_u_5.FONT_BOLD = Font.new("rbxasset://fonts/families/BuilderSans.json", Enum.FontWeight.Bold)
v_u_5.FONT_HEAVY = Font.new("rbxasset://fonts/families/BuilderSans.json", Enum.FontWeight.ExtraBold)
v_u_5.FONT_DIGITS = Font.new("rbxasset://fonts/families/RobotoMono.json", Enum.FontWeight.Bold)
v_u_5.FONT_DISPLAY = Font.new("rbxasset://fonts/families/Montserrat.json", Enum.FontWeight.Heavy)
v_u_5.FONT_TITLE = Font.new("rbxasset://fonts/families/Montserrat.json", Enum.FontWeight.Bold)
v_u_5.EDGE = 16
v_u_5.CORNER = 8
v_u_5.FADE = TweenInfo.new(0.15, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
v_u_5.POP = TweenInfo.new(0.28, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
v_u_5.QUICK = TweenInfo.new(0.1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
function v_u_5.touchDevice(p16) -- name: touchDevice
	-- upvalues: (copy) v_u_4
	local v_u_17 = p16 or v_u_4
	if not v_u_17.TouchEnabled then
		return false
	end
	if not (v_u_17.KeyboardEnabled and v_u_17.MouseEnabled) then
		return true
	end
	local v18, v19 = pcall(function()
		-- upvalues: (ref) v_u_17
		return v_u_17.PreferredInput == Enum.PreferredInput.Touch
	end)
	if v18 then
		v18 = v19 == true
	end
	return v18
end
local v_u_20 = nil
function v_u_5.isTouch() -- name: isTouch
	-- upvalues: (ref) v_u_20, (copy) v_u_5
	if v_u_20 == nil then
		v_u_20 = v_u_5.touchDevice()
		if game:GetService("RunService"):IsStudio() and workspace:GetAttribute("StudioTouchTest") == true then
			v_u_20 = true
		end
	end
	return v_u_20
end
v_u_5.PHONE_SHRINK = 0.8
function v_u_5.isPhone(p21) -- name: isPhone
	-- upvalues: (copy) v_u_5
	local v22 = workspace.CurrentCamera
	if not p21 then
		if v22 then
			p21 = v22.ViewportSize
		else
			p21 = Vector2.new(844, 390)
		end
	end
	local v23 = v_u_5.isTouch()
	if v23 then
		local v24 = p21.X
		local v25 = p21.Y
		v23 = math.min(v24, v25) <= 500
	end
	return v23
end
function v_u_5.new(p26, p27, p28) -- name: new
	-- upvalues: (copy) v_u_1
	local v29 = v_u_1.new(p26)
	for v30, v31 in p27 or {} do
		if v30 == "Parent" then
			continue
		end
		v29[v30] = v31
	end
	for _, v32 in p28 or {} do
		v32.Parent = v29
	end
	if p27 and p27.Parent then
		v29.Parent = p27.Parent
	end
	return v29
end
function v_u_5.corner(p33, p34) -- name: corner
	-- upvalues: (copy) v_u_5
	return v_u_5.new("UICorner", {
		["CornerRadius"] = UDim.new(0, p34 or v_u_5.CORNER),
		["Parent"] = p33
	})
end
function v_u_5.border(p35, p36, p37, p38) -- name: border
	-- upvalues: (copy) v_u_5
	return v_u_5.new("UIStroke", {
		["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
		["Color"] = p36 or v_u_5.BORDER,
		["Transparency"] = p37 or v_u_5.BORDER_TRANSPARENCY,
		["Thickness"] = p38 or 1.2,
		["Parent"] = p35
	})
end
function v_u_5.padding(p39, p40, p41) -- name: padding
	-- upvalues: (copy) v_u_5
	return v_u_5.new("UIPadding", {
		["PaddingLeft"] = UDim.new(0, p40),
		["PaddingRight"] = UDim.new(0, p40),
		["PaddingTop"] = UDim.new(0, p41 or p40),
		["PaddingBottom"] = UDim.new(0, p41 or p40),
		["Parent"] = p39
	})
end
function v_u_5.gradient(p42, p43, p44) -- name: gradient
	-- upvalues: (copy) v_u_5
	if type(p43) == "string" then
		p43 = v_u_5.GRAD[p43]
	end
	return v_u_5.new("UIGradient", {
		["Color"] = ColorSequence.new(p43[1], p43[2]),
		["Rotation"] = p44 or 90,
		["Parent"] = p42
	})
end
function v_u_5.gloss(p45, p46, p47) -- name: gloss
	-- upvalues: (copy) v_u_5
	local v48 = v_u_5.new("Frame", {
		["Name"] = "Gloss",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["ZIndex"] = nil,
		["Active"] = false,
		["Parent"] = nil,
		["BackgroundColor3"] = Color3.new(1, 1, 1),
		["BackgroundTransparency"] = 1 - (p47 or 0.22),
		["Size"] = UDim2.fromScale(1, 0.5),
		["ZIndex"] = p45.ZIndex,
		["Parent"] = p45
	})
	v_u_5.corner(v48, p46 or v_u_5.CORNER)
	v_u_5.new("UIGradient", {
		["Rotation"] = 90,
		["Transparency"] = nil,
		["Parent"] = nil,
		["Transparency"] = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 1) }),
		["Parent"] = v48
	})
	return v48
end
function v_u_5.shadow(p_u_49, p50, p51, p52) -- name: shadow
	-- upvalues: (copy) v_u_5
	if p_u_49.ZIndex <= 1 then
		p_u_49.ZIndex = 2
	end
	local v53 = v_u_5.new
	local v54 = {
		["Name"] = nil,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = nil,
		["Parent"] = nil,
		["Name"] = p_u_49.Name .. "Shadow",
		["BackgroundColor3"] = Color3.new(0, 0, 0),
		["BackgroundTransparency"] = p52 or 0.55,
		["AnchorPoint"] = p_u_49.AnchorPoint,
		["Position"] = p_u_49.Position + UDim2.fromOffset(0, p51 or 4),
		["Size"] = p_u_49.Size
	}
	local v55 = p_u_49.ZIndex - 1
	v54.ZIndex = math.max(v55, 1)
	v54.Parent = p_u_49.Parent
	local v_u_56 = v53("Frame", v54)
	v_u_5.corner(v_u_56, p50 or v_u_5.CORNER)
	p_u_49:GetPropertyChangedSignal("Visible"):Connect(function()
		-- upvalues: (copy) v_u_56, (copy) p_u_49
		v_u_56.Visible = p_u_49.Visible
	end)
	v_u_56.Visible = p_u_49.Visible
	return v_u_56
end
function v_u_5.panel(p57) -- name: panel
	-- upvalues: (copy) v_u_5
	local v58 = v_u_5.new("Frame", p57)
	if not (p57 and p57.BackgroundColor3) then
		v58.BackgroundColor3 = v_u_5.PANEL
	end
	if not (p57 and p57.BackgroundTransparency) then
		v58.BackgroundTransparency = v_u_5.PANEL_TRANSPARENCY
	end
	v58.BorderSizePixel = 0
	v_u_5.corner(v58)
	v_u_5.border(v58, Color3.new(1, 1, 1), 0.9, 1)
	return v58
end
function v_u_5.text(p59) -- name: text
	-- upvalues: (copy) v_u_5
	local v60 = v_u_5.new(p59.ClassName or "TextLabel", {
		["BackgroundTransparency"] = 1,
		["FontFace"] = nil,
		["TextColor3"] = nil,
		["TextSize"] = 16,
		["FontFace"] = v_u_5.FONT,
		["TextColor3"] = v_u_5.TEXT
	})
	for v61, v62 in p59 do
		if v61 == "ClassName" then
			continue
		end
		v60[v61] = v62
	end
	return v60
end
local function v_u_65(p63, p64) -- name: kp
	return NumberSequenceKeypoint.new(p63, p64)
end
function v_u_5.slant(p_u_66, p_u_67, p68) -- name: slant
	-- upvalues: (copy) v_u_5, (copy) v_u_65
	local v_u_69 = p68 or (p_u_66:FindFirstChildOfClass("UIGradient") or v_u_5.new("UIGradient", {
		["Parent"] = p_u_66
	}))
	local function v91() -- name: fit
		-- upvalues: (copy) p_u_66, (copy) p_u_67, (copy) v_u_69, (ref) v_u_65
		local v70 = p_u_66.AbsoluteSize
		local v71 = v70.X
		local v72 = v70.Y
		if v71 >= 4 and v72 >= 4 then
			local v73 = p_u_67
			local v74 = v72 * 0.6
			local v75 = v71 * 0.2
			local v76 = math.min(v73, v74, v75) / v72
			local v77 = math.atan(v76)
			local v78 = v71 * math.cos(v77) + v72 * math.sin(v77)
			local v79 = v72 * math.sin(v77) / v78
			local v80 = math.clamp(v79, 0.0005, 0.45)
			v_u_69.Rotation = math.deg(v77)
			local v81 = v_u_69
			local v82 = NumberSequence.new
			local v83 = {}
			local v84 = NumberSequenceKeypoint.new(0, 1)
			local v85 = NumberSequenceKeypoint.new(v80, 1)
			local v86 = v80 + 0.0004
			local v87 = NumberSequenceKeypoint.new(v86, 0)
			local v88 = 1 - v80 - 0.0004
			local v89 = NumberSequenceKeypoint.new(v88, 0)
			local v90 = 1 - v80
			__set_list(v83, 1, {v84, v85, v87, v89, NumberSequenceKeypoint.new(v90, 1), v_u_65(1, 1)})
			v81.Transparency = v82(v83)
		end
	end
	p_u_66:GetPropertyChangedSignal("AbsoluteSize"):Connect(v91)
	v91()
	return v_u_69
end
function v_u_5.chip(p92, p93, p94, p95) -- name: chip
	-- upvalues: (copy) v_u_5
	if typeof(p94) ~= "Color3" then
		local v96 = p94 or "gold"
		if type(v96) ~= "table" then
			v96 = v_u_5.GRAD[v96 or "gold"] or v_u_5.GRAD.gold
		end
		p94 = v96[1]
		local _ = v96[2]
	end
	local v97 = v_u_5.new("Frame", {
		["Name"] = "Chip",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["ZIndex"] = 4,
		["Parent"] = nil,
		["BackgroundColor3"] = p94,
		["Size"] = UDim2.fromOffset(0, 20),
		["AutomaticSize"] = Enum.AutomaticSize.X,
		["Parent"] = p92
	})
	for v98, v99 in p95 or {} do
		v97[v98] = v99
	end
	v_u_5.corner(v97, 4)
	v_u_5.new("UIPadding", {
		["PaddingLeft"] = UDim.new(0, 7),
		["PaddingRight"] = UDim.new(0, 7),
		["Parent"] = v97
	})
	v_u_5.text({
		["Name"] = "Text",
		["Text"] = nil,
		["TextSize"] = 11,
		["FontFace"] = nil,
		["TextColor3"] = nil,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["ZIndex"] = nil,
		["Parent"] = nil,
		["Text"] = string.upper(p93 or ""),
		["FontFace"] = v_u_5.FONT_HEAVY,
		["TextColor3"] = v_u_5.inkOn(p94),
		["Size"] = UDim2.fromScale(0, 1),
		["AutomaticSize"] = Enum.AutomaticSize.X,
		["ZIndex"] = v97.ZIndex,
		["Parent"] = v97
	})
	return v97
end
v_u_5.BUTTON_SLANT = false
local v_u_100 = nil
function v_u_5.button(p101) -- name: button
	-- upvalues: (ref) v_u_100, (copy) v_u_5, (copy) v_u_9, (copy) v_u_3
	v_u_100 = v_u_100 or require(script.Parent:WaitForChild("Icons"))
	local v102 = v_u_5.new("TextButton", {
		["Name"] = nil,
		["Text"] = "",
		["AutoButtonColor"] = false,
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = nil,
		["Parent"] = nil,
		["Name"] = p101.name or "Button",
		["BackgroundColor3"] = Color3.new(1, 1, 1),
		["AnchorPoint"] = p101.anchor or Vector2.zero,
		["Position"] = p101.position or UDim2.new(),
		["Size"] = p101.size or UDim2.fromOffset(140, 44),
		["ZIndex"] = p101.zindex or 1,
		["Parent"] = p101.parent
	})
	local v103 = p101.grad
	local v104 = type(v103) == "string" and v_u_9[v103] and "gold" or v103
	if type(v104) ~= "table" then
		v104 = v_u_5.GRAD[v104 or "gold"] or v_u_5.GRAD.gold
	end
	local v105 = v_u_5.new("UIGradient", {
		["Color"] = ColorSequence.new(v104[1], v104[2]),
		["Parent"] = v102
	})
	if p101.slant == false or not v_u_5.BUTTON_SLANT then
		v_u_5.corner(v102, p101.radius or 8)
		v105.Rotation = 90
	else
		v_u_5.slant(v102, p101.slant or 10, v105)
	end
	v_u_5.new("UIStroke", {
		["Name"] = "Glow",
		["ApplyStrokeMode"] = nil,
		["Color"] = nil,
		["Transparency"] = 1,
		["Thickness"] = 1,
		["Enabled"] = false,
		["Parent"] = nil,
		["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
		["Color"] = v104[1],
		["Parent"] = v102
	})
	local v106 = v_u_5.readable(v104[1], p101.textColor)
	local v107 = v_u_5.new("Frame", {
		["Name"] = "Row",
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["ZIndex"] = nil,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.5),
		["Size"] = UDim2.fromScale(0, 1),
		["AutomaticSize"] = Enum.AutomaticSize.X,
		["ZIndex"] = v102.ZIndex + 1,
		["Parent"] = v102
	})
	v_u_5.new("UIListLayout", {
		["FillDirection"] = Enum.FillDirection.Horizontal,
		["VerticalAlignment"] = Enum.VerticalAlignment.Center,
		["HorizontalAlignment"] = Enum.HorizontalAlignment.Center,
		["Padding"] = UDim.new(0, 8),
		["SortOrder"] = Enum.SortOrder.LayoutOrder,
		["Parent"] = v107
	})
	if p101.icon then
		local v108 = v_u_100.make
		local v109 = p101.icon
		local v110 = p101.iconSize
		if not v110 then
			local v111 = (p101.textSize or 18) * 1.1
			v110 = math.floor(v111)
		end
		local v112 = v108(v109, v106, v110)
		v112.LayoutOrder = 1
		for _, v113 in v112:GetDescendants() do
			if not v113:IsA("GuiObject") then
				continue
			end
			v113.ZIndex = v102.ZIndex + 2
		end
		v112.ZIndex = v102.ZIndex + 2
		v112.Parent = v107
	end
	local v114 = v_u_5.text
	local v115 = {
		["Name"] = "Caption",
		["Text"] = nil,
		["FontFace"] = nil,
		["TextSize"] = nil,
		["TextColor3"] = nil,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["LayoutOrder"] = 2,
		["ZIndex"] = nil,
		["Parent"] = nil,
		["Text"] = string.upper(p101.text or ""),
		["FontFace"] = v_u_5.FONT_HEAVY
	}
	local v116 = (p101.textSize or 18) * 0.9
	v115.TextSize = math.floor(v116)
	v115.TextColor3 = v106
	v115.Size = UDim2.fromScale(0, 1)
	v115.AutomaticSize = Enum.AutomaticSize.X
	v115.ZIndex = v102.ZIndex + 2
	v115.Parent = v107
	local v117 = v114(v115)
	local v_u_118 = v_u_5.new("UIScale", {
		["Parent"] = v102
	})
	v102.MouseEnter:Connect(function()
		-- upvalues: (ref) v_u_3, (copy) v_u_118, (ref) v_u_5
		v_u_3:Create(v_u_118, v_u_5.QUICK, {
			["Scale"] = 1.03
		}):Play()
	end)
	v102.MouseLeave:Connect(function()
		-- upvalues: (ref) v_u_3, (copy) v_u_118, (ref) v_u_5
		v_u_3:Create(v_u_118, v_u_5.QUICK, {
			["Scale"] = 1
		}):Play()
	end)
	v102.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_3, (copy) v_u_118, (ref) v_u_5
		v_u_3:Create(v_u_118, v_u_5.QUICK, {
			["Scale"] = 0.96
		}):Play()
	end)
	v102.MouseButton1Up:Connect(function()
		-- upvalues: (ref) v_u_3, (copy) v_u_118, (ref) v_u_5
		v_u_3:Create(v_u_118, v_u_5.QUICK, {
			["Scale"] = 1
		}):Play()
	end)
	return v102, v117, v105
end
function v_u_5.setButton(p119, p120, p121, p122) -- name: setButton
	-- upvalues: (copy) v_u_9, (copy) v_u_5
	local v123 = p119:FindFirstChildOfClass("UIGradient")
	local v124 = type(p120) == "string" and v_u_9[p120] and "gold" or p120
	if v123 and v124 then
		if type(v124) ~= "table" then
			v124 = v_u_5.GRAD[v124 or "gold"] or v_u_5.GRAD.gold
		end
		v123.Color = ColorSequence.new(v124[1], v124[2])
		p122 = v_u_5.readable(v124[1], p122)
	end
	local v125 = p119:FindFirstChild("Row")
	if v125 then
		v125 = p119.Row:FindFirstChild("Caption")
	end
	if v125 then
		if p121 then
			v125.Text = string.upper(p121)
		end
		if p122 then
			v125.TextColor3 = p122
		end
	end
end
function v_u_5.badge(p126, p127, p128, p129, p130) -- name: badge
	-- upvalues: (ref) v_u_100, (copy) v_u_9, (copy) v_u_5
	v_u_100 = v_u_100 or require(script.Parent:WaitForChild("Icons"))
	local v131 = type(p128) == "string" and v_u_9[p128] and "gold" or p128
	if type(v131) ~= "table" then
		v131 = v_u_5.GRAD[v131 or "gold"] or v_u_5.GRAD.gold
	end
	local v132 = v_u_5.new("Frame", {
		["Name"] = "Badge",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = Color3.new(1, 1, 1),
		["Size"] = UDim2.fromOffset(p129, p129),
		["Parent"] = p126
	})
	local v133 = v_u_5.corner
	local v134 = p129 * 0.22
	v133(v132, (math.floor(v134)))
	v_u_5.new("UIGradient", {
		["Rotation"] = 135,
		["Color"] = nil,
		["Parent"] = nil,
		["Color"] = ColorSequence.new(v131[1], v131[2]),
		["Parent"] = v132
	})
	local v135 = v_u_100.make
	local v136 = p130 or v_u_5.inkOn(v131[1])
	local v137 = p129 * 0.56
	local v138 = v135(p127, v136, (math.floor(v137)))
	v138.AnchorPoint = Vector2.new(0.5, 0.5)
	v138.Position = UDim2.fromScale(0.5, 0.5)
	v138.Parent = v132
	return v132, v138
end
function v_u_5.header(p139, p140, p141, p142, p143) -- name: header
	-- upvalues: (copy) v_u_5
	local v144 = v_u_5.new("Frame", {
		["Name"] = "Header",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Parent"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 46),
		["Parent"] = p139
	})
	v_u_5.badge(v144, p140 or "store", p141 == "red" and "red" or "gold", 44).Position = UDim2.fromOffset(0, 1)
	return v144, v_u_5.text({
		["Name"] = "Title",
		["Text"] = nil,
		["TextSize"] = 22,
		["FontFace"] = nil,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["TextTruncate"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Text"] = string.upper(p142 or ""),
		["FontFace"] = v_u_5.FONT_DISPLAY,
		["TextColor3"] = v_u_5.TEXT,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["TextTruncate"] = Enum.TextTruncate.AtEnd,
		["Position"] = UDim2.fromOffset(56, 0),
		["Size"] = UDim2.new(1, -112, 0, 26),
		["Parent"] = v144
	}), v_u_5.text({
		["Name"] = "Sub",
		["Text"] = nil,
		["TextSize"] = 14,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["TextTruncate"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Text"] = p143 or "",
		["TextColor3"] = v_u_5.TEXT_DIM,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["TextTruncate"] = Enum.TextTruncate.AtEnd,
		["Position"] = UDim2.fromOffset(56, 27),
		["Size"] = UDim2.new(1, -112, 0, 18),
		["Parent"] = v144
	})
end
local v_u_145 = Color3.fromRGB(30, 32, 40)
function v_u_5.closeButton(p146) -- name: closeButton
	-- upvalues: (ref) v_u_100, (copy) v_u_5, (copy) v_u_145, (copy) v_u_3
	v_u_100 = v_u_100 or require(script.Parent:WaitForChild("Icons"))
	local v_u_147 = v_u_5.new("TextButton", {
		["Name"] = "Close",
		["Text"] = "",
		["AutoButtonColor"] = false,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_145,
		["AnchorPoint"] = Vector2.new(1, 0),
		["Position"] = UDim2.new(1, 0, 0, 3),
		["Size"] = UDim2.fromOffset(38, 38),
		["Parent"] = p146
	})
	v_u_5.corner(v_u_147, 6)
	v_u_5.border(v_u_147, Color3.new(1, 1, 1), 0.88, 1)
	local v148 = v_u_100.make("close", v_u_5.TEXT, 20)
	v148.AnchorPoint = Vector2.new(0.5, 0.5)
	v148.Position = UDim2.fromScale(0.5, 0.5)
	v148.Parent = v_u_147
	v_u_147.MouseEnter:Connect(function()
		-- upvalues: (ref) v_u_3, (copy) v_u_147, (ref) v_u_5
		v_u_3:Create(v_u_147, v_u_5.QUICK, {
			["BackgroundColor3"] = v_u_5.RED
		}):Play()
	end)
	v_u_147.MouseLeave:Connect(function()
		-- upvalues: (ref) v_u_3, (copy) v_u_147, (ref) v_u_5, (ref) v_u_145
		local v149 = {
			["BackgroundColor3"] = v_u_145
		}
		v_u_3:Create(v_u_147, v_u_5.QUICK, v149):Play()
	end)
	return v_u_147
end
local v_u_150 = setmetatable({}, {
	["__mode"] = "k"
})
local function v_u_185(p_u_151, p152, p153, p_u_154, p155) -- name: railTabs
	-- upvalues: (copy) v_u_5, (ref) v_u_100
	local v_u_156 = v_u_5.new("Frame", {
		["Name"] = "TabSet",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["Parent"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 0),
		["AutomaticSize"] = Enum.AutomaticSize.Y,
		["Parent"] = p_u_151.nav
	})
	v_u_5.new("UIListLayout", {
		["Padding"] = UDim.new(0, 4),
		["SortOrder"] = Enum.SortOrder.LayoutOrder,
		["Parent"] = v_u_156
	})
	local v157 = p_u_151.touch
	local v158 = v157 and 50 or 40
	local v_u_159 = p152:FindFirstChild("PageTitle")
	if not v_u_159 then
		v_u_159 = v_u_5.new("Frame", {
			["Name"] = "PageTitle",
			["BackgroundTransparency"] = 1,
			["Size"] = nil,
			["Parent"] = nil,
			["Size"] = UDim2.new(1, 0, 0, p155),
			["Parent"] = p152
		})
		v_u_5.text({
			["Name"] = "Title",
			["Text"] = "",
			["FontFace"] = nil,
			["TextSize"] = nil,
			["TextXAlignment"] = nil,
			["TextYAlignment"] = nil,
			["TextTruncate"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["FontFace"] = v_u_5.FONT_DISPLAY,
			["TextSize"] = v157 and 20 or 24,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["TextYAlignment"] = Enum.TextYAlignment.Center,
			["TextTruncate"] = Enum.TextTruncate.AtEnd,
			["Position"] = UDim2.fromOffset(0, -3),
			["Size"] = UDim2.new(1, 0, 1, -3),
			["Parent"] = v_u_159
		})
		local v160 = v_u_5.new("Frame", {
			["Name"] = "Line",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["BackgroundColor3"] = v_u_5.ACCENT,
			["AnchorPoint"] = Vector2.new(0, 1),
			["Position"] = UDim2.new(0, 0, 1, -2),
			["Size"] = UDim2.fromOffset(34, 3),
			["Parent"] = v_u_159
		})
		v_u_5.corner(v160, 2)
	end
	local v_u_161 = v_u_159:FindFirstChild("Title")
	local v_u_162 = {}
	local v_u_163 = nil
	local function v_u_172() -- name: paint
		-- upvalues: (copy) v_u_162, (ref) v_u_163, (ref) v_u_5, (ref) v_u_100, (copy) v_u_161
		for v164, v165 in v_u_162 do
			local v166 = v164 == v_u_163
			v165.button.BackgroundTransparency = v166 and 0 or 1
			v165.button.BackgroundColor3 = v_u_5.CARD_HOVER
			v165.bar.Visible = v166
			local v167 = v_u_100.tint
			local v168 = v165.icon
			local v169
			if v166 then
				v169 = v_u_5.ACCENT_LIGHT
			else
				v169 = v_u_5.TEXT_DIM
			end
			v167(v168, v169)
			local v170 = v165.caption
			local v171
			if v166 then
				v171 = v_u_5.TEXT
			else
				v171 = Color3.fromRGB(184, 187, 200)
			end
			v170.TextColor3 = v171
			if not (v166 and v_u_161) then
				continue
			end
			v_u_161.Text = string.upper(v165.label)
		end
	end
	local v_u_173 = v_u_163
	for v174, v_u_175 in p153 do
		local v_u_176 = v_u_5.new("TextButton", {
			["Name"] = nil,
			["Text"] = "",
			["AutoButtonColor"] = false,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 1,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["LayoutOrder"] = nil,
			["Parent"] = nil,
			["Name"] = v_u_175.id,
			["BackgroundColor3"] = v_u_5.CARD_HOVER,
			["Size"] = UDim2.new(1, 0, 0, v158),
			["LayoutOrder"] = v174,
			["Parent"] = v_u_156
		})
		v_u_5.corner(v_u_176, 6)
		local v177 = v_u_5.new("Frame", {
			["Name"] = "Picked",
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Visible"] = false,
			["Parent"] = nil,
			["BackgroundColor3"] = v_u_5.ACCENT,
			["AnchorPoint"] = Vector2.new(0, 0.5),
			["Position"] = UDim2.new(0, 0, 0.5, 0),
			["Size"] = UDim2.new(0, 3, 0.56, 0),
			["Parent"] = v_u_176
		})
		v_u_5.corner(v177, 2)
		local v178 = v_u_100.make(v_u_175.icon or "star", v_u_5.TEXT_DIM, v157 and 22 or 18)
		v178.AnchorPoint = Vector2.new(v157 and 0.5 or 0, 0.5)
		local v179
		if v157 then
			v179 = UDim2.fromScale(0.5, 0.5)
		else
			v179 = UDim2.new(0, 14, 0.5, 0)
		end
		v178.Position = v179
		v178.Parent = v_u_176
		local v180 = v_u_5.text({
			["Name"] = "Caption",
			["Text"] = nil,
			["TextSize"] = 14,
			["FontFace"] = nil,
			["TextColor3"] = nil,
			["TextXAlignment"] = nil,
			["TextTruncate"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Visible"] = nil,
			["Parent"] = nil,
			["Text"] = v_u_175.label,
			["FontFace"] = v_u_5.FONT_BOLD,
			["TextColor3"] = v_u_5.TEXT_DIM,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["TextTruncate"] = Enum.TextTruncate.AtEnd,
			["Position"] = UDim2.fromOffset(42, 0),
			["Size"] = UDim2.new(1, -50, 1, 0),
			["Visible"] = not v157,
			["Parent"] = v_u_176
		})
		v_u_162[v_u_175.id] = {
			["button"] = v_u_176,
			["caption"] = v180,
			["icon"] = v178,
			["bar"] = v177,
			["label"] = v_u_175.label
		}
		v_u_176.MouseEnter:Connect(function()
			-- upvalues: (ref) v_u_173, (copy) v_u_175, (copy) v_u_176
			if v_u_173 ~= v_u_175.id then
				v_u_176.BackgroundTransparency = 0.4
			end
		end)
		v_u_176.MouseLeave:Connect(function()
			-- upvalues: (ref) v_u_173, (copy) v_u_175, (copy) v_u_176
			if v_u_173 ~= v_u_175.id then
				v_u_176.BackgroundTransparency = 1
			end
		end)
		v_u_176.Activated:Connect(function()
			-- upvalues: (ref) v_u_173, (copy) v_u_175, (copy) v_u_172, (copy) p_u_154
			if v_u_173 ~= v_u_175.id then
				v_u_173 = v_u_175.id
				v_u_172()
				p_u_154(v_u_175.id)
			end
		end)
	end
	local function v182(p181) -- name: select
		-- upvalues: (ref) v_u_173, (copy) v_u_172
		v_u_173 = p181
		v_u_172()
	end
	v_u_156.Destroying:Connect(function()
		-- upvalues: (ref) v_u_159, (copy) p_u_151, (copy) v_u_161
		if v_u_159.Parent and not p_u_151.nav:FindFirstChild("TabSet") then
			v_u_161.Text = ""
		end
	end)
	v_u_156.ChildAdded:Connect(function(p_u_183)
		-- upvalues: (copy) v_u_156
		if p_u_183:IsA("GuiObject") then
			task.delay(1, function()
				-- upvalues: (ref) v_u_156, (copy) p_u_183
				local v184 = v_u_156:FindFirstAncestorWhichIsA("ScreenGui")
				require(game:GetService("ReplicatedStorage"):WaitForChild("UiGuardShared")).sealed((not v184 and "?" or v184.Name) .. "/Tabs", p_u_183)
			end)
		end
	end)
	if p_u_151.onTabs then
		p_u_151.onTabs()
	end
	return v_u_156, v182
end
function v_u_5.tabs(p186, p187, p_u_188, p189) -- name: tabs
	-- upvalues: (ref) v_u_100, (copy) v_u_150, (copy) v_u_185, (copy) v_u_5
	v_u_100 = v_u_100 or require(script.Parent:WaitForChild("Icons"))
	local v190 = p186
	local v191 = p189 or 48
	while p186 and p186:IsA("GuiObject") do
		local v192 = v_u_150[p186]
		if v192 then
			if v192.nav and not v192.nav:FindFirstChild("TabSet") then
				return v_u_185(v192, v190, p187, p_u_188, v191)
			end
			break
		end
		p186 = p186.Parent
	end
	local v_u_193 = v_u_5.new("Frame", {
		["Name"] = "Tabs",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_5.CARD_DARK,
		["Size"] = UDim2.new(1, 0, 0, v191),
		["Parent"] = v190
	})
	v_u_5.corner(v_u_193, 6)
	v_u_5.border(v_u_193, Color3.new(1, 1, 1), 0.92, 1)
	v_u_5.padding(v_u_193, 4)
	v_u_5.new("UIListLayout", {
		["FillDirection"] = Enum.FillDirection.Horizontal,
		["Padding"] = UDim.new(0, 4),
		["SortOrder"] = Enum.SortOrder.LayoutOrder,
		["Parent"] = v_u_193
	})
	local v_u_194 = {}
	local v_u_195 = nil
	local v196 = v_u_5.isTouch()
	local function v_u_205() -- name: paint
		-- upvalues: (copy) v_u_194, (ref) v_u_195, (ref) v_u_5, (ref) v_u_100
		for v197, v198 in v_u_194 do
			local v199 = v197 == v_u_195
			v198.button.BackgroundTransparency = v199 and 0 or 1
			local v200 = v198.caption
			local v201
			if v199 then
				v201 = Color3.new(1, 1, 1)
			else
				v201 = v_u_5.TEXT_DIM
			end
			v200.TextColor3 = v201
			local v202 = v_u_100.tint
			local v203 = v198.icon
			local v204
			if v199 then
				v204 = Color3.new(1, 1, 1)
			else
				v204 = v_u_5.TEXT_DIM
			end
			v202(v203, v204)
		end
	end
	local v_u_206 = v_u_195
	for v207, v_u_208 in p187 do
		local v209 = v_u_5.new("TextButton", {
			["Name"] = nil,
			["Text"] = "",
			["AutoButtonColor"] = false,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 1,
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["LayoutOrder"] = nil,
			["Parent"] = nil,
			["Name"] = v_u_208.id,
			["BackgroundColor3"] = Color3.new(1, 1, 1),
			["Size"] = UDim2.new(1 / #p187, 4 / #p187 + -4, 1, 0),
			["LayoutOrder"] = v207,
			["Parent"] = v_u_193
		})
		v_u_5.corner(v209, 5)
		local v210 = v_u_208.grad == "red" and "red" or "gold"
		if type(v210) ~= "table" then
			v210 = v_u_5.GRAD[v210 or "gold"] or v_u_5.GRAD.gold
		end
		v_u_5.new("UIGradient", {
			["Color"] = ColorSequence.new(v210[1], v210[2]),
			["Parent"] = v209
		})
		local v211 = v_u_5.new("Frame", {
			["BackgroundTransparency"] = 1,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["AutomaticSize"] = nil,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5, 0.5),
			["Size"] = UDim2.fromScale(0, 1),
			["AutomaticSize"] = Enum.AutomaticSize.X,
			["Parent"] = v209
		})
		v_u_5.new("UIListLayout", {
			["FillDirection"] = Enum.FillDirection.Horizontal,
			["VerticalAlignment"] = Enum.VerticalAlignment.Center,
			["HorizontalAlignment"] = Enum.HorizontalAlignment.Center,
			["Padding"] = UDim.new(0, 7),
			["SortOrder"] = Enum.SortOrder.LayoutOrder,
			["Parent"] = v211
		})
		local v212 = v_u_100.make(v_u_208.icon, v_u_5.TEXT_DIM, 20)
		v212.LayoutOrder = 1
		v212.Parent = v211
		local v213 = {
			["button"] = v209,
			["caption"] = v_u_5.text({
				["Text"] = nil,
				["TextSize"] = nil,
				["FontFace"] = nil,
				["TextColor3"] = nil,
				["Size"] = nil,
				["AutomaticSize"] = nil,
				["LayoutOrder"] = 2,
				["Parent"] = nil,
				["Text"] = v_u_208.label,
				["TextSize"] = v196 and 14 or 15,
				["FontFace"] = v_u_5.FONT_HEAVY,
				["TextColor3"] = v_u_5.TEXT_DIM,
				["Size"] = UDim2.fromScale(0, 1),
				["AutomaticSize"] = Enum.AutomaticSize.X,
				["Parent"] = v211
			}),
			["icon"] = v212
		}
		v_u_194[v_u_208.id] = v213
		v209.Activated:Connect(function()
			-- upvalues: (ref) v_u_206, (copy) v_u_208, (copy) v_u_205, (copy) p_u_188
			if v_u_206 ~= v_u_208.id then
				v_u_206 = v_u_208.id
				v_u_205()
				p_u_188(v_u_208.id)
			end
		end)
	end
	v_u_193.ChildAdded:Connect(function(p_u_214)
		-- upvalues: (copy) v_u_193
		if p_u_214:IsA("GuiObject") then
			task.delay(1, function()
				-- upvalues: (ref) v_u_193, (copy) p_u_214
				local v215 = v_u_193:FindFirstAncestorWhichIsA("ScreenGui")
				require(game:GetService("ReplicatedStorage"):WaitForChild("UiGuardShared")).sealed((not v215 and "?" or v215.Name) .. "/Tabs", p_u_214)
			end)
		end
	end)
	return v_u_193, function(p216) -- name: select
		-- upvalues: (ref) v_u_206, (copy) v_u_205
		v_u_206 = p216
		v_u_205()
	end
end
local v_u_217 = Color3.new(1, 1, 1)
local v_u_218 = {}
function v_u_5.neon(p219, p220, p221, p222) -- name: neon
	-- upvalues: (copy) v_u_5, (copy) v_u_217, (copy) v_u_218
	if type(p220) ~= "table" then
		p220 = v_u_5.GRAD[p220 or "gold"] or v_u_5.GRAD.gold
	end
	local v223 = p220[1]
	local v224 = p220[2]
	local v225 = v223:Lerp(v_u_217, 0.5)
	local v226 = p219:FindFirstChildOfClass("UIStroke") or v_u_5.new("UIStroke", {
		["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
		["Parent"] = p219
	})
	v226.Color = v_u_217
	v226.Thickness = 1.8
	v226.Transparency = 0
	local v227 = v226:FindFirstChildOfClass("UIGradient") or v_u_5.new("UIGradient", {
		["Parent"] = v226
	})
	v227.Color = ColorSequence.new({
		ColorSequenceKeypoint.new(0, v224),
		ColorSequenceKeypoint.new(0.4, v223),
		ColorSequenceKeypoint.new(0.5, v225),
		ColorSequenceKeypoint.new(0.6, v223),
		ColorSequenceKeypoint.new(1, v224)
	})
	v227.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.6), NumberSequenceKeypoint.new(0.5, 0), NumberSequenceKeypoint.new(1, 0.6) })
	local v228 = v_u_218
	table.insert(v228, {
		["gradient"] = v227,
		["owner"] = p219
	})
	local v229 = p221 or 0
	local v230 = p222 or 10
	for _, v231 in {
		{ 4, 0.7, 2 },
		{ 12, 0.88, 6 }
	} do
		local v232 = {
			["BackgroundTransparency"] = 1,
			["Position"] = nil,
			["Size"] = nil,
			["Position"] = UDim2.fromOffset(-v229 - v231[3], -v229 - v231[3]),
			["Size"] = UDim2.new(1, (v229 + v231[3]) * 2, 1, (v229 + v231[3]) * 2),
			["Name"] = "Glow",
			["BorderSizePixel"] = 0,
			["Active"] = false
		}
		v232.ZIndex = v232.ZIndex or 0
		v232.Parent = p219
		local v233 = v_u_5.new("Frame", v232)
		v_u_5.corner(v233, v230 + v231[3])
		v_u_5.new("UIStroke", {
			["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
			["Color"] = v223,
			["Thickness"] = v231[1],
			["Transparency"] = v231[2],
			["Parent"] = v233
		})
	end
	local v234 = {
		["BackgroundColor3"] = v223,
		["Position"] = UDim2.fromOffset(-v229, -v229),
		["Size"] = UDim2.new(1, v229 * 2, 0, 170),
		["Name"] = "TopGlow",
		["BorderSizePixel"] = 0,
		["Active"] = false
	}
	v234.ZIndex = v234.ZIndex or 0
	v234.Parent = p219
	local v235 = v_u_5.new("Frame", v234)
	v_u_5.corner(v235, v230)
	v_u_5.new("UIGradient", {
		["Rotation"] = 90,
		["Transparency"] = nil,
		["Parent"] = nil,
		["Transparency"] = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.62), NumberSequenceKeypoint.new(0.45, 0.9), NumberSequenceKeypoint.new(1, 1) }),
		["Parent"] = v235
	})
	local v236 = {
		["BackgroundColor3"] = v_u_217,
		["Position"] = UDim2.fromOffset(-v229, -v229),
		["Size"] = UDim2.new(1, v229 * 2, 1, v229 * 2),
		["Name"] = "Beam",
		["BorderSizePixel"] = 0,
		["Active"] = false
	}
	v236.ZIndex = v236.ZIndex or 0
	v236.Parent = p219
	local v237 = v_u_5.new("Frame", v236)
	v_u_5.corner(v237, v230)
	v_u_5.new("UIGradient", {
		["Rotation"] = 30,
		["Transparency"] = nil,
		["Parent"] = nil,
		["Transparency"] = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.9), NumberSequenceKeypoint.new(0.35, 0.985), NumberSequenceKeypoint.new(1, 1) }),
		["Parent"] = v237
	})
	for _, v238 in {
		{ 0, 0 },
		{ 1, 0 },
		{ 0, 1 },
		{ 1, 1 }
	} do
		for _, v239 in { true, false } do
			local v240 = {
				["BackgroundColor3"] = nil,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["ZIndex"] = 6,
				["BackgroundColor3"] = v225,
				["AnchorPoint"] = Vector2.new(v238[1], v238[2]),
				["Position"] = UDim2.new(v238[1], (v238[1] * 2 - 1) * (v229 + 5), v238[2], (v238[2] * 2 - 1) * (v229 + 5))
			}
			local v241
			if v239 then
				v241 = UDim2.fromOffset(30, 3)
			else
				v241 = UDim2.fromOffset(3, 30)
			end
			v240.Size = v241
			v240.Name = "Bracket"
			v240.BorderSizePixel = 0
			v240.Active = false
			v240.ZIndex = v240.ZIndex or 0
			v240.Parent = p219
			local v242 = v_u_5.new("Frame", v240)
			v_u_5.corner(v242, 2)
		end
	end
	return v226
end
game:GetService("RunService").Heartbeat:Connect(function(p243)
	-- upvalues: (copy) v_u_218
	for v244 = #v_u_218, 1, -1 do
		local v245 = v_u_218[v244]
		if v245.owner.Parent then
			if not v245.owner.Visible then
				continue
			end
			v245.gradient.Rotation = (v245.gradient.Rotation + p243 * 70) % 360
		else
			table.remove(v_u_218, v244)
		end
	end
end)
v_u_5.RAIL_W = 248
v_u_5.RAIL_W_TOUCH = 76
local v_u_246 = nil
local function v_u_255(p247) -- name: cashText
	-- upvalues: (ref) v_u_246
	if v_u_246 == nil then
		local v248 = require
		local v249 = game:GetService("ReplicatedStorage")
		local v250, v251 = pcall(v248, v249:WaitForChild("GameShared"))
		local v252
		if v250 and (v251 and v251.formatNumber) then
			v252 = v251.formatNumber
		else
			v252 = false
		end
		v_u_246 = v252
	end
	local v253 = tonumber(p247) or 0
	if v_u_246 then
		return v_u_246(v253)
	end
	local v254 = math.floor(v253)
	return tostring(v254)
end
function v_u_5.rail(p256, p_u_257) -- name: rail
	-- upvalues: (ref) v_u_100, (copy) v_u_5, (copy) v_u_65, (copy) v_u_255, (copy) v_u_3
	v_u_100 = v_u_100 or require(script.Parent:WaitForChild("Icons"))
	local v258 = p_u_257.touch
	local v259 = p_u_257.compact
	local v260 = p_u_257.width
	if not v260 then
		if v258 then
			v260 = v_u_5.RAIL_W_TOUCH
		else
			v260 = v_u_5.RAIL_W
		end
	end
	local v261 = p_u_257.pad or 0
	local v262 = p256:FindFirstChildOfClass("UIPadding")
	if v262 then
		v262.PaddingLeft = UDim.new(0, v260 + v261)
	end
	local v263 = p256:FindFirstChildOfClass("UICorner")
	local v264 = not v263 and 10 or v263.CornerRadius.Offset
	local v265 = {
		["touch"] = v258
	}
	local v266 = {
		["Name"] = "Rail",
		["BackgroundColor3"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = v_u_5.SIDEBAR,
		["Position"] = UDim2.fromOffset(-(v260 + v261), -v261),
		["Size"] = UDim2.new(0, v260, 1, v261 * 2),
		["BorderSizePixel"] = 0,
		["Active"] = false,
		["Parent"] = p256
	}
	local v267 = v_u_5.new("Frame", v266)
	v_u_5.corner(v267, v264)
	local v268 = {
		["Name"] = "Square",
		["BackgroundColor3"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = v_u_5.SIDEBAR,
		["Position"] = UDim2.new(1, -v264, 0, 0),
		["Size"] = UDim2.new(0, v264, 1, 0),
		["BorderSizePixel"] = 0,
		["Active"] = false,
		["Parent"] = v267
	}
	v_u_5.new("Frame", v268)
	local v269 = {
		["Name"] = "Seam",
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.93,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = Color3.new(1, 1, 1),
		["AnchorPoint"] = Vector2.new(1, 0),
		["Position"] = UDim2.fromScale(1, 0),
		["Size"] = UDim2.new(0, 1, 1, 0),
		["BorderSizePixel"] = 0,
		["Active"] = false,
		["Parent"] = v267
	}
	v_u_5.new("Frame", v269)
	v265.frame = v267
	local v_u_270 = nil
	local v271
	if v258 then
		local v272 = v_u_5.badge(v267, p_u_257.icon or "store", "gold", 46)
		v272.AnchorPoint = Vector2.new(0.5, 0)
		v272.Position = UDim2.new(0.5, 0, 0, 12)
		v271 = 72
	else
		v_u_5.text({
			["Name"] = "Brand",
			["Text"] = "MAHANAKHON RACING",
			["FontFace"] = nil,
			["TextSize"] = 11,
			["TextColor3"] = nil,
			["TextXAlignment"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["FontFace"] = v_u_5.FONT_HEAVY,
			["TextColor3"] = v_u_5.TEXT_DIM,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["Position"] = UDim2.fromOffset(22, 18),
			["Size"] = UDim2.new(1, -40, 0, 14),
			["Parent"] = v267
		})
		local v273 = v259 and 52 or 70
		local v274 = v_u_5.text
		local v275 = {
			["Name"] = "RailTitle",
			["Text"] = nil,
			["RichText"] = true,
			["FontFace"] = nil,
			["TextScaled"] = true,
			["TextWrapped"] = true,
			["TextXAlignment"] = nil,
			["TextYAlignment"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil
		}
		local v276 = p_u_257.title
		local v277 = string.upper(v276 or "")
		local v278, v279 = v277:match("^(%S+)%s+(.+)$")
		local v280
		if v278 then
			v280 = ("<font color=\"%s\">%s</font> %s"):format("#EEE452", v278, v279)
		else
			v280 = ("<font color=\"%s\">%s</font>"):format("#EEE452", v277)
		end
		v275.Text = v280
		v275.FontFace = v_u_5.FONT_DISPLAY
		v275.TextXAlignment = Enum.TextXAlignment.Left
		v275.TextYAlignment = Enum.TextYAlignment.Top
		v275.Position = UDim2.fromOffset(22, 38)
		v275.Size = UDim2.new(1, -40, 0, v273)
		v275.Parent = v267
		v_u_270 = v274(v275)
		v_u_5.new("UITextSizeConstraint", {
			["MaxTextSize"] = nil,
			["MinTextSize"] = 12,
			["Parent"] = nil,
			["MaxTextSize"] = v259 and 22 or 30,
			["Parent"] = v_u_270
		})
		v271 = v273 + 38 + 8
		if not v259 then
			local v_u_281 = game:GetService("Players").LocalPlayer
			local v282 = {
				["Name"] = "Balance",
				["BackgroundColor3"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["BackgroundColor3"] = v_u_5.CARD,
				["Position"] = UDim2.fromOffset(16, v271),
				["Size"] = UDim2.new(1, -32, 0, 60),
				["BorderSizePixel"] = 0,
				["Active"] = false,
				["Parent"] = v267
			}
			local v283 = v_u_5.new("Frame", v282)
			v_u_5.corner(v283, 8)
			v_u_5.border(v283, Color3.new(1, 1, 1), 0.93, 1)
			local v284 = {
				["Name"] = "Coin",
				["BackgroundColor3"] = nil,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["BackgroundColor3"] = Color3.new(1, 1, 1),
				["AnchorPoint"] = Vector2.new(0, 0.5),
				["Position"] = UDim2.new(0, 12, 0.5, 0),
				["Size"] = UDim2.fromOffset(32, 32),
				["BorderSizePixel"] = 0,
				["Active"] = false,
				["Parent"] = v283
			}
			local v285 = v_u_5.new("Frame", v284)
			v_u_5.corner(v285, 999)
			v_u_5.new("UIGradient", {
				["Rotation"] = 120,
				["Color"] = nil,
				["Parent"] = nil,
				["Color"] = ColorSequence.new(Color3.fromRGB(255, 230, 120), Color3.fromRGB(214, 140, 10)),
				["Parent"] = v285
			})
			local v286 = {
				["Name"] = "Face",
				["BackgroundColor3"] = nil,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["BackgroundColor3"] = Color3.fromRGB(236, 172, 30),
				["AnchorPoint"] = Vector2.new(0.5, 0.5),
				["Position"] = UDim2.fromScale(0.5, 0.5),
				["Size"] = UDim2.fromOffset(24, 24),
				["BorderSizePixel"] = 0,
				["Active"] = false,
				["Parent"] = v285
			}
			local v287 = v_u_5.new("Frame", v286)
			v_u_5.corner(v287, 999)
			v_u_5.text({
				["Name"] = "Baht",
				["Text"] = "\224\184\191",
				["FontFace"] = nil,
				["TextSize"] = 15,
				["TextColor3"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["FontFace"] = v_u_5.FONT_HEAVY,
				["TextColor3"] = Color3.fromRGB(122, 70, 0),
				["Size"] = UDim2.fromScale(1, 1),
				["Parent"] = v287
			})
			v_u_5.text({
				["Name"] = "Label",
				["Text"] = "Cash balance",
				["FontFace"] = nil,
				["TextSize"] = 11,
				["TextColor3"] = nil,
				["TextXAlignment"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["FontFace"] = v_u_5.FONT_BOLD,
				["TextColor3"] = v_u_5.TEXT_DIM,
				["TextXAlignment"] = Enum.TextXAlignment.Left,
				["Position"] = UDim2.fromOffset(54, 12),
				["Size"] = UDim2.new(1, -100, 0, 12),
				["Parent"] = v283
			})
			local v_u_288 = v_u_5.text({
				["Name"] = "Cash",
				["Text"] = "",
				["FontFace"] = nil,
				["TextSize"] = 16,
				["TextColor3"] = nil,
				["TextXAlignment"] = nil,
				["TextTruncate"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["FontFace"] = v_u_5.FONT_DISPLAY,
				["TextColor3"] = v_u_5.TEXT,
				["TextXAlignment"] = Enum.TextXAlignment.Left,
				["TextTruncate"] = Enum.TextTruncate.AtEnd,
				["Position"] = UDim2.fromOffset(54, 26),
				["Size"] = UDim2.new(1, -100, 0, 22),
				["Parent"] = v283
			})
			v_u_5.new("UIGradient", {
				["Color"] = ColorSequence.new(Color3.fromRGB(255, 236, 170), Color3.new(1, 1, 1)),
				["Transparency"] = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), v_u_65(1, 0) }),
				["Parent"] = v283
			})
			if v_u_281 then
				local function v289() -- name: show
					-- upvalues: (copy) v_u_288, (ref) v_u_255, (copy) v_u_281
					v_u_288.Text = v_u_255(v_u_281:GetAttribute("Cash"))
				end
				v_u_281:GetAttributeChangedSignal("Cash"):Connect(v289)
				v_u_288.Text = v_u_255(v_u_281:GetAttribute("Cash"))
			end
			local v290 = v_u_5.new("TextButton", {
				["Name"] = "TopUp",
				["Text"] = "",
				["AutoButtonColor"] = false,
				["BackgroundColor3"] = nil,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["BackgroundColor3"] = Color3.new(1, 1, 1),
				["AnchorPoint"] = Vector2.new(1, 0.5),
				["Position"] = UDim2.new(1, -7, 0.5, 0),
				["Size"] = UDim2.fromOffset(34, 46),
				["Parent"] = v283
			})
			v_u_5.corner(v290, 5)
			v_u_5.new("UIGradient", {
				["Rotation"] = 90,
				["Color"] = nil,
				["Parent"] = nil,
				["Color"] = ColorSequence.new(v_u_5.GRAD.gold[1], v_u_5.GRAD.gold[2]),
				["Parent"] = v290
			})
			local v291 = v_u_100.make("plus", v_u_5.INK, 15)
			v291.AnchorPoint = Vector2.new(0.5, 0)
			v291.Position = UDim2.new(0.5, 0, 0, 8)
			v291.Parent = v290
			v_u_5.text({
				["Name"] = "Add",
				["Text"] = "ADD",
				["FontFace"] = nil,
				["TextSize"] = 10,
				["TextColor3"] = nil,
				["AnchorPoint"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["FontFace"] = v_u_5.FONT_HEAVY,
				["TextColor3"] = v_u_5.INK,
				["AnchorPoint"] = Vector2.new(0.5, 1),
				["Position"] = UDim2.new(0.5, 0, 1, -6),
				["Size"] = UDim2.new(1, 0, 0, 12),
				["Parent"] = v290
			})
			v290.Activated:Connect(function()
				-- upvalues: (copy) p_u_257
				if p_u_257.onTopUp then
					p_u_257.onTopUp()
				end
			end)
			v271 = v271 + 78
		end
	end
	local v292 = v259 and 12 or (v258 and 74 or 78)
	local v293
	if v258 then
		v293 = v271
	else
		v293 = v271 + 18
	end
	local v294 = {
		["Name"] = "Nav",
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["CanvasSize"] = nil,
		["AutomaticCanvasSize"] = nil,
		["ScrollingDirection"] = nil,
		["ScrollBarThickness"] = 2,
		["ScrollBarImageColor3"] = nil,
		["ScrollBarImageTransparency"] = 0.4,
		["Position"] = UDim2.fromOffset(v258 and 8 or 12, v293),
		["Size"] = UDim2.new(1, v258 and -16 or -24, 1, -(v293 + v292)),
		["CanvasSize"] = UDim2.new(),
		["AutomaticCanvasSize"] = Enum.AutomaticSize.Y,
		["ScrollingDirection"] = Enum.ScrollingDirection.Y,
		["ScrollBarImageColor3"] = v_u_5.TEXT_DIM,
		["BorderSizePixel"] = 0,
		["Active"] = false,
		["Parent"] = v267
	}
	local v295 = v_u_5.new("ScrollingFrame", v294)
	v295.Active = true
	v265.nav = v295
	if not v258 then
		local v_u_296 = v_u_5.text({
			["Name"] = "NavLabel",
			["Text"] = "MENU",
			["FontFace"] = nil,
			["TextSize"] = 10,
			["TextColor3"] = nil,
			["TextXAlignment"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Visible"] = false,
			["Parent"] = nil,
			["FontFace"] = v_u_5.FONT_HEAVY,
			["TextColor3"] = v_u_5.TEXT_DIM,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["Position"] = UDim2.fromOffset(24, v271),
			["Size"] = UDim2.new(1, -48, 0, 12),
			["Parent"] = v267
		})
		function v265.onTabs()
			-- upvalues: (copy) v_u_296
			v_u_296.Visible = true
		end
	end
	local v297 = game:GetService("Players").LocalPlayer
	local v_u_298, v_u_299
	if v297 and not v259 then
		local v300 = {
			["Name"] = "FootLine",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.93,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = Color3.new(1, 1, 1),
			["AnchorPoint"] = Vector2.new(0.5, 1),
			["Position"] = UDim2.new(0.5, 0, 1, -(v292 - 6)),
			["Size"] = UDim2.new(1, -24, 0, 1),
			["BorderSizePixel"] = 0,
			["Active"] = false,
			["Parent"] = v267
		}
		v_u_5.new("Frame", v300)
		local v301 = {
			["Name"] = "PlayerCard",
			["BackgroundTransparency"] = 1,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 1),
			["Position"] = UDim2.new(0.5, 0, 1, -12)
		}
		local v302
		if v258 then
			v302 = UDim2.fromOffset(v260 - 20, 52)
		else
			v302 = UDim2.new(1, -32, 0, 52)
		end
		v301.Size = v302
		v301.BorderSizePixel = 0
		v301.Active = false
		v301.Parent = v267
		v_u_298 = v_u_5.new("Frame", v301)
		local v303 = v_u_298
		local v304 = {
			["Name"] = "Face",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0,
			["Image"] = nil,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_5.CARD,
			["Image"] = ("rbxthumb://type=AvatarHeadShot&id=%d&w=150&h=150"):format(v297.UserId),
			["AnchorPoint"] = Vector2.new(v258 and 0.5 or 0, 0.5)
		}
		local v305
		if v258 then
			v305 = UDim2.fromScale(0.5, 0.5)
		else
			v305 = UDim2.new(0, 0, 0.5, 0)
		end
		v304.Position = v305
		v304.Size = UDim2.fromOffset(40, 40)
		v304.BorderSizePixel = 0
		v304.Active = false
		v304.Parent = v303
		local v306 = v_u_5.new("ImageLabel", v304)
		v_u_5.corner(v306, 999)
		v_u_5.new("UIStroke", {
			["ApplyStrokeMode"] = nil,
			["Color"] = nil,
			["Thickness"] = 1.5,
			["Parent"] = nil,
			["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
			["Color"] = v_u_5.ACCENT,
			["Parent"] = v306
		})
		if not v258 then
			v_u_5.text({
				["Name"] = "Who",
				["Text"] = nil,
				["FontFace"] = nil,
				["TextSize"] = 14,
				["TextXAlignment"] = nil,
				["TextTruncate"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["Text"] = v297.DisplayName,
				["FontFace"] = v_u_5.FONT_HEAVY,
				["TextXAlignment"] = Enum.TextXAlignment.Left,
				["TextTruncate"] = Enum.TextTruncate.AtEnd,
				["Position"] = UDim2.fromOffset(52, 7),
				["Size"] = UDim2.new(1, -56, 0, 18),
				["Parent"] = v_u_298
			})
			v_u_5.text({
				["Name"] = "User",
				["Text"] = nil,
				["TextSize"] = 12,
				["TextColor3"] = nil,
				["TextXAlignment"] = nil,
				["TextTruncate"] = nil,
				["Position"] = nil,
				["Size"] = nil,
				["Parent"] = nil,
				["Text"] = "@" .. v297.Name,
				["TextColor3"] = v_u_5.TEXT_DIM,
				["TextXAlignment"] = Enum.TextXAlignment.Left,
				["TextTruncate"] = Enum.TextTruncate.AtEnd,
				["Position"] = UDim2.fromOffset(52, 26),
				["Size"] = UDim2.new(1, -56, 0, 16),
				["Parent"] = v_u_298
			})
		end
		v_u_299 = v_u_298.Position
	else
		v_u_298 = nil
		v_u_299 = nil
	end
	function v265.setTitle(p307) -- name: setTitle
		-- upvalues: (ref) v_u_270
		if v_u_270 then
			local v308 = v_u_270
			local v309 = string.upper(p307 or "")
			local v310, v311 = v309:match("^(%S+)%s+(.+)$")
			local v312
			if v310 then
				v312 = ("<font color=\"%s\">%s</font> %s"):format("#EEE452", v310, v311)
			else
				v312 = ("<font color=\"%s\">%s</font>"):format("#EEE452", v309)
			end
			v308.Text = v312
		end
	end
	if v_u_270 then
		local v_u_313 = v_u_270.Position
	end
	function v265.play() -- name: play
		-- upvalues: (ref) v_u_270, (copy) v_u_313, (ref) v_u_3, (ref) v_u_298, (ref) v_u_299
		local v314 = TweenInfo.new(0.4, Enum.EasingStyle.Quart, Enum.EasingDirection.Out)
		if v_u_270 then
			v_u_270.Position = v_u_313 + UDim2.fromOffset(-16, 0)
			v_u_270.TextTransparency = 1
			v_u_3:Create(v_u_270, v314, {
				["Position"] = nil,
				["TextTransparency"] = 0,
				["Position"] = v_u_313
			}):Play()
		end
		if v_u_298 then
			v_u_298.Position = v_u_299 + UDim2.fromOffset(0, 16)
			v_u_3:Create(v_u_298, v314, {
				["Position"] = v_u_299
			}):Play()
		end
	end
	return v265
end
function v_u_5.backdrop(p315, _) -- name: backdrop
	p315.BackgroundColor3 = Color3.fromRGB(4, 5, 8)
	return function() end
end
function v_u_5.window(p_u_316) -- name: window
	-- upvalues: (copy) v_u_5, (copy) v_u_1, (copy) v_u_65, (copy) v_u_150, (copy) v_u_3
	local v317 = v_u_5.isTouch()
	local v_u_318 = not v_u_5.isPhone() and 1 or v_u_5.PHONE_SHRINK
	local v_u_319 = p_u_316.bare == true
	local v_u_320 = p_u_316.dock == "right"
	local v_u_321 = {
		["changed"] = v_u_1.new("BindableEvent")
	}
	local v_u_322 = v_u_5.new("TextButton", {
		["Name"] = nil,
		["Text"] = "",
		["AutoButtonColor"] = false,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.3,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["Visible"] = false,
		["ZIndex"] = nil,
		["Parent"] = nil,
		["Name"] = (p_u_316.name or "Window") .. "Shade",
		["BackgroundColor3"] = Color3.fromRGB(4, 5, 8),
		["Size"] = UDim2.fromScale(1, 1),
		["ZIndex"] = p_u_316.zindex or 1,
		["Parent"] = p_u_316.gui
	})
	local v323
	if v317 then
		v323 = p_u_316.touchSize or Vector2.new(0.96, 0.92)
	else
		v323 = p_u_316.size or Vector2.new(0.8, 0.82)
	end
	if v_u_320 then
		if v317 then
			v323 = p_u_316.touchDockSize or Vector2.new(0.5, 0.94)
		else
			v323 = p_u_316.dockSize or Vector2.new(0.34, 0.84)
		end
	end
	local v324
	if v_u_319 or v_u_320 then
		v324 = 0
	elseif v317 then
		v324 = v_u_5.RAIL_W_TOUCH
	else
		v324 = v_u_5.RAIL_W
	end
	local v325 = p_u_316.max or Vector2.new(1120, 760)
	local v326
	if v317 or (v_u_319 or v_u_320) then
		v326 = v323.X
	else
		local v327 = v323.X + 0.14
		v326 = math.min(0.95, v327)
	end
	local v_u_328
	if v_u_320 then
		v_u_328 = UDim2.new(1, -(v317 and 10 or v_u_5.EDGE), 0.5, v317 and 0 or 34)
	else
		v_u_328 = UDim2.fromScale(0.5, 0.5)
	end
	local v329 = v_u_5.panel
	local v330 = {
		["Name"] = nil,
		["Visible"] = false,
		["Active"] = true,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = nil,
		["Parent"] = nil,
		["Name"] = p_u_316.name or "Window"
	}
	local v331
	if v_u_320 then
		v331 = Vector2.new(1, 0.5)
	else
		v331 = Vector2.new(0.5, 0.5)
	end
	v330.AnchorPoint = v331
	v330.Position = v_u_328
	v330.Size = UDim2.fromScale(v326 / v_u_318, v323.Y / v_u_318)
	v330.ZIndex = p_u_316.zindex or 1
	v330.Parent = p_u_316.gui
	local v_u_332 = v329(v330)
	v_u_332.UICorner.CornerRadius = UDim.new(0, 10)
	v_u_5.new("UISizeConstraint", {
		["MaxSize"] = Vector2.new(v325.X + v324, v325.Y),
		["Parent"] = v_u_332
	})
	local v333 = v_u_319 and 0 or (v317 and 12 or 20)
	v_u_5.padding(v_u_332, v333)
	local v334 = p_u_316.grad == "red" and "red" or "gold"
	if v_u_319 then
		v_u_332.BackgroundTransparency = 1
		local v335 = v_u_332:FindFirstChildOfClass("UIStroke")
		if v335 then
			v335.Enabled = false
		end
	else
		v_u_5.new("Frame", {
			["Name"] = "HeaderLine",
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.92,
			["BorderSizePixel"] = 0,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["BackgroundColor3"] = Color3.new(1, 1, 1),
			["Position"] = UDim2.fromOffset(0, 52),
			["Size"] = UDim2.new(1, 0, 0, 1),
			["Parent"] = v_u_332
		})
		v_u_5.new("UIGradient", {
			["Rotation"] = 90,
			["Transparency"] = nil,
			["Parent"] = nil,
			["Transparency"] = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.5, 0.4), v_u_65(1, 0) }),
			["Parent"] = v_u_322
		})
	end
	local v_u_336 = v_u_5.backdrop(v_u_322, v334)
	local v337, v_u_338, v339 = v_u_5.header(v_u_332, p_u_316.icon or "store", v334, p_u_316.title or "", p_u_316.sub)
	local v340 = v337:FindFirstChild("Badge")
	if v340 then
		v340.Visible = false
	end
	v_u_338.Position = UDim2.fromOffset(0, 1)
	v339.TextTruncate = Enum.TextTruncate.AtEnd
	if v317 or v_u_320 then
		v_u_338.TextSize = v_u_320 and not v317 and 20 or 18
		v339.Position = UDim2.fromOffset(0, 25)
		v339.TextSize = 13
		if v_u_320 then
			v_u_338.FontFace = v_u_5.FONT_DISPLAY
			v_u_338.TextColor3 = v_u_5.ACCENT_LIGHT
			v339.TextColor3 = v_u_5.TEXT_DIM
			v339.Size = UDim2.new(1, -56, 0, 18)
		end
	else
		v_u_338.Visible = false
		v339.Position = UDim2.fromOffset(0, 9)
		v339.TextSize = 15
		v339.FontFace = v_u_5.FONT_BOLD
		v339.TextColor3 = v_u_5.TEXT_DIM
		v339.Size = UDim2.new(1, -170, 0, 26)
	end
	if v_u_319 then
		v337.Visible = false
	end
	local v_u_341
	if v_u_319 or v_u_320 then
		v_u_341 = nil
	else
		local v_u_346 = v_u_5.rail(v_u_332, {
			["grad"] = v334,
			["icon"] = p_u_316.icon or "store",
			["title"] = p_u_316.title or "",
			["pad"] = v333,
			["touch"] = v317,
			["onTopUp"] = function() -- name: onTopUp
				-- upvalues: (copy) p_u_316, (copy) v_u_321
				local v342 = require
				local v343 = script.Parent
				local v344, v345 = pcall(v342, v343:WaitForChild("Store"))
				if v344 and (v345 and v345.open) then
					if p_u_316.name ~= "StorePanel" then
						v_u_321.setOpen(false)
					end
					v345.open("Money")
				end
			end
		})
		v_u_150[v_u_332] = v_u_346
		v_u_338:GetPropertyChangedSignal("Text"):Connect(function()
			-- upvalues: (ref) v_u_346, (copy) v_u_338
			v_u_346.setTitle(v_u_338.Text)
		end)
		v_u_341 = v_u_346
	end
	local v347 = v_u_5.closeButton(v_u_332)
	if not (v317 or v_u_320) then
		v_u_5.text({
			["Name"] = "Exit",
			["Text"] = "EXIT",
			["TextSize"] = 12,
			["FontFace"] = nil,
			["TextColor3"] = nil,
			["TextXAlignment"] = nil,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["FontFace"] = v_u_5.FONT_HEAVY,
			["TextColor3"] = v_u_5.TEXT_DIM,
			["TextXAlignment"] = Enum.TextXAlignment.Right,
			["AnchorPoint"] = Vector2.new(1, 0),
			["Position"] = UDim2.new(1, -46, 0, 3),
			["Size"] = UDim2.fromOffset(44, 38),
			["Parent"] = v_u_332
		})
	end
	local v348 = v_u_319 and 0 or 58
	local v349 = v_u_5.new("Frame", {
		["Name"] = "Body",
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Position"] = UDim2.fromOffset(0, v348),
		["Size"] = UDim2.new(1, 0, 1, -v348),
		["Parent"] = v_u_332
	})
	local v_u_350 = v_u_5.new("UIScale", {
		["Scale"] = v_u_318,
		["Parent"] = v_u_332
	})
	local v_u_351 = false
	function v_u_321.setOpen(p352) -- name: setOpen
		-- upvalues: (ref) v_u_351, (copy) v_u_332, (copy) v_u_322, (copy) v_u_320, (copy) v_u_350, (copy) v_u_319, (copy) v_u_318, (ref) v_u_3, (ref) v_u_5, (copy) v_u_328, (copy) v_u_321, (ref) v_u_341, (copy) v_u_336
		if p352 ~= v_u_351 then
			v_u_351 = p352
			v_u_332.Visible = p352
			local v353 = v_u_322
			local v354
			if p352 then
				v354 = not v_u_320
			else
				v354 = p352
			end
			v353.Visible = v354
			if p352 then
				v_u_350.Scale = (v_u_319 and 0.98 or 0.94) * v_u_318
				local v355 = {
					["Scale"] = v_u_318
				}
				v_u_3:Create(v_u_350, v_u_5.POP, v355):Play()
				if v_u_320 then
					v_u_332.Position = v_u_328 + UDim2.fromOffset(40, 0)
					local v356 = {
						["Position"] = v_u_328
					}
					v_u_3:Create(v_u_332, v_u_5.POP, v356):Play()
				elseif not v_u_319 then
					v_u_332.Position = UDim2.new(0.5, 0, 0.5, 18)
					v_u_3:Create(v_u_332, v_u_5.POP, {
						["Position"] = UDim2.fromScale(0.5, 0.5)
					}):Play()
				end
				v_u_321.shadeTo = v_u_321.shadeTo or v_u_322.BackgroundTransparency
				v_u_322.BackgroundTransparency = 1
				v_u_3:Create(v_u_322, v_u_5.FADE, {
					["BackgroundTransparency"] = v_u_321.shadeTo
				}):Play()
				if v_u_341 then
					v_u_341.play()
				end
				v_u_336()
			end
			v_u_321.changed:Fire(p352)
		end
	end
	function v_u_321.isOpen() -- name: isOpen
		-- upvalues: (ref) v_u_351
		return v_u_351
	end
	v347.Activated:Connect(function()
		-- upvalues: (copy) v_u_321
		v_u_321.setOpen(false)
	end)
	v_u_322.Activated:Connect(function()
		-- upvalues: (copy) p_u_316, (copy) v_u_321
		if not p_u_316.keepOpen then
			v_u_321.setOpen(false)
		end
	end)
	v_u_321.panel = v_u_332
	v_u_321.body = v349
	v_u_321.header = v337
	v_u_321.title = v_u_338
	v_u_321.sub = v339
	v_u_321.close = v347
	v_u_321.shade = v_u_322
	v_u_321.rail = v_u_341
	return v_u_321
end
function v_u_5.unscaledSize(p357) -- name: unscaledSize
	local v358 = p357
	local v359 = 1
	while p357 and p357:IsA("GuiObject") do
		local v360 = p357:FindFirstChildOfClass("UIScale")
		if v360 then
			v359 = v359 * v360.Scale
		end
		p357 = p357.Parent
	end
	return v358.AbsoluteSize / math.max(v359, 0.01)
end
function v_u_5.screen(p361, p362, p363) -- name: screen
	-- upvalues: (copy) v_u_5
	return v_u_5.new("ScreenGui", {
		["Name"] = nil,
		["ResetOnSpawn"] = false,
		["IgnoreGuiInset"] = false,
		["ZIndexBehavior"] = nil,
		["DisplayOrder"] = nil,
		["Parent"] = nil,
		["Name"] = p361,
		["ZIndexBehavior"] = Enum.ZIndexBehavior.Sibling,
		["DisplayOrder"] = p362 or 0,
		["Parent"] = p363
	})
end
function v_u_5.scaleFor(p364, p365) -- name: scaleFor
	-- upvalues: (copy) v_u_5
	if not v_u_5.isTouch() then
		local v366 = p364.Y / 1080
		local v367 = p364.X / 1920
		local v368 = math.min(v366, v367)
		return math.clamp(v368, 0.75, 1.3)
	end
	local v369 = p364.Y / 540
	local v370 = p364.X / 1000
	local v371 = math.min(v369, v370)
	if not (p365 and v_u_5.isPhone(p364)) then
		return math.clamp(v371, 0.6, 1.1)
	end
	local v372 = v371 * p365
	local v373 = 0.6 * p365
	return math.clamp(v372, v373, 1.1)
end
function v_u_5.touchLeft(p374) -- name: touchLeft
	local v375 = workspace.CurrentCamera
	local v376
	if v375 then
		v376 = v375.ViewportSize
	else
		v376 = Vector2.new(844, 390)
	end
	local v377 = v376.X
	local v378 = v376.Y
	local v379
	if v377 / math.max(v378, 1) >= 1.9 then
		local v380 = v376.X * 0.07
		v379 = math.floor(v380)
	else
		v379 = 18
	end
	local v381 = v376.X
	local v382 = v376.Y
	local v383 = math.min(v381, v382) <= 500 and 130 or 200
	local v384 = game:GetService("Players").LocalPlayer
	local v385 = v384 and v384:FindFirstChild("PlayerGui")
	if v385 then
		v385 = v384.PlayerGui:FindFirstChild("TouchGui")
	end
	if v385 then
		v385 = v385:FindFirstChild("TouchControlFrame")
	end
	if v385 then
		v385 = v385:FindFirstChild("ThumbstickFrame")
	end
	if v385 and (v385.Visible and v385.AbsoluteSize.X > 0) then
		v383 = v385.AbsolutePosition.X + v385.AbsoluteSize.X - (not p374 and 0 or p374.AbsolutePosition.X)
	end
	local v386 = v383 + 12
	return math.max(v379, v386)
end
function v_u_5.autoScale(p387, p_u_388) -- name: autoScale
	-- upvalues: (copy) v_u_5
	local v_u_389 = v_u_5.new("UIScale", {
		["Parent"] = p387
	})
	local v390 = workspace.CurrentCamera
	local function v392() -- name: update
		-- upvalues: (copy) v_u_389, (ref) v_u_5, (copy) p_u_388
		local v391 = workspace.CurrentCamera
		if v391 then
			v_u_389.Scale = v_u_5.scaleFor(v391.ViewportSize, p_u_388)
		end
	end
	local v393 = workspace.CurrentCamera
	if v393 then
		v_u_389.Scale = v_u_5.scaleFor(v393.ViewportSize, p_u_388)
	end
	if v390 then
		v390:GetPropertyChangedSignal("ViewportSize"):Connect(v392)
	end
	workspace:GetPropertyChangedSignal("CurrentCamera"):Connect(v392)
	return v_u_389
end
v_u_5.DRIVE_MIN_W = 1000
v_u_5.DRIVE_H = 400
v_u_5.DRIVE_SIDE_W = 120
v_u_5.DRIVE_PAD_H = 112
function v_u_5.driveScale(p394) -- name: driveScale
	-- upvalues: (copy) v_u_5
	local v395 = p394.X
	local v396 = p394.Y
	local v397 = v395 / math.max(v396, 1) >= 1.9 and 0.085 or 0.02
	local v398 = p394.X * (1 - v397 * 2)
	local v399 = p394.Y / 540
	local v400 = math.clamp(v399, 0.6, 1.1)
	local v401 = v398 / v_u_5.DRIVE_MIN_W
	local v402 = math.min(v400, v401)
	if v_u_5.isPhone(p394) then
		v402 = v402 * v_u_5.PHONE_SHRINK
	end
	return v402, v398
end
function v_u_5.driveArea(p403) -- name: driveArea
	-- upvalues: (copy) v_u_5
	local v_u_404 = v_u_5.new("Frame", {
		["Name"] = "DriveArea",
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0.5, 1),
		["Position"] = UDim2.new(0.5, 0, 1, -10),
		["Parent"] = p403
	})
	local v_u_405 = v_u_5.new("UIScale", {
		["Parent"] = v_u_404
	})
	local function v409() -- name: update
		-- upvalues: (ref) v_u_5, (copy) v_u_405, (copy) v_u_404
		local v406 = workspace.CurrentCamera
		if v406 then
			local v407, v408 = v_u_5.driveScale(v406.ViewportSize)
			v_u_405.Scale = v407
			v_u_404.Size = UDim2.fromOffset(v408 / v407, v_u_5.DRIVE_H)
		end
	end
	local v410 = workspace.CurrentCamera
	if v410 then
		local v411, v412 = v_u_5.driveScale(v410.ViewportSize)
		v_u_405.Scale = v411
		v_u_404.Size = UDim2.fromOffset(v412 / v411, v_u_5.DRIVE_H)
	end
	local v413 = workspace.CurrentCamera
	if v413 then
		v413:GetPropertyChangedSignal("ViewportSize"):Connect(v409)
	end
	workspace:GetPropertyChangedSignal("CurrentCamera"):Connect(v409)
	return v_u_404
end
function v_u_5.menuOpen() -- name: menuOpen
	-- upvalues: (copy) v_u_2
	return v_u_2.MenuIsOpen
end
local v414 = require(game:GetService("ReplicatedStorage"):WaitForChild("UiOwn"))
for _, v415 in v_u_5 do
	v414.entry(v415)
end
return v_u_5