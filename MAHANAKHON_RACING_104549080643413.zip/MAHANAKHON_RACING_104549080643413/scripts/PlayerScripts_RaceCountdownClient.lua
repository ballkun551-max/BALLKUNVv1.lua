-- Path: Players/ygggggg55551/PlayerScripts/RaceCountdownClient
-- Class: LocalScript  true/Enum.RunContext.Legacy
-- Decompiled by BALL KUN Universal Map Dump

local v1 = require(game:GetService("ReplicatedStorage"):WaitForChild("UiOwn")).Instance
local v2 = game:GetService("Players")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("RunService")
local v5 = game:GetService("SoundService")
local v_u_6 = game:GetService("TweenService")
local v7 = require(v3:WaitForChild("GameShared"))
local v_u_8 = require(v3:WaitForChild("RaceShared"))
local v9 = v3:WaitForChild("GameUI")
local v10 = require(v9:WaitForChild("Theme"))
local v_u_11 = v2.LocalPlayer
local v12 = v3:WaitForChild(v7.REMOTES):WaitForChild(v_u_8.EVENT)
local v_u_13 = {
	["3"] = Color3.fromRGB(255, 72, 72),
	["2"] = Color3.fromRGB(255, 150, 40),
	["1"] = Color3.fromRGB(255, 214, 40),
	["GO!"] = Color3.fromRGB(60, 230, 120)
}
local v_u_14 = v1.new("ScreenGui")
v_u_14.Name = "RaceCountdown"
v_u_14.ResetOnSpawn = false
v_u_14.IgnoreGuiInset = true
v_u_14.DisplayOrder = 50
v_u_14.Enabled = false
v_u_14.Parent = v_u_11:WaitForChild("PlayerGui")
local v15 = v1.new("Frame")
v15.BackgroundTransparency = 1
v15.AnchorPoint = Vector2.new(0.5, 0.5)
v15.Position = UDim2.fromScale(0.5, 0.36)
v15.Size = UDim2.fromOffset(320, 110)
v15.Parent = v_u_14
local v_u_16 = v1.new("UIScale")
v_u_16.Parent = v15
local v17 = v1.new("Frame")
v17.BackgroundTransparency = 1
v17.Size = UDim2.fromScale(1, 1)
v17.Parent = v15
local v_u_18 = v1.new("UIScale")
v_u_18.Parent = v17
local v_u_19 = v1.new("TextLabel")
v_u_19.Name = "Number"
v_u_19.BackgroundTransparency = 1
v_u_19.Size = UDim2.fromScale(1, 1)
v_u_19.FontFace = v10.FONT_BOLD
v_u_19.TextSize = 100
v_u_19.Text = ""
v_u_19.TextColor3 = Color3.new(1, 1, 1)
v_u_19.Parent = v17
local v_u_20 = v1.new("UIStroke")
v_u_20.Color = Color3.fromRGB(10, 10, 14)
v_u_20.Thickness = 6
v_u_20.Parent = v_u_19
local v_u_21 = v1.new("TextLabel")
v_u_21.Name = "Racers"
v_u_21.BackgroundTransparency = 1
v_u_21.AnchorPoint = Vector2.new(0.5, 0)
v_u_21.Position = UDim2.fromScale(0.5, 0.503)
v_u_21.Size = UDim2.fromScale(0.9, 0.05)
v_u_21.FontFace = v10.FONT_BOLD
v_u_21.TextScaled = true
v_u_21.TextColor3 = Color3.new(1, 1, 1)
v_u_21.Text = ""
v_u_21.Parent = v_u_14
local v_u_22 = v1.new("UIStroke")
v_u_22.Color = Color3.fromRGB(10, 10, 14)
v_u_22.Thickness = 2.5
v_u_22.Parent = v_u_21
local v23 = v1.new("UITextSizeConstraint")
v23.MinTextSize = 12
v23.MaxTextSize = 34
v23.Parent = v_u_21
local function v27() -- name: fitScreen
	-- upvalues: (copy) v_u_16, (copy) v_u_20
	local v24 = workspace.CurrentCamera
	local v25 = v_u_16
	local v26 = (not v24 and 600 or v24.ViewportSize.Y) * 0.26 / 100
	v25.Scale = math.max(0.5, v26)
	v_u_20.Thickness = 4
end
local v28 = workspace.CurrentCamera
local v29 = (not v28 and 600 or v28.ViewportSize.Y) * 0.26 / 100
v_u_16.Scale = math.max(0.5, v29)
v_u_20.Thickness = 4
workspace:GetPropertyChangedSignal("CurrentCamera"):Connect(v27)
if workspace.CurrentCamera then
	workspace.CurrentCamera:GetPropertyChangedSignal("ViewportSize"):Connect(v27)
end
local v_u_30 = v1.new("Sound")
v_u_30.Name = "RaceBeep"
v_u_30.SoundId = "rbxasset://sounds/electronicpingshort.wav"
v_u_30.Volume = 0.9
v_u_30.Parent = v5
local v_u_31 = TweenInfo.new(0.25, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
local v_u_32 = nil
local v_u_33 = nil
local function v42(p34, _, p35) -- name: show
	-- upvalues: (ref) v_u_33, (copy) v_u_14, (ref) v_u_32, (copy) v_u_11, (copy) v_u_21, (copy) v_u_19, (copy) v_u_4, (copy) v_u_8, (copy) v_u_13, (copy) v_u_18, (copy) v_u_6, (copy) v_u_31, (copy) v_u_30, (copy) v_u_20, (copy) v_u_22
	if v_u_33 then
		v_u_33:Disconnect()
		v_u_33 = nil
	end
	v_u_14.Enabled = false
	v_u_32 = nil
	v_u_32 = {
		["start"] = nil,
		["shown"] = nil,
		["start"] = p34
	}
	local v36 = {}
	for _, v37 in p35 do
		if v37 == v_u_11.DisplayName then
			continue
		end
		table.insert(v36, v37)
	end
	v_u_21.Text = #v36 == 0 and "Get ready!" or ("Racing %d: %s"):format(#p35, table.concat(v36, ", "))
	v_u_19.Text = ""
	v_u_14.Enabled = true
	v_u_33 = v_u_4.RenderStepped:Connect(function()
		-- upvalues: (ref) v_u_32, (ref) v_u_8, (ref) v_u_33, (ref) v_u_14, (ref) v_u_19, (ref) v_u_13, (ref) v_u_18, (ref) v_u_6, (ref) v_u_31, (ref) v_u_30, (ref) v_u_20, (ref) v_u_21, (ref) v_u_22
		local v38 = workspace:GetServerTimeNow() - v_u_32.start
		local v39 = v_u_8.phase(v38)
		if v39 == nil then
			if v38 > 0 then
				if v_u_33 then
					v_u_33:Disconnect()
					v_u_33 = nil
				end
				v_u_14.Enabled = false
				v_u_32 = nil
			else
				v_u_19.Text = ""
			end
		else
			if v39 ~= v_u_32.shown then
				v_u_32.shown = v39
				v_u_19.Text = v39
				v_u_19.TextColor3 = v_u_13[v39]
				v_u_18.Scale = 1.6
				v_u_6:Create(v_u_18, v_u_31, {
					["Scale"] = 1
				}):Play()
				v_u_30.PlaybackSpeed = v39 == "GO!" and 1.6 or 1
				v_u_30:Play()
			end
			if v39 == "GO!" then
				local v40 = 1 - (3 * v_u_8.STEP + v_u_8.GO_TIME - v38) / 0.5
				local v41 = math.clamp(v40, 0, 1)
				v_u_19.TextTransparency = v41
				v_u_20.Transparency = v41
				v_u_21.TextTransparency = v41
				v_u_22.Transparency = v41
			else
				v_u_19.TextTransparency = 0
				v_u_20.Transparency = 0
				v_u_21.TextTransparency = 0
				v_u_22.Transparency = 0
			end
		end
	end)
end
v12.OnClientEvent:Connect(v42)