-- Path: ReplicatedStorage/GameUI/EcuPanel
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = require(game:GetService("ReplicatedStorage"):WaitForChild("UiOwn")).Instance
local v_u_2 = require(game:GetService("ReplicatedStorage"):WaitForChild("NetSeal"))
local v_u_3 = game:GetService("Players")
local v_u_4 = game:GetService("ReplicatedStorage")
local v_u_5 = game:GetService("TweenService")
local v_u_6 = game:GetService("UserInputService")
local v_u_7 = require(v_u_4:WaitForChild("GameShared"))
local v_u_8 = require(v_u_4:WaitForChild("EcuShared"))
local v_u_9 = require(script.Parent:WaitForChild("Theme"))
local v_u_10 = require(script.Parent:WaitForChild("Toast"))
local v_u_11 = require(script.Parent:WaitForChild("Icons"))
local v_u_12 = require(script.Parent:WaitForChild("EcuEditors"))
local v_u_13 = {
	["chip_Afr"] = {
		318,
		136,
		61,
		12,
		233,
		414
	},
	["chip_Air"] = {
		134,
		136,
		60,
		13,
		234,
		181
	},
	["chip_Fuel"] = {
		162,
		90,
		62,
		19,
		233,
		291
	},
	["chip_Idle"] = {
		377,
		115,
		70,
		16,
		230,
		879
	},
	["chip_Ign"] = {
		344,
		90,
		68,
		18,
		230,
		762
	},
	["chip_Oil"] = {
		338,
		3,
		49,
		22,
		238,
		641
	},
	["chip_Speed"] = {
		0,
		0,
		70,
		16,
		230,
		990
	},
	["name_Speed"] = {
		0,
		0,
		70,
		16,
		324,
		985
	},
	["chip_Tps"] = {
		288,
		90,
		53,
		18,
		238,
		528
	},
	["code"] = {
		55,
		90,
		58,
		22,
		1260,
		183
	},
	["factory"] = {
		246,
		3,
		89,
		25,
		1295,
		891
	},
	["lower"] = {
		76,
		136,
		55,
		14,
		1106,
		902
	},
	["name_Afr"] = {
		3,
		115,
		99,
		18,
		323,
		404
	},
	["name_Air"] = {
		197,
		136,
		60,
		13,
		324,
		175
	},
	["name_Fuel"] = {
		390,
		3,
		74,
		22,
		324,
		283
	},
	["name_Idle"] = {
		3,
		136,
		70,
		16,
		324,
		873
	},
	["name_Ign"] = {
		161,
		115,
		69,
		18,
		324,
		756
	},
	["name_Oil"] = {
		3,
		90,
		49,
		22,
		324,
		635
	},
	["name_Tps"] = {
		105,
		115,
		53,
		18,
		324,
		522
	},
	["next"] = {
		252,
		115,
		17,
		17,
		1366,
		815
	},
	["power"] = {
		260,
		136,
		55,
		13,
		1382,
		171
	},
	["prev"] = {
		233,
		115,
		16,
		17,
		680,
		815
	},
	["raise"] = {
		178,
		3,
		65,
		25,
		894,
		891
	},
	["shadow"] = {
		127,
		3,
		48,
		48
	},
	["smooth"] = {
		116,
		90,
		43,
		21,
		700,
		901
	},
	["top_post"] = {
		272,
		115,
		102,
		17,
		1612,
		167
	},
	["top_pre"] = {
		227,
		90,
		58,
		19,
		1529,
		169
	},
	["tune"] = {
		3,
		3,
		121,
		84,
		1529,
		834
	}
}
local v_u_14 = {
	["Air"] = "\224\184\173\224\184\178\224\184\129\224\184\178\224\184\168",
	["Fuel"] = "\224\185\128\224\184\138\224\184\183\224\185\137\224\184\173\224\185\128\224\184\158\224\184\165\224\184\180\224\184\135",
	["Afr"] = "\224\184\129\224\184\178\224\184\163\224\185\128\224\184\156\224\184\178\224\185\132\224\184\171\224\184\161\224\185\137",
	["Tps"] = "\224\184\132\224\184\177\224\184\153\224\185\128\224\184\163\224\185\136\224\184\135",
	["Oil"] = "\224\184\153\224\185\137\224\184\179\224\184\161\224\184\177\224\184\153",
	["Ign"] = "\224\184\171\224\184\177\224\184\167\224\185\128\224\184\151\224\184\181\224\184\162\224\184\153",
	["Idle"] = "\224\185\128\224\184\148\224\184\180\224\184\153\224\184\171\224\184\173\224\184\154",
	["Speed"] = "\224\184\132\224\184\167\224\184\178\224\184\161\224\185\132\224\184\167",
	["code"] = "\224\185\130\224\184\132\224\185\137\224\184\148\224\184\136\224\184\185\224\184\153",
	["power"] = "\224\184\158\224\184\165\224\184\177\224\184\135\224\184\135\224\184\178\224\184\153",
	["top_pre"] = "\224\185\128\224\184\163\224\185\135\224\184\167\224\184\170\224\184\185\224\184\135\224\184\170\224\184\184\224\184\148",
	["top_post"] = "\224\184\129\224\184\180\224\185\130\224\184\165\224\185\128\224\184\161\224\184\149\224\184\163/\224\184\138\224\184\177\224\185\136\224\184\167\224\185\130\224\184\161\224\184\135",
	["smooth"] = "\224\184\170\224\184\161\224\184\185\224\184\151",
	["raise"] = "\224\185\128\224\184\158\224\184\180\224\185\136\224\184\161\224\184\130\224\184\182\224\185\137\224\184\153",
	["lower"] = "\224\184\165\224\184\148\224\184\165\224\184\135",
	["factory"] = "\224\184\132\224\185\136\224\184\178\224\185\128\224\184\163\224\184\180\224\185\136\224\184\161\224\184\149\224\185\137\224\184\153",
	["tune"] = "\224\184\136\224\184\185\224\184\153",
	["prev"] = "<",
	["next"] = ">"
}
local v_u_15 = {
	["chip"] = 20,
	["name"] = 26,
	["tool"] = 30,
	["code"] = 26,
	["power"] = 20,
	["top"] = 18,
	["tune"] = 84,
	["arrow"] = 30
}
local v_u_16 = {
	["chip"] = true,
	["tool"] = true,
	["code"] = true,
	["tune"] = true,
	["arrow"] = true
}
local v_u_17 = Vector2.new(125, 82)
local v_u_18 = Vector2.new(1669, 914)
local v_u_19 = {
	164,
	118,
	1756,
	959
}
local v_u_20 = {
	606,
	64,
	661,
	168
}
local v_u_21 = {
	80,
	406,
	875,
	223
}
local v_u_22 = {
	138,
	238,
	338,
	438,
	538,
	638,
	738,
	838
}
local v_u_23 = {
	600,
	236,
	1730,
	784
}
local v_u_24 = {
	["Air"] = "Faders",
	["Fuel"] = "Cells",
	["Afr"] = "Gauge",
	["Tps"] = "Graph",
	["Oil"] = "Blocks",
	["Ign"] = "Wheel",
	["Idle"] = "Knobs",
	["Speed"] = "Faders"
}
local v_u_25 = {
	1236,
	159,
	1344,
	227
}
local v_u_26 = {
	1367,
	159,
	1729,
	226
}
local v_u_27 = {
	{
		781,
		797,
		884,
		852
	},
	{
		914,
		797,
		1016,
		852
	},
	{
		1047,
		797,
		1149,
		852
	},
	{
		1180,
		797,
		1282,
		852
	}
}
local v_u_28 = {
	-10,
	-1,
	1,
	10
}
local v_u_29 = {
	625,
	797,
	751,
	852
}
local v_u_30 = {
	1312,
	797,
	1436,
	852
}
local v_u_31 = {
	["smooth"] = {
		624,
		881,
		818,
		934
	},
	["raise"] = {
		830,
		881,
		1024,
		934
	},
	["lower"] = {
		1037,
		881,
		1231,
		934
	},
	["factory"] = {
		1243,
		881,
		1436,
		934
	}
}
local v_u_32 = {
	1461,
	795,
	1720,
	934
}
local v_u_33 = Color3.new(1, 1, 1)
local v_u_34 = Color3.fromRGB(255, 255, 255)
local v_u_35 = Color3.fromRGB(158, 164, 182)
local v_u_36 = Color3.fromRGB(24, 255, 0)
local v37 = Color3.fromRGB(255, 208, 20)
local v_u_38 = Color3.fromRGB(255, 20, 47)
local v_u_39 = v_u_9.ACCENT
local v_u_40 = v_u_9.YELLOW
local v_u_41 = v_u_9.ACCENT
local v_u_42 = v_u_9.CARD
local v_u_43 = v_u_9.PANEL
local v_u_44 = v_u_9.GRAD.gold[1]
local v_u_45 = v_u_9.GRAD.gold[2]
local v_u_46 = {
	["Air"] = { Color3.fromRGB(96, 228, 255), Color3.fromRGB(18, 138, 210) },
	["Fuel"] = { Color3.fromRGB(255, 176, 64), Color3.fromRGB(236, 104, 14) },
	["Afr"] = { Color3.fromRGB(92, 228, 132), Color3.fromRGB(20, 148, 72) },
	["Tps"] = { Color3.fromRGB(182, 126, 255), Color3.fromRGB(108, 56, 226) },
	["Oil"] = { Color3.fromRGB(255, 226, 112), Color3.fromRGB(244, 150, 20) },
	["Ign"] = { Color3.fromRGB(255, 88, 88), Color3.fromRGB(204, 22, 44) },
	["Idle"] = { Color3.fromRGB(255, 116, 196), Color3.fromRGB(212, 38, 132) },
	["Speed"] = { Color3.fromRGB(48, 214, 186), Color3.fromRGB(10, 136, 124) }
}
local v_u_47 = Color3.fromRGB(20, 148, 72)
local v_u_48 = Color3.fromRGB(92, 228, 132)
local v_u_49 = Color3.fromRGB(14, 70, 44)
local v_u_50 = Color3.fromRGB(22, 110, 66)
local v_u_51 = {
	{ 7, v_u_38 },
	{ 14, v37 },
	{ 24, v_u_36 }
}
local v_u_52 = {
	{ 0, Color3.fromRGB(213, 0, 0) },
	{ 0.3, Color3.fromRGB(213, 105, 0) },
	{ 0.5, Color3.fromRGB(194, 142, 0) },
	{ 0.7, Color3.fromRGB(178, 194, 0) },
	{ 1, Color3.fromRGB(68, 194, 0) }
}
local v_u_53 = {
	{ 620, Color3.fromRGB(58, 60, 72) },
	{ 1440, Color3.fromRGB(36, 38, 47) }
}
local v_u_54 = Font.new("rbxasset://fonts/families/GothamSSm.json", Enum.FontWeight.Bold)
local v_u_55 = Font.new("rbxasset://fonts/families/GothamSSm.json", Enum.FontWeight.Heavy)
local v_u_56 = v_u_9.FONT_HEAVY
local v_u_57 = {}
local v_u_58 = nil
local function v_u_66(p59, p60) -- name: corner
	-- upvalues: (copy) v_u_1
	local v61 = {}
	local v62
	if p60 == "round" then
		v62 = UDim.new(1, 0)
	else
		v62 = UDim.new(0, p60)
	end
	v61.CornerRadius = v62
	local v63 = v_u_1.new("UICorner")
	for v64, v65 in v61 do
		v63[v64] = v65
	end
	v63.Parent = p59
end
local function v_u_74(p67, p68, p69) -- name: stroke
	-- upvalues: (copy) v_u_1
	local v70 = {
		["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
		["Color"] = p68,
		["Thickness"] = p69
	}
	local v_u_71 = v_u_1.new("UIStroke")
	for v72, v73 in v70 do
		v_u_71[v72] = v73
	end
	v_u_71.Parent = p67
	pcall(function()
		-- upvalues: (copy) v_u_71
		v_u_71.BorderStrokePosition = Enum.BorderStrokePosition.Inner
	end)
	return v_u_71
end
local function v_u_87(p75, p76, p77, p78, p79, p80) -- name: text
	-- upvalues: (copy) v_u_54, (copy) v_u_34, (copy) v_u_1
	local v81 = {
		["BackgroundTransparency"] = 1,
		["FontFace"] = nil,
		["Text"] = nil,
		["TextSize"] = nil,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["FontFace"] = p77 or v_u_54,
		["Text"] = p76,
		["TextSize"] = p78 or 20,
		["TextColor3"] = p79 or v_u_34,
		["TextXAlignment"] = Enum.TextXAlignment.Left
	}
	local v82 = v_u_1.new("TextLabel")
	for v83, v84 in v81 do
		v82[v83] = v84
	end
	v82.Parent = p75
	for v85, v86 in p80 or {} do
		v82[v85] = v86
	end
	return v82
end
local function v_u_92(p88) -- name: barColor
	-- upvalues: (copy) v_u_52
	for v89 = 2, #v_u_52 do
		local v90 = v_u_52[v89 - 1]
		local v91 = v_u_52[v89]
		if p88 > v91[1] then
			continue
		end
		return v90[2]:Lerp(v91[2], (p88 - v90[1]) / (v91[1] - v90[1]))
	end
	return v_u_52[#v_u_52][2]
end
local function v_u_95(p93) -- name: kindOf
	local v94 = p93:sub(1, 5)
	if v94 == "chip_" or v94 == "name_" then
		return v94:sub(1, 4)
	else
		return (p93 == "smooth" or (p93 == "raise" or (p93 == "lower" or p93 == "factory"))) and "tool" or ((p93 == "prev" or p93 == "next") and "arrow" or ((p93 == "top_pre" or p93 == "top_post") and "top" or p93))
	end
end
local function v_u_112(p96, p97, p98, p99, p100) -- name: sprite
	-- upvalues: (copy) v_u_13, (copy) v_u_17, (copy) v_u_95, (copy) v_u_15, (copy) v_u_14, (copy) v_u_16, (copy) v_u_87, (copy) v_u_54, (copy) v_u_56, (copy) v_u_34
	local v101 = v_u_13[p97]
	local v102 = p98 or v_u_17
	UDim2.fromOffset(v101[5] - v102.X, v101[6] - v102.Y)
	UDim2.fromOffset(v101[3], v101[4])
	local v103 = v_u_95(p97)
	local v104 = v_u_15[v103] or 20
	local v105 = v_u_14[p100 or p97] or p97
	local v106
	if v_u_16[v103] then
		local v107 = v_u_87
		local v108
		if v103 == "arrow" then
			v108 = v_u_54
		else
			v108 = v_u_56
		end
		v106 = v107(p96, v105, v108, v104, v_u_34, {
			["TextXAlignment"] = Enum.TextXAlignment.Center,
			["Size"] = UDim2.fromScale(1, 1)
		})
	else
		local v109 = v103 == "name" and 43 or v101[6] + v101[4] / 2 - v102.Y
		v106 = v_u_87(p96, v105, v_u_56, v104, v_u_34, {
			["AnchorPoint"] = Vector2.new(0, 0.5),
			["Position"] = UDim2.fromOffset(v101[5] - v102.X, v109),
			["Size"] = UDim2.fromOffset(0, v104 + 4),
			["AutomaticSize"] = Enum.AutomaticSize.X
		})
	end
	for v110, v111 in p99 or {} do
		if v106:IsA("ImageLabel") and v110 == "Color" then
			v106.ImageColor3 = v111
		elseif v106:IsA("TextLabel") and v110 == "Color" then
			v106.TextColor3 = v111
		elseif v106:IsA("ImageLabel") and v110 == "Transparency" then
			v106.ImageTransparency = v111
		elseif v106:IsA("TextLabel") and v110 == "Transparency" then
			v106.TextTransparency = v111
		else
			v106[v110] = v111
		end
	end
	return v106
end
local function v_u_113(_, _, _, _) -- name: shadow
	return nil
end
local function v_u_140(p114, p115, p116, p117, p118, p119, p120) -- name: psdButton
	-- upvalues: (copy) v_u_113, (copy) v_u_17, (copy) v_u_33, (copy) v_u_1, (copy) v_u_66, (copy) v_u_74, (copy) v_u_13, (copy) v_u_112, (copy) v_u_87, (copy) v_u_54, (copy) v_u_34, (copy) v_u_5, (copy) v_u_9
	v_u_113(p114, p115, nil, Vector2.new(2, 2))
	local v121 = nil or v_u_17
	local v122 = {
		["Text"] = "",
		["AutoButtonColor"] = false,
		["BackgroundColor3"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = v_u_33,
		["Position"] = UDim2.fromOffset(p115[1] - v121.X, p115[2] - v121.Y),
		["Size"] = UDim2.fromOffset(p115[3] - p115[1], p115[4] - p115[2])
	}
	local v123 = v_u_1.new("TextButton")
	for v124, v125 in v122 do
		v123[v124] = v125
	end
	v123.Parent = p114
	v_u_66(v123, 9)
	local v126 = {
		["Color"] = ColorSequence.new(p116, p117),
		["Rotation"] = p120 or 0 or 0
	}
	local v127 = v_u_1.new("UIGradient")
	for v128, v129 in v126 do
		v127[v128] = v129
	end
	v127.Parent = v123
	v_u_74(v123, v_u_33, 1).Transparency = 0.82
	local v130 = Vector2.new(p115[1], p115[2])
	local v131 = nil
	if type(p118) == "string" and v_u_13[p118] then
		v131 = v_u_112(v123, p118, v130)
	elseif type(p118) == "string" then
		v131 = v_u_87(v123, p118, v_u_54, 24, v_u_34, {
			["TextXAlignment"] = Enum.TextXAlignment.Center,
			["Size"] = UDim2.fromScale(1, 1)
		})
	end
	local v_u_132 = v_u_1.new("UIScale")
	for v133, v134 in {} do
		v_u_132[v133] = v134
	end
	v_u_132.Parent = v123
	v123.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_5, (copy) v_u_132
		v_u_5:Create(v_u_132, TweenInfo.new(0.06), {
			["Scale"] = 0.95
		}):Play()
	end)
	local function v135() -- name: up
		-- upvalues: (ref) v_u_5, (copy) v_u_132
		v_u_5:Create(v_u_132, TweenInfo.new(0.12, Enum.EasingStyle.Back), {
			["Scale"] = 1
		}):Play()
	end
	v123.MouseButton1Up:Connect(v135)
	v123.MouseLeave:Connect(v135)
	if p119 then
		v123.Activated:Connect(p119)
		if v_u_9.isTouch() then
			local v136 = {
				["Name"] = "TouchPad",
				["Text"] = "",
				["BackgroundTransparency"] = 1,
				["AutoButtonColor"] = false,
				["Position"] = nil,
				["Size"] = nil,
				["Position"] = UDim2.fromOffset(-14, -14),
				["Size"] = UDim2.new(1, 28, 1, 28)
			}
			local v137 = v_u_1.new("TextButton")
			for v138, v139 in v136 do
				v137[v138] = v139
			end
			v137.Parent = v123
			v137.Activated:Connect(p119)
		end
	end
	return v123, v131
end
local function v_u_145(p141) -- name: copy
	local v142 = {}
	for v143, v144 in p141 do
		v142[v143] = table.clone(v144)
	end
	return v142
end
local function v_u_149() -- name: dirty
	-- upvalues: (copy) v_u_8, (ref) v_u_58
	for _, v146 in v_u_8.TABLES do
		for v147 = 1, v_u_8.POINTS do
			local v148 = (v_u_58.sent or v_u_58.stock)[v146.key][v147] - v_u_58.file[v146.key][v147]
			if math.abs(v148) <= v146.step / 2 then
				continue
			end
			return true
		end
	end
	return false
end
local function v_u_153() -- name: soundDirty
	-- upvalues: (ref) v_u_58
	for v150, v151 in v_u_58.sound do
		local v152 = v151 - (v_u_58.soundSent[v150] or 1)
		if math.abs(v152) <= 1e-6 then
			continue
		end
		return true
	end
	return false
end
local function v_u_154() -- name: current
	-- upvalues: (copy) v_u_8, (ref) v_u_58
	return v_u_8.table(v_u_58.tab)
end
local v_u_155 = nil
local v_u_156 = nil
local function v_u_167() -- name: drawSide
	-- upvalues: (ref) v_u_58, (copy) v_u_40, (copy) v_u_33, (copy) v_u_8, (copy) v_u_5, (copy) v_u_92
	for v157, v158 in v_u_58.ui.maps do
		local v159 = v157 == v_u_58.tab
		local v160 = v158.Stroke
		local v161
		if v159 then
			v161 = v_u_40
		else
			v161 = v_u_33
		end
		v160.Color = v161
		v158.Stroke.Transparency = v159 and 0 or 0.82
		v158.Stroke.Thickness = v159 and 3 or 1
		local v162 = v_u_58.feedback
		if v162 then
			v162 = v_u_58.feedback[v157]
		end
		local v163
		if type(v162) == "number" then
			v163 = v_u_58.sent and v_u_8.gain(v_u_58.model) >= v_u_8.GAIN_MAX and 1 or v162
		else
			v163 = nil
		end
		local v164 = v158.Pct
		local v165
		if v163 then
			local v166 = v163 * 1000 + 0.5
			v165 = ("%.1f %%"):format(math.floor(v166) / 10)
		else
			v165 = "\226\128\148 %"
		end
		v164.Text = v165
		v158.Pct.TextTransparency = v163 and 0 or 0.4
		v_u_5:Create(v158.Fill, TweenInfo.new(0.35), {
			["Size"] = UDim2.fromScale(v163 or 0, 1)
		}):Play()
		v158.Fill.BackgroundColor3 = v_u_92(v163 or 0)
	end
end
local function v_u_174(p168) -- name: setLeds
	-- upvalues: (copy) v_u_8, (ref) v_u_58
	local v169
	if p168 then
		local v170 = (p168 - v_u_8.GAIN_MIN) / (v_u_8.GAIN_MAX - v_u_8.GAIN_MIN)
		local v171 = math.clamp(v170, 0, 1) * 24 + 0.5
		v169 = math.floor(v171)
	else
		v169 = 0
	end
	for v172, v173 in v_u_58.ui.leds do
		v173.BackgroundTransparency = v172 <= v169 and 0 or 0.78
	end
end
local function v_u_182(p175) -- name: setTuneLook
	-- upvalues: (ref) v_u_58, (copy) v_u_47, (copy) v_u_49, (copy) v_u_48, (copy) v_u_50
	local v176 = v_u_58.ui
	local v177 = p175 == "ready"
	local v178 = v176.tuneGrad
	local v179 = ColorSequence.new
	local v180
	if v177 then
		v180 = v_u_47
	else
		v180 = v_u_49
	end
	local v181
	if v177 then
		v181 = v_u_48
	else
		v181 = v_u_50
	end
	v178.Color = v179(v180, v181)
	if v176.tuneLabel:IsA("ImageLabel") then
		v176.tuneLabel.ImageTransparency = v177 and 0 or 0.3
	else
		v176.tuneLabel.TextTransparency = v177 and 0 or 0.3
	end
end
local function v_u_194() -- name: drawMeter
	-- upvalues: (ref) v_u_58, (copy) v_u_174, (copy) v_u_36, (copy) v_u_38, (copy) v_u_34, (copy) v_u_7, (copy) v_u_8, (copy) v_u_35, (copy) v_u_182, (copy) v_u_149, (copy) v_u_153
	local v183 = v_u_58.ui
	if v_u_58.result and not v_u_58.running then
		local v184 = v_u_58.result
		v_u_174(v184)
		v183.gain.Text = ("x%.2f"):format(v184)
		local v185 = v183.gain
		local v186
		if v184 > 1.01 then
			v186 = v_u_36
		elseif v184 < 0.99 then
			v186 = v_u_38
		else
			v186 = v_u_34
		end
		v185.TextColor3 = v186
		local v187 = v183.top
		local v188 = v_u_58.model:GetAttribute("MaxSpeed") or 100
		local _, _, v189 = v_u_7.upgradeScales(v_u_58.model)
		local v190 = v188 * v189 * v_u_8.KMH_PER_STUD + 0.5
		local v191 = math.floor(v190)
		v187.Text = tostring(v191)
	elseif not v_u_58.running then
		for v192, v193 in v_u_58.ui.leds do
			v193.BackgroundTransparency = v192 <= 0 and 0 or 0.78
		end
		v183.gain.Text = "x?.??"
		v183.gain.TextColor3 = v_u_35
		v183.top.Text = "?"
	end
	if not v_u_58.flashing then
		v_u_182((v_u_149() or v_u_153()) and "ready" or "idle")
	end
end
local v_u_227 = {
	["soundSetting"] = function(p195) -- name: soundSetting
		-- upvalues: (ref) v_u_58
		return v_u_58 and (v_u_58.sound[p195] or 1) or 1
	end,
	["setSoundSetting"] = function(p196, p197) -- name: setSoundSetting
		-- upvalues: (copy) v_u_8, (ref) v_u_58, (copy) v_u_194
		local v198 = v_u_8.snapSetting(p196, p197)
		if v_u_58 then
			local v199 = v198 - (v_u_58.sound[p196] or 1)
			if math.abs(v199) > 1e-6 then
				v_u_58.sound[p196] = v198
				local v200 = v_u_8.SOUND_SETTINGS[p196]
				local v201 = v_u_58.model
				local v202 = v200.attribute
				local v203 = v198 - 1
				if math.abs(v203) < 1e-6 then
					v198 = nil
				end
				v201:SetAttribute(v202, v198)
				v_u_194()
			end
		end
	end,
	["size"] = Vector2.new(v_u_23[3] - v_u_23[1], v_u_23[4] - v_u_23[2]),
	["style"] = {
		["NUM"] = v_u_54,
		["NUM_HEAVY"] = v_u_55,
		["THAI"] = v_u_56
	},
	["t"] = function() -- name: t
		-- upvalues: (copy) v_u_154
		return v_u_154()
	end,
	["values"] = function() -- name: values
		-- upvalues: (ref) v_u_58
		return v_u_58.file[v_u_58.tab]
	end,
	["set"] = function(p204, p205) -- name: set
		-- upvalues: (ref) v_u_58, (copy) v_u_8, (ref) v_u_156
		if v_u_58 and not v_u_58.veiled then
			local v206 = v_u_8.table(v_u_58.tab)
			local v207 = p205 / v206.step
			local v208 = math.round(v207)
			local v209 = v_u_58.file[v206.key]
			local v210 = v208 * v206.step
			local v211 = tonumber(("%.4f"):format(v210))
			local v212 = v206.min
			local v213 = v206.max
			v209[p204] = math.clamp(v211, v212, v213)
			v_u_156()
		end
	end,
	["pick"] = function() -- name: pick
		-- upvalues: (ref) v_u_58
		return v_u_58.pick
	end,
	["setPick"] = function(p214) -- name: setPick
		-- upvalues: (ref) v_u_58, (copy) v_u_8
		local v215 = v_u_58
		local v216 = v_u_8.POINTS
		v215.pick = math.clamp(p214, 1, v216)
	end,
	["changed"] = function(p217) -- name: changed
		-- upvalues: (copy) v_u_8, (ref) v_u_58
		local v218 = v_u_8.table(v_u_58.tab)
		local v219 = (v_u_58.sent or v_u_58.stock)[v218.key][p217] - v_u_58.file[v218.key][p217]
		return math.abs(v219) > v218.step / 2
	end,
	["veiled"] = function() -- name: veiled
		-- upvalues: (ref) v_u_58
		return v_u_58 == nil and true or v_u_58.veiled == true
	end,
	["hint"] = function() -- name: hint
		-- upvalues: (ref) v_u_58
		local v220
		if v_u_58 then
			local v221 = v_u_58.hints
			v220 = type(v221) == "table" and v_u_58.hints[v_u_58.tab] or nil
		else
			v220 = nil
		end
		return v220
	end,
	["match"] = function() -- name: match
		-- upvalues: (ref) v_u_58, (copy) v_u_8
		local v222 = v_u_58
		if v222 then
			local v223 = v_u_58.tab
			v222 = v_u_58.feedback
			if v222 then
				v222 = v_u_58.feedback[v223]
			end
			if type(v222) ~= "number" then
				return nil
			end
			if v_u_58.sent and v_u_8.gain(v_u_58.model) >= v_u_8.GAIN_MAX then
				return 1
			end
		end
		return v222
	end,
	["redraw"] = function() -- name: redraw
		-- upvalues: (ref) v_u_58, (ref) v_u_155
		if v_u_58 then
			v_u_155()
		end
	end,
	["beginDrag"] = function(p224, p225) -- name: beginDrag
		-- upvalues: (ref) v_u_58
		local v226 = v_u_58
		v_u_58.drag = p224
		v226.dragEnd = p225
	end,
	["scale"] = function() -- name: scale
		-- upvalues: (ref) v_u_58
		return not v_u_58 and 1 or v_u_58.ui.scale.Scale
	end
}
v_u_155 = function() -- name: draw
	-- upvalues: (ref) v_u_58, (copy) v_u_8, (copy) v_u_12, (copy) v_u_24, (copy) v_u_227, (copy) v_u_167, (copy) v_u_194
	local v228 = v_u_58.ui
	local v229 = v_u_8.table(v_u_58.tab)
	if v228.editorKey == v229.key then
		v228.editor.update()
	else
		if v228.editor then
			v228.editor.destroy()
		end
		v228.edit:ClearAllChildren()
		local v230 = v_u_58
		v_u_58.drag = nil
		v230.dragEnd = nil
		v228.editor = v_u_12.new(v_u_24[v229.key] or "Graph", v228.edit, v_u_227)
		v228.editorKey = v229.key
	end
	v228.veil.Visible = v_u_58.veiled == true
	v228.edit.Visible = not v_u_58.veiled
	if v_u_58.veiled then
		v228.veilRows.update()
	end
	v228.veilSub.Text = ("\224\184\136\224\184\185\224\184\153\224\184\136\224\184\178\224\184\129 %s \194\183 \224\184\132\224\185\136\224\184\178\224\184\150\224\184\185\224\184\129\224\184\139\224\185\136\224\184\173\224\184\153\224\185\132\224\184\167\224\185\137 \224\184\148\224\184\185\224\185\132\224\184\161\224\185\136\224\185\132\224\184\148\224\185\137 \194\183 \224\185\129\224\184\159\224\184\165\224\184\138\224\185\132\224\184\159\224\184\165\224\185\140\224\184\130\224\184\173\224\184\135\224\184\149\224\184\177\224\184\167\224\185\128\224\184\173\224\184\135\224\185\128\224\184\161\224\184\183\224\185\136\224\184\173\224\185\132\224\184\171\224\184\163\224\185\136 \224\184\136\224\184\185\224\184\153\224\184\153\224\184\181\224\185\137\224\184\136\224\184\176\224\184\171\224\184\178\224\184\162\224\185\132\224\184\155"):format(v_u_58.borrowed or "?")
	for _, v231 in v228.nudges do
		local v232 = v231.label
		local v233 = v231.steps > 0 and "+" or "-"
		local v234 = v231.steps
		v232.Text = v233 .. ("%g"):format(math.abs(v234) * v229.step)
	end
	v_u_167()
	v_u_194()
end
local function v_u_246(p235) -- name: shiftAll
	-- upvalues: (ref) v_u_58, (copy) v_u_8, (ref) v_u_155
	if not v_u_58.veiled then
		local v236 = v_u_8.table(v_u_58.tab)
		for v237, v238 in v_u_58.file[v236.key] do
			local v239 = (v238 + (v236.max - v236.min) * 0.02 * p235) / v236.step
			local v240 = math.round(v239)
			local v241 = v_u_58.file[v236.key]
			local v242 = v240 * v236.step
			local v243 = tonumber(("%.4f"):format(v242))
			local v244 = v236.min
			local v245 = v236.max
			v241[v237] = math.clamp(v243, v244, v245)
		end
		v_u_155()
	end
end
local function v_u_260(p247) -- name: nudge
	-- upvalues: (ref) v_u_58, (copy) v_u_8, (ref) v_u_155
	if not v_u_58.veiled then
		local v248 = v_u_8.table(v_u_58.tab)
		local v249 = v_u_58.ui.editor
		local v250
		if v249 and v249.selection then
			v250 = v249.selection()
		else
			v250 = { v_u_58.pick }
		end
		for _, v251 in v250 do
			local v252 = v_u_58.file[v248.key][v251] / v248.step
			local v253 = (math.round(v252) + p247) * v248.step / v248.step
			local v254 = math.round(v253)
			local v255 = v_u_58.file[v248.key]
			local v256 = v254 * v248.step
			local v257 = tonumber(("%.4f"):format(v256))
			local v258 = v248.min
			local v259 = v248.max
			v255[v251] = math.clamp(v257, v258, v259)
		end
		v_u_155()
	end
end
local function v_u_275() -- name: smooth
	-- upvalues: (ref) v_u_58, (copy) v_u_8, (ref) v_u_155
	if not v_u_58.veiled then
		local v261 = v_u_8.table(v_u_58.tab)
		local v262 = table.clone(v_u_58.file[v261.key])
		for v263 = 1, #v262 do
			local v264 = v263 - 1
			local v265 = v262[math.max(1, v264)] + 2 * v262[v263]
			local v266 = #v262
			local v267 = v263 + 1
			local v268 = (v265 + v262[math.min(v266, v267)]) / 4 / v261.step
			local v269 = math.round(v268)
			local v270 = v_u_58.file[v261.key]
			local v271 = v269 * v261.step
			local v272 = tonumber(("%.4f"):format(v271))
			local v273 = v261.min
			local v274 = v261.max
			v270[v263] = math.clamp(v272, v273, v274)
		end
		v_u_155()
	end
end
local function v_u_277() -- name: factory
	-- upvalues: (ref) v_u_58, (copy) v_u_8, (ref) v_u_155
	if not v_u_58.veiled then
		local v276 = v_u_8.table(v_u_58.tab)
		v_u_58.file[v276.key] = table.clone(v_u_8.stockFile()[v276.key])
		v_u_155()
	end
end
local function v_u_309() -- name: flash
	-- upvalues: (ref) v_u_58, (copy) v_u_149, (copy) v_u_153, (copy) v_u_49, (copy) v_u_50, (copy) v_u_5, (copy) v_u_4, (copy) v_u_7, (copy) v_u_8, (copy) v_u_2, (copy) v_u_145, (copy) v_u_10, (copy) v_u_194, (ref) v_u_155, (copy) v_u_174
	if v_u_58.flashing or not (v_u_149() or v_u_153()) then
		return
	else
		v_u_58.flashing = true
		local v278 = v_u_58.ui
		local v279 = v_u_58.ui
		v279.tuneGrad.Color = ColorSequence.new(v_u_49, v_u_50)
		if v279.tuneLabel:IsA("ImageLabel") then
			v279.tuneLabel.ImageTransparency = 0.3
		else
			v279.tuneLabel.TextTransparency = 0.3
		end
		v278.progress.Visible = true
		v278.progress.Size = UDim2.fromScale(0, 1)
		local v280 = v_u_5:Create(v278.progress, TweenInfo.new(0.7, Enum.EasingStyle.Quad), {
			["Size"] = UDim2.fromScale(1, 1)
		})
		v280:Play()
		local v281 = v_u_4:WaitForChild(v_u_7.REMOTES):WaitForChild(v_u_8.REMOTE)
		local v282 = v_u_58
		local v283 = true
		for v284, v285 in table.clone(v_u_58.sound) do
			local v286 = v285 - (v_u_58.soundSent[v284] or 1)
			if math.abs(v286) <= 1e-6 then
				continue
			end
			local v287 = v_u_2.invoke
			local v288 = v_u_58.model
			local v289, v290 = pcall(v287, v281, "Sound", v288, {
				["k"] = v284,
				["v"] = v285
			})
			if v289 and v290 then
				v282.soundSent[v284] = v285
			else
				v283 = false
			end
		end
		local v291
		if v_u_58 == v282 then
			v291 = v_u_149()
		else
			v291 = false
		end
		local v292, v293, v294, v295, v296, v297, v298
		if v291 then
			v292 = v_u_145(v_u_58.file)
			local v299 = v_u_2.invoke
			local v300 = v_u_58.model
			local v301 = {
				["k"] = v_u_8.sum(v292)
			}
			local v302
			v293, v294, v295, v302, v296, v297 = pcall(v299, v281, "Send", v300, v292, v301)
			v298 = 0
		else
			v293 = nil
			v294 = nil
			v298 = 0
			v295 = nil
			v292 = nil
			v296 = nil
			v297 = nil
		end
		if v280.PlaybackState == Enum.PlaybackState.Playing then
			v280.Completed:Wait()
		end
		if v_u_58 == v282 then
			v_u_58.flashing = false
			v278.progress.Visible = false
			if v291 then
				if v293 then
					if v294 and v298 > 0 then
						v295 = ("%s \194\183 \224\185\129\224\184\129\224\185\137\224\185\132\224\184\167\224\185\137\224\184\173\224\184\181\224\184\129 %d \224\185\129\224\184\156\224\184\153\224\184\151\224\184\181\224\185\136 \224\184\129\224\184\148\224\184\136\224\184\185\224\184\153\224\184\173\224\184\181\224\184\129\224\184\132\224\184\163\224\184\177\224\185\137\224\184\135 (\224\185\129\224\184\159\224\184\165\224\184\138\224\185\132\224\184\148\224\185\137\224\184\151\224\184\181\224\184\165\224\184\176 1 \224\185\129\224\184\156\224\184\153\224\184\151\224\184\181\224\185\136)"):format(v295 or "", v298)
					end
					v_u_10.show(v295 or "", v294 and "ok" or "error")
					if v294 then
						v_u_58.sent = v_u_145(v292)
						v_u_58.feedback = v296
						local v303 = v_u_58
						if type(v297) ~= "table" then
							v297 = nil
						end
						v303.hints = v297
						local v304 = v_u_58
						v_u_58.borrowed = nil
						v304.veiled = false
					end
				else
					v_u_10.show("The ECU didn\'t answer", "error")
				end
				v_u_155()
				if v293 and v294 then
					local v305 = v_u_8.gain(v_u_58.model)
					v_u_58.running = true
					v278.top.Text = "\226\128\166"
					for v306 = 1, 24 do
						if v_u_58 ~= v282 then
							return
						end
						local v307 = v306 / 24
						local v308 = v_u_8.GAIN_MIN + (v305 - v_u_8.GAIN_MIN) * (1 - (1 - v307) ^ 3)
						v_u_174(v308)
						v278.gain.Text = ("x%.2f"):format(v308)
						task.wait(0.04)
					end
					v_u_58.running = false
					v_u_58.result = v305
					v_u_194()
				end
			else
				v_u_10.show(v283 and "\224\184\149\224\184\177\224\185\137\224\184\135\224\185\128\224\184\170\224\184\181\224\184\162\224\184\135\224\185\129\224\184\165\224\185\137\224\184\167 (\224\185\132\224\184\161\224\185\136\224\184\161\224\184\181\224\184\156\224\184\165\224\184\129\224\184\177\224\184\154\224\184\132\224\185\136\224\184\178\224\184\136\224\184\185\224\184\153)" or "\224\184\149\224\184\177\224\185\137\224\184\135\224\185\128\224\184\170\224\184\181\224\184\162\224\184\135\224\185\132\224\184\161\224\185\136\224\184\170\224\184\179\224\185\128\224\184\163\224\185\135\224\184\136 \224\184\165\224\184\173\224\184\135\224\185\131\224\184\171\224\184\161\224\185\136\224\184\173\224\184\181\224\184\129\224\184\151\224\184\181", v283 and "ok" or "error")
				v_u_194()
			end
		else
			return
		end
	end
end
local v_u_310 = false
local v_u_311 = 0
local function v_u_317() -- name: drawCode
	-- upvalues: (ref) v_u_58, (copy) v_u_149, (copy) v_u_7, (copy) v_u_8, (ref) v_u_310, (copy) v_u_9, (copy) v_u_34, (ref) v_u_311, (copy) v_u_35
	local v312 = v_u_58.ui
	local v313 = v_u_58.borrowed and "\224\184\136\224\184\185\224\184\153\224\184\153\224\184\181\224\185\137\224\185\128\224\184\155\224\185\135\224\184\153\224\184\132\224\185\136\224\184\178\224\184\130\224\184\173\224\184\135\224\184\132\224\184\153\224\184\173\224\184\183\224\185\136\224\184\153 \224\185\129\224\184\138\224\184\163\224\185\140\224\184\149\224\185\136\224\184\173\224\185\132\224\184\161\224\185\136\224\185\132\224\184\148\224\185\137" or (not v_u_58.sent and "\224\184\162\224\184\177\224\184\135\224\185\132\224\184\161\224\185\136\224\185\132\224\184\148\224\185\137\224\185\129\224\184\159\224\184\165\224\184\138\224\184\136\224\184\185\224\184\153 \224\185\129\224\184\159\224\184\165\224\184\138\224\184\129\224\185\136\224\184\173\224\184\153\224\184\150\224\184\182\224\184\135\224\184\136\224\184\176\224\185\129\224\184\138\224\184\163\224\185\140\224\185\132\224\184\148\224\185\137" or (v_u_149() and "\224\184\161\224\184\181\224\184\132\224\185\136\224\184\178\224\184\151\224\184\181\224\185\136\224\185\129\224\184\129\224\185\137\224\185\129\224\184\149\224\185\136\224\184\162\224\184\177\224\184\135\224\185\132\224\184\161\224\185\136\224\185\129\224\184\159\224\184\165\224\184\138 \224\185\129\224\184\159\224\184\165\224\184\138\224\184\129\224\185\136\224\184\173\224\184\153\224\185\129\224\184\165\224\185\137\224\184\167\224\184\132\224\185\136\224\184\173\224\184\162\224\185\129\224\184\138\224\184\163\224\185\140" or nil))
	local v314 = v_u_7.formatCash(v_u_8.SHARE_PRICE)
	if v_u_310 then
		v_u_9.setButton(v312.shareBtn, "grey", "\224\184\163\224\184\173\224\184\170\224\184\177\224\184\129\224\184\132\224\184\163\224\184\185\224\185\136\226\128\166", v_u_34)
	elseif v313 then
		v_u_9.setButton(v312.shareBtn, "grey", "\224\184\170\224\184\163\224\185\137\224\184\178\224\184\135\224\185\130\224\184\132\224\185\137\224\184\148  " .. v314, v_u_34)
	elseif os.clock() < v_u_311 then
		v_u_9.setButton(v312.shareBtn, "red", "\224\184\129\224\184\148\224\184\173\224\184\181\224\184\129\224\184\132\224\184\163\224\184\177\224\185\137\224\184\135 \224\184\136\224\185\136\224\184\178\224\184\162 " .. v314, v_u_34)
	else
		v_u_9.setButton(v312.shareBtn, "gold", "\224\184\170\224\184\163\224\185\137\224\184\178\224\184\135\224\185\130\224\184\132\224\185\137\224\184\148  " .. v314, v_u_9.DARK_TEXT)
	end
	v312.shareNote.Text = v313 or "1 \224\185\130\224\184\132\224\185\137\224\184\148 \224\185\131\224\184\138\224\185\137\224\185\132\224\184\148\224\185\137 1 \224\184\132\224\184\153 \224\184\129\224\184\177\224\184\154\224\184\163\224\184\150\224\184\163\224\184\184\224\185\136\224\184\153\224\185\128\224\184\148\224\184\181\224\184\162\224\184\167\224\184\129\224\184\177\224\184\153 \194\183 \224\184\132\224\184\153\224\185\131\224\184\138\224\185\137\224\184\136\224\184\176\224\184\161\224\184\173\224\184\135\224\185\132\224\184\161\224\185\136\224\185\128\224\184\171\224\185\135\224\184\153\224\184\132\224\185\136\224\184\178 \194\183 \224\184\170\224\185\136\224\184\135\224\185\130\224\184\132\224\185\137\224\184\148\224\185\131\224\184\171\224\185\137\224\185\128\224\184\158\224\184\183\224\185\136\224\184\173\224\184\153\224\185\132\224\184\148\224\185\137\224\185\128\224\184\165\224\184\162"
	local v315 = v312.shareNote
	local v316
	if v313 then
		v316 = Color3.fromRGB(255, 110, 110)
	else
		v316 = v_u_35
	end
	v315.TextColor3 = v316
	v312.codeOut.Text = v_u_58.lastCode or "\226\128\148"
end
local function v_u_331() -- name: redeemCode
	-- upvalues: (ref) v_u_310, (ref) v_u_58, (copy) v_u_8, (copy) v_u_10, (copy) v_u_317, (copy) v_u_4, (copy) v_u_7, (copy) v_u_2, (copy) v_u_145, (ref) v_u_311, (ref) v_u_155
	if v_u_310 or not v_u_58 then
		return
	else
		local v318 = v_u_58.ui.codeInput.Text
		if v_u_8.cleanCode(v318) then
			v_u_310 = true
			v_u_317()
			local v319 = v_u_4:WaitForChild(v_u_7.REMOTES):WaitForChild(v_u_8.REMOTE)
			local v320 = v_u_2.invoke
			local v321 = v_u_58.model
			local v322, v323, v324, v325, v326, v327 = pcall(v320, v319, "Redeem", v321, v318)
			v_u_310 = false
			if v_u_58 then
				v_u_10.show(v322 and (v324 or "") or "The ECU didn\'t answer", v322 and v323 and "ok" or "error")
				if v322 and v323 then
					local v328 = v_u_58
					v_u_58.borrowed = v327
					v328.veiled = true
					local v329 = v_u_58
					v_u_58.file = v_u_145(v_u_58.stock)
					v329.sent = nil
					local v330 = v_u_58
					v_u_58.feedback = v326
					v330.result = v325
					v_u_58.hints = nil
					v_u_58.ui.codeInput.Text = ""
					v_u_58.ui.codeBox.Visible = false
					v_u_311 = 0
					v_u_155()
				else
					v_u_317()
				end
			else
				return
			end
		else
			v_u_10.show("\224\185\130\224\184\132\224\185\137\224\184\148\224\185\132\224\184\161\224\185\136\224\184\150\224\184\185\224\184\129\224\184\149\224\185\137\224\184\173\224\184\135 (8 \224\184\149\224\184\177\224\184\167 \224\185\128\224\184\138\224\185\136\224\184\153 ABCD-EFGH)", "error")
			return
		end
	end
end
local function v_u_340() -- name: shareCode
	-- upvalues: (ref) v_u_310, (ref) v_u_58, (copy) v_u_149, (copy) v_u_10, (ref) v_u_311, (copy) v_u_317, (copy) v_u_4, (copy) v_u_7, (copy) v_u_8, (copy) v_u_2
	if v_u_310 or not v_u_58 then
		return
	else
		local v332 = v_u_58.borrowed and "\224\184\136\224\184\185\224\184\153\224\184\153\224\184\181\224\185\137\224\185\128\224\184\155\224\185\135\224\184\153\224\184\132\224\185\136\224\184\178\224\184\130\224\184\173\224\184\135\224\184\132\224\184\153\224\184\173\224\184\183\224\185\136\224\184\153 \224\185\129\224\184\138\224\184\163\224\185\140\224\184\149\224\185\136\224\184\173\224\185\132\224\184\161\224\185\136\224\185\132\224\184\148\224\185\137" or (not v_u_58.sent and "\224\184\162\224\184\177\224\184\135\224\185\132\224\184\161\224\185\136\224\185\132\224\184\148\224\185\137\224\185\129\224\184\159\224\184\165\224\184\138\224\184\136\224\184\185\224\184\153 \224\185\129\224\184\159\224\184\165\224\184\138\224\184\129\224\185\136\224\184\173\224\184\153\224\184\150\224\184\182\224\184\135\224\184\136\224\184\176\224\185\129\224\184\138\224\184\163\224\185\140\224\185\132\224\184\148\224\185\137" or (v_u_149() and "\224\184\161\224\184\181\224\184\132\224\185\136\224\184\178\224\184\151\224\184\181\224\185\136\224\185\129\224\184\129\224\185\137\224\185\129\224\184\149\224\185\136\224\184\162\224\184\177\224\184\135\224\185\132\224\184\161\224\185\136\224\185\129\224\184\159\224\184\165\224\184\138 \224\185\129\224\184\159\224\184\165\224\184\138\224\184\129\224\185\136\224\184\173\224\184\153\224\185\129\224\184\165\224\185\137\224\184\167\224\184\132\224\185\136\224\184\173\224\184\162\224\185\129\224\184\138\224\184\163\224\185\140" or nil))
		if v332 then
			v_u_10.show(v332, "error")
			return
		elseif v_u_311 <= os.clock() then
			v_u_311 = os.clock() + 4
			v_u_317()
			task.delay(4.05, function()
				-- upvalues: (ref) v_u_58, (ref) v_u_310, (ref) v_u_317
				if v_u_58 and (v_u_58.ui.codeBox.Visible and not v_u_310) then
					v_u_317()
				end
			end)
			return
		else
			v_u_311 = 0
			v_u_310 = true
			v_u_317()
			local v333 = v_u_4:WaitForChild(v_u_7.REMOTES):WaitForChild(v_u_8.REMOTE)
			local v334 = v_u_2.invoke
			local v335 = v_u_58.model
			local v336, v337, v338, v339 = pcall(v334, v333, "Share", v335)
			v_u_310 = false
			if v_u_58 then
				if v336 and (v337 and v339) then
					v_u_58.lastCode = v339
				end
				v_u_10.show(v336 and (v338 or "") or "The ECU didn\'t answer", v336 and v337 and "ok" or "error")
				v_u_317()
			end
		end
	end
end
local function v_u_341() -- name: tuneOwn
	-- upvalues: (ref) v_u_58, (copy) v_u_145, (ref) v_u_155
	v_u_58.veiled = false
	v_u_58.file = v_u_145(v_u_58.stock)
	v_u_155()
end
local function v_u_357(p342) -- name: buildBackground
	-- upvalues: (copy) v_u_9, (copy) v_u_1, (copy) v_u_66, (copy) v_u_19, (copy) v_u_17, (copy) v_u_33
	local v343 = {
		["Name"] = "Bg",
		["BackgroundColor3"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = v_u_9.CARD_DARK,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v344 = v_u_1.new("Frame")
	for v345, v346 in v343 do
		v344[v345] = v346
	end
	v344.Parent = p342
	v_u_66(v344, 12)
	local v347 = v_u_19
	local v348 = nil or v_u_17
	local v349 = {
		["BackgroundColor3"] = v_u_33,
		["Position"] = UDim2.fromOffset(v347[1] - v348.X, v347[2] - v348.Y),
		["Size"] = UDim2.fromOffset(v347[3] - v347[1], v347[4] - v347[2])
	}
	local v350 = v_u_1.new("Frame")
	for v351, v352 in v349 do
		v350[v351] = v352
	end
	v350.Parent = v344
	v_u_66(v350, 12)
	local v353 = {
		["Rotation"] = -6,
		["Color"] = nil,
		["Color"] = ColorSequence.new({ ColorSequenceKeypoint.new(0, v_u_9.CARD), ColorSequenceKeypoint.new(0.45, v_u_9.PANEL), ColorSequenceKeypoint.new(1, v_u_9.CARD_DARK) })
	}
	local v354 = v_u_1.new("UIGradient")
	for v355, v356 in v353 do
		v354[v355] = v356
	end
	v354.Parent = v350
end
local function v_u_364(p358) -- name: buildLogo
	-- upvalues: (copy) v_u_20, (copy) v_u_17, (copy) v_u_21, (copy) v_u_1
	local v359 = UDim2.fromOffset(v_u_20[1] - v_u_17.X, v_u_20[2] - v_u_17.Y)
	local v360 = {
		["Name"] = "Logo",
		["BackgroundTransparency"] = 1,
		["Image"] = "rbxassetid://121721248770913",
		["ImageRectOffset"] = nil,
		["ImageRectSize"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 3,
		["ImageRectOffset"] = Vector2.new(v_u_21[1], v_u_21[2]),
		["ImageRectSize"] = Vector2.new(v_u_21[3], v_u_21[4]),
		["Position"] = v359,
		["Size"] = UDim2.fromOffset(v_u_20[3], v_u_20[4])
	}
	local v361 = v_u_1.new("ImageLabel")
	for v362, v363 in v360 do
		v361[v362] = v363
	end
	v361.Parent = p358
end
local function v_u_621(p365) -- name: build
	-- upvalues: (copy) v_u_18, (copy) v_u_1, (copy) v_u_357, (copy) v_u_364, (copy) v_u_17, (copy) v_u_66, (copy) v_u_74, (copy) v_u_33, (copy) v_u_11, (copy) v_u_34, (ref) v_u_58, (copy) v_u_140, (copy) v_u_25, (copy) v_u_9, (copy) v_u_112, (copy) v_u_113, (copy) v_u_26, (copy) v_u_87, (copy) v_u_55, (copy) v_u_38, (copy) v_u_54, (copy) v_u_51, (copy) v_u_8, (copy) v_u_22, (copy) v_u_42, (copy) v_u_43, (copy) v_u_46, (copy) v_u_44, (copy) v_u_45, (ref) v_u_155, (copy) v_u_23, (copy) v_u_41, (copy) v_u_56, (copy) v_u_35, (copy) v_u_53, (copy) v_u_341, (copy) v_u_12, (copy) v_u_227, (copy) v_u_29, (copy) v_u_28, (copy) v_u_27, (copy) v_u_260, (copy) v_u_30, (copy) v_u_31, (copy) v_u_275, (copy) v_u_246, (copy) v_u_277, (copy) v_u_32, (copy) v_u_47, (copy) v_u_48, (copy) v_u_309, (ref) v_u_311, (copy) v_u_39, (copy) v_u_331, (copy) v_u_340, (copy) v_u_36, (copy) v_u_317
	local v366 = {
		["Name"] = "EcuPanel",
		["BackgroundTransparency"] = 1,
		["Active"] = true,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["AnchorPoint"] = Vector2.new(1, 0.5),
		["Position"] = UDim2.new(1, -12, 0.5, 0),
		["Size"] = UDim2.fromOffset(v_u_18.X, v_u_18.Y)
	}
	local v367 = v_u_1.new("Frame")
	local v368 = {}
	for v369, v370 in v366 do
		v367[v369] = v370
	end
	v367.Parent = p365
	v368.root = v367
	local v371 = v_u_1.new("UIScale")
	for v372, v373 in {} do
		v371[v372] = v373
	end
	v371.Parent = v367
	v368.scale = v371
	v_u_357(v367)
	v_u_364(v367)
	local v374 = {
		["Name"] = "Close",
		["Text"] = "",
		["AutoButtonColor"] = true,
		["BackgroundColor3"] = nil,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 5,
		["BackgroundColor3"] = Color3.fromRGB(22, 24, 32),
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromOffset(1764 - v_u_17.X, 108 - v_u_17.Y),
		["Size"] = UDim2.fromOffset(52, 52)
	}
	local v375 = v_u_1.new("TextButton")
	for v376, v377 in v374 do
		v375[v376] = v377
	end
	v375.Parent = v367
	v_u_66(v375, "round")
	v_u_74(v375, v_u_33, 2)
	local v378 = v_u_11.make("close", v_u_34, 24)
	v378.AnchorPoint = Vector2.new(0.5, 0.5)
	v378.Position = UDim2.fromScale(0.5, 0.5)
	v378.Parent = v375
	v375.Activated:Connect(function()
		-- upvalues: (ref) v_u_58
		if v_u_58 and v_u_58.onClose then
			v_u_58.onClose()
		end
	end)
	local v379 = v_u_140(v367, v_u_25, v_u_9.GRAD.gold[1], v_u_9.GRAD.gold[2], nil, nil, 35)
	v_u_112(v379, "code", Vector2.new(v_u_25[1], v_u_25[2]), {
		["Color"] = v_u_9.DARK_TEXT
	})
	v_u_113(v367, v_u_26, nil, Vector2.new(2, 2))
	local v380 = v_u_26
	local v381 = nil or v_u_17
	local v382 = {
		["Name"] = "Power",
		["BackgroundColor3"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = v_u_33,
		["Position"] = UDim2.fromOffset(v380[1] - v381.X, v380[2] - v381.Y),
		["Size"] = UDim2.fromOffset(v380[3] - v380[1], v380[4] - v380[2])
	}
	local v383 = v_u_1.new("Frame")
	for v384, v385 in v382 do
		v383[v384] = v385
	end
	v383.Parent = v367
	v_u_66(v383, 9)
	local v386 = v_u_9.LCD
	local v387 = v_u_9.CARD_DARK
	local v388 = {
		["Color"] = nil,
		["Rotation"] = 20,
		["Color"] = ColorSequence.new(v386, v387)
	}
	local v389 = v_u_1.new("UIGradient")
	for v390, v391 in v388 do
		v389[v390] = v391
	end
	v389.Parent = v383
	v_u_74(v383, v_u_33, 1).Transparency = 0.82
	local v392 = Vector2.new(v_u_26[1], v_u_26[2])
	v_u_112(v383, "power", v392)
	v368.gain = v_u_87(v383, "", v_u_55, 31, v_u_38, {
		["Position"] = UDim2.fromOffset(1380 - v392.X, 189 - v392.Y),
		["Size"] = UDim2.fromOffset(110, 30)
	})
	local v393 = {
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["Position"] = UDim2.fromOffset(1440 - v392.X, 165 - v392.Y),
		["Size"] = UDim2.fromOffset(275, 24)
	}
	local v394 = v_u_1.new("Frame")
	for v395, v396 in v393 do
		v394[v395] = v396
	end
	v394.Parent = v383
	local v397 = {
		["FillDirection"] = Enum.FillDirection.Horizontal,
		["HorizontalAlignment"] = Enum.HorizontalAlignment.Right,
		["VerticalAlignment"] = Enum.VerticalAlignment.Center,
		["SortOrder"] = Enum.SortOrder.LayoutOrder,
		["Padding"] = UDim.new(0, 5)
	}
	local v398 = v_u_1.new("UIListLayout")
	for v399, v400 in v397 do
		v398[v399] = v400
	end
	v398.Parent = v394
	local v401 = v_u_112(v394, "top_pre", Vector2.new(0, 0), {
		["LayoutOrder"] = 1
	})
	v368.top = v_u_87(v394, "", v_u_54, 18, v_u_34, {
		["LayoutOrder"] = 2,
		["AutomaticSize"] = nil,
		["Size"] = nil,
		["AutomaticSize"] = Enum.AutomaticSize.X,
		["Size"] = UDim2.fromOffset(0, 20)
	})
	for _, v402 in { v401, (v_u_112(v394, "top_post", Vector2.new(0, 0), {
			["LayoutOrder"] = 3
		})) } do
		v402.AnchorPoint = Vector2.zero
		v402.Position = UDim2.new()
	end
	v368.leds = {}
	for v403 = 1, 24 do
		local v404 = nil
		for _, v405 in v_u_51 do
			if v403 > v405[1] then
				continue
			end
			v404 = v405[2]
		end
		local v406 = {
			["BorderSizePixel"] = 0,
			["BackgroundColor3"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = v404,
			["Position"] = UDim2.new(((v403 - 1) * 9.74 + 1481 - v392.X) / (v_u_26[3] - v_u_26[1]), 0, 0, 192 - v392.Y),
			["Size"] = UDim2.fromOffset(7, 22)
		}
		local v407 = v_u_1.new("Frame")
		for v408, v409 in v406 do
			v407[v408] = v409
		end
		v407.Parent = v383
		v_u_66(v407, "round")
		v368.leds[v403] = v407
	end
	v368.maps = {}
	for v410, v_u_411 in v_u_8.TABLES do
		local v412 = v_u_22[v410]
		local v413 = {
			202,
			v412,
			581,
			v412 + 92
		}
		v_u_113(v367, v413)
		local v414 = nil or v_u_17
		local v415 = UDim2.fromOffset(v413[1] - v414.X, v413[2] - v414.Y)
		local v416 = UDim2.fromOffset(v413[3] - v413[1], v413[4] - v413[2])
		local v417 = {
			["Name"] = nil,
			["Text"] = "",
			["AutoButtonColor"] = false,
			["BackgroundColor3"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Name"] = v_u_411.key,
			["BackgroundColor3"] = v_u_33,
			["Position"] = v415,
			["Size"] = v416
		}
		local v418 = v_u_1.new("TextButton")
		for v419, v420 in v417 do
			v418[v419] = v420
		end
		v418.Parent = v367
		v_u_66(v418, 10)
		local v421 = v_u_42
		local v422 = v_u_43
		local v423 = {
			["Color"] = nil,
			["Rotation"] = -6,
			["Color"] = ColorSequence.new(v421, v422)
		}
		local v424 = v_u_1.new("UIGradient")
		for v425, v426 in v423 do
			v424[v425] = v426
		end
		v424.Parent = v418
		local v427 = v_u_74(v418, v_u_33, 3)
		v427.Name = "Stroke"
		local v428 = Vector2.new(202, v412)
		local v429 = {
			["BackgroundColor3"] = v_u_33,
			["Position"] = UDim2.fromOffset(20, 14),
			["Size"] = UDim2.fromOffset(85, 64)
		}
		local v430 = v_u_1.new("Frame")
		for v431, v432 in v429 do
			v430[v431] = v432
		end
		v430.Parent = v418
		v_u_66(v430, 10)
		local v433 = (v_u_46[v_u_411.key] or { v_u_44 })[1]
		local v434 = (v_u_46[v_u_411.key] or { 0, v_u_45 })[2]
		local v435 = {
			["Color"] = nil,
			["Rotation"] = -6,
			["Color"] = ColorSequence.new(v433, v434)
		}
		local v436 = v_u_1.new("UIGradient")
		for v437, v438 in v435 do
			v436[v437] = v438
		end
		v436.Parent = v430
		v_u_74(v430, v_u_33, 1).Transparency = 0.7
		v_u_112(v430, "chip_" .. v_u_411.key, v428 + Vector2.new(20, 17), {
			["Color"] = v_u_9.DARK_TEXT
		}, v_u_411.key)
		v_u_112(v418, "name_" .. v_u_411.key, v428, nil, v_u_411.key)
		local v439 = v_u_87(v418, "", v_u_54, 20, v_u_34, {
			["Name"] = "Pct",
			["TextXAlignment"] = nil,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["TextXAlignment"] = Enum.TextXAlignment.Right,
			["AnchorPoint"] = Vector2.new(1, 0.5),
			["Position"] = UDim2.fromOffset(355, 43),
			["Size"] = UDim2.fromOffset(110, 22)
		})
		local v440 = {
			["Name"] = "Bar",
			["BorderSizePixel"] = 0,
			["BackgroundColor3"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_33,
			["Position"] = UDim2.fromOffset(120, 66),
			["Size"] = UDim2.fromOffset(237, 12)
		}
		local v441 = v_u_1.new("Frame")
		for v442, v443 in v440 do
			v441[v442] = v443
		end
		v441.Parent = v418
		v_u_66(v441, "round")
		local v444 = {
			["Name"] = "Fill",
			["BorderSizePixel"] = 0,
			["Size"] = nil,
			["Size"] = UDim2.fromScale(0, 1)
		}
		local v445 = v_u_1.new("Frame")
		for v446, v447 in v444 do
			v445[v446] = v447
		end
		v445.Parent = v441
		v_u_66(v445, "round")
		v418.Activated:Connect(function()
			-- upvalues: (ref) v_u_58, (copy) v_u_411, (ref) v_u_155
			v_u_58.tab = v_u_411.key
			v_u_155()
		end)
		v368.maps[v_u_411.key] = {
			["Stroke"] = v427,
			["Pct"] = v439,
			["Fill"] = v445
		}
	end
	local v448 = v_u_23
	local v449 = nil or v_u_17
	local v450 = UDim2.fromOffset(v448[1] - v449.X, v448[2] - v449.Y)
	local v451 = UDim2.fromOffset(v448[3] - v448[1], v448[4] - v448[2])
	local v452 = {
		["Name"] = "Editor",
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["Position"] = v450,
		["Size"] = v451
	}
	local v453 = v_u_1.new("Frame")
	for v454, v455 in v452 do
		v453[v454] = v455
	end
	v453.Parent = v367
	v368.edit = v453
	local v456 = {
		["Name"] = "Veil",
		["Text"] = "",
		["AutoButtonColor"] = false,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.06,
		["Position"] = nil,
		["Size"] = nil,
		["ZIndex"] = 20,
		["Visible"] = false,
		["BackgroundColor3"] = v_u_9.CARD_DARK,
		["Position"] = v450,
		["Size"] = v451
	}
	local v457 = v_u_1.new("TextButton")
	for v458, v459 in v456 do
		v457[v458] = v459
	end
	v457.Parent = v367
	v_u_66(v457, 12)
	for v460 = 0, 39 do
		local v461 = v460 * 0.5
		local v462 = math.sin(v461) * 60 + 130 + v460 % 3 * 14
		local v463 = {
			["BorderSizePixel"] = 0,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.88,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = v_u_41,
			["AnchorPoint"] = Vector2.new(0, 1),
			["Position"] = UDim2.new(v460 / 40, 0, 1, -30),
			["Size"] = UDim2.new(0.025, 1, 0, v462)
		}
		local v464 = v_u_1.new("Frame")
		for v465, v466 in v463 do
			v464[v465] = v466
		end
		v464.Parent = v457
	end
	v_u_87(v457, "\224\185\131\224\184\138\224\185\137\224\184\132\224\185\136\224\184\178\224\184\130\224\184\173\224\184\135\224\184\132\224\184\153\224\184\173\224\184\183\224\185\136\224\184\153", v_u_56, 46, v_u_34, {
		["TextXAlignment"] = Enum.TextXAlignment.Center,
		["Position"] = UDim2.fromOffset(0, 36),
		["Size"] = UDim2.new(1, 0, 0, 56)
	})
	v368.veilSub = v_u_87(v457, "", v_u_56, 24, v_u_35, {
		["TextXAlignment"] = nil,
		["TextWrapped"] = true,
		["Position"] = nil,
		["Size"] = nil,
		["TextXAlignment"] = Enum.TextXAlignment.Center,
		["Position"] = UDim2.fromOffset(60, 96),
		["Size"] = UDim2.new(1, -120, 0, 64)
	})
	local v467 = {
		["Name"] = "TuneOwn",
		["Text"] = "",
		["AutoButtonColor"] = true,
		["BackgroundColor3"] = nil,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = v_u_33,
		["AnchorPoint"] = Vector2.new(0.5, 0),
		["Position"] = UDim2.new(0.5, 0, 0, 176),
		["Size"] = UDim2.fromOffset(460, 72)
	}
	local v468 = v_u_1.new("TextButton")
	for v469, v470 in v467 do
		v468[v469] = v470
	end
	v468.Parent = v457
	v_u_66(v468, 9)
	local v471 = v_u_53[1][2]
	local v472 = v_u_53[2][2]
	local v473 = {
		["Color"] = nil,
		["Rotation"] = 0,
		["Color"] = ColorSequence.new(v471, v472)
	}
	local v474 = v_u_1.new("UIGradient")
	for v475, v476 in v473 do
		v474[v475] = v476
	end
	v474.Parent = v468
	v_u_74(v468, v_u_33, 2)
	v_u_87(v468, "\224\184\136\224\184\185\224\184\153\224\185\128\224\184\173\224\184\135 (\224\185\128\224\184\163\224\184\180\224\185\136\224\184\161\224\184\136\224\184\178\224\184\129\224\184\132\224\185\136\224\184\178\224\185\130\224\184\163\224\184\135\224\184\135\224\184\178\224\184\153)", v_u_56, 26, v_u_34, {
		["TextXAlignment"] = Enum.TextXAlignment.Center,
		["Size"] = UDim2.fromScale(1, 1)
	})
	v468.Activated:Connect(v_u_341)
	v368.veil = v457
	local v477 = v_u_12.SoundRows
	local v478 = {
		["Name"] = "VeilSound",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v479 = v_u_1.new("Frame")
	for v480, v481 in v478 do
		v479[v480] = v481
	end
	v479.Parent = v457
	v368.veilRows = v477(v479, v_u_227)
	v_u_140(v367, v_u_29, Color3.fromRGB(70, 74, 92), Color3.fromRGB(42, 44, 56), "prev", function()
		-- upvalues: (ref) v_u_58, (ref) v_u_8, (ref) v_u_155
		local v482 = v_u_58
		local v483 = v_u_58.pick + -1
		local v484 = v_u_8.POINTS
		v482.pick = math.clamp(v483, 1, v484)
		v_u_155()
	end, 35).Name = "Prev"
	v368.nudges = {}
	for v485, v_u_486 in v_u_28 do
		local v487 = v_u_27[v485]
		local v488 = v_u_140
		local v489 = v487[1]
		local v490 = v_u_53[1]
		local v491 = v_u_53[2]
		local v492 = v490[2]
		local v493 = v491[2]
		local v494 = (v489 - v490[1]) / (v491[1] - v490[1])
		local v495 = v492:Lerp(v493, (math.clamp(v494, 0, 1)))
		local v496 = v487[3]
		local v497 = v_u_53[1]
		local v498 = v_u_53[2]
		local v499 = v497[2]
		local v500 = v498[2]
		local v501 = (v496 - v497[1]) / (v498[1] - v497[1])
		local v502, v503 = v488(v367, v487, v495, v499:Lerp(v500, (math.clamp(v501, 0, 1))), "", function()
			-- upvalues: (ref) v_u_260, (copy) v_u_486
			v_u_260(v_u_486)
		end)
		v502.Name = "Nudge" .. v485
		v503.FontFace = v_u_54
		v503.TextSize = 25
		v368.nudges[v485] = {
			["label"] = v503,
			["steps"] = v_u_486
		}
	end
	v_u_140(v367, v_u_30, Color3.fromRGB(70, 74, 92), Color3.fromRGB(42, 44, 56), "next", function()
		-- upvalues: (ref) v_u_58, (ref) v_u_8, (ref) v_u_155
		local v504 = v_u_58
		local v505 = v_u_58.pick + 1
		local v506 = v_u_8.POINTS
		v504.pick = math.clamp(v505, 1, v506)
		v_u_155()
	end, 35).Name = "Next"
	local v507 = v_u_140
	local v508 = v_u_31.smooth
	local v509 = v_u_31.smooth[1]
	local v510 = v_u_53[1]
	local v511 = v_u_53[2]
	local v512 = v510[2]
	local v513 = v511[2]
	local v514 = (v509 - v510[1]) / (v511[1] - v510[1])
	local v515 = v512:Lerp(v513, (math.clamp(v514, 0, 1)))
	local v516 = v_u_31.smooth[3]
	local v517 = v_u_53[1]
	local v518 = v_u_53[2]
	local v519 = v517[2]
	local v520 = v518[2]
	local v521 = (v516 - v517[1]) / (v518[1] - v517[1])
	v507(v367, v508, v515, v519:Lerp(v520, (math.clamp(v521, 0, 1))), "smooth", v_u_275)
	local v522 = v_u_140
	local v523 = v_u_31.raise
	local v524 = v_u_31.raise[1]
	local v525 = v_u_53[1]
	local v526 = v_u_53[2]
	local v527 = v525[2]
	local v528 = v526[2]
	local v529 = (v524 - v525[1]) / (v526[1] - v525[1])
	local v530 = v527:Lerp(v528, (math.clamp(v529, 0, 1)))
	local v531 = v_u_31.raise[3]
	local v532 = v_u_53[1]
	local v533 = v_u_53[2]
	local v534 = v532[2]
	local v535 = v533[2]
	local v536 = (v531 - v532[1]) / (v533[1] - v532[1])
	v522(v367, v523, v530, v534:Lerp(v535, (math.clamp(v536, 0, 1))), "raise", function()
		-- upvalues: (ref) v_u_246
		v_u_246(1)
	end)
	local v537 = v_u_140
	local v538 = v_u_31.lower
	local v539 = v_u_31.lower[1]
	local v540 = v_u_53[1]
	local v541 = v_u_53[2]
	local v542 = v540[2]
	local v543 = v541[2]
	local v544 = (v539 - v540[1]) / (v541[1] - v540[1])
	local v545 = v542:Lerp(v543, (math.clamp(v544, 0, 1)))
	local v546 = v_u_31.lower[3]
	local v547 = v_u_53[1]
	local v548 = v_u_53[2]
	local v549 = v547[2]
	local v550 = v548[2]
	local v551 = (v546 - v547[1]) / (v548[1] - v547[1])
	v537(v367, v538, v545, v549:Lerp(v550, (math.clamp(v551, 0, 1))), "lower", function()
		-- upvalues: (ref) v_u_246
		v_u_246(-1)
	end)
	local v552 = v_u_140
	local v553 = v_u_31.factory
	local v554 = v_u_31.factory[1]
	local v555 = v_u_53[1]
	local v556 = v_u_53[2]
	local v557 = v555[2]
	local v558 = v556[2]
	local v559 = (v554 - v555[1]) / (v556[1] - v555[1])
	local v560 = v557:Lerp(v558, (math.clamp(v559, 0, 1)))
	local v561 = v_u_31.factory[3]
	local v562 = v_u_53[1]
	local v563 = v_u_53[2]
	local v564 = v562[2]
	local v565 = v563[2]
	local v566 = (v561 - v562[1]) / (v563[1] - v562[1])
	v552(v367, v553, v560, v564:Lerp(v565, (math.clamp(v566, 0, 1))), "factory", v_u_277)
	local v567, v568 = v_u_140(v367, v_u_32, v_u_47, v_u_48, "tune", v_u_309, 30)
	v567.Name = "Tune"
	v368.tuneGrad = v567:FindFirstChildOfClass("UIGradient")
	v368.tuneLabel = v568
	v568.ZIndex = 3
	local v569 = {
		["Name"] = "Progress",
		["BorderSizePixel"] = 0,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.55,
		["Size"] = nil,
		["Visible"] = false,
		["ZIndex"] = 2,
		["BackgroundColor3"] = v_u_33,
		["Size"] = UDim2.fromScale(0, 1)
	}
	local v570 = v_u_1.new("Frame")
	for v571, v572 in v569 do
		v570[v571] = v572
	end
	v570.Parent = v567
	v368.progress = v570
	v_u_66(v368.progress, 9)
	local v573 = {
		["Name"] = "CodeBox",
		["Text"] = "",
		["AutoButtonColor"] = false,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.35,
		["Size"] = nil,
		["ZIndex"] = 40,
		["Visible"] = false,
		["BackgroundColor3"] = Color3.new(0, 0, 0),
		["Size"] = UDim2.fromScale(1, 1)
	}
	local v_u_574 = v_u_1.new("TextButton")
	for v575, v576 in v573 do
		v_u_574[v575] = v576
	end
	v_u_574.Parent = v367
	v_u_66(v_u_574, 12)
	local v577 = {
		["BackgroundColor3"] = v_u_33,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromScale(0.5, 0.5),
		["Size"] = UDim2.fromOffset(480, 318)
	}
	local v578 = v_u_1.new("Frame")
	for v579, v580 in v577 do
		v578[v579] = v580
	end
	v578.Parent = v_u_574
	local v581 = v_u_1.new("UIScale")
	for v582, v583 in {
		["Scale"] = 1.9
	} do
		v581[v582] = v583
	end
	v581.Parent = v578
	v_u_66(v578, 10)
	local v584 = v_u_9.PANEL
	local v585 = v_u_9.CARD_DARK
	local v586 = {
		["Color"] = nil,
		["Rotation"] = 90,
		["Color"] = ColorSequence.new(v584, v585)
	}
	local v587 = v_u_1.new("UIGradient")
	for v588, v589 in v586 do
		v587[v588] = v589
	end
	v587.Parent = v578
	local v590 = {
		["Color"] = nil,
		["Thickness"] = 1.5,
		["Color"] = v_u_41
	}
	local v591 = v_u_1.new("UIStroke")
	for v592, v593 in v590 do
		v591[v592] = v593
	end
	v591.Parent = v578
	v_u_87(v578, "\224\185\130\224\184\132\224\185\137\224\184\148\224\184\170\224\184\185\224\184\149\224\184\163\224\184\136\224\184\185\224\184\153", v_u_56, 22, v_u_34, {
		["Position"] = UDim2.fromOffset(20, 14),
		["Size"] = UDim2.fromOffset(300, 28)
	})
	local v594 = {
		["Text"] = "",
		["AutoButtonColor"] = true,
		["BackgroundColor3"] = nil,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = Color3.fromRGB(22, 24, 32),
		["AnchorPoint"] = Vector2.new(1, 0),
		["Position"] = UDim2.new(1, -14, 0, 12),
		["Size"] = UDim2.fromOffset(36, 36)
	}
	local v595 = v_u_1.new("TextButton")
	for v596, v597 in v594 do
		v595[v596] = v597
	end
	v595.Parent = v578
	v_u_66(v595, "round")
	local v598 = {
		["Color"] = nil,
		["Thickness"] = 1.5,
		["ApplyStrokeMode"] = nil,
		["Color"] = v_u_33,
		["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border
	}
	local v599 = v_u_1.new("UIStroke")
	for v600, v601 in v598 do
		v599[v600] = v601
	end
	v599.Parent = v595
	local v602 = v_u_11.make("close", v_u_34, 18)
	v602.AnchorPoint = Vector2.new(0.5, 0.5)
	v602.Position = UDim2.fromScale(0.5, 0.5)
	v602.Parent = v595
	v595.Activated:Connect(function()
		-- upvalues: (ref) v_u_58, (ref) v_u_311
		v_u_58.ui.codeBox.Visible = false
		v_u_311 = 0
	end)
	v_u_87(v578, "\224\185\131\224\184\170\224\185\136\224\185\130\224\184\132\224\185\137\224\184\148\224\184\136\224\184\178\224\184\129\224\184\132\224\184\153\224\184\173\224\184\183\224\185\136\224\184\153", v_u_56, 15, v_u_39, {
		["Position"] = UDim2.fromOffset(20, 54),
		["Size"] = UDim2.fromOffset(300, 20)
	})
	local v603 = {
		["Text"] = "",
		["PlaceholderText"] = "ABCD-EFGH",
		["ClearTextOnFocus"] = false,
		["FontFace"] = nil,
		["TextSize"] = 22,
		["TextColor3"] = nil,
		["PlaceholderColor3"] = nil,
		["BackgroundColor3"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["FontFace"] = v_u_9.FONT_DIGITS,
		["TextColor3"] = v_u_34,
		["PlaceholderColor3"] = v_u_35,
		["BackgroundColor3"] = Color3.fromRGB(10, 4, 1),
		["Position"] = UDim2.fromOffset(20, 78),
		["Size"] = UDim2.fromOffset(300, 46)
	}
	local v604 = v_u_1.new("TextBox")
	for v605, v606 in v603 do
		v604[v605] = v606
	end
	v604.Parent = v578
	v368.codeInput = v604
	v_u_66(v368.codeInput, 8)
	local v607 = {
		["Color"] = nil,
		["Transparency"] = 0.7,
		["ApplyStrokeMode"] = nil,
		["Color"] = v_u_33,
		["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border
	}
	local v608 = v368.codeInput
	local v609 = v_u_1.new("UIStroke")
	for v610, v611 in v607 do
		v609[v610] = v611
	end
	v609.Parent = v608
	v_u_9.button({
		["name"] = "UseCode",
		["text"] = "\224\185\131\224\184\138\224\185\137\224\185\130\224\184\132\224\185\137\224\184\148",
		["grad"] = "teal",
		["textSize"] = 16,
		["position"] = nil,
		["size"] = nil,
		["parent"] = nil,
		["radius"] = 8,
		["position"] = UDim2.fromOffset(330, 78),
		["size"] = UDim2.fromOffset(130, 46),
		["parent"] = v578
	}).Activated:Connect(v_u_331)
	v_u_87(v578, "\224\185\131\224\184\138\224\185\137\224\185\132\224\184\148\224\185\137\224\184\132\224\184\163\224\184\177\224\185\137\224\184\135\224\185\128\224\184\148\224\184\181\224\184\162\224\184\167 \194\183 \224\184\163\224\184\150\224\184\163\224\184\184\224\185\136\224\184\153\224\185\128\224\184\148\224\184\181\224\184\162\224\184\167\224\184\129\224\184\177\224\184\153\224\185\128\224\184\151\224\185\136\224\184\178\224\184\153\224\184\177\224\185\137\224\184\153 \194\183 \224\185\131\224\184\138\224\185\137\224\185\129\224\184\151\224\184\153\224\184\136\224\184\185\224\184\153\224\185\128\224\184\148\224\184\180\224\184\161\224\184\130\224\184\173\224\184\135\224\184\132\224\184\177\224\184\153\224\184\153\224\184\181\224\185\137 \224\185\129\224\184\165\224\184\176\224\184\136\224\184\176\224\184\161\224\184\173\224\184\135\224\185\132\224\184\161\224\185\136\224\185\128\224\184\171\224\185\135\224\184\153\224\184\132\224\185\136\224\184\178", v_u_56, 12, v_u_35, {
		["Position"] = nil,
		["Size"] = nil,
		["TextWrapped"] = true,
		["TextYAlignment"] = nil,
		["Position"] = UDim2.fromOffset(20, 130),
		["Size"] = UDim2.fromOffset(440, 32),
		["TextYAlignment"] = Enum.TextYAlignment.Top
	})
	local v612 = {
		["BorderSizePixel"] = 0,
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.85,
		["Position"] = nil,
		["Size"] = nil,
		["BackgroundColor3"] = v_u_33,
		["Position"] = UDim2.fromOffset(20, 170),
		["Size"] = UDim2.fromOffset(440, 1)
	}
	local v613 = v_u_1.new("Frame")
	for v614, v615 in v612 do
		v613[v614] = v615
	end
	v613.Parent = v578
	v_u_87(v578, "\224\185\129\224\184\138\224\184\163\224\185\140\224\184\136\224\184\185\224\184\153\224\184\132\224\184\177\224\184\153\224\184\153\224\184\181\224\185\137\224\185\131\224\184\171\224\185\137\224\184\132\224\184\153\224\184\173\224\184\183\224\185\136\224\184\153", v_u_56, 15, v_u_39, {
		["Position"] = UDim2.fromOffset(20, 184),
		["Size"] = UDim2.fromOffset(300, 20)
	})
	v368.shareBtn = v_u_9.button({
		["name"] = "ShareCode",
		["text"] = "",
		["grad"] = "gold",
		["textSize"] = 15,
		["position"] = nil,
		["size"] = nil,
		["parent"] = nil,
		["radius"] = 8,
		["position"] = UDim2.fromOffset(20, 208),
		["size"] = UDim2.fromOffset(230, 46),
		["parent"] = v578
	})
	v368.shareBtn.Activated:Connect(v_u_340)
	local v616 = {
		["Text"] = "\226\128\148",
		["TextEditable"] = false,
		["ClearTextOnFocus"] = false,
		["FontFace"] = nil,
		["TextSize"] = 24,
		["TextColor3"] = nil,
		["BackgroundColor3"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["FontFace"] = v_u_9.FONT_DIGITS,
		["TextColor3"] = v_u_36,
		["BackgroundColor3"] = Color3.fromRGB(10, 4, 1),
		["Position"] = UDim2.fromOffset(260, 208),
		["Size"] = UDim2.fromOffset(200, 46)
	}
	local v617 = v_u_1.new("TextBox")
	for v618, v619 in v616 do
		v617[v618] = v619
	end
	v617.Parent = v578
	v368.codeOut = v617
	v_u_66(v368.codeOut, 8)
	v368.shareNote = v_u_87(v578, "", v_u_56, 12, v_u_35, {
		["Position"] = nil,
		["Size"] = nil,
		["TextWrapped"] = true,
		["TextYAlignment"] = nil,
		["Position"] = UDim2.fromOffset(20, 262),
		["Size"] = UDim2.fromOffset(440, 40),
		["TextYAlignment"] = Enum.TextYAlignment.Top
	})
	v368.codeBox = v_u_574
	v379.Activated:Connect(function()
		-- upvalues: (copy) v_u_574, (ref) v_u_58, (ref) v_u_311, (ref) v_u_317
		local v620 = not v_u_574.Visible
		v_u_58.ui.codeBox.Visible = v620
		v_u_311 = 0
		if v620 then
			v_u_317()
		end
	end)
	return v368
end
local function v_u_623() -- name: rescale
	-- upvalues: (ref) v_u_58
	local v622 = v_u_58
	if v622 then
		v622 = v_u_58.ui.editor
	end
	if v622 and v622.rescale then
		v622.rescale()
	end
end
local function v_u_637(p624) -- name: fitScale
	-- upvalues: (copy) v_u_9, (copy) v_u_3, (copy) v_u_18
	local v625 = p624.AbsoluteSize
	if v625.X < 1 or v625.Y < 1 then
		return 0.55
	else
		local v626 = workspace.CurrentCamera
		local v627 = v_u_9.scaleFor
		local v628
		if v626 then
			v628 = v626.ViewportSize
		else
			v628 = v625
		end
		local v629 = v627(v628) * 0.55
		local v630 = require(script.Parent:WaitForChild("TuneDock"))
		local v631 = v_u_3.LocalPlayer.PlayerGui:FindFirstChild("TuneHub")
		local v632
		if v630.ecu and (v631 and v631.Enabled) then
			v632 = v630.ecu
		else
			v632 = nil
		end
		if v632 then
			local v633 = v632.w / v_u_18.X
			local v634 = v632.h / v_u_18.Y
			return math.min(v633, v634) * 0.98
		else
			local v635 = (v625.X - 24) / v_u_18.X
			local v636 = v625.Y * 0.94 / v_u_18.Y
			return math.min(v629, v635, v636)
		end
	end
end
local v_u_638 = nil
local v_u_639 = nil
local v_u_640 = nil
local v_u_641 = 0
local v_u_642 = false
v_u_156 = function() -- name: drawSoon
	-- upvalues: (ref) v_u_642, (ref) v_u_641, (ref) v_u_155, (ref) v_u_58
	if v_u_642 then
		return
	else
		local v643 = 0.03333333333333333 - (os.clock() - v_u_641)
		if v643 <= 0 then
			v_u_641 = os.clock()
			v_u_155()
		else
			v_u_642 = true
			task.delay(v643, function()
				-- upvalues: (ref) v_u_642, (ref) v_u_58, (ref) v_u_641, (ref) v_u_155
				v_u_642 = false
				if v_u_58 then
					v_u_641 = os.clock()
					v_u_155()
				end
			end)
		end
	end
end
local v_u_644 = nil
function v_u_57.open(p645, p646, p647) -- name: open
	-- upvalues: (copy) v_u_57, (ref) v_u_644, (copy) v_u_4, (copy) v_u_7, (copy) v_u_8, (copy) v_u_2, (ref) v_u_58, (copy) v_u_145, (copy) v_u_3, (copy) v_u_1, (copy) v_u_621, (copy) v_u_637, (copy) v_u_5, (copy) v_u_623, (ref) v_u_640, (ref) v_u_155, (ref) v_u_638, (copy) v_u_6, (ref) v_u_639
	v_u_57.close()
	local v648 = {}
	v_u_644 = v648
	local v649 = v_u_4:WaitForChild(v_u_7.REMOTES):WaitForChild(v_u_8.REMOTE)
	local v650 = v_u_2.invoke
	local v651, v652 = pcall(v650, v649, "Get", p645)
	if v_u_644 == v648 then
		v_u_644 = nil
		local v653
		if v651 then
			v653 = v_u_8.clean(v652)
		else
			v653 = nil
		end
		local v654 = p645:GetAttribute("EcuBorrowed")
		local v655 = {
			["model"] = nil,
			["borrowed"] = nil,
			["veiled"] = nil,
			["file"] = nil,
			["sent"] = nil,
			["feedback"] = nil,
			["hints"] = nil,
			["sound"] = nil,
			["soundSent"] = nil,
			["tab"] = nil,
			["pick"] = 1,
			["stock"] = nil,
			["result"] = nil,
			["onClose"] = nil,
			["model"] = p645
		}
		local v656
		if type(v654) == "string" then
			v656 = v654
		else
			v656 = nil
		end
		v655.borrowed = v656
		v655.veiled = type(v654) == "string"
		v655.file = v_u_145(v653 or v_u_8.stockFile())
		if v653 then
			v653 = v_u_145(v653)
		end
		v655.sent = v653
		v655.feedback = v_u_8.decode(p645:GetAttribute("EcuFeedback"))
		v655.hints = v_u_8.decode(p645:GetAttribute("EcuHints"))
		v655.sound = {
			["Idle"] = v_u_8.soundSetting(p645, "Idle"),
			["Rev"] = v_u_8.soundSetting(p645, "Rev")
		}
		v655.soundSent = {
			["Idle"] = v_u_8.soundSetting(p645, "Idle"),
			["Rev"] = v_u_8.soundSetting(p645, "Rev")
		}
		v655.tab = v_u_8.TABLES[1].key
		v655.stock = v_u_8.stockFile()
		local v657
		if typeof(p645:GetAttribute("EcuGain")) == "number" then
			v657 = v_u_8.gain(p645)
		else
			v657 = nil
		end
		v655.result = v657
		v655.onClose = p647
		v_u_58 = v655
		local v658 = not (p646 and p646:IsA("ScreenGui")) and 7 or p646.DisplayOrder + 1
		local v659 = v_u_58
		local v660 = {
			["Name"] = "EcuTune",
			["ResetOnSpawn"] = false,
			["IgnoreGuiInset"] = true,
			["ZIndexBehavior"] = nil,
			["DisplayOrder"] = nil,
			["ZIndexBehavior"] = Enum.ZIndexBehavior.Sibling,
			["DisplayOrder"] = v658
		}
		local v661 = v_u_3.LocalPlayer:WaitForChild("PlayerGui")
		local v662 = v_u_1.new("ScreenGui")
		for v663, v664 in v660 do
			v662[v663] = v664
		end
		v662.Parent = v661
		v659.gui = v662
		v_u_58.ui = v_u_621(v_u_58.gui)
		local v665 = require(script.Parent:WaitForChild("TuneDock"))
		local v666 = v_u_3.LocalPlayer.PlayerGui:FindFirstChild("TuneHub")
		local v667
		if v665.ecu and (v666 and v666.Enabled) then
			v667 = v665.ecu
		else
			v667 = nil
		end
		if v667 then
			if v667.insets then
				v_u_58.gui.ScreenInsets = v667.insets
			end
			v_u_58.ui.root.AnchorPoint = Vector2.new(0.5, 0.5)
			v_u_58.ui.root.Position = UDim2.fromOffset(v667.x + v667.w / 2, v667.y + v667.h / 2)
		end
		local v668 = v_u_637(v_u_58.gui)
		v_u_58.ui.scale.Scale = v668 * 0.94
		local v_u_669 = v_u_5:Create(v_u_58.ui.scale, TweenInfo.new(0.22, Enum.EasingStyle.Back), {
			["Scale"] = v668
		})
		v_u_669:Play()
		v_u_58.ui.scale:GetPropertyChangedSignal("Scale"):Connect(v_u_623)
		v_u_640 = v_u_58.gui:GetPropertyChangedSignal("AbsoluteSize"):Connect(function()
			-- upvalues: (ref) v_u_58, (copy) v_u_669, (ref) v_u_637
			if v_u_58 then
				v_u_669:Cancel()
				v_u_58.ui.scale.Scale = v_u_637(v_u_58.gui)
			end
		end)
		v_u_155()
		v_u_638 = v_u_6.InputChanged:Connect(function(p670)
			-- upvalues: (ref) v_u_58, (ref) v_u_6
			if v_u_58 and v_u_58.drag then
				if p670.UserInputType == Enum.UserInputType.MouseMovement and not v_u_6:IsMouseButtonPressed(Enum.UserInputType.MouseButton1) then
					local v671 = v_u_58
					v_u_58.drag = nil
					v671.dragEnd = nil
				elseif p670.UserInputType == Enum.UserInputType.MouseMovement or p670.UserInputType == Enum.UserInputType.Touch then
					v_u_58.drag(p670.Position)
				end
			else
				return
			end
		end)
		v_u_639 = v_u_6.InputEnded:Connect(function(p672)
			-- upvalues: (ref) v_u_58
			if v_u_58 and (p672.UserInputType == Enum.UserInputType.MouseButton1 or p672.UserInputType == Enum.UserInputType.Touch) then
				local v673 = v_u_58.dragEnd
				local v674 = v_u_58
				v_u_58.drag = nil
				v674.dragEnd = nil
				if v673 then
					v673()
				end
			end
		end)
	end
end
function v_u_57.close() -- name: close
	-- upvalues: (ref) v_u_644, (ref) v_u_638, (ref) v_u_639, (ref) v_u_640, (ref) v_u_58, (copy) v_u_8
	v_u_644 = nil
	if v_u_638 then
		v_u_638:Disconnect()
		v_u_639:Disconnect()
		v_u_638 = nil
		v_u_639 = nil
	end
	if v_u_640 then
		v_u_640:Disconnect()
		v_u_640 = nil
	end
	if v_u_58 then
		if v_u_58.ui and v_u_58.ui.editor then
			v_u_58.ui.editor.destroy()
		end
		for v675, v682 in v_u_58.soundSent do
			local v677 = (v_u_58.sound[v675] or 1) - v682
			if math.abs(v677) <= 1e-6 then
				continue
			end
			local v678 = v_u_8.SOUND_SETTINGS[v675]
			local v679 = v_u_58.model
			local v680 = v678.attribute
			local v681 = v682 - 1
			if math.abs(v681) < 1e-6 then
				local v682 = nil
			end
			v679:SetAttribute(v680, v682)
		end
		v_u_58.gui:Destroy()
		v_u_58 = nil
	end
end
function v_u_57.isOpen() -- name: isOpen
	-- upvalues: (ref) v_u_58, (ref) v_u_644
	return v_u_58 ~= nil and true or v_u_644 ~= nil
end
return v_u_57