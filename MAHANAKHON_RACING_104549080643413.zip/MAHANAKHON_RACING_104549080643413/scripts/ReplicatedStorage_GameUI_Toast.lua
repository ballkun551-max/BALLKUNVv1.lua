-- Path: ReplicatedStorage/GameUI/Toast
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("TweenService")
local v_u_3 = require(script.Parent:WaitForChild("Theme"))
local v_u_4 = require(script.Parent:WaitForChild("Icons"))
local v_u_5 = {
	["ok"] = {
		["grad"] = "green",
		["icon"] = "check"
	},
	["error"] = {
		["grad"] = "red",
		["icon"] = "close"
	},
	["info"] = {
		["grad"] = "blue",
		["icon"] = "bulb"
	}
}
local v_u_6 = TweenInfo.new(0.28, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
local v_u_7 = TweenInfo.new(0.2, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
local v8 = {}
local v_u_9 = nil
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v_u_13 = nil
local v_u_14 = nil
local v_u_15 = nil
local v_u_16 = nil
local v_u_17 = 0
local v_u_18 = false
local v_u_19 = 0
local function v_u_45() -- name: build
	-- upvalues: (ref) v_u_9, (copy) v_u_3, (copy) v_u_1, (ref) v_u_18, (ref) v_u_10, (ref) v_u_16, (ref) v_u_19, (ref) v_u_11, (ref) v_u_12, (ref) v_u_13, (ref) v_u_15
	v_u_9 = v_u_3.screen("GameToast", 70, v_u_1.LocalPlayer:WaitForChild("PlayerGui"))
	v_u_18 = true
	local v20 = v_u_3.isTouch()
	local v21 = v_u_3.new
	local v22 = "Frame"
	local v23 = {
		["Name"] = "Holder",
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil
	}
	local v24
	if v_u_18 then
		v24 = Vector2.new(1, 0)
	else
		v24 = Vector2.new(0.5, 0)
	end
	v23.AnchorPoint = v24
	local v25
	if v20 then
		v25 = UDim2.new(1, -12, 0.3, 0)
	else
		v25 = UDim2.new(1, -v_u_3.EDGE, 0.24, 0)
	end
	v23.Position = v25
	v23.Size = UDim2.fromOffset(10, 48)
	v23.Parent = v_u_9
	v_u_10 = v21(v22, v23)
	v_u_3.autoScale(v_u_10, v_u_3.PHONE_SHRINK)
	local v26 = v_u_3.new
	local v27 = "CanvasGroup"
	local v28 = {
		["Name"] = "Fade",
		["BackgroundTransparency"] = 1,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["Visible"] = false,
		["Parent"] = nil
	}
	local v29
	if v_u_18 then
		v29 = Vector2.new(1, 0)
	else
		v29 = Vector2.new(0.5, 0)
	end
	v28.AnchorPoint = v29
	local v30
	if v_u_18 then
		v30 = UDim2.fromScale(1, 0)
	else
		v30 = UDim2.fromScale(0.5, 0)
	end
	v28.Position = v30
	v28.Size = UDim2.fromOffset(0, 48)
	local v31
	if v_u_18 then
		v31 = Enum.AutomaticSize.XY
	else
		v31 = Enum.AutomaticSize.X
	end
	v28.AutomaticSize = v31
	v28.Parent = v_u_10
	v_u_16 = v26(v27, v28)
	v_u_3.padding(v_u_16, 2)
	v_u_19 = v20 and 300 or 400
	local v32 = v_u_3.panel
	local v33 = {
		["Name"] = "Toast",
		["Size"] = nil,
		["Position"] = nil,
		["AutomaticSize"] = nil,
		["Parent"] = nil
	}
	local v34
	if v_u_18 then
		v34 = UDim2.fromOffset(v_u_19, 44)
	else
		v34 = UDim2.fromOffset(0, 44)
	end
	v33.Size = v34
	v33.Position = UDim2.fromOffset(0, 0)
	local v35
	if v_u_18 then
		v35 = Enum.AutomaticSize.None
	else
		v35 = Enum.AutomaticSize.X
	end
	v33.AutomaticSize = v35
	v33.Parent = v_u_16
	v_u_11 = v32(v33)
	v_u_11.UICorner.CornerRadius = UDim.new(0, v_u_18 and 14 or 22)
	v_u_3.new("UIPadding", {
		["PaddingLeft"] = UDim.new(0, 6),
		["PaddingRight"] = UDim.new(0, v_u_18 and 14 or 18),
		["PaddingTop"] = UDim.new(0, v_u_18 and 6 or 0),
		["PaddingBottom"] = UDim.new(0, v_u_18 and 6 or 0),
		["Parent"] = v_u_11
	})
	v_u_3.new("UIListLayout", {
		["FillDirection"] = Enum.FillDirection.Horizontal,
		["VerticalAlignment"] = Enum.VerticalAlignment.Center,
		["Padding"] = UDim.new(0, 10),
		["SortOrder"] = Enum.SortOrder.LayoutOrder,
		["Parent"] = v_u_11
	})
	v_u_12 = v_u_3.new("Frame", {
		["Name"] = "Badge",
		["BackgroundColor3"] = nil,
		["Size"] = nil,
		["LayoutOrder"] = 1,
		["Parent"] = nil,
		["BackgroundColor3"] = Color3.new(1, 1, 1),
		["Size"] = UDim2.fromOffset(32, 32),
		["Parent"] = v_u_11
	})
	v_u_3.corner(v_u_12, 16)
	v_u_13 = v_u_3.gradient(v_u_12, "blue")
	v_u_15 = v_u_3.text({
		["Name"] = "Text",
		["Size"] = nil,
		["AutomaticSize"] = nil,
		["TextSize"] = 18,
		["FontFace"] = nil,
		["LayoutOrder"] = 2,
		["Parent"] = nil,
		["Size"] = UDim2.fromScale(0, 1),
		["AutomaticSize"] = Enum.AutomaticSize.X,
		["FontFace"] = v_u_3.FONT_BOLD,
		["Parent"] = v_u_11
	})
	if v_u_18 then
		v_u_15.AutomaticSize = Enum.AutomaticSize.Y
		v_u_15.Size = UDim2.fromOffset(v_u_19 - 6 - 32 - 10 - 14, 32)
		v_u_15.TextWrapped = true
		v_u_15.TextSize = v20 and 16 or 20
		v_u_15.TextXAlignment = Enum.TextXAlignment.Left
		local function v40() -- name: fitCard
			-- upvalues: (ref) v_u_11, (ref) v_u_19, (ref) v_u_15
			local v36 = v_u_11.AbsoluteSize.X <= 0 and 1 or v_u_11.AbsoluteSize.X / v_u_19
			local v37 = v_u_15.AbsoluteSize.Y / v36
			local v38 = math.ceil(v37)
			local v39 = math.max(32, v38)
			v_u_11.Size = UDim2.fromOffset(v_u_19, v39 + 12)
		end
		v_u_15:GetPropertyChangedSignal("AbsoluteSize"):Connect(v40)
		local v41 = v_u_11.AbsoluteSize.X <= 0 and 1 or v_u_11.AbsoluteSize.X / v_u_19
		local v42 = v_u_15.AbsoluteSize.Y / v41
		local v43 = math.ceil(v42)
		local v44 = math.max(32, v43)
		v_u_11.Size = UDim2.fromOffset(v_u_19, v44 + 12)
	end
end
function v8.show(p46, p47) -- name: show
	-- upvalues: (ref) v_u_9, (copy) v_u_45, (copy) v_u_5, (ref) v_u_15, (copy) v_u_3, (ref) v_u_13, (ref) v_u_14, (copy) v_u_4, (ref) v_u_12, (ref) v_u_16, (ref) v_u_18, (copy) v_u_2, (copy) v_u_6, (ref) v_u_17, (copy) v_u_7
	if not (v_u_9 and v_u_9.Parent) then
		v_u_45()
	end
	local v48 = v_u_5[p47] or v_u_5.info
	v_u_15.Text = p46
	local v49 = v_u_3.GRAD[v48.grad]
	v_u_13.Color = ColorSequence.new(v49[1], v49[2])
	if v_u_14 then
		v_u_14:Destroy()
	end
	v_u_14 = v_u_4.make(v48.icon, Color3.new(1, 1, 1), 20)
	v_u_14.AnchorPoint = Vector2.new(0.5, 0.5)
	v_u_14.Position = UDim2.fromScale(0.5, 0.5)
	v_u_14.Parent = v_u_12
	v_u_16.Visible = true
	v_u_16.GroupTransparency = 1
	local v50 = v_u_16
	local v51
	if v_u_18 then
		v51 = UDim2.fromScale(1, 0)
	else
		v51 = UDim2.fromScale(0.5, 0)
	end
	local v52
	if v_u_18 then
		v52 = UDim2.fromOffset(30, 0)
	else
		v52 = UDim2.fromOffset(0, -14)
	end
	v50.Position = v51 + v52
	local v53 = v_u_2
	local v54 = v_u_16
	local v55 = v_u_6
	local v56 = {
		["GroupTransparency"] = 0,
		["Position"] = nil
	}
	local v57
	if v_u_18 then
		v57 = UDim2.fromScale(1, 0)
	else
		v57 = UDim2.fromScale(0.5, 0)
	end
	v56.Position = v57
	v53:Create(v54, v55, v56):Play()
	local v_u_58 = os.clock()
	v_u_17 = v_u_58
	local v59 = 2.6 + (utf8.len(p46) or #p46) * 0.04
	local v60 = math.clamp(v59, 2.6, 7)
	task.delay(v60, function()
		-- upvalues: (ref) v_u_17, (copy) v_u_58, (ref) v_u_16, (ref) v_u_2, (ref) v_u_7, (ref) v_u_18
		if v_u_17 == v_u_58 and v_u_16 then
			local v61 = v_u_2
			local v62 = v_u_16
			local v63 = v_u_7
			local v64 = {
				["GroupTransparency"] = 1,
				["Position"] = nil
			}
			local v65
			if v_u_18 then
				v65 = UDim2.fromScale(1, 0)
			else
				v65 = UDim2.fromScale(0.5, 0)
			end
			local v66
			if v_u_18 then
				v66 = UDim2.fromOffset(24, 0)
			else
				v66 = UDim2.fromOffset(0, -10)
			end
			v64.Position = v65 + v66
			local v67 = v61:Create(v62, v63, v64)
			v67.Completed:Connect(function()
				-- upvalues: (ref) v_u_17, (ref) v_u_58, (ref) v_u_16
				if v_u_17 == v_u_58 then
					v_u_16.Visible = false
				end
			end)
			v67:Play()
		end
	end)
end
return v8