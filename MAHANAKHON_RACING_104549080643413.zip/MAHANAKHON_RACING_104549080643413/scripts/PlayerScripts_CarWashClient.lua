-- Path: Players/ygggggg55551/PlayerScripts/CarWashClient
-- Class: LocalScript  true/Enum.RunContext.Legacy
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = require(game:GetService("ReplicatedStorage"):WaitForChild("NetSeal"))
local v_u_2 = game:GetService("CollectionService")
local v_u_3 = game:GetService("ContextActionService")
local v_u_4 = game:GetService("Players")
game:GetService("ProximityPromptService")
local v5 = game:GetService("ReplicatedStorage")
local v6 = game:GetService("RunService")
local v_u_7 = game:GetService("TweenService")
local v_u_8 = game:GetService("UserInputService")
local v9 = require(v5:WaitForChild("GameShared"))
local v_u_10 = require(v5:WaitForChild("CarWashShared"))
local v_u_11 = v_u_10.TEXT
local v12 = v5:WaitForChild("GameUI")
local v_u_13 = require(v12:WaitForChild("Theme"))
local v_u_14 = require(v12:WaitForChild("Toast"))
local v_u_15 = v_u_4.LocalPlayer
local v16 = v5:WaitForChild(v9.REMOTES)
local v_u_17 = v16:WaitForChild(v_u_10.REMOTE)
local v_u_18 = v16:WaitForChild(v_u_10.REMOTE_IN)
local v19 = v16:WaitForChild(v_u_10.REMOTE_FX)
local v_u_20 = v5:WaitForChild("GameAssets"):WaitForChild("CarWash")
local v_u_21 = v_u_13.isTouch()
local v_u_22 = v_u_13.ACCENT
local v_u_23 = v_u_13.DARK_TEXT
local v_u_24 = v_u_13.GREEN_TEXT
local v_u_25 = v_u_13.CARD
local v26 = v_u_13.CARD_DARK
local v_u_27 = v_u_13.CARD:Lerp(v_u_13.ACCENT, 0.14)
local v_u_28 = Color3.new(1, 1, 1)
local function v_u_35(...) -- name: call
	-- upvalues: (copy) v_u_1, (copy) v_u_17
	local v29 = v_u_1.invoke
	local v30 = v_u_17
	local v31, v32, v33, v34 = pcall(v29, v30, ...)
	if v31 then
		return v32, v33, v34
	else
		return false, "Couldn\'t reach the server"
	end
end
local function v_u_38(...) -- name: send
	-- upvalues: (copy) v_u_1, (copy) v_u_18
	local v36 = v_u_1.fire
	local v37 = v_u_18
	pcall(v36, v37, ...)
end
local v_u_39 = Instance.new("Folder")
v_u_39.Name = "CarWashFX"
local function v40() -- name: placeFolder
	-- upvalues: (copy) v_u_39
	if workspace.CurrentCamera then
		v_u_39.Parent = workspace.CurrentCamera
	end
end
if workspace.CurrentCamera then
	v_u_39.Parent = workspace.CurrentCamera
end
workspace:GetPropertyChangedSignal("CurrentCamera"):Connect(v40)
local v_u_41 = v_u_13.screen("CarWash", 30, v_u_15:WaitForChild("PlayerGui"))
local v_u_42 = {
	["click"] = v_u_13.new("Sound", {
		["Name"] = "Click",
		["SoundId"] = "rbxasset://sounds/clickfast.wav",
		["Volume"] = 0.35,
		["PlaybackSpeed"] = 1,
		["Looped"] = false,
		["Parent"] = nil,
		["Parent"] = v_u_41
	}),
	["open"] = v_u_13.new("Sound", {
		["Name"] = "Open",
		["SoundId"] = "rbxasset://sounds/switch.wav",
		["Volume"] = 0.3,
		["PlaybackSpeed"] = 1.2,
		["Looped"] = false,
		["Parent"] = nil,
		["Parent"] = v_u_41
	}),
	["step"] = v_u_13.new("Sound", {
		["Name"] = "Step",
		["SoundId"] = "rbxasset://sounds/electronicpingshort.wav",
		["Volume"] = 0.35,
		["PlaybackSpeed"] = 1,
		["Looped"] = false,
		["Parent"] = nil,
		["Parent"] = v_u_41
	}),
	["done"] = v_u_13.new("Sound", {
		["Name"] = "Done",
		["SoundId"] = "rbxasset://sounds/victory.wav",
		["Volume"] = 0.25,
		["PlaybackSpeed"] = 1,
		["Looped"] = false,
		["Parent"] = nil,
		["Parent"] = v_u_41
	})
}
local v_u_43 = v_u_13.new("Sound", {
	["Name"] = "Rub",
	["SoundId"] = "rbxasset://sounds/action_swim.mp3",
	["Volume"] = 0.12,
	["PlaybackSpeed"] = 1.7,
	["Looped"] = true,
	["Parent"] = nil,
	["Parent"] = v_u_41
})
local v_u_44 = v_u_13.window({
	["name"] = "CarWashPanel",
	["gui"] = nil,
	["icon"] = "car",
	["grad"] = "gold",
	["title"] = "Car Wash",
	["sub"] = "\224\184\165\224\185\137\224\184\178\224\184\135\224\184\163\224\184\150\224\184\171\224\184\162\224\184\173\224\184\148\224\185\128\224\184\171\224\184\163\224\184\181\224\184\162\224\184\141 24 \224\184\138\224\184\161. \194\183 SELF SERVICE CAR WASH",
	["size"] = nil,
	["max"] = nil,
	["gui"] = v_u_41,
	["size"] = Vector2.new(0.5, 0.74),
	["max"] = Vector2.new(820, 540)
})
local _ = v_u_44.panel
local v45 = v_u_44.body
local v46 = v_u_13.new("ScrollingFrame", {
	["Name"] = "Menu",
	["BackgroundTransparency"] = 1,
	["BorderSizePixel"] = 0,
	["Size"] = nil,
	["CanvasSize"] = nil,
	["AutomaticCanvasSize"] = nil,
	["ScrollingDirection"] = nil,
	["ScrollBarThickness"] = 3,
	["ScrollBarImageColor3"] = nil,
	["ScrollBarImageTransparency"] = 0.4,
	["Parent"] = nil,
	["Size"] = UDim2.new(0.42, -6, 1, 0),
	["CanvasSize"] = UDim2.new(),
	["AutomaticCanvasSize"] = Enum.AutomaticSize.Y,
	["ScrollingDirection"] = Enum.ScrollingDirection.Y,
	["ScrollBarImageColor3"] = v_u_13.TEXT_DIM,
	["Parent"] = v45
})
v_u_13.new("UIListLayout", {
	["Padding"] = UDim.new(0, 8),
	["SortOrder"] = Enum.SortOrder.LayoutOrder,
	["Parent"] = v46
})
v_u_13.new("UIPadding", {
	["PaddingLeft"] = UDim.new(0, 2),
	["PaddingRight"] = UDim.new(0, 7),
	["PaddingTop"] = UDim.new(0, 3),
	["PaddingBottom"] = UDim.new(0, 4),
	["Parent"] = v46
})
local v_u_47 = v_u_13.button({
	["name"] = "Start",
	["text"] = nil,
	["icon"] = "car",
	["grad"] = "gold",
	["size"] = nil,
	["textSize"] = 21,
	["parent"] = nil,
	["text"] = v_u_11.startPrice,
	["size"] = UDim2.new(1, 0, 0, 54),
	["parent"] = v46
})
v_u_47.LayoutOrder = 1
local v_u_48 = v_u_13.new("Frame", {
	["Name"] = "Options",
	["BackgroundTransparency"] = 1,
	["Size"] = nil,
	["AutomaticSize"] = nil,
	["LayoutOrder"] = 2,
	["Parent"] = nil,
	["Size"] = UDim2.new(1, 0, 0, 0),
	["AutomaticSize"] = Enum.AutomaticSize.Y,
	["Parent"] = v46
})
v_u_13.new("UIGridLayout", {
	["CellSize"] = UDim2.new(0.5, -4, 0, 70),
	["CellPadding"] = UDim2.fromOffset(8, 8),
	["SortOrder"] = Enum.SortOrder.LayoutOrder,
	["Parent"] = v_u_48
})
local v_u_49 = {}
local function v61(p50, p51, p52, p53) -- name: optionButton
	-- upvalues: (copy) v_u_13, (copy) v_u_25, (copy) v_u_28, (copy) v_u_48, (copy) v_u_10, (copy) v_u_11, (copy) v_u_49
	local v54 = v_u_13.new("TextButton", {
		["Name"] = nil,
		["Text"] = "",
		["AutoButtonColor"] = false,
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["LayoutOrder"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Name"] = p50,
		["BackgroundColor3"] = v_u_25,
		["LayoutOrder"] = p51,
		["Size"] = UDim2.new(1, 0, 0, p53 or 70),
		["Parent"] = p52
	})
	v_u_13.corner(v54, 8)
	local v55 = v_u_13.border(v54, v_u_28, 0.92, 1)
	if p52 == v_u_48 then
		local v56 = {
			["Name"] = "Icon",
			["Text"] = nil,
			["TextSize"] = 24,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["Text"] = v_u_10.ICONS[p50],
			["Position"] = UDim2.fromOffset(0, 8),
			["Size"] = UDim2.new(1, 0, 0, 30),
			["Parent"] = v54
		}
		v56.FontFace = v56.FontFace or v_u_13.FONT_BOLD
		v_u_13.text(v56)
		local v57 = {
			["Name"] = "Label",
			["Text"] = nil,
			["TextSize"] = 15,
			["FontFace"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["Text"] = v_u_11.options[p50],
			["FontFace"] = v_u_13.FONT_HEAVY,
			["Position"] = UDim2.new(0, 4, 1, -29),
			["Size"] = UDim2.new(1, -8, 0, 22),
			["Parent"] = v54
		}
		v57.FontFace = v57.FontFace or v_u_13.FONT_BOLD
		v_u_13.text(v57)
	else
		local v58 = {
			["Name"] = "Icon",
			["Text"] = nil,
			["TextSize"] = 24,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["Text"] = v_u_10.ICONS[p50],
			["AnchorPoint"] = Vector2.new(0, 0.5),
			["Position"] = UDim2.new(0, 14, 0.5, 0),
			["Size"] = UDim2.fromOffset(32, 32),
			["Parent"] = v54
		}
		v58.FontFace = v58.FontFace or v_u_13.FONT_BOLD
		v_u_13.text(v58)
		local v59 = {
			["Name"] = "Label",
			["Text"] = nil,
			["TextSize"] = 16,
			["FontFace"] = nil,
			["TextXAlignment"] = nil,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["Text"] = v_u_11.options[p50],
			["FontFace"] = v_u_13.FONT_HEAVY,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["AnchorPoint"] = Vector2.new(0, 0.5),
			["Position"] = UDim2.new(0, 56, 0.5, 0),
			["Size"] = UDim2.new(1, -90, 0, 22),
			["Parent"] = v54
		}
		v59.FontFace = v59.FontFace or v_u_13.FONT_BOLD
		v_u_13.text(v59)
	end
	local v60 = {
		["Name"] = "Badge",
		["Text"] = "",
		["TextSize"] = 14,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(1, 0),
		["Position"] = UDim2.new(1, -6, 0, 5),
		["Size"] = UDim2.fromOffset(20, 20),
		["Parent"] = v54
	}
	v60.FontFace = v60.FontFace or v_u_13.FONT_BOLD
	v_u_49[p50] = {
		["button"] = v54,
		["stroke"] = v55,
		["badge"] = v_u_13.text(v60)
	}
	return v54
end
v61("water", 1, v_u_48)
v61("foam", 2, v_u_48)
v61("sponge", 3, v_u_48)
v61("cloth", 4, v_u_48)
v61("wax", 3, v46, 56)
local v_u_62 = v_u_13.button({
	["name"] = "CancelJob",
	["text"] = "\224\184\162\224\184\129\224\185\128\224\184\165\224\184\180\224\184\129\224\184\129\224\184\178\224\184\163\224\184\165\224\185\137\224\184\178\224\184\135\224\184\163\224\184\150",
	["grad"] = "dark",
	["textColor"] = nil,
	["size"] = nil,
	["textSize"] = 16,
	["parent"] = nil,
	["textColor"] = Color3.fromRGB(255, 120, 120),
	["size"] = UDim2.new(1, 0, 0, 38),
	["parent"] = v46
})
v_u_62.LayoutOrder = 4
v_u_62.Visible = false
local v63 = v_u_13.new("Frame", {
	["Name"] = "Steps",
	["BackgroundTransparency"] = 1,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["Position"] = UDim2.new(0.42, 6, 0, 0),
	["Size"] = UDim2.new(0.58, -6, 1, 0),
	["Parent"] = v45
})
local v64 = {
	["Text"] = "\224\184\130\224\184\177\224\185\137\224\184\153\224\184\149\224\184\173\224\184\153\224\184\129\224\184\178\224\184\163\224\184\165\224\185\137\224\184\178\224\184\135\224\184\163\224\184\150",
	["TextSize"] = 17,
	["FontFace"] = nil,
	["TextXAlignment"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["FontFace"] = v_u_13.FONT_HEAVY,
	["TextXAlignment"] = Enum.TextXAlignment.Left,
	["Size"] = UDim2.new(1, 0, 0, 22),
	["Parent"] = v63
}
v64.FontFace = v64.FontFace or v_u_13.FONT_BOLD
v_u_13.text(v64)
v_u_13.new("Frame", {
	["Name"] = "Line",
	["BackgroundColor3"] = nil,
	["BorderSizePixel"] = 0,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["BackgroundColor3"] = v_u_22,
	["Position"] = UDim2.fromOffset(0, 24),
	["Size"] = UDim2.fromOffset(34, 3),
	["Parent"] = v63
})
local v65 = {
	["Text"] = "\224\185\128\224\184\170\224\184\163\224\185\135\224\184\136\224\185\129\224\184\149\224\185\136\224\184\165\224\184\176\224\184\130\224\184\177\224\185\137\224\184\153 \224\184\129\224\184\165\224\184\177\224\184\154\224\184\161\224\184\178\224\185\128\224\184\165\224\184\183\224\184\173\224\184\129\224\184\130\224\184\177\224\185\137\224\184\153\224\184\149\224\185\136\224\184\173\224\185\132\224\184\155\224\184\151\224\184\181\224\185\136\224\184\149\224\184\185\224\185\137",
	["TextSize"] = 12,
	["FontFace"] = nil,
	["TextColor3"] = nil,
	["TextTruncate"] = nil,
	["TextXAlignment"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["FontFace"] = v_u_13.FONT,
	["TextColor3"] = v_u_13.TEXT_DIM,
	["TextTruncate"] = Enum.TextTruncate.AtEnd,
	["TextXAlignment"] = Enum.TextXAlignment.Left,
	["Position"] = UDim2.fromOffset(0, 31),
	["Size"] = UDim2.new(1, 0, 0, 16),
	["Parent"] = v63
}
v65.FontFace = v65.FontFace or v_u_13.FONT_BOLD
v_u_13.text(v65)
local v66 = v_u_13.new("ScrollingFrame", {
	["BackgroundTransparency"] = 1,
	["Position"] = nil,
	["Size"] = nil,
	["CanvasSize"] = nil,
	["AutomaticCanvasSize"] = nil,
	["ScrollingDirection"] = nil,
	["ScrollBarThickness"] = 3,
	["ScrollBarImageColor3"] = nil,
	["ScrollBarImageTransparency"] = 0.4,
	["BorderSizePixel"] = 0,
	["Parent"] = nil,
	["Position"] = UDim2.fromOffset(0, 54),
	["Size"] = UDim2.new(1, 0, 1, -54),
	["CanvasSize"] = UDim2.new(),
	["AutomaticCanvasSize"] = Enum.AutomaticSize.Y,
	["ScrollingDirection"] = Enum.ScrollingDirection.Y,
	["ScrollBarImageColor3"] = v_u_13.TEXT_DIM,
	["Parent"] = v63
})
v_u_13.new("UIListLayout", {
	["Padding"] = UDim.new(0, 6),
	["SortOrder"] = Enum.SortOrder.LayoutOrder,
	["Parent"] = v66
})
v_u_13.new("UIPadding", {
	["PaddingTop"] = UDim.new(0, 1),
	["PaddingBottom"] = UDim.new(0, 2),
	["Parent"] = v66
})
local v_u_67 = {}
for v68, v69 in ipairs(v_u_11.steps) do
	local v70 = v_u_13.new("Frame", {
		["Name"] = nil,
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["LayoutOrder"] = nil,
		["Parent"] = nil,
		["Name"] = "Step" .. v68,
		["BackgroundColor3"] = v26,
		["Size"] = UDim2.new(1, -7, 0, 54),
		["LayoutOrder"] = v68,
		["Parent"] = v66
	})
	v_u_13.corner(v70, 8)
	local v71 = v_u_13.border(v70, v_u_28, 0.92, 1)
	local v72 = v_u_13.new("Frame", {
		["BackgroundColor3"] = v_u_13.CARD_HOVER,
		["Position"] = UDim2.fromOffset(8, 13),
		["Size"] = UDim2.fromOffset(28, 28),
		["Parent"] = v70
	})
	v_u_13.corner(v72, 14)
	local v73 = {
		["Text"] = nil,
		["TextSize"] = 15,
		["FontFace"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Text"] = tostring(v68),
		["FontFace"] = v_u_13.FONT_HEAVY,
		["Size"] = UDim2.fromScale(1, 1),
		["Parent"] = v72
	}
	v73.FontFace = v73.FontFace or v_u_13.FONT_BOLD
	local v74 = v_u_13.text(v73)
	local v75 = {
		["Text"] = nil,
		["TextSize"] = 20,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Text"] = v_u_10.ICONS[v_u_10.STEP_TOOLS[v68]],
		["Position"] = UDim2.fromOffset(42, 0),
		["Size"] = UDim2.new(0, 28, 1, 0),
		["Parent"] = v70
	}
	v75.FontFace = v75.FontFace or v_u_13.FONT_BOLD
	v_u_13.text(v75)
	local v76 = {
		["Text"] = nil,
		["TextSize"] = 15,
		["FontFace"] = nil,
		["TextXAlignment"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Text"] = v69,
		["FontFace"] = v_u_13.FONT_HEAVY,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["Position"] = UDim2.fromOffset(76, 5),
		["Size"] = UDim2.new(1, -84, 0, 18),
		["Parent"] = v70
	}
	v76.FontFace = v76.FontFace or v_u_13.FONT_BOLD
	v_u_13.text(v76)
	local v77 = {
		["Text"] = nil,
		["TextSize"] = 12,
		["FontFace"] = nil,
		["TextColor3"] = nil,
		["TextWrapped"] = true,
		["TextXAlignment"] = nil,
		["TextYAlignment"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Text"] = v_u_11.stepDesc[v68],
		["FontFace"] = v_u_13.FONT,
		["TextColor3"] = v_u_13.TEXT_DIM,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["TextYAlignment"] = Enum.TextYAlignment.Top,
		["Position"] = UDim2.fromOffset(76, 23),
		["Size"] = UDim2.new(1, -84, 0, 30),
		["Parent"] = v70
	}
	v77.FontFace = v77.FontFace or v_u_13.FONT_BOLD
	v_u_13.text(v77)
	v_u_67[v68] = {
		["item"] = v70,
		["stroke"] = v71,
		["n"] = v72,
		["num"] = v74
	}
end
local v_u_78 = v_u_13.panel({
	["Name"] = "Hud",
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["AutomaticSize"] = nil,
	["Visible"] = false,
	["Parent"] = nil,
	["AnchorPoint"] = Vector2.new(1, 0.5),
	["Position"] = UDim2.new(1, -16, 0.5, 0),
	["Size"] = UDim2.fromOffset(280, 0),
	["AutomaticSize"] = Enum.AutomaticSize.Y,
	["Parent"] = v_u_41
})
local v_u_79 = v_u_13.autoScale(v_u_78, v_u_13.PHONE_SHRINK)
v_u_13.padding(v_u_78, 14, 12)
v_u_13.new("UIListLayout", {
	["Padding"] = UDim.new(0, 6),
	["SortOrder"] = Enum.SortOrder.LayoutOrder,
	["Parent"] = v_u_78
})
local v80 = v_u_13.new("Frame", {
	["BackgroundTransparency"] = 1,
	["Size"] = nil,
	["LayoutOrder"] = 1,
	["Parent"] = nil,
	["Size"] = UDim2.new(1, 0, 0, 22),
	["Parent"] = v_u_78
})
local v81 = {
	["Text"] = "<font color=\"#EEE452\">CAR</font> WASH",
	["RichText"] = true,
	["TextSize"] = 16,
	["FontFace"] = nil,
	["TextXAlignment"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["FontFace"] = v_u_13.FONT_DISPLAY,
	["TextXAlignment"] = Enum.TextXAlignment.Left,
	["Size"] = UDim2.fromScale(0.6, 1),
	["Parent"] = v80
}
v81.FontFace = v81.FontFace or v_u_13.FONT_BOLD
v_u_13.text(v81)
local v82 = {
	["Text"] = "1/6",
	["TextSize"] = 15,
	["FontFace"] = nil,
	["TextColor3"] = nil,
	["TextXAlignment"] = nil,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["FontFace"] = v_u_13.FONT_DIGITS,
	["TextColor3"] = v_u_13.ACCENT_LIGHT,
	["TextXAlignment"] = Enum.TextXAlignment.Right,
	["AnchorPoint"] = Vector2.new(1, 0),
	["Position"] = UDim2.fromScale(1, 0),
	["Size"] = UDim2.fromScale(0.4, 1),
	["Parent"] = v80
}
v82.FontFace = v82.FontFace or v_u_13.FONT_BOLD
local v_u_83 = v_u_13.text(v82)
local function v89(p84, p85, p86) -- name: bar
	-- upvalues: (copy) v_u_13, (copy) v_u_22
	local v87 = v_u_13.new("Frame", {
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["LayoutOrder"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_13.CARD_HOVER,
		["Size"] = UDim2.new(1, 0, 0, p86),
		["LayoutOrder"] = p85,
		["Parent"] = p84
	})
	v_u_13.corner(v87, p86 // 2)
	local v88 = v_u_13.new("Frame", {
		["BackgroundColor3"] = v_u_22,
		["Size"] = UDim2.fromScale(0, 1),
		["Parent"] = v87
	})
	v_u_13.corner(v88, p86 // 2)
	return v88, v87
end
local v_u_90 = v89(v_u_78, 2, 8)
local v_u_91 = {}
for v92, v93 in ipairs(v_u_11.steps) do
	local v94 = v_u_13.new("Frame", {
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["LayoutOrder"] = nil,
		["Parent"] = nil,
		["Size"] = UDim2.new(1, 0, 0, 30),
		["LayoutOrder"] = 2 + v92,
		["Parent"] = v_u_78
	})
	local v95 = {
		["Text"] = nil,
		["TextSize"] = 13,
		["FontFace"] = nil,
		["TextColor3"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Text"] = tostring(v92),
		["FontFace"] = v_u_13.FONT_HEAVY,
		["TextColor3"] = v_u_13.TEXT_DIM,
		["Size"] = UDim2.fromOffset(18, 30),
		["Parent"] = v94
	}
	v95.FontFace = v95.FontFace or v_u_13.FONT_BOLD
	local v96 = v_u_13.text(v95)
	local v97 = {
		["Text"] = nil,
		["TextSize"] = 13,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Text"] = v93,
		["TextColor3"] = v_u_13.TEXT_DIM,
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["Position"] = UDim2.fromOffset(24, 0),
		["Size"] = UDim2.new(1, -70, 0, 16),
		["Parent"] = v94
	}
	v97.FontFace = v97.FontFace or v_u_13.FONT_BOLD
	local v98 = v_u_13.text(v97)
	local v99 = {
		["Text"] = "0%",
		["TextSize"] = 13,
		["FontFace"] = nil,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["FontFace"] = v_u_13.FONT_DIGITS,
		["TextColor3"] = v_u_13.TEXT_DIM,
		["TextXAlignment"] = Enum.TextXAlignment.Right,
		["AnchorPoint"] = Vector2.new(1, 0),
		["Position"] = UDim2.fromScale(1, 0),
		["Size"] = UDim2.fromOffset(44, 16),
		["Parent"] = v94
	}
	v99.FontFace = v99.FontFace or v_u_13.FONT_BOLD
	local v100 = v_u_13.text(v99)
	local v101 = v_u_13.new("Frame", {
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Position"] = UDim2.fromOffset(24, 20),
		["Size"] = UDim2.new(1, -24, 0, 6),
		["Parent"] = v94
	})
	v_u_13.new("UIListLayout", {
		["Parent"] = v101
	})
	v_u_91[v92] = {
		["row"] = v94,
		["n"] = v96,
		["name"] = v98,
		["pc"] = v100,
		["fill"] = v89(v101, 1, 6)
	}
end
local v_u_102 = v_u_13.new("Frame", {
	["BackgroundTransparency"] = 1,
	["Size"] = nil,
	["LayoutOrder"] = 10,
	["Visible"] = false,
	["Parent"] = nil,
	["Size"] = UDim2.new(1, 0, 0, 48),
	["Parent"] = v_u_78
})
local v103 = {
	["Text"] = "",
	["TextSize"] = 13,
	["TextColor3"] = nil,
	["TextXAlignment"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["TextColor3"] = v_u_22,
	["TextXAlignment"] = Enum.TextXAlignment.Left,
	["Size"] = UDim2.new(1, 0, 0, 16),
	["Parent"] = v_u_102
}
v103.FontFace = v103.FontFace or v_u_13.FONT_BOLD
local v_u_104 = v_u_13.text(v103)
local v_u_105 = {}
for v106 = 1, 4 do
	local v107 = v_u_13.new("Frame", {
		["BackgroundColor3"] = v_u_25,
		["Position"] = UDim2.new((v106 - 1) * 0.25, 2, 0, 20),
		["Size"] = UDim2.new(0.25, -4, 0, 26),
		["Parent"] = v_u_102
	})
	v_u_13.corner(v107, 6)
	local v108 = {
		["Text"] = "0%",
		["TextSize"] = 13,
		["FontFace"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["FontFace"] = v_u_13.FONT_DIGITS,
		["Size"] = UDim2.fromScale(1, 1),
		["Parent"] = v107
	}
	v108.FontFace = v108.FontFace or v_u_13.FONT_BOLD
	v_u_105[v106] = v_u_13.text(v108)
end
local v109 = {
	["Text"] = nil,
	["TextSize"] = 12,
	["TextColor3"] = nil,
	["TextWrapped"] = true,
	["TextXAlignment"] = nil,
	["Size"] = nil,
	["LayoutOrder"] = 11,
	["Visible"] = nil,
	["Parent"] = nil,
	["Text"] = v_u_21 and "" or v_u_11.stopKey,
	["TextColor3"] = v_u_13.TEXT_DIM,
	["TextXAlignment"] = Enum.TextXAlignment.Left,
	["Size"] = UDim2.new(1, 0, 0, 30),
	["Visible"] = not v_u_21,
	["Parent"] = v_u_78
}
v109.FontFace = v109.FontFace or v_u_13.FONT_BOLD
v_u_13.text(v109)
local v110 = v_u_13.button({
	["name"] = "Stop",
	["text"] = nil,
	["grad"] = "red",
	["size"] = nil,
	["textSize"] = 17,
	["parent"] = nil,
	["text"] = v_u_11.stopTouch,
	["size"] = UDim2.new(1, 0, 0, 38),
	["parent"] = v_u_78
})
v110.LayoutOrder = 12
v110.Visible = v_u_21
local v_u_111 = v_u_13.new("Frame", {
	["Name"] = "Prompt",
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["AutomaticSize"] = nil,
	["BackgroundColor3"] = nil,
	["BackgroundTransparency"] = 0.08,
	["Visible"] = false,
	["Parent"] = nil,
	["AnchorPoint"] = Vector2.new(0.5, 1),
	["Position"] = UDim2.new(0.5, 0, 1, -170),
	["Size"] = UDim2.fromOffset(0, 44),
	["AutomaticSize"] = Enum.AutomaticSize.X,
	["BackgroundColor3"] = v_u_13.PANEL,
	["Parent"] = v_u_41
})
v_u_13.corner(v_u_111, 22)
v_u_13.border(v_u_111, v_u_28, 0.9, 1)
v_u_13.padding(v_u_111, 8, 6)
v_u_13.new("UIListLayout", {
	["FillDirection"] = Enum.FillDirection.Horizontal,
	["VerticalAlignment"] = Enum.VerticalAlignment.Center,
	["Padding"] = UDim.new(0, 10),
	["Parent"] = v_u_111
})
local v112 = v_u_13.new("Frame", {
	["BackgroundColor3"] = v_u_22,
	["Size"] = UDim2.fromOffset(0, 32),
	["AutomaticSize"] = Enum.AutomaticSize.X,
	["Parent"] = v_u_111
})
v_u_13.corner(v112, 8)
v_u_13.padding(v112, 9, 0)
local v113 = {
	["Text"] = "E",
	["TextSize"] = 16,
	["FontFace"] = nil,
	["TextColor3"] = nil,
	["Size"] = nil,
	["AutomaticSize"] = nil,
	["Parent"] = nil,
	["FontFace"] = v_u_13.FONT_HEAVY,
	["TextColor3"] = v_u_23,
	["Size"] = UDim2.fromOffset(14, 32),
	["AutomaticSize"] = Enum.AutomaticSize.X,
	["Parent"] = v112
}
v113.FontFace = v113.FontFace or v_u_13.FONT_BOLD
local v_u_114 = v_u_13.text(v113)
local v115 = {
	["Text"] = "",
	["TextSize"] = 16,
	["Size"] = nil,
	["AutomaticSize"] = nil,
	["Parent"] = nil,
	["Size"] = UDim2.fromOffset(0, 32),
	["AutomaticSize"] = Enum.AutomaticSize.X,
	["Parent"] = v_u_111
}
v115.FontFace = v115.FontFace or v_u_13.FONT_BOLD
local v_u_116 = v_u_13.text(v115)
v_u_13.new("UIPadding", {
	["PaddingRight"] = UDim.new(0, 8),
	["Parent"] = v_u_116
})
local v_u_117 = v_u_13.new("UIScale", {
	["Name"] = "PhoneHintScale",
	["Scale"] = 1,
	["Parent"] = nil,
	["Parent"] = v_u_111
})
local v_u_118 = nil
local v119 = nil
local v_u_120 = v_u_13.new("TextButton", {
	["Name"] = "Action",
	["Text"] = "",
	["AutoButtonColor"] = false,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["BackgroundColor3"] = nil,
	["BackgroundTransparency"] = 0.05,
	["Visible"] = false,
	["Parent"] = nil,
	["AnchorPoint"] = Vector2.new(1, 1),
	["Position"] = UDim2.new(1, -118, 1, -150),
	["Size"] = UDim2.fromOffset(96, 96),
	["BackgroundColor3"] = Color3.new(1, 1, 1),
	["Parent"] = v_u_41
})
v_u_13.corner(v_u_120, 999)
v_u_13.gradient(v_u_120, "gold")
v_u_13.border(v_u_120, Color3.new(1, 1, 1), 0.5, 2)
local v121 = {
	["Text"] = nil,
	["TextSize"] = 30,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["Text"] = v_u_10.ICONS.water,
	["Position"] = UDim2.fromOffset(0, 14),
	["Size"] = UDim2.new(1, 0, 0, 40),
	["Parent"] = v_u_120
}
v121.FontFace = v121.FontFace or v_u_13.FONT_BOLD
local v_u_122 = v_u_13.text(v121)
local v123 = {
	["Text"] = "",
	["TextSize"] = 15,
	["FontFace"] = nil,
	["TextColor3"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["FontFace"] = v_u_13.FONT_HEAVY,
	["TextColor3"] = v_u_23,
	["Position"] = UDim2.fromOffset(0, 54),
	["Size"] = UDim2.new(1, 0, 0, 22),
	["Parent"] = v_u_120
}
v123.FontFace = v123.FontFace or v_u_13.FONT_BOLD
local v_u_124 = v_u_13.text(v123)
local v_u_125 = v_u_13.new("Frame", {
	["Name"] = "Crosshair",
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["BackgroundTransparency"] = 1,
	["Visible"] = false,
	["Parent"] = nil,
	["AnchorPoint"] = Vector2.new(0.5, 0.5),
	["Position"] = UDim2.fromScale(0.5, 0.5),
	["Size"] = UDim2.fromOffset(18, 18),
	["Parent"] = v_u_41
})
v_u_13.corner(v_u_125, 9)
v_u_13.border(v_u_125, Color3.new(1, 1, 1), 0.1, 2)
local v_u_126 = {
	["water"] = "\224\184\137\224\184\181\224\184\148",
	["foam"] = "\224\184\137\224\184\181\224\184\148",
	["sponge"] = "\224\184\130\224\184\177\224\184\148",
	["cloth"] = "\224\185\128\224\184\138\224\185\135\224\184\148",
	["wax"] = "\224\185\128\224\184\132\224\184\165\224\184\183\224\184\173\224\184\154"
}
local function v_u_138() -- name: topRightKeysBottom
	-- upvalues: (copy) v_u_15, (copy) v_u_41
	local v127 = v_u_15:FindFirstChildOfClass("PlayerGui")
	local v128 = game:GetService("GuiService"):GetGuiInset()
	local v129 = v_u_41.AbsoluteSize
	local v130 = 0
	for _, v131 in not v127 and {} or v127:GetChildren() do
		if not v131:IsA("ScreenGui") or (v131 == v_u_41 or not v131.Enabled) then
			continue
		end
		local v132 = not v131.IgnoreGuiInset and 0 or -v128.Y
		for _, v133 in v131:GetDescendants() do
			if not v133:IsA("GuiButton") or (not v133.Visible or v133.AbsoluteSize.X <= 0) then
				continue
			end
			local v134 = v133.AbsolutePosition.Y + v132
			if v133.AbsolutePosition.X + v133.AbsoluteSize.X <= v129.X * 0.6 or (v134 >= v129.Y * 0.35 or v134 + v133.AbsoluteSize.Y <= 0) then
				continue
			end
			local v135 = v133.Parent
			local v136 = true
			while v135 and v135 ~= v131 do
				if v135:IsA("GuiObject") and not v135.Visible then
					v136 = false
					break
				end
				v135 = v135.Parent
			end
			if not v136 then
				break
			end
			local v137 = v134 + v133.AbsoluteSize.Y
			v130 = math.max(v130, v137)
		end
	end
	return v130
end
local function v_u_150() -- name: fitHud
	-- upvalues: (copy) v_u_21, (copy) v_u_78, (copy) v_u_79, (copy) v_u_13, (copy) v_u_41, (copy) v_u_120
	if v_u_21 and (v_u_78.Visible and v_u_79.Scale > 0) then
		local v139 = workspace.CurrentCamera
		local v140 = v_u_13.scaleFor
		local v141
		if v139 then
			v141 = v139.ViewportSize
		else
			v141 = v_u_41.AbsoluteSize
		end
		local v142 = v140(v141, v_u_13.PHONE_SHRINK)
		local v143 = v_u_120
		local v144 = v_u_78
		local v145 = v143.Visible
		if v145 then
			if v143.AbsolutePosition.X < v144.AbsolutePosition.X + v144.AbsoluteSize.X then
				v145 = v143.AbsolutePosition.X + v143.AbsoluteSize.X > v144.AbsolutePosition.X
			else
				v145 = false
			end
		end
		local v146 = v144.AbsoluteSize.Y / v_u_79.Scale
		local v147 = v143.AbsolutePosition.Y - 10 - v144.AbsolutePosition.Y
		if v145 and (v146 > 0 and v147 > 60) then
			local v148 = v147 / v146
			v142 = math.min(v142, v148)
		end
		local v149 = v_u_79.Scale - v142
		if math.abs(v149) > 0.005 then
			v_u_79.Scale = v142
		end
	end
end
v_u_78:GetPropertyChangedSignal("AbsoluteSize"):Connect(v_u_150)
v_u_78:GetPropertyChangedSignal("Visible"):Connect(v_u_150)
local function v_u_158() -- name: layoutTouch
	-- upvalues: (copy) v_u_21, (copy) v_u_41, (copy) v_u_13, (copy) v_u_120, (copy) v_u_15, (copy) v_u_78, (copy) v_u_138, (copy) v_u_150, (ref) v_u_118
	if v_u_21 then
		local v151 = v_u_41.AbsoluteSize
		if v151.X >= 1 and v151.Y >= 1 then
			local v152 = v_u_13.isPhone() and 84 or 104
			v_u_120.Size = UDim2.fromOffset(v152, v152)
			v_u_120.AnchorPoint = Vector2.new(1, 1)
			local v153 = v_u_15:FindFirstChildOfClass("PlayerGui")
			if v153 then
				v153 = v153:FindFirstChild("TouchGui")
			end
			if v153 then
				v153 = v153:FindFirstChild("JumpButton", true)
			end
			if v153 and (v153:IsA("GuiObject") and v153.AbsoluteSize.X > 0) then
				local v154 = v153.AbsolutePosition - v_u_41.AbsolutePosition
				v_u_120.Position = UDim2.fromOffset(v154.X - 16, v154.Y + v153.AbsoluteSize.Y)
			else
				v_u_120.Position = UDim2.new(1, -118, 1, -150)
			end
			v_u_78.AnchorPoint = Vector2.new(1, 0)
			local v155 = v_u_78
			local v156 = UDim2.new
			local v157 = v_u_138() + 8
			v155.Position = v156(1, -12, 0, (math.max(6, v157)))
			task.defer(v_u_150)
			v_u_118()
		end
	else
		return
	end
end
local function v_u_171() -- name: topMiddleKeysBottom
	-- upvalues: (copy) v_u_15, (copy) v_u_41
	local v159 = v_u_15:FindFirstChildOfClass("PlayerGui")
	local v160 = game:GetService("GuiService"):GetGuiInset()
	local v161 = v_u_41.AbsoluteSize
	local v162 = 0
	for _, v163 in not v159 and {} or v159:GetChildren() do
		if not v163:IsA("ScreenGui") or (v163 == v_u_41 or not v163.Enabled) then
			continue
		end
		local v164 = not v163.IgnoreGuiInset and 0 or -v160.Y
		for _, v165 in v163:GetDescendants() do
			if not v165:IsA("GuiButton") or (not v165.Visible or v165.AbsoluteSize.X <= 0) then
				continue
			end
			local v166 = v165.AbsolutePosition.Y + v164
			local v167 = v165.AbsolutePosition.X
			if v165.AbsolutePosition.X + v165.AbsoluteSize.X <= v161.X * 0.3 or (v167 >= v161.X * 0.7 or (v166 >= v161.Y * 0.2 or v166 + v165.AbsoluteSize.Y <= 0)) then
				continue
			end
			local v168 = v165.Parent
			local v169 = true
			while v168 and v168 ~= v163 do
				if v168:IsA("GuiObject") and not v168.Visible then
					v169 = false
					break
				end
				v168 = v168.Parent
			end
			if not v169 then
				break
			end
			local v170 = v166 + v165.AbsoluteSize.Y
			v162 = math.max(v162, v170)
		end
	end
	return v162
end
v_u_118 = function()
	-- upvalues: (copy) v_u_21, (copy) v_u_13, (copy) v_u_117, (copy) v_u_111, (copy) v_u_171
	if v_u_21 and v_u_13.isPhone() then
		v_u_117.Scale = 0.72
		v_u_111.AnchorPoint = Vector2.new(0.5, 0)
		local v172 = v_u_111
		local v173 = UDim2.new
		local v174 = v_u_171() + 6
		v172.Position = v173(0.5, 0, 0, (math.max(4, v174)))
	else
		v_u_117.Scale = 1
		v_u_111.AnchorPoint = Vector2.new(0.5, 1)
		local v175 = v_u_111
		local v176
		if v_u_21 then
			v176 = UDim2.new(0.5, 0, 0.5, -22)
		else
			v176 = UDim2.new(0.5, 0, 1, -170)
		end
		v175.Position = v176
	end
end
v_u_41:GetPropertyChangedSignal("AbsoluteSize"):Connect(v_u_158)
v_u_158()
local v_u_177 = {
	["started"] = false,
	["step"] = 1,
	["pct"] = nil,
	["total"] = 0,
	["pct"] = {
		0,
		0,
		0,
		0,
		0,
		0
	}
}
local v_u_178 = nil
local v_u_179 = nil
local v_u_180 = false
local function v_u_184(p181) -- name: customerAt
	-- upvalues: (copy) v_u_15, (copy) v_u_10
	local v182 = v_u_15:FindFirstChildOfClass("PlayerGui")
	for _, v183 in not (v182 and p181) and {} or v182:GetChildren() do
		if v183.Name ~= v_u_10.CUSTOMER_FOLDER or v183:GetAttribute("Machine") ~= p181.Name then
			continue
		end
		return true
	end
	return false
end
local function v_u_213() -- name: renderJob
	-- upvalues: (ref) v_u_177, (copy) v_u_13, (copy) v_u_47, (copy) v_u_184, (ref) v_u_178, (copy) v_u_11, (copy) v_u_62, (copy) v_u_10, (copy) v_u_49, (copy) v_u_22, (copy) v_u_28, (copy) v_u_27, (copy) v_u_25, (copy) v_u_24, (copy) v_u_67, (copy) v_u_23
	local v185 = v_u_177.started == true
	local v186 = v_u_13.setButton
	local v187 = v_u_47
	local v188 = v185 and "grey" or "gold"
	local v189
	if v185 then
		v189 = "\224\184\129\224\184\179\224\184\165\224\184\177\224\184\135\224\184\165\224\185\137\224\184\178\224\184\135\224\184\163\224\184\150"
	elseif v_u_184(v_u_178) then
		v189 = v_u_11.startFree
	else
		v189 = v_u_11.startPrice
	end
	v186(v187, v188, v189)
	v_u_62.Visible = v185
	local v190
	if v185 then
		v190 = v_u_10.STEP_TOOLS[v_u_177.step]
	else
		v190 = nil
	end
	for v191, v192 in v_u_49 do
		local v193 = v185
		for _, v194 in v_u_10.OPTION_STEPS[v191] do
			if (v_u_177.pct[v194] or 0) >= 100 then
				continue
			end
			v193 = false
		end
		local v195
		if v185 then
			v195 = v191 == v190
		else
			v195 = v185
		end
		local v196 = v192.stroke
		local v197
		if v195 then
			v197 = v_u_22
		else
			v197 = v_u_28
		end
		v196.Color = v197
		v192.stroke.Transparency = v195 and 0 or 0.92
		v192.stroke.Thickness = v195 and 2 or 1
		local v198 = v192.button
		local v199
		if v195 then
			v199 = v_u_27
		else
			v199 = v_u_25
		end
		v198.BackgroundColor3 = v199
		v192.badge.Text = v193 and "\226\156\148" or (v195 and "" or "\240\159\148\146")
		local v200 = v192.badge
		local v201
		if v193 then
			v201 = v_u_24
		else
			v201 = v_u_13.TEXT_DIM
		end
		v200.TextColor3 = v201
		for _, v202 in v192.button:GetChildren() do
			if not v202:IsA("TextLabel") or v202.Name == "Badge" then
				continue
			end
			v202.TextTransparency = (v195 or v193) and 0 or 0.45
		end
	end
	for v203, v204 in v_u_67 do
		local v205
		if v185 then
			v205 = (v_u_177.pct[v203] or 0) >= 100
		else
			v205 = v185
		end
		local v206
		if v185 then
			v206 = v_u_177.step == v203
		else
			v206 = v185
		end
		local v207 = v204.stroke
		local v208
		if v206 then
			v208 = v_u_22
		else
			v208 = v_u_28
		end
		v207.Color = v208
		v204.stroke.Transparency = v206 and 0 or 0.92
		v204.stroke.Thickness = v206 and 1.5 or 1
		local v209 = v204.n
		local v210
		if v205 then
			v210 = v_u_24
		elseif v206 then
			v210 = v_u_22
		else
			v210 = v_u_13.CARD_HOVER
		end
		v209.BackgroundColor3 = v210
		v204.num.Text = v205 and "\226\156\148" or tostring(v203)
		local v211 = v204.num
		local v212
		if v205 or v206 then
			v212 = v_u_23
		else
			v212 = v_u_13.TEXT
		end
		v211.TextColor3 = v212
	end
end
local function v_u_236() -- name: renderHud
	-- upvalues: (ref) v_u_179, (copy) v_u_78, (copy) v_u_83, (ref) v_u_177, (copy) v_u_90, (copy) v_u_91, (copy) v_u_24, (copy) v_u_22, (copy) v_u_13, (copy) v_u_21, (copy) v_u_102, (copy) v_u_104, (copy) v_u_11, (copy) v_u_105
	if v_u_179 then
		v_u_78.Visible = true
		local v214 = v_u_83
		local v215 = v_u_177.step or 1
		v214.Text = ("%d/6"):format((math.min(v215, 6)))
		local v216 = v_u_90
		local v217 = UDim2.fromScale
		local v218 = (v_u_177.total or 0) / 100
		v216.Size = v217(math.clamp(v218, 0, 1), 1)
		for v219, v220 in v_u_91 do
			local v221 = v_u_177.pct[v219] or 0
			local v222 = v_u_177.step == v219
			local v223 = v220.fill
			local v224 = UDim2.fromScale
			local v225 = v221 / 100
			v223.Size = v224(math.clamp(v225, 0, 1), 1)
			local v226 = v220.fill
			local v227
			if v221 >= 100 then
				v227 = v_u_24
			else
				v227 = v_u_22
			end
			v226.BackgroundColor3 = v227
			v220.pc.Text = ("%d%%"):format((math.floor(v221)))
			local v228
			if v222 then
				v228 = v_u_13.TEXT
			elseif v221 >= 100 then
				v228 = v_u_24
			else
				v228 = v_u_13.TEXT_DIM
			end
			local v229 = v220.name
			local v230 = v220.pc
			local v231 = v220.n
			v229.TextColor3 = v228
			v230.TextColor3 = v228
			v231.TextColor3 = v228
			v220.row.Visible = not v_u_21 or v222
		end
		if v_u_177.spotKind and v_u_177.spots then
			v_u_102.Visible = true
			v_u_104.Text = v_u_11.spotTitles[v_u_177.spotKind] or ""
			for v232, v233 in v_u_105 do
				local v234 = v_u_177.spots[v232] or 0
				v233.Text = ("%d%%"):format((math.floor(v234)))
				local v235
				if v234 >= 100 then
					v235 = v_u_24
				else
					v235 = v_u_13.TEXT
				end
				v233.TextColor3 = v235
			end
		else
			v_u_102.Visible = false
		end
	else
		v_u_78.Visible = false
		return
	end
end
v_u_44.changed.Event:Connect(function(p237)
	-- upvalues: (ref) v_u_178, (copy) v_u_42, (copy) v_u_35
	if not p237 and v_u_178 then
		local v238 = v_u_42.click
		if v238 then
			v238:Play()
		end
		local v239 = v_u_178
		v_u_178 = nil
		task.spawn(v_u_35, "Close", v239)
	end
end)
v_u_47.Activated:Connect(function()
	-- upvalues: (ref) v_u_180, (ref) v_u_177, (ref) v_u_178, (copy) v_u_42, (copy) v_u_35, (copy) v_u_213, (copy) v_u_14
	if not v_u_180 and (not v_u_177.started and v_u_178) then
		v_u_180 = true
		local v240 = v_u_42.click
		if v240 then
			v240:Play()
		end
		local v241, v242, v243 = v_u_35("Start", v_u_178)
		v_u_180 = false
		if v241 then
			v_u_177 = v243 or v_u_177
			v_u_213()
			if v242 then
				v_u_14.show(v242, "ok")
				return
			end
		elseif v242 then
			v_u_14.show(v242, "error")
		end
	end
end)
local v_u_244 = v_u_118
local v_u_245 = v119
local v_u_246 = v_u_179
local v_u_247 = v_u_177
local v_u_248 = v_u_178
local v_u_249 = v_u_180
for v_u_250, v251 in v_u_49 do
	v251.button.Activated:Connect(function()
		-- upvalues: (ref) v_u_249, (ref) v_u_248, (copy) v_u_42, (ref) v_u_247, (copy) v_u_14, (copy) v_u_11, (copy) v_u_35, (copy) v_u_250, (copy) v_u_44, (copy) v_u_213
		if v_u_249 or not v_u_248 then
			return
		else
			local v252 = v_u_42.click
			if v252 then
				v252:Play()
			end
			if v_u_247.started then
				v_u_249 = true
				local v253, v254, v255 = v_u_35("Select", v_u_248, v_u_250)
				v_u_249 = false
				if v253 then
					v_u_248 = nil
					v_u_44.setOpen(false)
				else
					if v255 then
						v_u_247 = v255
						v_u_213()
					end
					if v254 then
						v_u_14.show(v254, "error")
					end
				end
			else
				v_u_14.show(v_u_11.needStart, "error")
				return
			end
		end
	end)
end
v_u_62.Activated:Connect(function()
	-- upvalues: (ref) v_u_249, (ref) v_u_248, (copy) v_u_42, (copy) v_u_35, (ref) v_u_247, (copy) v_u_213, (copy) v_u_14, (copy) v_u_11
	if not v_u_249 and v_u_248 then
		v_u_249 = true
		local v256 = v_u_42.click
		if v256 then
			v256:Play()
		end
		local v257, _, v258 = v_u_35("CancelJob", v_u_248)
		v_u_249 = false
		if v257 then
			v_u_247 = v258 or {
				["started"] = false,
				["step"] = 1,
				["pct"] = nil,
				["total"] = 0,
				["pct"] = {
					0,
					0,
					0,
					0,
					0,
					0
				}
			}
			v_u_213()
			v_u_14.show(v_u_11.cancelled, "info")
		end
	end
end)
local v_u_259 = false
local v_u_260 = false
local v_u_261 = false
local v_u_262 = false
local v_u_263 = 0
local v_u_264 = nil
local v_u_265 = v_u_120:FindFirstChildOfClass("UIGradient")
local function v_u_270() -- name: actionLook
	-- upvalues: (ref) v_u_261, (copy) v_u_124, (ref) v_u_246, (copy) v_u_126, (copy) v_u_23, (copy) v_u_265, (copy) v_u_13
	local v266 = v_u_261
	v_u_124.Text = v266 and "\224\184\171\224\184\162\224\184\184\224\184\148" or (v_u_246 and (v_u_126[v_u_246.tool] or "") or "")
	local v267 = v_u_124
	local v268
	if v266 then
		v268 = Color3.new(1, 1, 1)
	else
		v268 = v_u_23
	end
	v267.TextColor3 = v268
	if v_u_265 then
		local v269
		if v266 then
			v269 = v_u_13.GRAD.red
		else
			v269 = v_u_13.GRAD.gold
		end
		v_u_265.Color = ColorSequence.new(v269[1], v269[2])
	end
end
local function v_u_274(p271) -- name: setPromptsEnabled
	-- upvalues: (copy) v_u_2, (copy) v_u_10
	for _, v272 in v_u_2:GetTagged(v_u_10.SITE_TAG) do
		for _, v273 in v272:GetDescendants() do
			if not v273:IsA("ProximityPrompt") or v273.Name ~= "CarWashPrompt" then
				continue
			end
			v273.Enabled = p271
		end
	end
end
local function v_u_283() -- name: makeMarkers
	-- upvalues: (ref) v_u_246, (copy) v_u_13, (copy) v_u_39, (copy) v_u_22
	if v_u_246 and v_u_246.markers then
		for _, v275 in v_u_246.markers do
			v275.part:Destroy()
		end
		v_u_246.markers = nil
	end
	v_u_246.markers = {}
	for v276 = 1, 4 do
		local v277 = v_u_13.new("Part", {
			["Name"] = nil,
			["Anchored"] = true,
			["CanCollide"] = false,
			["CanQuery"] = false,
			["CanTouch"] = false,
			["Transparency"] = 1,
			["Size"] = Vector3.new(0.2, 0.2, 0.2),
			["Parent"] = nil,
			["Name"] = "Spot" .. v276,
			["Parent"] = v_u_39
		})
		local v278 = v_u_13.new("BillboardGui", {
			["Size"] = nil,
			["AlwaysOnTop"] = true,
			["LightInfluence"] = 0,
			["Adornee"] = nil,
			["Parent"] = nil,
			["Size"] = UDim2.fromOffset(54, 72),
			["Adornee"] = v277,
			["Parent"] = v277
		})
		local v279 = v_u_13.new("Frame", {
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["BackgroundColor3"] = nil,
			["BackgroundTransparency"] = 0.55,
			["Parent"] = nil,
			["AnchorPoint"] = Vector2.new(0.5, 0),
			["Position"] = UDim2.fromScale(0.5, 0),
			["Size"] = UDim2.fromOffset(46, 46),
			["BackgroundColor3"] = v_u_22,
			["Parent"] = v278
		})
		v_u_13.corner(v279, 23)
		local v280 = v_u_13.border(v279, v_u_22, 0, 3)
		local v281 = {
			["Text"] = "0%",
			["TextSize"] = 14,
			["FontFace"] = nil,
			["TextStrokeTransparency"] = 0.4,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["FontFace"] = v_u_13.FONT_HEAVY,
			["Position"] = UDim2.fromOffset(0, 48),
			["Size"] = UDim2.new(1, 0, 0, 20),
			["Parent"] = v278
		}
		v281.FontFace = v281.FontFace or v_u_13.FONT_BOLD
		local v282 = {
			["part"] = v277,
			["ring"] = v279,
			["stroke"] = v280,
			["pc"] = v_u_13.text(v281)
		}
		v_u_246.markers[v276] = v282
	end
end
local function v_u_300() -- name: runFoamMarks
	-- upvalues: (ref) v_u_247, (ref) v_u_246, (copy) v_u_10, (copy) v_u_13, (copy) v_u_39, (copy) v_u_22
	local v284 = v_u_247
	if v284 then
		if v_u_247.step == 2 then
			v284 = v_u_247.foamZones
		else
			v284 = false
		end
	end
	if v_u_246 and (v_u_246.tool == "foam" and (v284 and (v_u_246.chassis and (v_u_246.mn and v_u_246.mx)))) then
		if not v_u_246.foamMarks then
			v_u_246.zones = v_u_10.foamZones(v_u_246.mn, v_u_246.mx)
			v_u_246.foamMarks = {}
			for v285 = 1, #v_u_246.zones.centers do
				local v286 = v_u_13.new("Part", {
					["Name"] = nil,
					["Anchored"] = true,
					["CanCollide"] = false,
					["CanQuery"] = false,
					["CanTouch"] = false,
					["Transparency"] = 1,
					["Size"] = Vector3.new(0.2, 0.2, 0.2),
					["Parent"] = nil,
					["Name"] = "FoamZone" .. v285,
					["Parent"] = v_u_39
				})
				local v287 = v_u_13.new("BillboardGui", {
					["Size"] = nil,
					["AlwaysOnTop"] = true,
					["LightInfluence"] = 0,
					["Adornee"] = nil,
					["Parent"] = nil,
					["Size"] = UDim2.fromOffset(50, 24),
					["Adornee"] = v286,
					["Parent"] = v286
				})
				local v288 = v_u_13.new("Frame", {
					["Size"] = nil,
					["BackgroundColor3"] = nil,
					["BackgroundTransparency"] = 0.15,
					["Parent"] = nil,
					["Size"] = UDim2.fromScale(1, 1),
					["BackgroundColor3"] = v_u_22,
					["Parent"] = v287
				})
				v_u_13.corner(v288, 12)
				local v289 = {
					["Text"] = "0%",
					["TextSize"] = 13,
					["FontFace"] = nil,
					["TextColor3"] = nil,
					["Size"] = nil,
					["Parent"] = nil,
					["FontFace"] = v_u_13.FONT_HEAVY,
					["TextColor3"] = Color3.fromRGB(20, 20, 22),
					["Size"] = UDim2.fromScale(1, 1),
					["Parent"] = v288
				}
				v289.FontFace = v289.FontFace or v_u_13.FONT_BOLD
				local v290 = {
					["part"] = v286,
					["pill"] = v288,
					["pc"] = v_u_13.text(v289)
				}
				v_u_246.foamMarks[v285] = v290
			end
		end
		local v291 = v_u_246.chassis.CFrame
		for v292, v293 in v_u_246.foamMarks do
			v293.part.CFrame = CFrame.new(v291 * v_u_246.zones.centers[v292])
			local v294 = v284[v292] or 0
			local v295 = math.floor(v294)
			local v296 = v295 >= 100
			local v297 = v293.pill
			local v298
			if v296 then
				v298 = Color3.new(1, 1, 1)
			else
				v298 = v_u_22
			end
			v297.BackgroundColor3 = v298
			v293.pill.BackgroundTransparency = v296 and 0.45 or 0.15
			v293.pc.Text = v296 and "\226\156\147" or ("%d%%"):format(v295)
		end
	elseif v_u_246 and v_u_246.foamMarks then
		for _, v299 in v_u_246.foamMarks do
			v299.part:Destroy()
		end
		v_u_246.foamMarks = nil
	end
end
local v_u_301 = nil
local function v_u_303(p302) -- name: beginSession
	-- upvalues: (ref) v_u_248, (copy) v_u_44, (ref) v_u_246, (ref) v_u_259, (ref) v_u_260, (ref) v_u_261, (ref) v_u_263, (copy) v_u_274, (copy) v_u_283, (ref) v_u_301, (copy) v_u_158, (copy) v_u_120, (copy) v_u_21, (copy) v_u_122, (copy) v_u_10, (ref) v_u_264, (copy) v_u_270, (copy) v_u_236
	v_u_248 = nil
	v_u_44.setOpen(false)
	v_u_246 = p302
	v_u_259 = false
	v_u_260 = false
	v_u_261 = false
	v_u_263 = 0
	v_u_274(false)
	if v_u_246.kind then
		v_u_283()
		v_u_301(true)
	end
	v_u_158()
	v_u_120.Visible = v_u_21
	v_u_122.Text = v_u_10.ICONS[v_u_246.tool] or ""
	v_u_264 = nil
	v_u_270()
	v_u_236()
end
local v_u_304 = {
	["done"] = { v_u_11.waxDone, "ok" },
	["stepdone"] = { v_u_11.stepDone, "ok" },
	["stop"] = { v_u_11.stopped, "info" },
	["abort"] = { v_u_11.cancelled, "error" },
	["cancel"] = { v_u_11.cancelled, "info" }
}
local function v_u_309(p305) -- name: endSession
	-- upvalues: (ref) v_u_262, (copy) v_u_38, (copy) v_u_15, (ref) v_u_246, (ref) v_u_301, (ref) v_u_261, (ref) v_u_264, (copy) v_u_270, (copy) v_u_43, (ref) v_u_245, (copy) v_u_111, (copy) v_u_120, (copy) v_u_125, (copy) v_u_274, (copy) v_u_236, (copy) v_u_304, (copy) v_u_14
	if v_u_262 then
		v_u_262 = false
		v_u_38("Spraying", false)
	end
	local v306 = v_u_15.Character
	if v306 then
		v306 = v306:FindFirstChildOfClass("Humanoid")
	end
	if v306 and not v306.AutoRotate then
		v306.AutoRotate = true
	end
	if v_u_246 and v_u_246.markers then
		for _, v307 in v_u_246.markers do
			v307.part:Destroy()
		end
		v_u_246.markers = nil
	end
	if v_u_246 and v_u_246.foamMarks then
		for _, v308 in v_u_246.foamMarks do
			v308.part:Destroy()
		end
		v_u_246.foamMarks = nil
	end
	v_u_301(false)
	v_u_246 = nil
	v_u_261 = false
	v_u_264 = nil
	v_u_270()
	v_u_43:Stop()
	if v_u_245 ~= nil then
		v_u_245 = nil
		v_u_111.Visible = false
	end
	v_u_120.Visible = false
	v_u_125.Visible = false
	v_u_274(true)
	v_u_236()
	if p305 then
		p305 = v_u_304[p305]
	end
	if p305 then
		v_u_14.show(p305[1], p305[2])
	end
end
v110.Activated:Connect(function()
	-- upvalues: (ref) v_u_246, (copy) v_u_35
	if v_u_246 then
		task.spawn(v_u_35, "Stop")
	end
end)
v_u_120.InputBegan:Connect(function(p310)
	-- upvalues: (ref) v_u_261, (ref) v_u_264, (copy) v_u_270
	if p310.UserInputType == Enum.UserInputType.Touch or p310.UserInputType == Enum.UserInputType.MouseButton1 then
		if v_u_261 then
			v_u_261 = false
			v_u_264 = nil
		else
			local v311 = os.clock()
			v_u_261 = true
			v_u_264 = v311
		end
		v_u_270()
	end
end)
v_u_120.InputEnded:Connect(function(p312)
	-- upvalues: (ref) v_u_264, (ref) v_u_261, (copy) v_u_270
	if p312.UserInputType == Enum.UserInputType.Touch or p312.UserInputType == Enum.UserInputType.MouseButton1 then
		if v_u_264 and os.clock() - v_u_264 > 0.35 then
			v_u_261 = false
			v_u_270()
		end
		v_u_264 = nil
	end
end)
v_u_8.InputBegan:Connect(function(p313, p314)
	-- upvalues: (ref) v_u_246, (ref) v_u_259, (copy) v_u_35
	if v_u_246 then
		if p313.UserInputType == Enum.UserInputType.MouseButton1 and not p314 then
			v_u_259 = true
		elseif p313.KeyCode == Enum.KeyCode.X and not p314 then
			task.spawn(v_u_35, "Stop")
		end
	else
		return
	end
end)
v_u_8.InputEnded:Connect(function(p315)
	-- upvalues: (ref) v_u_259
	if p315.UserInputType == Enum.UserInputType.MouseButton1 then
		v_u_259 = false
	end
end)
local v_u_316 = Enum.KeyCode.G
v_u_301 = function(p317)
	-- upvalues: (copy) v_u_3, (ref) v_u_260, (copy) v_u_316
	if p317 then
		v_u_3:BindActionAtPriority("CarWashRub", function(_, p318)
			-- upvalues: (ref) v_u_260
			if p318 == Enum.UserInputState.Begin then
				v_u_260 = true
			elseif p318 == Enum.UserInputState.End or p318 == Enum.UserInputState.Cancel then
				v_u_260 = false
			end
			return Enum.ContextActionResult.Sink
		end, false, Enum.ContextActionPriority.High.Value + 50, v_u_316)
	else
		v_u_3:UnbindAction("CarWashRub")
		v_u_260 = false
	end
end
local v_u_319 = RaycastParams.new()
v_u_319.FilterType = Enum.RaycastFilterType.Include
local function v_u_334(p320, p321, p322, p323) -- name: segment
	local v324 = 0
	local v325 = (1 / 0)
	for _, v326 in { Vector3.new(1, 0, 0), Vector3.new(0, 1, 0), Vector3.new(0, 0, 1) } do
		local v327 = p320:Dot(v326)
		local v328 = p321:Dot(v326)
		local v329 = p322:Dot(v326)
		local v330 = p323:Dot(v326)
		if math.abs(v328) < 1e-6 then
			if v327 >= v329 and v330 >= v327 then
				continue
			end
			return nil
		end
		local v331 = (v329 - v327) / v328
		local v332 = (v330 - v327) / v328
		if v332 >= v331 then
			local v333 = v331
			v331 = v332
			v332 = v333
		end
		v324 = math.max(v324, v332)
		v325 = math.min(v325, v331)
		if v325 >= v324 then
			continue
		end
		return nil
	end
	return v324, v325
end
local function v_u_349(p335) -- name: aimAt
	-- upvalues: (copy) v_u_319, (ref) v_u_246, (copy) v_u_334, (copy) v_u_10
	v_u_319.FilterDescendantsInstances = { v_u_246.vehicle }
	local v336 = workspace:Raycast(p335.Origin, p335.Direction * 400, v_u_319)
	if v336 then
		return v336.Position, v336.Normal
	end
	local v337 = v_u_246.mn
	if typeof(v337) == "Vector3" then
		local v338 = v_u_246.mx
		if typeof(v338) == "Vector3" then
			local v339 = v_u_246.chassis.CFrame
			local v340 = p335.Direction.Unit
			local v341, v342 = v_u_334(v339:PointToObjectSpace(p335.Origin), v339:VectorToObjectSpace(v340), v_u_246.mn - Vector3.new(2, 2, 2), v_u_246.mx + Vector3.new(2, 2, 2))
			if not v341 then
				return nil, nil
			end
			if not v_u_246.parts then
				v_u_246.parts = v_u_10.bodyParts(v_u_246.vehicle)
			end
			local v343, v344 = v_u_10.rayParts(v_u_246.parts, p335.Origin, v340, v342 + 0.5)
			if v343 then
				return v343, v344
			end
			local v345 = (v342 - v341) / 60
			local v346 = {}
			for v347 = v341, v342, math.max(0.35, v345) do
				local v348 = p335.Origin + v340 * v347
				table.insert(v346, v348)
			end
			return v_u_10.nearParts(v_u_246.parts, v346, 2)
		end
	end
	return nil, nil
end
local function v_u_373(p350) -- name: autoAim
	-- upvalues: (ref) v_u_246, (copy) v_u_349
	local v351 = v_u_246.mn
	if typeof(v351) == "Vector3" then
		local v352 = v_u_246.mx
		if typeof(v352) == "Vector3" then
			local v353 = os.clock()
			local v354 = v_u_246.mn.X
			local v355 = v_u_246.mx.X
			local v356 = v353 * 1.9
			local v357 = math.sin(v356) * 0.42 + 0.5
			local v358 = v354 + (v355 - v354) * v357
			local v359 = v_u_246.mn.Y
			local v360 = v_u_246.mx.Y
			local v361 = v353 * 2.6
			local v362 = math.sin(v361) * 0.3 + 0.45
			local v363 = v359 + (v360 - v359) * v362
			local v364 = v_u_246.mn.Z
			local v365 = v_u_246.mx.Z
			local v366 = v353 * 1.3 + 1
			local v367 = math.sin(v366) * 0.42 + 0.5
			local v368 = v364 + (v365 - v364) * v367
			local v369 = Vector3.new(v358, v363, v368)
			local v370 = v_u_246.chassis.CFrame * v369
			local v371 = p350.Position + Vector3.new(0, 1.2, 0)
			local v372 = v370 - v371
			if v372.Magnitude < 0.2 then
				return nil, nil
			else
				return v_u_349(Ray.new(v371, v372.Unit))
			end
		end
	end
	return nil, nil
end
local function v_u_397(p374, p375) -- name: runSpray
	-- upvalues: (copy) v_u_300, (ref) v_u_246, (copy) v_u_10, (ref) v_u_259, (ref) v_u_261, (copy) v_u_125, (copy) v_u_21, (ref) v_u_262, (copy) v_u_38, (copy) v_u_15, (copy) v_u_11, (copy) v_u_8, (copy) v_u_349, (copy) v_u_373, (ref) v_u_263
	v_u_300()
	local v376 = (p375.Position - v_u_246.hose.WorldPosition).Magnitude > v_u_10.HOSE_LENGTH + v_u_10.HOSE_SLACK
	local v377 = v_u_259 or v_u_261
	v_u_125.Visible = v_u_21
	if v376 then
		if v_u_262 then
			v_u_262 = false
			v_u_38("Spraying", false)
		end
		local v378 = v_u_15.Character
		if v378 then
			v378 = v378:FindFirstChildOfClass("Humanoid")
		end
		if v378 and not v378.AutoRotate then
			v378.AutoRotate = true
		end
		return "!", v_u_11.tooFar
	elseif v377 then
		local v379 = workspace.CurrentCamera
		local v380
		if v_u_21 or v_u_8.MouseBehavior == Enum.MouseBehavior.LockCenter then
			v380 = v379.ViewportSize / 2
		else
			v380 = v_u_8:GetMouseLocation()
		end
		local v381 = v379:ViewportPointToRay(v380.X, v380.Y)
		local v382, v383 = v_u_349(v381)
		local v384, v385
		if v_u_21 and (not v382 or (v382 - p375.Position).Magnitude > v_u_10.SPRAY_RANGE) then
			v384, v385 = v_u_373(p375)
			if v384 then
				if not v385 then
					v385 = v383
					v384 = v382
				end
			else
				v385 = v383
				v384 = v382
			end
		else
			v385 = v383
			v384 = v382
		end
		local v386 = v384 or v381.Origin + v381.Direction * 30
		local v387 = v_u_15.Character
		if v387 then
			v387 = v387:FindFirstChildOfClass("Humanoid")
		end
		if v387 then
			v387.AutoRotate = false
		end
		local v388 = v386.X
		local v389 = p375.Position.Y
		local v390 = v386.Z
		local v391 = Vector3.new(v388, v389, v390)
		if (v391 - p375.Position).Magnitude > 0.5 then
			p375.CFrame = CFrame.lookAt(p375.Position, v391)
		end
		local v392
		if v384 == nil then
			v392 = false
		else
			v392 = (v384 - p375.Position).Magnitude <= v_u_10.SPRAY_RANGE
		end
		v_u_263 = v_u_263 + p374
		if v_u_263 >= v_u_10.SPRAY_TICK then
			v_u_263 = 0
			if v392 then
				local v393 = v_u_246.chassis.CFrame
				v_u_38("Spray", v_u_246.tool, v393:PointToObjectSpace(v384), v393:VectorToObjectSpace(v385))
				v_u_262 = true
			elseif v_u_262 then
				v_u_262 = false
				v_u_38("Spraying", false)
			end
		end
		if v392 then
			if v_u_21 then
				return v_u_10.ICONS[v_u_246.tool], v_u_11.sprayingTouch
			else
				return nil, nil
			end
		else
			local v394 = not v_u_21 and "LMB" or v_u_10.ICONS[v_u_246.tool]
			if v_u_21 then
				return v394, v_u_11.nearCarTouch
			else
				return v394, v_u_11.aimCar
			end
		end
	else
		if v_u_262 then
			v_u_262 = false
			v_u_38("Spraying", false)
		end
		local v395 = v_u_15.Character
		if v395 then
			v395 = v395:FindFirstChildOfClass("Humanoid")
		end
		if v395 and not v395.AutoRotate then
			v395.AutoRotate = true
		end
		local v396 = not v_u_21 and "LMB" or v_u_10.ICONS[v_u_246.tool]
		if v_u_21 then
			return v396, v_u_11.tapSprayTouch
		else
			return v396, v_u_11.holdSpray
		end
	end
end
local function v_u_418(p398, p399) -- name: runSpots
	-- upvalues: (copy) v_u_125, (ref) v_u_247, (ref) v_u_246, (copy) v_u_22, (copy) v_u_10, (copy) v_u_43, (copy) v_u_11, (copy) v_u_21, (copy) v_u_316, (ref) v_u_260, (ref) v_u_261, (ref) v_u_263, (copy) v_u_38
	v_u_125.Visible = false
	local v400 = v_u_247.spots or {
		0,
		0,
		0,
		0
	}
	local v401 = v_u_246.chassis.CFrame
	local v402 = nil
	local v403 = nil
	for v404, v405 in v_u_246.markers or {} do
		local v406 = v401 * v_u_246.spots[v404]
		v405.part.CFrame = CFrame.new(v406)
		local v407 = (v400[v404] or 0) >= 100
		local v408 = v405.ring
		local v409
		if v407 then
			v409 = Color3.new(1, 1, 1)
		else
			v409 = v_u_22
		end
		v408.BackgroundColor3 = v409
		v405.ring.BackgroundTransparency = v407 and 0.75 or 0.55
		local v410 = v405.stroke
		local v411
		if v407 then
			v411 = Color3.new(1, 1, 1)
		else
			v411 = v_u_22
		end
		v410.Color = v411
		v405.stroke.Transparency = v407 and 0.5 or 0
		local v412 = v405.pc
		local v413 = v400[v404] or 0
		v412.Text = ("%d%%"):format((math.floor(v413)))
		if v407 then
			continue
		end
		local v414 = v406.X - p399.Position.X
		local v415 = v406.Z - p399.Position.Z
		local v416 = Vector3.new(v414, 0, v415).Magnitude
		if v416 > v_u_10.SPOT_RADIUS or v402 and v416 >= v402 then
			continue
		end
		v403 = v404
		v402 = v416
	end
	if v403 then
		local v417
		if v_u_21 then
			v417 = v_u_10.ICONS[v_u_246.tool]
		else
			v417 = v_u_316.Name
		end
		if v_u_260 or v_u_261 then
			if not v_u_43.IsPlaying then
				v_u_43:Play()
			end
			v_u_263 = v_u_263 + p398
			if v_u_263 >= v_u_10.SPRAY_TICK then
				v_u_263 = 0
				v_u_38("Rub", v403)
			end
		else
			v_u_43:Stop()
		end
		if v_u_21 then
			if v_u_261 then
				return v417, v_u_11.rubbingTouch
			else
				return v417, v_u_11.tapRubTouch
			end
		else
			return v417, v_u_11["hold_" .. v_u_246.tool]
		end
	else
		v_u_43:Stop()
		return nil, v_u_11.goToSpot
	end
end
v6.RenderStepped:Connect(function(p419)
	-- upvalues: (ref) v_u_246, (copy) v_u_15, (ref) v_u_245, (copy) v_u_111, (copy) v_u_10, (copy) v_u_397, (copy) v_u_418, (ref) v_u_244, (copy) v_u_114, (copy) v_u_116
	if v_u_246 then
		local v420 = v_u_15.Character
		if v420 then
			v420 = v420:FindFirstChild("HumanoidRootPart")
		end
		if v420 and (v_u_246.chassis and (v_u_246.chassis.Parent and (v_u_246.hose and v_u_246.hose.Parent))) then
			local v421, v422
			if v_u_10.SPRAY_TOOLS[v_u_246.tool] then
				v421, v422 = v_u_397(p419, v420)
			else
				v421, v422 = v_u_418(p419, v420)
			end
			local v423
			if v422 then
				v423 = (v421 or "") .. "|" .. v422
			else
				v423 = nil
			end
			if v423 ~= v_u_245 then
				v_u_245 = v423
				if v422 ~= nil and (not v_u_111.Visible and v_u_244) then
					v_u_244()
				end
				v_u_111.Visible = v422 ~= nil
				if v422 then
					v_u_114.Text = v421 or "E"
					v_u_116.Text = v422
				end
			end
		elseif v_u_245 ~= nil then
			v_u_245 = nil
			v_u_111.Visible = false
		end
	else
		return
	end
end)
task.spawn(function()
	-- upvalues: (copy) v_u_44, (ref) v_u_248, (copy) v_u_15, (copy) v_u_10, (copy) v_u_35
	while true do
		repeat
			task.wait(0.3)
		until v_u_44.isOpen() and v_u_248
		local v424 = v_u_15.Character
		if v424 then
			v424 = v424:FindFirstChild("HumanoidRootPart")
		end
		local v425 = v_u_248:FindFirstChild("CarWashPrompt", true)
		if v425 then
			v425 = v425.Parent
		end
		local v426
		if v425 and v425:IsA("Attachment") then
			v426 = v425.WorldPosition
		elseif v_u_248.PrimaryPart then
			v426 = v_u_248.PrimaryPart.Position
		else
			v426 = nil
		end
		if v424 and (v426 and (v424.Position - v426).Magnitude <= v_u_10.MACHINE_REACH + 4) then
			continue
		end
		local v427 = v_u_248
		v_u_248 = nil
		if v_u_44.isOpen() then
			v_u_44.setOpen(false)
		end
		if not v427 then
			continue
		end
		task.spawn(v_u_35, "Close", v427)
	end
end)
local v_u_428 = Color3.fromRGB(250, 252, 255)
local v_u_429 = {
	["min"] = 4,
	["max"] = 7,
	["rMin"] = 0.1,
	["rMax"] = 0.26,
	["spread"] = 0.45,
	["see"] = nil,
	["see"] = { 0.2, 0.5 }
}
local v_u_430 = {}
local v_u_431 = {}
local function v_u_437(p432, p433, p434) -- name: foamCF
	local v435 = p433.Y
	local v436 = (math.abs(v435) < 0.95 and Vector3.new(0, 1, 0) or Vector3.new(1, 0, 0)):Cross(p433).Unit
	return CFrame.fromMatrix(p432, v436, p433, v436:Cross(p433)) * CFrame.Angles(0, math.rad(p434 or 0), 0)
end
local function v_u_456(p438, p439, p440, p441, p442) -- name: addFoam
	-- upvalues: (copy) v_u_10, (copy) v_u_430, (copy) v_u_437, (copy) v_u_429, (copy) v_u_428, (copy) v_u_39, (copy) v_u_7
	if typeof(p438) == "Instance" and (p438.Parent and (typeof(p440) == "Vector3" and typeof(p441) == "Vector3")) then
		local v443 = v_u_10.chassisOf(p438)
		if v443 then
			local v444 = v_u_430[p438]
			if not v444 then
				v444 = {
					["chassis"] = v443,
					["items"] = {}
				}
				v_u_430[p438] = v444
			end
			if not v444.items[p439] then
				local v445 = Random.new((tonumber(p439) or 0) * 7919 + 17)
				local v446 = v_u_437(p440, p441, p442)
				local v447 = {}
				for _ = 1, v445:NextInteger(v_u_429.min, v_u_429.max) do
					local v448 = v445:NextNumber(v_u_429.rMin, v_u_429.rMax)
					local v449 = v445:NextNumber(0, 6.283185307179586)
					local v450 = v_u_429.spread
					local v451 = v445:NextNumber()
					local v452 = v450 * math.sqrt(v451)
					local v453 = v446 * CFrame.new(math.cos(v449) * v452, v448 * 0.3, math.sin(v449) * v452)
					local v454 = Instance.new("Part")
					v454.Name = "Bubble"
					v454.Shape = Enum.PartType.Ball
					v454.Size = Vector3.new(1, 1, 1) * (v448 * 2)
					v454.Color = v_u_428
					v454.Material = Enum.Material.SmoothPlastic
					v454.Reflectance = 0.25
					v454.Anchored = true
					v454.CanCollide = false
					v454.CanQuery = false
					v454.CanTouch = false
					v454.CastShadow = false
					v454.TopSurface = Enum.SurfaceType.Smooth
					v454.BottomSurface = Enum.SurfaceType.Smooth
					v454.CFrame = v443.CFrame * v453
					v454.Transparency = 1
					v454.Parent = v_u_39
					local v455 = {
						["Transparency"] = v445:NextNumber(v_u_429.see[1], v_u_429.see[2])
					}
					v_u_7:Create(v454, TweenInfo.new(0.3), v455):Play()
					table.insert(v447, {
						["part"] = v454,
						["lcf"] = v453
					})
				end
				v444.items[p439] = {
					["bubbles"] = v447
				}
				v444.at = v443.CFrame
			end
		else
			return
		end
	else
		return
	end
end
local function v_u_460(p457) -- name: dropFoam
	-- upvalues: (copy) v_u_7
	for _, v_u_458 in p457.bubbles do
		local v459 = v_u_7:Create(v_u_458.part, TweenInfo.new(0.35), {
			["Transparency"] = 1
		})
		v459.Completed:Connect(function()
			-- upvalues: (copy) v_u_458
			v_u_458.part:Destroy()
		end)
		v459:Play()
	end
end
local function v_u_466(p461, p462) -- name: removeFoam
	-- upvalues: (copy) v_u_430, (copy) v_u_460
	local v463 = v_u_430[p461]
	if v463 and type(p462) == "table" then
		for _, v464 in p462 do
			local v465 = v463.items[v464]
			if not v465 then
				continue
			end
			v463.items[v464] = nil
			v_u_460(v465)
		end
	end
end
v6.Heartbeat:Connect(function()
	-- upvalues: (copy) v_u_430
	for v467, v468 in v_u_430 do
		if v467.Parent and v468.chassis.Parent then
			local v469 = v468.chassis.CFrame
			if v468.at == v469 then
				continue
			end
			v468.at = v469
			local v470 = {}
			local v471 = {}
			for _, v472 in v468.items do
				for _, v473 in v472.bubbles do
					local v474 = v473.part
					table.insert(v470, v474)
					local v475 = v469 * v473.lcf
					table.insert(v471, v475)
				end
			end
			if #v470 <= 0 then
				break
			end
			workspace:BulkMoveTo(v470, v471, Enum.BulkMoveMode.FireCFrameChanged)
		else
			for _, v476 in v468.items do
				for _, v477 in v476.bubbles do
					v477.part:Destroy()
				end
			end
			v_u_430[v467] = nil
		end
	end
end)
v19.OnClientEvent:Connect(function(p478, p479, p480, p481, p482, p483)
	-- upvalues: (ref) v_u_246, (ref) v_u_248, (ref) v_u_247, (copy) v_u_213, (copy) v_u_44, (copy) v_u_42, (copy) v_u_236, (copy) v_u_303, (copy) v_u_309, (copy) v_u_14, (copy) v_u_456, (copy) v_u_466, (copy) v_u_430, (copy) v_u_460
	if p478 == "open" then
		if not v_u_246 then
			v_u_248 = p479
			v_u_247 = p480 or v_u_247
			v_u_213()
			v_u_44.setOpen(true)
			local v484 = v_u_42.open
			if v484 then
				v484:Play()
				return
			end
		end
	else
		if p478 == "job" then
			v_u_247 = p479 or v_u_247
			v_u_213()
			v_u_236()
			return
		end
		if p478 == "session" then
			if p479 then
				v_u_303(p479)
			else
				v_u_309(p480)
			end
		end
		if p478 == "toast" then
			v_u_14.show(p479, p480)
			return
		end
		if p478 == "sfx" then
			local v485 = v_u_42[p479]
			if v485 then
				v485:Play()
				return
			end
		else
			if p478 == "foamAdd" then
				v_u_456(p479, p480, p481, p482, p483)
				return
			end
			if p478 == "foamRemove" then
				v_u_466(p479, p480)
				return
			end
			if p478 == "foamClear" then
				local v486 = v_u_430[p479]
				if not v486 then
					return
				end
				v_u_430[p479] = nil
				for _, v487 in v486.items do
					v_u_460(v487)
				end
			end
		end
	end
end)
local v_u_488 = {
	["gun"] = {
		["shoulder"] = { 80, 0, 0 },
		["elbow"] = { 4, 0, 0 }
	},
	["hold"] = {
		["shoulder"] = { 35, 0, 0 },
		["elbow"] = { 35, 0, 0 }
	},
	["rub"] = {
		["shoulder"] = nil,
		["elbow"] = nil,
		["swing"] = 18,
		["shoulder"] = { 72, 0, 0 },
		["elbow"] = { 22, 0, 0 }
	}
}
local v_u_489 = setmetatable({}, {
	["__mode"] = "k"
})
local function v_u_494(p490) -- name: jointsOf
	-- upvalues: (copy) v_u_489
	local v491 = v_u_489[p490]
	if v491 and (v491.shoulder and v491.shoulder.Parent) then
		return v491
	end
	local v492 = {}
	for _, v493 in p490:GetDescendants() do
		if not (v493:IsA("AnimationConstraint") or v493:IsA("Motor6D")) then
			continue
		end
		if v493.Name == "RightShoulder" then
			v492.shoulder = v493
		elseif v493.Name == "RightElbow" then
			v492.elbow = v493
		elseif v493.Name == "LeftShoulder" then
			v492.leftShoulder = v493
		else
			if v493.Name ~= "LeftElbow" then
				continue
			end
			v492.leftElbow = v493
		end
	end
	v_u_489[p490] = v492
	return v492
end
local v_u_495 = math.rad
local v_u_496 = { 0.2, 0.45, 0.7 }
local v_u_497 = {}
local function v_u_501(p498) -- name: waxPuff
	local v_u_499 = p498:FindFirstChild("CarWashTool")
	if v_u_499 then
		v_u_499 = v_u_499.PrimaryPart
	end
	local v500
	if v_u_499 then
		v500 = v_u_499:FindFirstChild("Nozzle")
	else
		v500 = v_u_499
	end
	if v500 then
		v500 = v500:FindFirstChild("Mist")
	end
	if v500 then
		v500:Emit(14)
	end
	if v_u_499 then
		v_u_499 = v_u_499:FindFirstChild("Psst")
	end
	if v_u_499 then
		v_u_499.TimePosition = 0
		v_u_499:Play()
		task.delay(0.16, function()
			-- upvalues: (copy) v_u_499
			v_u_499:Stop()
		end)
	end
end
local function v_u_512(p502, p503, p504) -- name: waxArms
	-- upvalues: (copy) v_u_497, (copy) v_u_496, (copy) v_u_501, (copy) v_u_495
	local v505 = v_u_497[p502]
	if not v505 then
		v505 = {
			["start"] = nil,
			["last"] = -1,
			["start"] = p504
		}
		v_u_497[p502] = v505
	end
	local v506 = (p504 - v505.start) % 2.7
	if v506 < v505.last then
		v505.last = -1
	end
	if v506 < 1 then
		local v507 = 0
		for _, v508 in v_u_496 do
			if v505.last < v508 and v508 <= v506 then
				v_u_501(p502)
			end
			local v509 = v506 - v508
			if v509 < 0 or v509 >= 0.12 then
				continue
			end
			local v510 = v509 / 0.12 * 3.141592653589793
			v507 = math.sin(v510)
		end
		if p503.shoulder then
			p503.shoulder.Transform = CFrame.Angles(v_u_495(v507 * 4 + 86), 0, -0.10471975511965978)
		end
		if p503.elbow then
			p503.elbow.Transform = CFrame.Angles(v_u_495(v507 * 10 + 6), 0, 0)
		end
	else
		local v511 = (v506 - 1) * 9
		if p503.shoulder then
			p503.shoulder.Transform = CFrame.Angles(0.6108652381980153, 0, 0)
		end
		if p503.elbow then
			p503.elbow.Transform = CFrame.Angles(0.6108652381980153, 0, 0)
		end
		if p503.leftShoulder then
			p503.leftShoulder.Transform = CFrame.Angles(v_u_495(math.sin(v511) * 6 + 72), v_u_495(math.cos(v511) * 6), (v_u_495(-math.cos(v511) * 16)))
		end
		if p503.leftElbow then
			p503.leftElbow.Transform = CFrame.Angles(v_u_495(math.sin(v511) * 12 + 24), 0, 0)
		end
	end
	v505.last = v506
end
v6.Stepped:Connect(function(p513)
	-- upvalues: (copy) v_u_497, (copy) v_u_4, (copy) v_u_488, (copy) v_u_512, (copy) v_u_494, (copy) v_u_495
	for v514 in v_u_497 do
		if v514.Parent then
			continue
		end
		v_u_497[v514] = nil
	end
	for _, v515 in v_u_4:GetPlayers() do
		local v516 = v515.Character
		local v517
		if v516 then
			v517 = v516:GetAttribute("CarWashPose")
		else
			v517 = v516
		end
		if v516 and (v517 ~= "waxrub" and v_u_497[v516]) then
			v_u_497[v516] = nil
		end
		local v518
		if v516 then
			v518 = v_u_488[v517]
		else
			v518 = v516
		end
		if v517 == "waxrub" then
			v_u_512(v516, v_u_494(v516), p513)
		else
			if not v518 then
				continue
			end
			local v519 = v_u_494(v516)
			local v520
			if v518.swing then
				local v521 = p513 * 11
				v520 = math.sin(v521) * v518.swing
			else
				v520 = 0
			end
			if v519.shoulder then
				v519.shoulder.Transform = CFrame.Angles(v_u_495(v518.shoulder[1]), v_u_495(v520 * 0.4), (v_u_495(v518.shoulder[3] + v520)))
			end
			if not v519.elbow then
				continue
			end
			v519.elbow.Transform = CFrame.Angles(v_u_495(v518.elbow[1] + v520 * 0.5), 0, 0)
		end
	end
end)
local v_u_522 = Color3.fromRGB(40, 190, 70)
local v_u_523 = Color3.fromRGB(110, 255, 140)
local v_u_524 = {}
local function v_u_532(p525) -- name: machineLook
	-- upvalues: (copy) v_u_524
	local v526 = v_u_524[p525]
	if v526 and v526.main.Parent then
		return v526
	end
	local v527 = p525:FindFirstChild("CoinMachine")
	local v528
	if v527 then
		v528 = v527:FindFirstChild("Display")
	else
		v528 = v527
	end
	if v528 then
		v528 = v528:FindFirstChild("Back", true)
	end
	if not (v528 and (v528:FindFirstChild("Main") and v528:FindFirstChild("Sub"))) then
		return nil
	end
	local v529 = {
		["main"] = v528.Main,
		["sub"] = v528.Sub,
		["buttons"] = {}
	}
	for _, v530 in v527:GetChildren() do
		local v531 = v530:GetAttribute("Option")
		if not v531 then
			continue
		end
		v529.buttons[v531] = v530
	end
	v_u_524[p525] = v529
	return v529
end
local v_u_533 = {}
local function v_u_554(p534, p535) -- name: setIdleHose
	-- upvalues: (copy) v_u_533, (copy) v_u_524, (copy) v_u_39, (copy) v_u_20
	local v536 = v_u_533[p534]
	if p534.Parent then
		if p535 then
			if v536 then
				if v536.Parent ~= v_u_39 then
					v536.Parent = v_u_39
				end
				return
			else
				local v537 = p534:FindFirstChild("Hose")
				local v538 = p534:FindFirstChild("Bay")
				local v539 = p534:FindFirstChild("CoinMachine")
				if v539 then
					v539 = v539:FindFirstChild("Cabinet")
				end
				local v540 = v_u_20:FindFirstChild("GunWater")
				if v537 and (v537.Value and (v538 and (v538.Value and (v539 and v540)))) then
					local v541 = v540:Clone()
					v541.Name = "IdleGun"
					for _, v542 in v541:GetDescendants() do
						if v542:IsA("BasePart") then
							v542.Anchored = true
							v542.CanCollide = false
							v542.CanQuery = false
							v542.CanTouch = false
						else
							if not (v542:IsA("Sound") or v542:IsA("ParticleEmitter")) then
								continue
							end
							v542:Destroy()
						end
					end
					local v543 = v541.PrimaryPart
					local v544
					if v543 then
						v544 = v543:FindFirstChild("HoseIn")
					else
						v544 = v543
					end
					if v544 then
						local v545 = v539.CFrame
						local v546 = v545.RightVector
						local v547 = (v538.Value.Position - v545.Position):Dot(v545.RightVector)
						local v548 = v546 * math.sign(v547)
						local v549
						if v545.LookVector.X < 0 then
							v549 = v545.LookVector
						else
							v549 = -v545.LookVector
						end
						local v550 = v545.Position + v549 * (v539.Size.Z / 2 + 0.41) + v548 * (v539.Size.X / 2 - 0.22) - Vector3.new(0, 0.15, 0)
						local v551 = -v549
						v543.CFrame = CFrame.fromMatrix(v550, v551:Cross(Vector3.new(-0, -1, -0)), v551, Vector3.new(-0, -1, -0))
						local v552 = Instance.new("Part")
						v552.Name = "Holster"
						v552.Anchored = true
						v552.CanCollide = false
						v552.CanQuery = false
						v552.CanTouch = false
						v552.Size = Vector3.new(0.14, 0.34, 0.32)
						v552.Color = Color3.fromRGB(28, 28, 30)
						v552.Material = Enum.Material.Metal
						v552.CFrame = CFrame.fromMatrix(v545.Position + v549 * (v539.Size.Z / 2 + 0.07) + v548 * (v539.Size.X / 2 - 0.22) + Vector3.new(0, 0.62, 0), v549, Vector3.new(0, 1, 0))
						v552.Parent = v541
						v_u_533[p534] = v541
						v541.Parent = v_u_39
					else
						v541:Destroy()
					end
				else
					return
				end
			end
		else
			if v536 and v536.Parent then
				v536.Parent = nil
			end
			return
		end
	else
		if v536 then
			v536:Destroy()
		end
		local v553 = v_u_524
		v_u_533[p534] = nil
		v553[p534] = nil
		return
	end
end
local v_u_555 = game:GetService("Lighting")
local v_u_556 = {}
task.spawn(function()
	-- upvalues: (copy) v_u_555, (copy) v_u_2, (copy) v_u_10, (copy) v_u_556, (copy) v_u_532, (copy) v_u_554, (copy) v_u_11, (copy) v_u_184, (copy) v_u_523, (copy) v_u_522
	while true do
		task.wait(0.12)
		local v557 = workspace.CurrentCamera
		local v558 = os.clock() % 1 < 0.55
		local v559 = workspace:GetServerTimeNow()
		local v560 = v_u_555.ClockTime
		local v561 = v560 >= 18 and true or v560 < 6
		for _, v562 in v_u_2:GetTagged(v_u_10.SITE_TAG) do
			local v563 = v_u_556[v562]
			if not v563 or os.clock() - v563.at > 5 then
				v563 = {
					["at"] = os.clock(),
					["list"] = {}
				}
				for _, v564 in v562:GetDescendants() do
					if not (v564:IsA("SurfaceGui") and v564:GetAttribute("NightLI")) then
						continue
					end
					local v565 = v563.list
					table.insert(v565, v564)
				end
				v_u_556[v562] = v563
			end
			for _, v566 in v563.list do
				local v567 = v566:GetAttribute(v561 and "NightLI" or "DayLI")
				if typeof(v567) ~= "number" or v566.LightInfluence == v567 then
					continue
				end
				v566.LightInfluence = v567
			end
			local v568 = v562:FindFirstChild("Machines")
			for _, v569 in not v568 and {} or v568:GetChildren() do
				local v570 = v_u_532(v569)
				local v571 = v557 and v569.PrimaryPart
				if v571 then
					v571 = (v569.PrimaryPart.Position - v557.CFrame.Position).Magnitude < 160
				end
				local v572 = v569:FindFirstChild("Hose")
				local v573 = v_u_554
				local v574, v575
				if v571 then
					if v572 == nil or v572.Value == nil then
						v574 = v569
						v575 = false
					else
						local v576 = v572.Value
						v574 = v569
						for _, v577 in v_u_2:GetTagged(v_u_10.HOSE_TAG) do
							if v577.Attachment0 ~= v576 then
								continue
							end
							v578 = true
						end
						local v578 = false
						v575 = not v578
					end
				else
					v575 = v571
					v574 = v569
				end
				v573(v574, v575)
				if not (v570 and v571) then
					continue
				end
				local v579 = v569:GetAttribute("WashStep") or 0
				local v580 = v569:GetAttribute("WashDoneAt")
				local v581
				if v579 == 0 and typeof(v580) == "number" then
					v581 = v559 - v580 < 6
				else
					v581 = false
				end
				local v582
				if v579 >= 1 and v579 <= 6 then
					v582 = v_u_10.STEP_TOOLS[v579]
				else
					v582 = nil
				end
				if v581 then
					local v583 = v570.main
					if v583.Text ~= "DONE" then
						v583.Text = "DONE"
					end
					local v584 = v570.sub
					if v584.Text ~= "\224\184\130\224\184\173\224\184\154\224\184\132\224\184\184\224\184\147\224\184\151\224\184\181\224\185\136\224\185\131\224\184\138\224\185\137\224\184\154\224\184\163\224\184\180\224\184\129\224\184\178\224\184\163" then
						v584.Text = "\224\184\130\224\184\173\224\184\154\224\184\132\224\184\184\224\184\147\224\184\151\224\184\181\224\185\136\224\185\131\224\184\138\224\185\137\224\184\154\224\184\163\224\184\180\224\184\129\224\184\178\224\184\163"
					end
				elseif v582 then
					local v585 = v570.main
					local v586 = ("STEP %d/6"):format(v579)
					if v585.Text ~= v586 then
						v585.Text = v586
					end
					local v587 = v570.sub
					local v588 = ("%s %d%%"):format(v_u_11.options[v582] or "", v569:GetAttribute("WashPct") or 0)
					if v587.Text ~= v588 then
						v587.Text = v588
					end
				elseif v569:GetAttribute("StaffCustomer") and not v_u_184(v569) then
					local v589 = v570.main
					if v589.Text ~= "STAFF" then
						v589.Text = "STAFF"
					end
					local v590 = v570.sub
					if v590.Text ~= "\224\184\138\224\185\136\224\184\173\224\184\135\224\184\153\224\184\181\224\185\137\224\184\158\224\184\153\224\184\177\224\184\129\224\184\135\224\184\178\224\184\153\224\185\131\224\184\138\224\185\137\224\184\173\224\184\162\224\184\185\224\185\136" then
						v590.Text = "\224\184\138\224\185\136\224\184\173\224\184\135\224\184\153\224\184\181\224\185\137\224\184\158\224\184\153\224\184\177\224\184\129\224\184\135\224\184\178\224\184\153\224\185\131\224\184\138\224\185\137\224\184\173\224\184\162\224\184\185\224\185\136"
					end
				else
					local v591 = v570.main
					if v591.Text ~= "READY" then
						v591.Text = "READY"
					end
					local v592 = v570.sub
					local v593 = v558 and "\224\184\129\224\184\148 E" or ""
					if v592.Text ~= v593 then
						v592.Text = v593
					end
				end
				for v594, v595 in v570.buttons do
					if v594 == "stop" then
						continue
					end
					local v596
					if v558 then
						v596 = v594 == v582 and true or v581
					else
						v596 = v558
					end
					local v597
					if v596 then
						v597 = Enum.Material.Neon
					else
						v597 = Enum.Material.SmoothPlastic
					end
					if v595.Material ~= v597 then
						v595.Material = v597
					end
					local v598
					if v596 then
						v598 = v_u_523
					else
						v598 = v_u_522
					end
					if v595.Color == v598 then
						continue
					end
					v595.Color = v598
				end
			end
		end
	end
end)
local v_u_599 = {}
local v_u_600 = {}
local v_u_601 = Color3.fromRGB(104, 80, 54)
local v_u_602 = {}
local function v_u_612(p603) -- name: paintParts
	local v604 = {}
	for _, v605 in p603:GetDescendants() do
		local v606 = v605:IsA("BasePart")
		if v606 then
			v606 = v605:GetAttribute("PaintGroup")
		end
		if not v606 or (v606 == "Wheel" or v605:FindFirstChildOfClass("SurfaceAppearance")) then
			continue
		end
		table.insert(v604, v605)
	end
	if #v604 > 0 then
		return v604
	end
	for _, v611 in p603:GetDescendants() do
		if not v611:IsA("BasePart") or (v611.Transparency >= 0.3 or (v611:FindFirstChildOfClass("SurfaceAppearance") or (v611.Material == Enum.Material.Glass or (v611.Material == Enum.Material.Neon or v611.Material == Enum.Material.ForceField)))) then
			continue
		end
		local v608 = v611
		local v609 = false
		while v611 and (v611 ~= p603 and not v609) do
			local v610 = v611.Name:lower()
			v609 = (v610:find("wheel") ~= nil or (v610:find("tire") ~= nil or v610:find("tyre") ~= nil)) and true or v610:find("rim") ~= nil
			local v611 = v611.Parent
		end
		if v609 then
			break
		end
		table.insert(v604, v608)
	end
	return v604
end
local function v_u_625(p613, p614) -- name: setGloss
	-- upvalues: (copy) v_u_602, (copy) v_u_612, (copy) v_u_10
	local v615 = v_u_602[p613]
	if p614 <= 0 then
		if v615 then
			for v616, v617 in v615.parts do
				if not v616.Parent or v616.Reflectance ~= v617.set then
					continue
				end
				v616.Reflectance = v617.base
			end
			v_u_602[p613] = nil
		end
	else
		if not v615 then
			v615 = {
				["list"] = v_u_612(p613),
				["parts"] = {}
			}
			v_u_602[p613] = v615
		end
		local v618 = v_u_10.WAX.shine * math.clamp(p614, 0, 1)
		for _, v619 in v615.list do
			if not v619.Parent then
				continue
			end
			local v620 = v615.parts[v619]
			if not v620 or v619.Reflectance ~= v620.set then
				v620 = {
					["base"] = v619.Reflectance
				}
				v615.parts[v619] = v620
			end
			local v621 = v620.base + v618
			local v622 = math.clamp(v621, 0, 1) * 1000 + 0.5
			local v623 = math.floor(v622) / 1000
			local v624 = v619.Reflectance - v623
			if math.abs(v624) > 0.0005 then
				v619.Reflectance = v623
			end
			v620.set = v619.Reflectance
		end
	end
end
local function v_u_633(p626, p627) -- name: shineFor
	-- upvalues: (copy) v_u_600, (copy) v_u_10, (copy) v_u_13, (copy) v_u_39
	local v628 = v_u_600[p626]
	if v628 then
		return v628
	end
	local _, v629, v630 = v_u_10.spots(p626, p627)
	local v631 = v_u_13.new("Part", {
		["Name"] = "Shine",
		["Anchored"] = true,
		["CanCollide"] = false,
		["CanQuery"] = false,
		["CanTouch"] = false,
		["Transparency"] = 1,
		["Size"] = nil,
		["Parent"] = nil,
		["Size"] = v630 - v629 + Vector3.new(0.4, 0.2, 0.4),
		["Parent"] = v_u_39
	})
	v_u_13.new("ParticleEmitter", {
		["Texture"] = "rbxasset://textures/particles/sparkles_main.dds",
		["Shape"] = nil,
		["ShapeStyle"] = nil,
		["Rate"] = 5,
		["Lifetime"] = nil,
		["Speed"] = nil,
		["Size"] = nil,
		["LightEmission"] = 1,
		["Color"] = nil,
		["Rotation"] = nil,
		["Parent"] = nil,
		["Shape"] = Enum.ParticleEmitterShape.Box,
		["ShapeStyle"] = Enum.ParticleEmitterShapeStyle.Surface,
		["Lifetime"] = NumberRange.new(0.5, 0.9),
		["Speed"] = NumberRange.new(0, 0.2),
		["Size"] = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.4, 0.45), NumberSequenceKeypoint.new(1, 0) }),
		["Color"] = ColorSequence.new(Color3.fromRGB(255, 252, 232)),
		["Rotation"] = NumberRange.new(0, 360),
		["Parent"] = v631
	})
	local v632 = {
		["part"] = v631,
		["chassis"] = p627,
		["offset"] = CFrame.new((v629 + v630) / 2)
	}
	v_u_600[p626] = v632
	return v632
end
local v_u_634 = ColorSequence.new(Color3.fromRGB(18, 18, 20))
local v_u_635 = {}
local v_u_636 = RaycastParams.new()
v_u_636.FilterType = Enum.RaycastFilterType.Exclude
local v_u_637 = {}
local v_u_638 = RaycastParams.new()
v_u_638.FilterType = Enum.RaycastFilterType.Include
local function v_u_662(p639) -- name: vehicleTop
	-- upvalues: (copy) v_u_637, (copy) v_u_638, (copy) v_u_10
	local v640, v641 = p639:GetBoundingBox()
	local v642 = v_u_637[p639]
	if v642 and (os.clock() - v642.at < 3 and (v642.cf.Position - v640.Position).Magnitude < 0.2) then
		return v642
	end
	local v643 = v641.X / 2
	local v644 = v641.Y / 2
	local v645 = v641.Z / 2
	local v646 = v641.X / 1.2
	local v647 = math.ceil(v646)
	local v648 = math.clamp(v647, 2, 16)
	local v649 = v641.Z / 1.2
	local v650 = math.ceil(v649)
	local v651 = math.clamp(v650, 2, 16)
	local v652 = {
		["at"] = os.clock(),
		["cf"] = v640,
		["hx"] = v643,
		["hy"] = v644,
		["hz"] = v645,
		["nx"] = v648,
		["nz"] = v651,
		["cx"] = v641.X / v648,
		["cz"] = v641.Z / v651,
		["heights"] = {}
	}
	v_u_638.FilterDescendantsInstances = { p639 }
	local v653 = nil
	for v654 = 1, v651 do
		for v655 = 1, v648 do
			local v656 = -v643 + (v655 - 0.5) * v652.cx
			local v657 = -v645 + (v654 - 0.5) * v652.cz
			local v658 = v644 + 0.5
			local v659 = v640:PointToWorldSpace((Vector3.new(v656, v658, v657)))
			local v660 = -v640.UpVector
			local v661 = workspace:Raycast(v659, v660 * (v641.Y + 1), v_u_638)
			if v661 then
				v661 = v661.Position
			end
			if not v661 then
				v653 = v653 or v_u_10.bodyParts(p639)
				v661 = v_u_10.rayParts(v653, v659, v660, v641.Y + 1)
			end
			if not v661 then
				continue
			end
			v652.heights[(v654 - 1) * v648 + v655] = v640:PointToObjectSpace(v661).Y
		end
	end
	v_u_637[p639] = v652
	return v652
end
local function v_u_676(p663, p664) -- name: ropeSurroundings
	-- upvalues: (copy) v_u_39, (copy) v_u_4, (copy) v_u_636, (copy) v_u_10, (copy) v_u_662, (copy) v_u_637
	local v665 = { v_u_39 }
	for _, v666 in v_u_4:GetPlayers() do
		if not v666.Character then
			continue
		end
		local v667 = v666.Character
		table.insert(v665, v667)
	end
	local v668 = workspace:FindFirstChild("SpawnedVehicles")
	if v668 then
		table.insert(v665, v668)
	end
	v_u_636.FilterDescendantsInstances = v665
	local v669 = workspace:Raycast(p664, Vector3.new(0, -60, 0), v_u_636)
	local v670
	if v669 then
		v670 = v669.Position.Y + 0.09
	else
		v670 = p664.Y - 60
	end
	p663.floorY = v670
	p663.boxes = {}
	for _, v671 in not v668 and {} or v668:GetChildren() do
		local v672 = v671:IsA("Model")
		if v672 then
			v672 = v_u_10.chassisOf(v671)
		end
		if not v672 or (not v672:IsA("BasePart") or (v672.Position - p664).Magnitude >= 45) then
			continue
		end
		local v673 = p663.boxes
		local v674 = v_u_662(v671)
		table.insert(v673, v674)
	end
	for v675 in v_u_637 do
		if v675.Parent then
			continue
		end
		v_u_637[v675] = nil
	end
end
local function v_u_735(p677, p678) -- name: stepRope
	-- upvalues: (copy) v_u_10
	local v679 = p677.pts
	local v680 = p677.prev
	local v681 = p677.a0.WorldPosition
	local v682 = p677.a1.WorldPosition
	local v683 = (v682 - v681).Magnitude
	local v684
	if p677.idle then
		v684 = v683 * 1.05 + 2.5
	else
		local v685 = v683 * 1.15 + 7
		local v686 = v_u_10.HOSE_LENGTH + v_u_10.HOSE_SLACK
		v684 = math.min(v685, v686)
	end
	local v687 = v684 / 26
	local v688 = Vector3.new(0, -90, 0) * (p678 * p678)
	local v689 = p677.floorY
	for v690 = 1, 25 do
		local v691 = v679[v690]
		local v692 = (v691 - v680[v690]) * 0.97
		if v691.Y <= v689 + 0.02 then
			v692 = v692 * 0.4
		end
		v680[v690] = v691
		v679[v690] = v691 + v692 + v688
	end
	v679[0] = v681
	v679[26] = v682
	for _ = 1, 16 do
		for v693 = 0, 25 do
			local v694 = v679[v693]
			local v695 = v679[v693 + 1]
			local v696 = v695 - v694
			local v697 = v696.Magnitude
			if v697 <= 0.0001 then
				continue
			end
			local v698 = v696 * ((v697 - v687) / v697)
			if v693 == 0 then
				v679[1] = v695 - v698
			elseif v693 == 25 then
				v679[v693] = v694 + v698
			else
				v679[v693] = v694 + v698 * 0.5
				v679[v693 + 1] = v695 - v698 * 0.5
			end
		end
		for v699 = 1, 25 do
			local v700 = v679[v699]
			if v700.Y < v689 then
				local v701 = v700.X
				local v702 = v700.Z
				v700 = Vector3.new(v701, v689, v702)
			end
			for _, v703 in p677.boxes do
				local v704 = v703.cf:PointToObjectSpace(v700)
				local v705 = v704.X
				if math.abs(v705) >= v703.hx then
					continue
				end
				local v706 = v704.Z
				if math.abs(v706) >= v703.hz or v704.Y <= -v703.hy then
					continue
				end
				local v707 = (v704.X + v703.hx) / v703.cx
				local v708 = math.floor(v707) + 1
				local v709 = v703.nx
				local v710 = math.clamp(v708, 1, v709)
				local v711 = (v704.Z + v703.hz) / v703.cz
				local v712 = math.floor(v711) + 1
				local v713 = v703.nz
				local v714 = math.clamp(v712, 1, v713)
				local v715 = v703.heights[(v714 - 1) * v703.nx + v710]
				if not v715 or v704.Y >= v715 + 0.12 then
					continue
				end
				local v716 = v715 + 0.12 - v704.Y
				local v717 = v703.hx
				local v718 = v704.X
				local v719 = v717 - math.abs(v718)
				local v720 = v703.hz
				local v721 = v704.Z
				local v722 = v720 - math.abs(v721)
				local v723
				if v719 < v716 and v719 <= v722 then
					local v724 = v704.X
					local v725 = math.sign(v724) * v703.hx
					local v726 = v704.Y
					local v727 = v704.Z
					v723 = Vector3.new(v725, v726, v727)
				elseif v722 < v716 then
					local v728 = v704.X
					local v729 = v704.Y
					local v730 = v704.Z
					local v731 = math.sign(v730) * v703.hz
					v723 = Vector3.new(v728, v729, v731)
				else
					local v732 = v704.X
					local v733 = v715 + 0.12
					local v734 = v704.Z
					v723 = Vector3.new(v732, v733, v734)
				end
				v700 = v703.cf:PointToWorldSpace(v723)
			end
			v679[v699] = v700
		end
	end
end
local function v_u_753(p736, p737, p738) -- name: newRope
	-- upvalues: (copy) v_u_634, (copy) v_u_676, (copy) v_u_735, (copy) v_u_39, (copy) v_u_635
	local v739 = p736.WorldPosition
	local v740 = p737.WorldPosition
	local v741 = Instance.new("Part")
	v741.Name = "Hose"
	v741.Anchored = true
	v741.CanCollide = false
	v741.CanQuery = false
	v741.CanTouch = false
	v741.CastShadow = false
	v741.Transparency = 1
	v741.Size = Vector3.new(0.2, 0.2, 0.2)
	v741.CFrame = CFrame.new(v739)
	local v742 = {
		["a0"] = nil,
		["a1"] = nil,
		["idle"] = nil,
		["origin"] = nil,
		["holder"] = nil,
		["atts"] = nil,
		["beams"] = nil,
		["pts"] = nil,
		["prev"] = nil,
		["boxes"] = nil,
		["floorY"] = (-1 / 0),
		["checkAt"] = nil,
		["shown"] = true,
		["a0"] = p736,
		["a1"] = p737,
		["idle"] = p738,
		["origin"] = v739,
		["holder"] = v741,
		["atts"] = {},
		["beams"] = {},
		["pts"] = {},
		["prev"] = {},
		["boxes"] = {},
		["checkAt"] = os.clock() + 0.5
	}
	for v743 = 0, 26 do
		local v744 = v743 / 26
		local v745 = v739:Lerp(v740, v744)
		local v746 = v744 * 3.141592653589793
		local v747 = math.sin(v746) * 2
		local v748 = v745 - Vector3.new(0, v747, 0)
		local v749 = v742.pts
		local v750 = v742.prev
		v749[v743] = v748
		v750[v743] = v748
		local v751 = Instance.new("Attachment")
		v751.Position = v748 - v739
		v751.Parent = v741
		v742.atts[v743] = v751
		if v743 <= 0 then
			continue
		end
		local v752 = Instance.new("Beam")
		v752.Attachment0 = v742.atts[v743 - 1]
		v752.Attachment1 = v751
		v752.Width0 = 0.18
		v752.Width1 = 0.18
		v752.Color = v_u_634
		v752.LightInfluence = 1
		v752.FaceCamera = true
		v752.Segments = 1
		v752.Parent = v741
		v742.beams[v743] = v752
	end
	v_u_676(v742, v739)
	for _ = 1, 45 do
		v_u_735(v742, 0.016666666666666666)
	end
	v741.Parent = v_u_39
	v_u_635[p737] = v742
	return v742
end
local function v_u_777(p754) -- name: updateRopes
	-- upvalues: (copy) v_u_2, (copy) v_u_10, (copy) v_u_533, (copy) v_u_635, (copy) v_u_753, (copy) v_u_39, (copy) v_u_676, (copy) v_u_735
	local v755 = math.min(p754, 0.03333333333333333)
	local v756 = workspace.CurrentCamera
	local v757 = not v756 and Vector3.new(0, 0, 0) or v756.CFrame.Position
	local v758 = {}
	for _, v759 in v_u_2:GetTagged(v_u_10.HOSE_TAG) do
		local v760 = v759.Attachment0
		local v761 = v759.Attachment1
		if not (v760 and (v761 and (v759:IsDescendantOf(workspace) and (v760:IsDescendantOf(workspace) and v761:IsDescendantOf(workspace))))) then
			continue
		end
		if v759.Enabled then
			v759.Enabled = false
		end
		v758[v761] = {
			["a0"] = nil,
			["idle"] = false,
			["a0"] = v760
		}
	end
	for v762, v763 in v_u_533 do
		local v764 = v762:FindFirstChild("Hose")
		local v765 = v763.Parent and v763.PrimaryPart
		if v765 then
			v765 = v763.PrimaryPart:FindFirstChild("HoseIn")
		end
		if not (v765 and (v764 and v764.Value)) then
			continue
		end
		v758[v765] = {
			["a0"] = nil,
			["idle"] = true,
			["a0"] = v764.Value
		}
	end
	for v766, v767 in v_u_635 do
		if v758[v766] and v758[v766].a0 == v767.a0 then
			continue
		end
		v767.holder:Destroy()
		v_u_635[v766] = nil
	end
	local v768 = os.clock()
	for v769, v770 in v758 do
		local v771 = (v770.a0.WorldPosition - v757).Magnitude < 170
		local v772 = v_u_635[v769]
		if not v772 and v771 then
			v772 = v_u_753(v770.a0, v769, v770.idle)
		end
		if not v772 then
			continue
		end
		if v772.shown ~= v771 then
			v772.shown = v771
			local v773 = v772.holder
			local v774
			if v771 then
				v774 = v_u_39
			else
				v774 = nil
			end
			v773.Parent = v774
		end
		if not v771 then
			continue
		end
		if v772.checkAt <= v768 then
			v772.checkAt = v768 + 0.5
			v_u_676(v772, v772.a0.WorldPosition)
		end
		v_u_735(v772, v755)
		local v775 = v772.origin
		for v776 = 0, 26 do
			v772.atts[v776].Position = v772.pts[v776] - v775
		end
	end
end
v6.RenderStepped:Connect(function(p778)
	-- upvalues: (copy) v_u_600, (copy) v_u_777
	for _, v779 in v_u_600 do
		if not v779.chassis.Parent then
			continue
		end
		v779.part.CFrame = v779.chassis.CFrame * v779.offset
	end
	v_u_777(p778)
end)
task.spawn(function()
	-- upvalues: (copy) v_u_10, (copy) v_u_430, (copy) v_u_431, (copy) v_u_35, (copy) v_u_456, (copy) v_u_599, (copy) v_u_13, (copy) v_u_601, (copy) v_u_39, (copy) v_u_600, (copy) v_u_633, (copy) v_u_602, (copy) v_u_625
	while true do
		task.wait(0.25)
		local v780 = workspace.CurrentCamera
		local v781 = workspace:FindFirstChild("SpawnedVehicles")
		local v782 = workspace:GetServerTimeNow()
		local v783 = {}
		if v780 and v781 then
			for _, v784 in v781:GetChildren() do
				local v785 = v_u_10.chassisOf(v784)
				if not (v784:IsA("Model") and (v785 and v785:IsA("BasePart"))) then
					continue
				end
				local v786 = (v785.Position - v780.CFrame.Position).Magnitude
				if v786 > 220 then
					continue
				end
				table.insert(v783, {
					["v"] = v784,
					["ch"] = v785,
					["d"] = v786
				})
			end
		end
		local v787 = workspace:FindFirstChild("CarWashCustomers")
		if v780 and v787 then
			for _, v788 in v787:GetChildren() do
				local v789
				if v788.Name == "Vehicle" then
					v789 = v_u_10.chassisOf(v788)
				else
					v789 = false
				end
				if not (v788:IsA("Model") and (v789 and v789:IsA("BasePart"))) then
					continue
				end
				local v790 = {
					["v"] = v788,
					["ch"] = v789,
					["d"] = (v789.Position - v780.CFrame.Position).Magnitude
				}
				table.insert(v783, v790)
			end
		end
		table.sort(v783, function(p791, p792)
			return p791.d < p792.d
		end)
		local v793 = {}
		local v794 = {}
		local v795 = {}
		for v796, v797 in v783 do
			local v798 = v_u_10.dirt(v797.v)
			if v798 > 0.03 and v796 <= 8 then
				v793[v797.v] = v798
			end
			local v799 = v797.v:GetAttribute("WaxAt")
			if typeof(v799) == "number" and (v782 - v799 < v_u_10.WAX.sparkleSeconds and v796 <= 8) then
				v795[v797.v] = v797.ch
			end
			local v800 = v797.v:GetAttribute("WaxShine")
			if typeof(v800) == "number" and (v800 > 0 and v796 <= 16) then
				v794[v797.v] = v800
			end
			local v801 = v797.v:GetAttribute("CarWashFoam")
			if typeof(v801) ~= "number" or (v801 <= 0 or (v_u_430[v797.v] or os.clock() - (v_u_431[v797.v] or 0) <= 5)) then
				continue
			end
			v_u_431[v797.v] = os.clock()
			local v_u_802 = v797.v
			task.spawn(function()
				-- upvalues: (ref) v_u_35, (copy) v_u_802, (ref) v_u_456
				local v803 = v_u_35("Sync", v_u_802)
				if type(v803) == "table" then
					for _, v804 in v803 do
						v_u_456(v_u_802, v804[1], v804[2], v804[3], v804[4])
					end
				end
			end)
		end
		for v805, v806 in v_u_599 do
			if v793[v805] then
				continue
			end
			v806:Destroy()
			v_u_599[v805] = nil
		end
		for v807, v808 in v793 do
			local v809 = v_u_599[v807]
			if not v809 then
				v809 = v_u_13.new("Highlight", {
					["Name"] = "Dirt",
					["FillColor"] = nil,
					["OutlineTransparency"] = 1,
					["DepthMode"] = nil,
					["Adornee"] = nil,
					["Parent"] = nil,
					["FillColor"] = v_u_601,
					["DepthMode"] = Enum.HighlightDepthMode.Occluded,
					["Adornee"] = v807,
					["Parent"] = v_u_39
				})
				v_u_599[v807] = v809
			end
			v809.FillTransparency = 1 - 0.42 * v808
		end
		for v810, v811 in v_u_600 do
			if v795[v810] then
				continue
			end
			v811.part:Destroy()
			v_u_600[v810] = nil
		end
		for v812, v813 in v795 do
			v_u_633(v812, v813)
		end
		for v814 in v_u_602 do
			if v794[v814] then
				continue
			end
			local v815 = v_u_602[v814]
			if not v815 then
				continue
			end
			for v816, v817 in v815.parts do
				if not v816.Parent or v816.Reflectance ~= v817.set then
					continue
				end
				v816.Reflectance = v817.base
			end
			v_u_602[v814] = nil
		end
		for v818, v819 in v794 do
			v_u_625(v818, v819)
		end
	end
end)