-- Path: ReplicatedStorage/GameUI/JobsApp
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v1 = game:GetService("Players")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = require(v_u_2:WaitForChild("GameShared"))
local v_u_5 = require(v_u_2:WaitForChild("JobShared"))
local v_u_6 = require(v_u_2:WaitForChild("NetSeal"))
local v_u_7 = require(script.Parent:WaitForChild("Theme"))
local v_u_8 = require(script.Parent:WaitForChild("Icons"))
local v_u_9 = require(script.Parent:WaitForChild("Toast"))
local v_u_10 = Color3.new(1, 1, 1)
local v_u_11 = Color3.fromRGB(28, 30, 36)
local v_u_12 = Color3.fromRGB(112, 116, 128)
local v_u_13 = Color3.fromRGB(243, 244, 247)
local v_u_14 = Color3.fromRGB(70, 120, 255)
local v_u_15 = Color3.fromRGB(128, 70, 230)
local v_u_16 = Color3.fromRGB(22, 170, 100)
local v_u_17 = TweenInfo.new(0.3, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
local v_u_18 = {
	"Grab",
	"Delivery",
	"Courier",
	"Mechanic",
	"Builder",
	"IceCream",
	"CarWash"
}
local v19 = {}
for v20 = #v_u_18, 1, -1 do
	if v_u_5.job(v_u_18[v20]) then
		continue
	end
	table.remove(v_u_18, v20)
end
local v_u_21 = v1.LocalPlayer
local function v_u_39(p22, p23, p24, p25, p26, p27, p28, p29, p30, p31) -- name: label
	-- upvalues: (copy) v_u_7
	local v32 = v_u_7.text
	local v33 = {
		["Text"] = p23
	}
	local v34
	if p30 then
		v34 = v_u_7.FONT_BOLD
	else
		v34 = v_u_7.FONT
	end
	v33.FontFace = v34
	v33.TextSize = p28
	v33.TextColor3 = p29
	v33.TextXAlignment = Enum.TextXAlignment.Left
	v33.TextTruncate = Enum.TextTruncate.AtEnd
	v33.Position = UDim2.new(0, p24, 0, p25)
	local v35
	if p26 then
		v35 = UDim2.fromOffset(p26, p27)
	else
		v35 = UDim2.new(1, -p24 - 8, 0, p27)
	end
	v33.Size = v35
	v33.Parent = p22
	local v36 = v32(v33)
	for v37, v38 in p31 or {} do
		v36[v37] = v38
	end
	return v36
end
local function v_u_53(p40, p41, p42, p43, p44, p45) -- name: badge
	-- upvalues: (copy) v_u_10, (copy) v_u_7, (copy) v_u_8
	local v46 = {
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_10,
		["AnchorPoint"] = Vector2.new(0.5, 0.5),
		["Position"] = UDim2.fromOffset(p44, p45),
		["Size"] = UDim2.fromOffset(p43, p43),
		["Parent"] = p40
	}
	local v47 = v_u_7.new("Frame", v46)
	v_u_7.corner(v47, p43 * 0.3)
	local v48 = {
		["Rotation"] = 135,
		["Color"] = nil,
		["Parent"] = nil,
		["Color"] = ColorSequence.new(p42:Lerp(v_u_10, 0.2), p42:Lerp(Color3.new(0, 0, 0), 0.2)),
		["Parent"] = v47
	}
	v_u_7.new("UIGradient", v48)
	local v49 = v_u_8.make
	local v50 = v_u_10
	local v51 = p43 * 0.58
	local v52 = v49(p41, v50, (math.floor(v51)))
	v52.AnchorPoint = Vector2.new(0.5, 0.5)
	v52.Position = UDim2.fromScale(0.5, 0.5)
	v52.Parent = v47
	return v47
end
local function v_u_61(p54, p55, p56) -- name: card
	-- upvalues: (copy) v_u_7, (copy) v_u_10
	local v57 = {
		["BackgroundColor3"] = nil,
		["BackgroundTransparency"] = 0.92,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = Color3.new(0, 0, 0),
		["Position"] = UDim2.new(0, 14, 0, p55 + 3),
		["Size"] = UDim2.new(1, -28, 0, p56),
		["Parent"] = p54
	}
	local v58 = v_u_7.new("Frame", v57)
	v_u_7.corner(v58, 14)
	local v59 = {
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_10,
		["Position"] = UDim2.new(0, 14, 0, p55),
		["Size"] = UDim2.new(1, -28, 0, p56),
		["Parent"] = p54
	}
	local v60 = v_u_7.new("Frame", v59)
	v_u_7.corner(v60, 14)
	return v60
end
function v19.build(p62, p_u_63) -- name: build
	-- upvalues: (copy) v_u_2, (copy) v_u_4, (copy) v_u_5, (copy) v_u_13, (copy) v_u_7, (copy) v_u_10, (copy) v_u_14, (copy) v_u_15, (copy) v_u_8, (copy) v_u_39, (copy) v_u_61, (copy) v_u_11, (copy) v_u_12, (copy) v_u_18, (copy) v_u_53, (copy) v_u_3, (copy) v_u_21, (copy) v_u_6, (copy) v_u_9, (copy) v_u_16, (copy) v_u_17
	local v_u_64 = v_u_2:WaitForChild(v_u_4.REMOTES):WaitForChild(v_u_5.REMOTE)
	local v_u_65 = v_u_2:WaitForChild("JobPlaces", 10)
	local v66 = {}
	local v67 = {
		["Name"] = "JobsApp",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["Visible"] = false,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_13,
		["Size"] = UDim2.fromScale(1, 1),
		["Parent"] = p62
	}
	local v_u_68 = v_u_7.new("Frame", v67)
	local v_u_69 = v_u_7.new("UIScale", {
		["Parent"] = v_u_68
	})
	v66.frame = v_u_68
	local v70 = {
		["Name"] = "Header",
		["BackgroundColor3"] = nil,
		["BorderSizePixel"] = 0,
		["Size"] = nil,
		["Parent"] = nil,
		["BackgroundColor3"] = v_u_10,
		["Size"] = UDim2.new(1, 0, 0, 92),
		["Parent"] = v_u_68
	}
	local v71 = v_u_7.new("Frame", v70)
	local v72 = {
		["Rotation"] = 25,
		["Color"] = nil,
		["Parent"] = nil,
		["Color"] = ColorSequence.new(v_u_14, v_u_15),
		["Parent"] = v71
	}
	v_u_7.new("UIGradient", v72)
	local v73 = {
		["Name"] = "Back",
		["Text"] = "",
		["BackgroundTransparency"] = 1,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["Position"] = UDim2.fromOffset(4, 42),
		["Size"] = UDim2.fromOffset(30, 44),
		["Parent"] = v71
	}
	local v74 = v_u_7.new("TextButton", v73)
	local v75 = v_u_8.make("arrow", v_u_10, 20)
	v75.AnchorPoint = Vector2.new(0.5, 0.5)
	v75.Position = UDim2.fromScale(0.5, 0.5)
	v75.Parent = v74
	v74.Activated:Connect(function()
		-- upvalues: (copy) p_u_63
		p_u_63()
	end)
	v_u_39(v71, "Jobs", 38, 40, nil, 26, 22, v_u_10, true)
	v_u_39(v71, "Mark a job, drive there, put on the uniform", 38, 66, nil, 16, 12, v_u_10, false, {
		["TextTransparency"] = 0.12
	})
	local v_u_76 = v_u_61(v_u_68, 104, 64)
	local v_u_77 = v_u_39(v_u_76, "", 64, 12, nil, 20, 16, v_u_11, true)
	local v_u_78 = v_u_39(v_u_76, "", 64, 34, nil, 18, 12, v_u_12, false)
	local v79 = {
		["Name"] = "List",
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["CanvasSize"] = nil,
		["ScrollBarThickness"] = 3,
		["ScrollBarImageColor3"] = nil,
		["ScrollingDirection"] = nil,
		["Parent"] = nil,
		["Position"] = UDim2.fromOffset(0, 180),
		["Size"] = UDim2.new(1, 0, 1, -206),
		["CanvasSize"] = UDim2.fromOffset(0, #v_u_18 * 88 + 6),
		["ScrollBarImageColor3"] = v_u_12,
		["ScrollingDirection"] = Enum.ScrollingDirection.Y,
		["Parent"] = v_u_68
	}
	local v80 = v_u_7.new("ScrollingFrame", v79)
	local v_u_81 = {}
	local v_u_82 = nil
	for v83, v_u_84 in v_u_18 do
		local v85 = v_u_5.job(v_u_84)
		local v86 = v_u_61(v80, (v83 - 1) * 88 + 2, 78)
		v_u_53(v86, v85.icon, v85.color, 44, 34, 39)
		v_u_39(v86, v85.th, 64, 12, 120, 20, 16, v_u_11, true)
		local v87 = v_u_39(v86, "", 64, 33, 124, 16, 11, v_u_12, false)
		local v88 = v_u_39(v86, "", 64, 50, 124, 16, 12, v85.color:Lerp(v_u_11, 0.35), true)
		local v89 = {
			["Name"] = "Mark",
			["Text"] = "",
			["AutoButtonColor"] = false,
			["BackgroundColor3"] = nil,
			["BorderSizePixel"] = 0,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Size"] = nil,
			["Parent"] = nil,
			["BackgroundColor3"] = v_u_10,
			["AnchorPoint"] = Vector2.new(1, 0.5),
			["Position"] = UDim2.new(1, -10, 0.5, 0),
			["Size"] = UDim2.fromOffset(74, 34),
			["Parent"] = v86
		}
		local v90 = v_u_7.new("TextButton", v89)
		v_u_7.corner(v90, 17)
		local v91 = v_u_7.new("UIGradient", {
			["Rotation"] = 90,
			["Parent"] = nil,
			["Parent"] = v90
		})
		local v92 = {
			["ApplyStrokeMode"] = nil,
			["Thickness"] = 1.5,
			["Parent"] = nil,
			["ApplyStrokeMode"] = Enum.ApplyStrokeMode.Border,
			["Parent"] = v90
		}
		local v93 = v_u_7.new("UIStroke", v92)
		local v94 = v_u_39(v90, "Mark", 0, 0, nil, 34, 13, v_u_10, true, {
			["TextXAlignment"] = Enum.TextXAlignment.Center,
			["Size"] = UDim2.fromScale(1, 1)
		})
		local v_u_95 = v_u_7.new("UIScale", {
			["Parent"] = v90
		})
		v90.MouseButton1Down:Connect(function()
			-- upvalues: (ref) v_u_3, (copy) v_u_95
			v_u_3:Create(v_u_95, TweenInfo.new(0.1), {
				["Scale"] = 0.92
			}):Play()
		end)
		for _, v96 in { v90.MouseButton1Up, v90.MouseLeave } do
			v96:Connect(function()
				-- upvalues: (ref) v_u_3, (copy) v_u_95
				v_u_3:Create(v_u_95, TweenInfo.new(0.1), {
					["Scale"] = 1
				}):Play()
			end)
		end
		local v_u_97 = false
		v90.Activated:Connect(function()
			-- upvalues: (ref) v_u_97, (ref) v_u_21, (copy) v_u_84, (ref) v_u_6, (copy) v_u_64, (ref) v_u_9
			if not v_u_97 and v_u_21:GetAttribute("Job") ~= v_u_84 then
				v_u_97 = true
				local v98 = v_u_21:GetAttribute("PlannedJob") == v_u_84
				local v99 = v_u_6.invoke
				local v100 = v_u_64
				local v101 = v98 and "" or v_u_84
				local v102, v103, v104 = pcall(v99, v100, "Plan", v101)
				v_u_97 = false
				if v102 and v104 then
					v_u_9.show(v104, v103 and "info" or "error")
				end
			end
		end)
		v_u_81[v_u_84] = {
			["where"] = v87,
			["far"] = v88,
			["button"] = v90,
			["fill"] = v91,
			["stroke"] = v93,
			["caption"] = v94,
			["info"] = v85
		}
	end
	local function v_u_135() -- name: refresh
		-- upvalues: (ref) v_u_21, (ref) v_u_5, (ref) v_u_82, (ref) v_u_53, (copy) v_u_76, (copy) v_u_77, (copy) v_u_78, (copy) v_u_81, (copy) v_u_65, (ref) v_u_16, (ref) v_u_10, (ref) v_u_11
		local v105 = v_u_21:GetAttribute("Job") or v_u_5.DEFAULT
		local v106 = v_u_21:GetAttribute("PlannedJob")
		local v107 = v_u_5.job(v105)
		if v_u_82 then
			v_u_82:Destroy()
		end
		local v108
		if v105 == v_u_5.DEFAULT then
			v108 = false
		else
			v108 = v107 ~= nil
		end
		local v109 = v_u_53
		local v110 = v_u_76
		local v111 = not v108 and "person" or v107.icon
		local v112
		if v108 then
			v112 = v107.color
		else
			v112 = Color3.fromRGB(150, 156, 170)
		end
		v_u_82 = v109(v110, v111, v112, 40, 34, 32)
		v_u_77.Text = not v108 and "Off duty" or "On duty: " .. v107.th
		v_u_78.Text = v108 and v107.noLocker and "Mark another job to stop" or (v108 and "Uniform off at its locker to stop" or (v106 and "Head to the marked workplace" or "Mark a job below to start"))
		local v113 = v_u_21.Character
		if v113 then
			v113 = v_u_21.Character:FindFirstChild("HumanoidRootPart")
		end
		for v114, v115 in v_u_81 do
			local v116 = v_u_65
			if v116 then
				v116 = v_u_65:GetAttribute(v114)
			end
			local v117 = 1
			local v118 = {}
			local v119 = false
			local v120 = nil
			while v_u_65 and v113 do
				local v121 = v_u_65:GetAttribute(v114 .. "_L" .. v117)
				if typeof(v121) ~= "Vector3" then
					break
				end
				local v122 = v_u_65:GetAttribute(v114 .. "_L" .. v117 .. "_Open")
				local v123 = {
					["pos"] = v121,
					["open"] = v122,
					["place"] = v_u_65:GetAttribute(v114 .. "_L" .. v117 .. "Place")
				}
				table.insert(v118, v123)
				v119 = (type(v122) ~= "number" or v122 > 0) and true or v119
				v117 = v117 + 1
			end
			local v124 = (1 / 0)
			for _, v125 in v118 do
				local v126 = (v125.pos - v113.Position).Magnitude
				if v119 then
					local v127 = v125.open
					if type(v127) == "number" and v125.open <= 0 then
						continue
					end
				end
				if v126 >= v124 then
					continue
				end
				v116 = v125.pos
				v120 = v125.place
				v124 = v126
			end
			if type(v120) ~= "string" or v120 == "" then
				v120 = nil
			end
			local v128 = v120 or (v_u_65 and (v_u_65:GetAttribute(v114 .. "Place") or "") or "")
			v115.where.Text = v128:gsub("^%l", string.upper)
			local v129 = v115.far
			local v130
			if typeof(v116) == "Vector3" and v113 then
				local v131 = (v116 - v113.Position).Magnitude * 0.28
				local v132
				if v131 >= 1000 then
					v132 = ("%.1f km"):format(v131 / 1000)
				else
					local v133 = v131 / 10 + 0.5
					v132 = ("%d m"):format(math.floor(v133) * 10)
				end
				v130 = v132 .. " away"
			else
				v130 = ""
			end
			v129.Text = v130
			local v134 = v105 == v114 and "duty" or (v106 == v114 and "marked" or "mark")
			if v134 == "duty" then
				v115.fill.Color = ColorSequence.new(v_u_16:Lerp(v_u_10, 0.15), v_u_16)
				v115.stroke.Transparency = 1
				v115.caption.Text = "On duty"
				v115.caption.TextColor3 = v_u_10
			elseif v134 == "marked" then
				v115.fill.Color = ColorSequence.new(v_u_10, v_u_10)
				v115.stroke.Color = v115.info.color
				v115.stroke.Transparency = 0
				v115.caption.Text = "Marked \226\156\147"
				v115.caption.TextColor3 = v115.info.color:Lerp(v_u_11, 0.25)
			else
				v115.fill.Color = ColorSequence.new(Color3.fromRGB(255, 214, 90), Color3.fromRGB(244, 150, 20))
				v115.stroke.Transparency = 1
				v115.caption.Text = "Mark"
				v115.caption.TextColor3 = Color3.fromRGB(40, 28, 8)
			end
		end
	end
	local v_u_136 = false
	function v66.show() -- name: show
		-- upvalues: (ref) v_u_136, (copy) v_u_68, (copy) v_u_135, (copy) v_u_69, (ref) v_u_3, (ref) v_u_17
		v_u_136 = true
		v_u_68.Visible = true
		v_u_135()
		v_u_69.Scale = 0.92
		v_u_3:Create(v_u_69, v_u_17, {
			["Scale"] = 1
		}):Play()
	end
	function v66.hide() -- name: hide
		-- upvalues: (ref) v_u_136, (copy) v_u_68
		v_u_136 = false
		v_u_68.Visible = false
	end
	function v66.isShown() -- name: isShown
		-- upvalues: (ref) v_u_136
		return v_u_136
	end
	local v_u_137 = v_u_136
	for _, v138 in { "Job", "PlannedJob" } do
		v_u_21:GetAttributeChangedSignal(v138):Connect(function()
			-- upvalues: (ref) v_u_137, (copy) v_u_135
			if v_u_137 then
				v_u_135()
			end
		end)
	end
	task.spawn(function()
		-- upvalues: (copy) v_u_68, (ref) v_u_137, (copy) v_u_135
		while v_u_68.Parent do
			task.wait(1)
			if not v_u_137 then
				continue
			end
			v_u_135()
		end
	end)
	return v66
end
return v19