-- Path: StarterPlayer/PlayerModule/Types/PlayerModuleInternalData
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

require(script.Parent.Parent)
require(script.Parent.ControlModuleData)
require(script.Parent.EngineInterfaceData)
return {}