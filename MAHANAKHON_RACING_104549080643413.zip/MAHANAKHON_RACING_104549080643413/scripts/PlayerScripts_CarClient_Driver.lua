-- Path: Players/ygggggg55551/PlayerScripts/CarClient/Driver
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = require(game:GetService("ReplicatedStorage"):WaitForChild("NetSeal"))
local v_u_2 = game:GetService("ContextActionService")
local v_u_3 = game:GetService("Players")
local v_u_4 = game:GetService("ReplicatedStorage")
local v_u_5 = game:GetService("RunService")
local v_u_6 = game:GetService("UserInputService")
local v_u_7 = require(v_u_4:WaitForChild("CarShared"))
local v_u_8 = require(v_u_4:WaitForChild("CareShared"))
local v_u_9 = require(v_u_4:WaitForChild("GameShared"))
local v_u_10 = require(v_u_4:WaitForChild("GearShared"))
local v_u_11 = require(v_u_4:WaitForChild("VehicleFx"))
local v_u_12 = require(v_u_4:WaitForChild("BumpGuard"))
local v_u_13 = require(script.Parent:WaitForChild("Visuals"))
local v_u_14 = require(script.Parent:WaitForChild("Hud"))
local v_u_15 = require(script.Parent:WaitForChild("Camera"))
local v_u_16 = require(script.Parent:WaitForChild("TuneMenu"))
local v_u_17 = {
	[Enum.KeyCode.Z] = "Left",
	[Enum.KeyCode.C] = "Right",
	[Enum.KeyCode.X] = "Hazard"
}
local v_u_18 = {
	[Enum.KeyCode.LeftShift] = true,
	[Enum.KeyCode.RightShift] = true
}
local v_u_19 = {
	[Enum.KeyCode.Q] = true,
	[Enum.KeyCode.ButtonL1] = true
}
local v_u_20 = {
	"FrontLeft",
	"FrontRight",
	"RearLeft",
	"RearRight"
}
local v_u_21 = {}
local v_u_22 = nil
local v_u_23 = nil
local function v_u_26(p24, ...) -- name: fire
	-- upvalues: (copy) v_u_4, (copy) v_u_7, (ref) v_u_22, (copy) v_u_1
	local v25 = v_u_4:FindFirstChild(v_u_7.REMOTE_NAME)
	if v25 and v_u_22 then
		v_u_1.fire(v25, p24, v_u_22.model, ...)
	end
end
local function v_u_27() -- name: toggleLights
	-- upvalues: (copy) v_u_26
	v_u_26("Lights")
end
local function v_u_29(p28) -- name: setIndicator
	-- upvalues: (copy) v_u_26
	v_u_26("Indicator", p28)
end
local function v_u_31(p30) -- name: setHorn
	-- upvalues: (copy) v_u_26
	v_u_26("Horn", p30)
end
local function v_u_32() -- name: toggleEngine
	-- upvalues: (ref) v_u_22, (copy) v_u_26
	if v_u_22 then
		v_u_26("Engine", v_u_22.model:GetAttribute("EngineOn") ~= true)
	end
end
local function v_u_33() -- name: toggleView
	-- upvalues: (copy) v_u_15
	v_u_15.toggle()
end
local function v_u_34() -- name: toggleRainbow
	-- upvalues: (copy) v_u_26
	v_u_26("Rainbow")
end
local function v_u_39(p35) -- name: shiftGear
	-- upvalues: (ref) v_u_22, (copy) v_u_10, (copy) v_u_11
	local v36 = v_u_22
	if v36 and v36.gears then
		local v37, v38 = v_u_10.shift(v36.gears, v36.gear, p35, v36.speed, v36.top)
		if v37 then
			v36.gear = v37
			v36.model:SetAttribute("Gear", v37)
		elseif v38 and os.clock() - v36.hintAt > 1 then
			v36.hintAt = os.clock()
			v_u_11.hint(v38)
		end
	else
		return
	end
end
local function v_u_41(_, p40) -- name: onExitAction
	-- upvalues: (ref) v_u_22, (copy) v_u_26
	if p40 == Enum.UserInputState.Begin and (v_u_22 and os.clock() - (v_u_22.exitAt or 0) > 0.5) then
		v_u_22.exitAt = os.clock()
		v_u_26("Exit")
	end
	return Enum.ContextActionResult.Sink
end
local function v_u_42() -- name: toggleTune
	-- upvalues: (ref) v_u_22, (copy) v_u_3, (copy) v_u_16, (copy) v_u_9, (copy) v_u_11
	if v_u_22 and not v_u_3.LocalPlayer:GetAttribute("Tuning") then
		if v_u_16.isOpen() then
			v_u_16.close()
			return
		elseif v_u_9.inTuneBay(v_u_22.model) then
			v_u_3.LocalPlayer:SetAttribute("TuneHub", true)
		else
			v_u_11.hint(v_u_9.TUNE_HINT)
		end
	else
		return
	end
end
v_u_3.LocalPlayer:GetAttributeChangedSignal("OpenTune"):Connect(function()
	-- upvalues: (copy) v_u_3, (ref) v_u_22, (copy) v_u_16, (copy) v_u_26, (copy) v_u_15
	local v43 = v_u_3.LocalPlayer:GetAttribute("OpenTune")
	if v43 and v_u_22 then
		v_u_3.LocalPlayer:SetAttribute("OpenTune", nil)
		if v43 == "Close" then
			if v_u_16.isOpen() then
				v_u_16.close()
				return
			end
		else
			local v44 = v_u_16.open
			local v45 = v_u_22.model
			local v46 = v_u_26
			local v47 = v_u_15.setMenuOpen
			local v48 = {}
			local v49
			if type(v43) == "string" then
				v49 = v43
			else
				v49 = nil
			end
			v48.group = v49
			v48.dock = type(v43) == "string"
			v44(v45, v46, v47, v48)
		end
	end
end)
local function v_u_68(p50, p51, p52, p53, p54) -- name: spring
	-- upvalues: (copy) v_u_7
	local v55 = math.min(p52, 0.15)
	local v56 = v55 / 0.02 - 1e-6
	local v57 = math.ceil(v56)
	local v58 = math.max(1, v57)
	local v59 = v55 / v58
	local v60 = p53 or v_u_7.SUSP_STIFFNESS
	local v61 = p54 or v_u_7.SUSP_DAMPING
	for _ = 1, v58 do
		p50.vel = p50.vel + (v60 * (p51 - p50.comp) - v61 * p50.vel) * v59
		p50.comp = p50.comp + p50.vel * v59
		if p50.comp > v_u_7.SUSP_TRAVEL then
			local v62 = v_u_7.SUSP_TRAVEL
			local v63 = p50.vel
			local v64 = math.min(v63, 0)
			p50.comp = v62
			p50.vel = v64
		else
			if p50.comp >= -v_u_7.SUSP_EXTEND then
				continue
			end
			local v65 = -v_u_7.SUSP_EXTEND
			local v66 = p50.vel
			local v67 = math.max(v66, 0)
			p50.comp = v65
			p50.vel = v67
		end
	end
end
local function v_u_80(p69) -- name: bodyRoom
	local v70 = p69.room
	local v71 = 0
	local v72 = 0
	local v73 = 0
	local v74 = 0
	for _, v75 in p69.wheels do
		local v76 = (v75.rest or v75.weld.C0).Y - v75.rest0Y
		if v75.front then
			v71 = v71 + v76
			v72 = v72 + 1
		else
			v73 = v73 + v76
			v74 = v74 + 1
		end
	end
	local v77 = v70.gapF - (v72 <= 0 and 0 or v71 / v72) - 0.2
	local v78 = math.max(0, v77)
	local v79 = v70.gapR - (v74 <= 0 and 0 or v73 / v74) - 0.2
	return v78, math.max(0, v79)
end
local function v_u_133(p81, p82, p83, p84, p85) -- name: stepSuspension
	-- upvalues: (copy) v_u_7, (copy) v_u_80, (copy) v_u_68
	local v86 = p85 - p81.lastVy
	p81.lastVy = p85
	local v87 = p81.model
	local v88 = v_u_7.SUSP_PITCH
	local v89
	if v87 then
		v89 = v87:GetAttribute("SuspPitchScale")
	else
		v89 = v87
	end
	local v90 = v88 * (typeof(v89) ~= "number" and 1 or v89)
	local v91 = v_u_7.SUSP_ROLL
	local v92
	if v87 then
		v92 = v87:GetAttribute("SuspRollScale")
	else
		v92 = v87
	end
	local v93 = v91 * (typeof(v92) ~= "number" and 1 or v92)
	local v94 = v_u_7.SUSP_STIFFNESS
	local v95
	if v87 then
		v95 = v87:GetAttribute("SuspStiffScale")
	else
		v95 = v87
	end
	local v96 = v94 * (typeof(v95) ~= "number" and 1 or v95)
	local v97 = v_u_7.SUSP_DAMPING
	if v87 then
		v87 = v87:GetAttribute("SuspDampScale")
	end
	local v98 = v97 * (typeof(v87) ~= "number" and 1 or v87)
	for _, v99 in p81.wheels do
		if v99.weld.C0 == v99.written then
			continue
		end
		v99.rest = v99.weld.C0
	end
	local v100 = 1
	local v101, v102
	if p81.room then
		v101, v102 = v_u_80(p81)
		local v103 = -p83 * v90
		local v104 = -v_u_7.SUSP_EXTEND
		local v105 = v_u_7.SUSP_TRAVEL
		local v106 = math.clamp(v103, v104, v105)
		local v107 = p83 * v90
		local v108 = -v_u_7.SUSP_EXTEND
		local v109 = v_u_7.SUSP_TRAVEL
		local v110 = math.clamp(v107, v108, v109)
		local v111 = (v106 - v110) / p81.wheelbase
		local v112 = v106 + p81.room.overF * v111
		local v113 = v110 - p81.room.overR * v111
		if v101 < v112 then
			local v114 = v101 / v112
			v100 = math.min(v100, v114)
		end
		if v102 < v113 then
			local v115 = v102 / v113
			v100 = math.min(v100, v115)
		end
	else
		v101 = 0
		v102 = 0
	end
	for _, v116 in p81.wheels do
		local v117
		if v116.front then
			v117 = -p83
		else
			v117 = p83
		end
		local v118 = v117 * v90 * v100 - v116.side * p84 * v93
		if v86 > 6 then
			v116.vel = v116.vel + v86 * 0.05
		end
		local v119 = v_u_68
		local v120 = -v_u_7.SUSP_EXTEND
		local v121 = v_u_7.SUSP_TRAVEL
		v119(v116, math.clamp(v118, v120, v121), p82, v96, v98)
	end
	if p81.room then
		local v122 = p81.wheels
		local v123 = ((v122.FrontLeft and (v122.FrontLeft.comp or 0) or 0) + (v122.FrontRight and (v122.FrontRight.comp or 0) or 0)) / 2
		local v124 = ((v122.RearLeft and (v122.RearLeft.comp or 0) or 0) + (v122.RearRight and (v122.RearRight.comp or 0) or 0)) / 2
		local v125 = (v123 - v124) / p81.wheelbase
		local v126 = v123 + p81.room.overF * v125
		local v127 = v124 - p81.room.overR * v125
		local v128 = 1
		if v101 < v126 then
			local v129 = v101 / v126
			v128 = math.min(v128, v129)
		end
		if v102 < v127 then
			local v130 = v102 / v127
			v128 = math.min(v128, v130)
		end
		if v128 < 1 then
			for _, v131 in v122 do
				v131.comp = v131.comp * v128
				v131.vel = v131.vel * v128
			end
		end
	end
	for _, v132 in p81.wheels do
		v132.written = CFrame.new(0, v132.comp, 0) * v132.rest
		v132.weld.C0 = v132.written
	end
end
local function v_u_156(p134, p135, p136) -- name: measureRoom
	local v137 = p134:FindFirstChild("BodyCollider")
	if not (v137 and v137:IsA("BasePart")) then
		return nil
	end
	local v138 = p135.CFrame
	local v139 = v138:PointToObjectSpace(v137.Position)
	local v140 = v139.Y - v137.Size.Y / 2
	local v141 = {
		["front"] = {
			["y"] = 0,
			["z"] = 0,
			["n"] = 0
		},
		["rear"] = {
			["y"] = 0,
			["z"] = 0,
			["n"] = 0
		}
	}
	for _, v142 in p136 do
		local v143 = v142.weld.Part1
		if not v143 then
			continue
		end
		local v144 = v138:PointToObjectSpace(v143.Position)
		local v145
		if v142.front then
			v145 = v141.front
		else
			v145 = v141.rear
		end
		v145.y = v145.y + (v144.Y - v143.Size.Y / 2)
		v145.z = v145.z + v144.Z
		v145.n = v145.n + 1
	end
	if v141.front.n == 0 or v141.rear.n == 0 then
		return nil
	end
	local v146 = v141.front.z / v141.front.n
	local v147 = v141.rear.z / v141.rear.n
	local v148 = v146 < v147 and -1 or 1
	local v149 = v139.Z + v148 * v137.Size.Z / 2
	local v150 = v139.Z - v148 * v137.Size.Z / 2
	local v151 = {
		["gapF"] = v140 - v141.front.y / v141.front.n,
		["gapR"] = v140 - v141.rear.y / v141.rear.n
	}
	local v152 = v149 - v146
	local v153 = math.abs(v152) * ((v149 - v146) * v148 > 0 and 1 or 0)
	v151.overF = math.max(0, v153)
	local v154 = v150 - v147
	local v155 = math.abs(v154) * ((v150 - v147) * v148 < 0 and 1 or 0)
	v151.overR = math.max(0, v155)
	return v151
end
local function v_u_172(p157) -- name: groundTilt
	local v158 = {}
	for v159, v160 in p157.groundPoints do
		local v161 = v160.WorldPosition
		local v162 = workspace:Raycast(v161 + Vector3.new(0, 3, 0), Vector3.new(0, -7, 0), p157.params)
		if not v162 then
			return nil
		end
		v158[v159] = v162.Position.Y
	end
	if not (v158.FrontLeft and (v158.FrontRight and (v158.RearLeft and v158.RearRight))) then
		return nil
	end
	local v163 = (v158.FrontLeft + v158.FrontRight) / 2
	local v164 = (v158.RearLeft + v158.RearRight) / 2
	local v165 = (v158.FrontLeft + v158.RearLeft) / 2
	local v166 = (v158.FrontRight + v158.RearRight) / 2
	local v167 = v163 - v164
	local v168 = p157.wheelbase
	local v169 = math.atan2(v167, v168)
	local v170 = v165 - v166
	local v171 = p157.track
	return v169, -math.atan2(v170, v171)
end
local function v_u_183(p173, p174, p175) -- name: bodyTilt
	-- upvalues: (copy) v_u_172, (copy) v_u_7
	local v176 = p173.chassis
	local v177, v178 = v_u_172(p173)
	if not v177 or v176.CFrame.UpVector.Y < v_u_7.FLIP_UP_Y then
		return v_u_7.alignTarget(v176.CFrame, p174, true)
	end
	local v179 = v_u_7.alpha(10, p175)
	p173.groundPitch = p173.groundPitch + (v177 - p173.groundPitch) * v179
	p173.groundRoll = p173.groundRoll + (v178 - p173.groundRoll) * v179
	local v180 = p173.wheels
	local v181 = ((v180.RearLeft and (v180.RearLeft.comp or 0) or 0) + (v180.RearRight and (v180.RearRight.comp or 0) or 0) - (v180.FrontLeft and (v180.FrontLeft.comp or 0) or 0) - (v180.FrontRight and (v180.FrontRight.comp or 0) or 0)) / 2 / p173.wheelbase
	local v182 = ((v180.FrontLeft and (v180.FrontLeft.comp or 0) or 0) + (v180.RearLeft and (v180.RearLeft.comp or 0) or 0) - (v180.FrontRight and (v180.FrontRight.comp or 0) or 0) - (v180.RearRight and v180.RearRight.comp or 0)) / 2 / p173.track
	return p174 * CFrame.Angles(p173.groundPitch + v181, 0, 0) * CFrame.Angles(0, 0, p173.groundRoll + v182)
end
local function v_u_186(p184) -- name: restoreSuspension
	for _, v185 in p184.wheels do
		if v185.rest and v185.weld.C0 == v185.written then
			v185.weld.C0 = v185.rest
		end
		v185.written = nil
		v185.comp = 0
		v185.vel = 0
	end
end
local function v_u_202(p187, p188, p189) -- name: impact
	-- upvalues: (copy) v_u_11
	local v190 = os.clock()
	if v190 - p187.impactAt >= 0.4 then
		p187.impactAt = v190
		local v191 = p187.chassis
		local v192 = p188.X
		local v193 = p188.Z
		local v194 = Vector3.new(v192, 0, v193)
		local v195
		if v194.Magnitude > 0.001 then
			v195 = v194.Unit
		else
			v195 = v191.CFrame.LookVector
		end
		local v196 = p187.halfLength + 4
		local v197 = workspace:Raycast(v191.Position + Vector3.new(0, 0.6, 0), v195 * v196, p187.params)
		local v198
		if v197 then
			v198 = v197.Position
		else
			v198 = v191.Position + v195 * p187.halfLength
		end
		local v199
		if v197 then
			v199 = v197.Normal
		else
			v199 = -v195
		end
		local v200 = p189 / 50
		local v201 = math.clamp(v200, 0.25, 1)
		v_u_11.burst(v198, v199 + Vector3.new(0, 0.5, 0), v201)
		v_u_11.report(v198, v199 + Vector3.new(0, 0.5, 0), v201)
		v_u_11.shake(v201 * 0.8 + 0.4)
	end
end
local function v_u_216(p203, p204) -- name: stepScrape
	-- upvalues: (copy) v_u_7, (copy) v_u_11
	local v205 = p203.chassis
	local v206 = 0
	local v207 = nil
	if v_u_7.SCRAPE_MIN_SPEED < p204 then
		local v208 = v205.CFrame
		for _, v209 in { -1, 1 } do
			for _, v210 in { -p203.halfLength * 0.6, 0, p203.halfLength * 0.6 } do
				local v211 = v209 * (p203.halfWidth - 0.5)
				local v212 = v208:PointToWorldSpace((Vector3.new(v211, 0.8, v210)))
				local v213 = workspace:Raycast(v212, v208.RightVector * v209 * 1.4, p203.params)
				if not v213 then
					continue
				end
				local v214 = v213.Normal.Y
				if math.abs(v214) >= 0.5 then
					continue
				end
				local v215 = p204 / 70
				v206 = math.clamp(v215, 0.2, 1)
				v207 = v213.Position
			end
			if not v207 then
				break
			end
		end
	end
	if v206 > 0 and not p203.scraper then
		p203.scraper = v_u_11.scraper()
	end
	if p203.scraper then
		p203.scraper:update(v206, v207 or v205.Position, -v205.CFrame.LookVector)
	end
end
local function v_u_223(p217) -- name: onTouched
	-- upvalues: (ref) v_u_22, (copy) v_u_4, (copy) v_u_11, (copy) v_u_1
	local v218 = v_u_22
	if v218 then
		local v219 = p217:FindFirstAncestorOfClass("Model")
		local v220
		if v219 then
			v220 = v219:FindFirstChildOfClass("Humanoid")
		else
			v220 = v219
		end
		if v220 and (not v220.SeatPart and v219 ~= v218.character) then
			if v218.chassis.AssemblyLinearVelocity.Magnitude < 22 then
				return
			else
				local v221 = os.clock()
				if (v218.hitPeople[v219] or 0) <= v221 - 1 then
					v218.hitPeople[v219] = v221
					local v222 = v_u_4:FindFirstChild(v_u_11.REMOTE_NAME)
					if v222 then
						v_u_1.fire(v222, "HitPerson", v219)
					end
				end
			end
		else
			return
		end
	else
		return
	end
end
local function v_u_237(p224) -- name: keysToSeat
	-- upvalues: (copy) v_u_6
	local v225 = p224.seat.Occupant
	if p224.seat:IsA("VehicleSeat") and (v225 and (v225.Parent == game:GetService("Players").LocalPlayer.Character and not v_u_6:GetFocusedTextBox())) then
		local v226 = Enum.KeyCode.W
		local v227 = Enum.KeyCode.Up
		local v228 = Enum.KeyCode.S
		local v229 = Enum.KeyCode.Down
		local v230 = 0
		if v_u_6:IsKeyDown(v226) or v_u_6:IsKeyDown(v227) then
			v230 = v230 + 1
		end
		if v_u_6:IsKeyDown(v228) or v_u_6:IsKeyDown(v229) then
			v230 = v230 - 1
		end
		local v231 = Enum.KeyCode.D
		local v232 = Enum.KeyCode.Right
		local v233 = Enum.KeyCode.A
		local v234 = Enum.KeyCode.Left
		local v235 = 0
		if v_u_6:IsKeyDown(v231) or v_u_6:IsKeyDown(v232) then
			v235 = v235 + 1
		end
		if v_u_6:IsKeyDown(v233) or v_u_6:IsKeyDown(v234) then
			v235 = v235 - 1
		end
		local v236 = v230 ~= 0 and true or v235 ~= 0
		if v236 or p224.keysHeld then
			p224.seat.ThrottleFloat = v230
			p224.seat.SteerFloat = v235
		end
		p224.keysHeld = v236
	end
end
local function v_u_329(p238) -- name: step
	-- upvalues: (ref) v_u_22, (copy) v_u_237, (copy) v_u_3, (copy) v_u_11, (copy) v_u_9, (copy) v_u_7, (copy) v_u_8, (copy) v_u_12, (copy) v_u_202, (copy) v_u_216, (copy) v_u_10, (copy) v_u_133, (copy) v_u_183, (copy) v_u_26, (copy) v_u_13, (copy) v_u_14, (copy) v_u_15, (copy) v_u_16
	local v239 = v_u_22
	if v239 then
		local v240 = v239.chassis
		local v241 = v239.model
		v_u_237(v239)
		local v242 = v239.seat.ThrottleFloat
		local v243 = v239.seat.SteerFloat
		if v_u_3.LocalPlayer:GetAttribute("Tuning") then
			v242 = 0
			v243 = 0
		end
		local v244 = v241:GetAttribute("EngineOn") == true
		if v242 > 0 and (not v244 and os.clock() - v239.hintAt > 2.5) then
			v239.hintAt = os.clock()
			v_u_11.hint("The engine\'s off: press R to start it")
		end
		local v245 = CFrame.Angles(0, v239.heading, 0)
		v239.travel = v239.travel or v239.heading
		local v246 = CFrame.Angles(0, v239.travel, 0).LookVector
		local v247, v248, v249 = v_u_9.upgradeScales(v241)
		local v250
		if v241:GetAttribute("MaxSpeed") then
			v250 = v_u_9.driveTop(v241, v249, 1)
		else
			v250 = v_u_7.DEFAULT_MAX_SPEED * v249 * v_u_8.healthTop(v241)
		end
		local v251 = v240.AssemblyLinearVelocity
		if not v240.Anchored and (v239.seat.Occupant and v239.seat.Occupant.Parent == v_u_3.LocalPlayer.Character) then
			local v252 = v251.X
			local v253 = v251.Z
			local v254 = Vector3.new(v252, 0, v253)
			local v255 = v250 * 1.1 + 10
			if v255 < v254.Magnitude then
				v254 = v254.Unit * v255
			end
			local v256 = v251.Y
			local v257 = v254.Magnitude * 0.6
			local v258 = math.max(60, v257)
			local v259 = math.min(v256, v258)
			local v260 = v254.Magnitude
			local v261 = v251.X
			local v262 = v251.Z
			if v260 < Vector3.new(v261, 0, v262).Magnitude or v259 < v251.Y then
				local v263 = v254.X
				local v264 = v254.Z
				v240.AssemblyLinearVelocity = Vector3.new(v263, v259, v264)
			end
			v251 = v_u_12.step(v239.bump, p238, nil, nil, v239.linear.VectorVelocity)
		end
		local v265 = v251:Dot(v246)
		local v266 = v251.X
		local v267 = v251.Z
		local v268 = Vector3.new(v266, 0, v267).Magnitude
		if not v240.Anchored then
			local v269 = v239.speed
			local v270 = v265 - 6
			local v271 = math.min(v270, v250)
			local v272 = v265 + 6
			local v273 = -v_u_7.REVERSE_MAX
			local v274 = math.max(v272, v273)
			v239.speed = math.clamp(v269, v271, v274)
			local v275 = os.clock()
			local v276 = v239.history
			local v277 = {
				v275,
				v268,
				v251,
				v239.pedalDrop
			}
			table.insert(v276, v277)
			while #v276 > 1 and v275 - v276[1][1] > v_u_7.IMPACT_WINDOW do
				table.remove(v276, 1)
			end
			local v278 = v276[1]
			for _, v279 in v276 do
				if v279[2] <= v278[2] then
					continue
				end
				v278 = v279
			end
			local v280 = v278[2] - v268 - (v239.pedalDrop - v278[4])
			if v278[2] > v_u_7.IMPACT_MIN_SPEED and v_u_7.IMPACT_SPEED_DROP < v280 then
				v_u_202(v239, v278[3], v280)
			end
			v_u_216(v239, v268)
		end
		local v281, v282
		if v239.gears then
			v239.top = v250
			local v283 = v239.speed
			if math.abs(v283) < v_u_10.STOPPED and (v242 <= 0 and v239.gear ~= 1) then
				v239.gear = 1
				v239.model:SetAttribute("Gear", 1)
			end
			v281 = v250 * v_u_10.share(v239.gears, v239.gear)
			v282 = v_u_10.pull(v239.speed, v250, v239.gears, v239.gear)
		else
			v281 = v250
			v282 = 1
		end
		local v284 = not v244 and (v242 > 0 or v239.speed <= v_u_7.STOPPED_SPEED) and 0 or v242
		local v285 = v239.handbrake and 0 or v284
		local v286 = v239.speed
		v239.speed = v_u_7.stepSpeed(v239.speed, v285, v250, math.min(p238, 0.15), (v241:GetAttribute("AccelScale") or 1) * v247 * v282, (v241:GetAttribute("BrakeScale") or 1) * v248)
		if v281 < v239.speed then
			local v287 = v239.speed
			local v288 = math.min(v286, v287)
			v239.speed = math.max(v281, v288)
		end
		if v239.handbrake then
			local v289 = v239.speed
			local v290 = math.sign(v289)
			local v291 = v239.speed
			local v292 = math.abs(v291) - 32 * p238
			v239.speed = v290 * math.max(0, v292)
		end
		local v293 = v239.pedalDrop
		local v294 = math.abs(v286)
		local v295 = v239.speed
		local v296 = v294 - math.abs(v295)
		v239.pedalDrop = v293 + math.max(0, v296)
		if v240.Anchored then
			v239.speed = 0
		end
		v239.accel = v239.accel + ((v239.speed - v286) / math.max(p238, 0.004166666666666667) - v239.accel) * v_u_7.alpha(8, p238)
		local v297 = math.abs(v243)
		local v298 = v239.steer
		local v299
		if v297 < math.abs(v298) then
			v299 = v_u_7.STEER_RATE * 1.5
		else
			v299 = v_u_7.STEER_RATE
		end
		v239.steer = v239.steer + (v243 - v239.steer) * v_u_7.alpha(v299, p238)
		local v300 = v241:GetAttribute("MaxSteer") or v_u_7.MAX_STEER
		local v301 = v239.steer
		local v302 = v_u_7.maxSteer(v239.speed) * v300 / v_u_7.MAX_STEER
		local v303 = v301 * math.min(v300, v302)
		local v304 = v_u_7.yawRate(v239.speed, v303, v239.wheelbase)
		local v305 = v239.handbrake
		if v305 then
			local v306 = v239.speed
			v305 = math.abs(v306) > 6
		end
		if v305 then
			v304 = v304 * 2.4
		end
		v239.heading = v239.heading - v304 * p238
		local v307 = v239.heading - v239.travel
		local v308 = math.sin(v307)
		local v309 = v239.heading - v239.travel
		local v310 = math.cos(v309)
		local v311 = math.atan2(v308, v310)
		v239.travel = v239.travel + v311 * v_u_7.alpha(v305 and 1.2 or 9, p238)
		if not v305 and math.abs(v311) < 0.008726646259971648 then
			v239.travel = v239.heading
		end
		if not v240.Anchored then
			v_u_133(v239, p238, v239.accel, v265 * v304, v251.Y)
		end
		local v312 = v240.AssemblyMass
		v239.linear.MaxAxesForce = Vector3.new(v312, 0, v312) * v_u_7.DRIVE_FORCE_PER_MASS
		v239.linear.VectorVelocity = v246 * v239.speed
		v239.align.MaxTorque = v312 * v_u_7.ALIGN_TORQUE_PER_MASS
		v239.align.CFrame = v_u_183(v239, v245, p238)
		local v313 = (v242 >= 0 or v239.speed <= v_u_7.STOPPED_SPEED) and (v242 <= 0 or v239.speed >= -v_u_7.STOPPED_SPEED) and v239.handbrake
		if v313 then
			local v314 = v239.speed
			v313 = math.abs(v314) > v_u_7.STOPPED_SPEED
		end
		local v315 = v239.speed < -0.3
		if v313 ~= v239.localBraking then
			v239.localBraking = v313
			v241:SetAttribute("LocalBraking", v313)
		end
		if v315 ~= v239.localReversing then
			v239.localReversing = v315
			v241:SetAttribute("LocalReversing", v315)
		end
		local v316 = v239.handbrake == true
		if v316 ~= v239.localHandbrake then
			v239.localHandbrake = v316
			v241:SetAttribute("LocalHandbrake", v316)
		end
		local v317 = v239.steer * 20
		local v318 = math.round(v317) / 20
		if (v318 ~= v239.sentSteer or (v313 ~= v239.sentBraking or (v315 ~= v239.sentReversing or v316 ~= v239.sentHandbrake))) and os.clock() - v239.sentAt > 0.1 then
			v239.sentAt = os.clock()
			v239.sentSteer = v318
			v239.sentBraking = v313
			v239.sentReversing = v315
			v239.sentHandbrake = v316
			v_u_26("State", v318, v313, v315, v316)
		end
		v_u_13.setLocalDriver(v241, v239.steer, not v244 and 0 or v242)
		local v319, v320 = v_u_7.rpm(v265, v250, v242)
		local v321
		if v239.gears == nil then
			v321 = false
		else
			v321 = v265 > -0.3
		end
		if v321 then
			local v322 = v_u_10.revs(v265, v250, v239.gears, v239.gear)
			v319 = v_u_7.IDLE_RPM + (v_u_7.REDLINE_RPM - v_u_7.IDLE_RPM) * v322
			if v239.gear == 1 and v242 > 0 then
				v319 = math.max(v319, 2200)
			end
			if v241:GetAttribute("Gear") ~= v239.gear then
				v241:SetAttribute("Gear", v239.gear)
			end
		end
		if v239.gears and (v239.gear ~= v239.sentGear and os.clock() - v239.gearSentAt > v_u_10.SEND_INTERVAL) then
			local v323 = v239.gear
			local v324 = os.clock()
			v239.sentGear = v323
			v239.gearSentAt = v324
			v_u_26("Gear", v239.gear)
		end
		local v325 = v_u_14.update
		local v326 = {
			["kmh"] = v_u_7.toKmh((math.abs(v265))),
			["rpm"] = not v244 and 0 or v319
		}
		local v327
		if v244 then
			if v321 then
				local v328 = v239.gear
				v327 = tostring(v328)
			else
				v327 = math.abs(v265) < 0.5 and v242 == 0 and "N" or tostring(v320)
			end
		else
			v327 = "-"
		end
		v326.gear = v327
		v326.engine = v244
		v326.lights = v241:GetAttribute("HeadlightsOn") == true
		v326.rainbow = v241:GetAttribute("RainbowOn") == true
		v326.indicator = v241:GetAttribute("Indicator") or "Off"
		v326.inside = v_u_15.mode() == "first"
		v326.tuning = v_u_16.isOpen()
		v325(v326)
	end
end
local function v_u_333(p330, p331) -- name: onInputBegan
	-- upvalues: (ref) v_u_22, (copy) v_u_26, (copy) v_u_17, (copy) v_u_15, (copy) v_u_42, (copy) v_u_18, (copy) v_u_10, (copy) v_u_39, (copy) v_u_19
	if p331 or not v_u_22 then
		return
	else
		local v332 = p330.KeyCode
		if v332 == Enum.KeyCode.L then
			v_u_26("Lights")
			return
		elseif v332 == Enum.KeyCode.G then
			v_u_26("Rainbow")
			return
		elseif v_u_17[v332] then
			v_u_26("Indicator", v_u_17[v332])
			return
		elseif v332 == Enum.KeyCode.H then
			v_u_26("Horn", true)
		elseif v332 == Enum.KeyCode.R then
			if v_u_22 then
				v_u_26("Engine", v_u_22.model:GetAttribute("EngineOn") ~= true)
				return
			end
		else
			if v332 == Enum.KeyCode.V then
				v_u_15.toggle()
				return
			end
			if v332 == Enum.KeyCode.P then
				v_u_42()
				return
			end
			if v_u_18[v332] then
				v_u_22.handbrake = true
				return
			end
			if v_u_10.UP_KEYS[v332] then
				if not v_u_10.promptOnKey(v332) then
					v_u_39(1)
					return
				end
			elseif v_u_19[v332] then
				v_u_39(-1)
			end
		end
	end
end
local function v_u_335(p334) -- name: onInputEnded
	-- upvalues: (ref) v_u_22, (copy) v_u_26, (copy) v_u_18
	if v_u_22 and p334.KeyCode == Enum.KeyCode.H then
		v_u_26("Horn", false)
	end
	if v_u_22 and v_u_18[p334.KeyCode] then
		v_u_22.handbrake = false
	end
end
function v_u_21.start(p336, p_u_337, p_u_338) -- name: start
	-- upvalues: (ref) v_u_22, (copy) v_u_21, (ref) v_u_23, (copy) v_u_7, (copy) v_u_20, (copy) v_u_3, (copy) v_u_156, (copy) v_u_10, (copy) v_u_12, (copy) v_u_5, (copy) v_u_329, (copy) v_u_6, (copy) v_u_333, (copy) v_u_335, (copy) v_u_223, (copy) v_u_2, (copy) v_u_41, (copy) v_u_26, (copy) v_u_15, (copy) v_u_14, (copy) v_u_27, (copy) v_u_34, (copy) v_u_29, (copy) v_u_31, (copy) v_u_32, (copy) v_u_33, (copy) v_u_42, (copy) v_u_39
	if v_u_22 and v_u_22.model == p336 then
		return
	else
		v_u_21.stop()
		local v339 = p336:FindFirstChild("Chassis")
		if v339 then
			local v340 = {}
			v_u_23 = v340
			local v341 = v339:WaitForChild("DriveVelocity", 5)
			local v342 = v339:WaitForChild("DriveAlign", 5)
			if v_u_23 == v340 then
				v_u_23 = nil
				if v341 and v342 then
					local v343 = v_u_7.flatRotation(v342.CFrame).LookVector
					local v344 = {}
					for _, v345 in v_u_20 do
						local v346 = p336:FindFirstChild("WheelCollider" .. v345)
						if v346 then
							v346 = v346:FindFirstChild("RideWeld")
						end
						if not v346 then
							continue
						end
						v344[v345] = {
							["weld"] = nil,
							["front"] = nil,
							["side"] = nil,
							["comp"] = 0,
							["vel"] = 0,
							["rest0Y"] = nil,
							["weld"] = v346,
							["front"] = v345:sub(1, 5) == "Front",
							["side"] = v345:find("Left") and -1 or 1,
							["rest0Y"] = v346.C0.Y
						}
					end
					local v347 = {}
					for _, v348 in v_u_20 do
						v347[v348] = v339:FindFirstChild("Ground" .. v348)
					end
					local v349 = p336:FindFirstChild("BodyCollider")
					local v350 = RaycastParams.new()
					v350.FilterType = Enum.RaycastFilterType.Exclude
					v350.FilterDescendantsInstances = { p336, p_u_337.Parent }
					local v351 = {
						["model"] = p336,
						["chassis"] = v339,
						["seat"] = p_u_338,
						["linear"] = v341,
						["align"] = v342
					}
					local v352 = -v343.X
					local v353 = -v343.Z
					v351.heading = math.atan2(v352, v353)
					v351.speed = v339.Anchored and 0 or v339.AssemblyLinearVelocity:Dot(v343)
					v351.steer = 0
					v351.autoAt = 0
					v351.sentAt = 0
					v351.sentSteer = 0
					v351.sentBraking = false
					v351.sentReversing = false
					v351.wheelbase = p336:GetAttribute("Wheelbase") or 10
					v351.savedMinZoom = v_u_3.LocalPlayer.CameraMinZoomDistance
					v351.character = p_u_337.Parent
					v351.hintAt = 0
					v351.history = {}
					v351.impactAt = 0
					v351.hitPeople = setmetatable({}, {
						["__mode"] = "k"
					})
					v351.accel = 0
					v351.pedalDrop = 0
					v351.lastVy = 0
					v351.wheels = v344
					v351.room = v_u_156(p336, v339, v344)
					v351.groundPoints = v347
					v351.groundPitch = 0
					v351.groundRoll = 0
					v351.track = p336:GetAttribute("Track") or 7
					v351.params = v350
					v351.halfLength = not v349 and 10 or v349.Size.Z / 2
					v351.halfWidth = not v349 and 4 or v349.Size.X / 2
					v351.gears = v_u_10.gears(p336)
					v351.gear = 1
					v351.sentGear = nil
					v351.gearSentAt = 0
					v351.top = 0
					v351.bump = v_u_12.new(v339, p336, { p336, p_u_337.Parent })
					v_u_22 = v351
					if v_u_22.gears then
						local v354 = v_u_22
						v354.gear = 1
						v354.model:SetAttribute("Gear", 1)
						v_u_10.watchPrompts()
					end
					v_u_22.connections = { v_u_5.Heartbeat:Connect(v_u_329), v_u_6.InputBegan:Connect(v_u_333), v_u_6.InputEnded:Connect(v_u_335) }
					if v349 then
						local v355 = v_u_22.connections
						local v356 = v349.Touched
						local v357 = v_u_223
						table.insert(v355, v356:Connect(v357))
					end
					v_u_2:BindActionAtPriority("CarExit", v_u_41, false, Enum.ContextActionPriority.High.Value, Enum.KeyCode.Space, Enum.KeyCode.ButtonA)
					local v358 = v_u_22.connections
					local v359 = p_u_337:GetPropertyChangedSignal("Jump")
					local function v360()
						-- upvalues: (copy) p_u_337, (copy) p_u_338, (ref) v_u_22, (ref) v_u_26
						if p_u_337.Jump and p_u_337.SeatPart == p_u_338 then
							p_u_337.Jump = false
							if v_u_22 and os.clock() - (v_u_22.exitAt or 0) > 0.5 then
								v_u_22.exitAt = os.clock()
								v_u_26("Exit")
							end
						end
					end
					table.insert(v358, v359:Connect(v360))
					v_u_15.start(p336, p_u_337)
					local v361 = v_u_3.LocalPlayer
					local v362 = v361.CameraMinZoomDistance
					v361.CameraMinZoomDistance = math.max(v362, 0.5)
					v_u_14.start({
						["onLights"] = v_u_27,
						["onRainbow"] = v_u_34,
						["onIndicator"] = v_u_29,
						["onHorn"] = v_u_31,
						["onEngine"] = v_u_32,
						["onView"] = v_u_33,
						["onTune"] = v_u_42,
						["onGearUp"] = function() -- name: onGearUp
							-- upvalues: (ref) v_u_39
							v_u_39(1)
						end,
						["onGearDown"] = function() -- name: onGearDown
							-- upvalues: (ref) v_u_39
							v_u_39(-1)
						end,
						["gears"] = v_u_22.gears,
						["name"] = p336:GetAttribute("DisplayName") or (p336:GetAttribute("CarName") or p336.Name),
						["model"] = p336
					})
				else
					warn("Car: drive constraints not found on", p336:GetFullName())
				end
			else
				return
			end
		else
			return
		end
	end
end
local function v_u_390(p363, p364, p365) -- name: slideOut
	-- upvalues: (copy) v_u_7, (copy) v_u_5
	local v366 = p364:FindFirstChild("Exit" .. (p365 or ""))
	local v_u_367 = p363:FindFirstChild("HumanoidRootPart")
	if v366 and v_u_367 then
		local v_u_368 = v_u_367.CFrame
		local v369 = v366.WorldPosition
		local v370 = RaycastParams.new()
		v370.FilterType = Enum.RaycastFilterType.Exclude
		v370.FilterDescendantsInstances = { p364.Parent, p363 }
		local v371 = workspace:Raycast(v369 + Vector3.new(0, 3, 0), Vector3.new(0, -12, 0), v370)
		local v372 = p363:FindFirstChildOfClass("Humanoid")
		if v371 and v372 then
			local v373 = v369.X
			local v374 = v371.Position.Y + v372.HipHeight + v_u_367.Size.Y / 2
			local v375 = v369.Z
			v369 = Vector3.new(v373, v374, v375)
		end
		local v_u_376 = CFrame.new(v369) * v_u_7.flatRotation(p364.CFrame)
		local v_u_377 = {}
		for _, v378 in p363:GetDescendants() do
			if not v378:IsA("BasePart") then
				continue
			end
			v_u_377[v378] = v378.CollisionGroup
			v378.CollisionGroup = v_u_7.EXIT_COLLISION_GROUP
		end
		v_u_367.Anchored = true
		local v_u_379 = os.clock()
		local v_u_380 = nil
		v_u_380 = v_u_5.Heartbeat:Connect(function()
			-- upvalues: (copy) v_u_379, (copy) v_u_367, (copy) v_u_368, (copy) v_u_376, (ref) v_u_380, (copy) v_u_377
			local v381 = (os.clock() - v_u_379) / 0.55
			local v382 = math.clamp(v381, 0, 1)
			local v383 = v382 * v382 * (3 - v382 * 2)
			if v_u_367.Parent then
				local v384 = v_u_368.Position:Lerp(v_u_376.Position, v383)
				local v385 = 3.141592653589793 * v383
				local v386 = math.sin(v385) * 0.4
				local v387 = v384 + Vector3.new(0, v386, 0)
				v_u_367.CFrame = CFrame.new(v387) * v_u_368.Rotation:Lerp(v_u_376.Rotation, v383)
			end
			if v382 >= 1 or not v_u_367.Parent then
				v_u_380:Disconnect()
				for v388, v389 in v_u_377 do
					if not v388.Parent then
						continue
					end
					v388.CollisionGroup = v389
				end
				if v_u_367.Parent then
					v_u_367.Anchored = false
					v_u_367.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
				end
			end
		end)
	end
end
function v_u_21.stop() -- name: stop
	-- upvalues: (ref) v_u_23, (ref) v_u_22, (copy) v_u_390, (copy) v_u_2, (copy) v_u_26, (copy) v_u_16, (copy) v_u_3, (copy) v_u_15, (copy) v_u_186, (copy) v_u_13, (copy) v_u_14
	v_u_23 = nil
	if v_u_22 then
		local v391 = v_u_22.character
		local v392 = v391 and v391.Parent
		if v392 then
			v392 = v391:FindFirstChildOfClass("Humanoid")
		end
		if v392 and (v392.Health > 0 and v392.SeatPart == nil) then
			task.defer(v_u_390, v391, v_u_22.chassis, v_u_22.seat:GetAttribute("SeatKey"))
		end
		for _, v393 in v_u_22.connections do
			v393:Disconnect()
		end
		v_u_2:UnbindAction("CarExit")
		if v_u_22.model:GetAttribute("HornOn") then
			v_u_26("Horn", false)
		end
		if v_u_16.isOpen() then
			v_u_16.close()
		end
		local v394 = v_u_3.LocalPlayer
		if v394.CameraMode == Enum.CameraMode.LockFirstPerson then
			v394.CameraMode = Enum.CameraMode.Classic
		end
		v394.CameraMinZoomDistance = v_u_22.savedMinZoom or 0.5
		v_u_15.stop()
		v_u_186(v_u_22)
		if v_u_22.scraper then
			v_u_22.scraper:destroy()
		end
		v_u_22 = nil
		v_u_13.setLocalDriver(nil)
		v_u_14.stop()
	end
end
function v_u_21.model() -- name: model
	-- upvalues: (ref) v_u_22
	local v395 = v_u_22
	if v395 then
		v395 = v_u_22.model
	end
	return v395
end
return v_u_21