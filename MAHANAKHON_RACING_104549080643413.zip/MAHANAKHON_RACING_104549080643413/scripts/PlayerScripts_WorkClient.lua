-- Path: Players/ygggggg55551/PlayerScripts/WorkClient
-- Class: LocalScript  true/Enum.RunContext.Legacy
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = game:GetService("CollectionService")
local v_u_2 = game:GetService("HttpService")
local v3 = game:GetService("Players")
local v4 = game:GetService("ReplicatedStorage")
local v5 = game:GetService("RunService")
local v_u_6 = game:GetService("TweenService")
local v7 = require(v4:WaitForChild("GameShared"))
local v_u_8 = require(v4:WaitForChild("JobShared"))
local v_u_9 = require(v4:WaitForChild("NetSeal"))
local v10 = v4:WaitForChild("GameUI")
local v_u_11 = require(v10:WaitForChild("Theme"))
local v_u_12 = require(v10:WaitForChild("Icons"))
local v_u_13 = require(v10:WaitForChild("Toast"))
local v_u_14 = require(v10:WaitForChild("Minigames"))
local v_u_15 = require(v10:WaitForChild("IceCreamWork"))
local v_u_16 = v3.LocalPlayer
local v17 = v4:WaitForChild(v7.REMOTES)
local v_u_18 = v17:WaitForChild(v_u_8.WORK_REMOTE)
local v_u_19 = v17:WaitForChild(v_u_8.REMOTE)
local v_u_20 = v4:WaitForChild("JobPlaces", 15)
local v_u_21 = {
	["Board"] = "Job Board",
	["Bay1"] = "Repair Bay 1",
	["Bay2"] = "Repair Bay 2",
	["Bay3"] = "Repair Bay 3",
	["Pile"] = "Cement Pile",
	["Mixer"] = "Cement Mixer",
	["Bricks"] = "Brick Wall",
	["Paint"] = "Wall to Paint"
}
local v_u_22 = {
	["Mechanic"] = "Mahanakhon Auto Service",
	["Builder"] = "Construction Site",
	["Courier"] = "Delivery Office",
	["IceCream"] = "MHNK ICECREAM"
}
local v_u_23 = Instance.new("Attachment")
v_u_23.Name = "DepotMarker"
local v24 = v_u_8.DEPOT.x
local v25 = (v_u_8.DEPOT.y or 0) + 3
local v26 = v_u_8.DEPOT.z
v_u_23.WorldPosition = Vector3.new(v24, v25, v26)
v_u_23.Parent = workspace.Terrain
local v_u_27 = false
local v_u_28 = nil
local v_u_29 = false
local v_u_30 = v_u_11.isTouch()
local v_u_31 = v_u_30 and 300 or 440
local v_u_32 = v_u_30 and 44 or 64
local v33 = v_u_30 and 32 or 44
local v34 = (v_u_32 - v33) / 2
local v_u_35 = v34 + v33 + (v_u_30 and 8 or 12)
local v36 = v_u_30 and 30 or 40
local v_u_37 = v_u_35 + 118
local v38 = v_u_11.screen("WorkHud", 6, v_u_16:WaitForChild("PlayerGui"))
local v_u_39 = v_u_11.panel({
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Visible"] = false,
	["ClipsDescendants"] = true,
	["Parent"] = nil,
	["AnchorPoint"] = Vector2.new(0.5, 0),
	["Position"] = UDim2.new(0.5, 0, 0, v_u_30 and 4 or 64),
	["Size"] = UDim2.fromOffset(v_u_31, v_u_32),
	["Parent"] = v38
})
v_u_39.UICorner.CornerRadius = UDim.new(0, not v_u_30 and 18 or v_u_32 / 2)
v_u_11.autoScale(v_u_39)
local v_u_40 = v_u_11.new("Frame", {
	["BorderSizePixel"] = 0,
	["BackgroundColor3"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["BackgroundColor3"] = Color3.new(1, 1, 1),
	["Position"] = UDim2.fromOffset(v34, v34),
	["Size"] = UDim2.fromOffset(v33, v33),
	["Parent"] = v_u_39
})
v_u_11.corner(v_u_40, not v_u_30 and 12 or v33 / 2)
local v_u_41 = v_u_11.new("UIGradient", {
	["Rotation"] = 90,
	["Parent"] = nil,
	["Parent"] = v_u_40
})
v_u_11.gloss(v_u_40, not v_u_30 and 12 or v33 / 2, 0.25)
local v_u_42 = nil
local v_u_43 = v_u_11.text({
	["FontFace"] = v_u_11.FONT_HEAVY,
	["TextSize"] = v_u_30 and 14 or 19,
	["TextXAlignment"] = Enum.TextXAlignment.Left,
	["TextTruncate"] = Enum.TextTruncate.AtEnd,
	["Position"] = UDim2.fromOffset(v_u_35, v_u_30 and 5 or 9),
	["Size"] = UDim2.new(1, -(v_u_35 + v36 + v34 + 6), 0, v_u_30 and 18 or 24),
	["Parent"] = v_u_39
})
local v_u_44 = v_u_11.text({
	["TextSize"] = v_u_30 and 11 or 14,
	["TextColor3"] = v_u_11.TEXT_DIM,
	["TextXAlignment"] = Enum.TextXAlignment.Left,
	["TextTruncate"] = Enum.TextTruncate.AtEnd,
	["Position"] = UDim2.fromOffset(v_u_35, v_u_30 and 23 or 34),
	["Size"] = UDim2.new(1, -(v_u_35 + v36 + v34 + 6), 0, v_u_30 and 15 or 20),
	["Parent"] = v_u_39
})
local v_u_45 = false
local function v_u_59(p46) -- name: setFolded
	-- upvalues: (ref) v_u_45, (copy) v_u_6, (copy) v_u_39, (copy) v_u_37, (copy) v_u_31, (copy) v_u_32, (copy) v_u_44, (ref) v_u_28, (copy) v_u_43, (copy) v_u_35, (copy) v_u_30
	v_u_45 = p46
	local v47 = v_u_6
	local v48 = v_u_39
	local v49 = TweenInfo.new(0.22, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	local v50 = {}
	local v51 = UDim2.fromOffset
	local v52
	if p46 then
		v52 = v_u_37
	else
		v52 = v_u_31
	end
	v50.Size = v51(v52, v_u_32)
	v47:Create(v48, v49, v50):Play()
	v_u_44.Visible = not p46
	local v53 = v_u_39:FindFirstChild("Quit")
	if v53 then
		local v54 = not p46
		if v54 then
			v54 = v_u_28 ~= nil
		end
		v53.Visible = v54
	end
	local v55 = v_u_43
	local v56 = UDim2.fromOffset
	local v57 = v_u_35
	local v58
	if p46 then
		v58 = (v_u_32 - (v_u_30 and 18 or 24)) / 2
	else
		v58 = v_u_30 and 5 or 9
	end
	v55.Position = v56(v57, v58)
end
local v_u_60 = 0
local function v_u_62() -- name: unfoldForAWhile
	-- upvalues: (copy) v_u_30, (copy) v_u_59, (ref) v_u_60
	if v_u_30 then
		v_u_59(false)
		local v_u_61 = os.clock()
		v_u_60 = v_u_61
		task.delay(6, function()
			-- upvalues: (ref) v_u_60, (copy) v_u_61, (ref) v_u_59
			if v_u_60 == v_u_61 then
				v_u_59(true)
			end
		end)
	end
end
if v_u_30 then
	v_u_11.new("TextButton", {
		["Name"] = "Fold",
		["Text"] = "",
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["ZIndex"] = 1,
		["Parent"] = nil,
		["Size"] = UDim2.fromScale(1, 1),
		["Parent"] = v_u_39
	}).Activated:Connect(function()
		-- upvalues: (ref) v_u_45, (copy) v_u_62, (ref) v_u_60, (copy) v_u_59
		if v_u_45 then
			v_u_62()
		else
			v_u_60 = 0
			v_u_59(true)
		end
	end)
	v_u_43:GetPropertyChangedSignal("Text"):Connect(v_u_62)
end
local v_u_63 = v_u_11.new("TextButton", {
	["Name"] = "Quit",
	["Text"] = "",
	["BackgroundColor3"] = nil,
	["AutoButtonColor"] = true,
	["BorderSizePixel"] = 0,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["ZIndex"] = 3,
	["Parent"] = nil,
	["BackgroundColor3"] = Color3.fromRGB(56, 58, 64),
	["AnchorPoint"] = Vector2.new(1, 0.5),
	["Position"] = UDim2.new(1, -v34, 0.5, 0),
	["Size"] = UDim2.fromOffset(v36, v36),
	["Parent"] = v_u_39
})
v_u_11.corner(v_u_63, not v_u_30 and 10 or v36 / 2)
local v64 = v_u_12.make("close", v_u_11.TEXT, v_u_30 and 16 or 20)
v64.AnchorPoint = Vector2.new(0.5, 0.5)
v64.Position = UDim2.fromScale(0.5, 0.5)
v64.Parent = v_u_63
v_u_63.Activated:Connect(function()
	-- upvalues: (copy) v_u_16, (copy) v_u_9, (copy) v_u_19, (copy) v_u_18, (copy) v_u_13
	local v65 = v_u_16:GetAttribute("PlannedJob")
	if v65 and v65 ~= v_u_16:GetAttribute("Job") then
		local v66 = v_u_9.invoke
		local v67 = v_u_19
		pcall(v66, v67, "Plan", "")
	else
		local v68 = v_u_9.invoke
		local v69 = v_u_18
		local v70, v71, v72 = pcall(v68, v69, "Quit", nil)
		if v70 and v72 then
			v_u_13.show(v72, v71 and "ok" or "error")
		end
	end
end)
local v73 = v_u_30 and 70 or 92
local v74 = v_u_30 and 52 or 70
local v75 = (v73 - v74) / 2
local v_u_76 = Color3.fromRGB(214, 22, 46)
local v77 = Color3.fromRGB(34, 28, 32)
local v_u_78 = v_u_11.new("Frame", {
	["Name"] = "OrderCard",
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["BackgroundColor3"] = nil,
	["BorderSizePixel"] = 0,
	["Visible"] = false,
	["Parent"] = nil,
	["AnchorPoint"] = Vector2.new(0.5, 0),
	["Position"] = UDim2.new(0.5, 0, 0, v_u_30 and 4 or 62),
	["Size"] = UDim2.fromOffset(v_u_30 and 330 or 450, v73),
	["BackgroundColor3"] = Color3.fromRGB(252, 252, 252),
	["Parent"] = v38
})
v_u_11.corner(v_u_78, v_u_30 and 14 or 18)
v_u_11.new("UIStroke", {
	["Color"] = nil,
	["Thickness"] = 2,
	["Transparency"] = 0.35,
	["Parent"] = nil,
	["Color"] = v_u_76,
	["Parent"] = v_u_78
})
v_u_11.autoScale(v_u_78)
local v_u_79 = v_u_11.new("UIScale", {
	["Parent"] = v_u_11.new("Frame", {
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Parent"] = nil,
		["Size"] = UDim2.fromScale(1, 1),
		["Parent"] = v_u_78
	})
})
local v_u_80 = v_u_11.new("Frame", {
	["BackgroundColor3"] = nil,
	["BorderSizePixel"] = 0,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["BackgroundColor3"] = v_u_76,
	["Position"] = UDim2.fromOffset(v75, v75),
	["Size"] = UDim2.fromOffset(v74, v74),
	["Parent"] = v_u_78
})
v_u_11.corner(v_u_80, v_u_30 and 12 or 16)
v_u_11.new("UIGradient", {
	["Rotation"] = 90,
	["Color"] = nil,
	["Parent"] = nil,
	["Color"] = ColorSequence.new(Color3.fromRGB(240, 60, 76), Color3.fromRGB(176, 10, 32)),
	["Parent"] = v_u_80
})
local v_u_81 = v_u_11.text({
	["Text"] = "\224\184\130\224\184\177\224\185\137\224\184\153",
	["FontFace"] = nil,
	["TextSize"] = nil,
	["TextColor3"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["FontFace"] = v_u_11.FONT_BOLD,
	["TextSize"] = v_u_30 and 12 or 15,
	["TextColor3"] = Color3.new(1, 1, 1),
	["Position"] = UDim2.fromOffset(0, v_u_30 and 4 or 7),
	["Size"] = UDim2.new(1, 0, 0, v_u_30 and 14 or 18),
	["Parent"] = v_u_80
})
local v_u_82 = v_u_11.text({
	["Text"] = "1/3",
	["FontFace"] = nil,
	["TextScaled"] = true,
	["TextColor3"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["FontFace"] = v_u_11.FONT_DISPLAY,
	["TextColor3"] = Color3.new(1, 1, 1),
	["Position"] = UDim2.new(0.1, 0, 0, v_u_30 and 18 or 25),
	["Size"] = UDim2.new(0.8, 0, 0, v_u_30 and 26 or 34),
	["Parent"] = v_u_80
})
local v83 = v75 + v74 + (v_u_30 and 10 or 14)
local v84 = v_u_30 and 26 or 32
local v_u_85 = v_u_11.text({
	["Text"] = "",
	["FontFace"] = nil,
	["TextSize"] = nil,
	["TextColor3"] = nil,
	["TextXAlignment"] = nil,
	["TextTruncate"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["FontFace"] = v_u_11.FONT_HEAVY,
	["TextSize"] = v_u_30 and 17 or 23,
	["TextColor3"] = v77,
	["TextXAlignment"] = Enum.TextXAlignment.Left,
	["TextTruncate"] = Enum.TextTruncate.AtEnd,
	["Position"] = UDim2.fromOffset(v83, v_u_30 and 7 or 10),
	["Size"] = UDim2.new(1, -(v83 + v84 + 14), 0, v_u_30 and 22 or 28),
	["Parent"] = v_u_78
})
local v_u_86 = v_u_11.text({
	["Text"] = "",
	["FontFace"] = nil,
	["TextSize"] = nil,
	["TextColor3"] = nil,
	["TextXAlignment"] = nil,
	["TextTruncate"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["FontFace"] = v_u_11.FONT_BOLD,
	["TextSize"] = v_u_30 and 12 or 15,
	["TextColor3"] = Color3.fromRGB(120, 112, 118),
	["TextXAlignment"] = Enum.TextXAlignment.Left,
	["TextTruncate"] = Enum.TextTruncate.AtEnd,
	["Position"] = UDim2.fromOffset(v83, v_u_30 and 30 or 40),
	["Size"] = UDim2.new(1, -(v83 + 12), 0, v_u_30 and 16 or 20),
	["Parent"] = v_u_78
})
local v_u_87 = v_u_11.new("Frame", {
	["BackgroundTransparency"] = 1,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["Position"] = UDim2.new(0, v83, 1, -(v75 + (v_u_30 and 8 or 10))),
	["Size"] = UDim2.new(1, -(v83 + 14), 0, v_u_30 and 6 or 8),
	["Parent"] = v_u_78
})
v_u_11.new("UIListLayout", {
	["FillDirection"] = Enum.FillDirection.Horizontal,
	["Padding"] = UDim.new(0, 6),
	["SortOrder"] = Enum.SortOrder.LayoutOrder,
	["Parent"] = v_u_87
})
local v_u_88 = v_u_11.new("TextButton", {
	["Text"] = "",
	["BackgroundColor3"] = nil,
	["AutoButtonColor"] = true,
	["BorderSizePixel"] = 0,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["BackgroundColor3"] = Color3.fromRGB(236, 232, 234),
	["AnchorPoint"] = Vector2.new(1, 0),
	["Position"] = UDim2.new(1, -10, 0, 10),
	["Size"] = UDim2.fromOffset(v84, v84),
	["Parent"] = v_u_78
})
v_u_11.corner(v_u_88, v84 / 2)
local v89 = v_u_12.make("close", Color3.fromRGB(120, 112, 118), v_u_30 and 14 or 18)
v89.AnchorPoint = Vector2.new(0.5, 0.5)
v89.Position = UDim2.fromScale(0.5, 0.5)
v89.Parent = v_u_88
v_u_88.Activated:Connect(function()
	-- upvalues: (copy) v_u_9, (copy) v_u_18, (copy) v_u_13
	local v90 = v_u_9.invoke
	local v91 = v_u_18
	local v92, v93, v94 = pcall(v90, v91, "Quit", nil)
	if v92 and v94 then
		v_u_13.show(v94, v93 and "ok" or "error")
	end
end)
local v_u_95 = nil
local v_u_96 = nil
local function v_u_107(p97, p98, p99) -- name: setSteps
	-- upvalues: (copy) v_u_87, (copy) v_u_11, (copy) v_u_76
	for _, v100 in v_u_87:GetChildren() do
		if not v100:IsA("Frame") then
			continue
		end
		v100:Destroy()
	end
	if p97 > 0 then
		for v101 = 1, p97 do
			local v102 = v_u_11.new
			local v103 = "Frame"
			local v104 = {
				["BorderSizePixel"] = 0,
				["LayoutOrder"] = nil,
				["Size"] = nil,
				["BackgroundColor3"] = nil,
				["Parent"] = nil,
				["LayoutOrder"] = v101,
				["Size"] = UDim2.new(1 / p97, -6 + 6 / p97, 1, 0)
			}
			local v105
			if v101 <= p98 then
				v105 = v_u_76
			elseif v101 == p99 then
				v105 = Color3.fromRGB(246, 150, 160)
			else
				v105 = Color3.fromRGB(226, 222, 224)
			end
			v104.BackgroundColor3 = v105
			v104.Parent = v_u_87
			local v106 = v102(v103, v104)
			v_u_11.corner(v106, 4)
		end
	end
end
local function v_u_127(p108, p109) -- name: showOrderCard
	-- upvalues: (copy) v_u_78, (copy) v_u_16, (ref) v_u_28, (copy) v_u_8, (copy) v_u_81, (copy) v_u_82, (copy) v_u_85, (copy) v_u_21, (copy) v_u_86, (copy) v_u_107, (copy) v_u_87, (ref) v_u_96, (ref) v_u_95, (copy) v_u_79, (copy) v_u_11, (copy) v_u_80, (copy) v_u_6, (copy) v_u_88
	v_u_78.Visible = true
	local v110 = v_u_16:GetAttribute("WorkCount") or 0
	local v111
	if v_u_28 then
		local v112 = v_u_8.task(v_u_28.job, v_u_28.task)
		local v113 = v_u_28
		if v113 and v_u_8.ORDER_JOBS[v113.job] then
			v113 = v_u_8.step(v113.job, v113.task, v113.n or 1)
		elseif v113 then
			v113 = v_u_8.task(v113.job, v113.task)
		end
		local v114 = v_u_28.n or 1
		local v115 = v_u_28.of or (v112 and v112.steps and (#v112.steps or 1) or 1)
		v_u_81.Text = "\224\184\130\224\184\177\224\185\137\224\184\153"
		v_u_82.Text = ("%d/%d"):format(v114, v115)
		v_u_85.Text = not v113 and "\224\184\151\224\184\179\224\184\173\224\184\173\224\185\128\224\184\148\224\184\173\224\184\163\224\185\140" or v113.th
		local v116 = v_u_28.station
		local v117 = v_u_8.PLACES
		if v117 then
			v117 = v_u_8.PLACES[p108]
		end
		local v118 = v117 and v117[v116] or (v_u_21[v116] or v116)
		v_u_86.Text = ("%s %s  \194\183  %s"):format(v112 and (v112.emoji or "") or "", v112 and v112.th or "", v_u_28.step == "doing" and "\224\184\129\224\184\179\224\184\165\224\184\177\224\184\135\224\184\151\224\184\179\226\128\166" or "\224\185\132\224\184\155\224\184\151\224\184\181\224\185\136 " .. v118)
		v_u_107(v115, v114 - 1, v114)
		v111 = ("%s:%d:%s"):format(v_u_28.task, v114, v_u_28.step)
	elseif p109 > 0 then
		v_u_81.Text = "\224\184\158\224\184\177\224\184\129"
		local v119 = v_u_82
		local v120 = math.ceil(p109)
		v119.Text = tostring(v120)
		v_u_85.Text = "\224\184\165\224\184\185\224\184\129\224\184\132\224\185\137\224\184\178\224\184\132\224\184\153\224\184\149\224\185\136\224\184\173\224\185\132\224\184\155\224\184\129\224\184\179\224\184\165\224\184\177\224\184\135\224\184\161\224\184\178\226\128\166"
		v_u_86.Text = ("MHNK ICECREAM  \194\183  \224\185\128\224\184\170\224\184\180\224\184\163\224\185\140\224\184\159\224\185\129\224\184\165\224\185\137\224\184\167 %d \224\184\173\224\184\173\224\185\128\224\184\148\224\184\173\224\184\163\224\185\140"):format(v110)
		for _, v121 in v_u_87:GetChildren() do
			if not v121:IsA("Frame") then
				continue
			end
			v121:Destroy()
		end
		v111 = "wait"
	else
		v_u_81.Text = "\224\184\163\224\185\137\224\184\178\224\184\153"
		v_u_82.Text = "\240\159\141\166"
		v_u_85.Text = v_u_96 and "\224\185\132\224\184\155\224\184\151\224\184\179\224\184\135\224\184\178\224\184\153\224\184\151\224\184\181\224\185\136\224\184\163\224\185\137\224\184\178\224\184\153 MHNK ICECREAM" or "\224\184\163\224\184\177\224\184\154\224\184\173\224\184\173\224\185\128\224\184\148\224\184\173\224\184\163\224\185\140\224\184\151\224\184\181\224\185\136\224\185\128\224\184\132\224\184\178\224\184\153\224\185\140\224\185\128\224\184\149\224\184\173\224\184\163\224\185\140 (E)"
		local v122 = v_u_86
		local v123
		if v_u_96 then
			v123 = v_u_96
		else
			v123 = ("MHNK ICECREAM  \194\183  \224\185\128\224\184\170\224\184\180\224\184\163\224\185\140\224\184\159\224\185\129\224\184\165\224\185\137\224\184\167 %d \224\184\173\224\184\173\224\185\128\224\184\148\224\184\173\224\184\163\224\185\140"):format(v110)
		end
		v122.Text = v123
		for _, v124 in v_u_87:GetChildren() do
			if not v124:IsA("Frame") then
				continue
			end
			v124:Destroy()
		end
		v111 = "ready"
	end
	if v111 ~= v_u_95 then
		v_u_95 = v111
		v_u_79.Scale = 1
		local v125 = {
			["Scale"] = 0.94,
			["Parent"] = nil,
			["Parent"] = v_u_80
		}
		local v_u_126 = v_u_11.new("UIScale", v125)
		v_u_6:Create(v_u_126, TweenInfo.new(0.3, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
			["Scale"] = 1
		}):Play()
		task.delay(0.35, function()
			-- upvalues: (copy) v_u_126
			v_u_126:Destroy()
		end)
	end
	v_u_88.Visible = v_u_28 ~= nil
end
local v_u_128 = Instance.new("Part")
v_u_128.Name = "WorkBeacon"
v_u_128.Shape = Enum.PartType.Cylinder
v_u_128.Size = Vector3.new(90, 3, 3)
v_u_128.Material = Enum.Material.Neon
v_u_128.Transparency = 0.5
v_u_128.Anchored = true
v_u_128.CanCollide = false
v_u_128.CanQuery = false
v_u_128.CanTouch = false
v_u_128.CastShadow = false
local function v_u_133(p129) -- name: wordLocker
	-- upvalues: (copy) v_u_8, (copy) v_u_16
	local v130 = p129:FindFirstChild("LockerPrompt")
	local v131 = v_u_8.job(p129:GetAttribute("Job"))
	if v130 then
		v130.Enabled = v131 ~= nil
	end
	if v130 and v131 then
		local v132 = v_u_16:GetAttribute("Job") == v131.id
		v130.ObjectText = "\224\184\149\224\184\185\224\185\137\224\185\128\224\184\129\224\185\135\224\184\154\224\184\130\224\184\173\224\184\135 " .. v131.th
		v130.ActionText = v132 and "\224\184\150\224\184\173\224\184\148\224\184\138\224\184\184\224\184\148 (\224\185\128\224\184\165\224\184\180\224\184\129\224\184\135\224\184\178\224\184\153)" or "\224\185\131\224\184\170\224\185\136\224\184\138\224\184\184\224\184\148 (\224\185\128\224\184\163\224\184\180\224\185\136\224\184\161\224\184\135\224\184\178\224\184\153)"
	end
end
v_u_1:GetInstanceAddedSignal("JobLocker"):Connect(function(p134)
	-- upvalues: (copy) v_u_133
	p134:WaitForChild("LockerPrompt", 5)
	v_u_133(p134)
end)
v_u_16:GetAttributeChangedSignal("Job"):Connect(function() -- name: wordLockers
	-- upvalues: (copy) v_u_1, (copy) v_u_133
	for _, v135 in v_u_1:GetTagged("JobLocker") do
		v_u_133(v135)
	end
end)
local v_u_136 = v_u_28
local v_u_137 = v_u_96
local v_u_138 = v_u_45
local function v_u_154(p139) -- name: placeNear
	-- upvalues: (copy) v_u_20, (copy) v_u_16
	if v_u_20 then
		local v140 = v_u_16.Character
		if v140 then
			v140 = v140:FindFirstChild("HumanoidRootPart")
		end
		if v140 then
			v140 = v140.Position
		end
		local v141 = 1
		local v142 = {}
		local v143 = false
		while true do
			local v144 = v_u_20:GetAttribute(p139 .. "_L" .. v141)
			if typeof(v144) ~= "Vector3" then
				break
			end
			local v145 = v_u_20:GetAttribute(p139 .. "_L" .. v141 .. "_Open")
			local v146 = {
				["pos"] = v144,
				["open"] = v145,
				["place"] = v_u_20:GetAttribute(p139 .. "_L" .. v141 .. "Place")
			}
			local v147
			if v140 then
				v147 = (v144 - v140).Magnitude
			else
				v147 = v141
			end
			v146.d = v147
			table.insert(v142, v146)
			v143 = (type(v145) ~= "number" or v145 > 0) and true or v143
			v141 = v141 + 1
		end
		local v148 = nil
		for _, v149 in v142 do
			local v150 = not v143
			if not v150 then
				local v151 = v149.open
				v150 = type(v151) ~= "number" and true or v149.open > 0
			end
			if not v150 or v148 ~= nil and v149.d >= v148.d then
				continue
			end
			v148 = v149
		end
		if v148 then
			local v152 = v148.pos
			local v153 = v148.place
			if type(v153) == "string" and v148.place ~= "" then
				return v152, v148.place
			else
				return v152, nil
			end
		else
			return v_u_20:GetAttribute(p139), nil
		end
	else
		return nil, nil
	end
end
local function v_u_161(p155) -- name: lockerOf
	-- upvalues: (copy) v_u_16, (copy) v_u_1
	local v156 = v_u_16.Character
	if v156 then
		v156 = v156:FindFirstChild("HumanoidRootPart")
	end
	if v156 then
		v156 = v156.Position
	end
	local v157 = (1 / 0)
	local v158 = nil
	for _, v159 in v_u_1:GetTagged("JobLocker") do
		if v159:GetAttribute("Job") ~= p155 or not v159:IsDescendantOf(workspace) then
			continue
		end
		local v160 = not v156 and 0 or (v159.Position - v156).Magnitude
		if v160 >= v157 then
			continue
		end
		v158 = v159
		v157 = v160
	end
	return v158
end
local v_u_162 = nil
local v_u_163 = {}
for _, v164 in v_u_1:GetTagged("JobLocker") do
	v_u_133(v164)
end
local v_u_165 = v_u_11.new("BillboardGui", {
	["Name"] = "WorkMarker",
	["AlwaysOnTop"] = true,
	["Size"] = nil,
	["StudsOffset"] = Vector3.new(0, 4.5, 0),
	["LightInfluence"] = 0,
	["Enabled"] = false,
	["Parent"] = nil,
	["Size"] = UDim2.fromOffset(64, 76),
	["Parent"] = v_u_16.PlayerGui
})
local v166 = v_u_11.new("Frame", {
	["BackgroundColor3"] = nil,
	["BorderSizePixel"] = 0,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["BackgroundColor3"] = v_u_11.YELLOW,
	["AnchorPoint"] = Vector2.new(0.5, 0),
	["Position"] = UDim2.fromScale(0.5, 0),
	["Size"] = UDim2.fromOffset(44, 44),
	["Parent"] = v_u_165
})
v_u_11.corner(v166, 22)
v_u_11.border(v166, Color3.new(1, 1, 1), 0, 2)
local v167 = v_u_12.make("pin", Color3.fromRGB(28, 26, 22), 26)
v167.AnchorPoint = Vector2.new(0.5, 0.5)
v167.Position = UDim2.fromScale(0.5, 0.5)
v167.Parent = v166
local v_u_168 = v_u_11.text({
	["FontFace"] = nil,
	["TextSize"] = 16,
	["TextStrokeTransparency"] = 0.4,
	["Position"] = nil,
	["Size"] = nil,
	["Parent"] = nil,
	["FontFace"] = v_u_11.FONT_BOLD,
	["Position"] = UDim2.fromOffset(0, 48),
	["Size"] = UDim2.new(1, 0, 0, 22),
	["Parent"] = v_u_165
})
local v_u_169 = nil
local function v_u_177(p170) -- name: stations
	-- upvalues: (copy) v_u_16, (copy) v_u_1
	local v171 = {}
	local v172 = v_u_16.Character
	if v172 then
		v172 = v_u_16.Character:FindFirstChild("HumanoidRootPart")
	end
	local v173 = v_u_16:GetAttribute("WorkSite")
	if typeof(v173) ~= "Vector3" then
		v173 = nil
	end
	if v173 then
		v172 = v173
	elseif v172 then
		v172 = v172.Position
	end
	for _, v174 in v_u_1:GetTagged("WorkStation") do
		if v174:GetAttribute("Job") ~= p170 then
			continue
		end
		local v175 = v174:GetAttribute("StationId")
		local v176 = v171[v175]
		if v176 and (not v172 or (v174.Position - v172).Magnitude >= (v176.Position - v172).Magnitude) then
			continue
		end
		v171[v175] = v174
	end
	return v171
end
local function v_u_181(p178) -- name: setBadge
	-- upvalues: (copy) v_u_8, (copy) v_u_11, (copy) v_u_41, (ref) v_u_42, (copy) v_u_12, (copy) v_u_40
	local v179 = v_u_8.job(p178)
	local v180
	if v179 then
		v180 = v179.color
	else
		v180 = v_u_11.YELLOW
	end
	v_u_41.Color = ColorSequence.new(v180:Lerp(Color3.new(1, 1, 1), 0.25), v180:Lerp(Color3.new(0, 0, 0), 0.3))
	if v_u_42 then
		v_u_42:Destroy()
	end
	v_u_42 = v_u_12.make(not v179 and "key" or v179.icon, Color3.new(1, 1, 1), 24)
	v_u_42.AnchorPoint = Vector2.new(0.5, 0.5)
	v_u_42.Position = UDim2.fromScale(0.5, 0.5)
	v_u_42.Parent = v_u_40
end
local v_u_182 = nil
local v_u_183 = nil
local function v_u_243() -- name: refresh
	-- upvalues: (copy) v_u_16, (copy) v_u_2, (ref) v_u_136, (ref) v_u_29, (copy) v_u_14, (copy) v_u_15, (copy) v_u_8, (copy) v_u_177, (copy) v_u_1, (ref) v_u_182, (copy) v_u_181, (copy) v_u_39, (copy) v_u_63, (ref) v_u_138, (copy) v_u_43, (copy) v_u_154, (ref) v_u_162, (copy) v_u_44, (copy) v_u_20, (copy) v_u_161, (ref) v_u_183, (copy) v_u_163, (copy) v_u_165, (copy) v_u_128, (copy) v_u_127, (ref) v_u_169, (copy) v_u_78, (ref) v_u_27, (copy) v_u_23, (copy) v_u_21, (copy) v_u_22
	local v184 = v_u_16:GetAttribute("WorkTask")
	local v185 = v_u_2.JSONDecode
	local v186 = v_u_2
	local v187, v188 = pcall(v185, v186, v184 or "")
	if not v187 or type(v188) ~= "table" then
		v188 = nil
	end
	v_u_136 = v188
	if v_u_29 and (v_u_136 == nil or v_u_136.step ~= "doing") then
		v_u_14.close()
		v_u_15.close()
		return
	else
		local v189 = v_u_16:GetAttribute("Job")
		local v190 = v_u_8.TASKS[v189] ~= nil
		local v191 = (v_u_16:GetAttribute("WorkNextAt") or 0) - workspace:GetServerTimeNow()
		local v192 = v_u_177(v189)
		for _, v193 in v_u_1:GetTagged("WorkStation") do
			local v194 = v193:FindFirstChild("WorkPrompt")
			if not v194 then
				continue
			end
			local v195 = v193:GetAttribute("StationId")
			local v196 = v_u_16:GetAttribute("WorkSite")
			if typeof(v196) ~= "Vector3" then
				v196 = nil
			end
			local v197 = v193:GetAttribute("Job") == v189 and not v_u_29
			if v197 then
				v197 = v196 == nil and true or (v193.Position - v196).Magnitude <= 220
			end
			local v198 = false
			if v197 and v195 == "Board" then
				if v_u_136 == nil then
					v198 = v191 <= 0
				else
					v198 = false
				end
				v194.ActionText = v_u_8.ORDER_JOBS[v189] and "\224\184\163\224\184\177\224\184\154\224\184\173\224\184\173\224\185\128\224\184\148\224\184\173\224\184\163\224\185\140" or "\224\184\163\224\184\177\224\184\154\224\184\135\224\184\178\224\184\153\224\184\170\224\184\184\224\185\136\224\184\161"
			elseif v197 and (v_u_136 and v_u_136.station == v195) then
				v198 = true
				local v199 = v_u_136
				if v199 and v_u_8.ORDER_JOBS[v199.job] then
					v199 = v_u_8.step(v199.job, v199.task, v199.n or 1)
				elseif v199 then
					v199 = v_u_8.task(v199.job, v199.task)
				end
				v194.ActionText = v_u_136.step == "carry" and "\224\185\128\224\184\151\224\184\155\224\184\185\224\184\153\224\184\165\224\184\135\224\185\130\224\184\161\224\185\136" or (not v199 and "\224\184\151\224\184\179\224\184\135\224\184\178\224\184\153" or v199.th)
			end
			v194.ObjectText = v198 and ((v_u_8.job(v189) or {}).th or "") or ""
			v194.Enabled = v198
		end
		local v200 = v_u_16:GetAttribute("PlannedJob")
		local v201
		if v200 then
			if v200 == v189 then
				v201 = false
			else
				v201 = v_u_8.job(v200)
			end
		else
			v201 = v200
		end
		if v201 then
			if v_u_182 ~= "plan:" .. v200 then
				v_u_182 = "plan:" .. v200
				v_u_181(v200)
			end
			v_u_39.Visible = true
			v_u_63.Visible = not v_u_138
			v_u_43.Text = "Go to work: " .. v201.th
			local v202, v203 = v_u_154(v200)
			v_u_162 = v202
			v_u_44.Text = ("Drive to %s and put on the uniform"):format(v203 or (v_u_20 and (v_u_20:GetAttribute(v200 .. "Place") or "the workplace") or "the workplace"))
			local v204 = v_u_161(v200)
			if v204 and (typeof(v202) == "Vector3" and (v204.Position - v202).Magnitude > 30) then
				v204 = nil
			end
			if not v204 then
				local v205 = not v202 and v_u_20
				if v205 then
					v205 = v_u_20:GetAttribute(v200)
				end
				if typeof(v205) == "Vector3" then
					v204 = v_u_163[v200]
					if not v204 then
						v204 = Instance.new("Attachment")
						v204.Name = "Place_" .. v200
						v204.Parent = workspace.Terrain
						v_u_163[v200] = v204
					end
					v204.WorldPosition = v205
				else
					v204 = nil
				end
			end
			v_u_183 = v204
			v_u_165.Adornee = v_u_183
			local v206 = v_u_165
			local v207
			if v_u_183 == nil then
				v207 = false
			else
				v207 = not v_u_29
			end
			v206.Enabled = v207
			if typeof(v202) ~= "Vector3" then
				v202 = nil
			end
			local v208 = v201.color
			if v202 then
				v_u_128.Color = v208
				v_u_128.CFrame = CFrame.new(v202 + Vector3.new(0, 55, 0)) * CFrame.Angles(0, 0, 1.5707963267948966)
				v_u_128.Parent = workspace
			else
				v_u_128.Parent = nil
			end
		else
			v_u_128.Parent = nil
			if v_u_8.ORDER_JOBS[v189] and v_u_16:GetAttribute("JobChosen") == true then
				v_u_39.Visible = false
				v_u_127(v189, v191)
				if v_u_136 then
					local v209 = v192[v_u_136.station]
					if not v209 then
						local v210 = v189 .. "_" .. v_u_136.station
						local v211 = v_u_20
						if v211 then
							v211 = v_u_20:GetAttribute(v210)
						end
						if typeof(v211) == "Vector3" then
							v209 = v_u_163[v210]
							if not v209 then
								v209 = Instance.new("Attachment")
								v209.Name = "Place_" .. v210
								v209.Parent = workspace.Terrain
								v_u_163[v210] = v209
							end
							v209.WorldPosition = v211
						else
							v209 = nil
						end
					end
					v_u_183 = v209
				elseif v191 > 0 then
					v_u_183 = nil
				else
					local v212 = v_u_16:GetAttribute("WorkSite")
					if typeof(v212) ~= "Vector3" then
						v212 = nil
					end
					local v213
					if v212 then
						if not v_u_169 then
							v_u_169 = Instance.new("Attachment")
							v_u_169.Name = "Place_WorkSite"
							v_u_169.Parent = workspace.Terrain
						end
						v_u_169.WorldPosition = v212
						v213 = v_u_169
					else
						v213 = nil
					end
					local v214 = v213 or v192.Board
					if not v214 then
						local v215 = v189 .. "_Board"
						local v216 = v_u_20
						if v216 then
							v216 = v_u_20:GetAttribute(v215)
						end
						if typeof(v216) == "Vector3" then
							v214 = v_u_163[v215]
							if not v214 then
								v214 = Instance.new("Attachment")
								v214.Name = "Place_" .. v215
								v214.Parent = workspace.Terrain
								v_u_163[v215] = v214
							end
							v214.WorldPosition = v216
						else
							v214 = nil
						end
					end
					v_u_183 = v214
				end
				v_u_165.Adornee = v_u_183
				local v217 = v_u_165
				local v218
				if v_u_183 == nil then
					v218 = false
				else
					v218 = not v_u_29
				end
				v217.Enabled = v218
				return
			else
				v_u_78.Visible = false
				local v219 = v_u_16:GetAttribute("JobChosen") == true
				local v220 = v_u_39
				if v219 then
					v219 = v190 or (v189 == "Courier" and true or v189 == "Delivery")
				end
				v220.Visible = v219
				local v221 = v_u_63
				local v222
				if v_u_136 == nil then
					v222 = false
				else
					v222 = not v_u_138
				end
				v221.Visible = v222
				if v_u_182 ~= v189 then
					v_u_182 = v189
					v_u_27 = false
					v_u_181(v189)
				end
				if v190 then
					if v_u_136 then
						local v223 = v_u_8.task(v_u_136.job, v_u_136.task)
						local v224 = v_u_43
						local v225 = "Job: "
						local v226
						if v223 then
							v226 = v223.th
						else
							v226 = v_u_136.task
						end
						v224.Text = v225 .. v226
						local v227 = v_u_44
						local v228
						if v_u_136.step == "carry" then
							v228 = "Carry the cement bag to the Cement Mixer"
						elseif v_u_136.step == "doing" then
							v228 = "Carry on at the " .. (v_u_21[v_u_136.station] or v_u_136.station)
						else
							v228 = "Go to the " .. (v_u_21[v_u_136.station] or v_u_136.station) .. " and press Work"
						end
						v227.Text = v228
						local v229 = v192[v_u_136.station]
						if not v229 then
							local v230 = v189 .. "_" .. v_u_136.station
							local v231 = v_u_20
							if v231 then
								v231 = v_u_20:GetAttribute(v230)
							end
							if typeof(v231) == "Vector3" then
								v229 = v_u_163[v230]
								if not v229 then
									v229 = Instance.new("Attachment")
									v229.Name = "Place_" .. v230
									v229.Parent = workspace.Terrain
									v_u_163[v230] = v229
								end
								v229.WorldPosition = v231
							else
								v229 = nil
							end
						end
						v_u_183 = v229
					else
						local v232 = v_u_16:GetAttribute("WorkCount") or 0
						v_u_43.Text = ((v_u_8.job(v189) or {}).th or "") .. ("  \194\183  %d done"):format(v232)
						if v191 > 0 then
							v_u_44.Text = ("Short break: next job in %d s"):format((math.ceil(v191)))
							v_u_183 = nil
						else
							v_u_44.Text = "Go to the job board at " .. (v_u_16:GetAttribute("WorkSiteName") or v_u_22[v189] or "") .. " for a random job"
							local v233 = v_u_16:GetAttribute("WorkSite")
							if typeof(v233) ~= "Vector3" then
								v233 = nil
							end
							local v234
							if v233 then
								if not v_u_169 then
									v_u_169 = Instance.new("Attachment")
									v_u_169.Name = "Place_WorkSite"
									v_u_169.Parent = workspace.Terrain
								end
								v_u_169.WorldPosition = v233
								v234 = v_u_169
							else
								v234 = nil
							end
							local v235 = v234 or v192.Board
							if not v235 then
								local v236 = v189 .. "_Board"
								local v237 = v_u_20
								if v237 then
									v237 = v_u_20:GetAttribute(v236)
								end
								if typeof(v237) == "Vector3" then
									v235 = v_u_163[v236]
									if not v235 then
										v235 = Instance.new("Attachment")
										v235.Name = "Place_" .. v236
										v235.Parent = workspace.Terrain
										v_u_163[v236] = v235
									end
									v235.WorldPosition = v237
								else
									v235 = nil
								end
							end
							v_u_183 = v235
						end
					end
					v_u_165.Adornee = v_u_183
					local v238 = v_u_165
					local v239
					if v_u_183 == nil then
						v239 = false
					else
						v239 = not v_u_29
					end
					v238.Enabled = v239
				else
					v_u_183 = nil
					if v189 == "Courier" then
						v_u_43.Text = "Courier"
						v_u_44.Text = v_u_27 and "Open your phone (F) and take parcel orders" or "Drive to the Delivery Office on Fai Chai Side Rd."
						local v240
						if v_u_27 then
							v240 = nil
						else
							v240 = v_u_23
						end
						v_u_183 = v240
					elseif v189 == "Delivery" then
						v_u_43.Text = "Food Delivery"
						v_u_44.Text = "Get a bike (G), open your phone (F) and take orders"
					end
					v_u_165.Adornee = v_u_183
					local v241 = v_u_165
					local v242 = v_u_39.Visible
					if v242 then
						v242 = v_u_183 ~= nil
					end
					v241.Enabled = v242
				end
			end
		end
	end
end
local function v_u_269() -- name: play
	-- upvalues: (ref) v_u_136, (copy) v_u_8, (ref) v_u_29, (copy) v_u_243, (copy) v_u_9, (copy) v_u_18, (copy) v_u_13, (copy) v_u_177, (copy) v_u_15, (copy) v_u_14
	local v244 = v_u_136
	if v244 and v_u_8.ORDER_JOBS[v244.job] then
		v244 = v_u_8.step(v244.job, v244.task, v244.n or 1)
	elseif v244 then
		v244 = v_u_8.task(v244.job, v244.task)
	end
	if v244 then
		v_u_29 = true
		v_u_243()
		local function v256(p245) -- name: finished
			-- upvalues: (ref) v_u_29, (ref) v_u_9, (ref) v_u_18, (ref) v_u_13, (ref) v_u_243
			v_u_29 = false
			if p245 then
				local v246 = v_u_9.invoke
				local v247 = v_u_18
				local v248, v249, v250 = pcall(v246, v247, "Done", p245)
				if v248 and v250 then
					v_u_13.show(v250, v249 and "ok" or "error")
				end
			else
				local v251 = v_u_9.invoke
				local v252 = v_u_18
				local v253, v254, v255 = pcall(v251, v252, "Rest", nil)
				if v253 and v255 then
					v_u_13.show(v255, v254 and "ok" or "error")
				end
			end
			v_u_243()
		end
		if v_u_8.ORDER_JOBS[v_u_136.job] then
			local v257 = v_u_177(v_u_136.job)[v_u_136.station]
			v_u_15.play(v244, v257, v256)
		else
			v_u_14.play(v244.game, v244.th, function(p258)
				-- upvalues: (ref) v_u_29, (ref) v_u_9, (ref) v_u_18, (ref) v_u_13, (ref) v_u_243
				v_u_29 = false
				if p258 then
					local v259 = v_u_9.invoke
					local v260 = v_u_18
					local v261, v262, v263 = pcall(v259, v260, "Done", p258)
					if v261 and v263 then
						v_u_13.show(v263, v262 and "ok" or "error")
					end
				else
					local v264 = v_u_9.invoke
					local v265 = v_u_18
					local v266, v267, v268 = pcall(v264, v265, "Rest", nil)
					if v266 and v268 then
						v_u_13.show(v268, v267 and "ok" or "error")
					end
				end
				v_u_243()
			end, v244.opts or {
				["paint"] = v244.id == "paint"
			})
		end
	else
		return
	end
end
local function v_u_297(p270) -- name: triggered
	-- upvalues: (ref) v_u_29, (ref) v_u_136, (copy) v_u_9, (copy) v_u_18, (copy) v_u_13, (copy) v_u_269, (copy) v_u_16, (copy) v_u_2
	if v_u_29 then
		return
	else
		local v271 = p270:GetAttribute("StationId")
		if v271 == "Board" and not v_u_136 then
			local v272 = v_u_9.invoke
			local v273 = v_u_18
			local v274, v275, v276 = pcall(v272, v273, "Take", nil)
			if v274 and v276 then
				v_u_13.show(v276, v275 and "ok" or "error")
			end
			return
		elseif v_u_136 and v_u_136.station == v271 then
			if v_u_136.step == "carry" then
				local v277 = v_u_9.invoke
				local v278 = v_u_18
				local v279, v280, v281 = pcall(v277, v278, "Done", 1)
				if v279 and v281 then
					v_u_13.show(v281, v280 and "ok" or "error")
				end
			elseif v_u_136.step == "doing" then
				local v282 = v_u_9.invoke
				local v283 = v_u_18
				local v284, v285, v286 = pcall(v282, v283, "Resume", nil)
				if v284 and v286 then
					v_u_13.show(v286, v285 and "ok" or "error")
				end
				if v284 and v285 then
					v_u_269()
					return
				end
			else
				local v287 = v_u_9.invoke
				local v288 = v_u_18
				local v289, v290, v291 = pcall(v287, v288, "Do", v271)
				if v289 and v291 then
					v_u_13.show(v291, v290 and "ok" or "error")
				end
				if v289 and v290 then
					local v292 = v_u_16:GetAttribute("WorkTask")
					local v293 = v_u_2.JSONDecode
					local v294 = v_u_2
					local v295, v296 = pcall(v293, v294, v292 or "")
					if not v295 or type(v296) ~= "table" then
						v296 = nil
					end
					v_u_136 = v296
					if v_u_136 and v_u_136.step == "doing" then
						v_u_269()
					end
				end
			end
		else
			return
		end
	end
end
local v_u_298 = v_u_183
local function v301(p_u_299) -- name: hook
	-- upvalues: (copy) v_u_297, (copy) v_u_243
	local v300 = p_u_299:WaitForChild("WorkPrompt", 10)
	if v300 then
		v300.Triggered:Connect(function()
			-- upvalues: (ref) v_u_297, (copy) p_u_299
			v_u_297(p_u_299)
		end)
	end
	v_u_243()
end
local function v_u_318(p302) -- name: farHint
	-- upvalues: (copy) v_u_16, (copy) v_u_20, (copy) v_u_44, (copy) v_u_8, (ref) v_u_136, (copy) v_u_22, (ref) v_u_137, (copy) v_u_78, (copy) v_u_127, (ref) v_u_29, (ref) v_u_27, (copy) v_u_243
	local v303 = v_u_16:GetAttribute("Job")
	local v304 = v_u_16:GetAttribute("PlannedJob")
	if v304 and v304 ~= v303 then
		local v305 = v_u_20 and v_u_20:GetAttribute(v304 .. "Place") or "the workplace"
		local v306 = v_u_44
		local v307
		if p302 <= 18 then
			v307 = "You\'re here: put on the uniform at the locker"
		else
			local v308 = p302 * 0.28 + 0.5
			v307 = ("Drive to %s  \194\183  %d m"):format(v305, (math.floor(v308)))
		end
		v306.Text = v307
		return
	elseif v_u_8.ORDER_JOBS[v303] then
		local v309
		if v_u_136 or p302 <= 150 then
			v309 = nil
		else
			local v310 = v_u_16:GetAttribute("WorkSiteName") or v_u_22[v303]
			local v311 = p302 * 0.28 + 0.5
			v309 = ("\224\184\130\224\184\177\224\184\154\224\185\132\224\184\155\224\184\151\224\184\181\224\185\136 %s  \194\183  %d m"):format(v310 or "MHNK ICECREAM", (math.floor(v311)))
		end
		if v309 ~= v_u_137 then
			v_u_137 = v309
			if v_u_78.Visible and not v_u_136 then
				v_u_127(v303, (v_u_16:GetAttribute("WorkNextAt") or 0) - workspace:GetServerTimeNow())
			end
		end
		return
	elseif v_u_136 or (v_u_29 or not v_u_22[v303]) then
		return
	elseif v303 == "Courier" then
		if v_u_27 or p302 > 45 then
			if not v_u_27 then
				local v312 = v_u_44
				local v313 = p302 * 0.28 + 0.5
				v312.Text = ("Drive to the Delivery Office on Fai Chai Side Rd.  \194\183  %d m"):format((math.floor(v313)))
			end
		else
			v_u_27 = true
			v_u_243()
		end
	elseif (v_u_16:GetAttribute("WorkNextAt") or 0) <= workspace:GetServerTimeNow() then
		local v314 = v_u_44
		local v315
		if p302 > 150 then
			local v316 = v_u_16:GetAttribute("WorkSiteName") or v_u_22[v303]
			local v317 = p302 * 0.28 + 0.5
			v315 = ("Drive to %s  \194\183  %d m"):format(v316, (math.floor(v317)))
		else
			v315 = "Go to the job board at " .. (v_u_16:GetAttribute("WorkSiteName") or v_u_22[v303]) .. " for a random job"
		end
		v314.Text = v315
	end
end
for _, v319 in v_u_1:GetTagged("WorkStation") do
	task.spawn(v301, v319)
end
v_u_1:GetInstanceAddedSignal("WorkStation"):Connect(v301)
task.spawn(function()
	-- upvalues: (ref) v_u_29, (copy) v_u_16, (copy) v_u_243
	while true do
		repeat
			task.wait(1)
		until not v_u_29 and v_u_16:GetAttribute("WorkNextAt")
		v_u_243()
	end
end)
for _, v320 in {
	"WorkTask",
	"Job",
	"WorkCount",
	"WorkNextAt",
	"JobChosen",
	"PlannedJob",
	"WorkSite"
} do
	v_u_16:GetAttributeChangedSignal(v320):Connect(v_u_243)
end
task.spawn(function()
	-- upvalues: (copy) v_u_16, (ref) v_u_29, (copy) v_u_154, (ref) v_u_162, (ref) v_u_298, (copy) v_u_243
	while true do
		repeat
			task.wait(2)
			local v321 = v_u_16:GetAttribute("PlannedJob")
		until v321 and (v321 ~= v_u_16:GetAttribute("Job") and not v_u_29)
		local v322 = v_u_154(v321)
		local v323
		if typeof(v322) == "Vector3" then
			local v324 = v_u_162
			v323 = typeof(v324) ~= "Vector3" and true or (v322 - v_u_162).Magnitude > 30
		else
			v323 = false
		end
		if not v323 and (v_u_298 == nil or v_u_298:IsDescendantOf(workspace)) then
			continue
		end
		v_u_243()
	end
end)
v5.Heartbeat:Connect(function()
	-- upvalues: (copy) v_u_165, (ref) v_u_298, (copy) v_u_16, (copy) v_u_168, (copy) v_u_318
	if v_u_165.Enabled and v_u_298 then
		local v325 = v_u_16.Character
		if v325 then
			v325 = v_u_16.Character:FindFirstChild("HumanoidRootPart")
		end
		if v325 then
			local v326
			if v_u_298:IsA("Attachment") then
				v326 = v_u_298.WorldPosition
			else
				v326 = v_u_298.Position
			end
			local v327 = (v325.Position - v326).Magnitude
			local v328 = v_u_168
			local v329 = v327 * 0.28 + 0.5
			v328.Text = ("%d m"):format((math.floor(v329)))
			v_u_318(v327)
		end
	end
end)
v_u_243()