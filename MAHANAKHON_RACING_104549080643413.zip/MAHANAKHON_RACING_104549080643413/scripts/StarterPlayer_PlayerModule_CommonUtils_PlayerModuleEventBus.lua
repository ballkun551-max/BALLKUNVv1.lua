-- Path: StarterPlayer/PlayerModule/CommonUtils/PlayerModuleEventBus
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v1 = require(script.Parent:WaitForChild("EventBus")).new()
v1.data = {}
return v1