-- Path: Players/ygggggg55551/PlayerScripts/WorkPoser
-- Class: LocalScript  true/Enum.RunContext.Legacy
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = game:GetService("Players")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = require(v2:WaitForChild("GameUI"):WaitForChild("Poses"))
local v_u_4 = {}
game:GetService("RunService").Stepped:Connect(function()
	-- upvalues: (copy) v_u_1, (copy) v_u_3, (copy) v_u_4
	local v5 = os.clock()
	for _, v6 in v_u_1:GetPlayers() do
		local v7 = v6.Character
		local v8 = v6:GetAttribute("WorkPose")
		if v7 and v8 then
			if not v_u_3.apply(v7, v8, v5) then
				continue
			end
			v_u_4[v7] = true
		else
			if not (v7 and v_u_4[v7]) then
				continue
			end
			v_u_4[v7] = nil
			v_u_3.clear(v7)
		end
	end
end)