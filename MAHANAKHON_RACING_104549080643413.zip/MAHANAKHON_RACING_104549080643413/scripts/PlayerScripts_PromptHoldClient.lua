-- Path: Players/ygggggg55551/PlayerScripts/PromptHoldClient
-- Class: LocalScript  true/Enum.RunContext.Legacy
-- Decompiled by BALL KUN Universal Map Dump

require(game:GetService("ReplicatedStorage"):WaitForChild("PromptHold")).watch()