-- Path: ReplicatedStorage/GameUI/EmotePanel
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = require(game:GetService("ReplicatedStorage"):WaitForChild("NetSeal"))
local v_u_2 = game:GetService("CollectionService")
local v3 = game:GetService("Players")
local v_u_4 = game:GetService("ReplicatedStorage")
local v_u_5 = game:GetService("RunService")
local v_u_6 = game:GetService("TweenService")
local v_u_7 = require(script.Parent:WaitForChild("Theme"))
local v_u_8 = require(script.Parent:WaitForChild("Toast"))
local v_u_9 = require(v_u_4:WaitForChild("RankShared"))
local v10 = {}
local v_u_11 = v3.LocalPlayer
local v_u_12 = v_u_7.isTouch()
local v_u_13 = {
	["Dances"] = {
		{ "Dance 1", 507771019 },
		{ "Dance 2", 507776043 },
		{ "Dance 3", 507777268 },
		{ "Old Town Road", 5937560570 },
		{ "Line Dance", 4049037604 },
		{ "Country Line", 5915712534 },
		{ "Hype", 3695333486 },
		{ "Swish", 3361481910 },
		{ "Monkey", 3333499508 },
		{ "Shuffle", 4349242221 },
		{ "Cabbage Patch", 3303391864 },
		{ "Top Rock", 3361276673 },
		{ "Robot", 3338025566 },
		{ "Twirl", 3334968680 },
		{ "Floss", 5917459365 },
		{ "Break Dance", 5915648917 },
		{ "Hips Poppin\'", 6797888062 },
		{ "Cha-Cha", 3695322025 },
		{ "Dorky", 4212455378 },
		{ "Cutesy", 4265725525 },
		{ "River Dance", 3333432454 },
		{ "Rocker", 5915714366 },
		{ "Dolphin", 5918726674 },
		{ "Boy Band", 4101966434 },
		{ "Air Guitar", 3695300085 },
		{ "Jacks", 3338066331 },
		{ "Zombie", 4210116953 }
	},
	["Emotes"] = {
		{ "Wave", 507770239 },
		{ "Hello", 3344650532 },
		{ "Jump Wave", 4940564896 },
		{ "Point", 507770453 },
		{ "Cheer", 507770677 },
		{ "Laugh", 507770818 },
		{ "Clap", 5911729486 },
		{ "Celebrate", 3338097973 },
		{ "Greatest", 3338042785 },
		{ "Louder", 3338083565 },
		{ "Stadium", 3338055167 },
		{ "Gun Show", 3333387824 },
		{ "Shrug", 3334392772 },
		{ "Tilt", 3334538554 },
		{ "Agree", 4841397952 },
		{ "Disagree", 4841401869 },
		{ "Happy", 4841405708 },
		{ "Sad", 4841407203 },
		{ "Confused", 4940561610 },
		{ "Bored", 5230599789 },
		{ "Come here", 5230598276 },
		{ "Cower", 4940563117 },
		{ "Tantrum", 5104341999 },
		{ "Curtsy", 4555816777 },
		{ "Shy", 3337978742 },
		{ "Sneaky", 3334424322 },
		{ "Keeping Time", 4555808220 }
	},
	["Poses"] = {
		{ "Chill on a bike", "lounge" },
		{ "Sleep (lie down)", 4686925579, 0.45 },
		{ "Godlike", 3337994105, 0.6 },
		{ "Superhero", 3695373233, 0.92 },
		{ "Hero Landing", 5104344710, 0.55 },
		{ "Heisman", 3695263073, 0.5 },
		{ "Model Walk", 3333331310, 0.35 },
		{ "Gun Show Pose", 3333387824, 0.5 },
		{ "Shrug Pose", 3334392772, 0.4 },
		{ "Point Pose", 507770453, 0.5 },
		{ "Tilt Pose", 3334538554, 0.5 },
		{ "Sneaky Pose", 3334424322, 0.3 },
		{ "T Pose", 3338010159, 0.5 },
		{ "Cheer Pose", 507770677, 0.45 },
		{ "Shy Pose", 3337978742, 0.5 },
		{ "Air Guitar Pose", 3695300085, 0.3 }
	}
}
local v_u_14 = { "Dances", "Emotes", "Poses" }
function v10.build(p15) -- name: build
	-- upvalues: (copy) v_u_12, (copy) v_u_7, (copy) v_u_14, (copy) v_u_4, (copy) v_u_1, (copy) v_u_11, (copy) v_u_2, (copy) v_u_5, (copy) v_u_8, (copy) v_u_13, (copy) v_u_9, (copy) v_u_6
	local v16 = v_u_12 and 330 or 380
	local v17 = v_u_12 and 300 or 380
	local v_u_18 = v_u_7.panel({
		["Name"] = "Emotes",
		["Visible"] = false,
		["AnchorPoint"] = nil,
		["Position"] = nil,
		["Size"] = nil,
		["Parent"] = nil,
		["AnchorPoint"] = Vector2.new(0, 0),
		["Position"] = UDim2.new(0, 8, 1, 8),
		["Size"] = UDim2.fromOffset(v16, v17),
		["Parent"] = p15
	})
	v_u_7.padding(v_u_18, 10)
	local v_u_19 = v_u_7.new("UIScale", {
		["Parent"] = v_u_18
	})
	local v_u_20 = {}
	for _, v21 in v_u_14 do
		local v22 = v_u_7.new("ScrollingFrame", {
			["Name"] = nil,
			["BackgroundTransparency"] = 1,
			["BorderSizePixel"] = 0,
			["Position"] = nil,
			["Size"] = nil,
			["CanvasSize"] = nil,
			["AutomaticCanvasSize"] = nil,
			["ScrollBarThickness"] = 4,
			["ScrollingDirection"] = nil,
			["Visible"] = false,
			["Parent"] = nil,
			["Name"] = v21,
			["Position"] = UDim2.fromOffset(0, 46),
			["Size"] = UDim2.new(1, 0, 1, -90),
			["CanvasSize"] = UDim2.new(),
			["AutomaticCanvasSize"] = Enum.AutomaticSize.Y,
			["ScrollingDirection"] = Enum.ScrollingDirection.Y,
			["Parent"] = v_u_18
		})
		v_u_7.new("UIPadding", {
			["PaddingRight"] = UDim.new(0, 6),
			["Parent"] = v22
		})
		v_u_7.new("UIGridLayout", {
			["CellSize"] = UDim2.new(0.5, -4, 0, 38),
			["CellPadding"] = UDim2.fromOffset(6, 6),
			["SortOrder"] = Enum.SortOrder.LayoutOrder,
			["Parent"] = v22
		})
		v_u_20[v21] = v22
	end
	local v_u_23 = v_u_7.new("ScrollingFrame", {
		["Name"] = "Ranks",
		["BackgroundTransparency"] = 1,
		["BorderSizePixel"] = 0,
		["Position"] = nil,
		["Size"] = nil,
		["CanvasSize"] = nil,
		["AutomaticCanvasSize"] = nil,
		["ScrollBarThickness"] = 4,
		["ScrollingDirection"] = nil,
		["Visible"] = false,
		["Parent"] = nil,
		["Position"] = UDim2.fromOffset(0, 46),
		["Size"] = UDim2.new(1, 0, 1, -46),
		["CanvasSize"] = UDim2.new(),
		["AutomaticCanvasSize"] = Enum.AutomaticSize.Y,
		["ScrollingDirection"] = Enum.ScrollingDirection.Y,
		["Parent"] = v_u_18
	})
	v_u_7.new("UIPadding", {
		["PaddingRight"] = UDim.new(0, 6),
		["Parent"] = v_u_23
	})
	v_u_7.new("UIListLayout", {
		["Padding"] = UDim.new(0, 6),
		["SortOrder"] = Enum.SortOrder.LayoutOrder,
		["Parent"] = v_u_23
	})
	v_u_20.Ranks = v_u_23
	local v_u_24 = nil
	local v_u_25 = nil
	local _, v29 = v_u_7.tabs(v_u_18, {
		{
			["id"] = "Dances",
			["label"] = "Dance",
			["icon"] = "sound",
			["grad"] = "pink"
		},
		{
			["id"] = "Emotes",
			["label"] = "Emote",
			["icon"] = "person",
			["grad"] = "pink"
		},
		{
			["id"] = "Poses",
			["label"] = "Pose",
			["icon"] = "camera",
			["grad"] = "pink"
		},
		{
			["id"] = "Ranks",
			["label"] = "Rank",
			["icon"] = "crown",
			["grad"] = "pink"
		}
	}, function(p26)
		-- upvalues: (copy) v_u_20, (ref) v_u_24, (ref) v_u_25
		for v27, v28 in v_u_20 do
			v28.Visible = v27 == p26
		end
		if v_u_24 then
			v_u_24.Visible = p26 ~= "Ranks"
		end
		if p26 == "Ranks" and v_u_25 then
			v_u_25()
		end
	end, 38)
	v29("Dances")
	v_u_20.Dances.Visible = true
	local v_u_30 = nil
	local function v_u_37() -- name: nearestBike
		-- upvalues: (ref) v_u_11, (ref) v_u_2
		local v31 = v_u_11.Character
		if v31 then
			v31 = v31:FindFirstChild("HumanoidRootPart")
		end
		local v32 = 12
		local v33 = nil
		for _, v34 in v_u_2:GetTagged("PCX160") do
			local v35 = v34:FindFirstChild("Chassis")
			if not (v31 and (v35 and v34:IsDescendantOf(workspace))) then
				continue
			end
			local v36 = (v35.Position - v31.Position).Magnitude
			if v36 >= v32 then
				continue
			end
			v33 = v34
			v32 = v36
		end
		return v33
	end
	v_u_5.Heartbeat:Connect(function()
		-- upvalues: (ref) v_u_11
		local v38 = v_u_11.Character
		local v39
		if v_u_11.Character == nil then
			v39 = false
		else
			v39 = v_u_11.Character:GetAttribute("Lounging") == true
		end
		if v39 then
			local v40 = v38:FindFirstChildOfClass("Humanoid")
			if v40 then
				v40 = v40:FindFirstChildOfClass("Animator")
			end
			if v40 then
				for _, v41 in v40:GetPlayingAnimationTracks() do
					v41:Stop(0)
				end
			end
		end
	end)
	game:GetService("UserInputService").JumpRequest:Connect(function()
		-- upvalues: (ref) v_u_11, (ref) v_u_30, (ref) v_u_4, (ref) v_u_1
		local v42
		if v_u_11.Character == nil then
			v42 = false
		else
			v42 = v_u_11.Character:GetAttribute("Lounging") == true
		end
		v_u_30 = v42 and (v_u_30 or v_u_4:WaitForChild("GameRemotes"):WaitForChild("BikeLounge", 5))
		if v_u_30 then
			v_u_1.fire(v_u_30, "Stop", nil)
		end
	end)
	local v_u_43 = nil
	local v_u_44 = nil
	local v_u_45 = nil
	local function v47() -- name: stop
		-- upvalues: (ref) v_u_11, (ref) v_u_30, (ref) v_u_4, (ref) v_u_1, (ref) v_u_45, (ref) v_u_43, (ref) v_u_44
		local v46
		if v_u_11.Character == nil then
			v46 = false
		else
			v46 = v_u_11.Character:GetAttribute("Lounging") == true
		end
		v_u_30 = v46 and (v_u_30 or v_u_4:WaitForChild("GameRemotes"):WaitForChild("BikeLounge", 5))
		if v_u_30 then
			v_u_1.fire(v_u_30, "Stop", nil)
		end
		if v_u_45 then
			v_u_45:Disconnect()
			v_u_45 = nil
		end
		if v_u_43 then
			v_u_43:Stop(0.25)
			v_u_43 = nil
		end
		v_u_44 = nil
	end
	local function v_u_60(p48) -- name: play
		-- upvalues: (ref) v_u_11, (ref) v_u_30, (ref) v_u_4, (ref) v_u_1, (ref) v_u_45, (ref) v_u_43, (ref) v_u_44, (copy) v_u_37, (ref) v_u_8, (ref) v_u_5
		local v49
		if v_u_11.Character == nil then
			v49 = false
		else
			v49 = v_u_11.Character:GetAttribute("Lounging") == true
		end
		v_u_30 = v49 and (v_u_30 or v_u_4:WaitForChild("GameRemotes"):WaitForChild("BikeLounge", 5))
		if v_u_30 then
			v_u_1.fire(v_u_30, "Stop", nil)
		end
		if v_u_45 then
			v_u_45:Disconnect()
			v_u_45 = nil
		end
		if v_u_43 then
			v_u_43:Stop(0.25)
			v_u_43 = nil
		end
		v_u_44 = nil
		local v_u_50 = v_u_11.Character
		local v_u_51
		if v_u_50 then
			v_u_51 = v_u_50:FindFirstChildOfClass("Humanoid")
		else
			v_u_51 = v_u_50
		end
		if v_u_51 and v_u_51.Health > 0 then
			if p48[2] == "lounge" then
				local v52 = v_u_37()
				if v_u_51.SeatPart then
					v_u_8.show("Get off the bike first, then stand next to it", "info")
					return
				elseif v52 then
					v_u_30 = v_u_30 or v_u_4:WaitForChild("GameRemotes"):WaitForChild("BikeLounge", 5)
					if v_u_30 then
						v_u_1.fire(v_u_30, "Start", v52)
					end
				else
					v_u_8.show("Stand next to a parked bike", "info")
				end
			elseif v_u_51.SeatPart then
				v_u_8.show("Get off the vehicle first", "info")
				return
			elseif v_u_51.RigType == Enum.HumanoidRigType.R15 then
				local v53 = v_u_51:FindFirstChildOfClass("Animator") or Instance.new("Animator", v_u_51)
				local v54 = Instance.new("Animation")
				v54.AnimationId = "rbxassetid://" .. p48[2]
				local v55 = v53.LoadAnimation
				local v56, v57 = pcall(v55, v53, v54)
				if v56 and v57 then
					v_u_43 = v57
					v_u_43.Priority = Enum.AnimationPriority.Action
					v_u_43.Looped = p48[3] == nil
					v_u_43:Play(0.2)
					v_u_44 = p48[3]
					local v_u_58 = v_u_50:GetPivot().Position
					v_u_45 = v_u_5.Heartbeat:Connect(function()
						-- upvalues: (ref) v_u_43, (ref) v_u_44, (copy) v_u_51, (copy) v_u_50, (copy) v_u_58, (ref) v_u_11, (ref) v_u_30, (ref) v_u_4, (ref) v_u_1, (ref) v_u_45
						if v_u_43 then
							if v_u_44 and (v_u_43.Length > 0 and (v_u_43.Speed ~= 0 and v_u_43.TimePosition >= v_u_43.Length * v_u_44)) then
								v_u_43:AdjustSpeed(0)
							end
							if not v_u_44 and (v_u_43.Length > 0 and not v_u_43.Looped) then
								v_u_43.Looped = true
							end
							if v_u_51.MoveDirection.Magnitude > 0.1 or v_u_51.Jump or (v_u_50:GetPivot().Position - v_u_58).Magnitude > 3 or (v_u_51.SeatPart or (v_u_51.Health <= 0 or not v_u_50.Parent)) then
								local v59
								if v_u_11.Character == nil then
									v59 = false
								else
									v59 = v_u_11.Character:GetAttribute("Lounging") == true
								end
								v_u_30 = v59 and (v_u_30 or v_u_4:WaitForChild("GameRemotes"):WaitForChild("BikeLounge", 5))
								if v_u_30 then
									v_u_1.fire(v_u_30, "Stop", nil)
								end
								if v_u_45 then
									v_u_45:Disconnect()
									v_u_45 = nil
								end
								if v_u_43 then
									v_u_43:Stop(0.25)
									v_u_43 = nil
								end
								v_u_44 = nil
							end
						end
					end)
				else
					v_u_8.show("That one didn\'t load", "error")
				end
			else
				v_u_8.show("Emotes need an R15 body", "error")
				return
			end
		else
			return
		end
	end
	for v61, v62 in v_u_13 do
		for v63, v_u_64 in v62 do
			local v65 = v_u_7.button({
				["text"] = nil,
				["grad"] = "dark",
				["textSize"] = 14,
				["parent"] = nil,
				["text"] = v_u_64[1],
				["parent"] = v_u_20[v61]
			})
			v65.LayoutOrder = v63
			v65.Activated:Connect(function()
				-- upvalues: (copy) v_u_60, (copy) v_u_64
				v_u_60(v_u_64)
			end)
		end
	end
	v_u_24 = v_u_7.button({
		["text"] = "Stop",
		["grad"] = "red",
		["icon"] = "close",
		["textSize"] = 15,
		["anchor"] = nil,
		["position"] = nil,
		["size"] = nil,
		["parent"] = nil,
		["anchor"] = Vector2.new(0, 1),
		["position"] = UDim2.fromScale(0, 1),
		["size"] = UDim2.new(1, 0, 0, 38),
		["parent"] = v_u_18
	})
	v_u_24.Activated:Connect(v47)
	v_u_11.CharacterAdded:Connect(v47)
	local v_u_66 = false
	local function v_u_73(p67) -- name: choose
		-- upvalues: (ref) v_u_66, (ref) v_u_4, (ref) v_u_1, (ref) v_u_8
		if not v_u_66 then
			v_u_66 = true
			local v68 = v_u_4:FindFirstChild("GameRemotes")
			if v68 then
				v68 = v68:FindFirstChild("TagChoice")
			end
			local v69, v70, v71
			if v68 then
				local v72 = v_u_1.invoke
				v69, v70, v71 = pcall(v72, v68, p67)
			else
				v69 = false
				v71 = nil
				v70 = false
			end
			v_u_66 = false
			v_u_8.show(tostring(v69 and v71 and v71 or "Couldn\'t change it, try again"), v69 and v70 and "ok" or "error")
		end
	end
	v_u_25 = function() -- name: buildRanks
		-- upvalues: (copy) v_u_23, (ref) v_u_7, (ref) v_u_9, (ref) v_u_11, (copy) v_u_73
		for _, v74 in v_u_23:GetChildren() do
			if not v74:IsA("GuiObject") then
				continue
			end
			v74:Destroy()
		end
		v_u_7.text({
			["Text"] = "The rank over your head",
			["TextSize"] = 14,
			["FontFace"] = nil,
			["TextColor3"] = nil,
			["TextXAlignment"] = nil,
			["Size"] = nil,
			["LayoutOrder"] = 0,
			["Parent"] = nil,
			["FontFace"] = v_u_7.FONT_BOLD,
			["TextColor3"] = v_u_7.TEXT_DIM,
			["TextXAlignment"] = Enum.TextXAlignment.Left,
			["Size"] = UDim2.new(1, 0, 0, 20),
			["Parent"] = v_u_23
		})
		local v75 = v_u_9.owned(v_u_11)
		local v76 = v_u_9.shown(v_u_11)
		for v77, v_u_78 in v75 do
			local v_u_79 = v_u_78 == v76
			local v80 = v_u_7.button({
				["text"] = nil,
				["grad"] = nil,
				["textSize"] = 15,
				["size"] = nil,
				["parent"] = nil,
				["text"] = v_u_9.label(v_u_78) .. (v_u_79 and "  \226\156\147" or ""),
				["grad"] = v_u_79 and "gold" or "dark",
				["size"] = UDim2.new(1, 0, 0, 40),
				["parent"] = v_u_23
			})
			v80.LayoutOrder = v77
			if not v_u_79 then
				v_u_7.setButton(v80, nil, nil, v_u_9.info(v_u_78).color)
			end
			v80.Activated:Connect(function()
				-- upvalues: (copy) v_u_79, (ref) v_u_73, (copy) v_u_78
				if not v_u_79 then
					v_u_73(v_u_78)
				end
			end)
		end
		if #v75 <= 1 then
			v_u_7.text({
				["Text"] = "Ranks you get (VIP, staff, a creator title) show up here to pick from.",
				["TextSize"] = 13,
				["TextColor3"] = nil,
				["TextWrapped"] = true,
				["Size"] = nil,
				["LayoutOrder"] = 100,
				["Parent"] = nil,
				["TextColor3"] = v_u_7.TEXT_DIM,
				["Size"] = UDim2.new(1, 0, 0, 36),
				["Parent"] = v_u_23
			})
		end
	end
	local v_u_81 = v_u_25
	for _, v82 in {
		"Rank",
		"TagRank",
		"TagGrant",
		"Pass_VIP"
	} do
		v_u_11:GetAttributeChangedSignal(v82):Connect(function()
			-- upvalues: (copy) v_u_23, (ref) v_u_81
			if v_u_23.Visible then
				v_u_81()
			end
		end)
	end
	local v_u_84 = {
		["setOpen"] = function(p83) -- name: setOpen
			-- upvalues: (copy) v_u_18, (copy) v_u_19, (ref) v_u_6, (ref) v_u_7
			v_u_18.Visible = p83
			if p83 then
				v_u_19.Scale = 0.9
				v_u_6:Create(v_u_19, v_u_7.POP, {
					["Scale"] = 1
				}):Play()
			end
		end,
		["isOpen"] = function() -- name: isOpen
			-- upvalues: (copy) v_u_18
			return v_u_18.Visible
		end,
		["toggle"] = function() -- name: toggle
			-- upvalues: (copy) v_u_84, (copy) v_u_18
			v_u_84.setOpen(not v_u_18.Visible)
		end
	}
	return v_u_84
end
return v10