-- Path: StarterPlayer/PlayerModule/EngineInterface
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = game:GetService("Players")
require(script.Parent:WaitForChild("CommonUtils"))
require(script.Parent.Types)
return {
	["update"] = function(p2) -- name: update
		-- upvalues: (copy) v_u_1
		local v3 = p2.engineInterface
		local v4 = v_u_1.LocalPlayer
		local v5
		if v4 then
			v5 = v4.Character
		else
			v5 = nil
		end
		local v6
		if v5 then
			v6 = v5:FindFirstChildOfClass("Humanoid")
		else
			v6 = nil
		end
		if v4 ~= v3.player or (v5 ~= v3.character or v6 ~= v3.humanoid) then
			v3.player = v4
			v3.character = v5
			v3.humanoid = v6
			v3.characterChanged = true
		end
	end,
	["cleanDirty"] = function(p7) -- name: cleanDirty
		p7.engineInterface.characterChanged = false
	end
}