-- Path: ReplicatedStorage/StickerCatalog
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("HttpService")
local v_u_3 = {
	["DATA"] = "StickerCatalogData",
	["MAX_NAME"] = 40,
	["MAX_CATEGORY"] = 24,
	["MAX_PRICE"] = 10000000,
	["BUILTIN"] = {
		{
			["id"] = "st_to1kr6gaw1",
			["name"] = "MahankhonDiwa",
			["image"] = "rbxassetid://87599061677668",
			["aspect"] = 1,
			["category"] = "\224\184\151\224\184\177\224\185\136\224\184\167\224\185\132\224\184\155",
			["price"] = 0,
			["tint"] = false
		}
	},
	["list"] = {},
	["byId"] = {},
	["ready"] = false
}
local v_u_4 = Instance.new("BindableEvent")
v_u_3.changed = v_u_4.Event
function v_u_3.cut(p5, p6) -- name: cut
	local v7 = tostring(p5 or ""):gsub("[%c]", " "):match("^%s*(.-)%s*$") or ""
	if utf8.len(v7) == nil then
		return ""
	end
	if p6 < utf8.len(v7) then
		v7 = v7:sub(1, utf8.offset(v7, p6 + 1) - 1)
	end
	return v7
end
function v_u_3.clean(p8) -- name: clean
	-- upvalues: (copy) v_u_3
	if type(p8) == "table" then
		local v9 = p8.id
		if type(v9) == "string" and (#p8.id <= 40 and p8.id:match("^[%w_]+$")) then
			local v10 = p8.image
			local v11 = type(v10) ~= "string" and "" or p8.image
			if not (v11:match("^rbxassetid://%d+$") or v11:match("^rbxasset://[%w_/%.]+$")) then
				return nil
			end
			local v12 = v_u_3.cut(p8.name, v_u_3.MAX_NAME)
			local v13 = v_u_3.cut(p8.category, v_u_3.MAX_CATEGORY)
			local v14 = p8.maxSize
			local v15 = tonumber(v14)
			local v16 = {
				["id"] = p8.id
			}
			if v12 == "" then
				v12 = p8.id
			end
			v16.name = v12
			v16.image = v11
			local v17 = p8.aspect
			local v18 = tonumber(v17) or 1
			v16.aspect = math.clamp(v18, 0.1, 10)
			v16.category = v13 == "" and "\224\184\151\224\184\177\224\185\136\224\184\167\224\185\132\224\184\155" or v13
			local v19 = p8.price
			local v20 = tonumber(v19) or 0
			local v21 = math.floor(v20)
			local v22 = v_u_3.MAX_PRICE
			v16.price = math.clamp(v21, 0, v22)
			v16.tint = p8.tint == true
			local v23 = p8.pass
			local v24
			if type(v23) == "string" and p8.pass ~= "" then
				v24 = p8.pass:sub(1, 40)
			else
				v24 = nil
			end
			v16.pass = v24
			local v25
			if v15 then
				v25 = math.clamp(v15, 0.2, 8)
			else
				v25 = nil
			end
			v16.maxSize = v25
			return v16
		end
	end
	return nil
end
function v_u_3.isBuiltin(p26) -- name: isBuiltin
	-- upvalues: (copy) v_u_3
	for _, v27 in v_u_3.BUILTIN do
		if v27.id ~= p26 then
			continue
		end
		return true
	end
	return false
end
local function v_u_40(p28) -- name: rebuild
	-- upvalues: (copy) v_u_3, (copy) v_u_2, (copy) v_u_4
	local v29 = {}
	local v30 = {}
	for _, v31 in v_u_3.BUILTIN do
		local v32 = v_u_3.clean(v31)
		if not v32 or v29[v32.id] then
			continue
		end
		v29[v32.id] = v32
		table.insert(v30, v32)
	end
	if type(p28) == "string" and p28 ~= "" then
		local v33 = v_u_2.JSONDecode
		local v34 = v_u_2
		local v35, v36 = pcall(v33, v34, p28)
		if v35 and type(v36) == "table" then
			for _, v37 in v36 do
				local v38 = v_u_3.clean(v37)
				if not v38 or v29[v38.id] then
					continue
				end
				v29[v38.id] = v38
				table.insert(v30, v38)
			end
		end
	end
	local v39 = v_u_3
	v_u_3.list = v30
	v39.byId = v29
	v_u_4:Fire()
end
function v_u_3.get(p41) -- name: get
	-- upvalues: (copy) v_u_3
	return v_u_3.byId[p41]
end
function v_u_3.waitReady(p42) -- name: waitReady
	-- upvalues: (copy) v_u_3
	local v43 = os.clock()
	while not v_u_3.ready and os.clock() - v43 < (p42 or 30) do
		task.wait(0.1)
	end
	return v_u_3.ready
end
function v_u_3.isAdmin(p44) -- name: isAdmin
	local v45
	if p44 == nil then
		v45 = false
	else
		v45 = p44:GetAttribute("StickerAdmin") == true
	end
	return v45
end
v_u_40(nil)
local v_u_46 = v1:FindFirstChild(v_u_3.DATA)
if not (v_u_46 and v_u_46:IsA("StringValue")) then
	local v_u_47 = nil
	v_u_47 = v1.ChildAdded:Connect(function(p_u_48)
		-- upvalues: (copy) v_u_3, (ref) v_u_47, (copy) v_u_40
		if p_u_48.Name == v_u_3.DATA and p_u_48:IsA("StringValue") then
			v_u_47:Disconnect()
			v_u_3.ready = true
			v_u_40(p_u_48.Value)
			p_u_48.Changed:Connect(function()
				-- upvalues: (ref) v_u_40, (copy) p_u_48
				v_u_40(p_u_48.Value)
			end)
		end
	end)
	return v_u_3
end
v_u_3.ready = true
v_u_40(v_u_46.Value)
v_u_46.Changed:Connect(function()
	-- upvalues: (copy) v_u_40, (copy) v_u_46
	v_u_40(v_u_46.Value)
end)
return v_u_3