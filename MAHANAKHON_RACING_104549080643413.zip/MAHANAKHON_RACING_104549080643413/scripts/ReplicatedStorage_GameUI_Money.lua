-- Path: ReplicatedStorage/GameUI/Money
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = require(game:GetService("ReplicatedStorage"):WaitForChild("UiOwn")).Instance
local v_u_2 = game:GetService("TweenService")
local v_u_3 = {}
local v_u_4 = Color3.fromRGB(255, 244, 178)
local v_u_5 = Color3.fromRGB(255, 204, 64)
local v_u_6 = Color3.fromRGB(206, 122, 8)
local v_u_7 = Color3.fromRGB(138, 78, 0)
local v_u_8 = Color3.fromRGB(150, 86, 2)
local v_u_9 = Font.new("rbxasset://fonts/families/Montserrat.json", Enum.FontWeight.Heavy)
local function v_u_18(p10, p11, p12, p13) -- name: circle
	-- upvalues: (copy) v_u_1
	local v14 = v_u_1.new("Frame")
	v14.BorderSizePixel = 0
	v14.AnchorPoint = Vector2.new(0.5, 0.5)
	v14.Position = UDim2.fromScale(0.5, 0.5)
	v14.Size = UDim2.fromScale(p11, p11)
	v14.BackgroundColor3 = Color3.new(1, 1, 1)
	v14.ZIndex = p12 or 1
	for v15, v16 in p13 or {} do
		v14[v15] = v16
	end
	local v17 = v_u_1.new("UICorner")
	v17.CornerRadius = UDim.new(1, 0)
	v17.Parent = v14
	v14.Parent = p10
	return v14
end
local function v_u_28(p19, p20, p21) -- name: grad
	-- upvalues: (copy) v_u_1
	local v22 = v_u_1.new("UIGradient")
	local v23 = {}
	for _, v24 in p20 do
		local v25 = ColorSequenceKeypoint.new
		local v26 = v24[1]
		local v27 = v24[2]
		table.insert(v23, v25(v26, v27))
	end
	v22.Color = ColorSequence.new(v23)
	v22.Rotation = p21 or 90
	v22.Parent = p19
	return v22
end
local function v_u_32(p29, p30) -- name: zAll
	for _, v31 in p29:GetDescendants() do
		if not v31:IsA("GuiObject") then
			continue
		end
		v31.ZIndex = v31.ZIndex + p30
	end
end
local function v_u_40(p33, p34, p35) -- name: sweep
	-- upvalues: (copy) v_u_1
	local v36 = v_u_1.new("CanvasGroup")
	v36.Name = "Sweep"
	v36.BackgroundTransparency = 1
	v36.Size = UDim2.fromScale(1, 1)
	v36.ZIndex = p34
	v36.Parent = p33
	local v37 = v_u_1.new("UICorner")
	v37.CornerRadius = p35 or UDim.new(1, 0)
	v37.Parent = v36
	local v38 = v_u_1.new("Frame")
	v38.Name = "Band"
	v38.BorderSizePixel = 0
	v38.BackgroundColor3 = Color3.new(1, 1, 1)
	v38.AnchorPoint = Vector2.new(0.5, 0.5)
	v38.Rotation = 24
	v38.Size = UDim2.fromScale(0.34, 2.4)
	v38.Position = UDim2.fromScale(-0.6, 0.5)
	v38.ZIndex = p34
	v38.Parent = v36
	local v39 = v_u_1.new("UIGradient")
	v39.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(0.5, 0.35), NumberSequenceKeypoint.new(1, 1) })
	v39.Parent = v38
	return v36, v38
end
local v_u_41 = TweenInfo.new(0.75, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut)
local function v_u_43(p42) -- name: runSweep
	-- upvalues: (copy) v_u_2, (copy) v_u_41
	p42.Position = UDim2.fromScale(-0.6, 0.5)
	v_u_2:Create(p42, v_u_41, {
		["Position"] = UDim2.fromScale(1.6, 0.5)
	}):Play()
end
function v_u_3.coin(p_u_44, p45) -- name: coin
	-- upvalues: (copy) v_u_1, (copy) v_u_18, (copy) v_u_5, (copy) v_u_7, (copy) v_u_28, (copy) v_u_4, (copy) v_u_6, (copy) v_u_8, (copy) v_u_9, (copy) v_u_40, (copy) v_u_43, (copy) v_u_2, (copy) v_u_32
	local v46 = p45 or {}
	local v47 = v_u_1.new("Frame")
	v47.Name = "Coin"
	v47.BackgroundTransparency = 1
	v47.Size = UDim2.fromOffset(p_u_44, p_u_44)
	v47.AnchorPoint = v46.anchor or Vector2.zero
	local v_u_48 = v_u_1.new("Frame")
	v_u_48.Name = "Holder"
	v_u_48.BackgroundTransparency = 1
	v_u_48.AnchorPoint = Vector2.new(0.5, 0.5)
	v_u_48.Position = UDim2.fromScale(0.5, 0.5)
	v_u_48.Size = UDim2.fromScale(1, 1)
	v_u_48.Parent = v47
	local v_u_49 = {}
	if v46.glow ~= false then
		for v50, v51 in { 1.55, 1.3 } do
			local v52 = v_u_18(v_u_48, v51, 1, {
				["BackgroundColor3"] = v_u_5,
				["BackgroundTransparency"] = v50 == 1 and 0.9 or 0.82
			})
			v52.Name = "Glow"
			table.insert(v_u_49, v52)
		end
	end
	local v53 = v_u_18
	local v54 = {}
	local v55 = UDim2.new
	local v56 = p_u_44 * 0.05
	local v57 = math.floor(v56)
	v54.Position = v55(0.5, 0, 0.5, (math.max(1, v57)))
	local v58 = v53(v_u_48, 1, 2, v54)
	v58.Name = "Edge"
	v58.BackgroundColor3 = v_u_7
	local v59 = v_u_18(v_u_48, 1, 3)
	v59.Name = "Rim"
	v_u_28(v59, {
		{ 0, v_u_4 },
		{ 0.42, v_u_5 },
		{ 1, v_u_6 }
	}, 60)
	local v60 = v_u_7
	local v61 = p_u_44 / 30
	local v62 = math.max(1, v61)
	local v63 = v_u_1.new("UIStroke")
	v63.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v63.Color = v60
	v63.Thickness = v62
	v63.Transparency = 0.15
	v63.Parent = v59
	if p_u_44 >= 40 then
		for v64 = 0, 19 do
			local v65 = v64 / 20 * 3.141592653589793 * 2
			local v66 = v_u_1.new("Frame")
			v66.BorderSizePixel = 0
			v66.BackgroundColor3 = v_u_7
			v66.BackgroundTransparency = 0.55
			v66.AnchorPoint = Vector2.new(0.5, 0.5)
			local v67 = UDim2.fromOffset
			local v68 = p_u_44 * 0.035
			local v69 = math.max(1, v68)
			local v70 = p_u_44 * 0.07
			v66.Size = v67(v69, (math.max(2, v70)))
			v66.Position = UDim2.fromScale(math.cos(v65) * 0.455 + 0.5, math.sin(v65) * 0.455 + 0.5)
			v66.Rotation = math.deg(v65) + 90
			v66.ZIndex = 4
			v66.Parent = v_u_48
		end
	end
	local v71 = v_u_18(v_u_48, 0.78, 4)
	v71.Name = "Face"
	v_u_28(v71, {
		{ 0, v_u_6 },
		{ 0.55, v_u_5 },
		{ 1, v_u_4 }
	}, 60)
	local v72 = Color3.fromRGB(255, 236, 160)
	local v73 = p_u_44 / 44
	local v74 = math.max(1, v73)
	local v75 = v_u_1.new("UIStroke")
	v75.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v75.Color = v72
	v75.Thickness = v74
	v75.Transparency = 0.25
	v75.Parent = v71
	local v76 = v_u_18(v_u_48, 0.62, 5, {
		["BackgroundTransparency"] = 1
	})
	v76.Name = "Ring"
	local v77 = v_u_8
	local v78 = p_u_44 / 48
	local v79 = math.max(1, v78)
	local v80 = v_u_1.new("UIStroke")
	v80.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v80.Color = v77
	v80.Thickness = v79
	v80.Transparency = 0.55
	v80.Parent = v76
	local function v87(p81, p82, p83, p84) -- name: sign
		-- upvalues: (ref) v_u_1, (copy) p_u_44, (ref) v_u_9, (copy) v_u_48
		local v85 = v_u_1.new("TextLabel")
		v85.Name = "Sign"
		v85.BackgroundTransparency = 1
		v85.AnchorPoint = Vector2.new(0.5, 0.5)
		v85.Position = UDim2.new(0.5, p82, 0.5, p82 + p_u_44 * 0.01)
		v85.Size = UDim2.fromScale(0.8, 0.8)
		v85.FontFace = v_u_9
		v85.Text = "\224\184\191"
		local v86 = p_u_44 * 0.5
		v85.TextSize = math.floor(v86)
		v85.TextColor3 = p81
		v85.TextTransparency = p84 or 0
		v85.ZIndex = p83
		v85.Parent = v_u_48
		return v85
	end
	local v88 = Color3.fromRGB(255, 250, 220)
	local v89 = p_u_44 * 0.03
	v87(v88, -math.max(1, v89), 6, 0.25)
	v_u_28(v87(v_u_8, 0, 7), {
		{ 0, Color3.fromRGB(176, 104, 8) },
		{ 1, Color3.fromRGB(116, 60, 0) }
	}, 90)
	local v90 = v_u_18(v_u_48, 0.2, 8, {
		["Position"] = nil,
		["BackgroundTransparency"] = 0.55,
		["Position"] = UDim2.fromScale(0.3, 0.27)
	})
	v90.Name = "Spot"
	local v91 = v_u_1.new("UIGradient")
	v91.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(1, 1) })
	v91.Rotation = 45
	v91.Parent = v90
	local v_u_92
	if v46.sweep == false then
		v_u_92 = nil
	else
		local v93
		v93, v_u_92 = v_u_40(v_u_48, 9)
	end
	local v102 = {
		["shine"] = function() -- name: shine
			-- upvalues: (ref) v_u_92, (ref) v_u_43
			if v_u_92 then
				v_u_43(v_u_92)
			end
		end,
		["flip"] = function() -- name: flip
			-- upvalues: (ref) v_u_2, (copy) v_u_48, (ref) v_u_92, (ref) v_u_43
			local v94 = v_u_2:Create(v_u_48, TweenInfo.new(0.12, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
				["Size"] = UDim2.fromScale(0.08, 1)
			})
			v94.Completed:Connect(function()
				-- upvalues: (ref) v_u_2, (ref) v_u_48, (ref) v_u_92, (ref) v_u_43
				v_u_2:Create(v_u_48, TweenInfo.new(0.22, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
					["Size"] = UDim2.fromScale(1, 1)
				}):Play()
				if v_u_92 then
					v_u_43(v_u_92)
				end
			end)
			v94:Play()
		end,
		["glow"] = function(p95) -- name: glow
			-- upvalues: (copy) v_u_49, (ref) v_u_2
			for v96, v97 in v_u_49 do
				local v98 = v_u_2
				local v99 = TweenInfo.new(0.3)
				local v100 = {}
				local v101
				if p95 then
					v101 = v96 == 1 and 0.78 or 0.66
				else
					v101 = v96 == 1 and 0.9 or 0.82
				end
				v100.BackgroundTransparency = v101
				v98:Create(v97, v99, v100):Play()
			end
		end
	}
	if v46.z then
		v_u_32(v47, v46.z)
	end
	return v47, v102
end
function v_u_3.note(p103) -- name: note
	-- upvalues: (copy) v_u_1, (copy) v_u_28, (copy) v_u_9
	local v104 = p103 * 0.5
	local v105 = math.floor(v104)
	local v106 = v_u_1.new("Frame")
	v106.Name = "Note"
	v106.BorderSizePixel = 0
	v106.BackgroundColor3 = Color3.new(1, 1, 1)
	v106.Size = UDim2.fromOffset(p103, v105)
	local v107 = v_u_1.new("UICorner")
	local v108 = UDim.new
	local v109 = p103 * 0.05
	v107.CornerRadius = v108(0, (math.max(2, v109)))
	v107.Parent = v106
	v_u_28(v106, {
		{ 0, Color3.fromRGB(150, 232, 160) },
		{ 0.5, Color3.fromRGB(70, 186, 112) },
		{ 1, Color3.fromRGB(26, 122, 74) }
	}, 35)
	local v110 = Color3.fromRGB(14, 84, 48)
	local v111 = p103 / 60
	local v112 = math.max(1, v111)
	local v113 = v_u_1.new("UIStroke")
	v113.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v113.Color = v110
	v113.Thickness = v112
	v113.Transparency = 0.2
	v113.Parent = v106
	local v114 = v_u_1.new("Frame")
	v114.BackgroundTransparency = 1
	v114.AnchorPoint = Vector2.new(0.5, 0.5)
	v114.Position = UDim2.fromScale(0.5, 0.5)
	v114.Size = UDim2.new(1, -p103 * 0.1, 1, -p103 * 0.1)
	v114.Parent = v106
	local v115 = v_u_1.new("UICorner")
	local v116 = UDim.new
	local v117 = p103 * 0.03
	v115.CornerRadius = v116(0, (math.max(2, v117)))
	v115.Parent = v114
	local v118 = Color3.fromRGB(230, 255, 230)
	local v119 = p103 / 80
	local v120 = math.max(1, v119)
	local v121 = v_u_1.new("UIStroke")
	v121.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v121.Color = v118
	v121.Thickness = v120
	v121.Transparency = 0.45
	v121.Parent = v114
	local v122 = v_u_1.new("Frame")
	v122.BorderSizePixel = 0
	v122.BackgroundColor3 = Color3.fromRGB(220, 255, 226)
	v122.BackgroundTransparency = 0.25
	v122.AnchorPoint = Vector2.new(0.5, 0.5)
	v122.Position = UDim2.fromScale(0.5, 0.5)
	v122.Size = UDim2.fromOffset(v105 * 0.62, v105 * 0.62)
	v122.Parent = v106
	local v123 = v_u_1.new("UICorner")
	v123.CornerRadius = UDim.new(1, 0)
	v123.Parent = v122
	local v124 = Color3.fromRGB(14, 96, 56)
	local v125 = p103 / 70
	local v126 = math.max(1, v125)
	local v127 = v_u_1.new("UIStroke")
	v127.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v127.Color = v124
	v127.Thickness = v126
	v127.Transparency = 0.3
	v127.Parent = v122
	local v128 = v_u_1.new("TextLabel")
	v128.BackgroundTransparency = 1
	v128.Size = UDim2.fromScale(1, 1)
	v128.FontFace = v_u_9
	v128.Text = "\224\184\191"
	local v129 = v105 * 0.42
	v128.TextSize = math.floor(v129)
	v128.TextColor3 = Color3.fromRGB(16, 100, 58)
	v128.Parent = v122
	for _, v130 in { Vector2.new(0.13, 0.22), Vector2.new(0.87, 0.78) } do
		local v131 = v_u_1.new("Frame")
		v131.BorderSizePixel = 0
		v131.BackgroundColor3 = Color3.fromRGB(230, 255, 232)
		v131.BackgroundTransparency = 0.35
		v131.AnchorPoint = Vector2.new(0.5, 0.5)
		v131.Position = UDim2.fromScale(v130.X, v130.Y)
		v131.Size = UDim2.fromOffset(p103 * 0.12, v105 * 0.1)
		v131.Parent = v106
		local v132 = v_u_1.new("UICorner")
		v132.CornerRadius = UDim.new(1, 0)
		v132.Parent = v131
	end
	return v106
end
local function v_u_146(p133) -- name: goldBar
	-- upvalues: (copy) v_u_1, (copy) v_u_28, (copy) v_u_4, (copy) v_u_5, (copy) v_u_6, (copy) v_u_7
	local v134 = p133 * 0.42
	local v135 = math.floor(v134)
	local v136 = v_u_1.new("Frame")
	v136.Name = "GoldBar"
	v136.BorderSizePixel = 0
	v136.BackgroundColor3 = Color3.new(1, 1, 1)
	v136.Size = UDim2.fromOffset(p133, v135)
	local v137 = v_u_1.new("UICorner")
	local v138 = UDim.new
	local v139 = p133 * 0.08
	v137.CornerRadius = v138(0, (math.max(2, v139)))
	v137.Parent = v136
	v_u_28(v136, {
		{ 0, v_u_4 },
		{ 0.45, v_u_5 },
		{ 1, v_u_6 }
	}, 90)
	local v140 = v_u_7
	local v141 = p133 / 50
	local v142 = math.max(1, v141)
	local v143 = v_u_1.new("UIStroke")
	v143.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v143.Color = v140
	v143.Thickness = v142
	v143.Transparency = 0.1
	v143.Parent = v136
	local v144 = v_u_1.new("Frame")
	v144.BorderSizePixel = 0
	v144.BackgroundColor3 = Color3.fromRGB(255, 250, 210)
	v144.BackgroundTransparency = 0.3
	v144.Position = UDim2.fromScale(0.12, 0.12)
	v144.Size = UDim2.fromScale(0.76, 0.22)
	v144.Parent = v136
	local v145 = v_u_1.new("UICorner")
	v145.CornerRadius = UDim.new(1, 0)
	v145.Parent = v144
	return v136
end
function v_u_3.sparkle(p147, p148, p149, p150, p_u_151, p152) -- name: sparkle
	-- upvalues: (copy) v_u_1, (copy) v_u_2
	local v_u_153 = v_u_1.new("Frame")
	v_u_153.Name = "Sparkle"
	v_u_153.BackgroundTransparency = 1
	v_u_153.AnchorPoint = Vector2.new(0.5, 0.5)
	v_u_153.Position = UDim2.fromScale(p148, p149)
	v_u_153.Size = UDim2.fromOffset(p150, p150)
	v_u_153.ZIndex = p152 or 20
	v_u_153.Parent = p147
	for _, v154 in { 0, 90 } do
		local v155 = v_u_1.new("Frame")
		v155.BorderSizePixel = 0
		v155.BackgroundColor3 = Color3.fromRGB(255, 252, 230)
		v155.AnchorPoint = Vector2.new(0.5, 0.5)
		v155.Position = UDim2.fromScale(0.5, 0.5)
		local v156 = UDim2.new
		local v157 = p150 * 0.16
		v155.Size = v156(0, math.max(2, v157), 1, 0)
		v155.Rotation = v154
		v155.ZIndex = v_u_153.ZIndex
		v155.Parent = v_u_153
		local v158 = v_u_1.new("UICorner")
		v158.CornerRadius = UDim.new(1, 0)
		v158.Parent = v155
	end
	local v_u_159 = v_u_1.new("UIScale")
	v_u_159.Scale = 0
	v_u_159.Parent = v_u_153
	task.spawn(function()
		-- upvalues: (copy) p_u_151, (copy) v_u_153, (ref) v_u_2, (copy) v_u_159
		task.wait(p_u_151 or 0)
		while v_u_153.Parent do
			v_u_2:Create(v_u_159, TweenInfo.new(0.45, Enum.EasingStyle.Sine, Enum.EasingDirection.Out), {
				["Scale"] = 1
			}):Play()
			task.wait(0.5)
			v_u_2:Create(v_u_159, TweenInfo.new(0.55, Enum.EasingStyle.Sine, Enum.EasingDirection.In), {
				["Scale"] = 0
			}):Play()
			task.wait(1.4 + math.random() * 1.6)
		end
	end)
	return v_u_153
end
function v_u_3.pile(p160, p161) -- name: pile
	-- upvalues: (copy) v_u_1, (copy) v_u_32, (copy) v_u_3, (copy) v_u_146
	local v162 = v_u_1.new("Frame")
	v162.Name = "Pile"
	v162.BackgroundTransparency = 1
	v162.Size = UDim2.fromOffset(p161.X, p161.Y)
	local v163 = p161.X
	local v164 = p161.Y
	local v165 = v163 * 0.55
	local v166 = v164 * 0.9
	local v167 = math.min(v165, v166)
	local v168 = math.floor(v167)
	local v169 = math.min(v163, v164) * 0.3
	local v170 = math.floor(v169)
	local v171 = ({
		0,
		1,
		3,
		4,
		5
	})[p160] or 0
	for v172 = 1, v171 do
		local v173 = v172 - (v171 + 1) / 2
		local v174 = v_u_3.note(v168)
		local v175 = 0.5 + v173 * 0.07
		local v176 = 0.42 - math.abs(v173) * 0.02
		local v177 = v173 * 9
		v174.AnchorPoint = Vector2.new(0.5, 0.5)
		v174.Position = UDim2.fromScale(v175, v176)
		v174.Rotation = v177 or 0
		v174.Parent = v162
		v_u_32(v174, v172)
		v174.ZIndex = v174.ZIndex + v172
	end
	if p160 >= 5 then
		local v178 = v_u_146
		local v179 = v168 * 0.62
		local v180 = v178((math.floor(v179)))
		v180.AnchorPoint = Vector2.new(0.5, 0.5)
		v180.Position = UDim2.fromScale(0.25, 0.7)
		v180.Rotation = -8
		v180.Parent = v162
		v_u_32(v180, 8)
		v180.ZIndex = v180.ZIndex + 8
		local v181 = v_u_146
		local v182 = v168 * 0.62
		local v183 = v181((math.floor(v182)))
		v183.AnchorPoint = Vector2.new(0.5, 0.5)
		v183.Position = UDim2.fromScale(0.75, 0.7)
		v183.Rotation = 8
		v183.Parent = v162
		v_u_32(v183, 8)
		v183.ZIndex = v183.ZIndex + 8
		local v184 = v_u_146
		local v185 = v168 * 0.62
		local v186 = v184((math.floor(v185)))
		v186.AnchorPoint = Vector2.new(0.5, 0.5)
		v186.Position = UDim2.fromScale(0.5, 0.6)
		v186.Rotation = 0
		v186.Parent = v162
		v_u_32(v186, 9)
		v186.ZIndex = v186.ZIndex + 9
	end
	local v187 = {
		{ 0.5, 0.66 },
		{ 0.32, 0.74 },
		{ 0.68, 0.74 },
		{ 0.2, 0.6 },
		{ 0.8, 0.6 }
	}
	for v188 = 1, ({
		3,
		3,
		4,
		5,
		5
	})[p160] or 3 do
		local v189 = v_u_3.coin
		local v190
		if v188 == 1 then
			v190 = v170
		else
			local v191 = v170 * 0.82
			v190 = math.floor(v191)
		end
		local v192 = v189(v190, {
			["glow"] = false,
			["sweep"] = false
		})
		local v193 = v187[v188][1]
		local v194 = v187[v188][2] + (p160 == 1 and -0.1 or 0)
		local v195 = (v188 == 1 and 3 or 0) + 12
		v192.AnchorPoint = Vector2.new(0.5, 0.5)
		v192.Position = UDim2.fromScale(v193, v194)
		v192.Rotation = 0
		v192.Parent = v162
		v_u_32(v192, v195)
		v192.ZIndex = v192.ZIndex + v195
	end
	if p160 >= 3 then
		for v196 = 1, p160 - 1 do
			local v197 = v_u_3.sparkle
			local v198 = v196 * 0.23 % 0.8 + 0.12
			local v199 = v196 * 0.37 % 0.5 + 0.12
			local v200 = v170 * 0.45
			v197(v162, v198, v199, math.floor(v200), v196 * 0.35, 30)
		end
	end
	return v162
end
return v_u_3