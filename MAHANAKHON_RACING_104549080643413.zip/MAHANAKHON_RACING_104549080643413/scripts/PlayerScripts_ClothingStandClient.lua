-- Path: Players/ygggggg55551/PlayerScripts/ClothingStandClient
-- Class: LocalScript  true/Enum.RunContext.Legacy
-- Decompiled by BALL KUN Universal Map Dump

local v1 = game:GetService("CollectionService")
local v_u_2 = {}
game:GetService("RunService").RenderStepped:Connect(function(p3)
	-- upvalues: (copy) v_u_2
	local v4 = workspace.CurrentCamera
	if v4 then
		v4 = v4.CFrame.Position
	end
	for v5, v6 in v_u_2 do
		if v5.Parent then
			if not v4 or (v4 - v6.axis.Position).Magnitude >= 150 then
				continue
			end
			v6.angle = (v6.angle + p3 * 2 * 3.141592653589793 / 16) % 6.283185307179586
			local v7 = v6.axis * CFrame.Angles(0, v6.angle, 0)
			for v8, v9 in v6.parts do
				v8.CFrame = v7 * v9
			end
		else
			local v10 = v_u_2[v5]
			if not v10 then
				continue
			end
			for _, v11 in v10.connections do
				v11:Disconnect()
			end
			v_u_2[v5] = nil
		end
	end
end)
local v_u_12 = game:GetService("TweenService")
local v_u_13 = TweenInfo.new(0.2, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
local v_u_14 = TweenInfo.new(0.08, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
local v_u_15 = Color3.fromRGB(255, 255, 255)
local function v_u_24(p16) -- name: trackSign
	-- upvalues: (copy) v_u_12, (copy) v_u_13, (copy) v_u_15, (copy) v_u_14
	local v17 = p16:WaitForChild("BuyButton", 10)
	if v17 then
		v17 = v17:FindFirstChildOfClass("ClickDetector")
	end
	local v18 = p16:FindFirstChild("PriceTag", true)
	if v17 and (v18 and not v18:GetAttribute("HoverReady")) then
		v18:SetAttribute("HoverReady", true)
		local v_u_19 = v18:FindFirstChild("Hover") or Instance.new("UIScale")
		v_u_19.Name = "Hover"
		v_u_19.Parent = v18
		local v_u_20 = v18:FindFirstChildOfClass("UIStroke")
		local v_u_21
		if v_u_20 then
			v_u_21 = v_u_20.Color
		else
			v_u_21 = v_u_20
		end
		local v_u_22 = false
		v17.MouseHoverEnter:Connect(function()
			-- upvalues: (ref) v_u_22, (ref) v_u_12, (copy) v_u_19, (ref) v_u_13, (copy) v_u_20, (ref) v_u_15
			v_u_22 = true
			v_u_12:Create(v_u_19, v_u_13, {
				["Scale"] = 1.1
			}):Play()
			if v_u_20 then
				v_u_12:Create(v_u_20, v_u_13, {
					["Color"] = v_u_15
				}):Play()
			end
		end)
		v17.MouseHoverLeave:Connect(function()
			-- upvalues: (ref) v_u_22, (ref) v_u_12, (copy) v_u_19, (ref) v_u_13, (copy) v_u_20, (copy) v_u_21
			v_u_22 = false
			v_u_12:Create(v_u_19, v_u_13, {
				["Scale"] = 1
			}):Play()
			if v_u_20 then
				v_u_12:Create(v_u_20, v_u_13, {
					["Color"] = v_u_21
				}):Play()
			end
		end)
		v17.MouseClick:Connect(function()
			-- upvalues: (ref) v_u_12, (copy) v_u_19, (ref) v_u_14, (ref) v_u_22, (ref) v_u_13
			local v23 = v_u_12:Create(v_u_19, v_u_14, {
				["Scale"] = 0.95
			})
			v23.Completed:Connect(function()
				-- upvalues: (ref) v_u_22, (ref) v_u_12, (ref) v_u_19, (ref) v_u_13
				v_u_12:Create(v_u_19, v_u_13, {
					["Scale"] = v_u_22 and 1.1 or 1
				}):Play()
			end)
			v23:Play()
		end)
	end
end
v1:GetInstanceAddedSignal("ClothingSign"):Connect(function(p25)
	-- upvalues: (copy) v_u_24
	task.spawn(v_u_24, p25)
end)
local function v_u_40(p26) -- name: track
	-- upvalues: (copy) v_u_2
	if v_u_2[p26] or not p26:IsA("Model") then
		return
	else
		local v27 = p26:WaitForChild("Mannequin", 10)
		local v28 = p26:WaitForChild("Pedestal", 10)
		if v27 and (v28 and (not v_u_2[p26] and p26:IsDescendantOf(workspace))) then
			local v29 = v28.Position
			local v_u_30 = CFrame.new(v29.X, v29.Y, v29.Z)
			local v_u_31 = {
				["axis"] = nil,
				["parts"] = nil,
				["angle"] = 0,
				["connections"] = nil,
				["axis"] = v_u_30,
				["parts"] = {},
				["connections"] = {}
			}
			local function v33(p32) -- name: add
				-- upvalues: (copy) v_u_31, (copy) v_u_30
				if p32:IsA("BasePart") then
					v_u_31.parts[p32] = v_u_30:ToObjectSpace(p32.CFrame)
				end
			end
			for _, v34 in v27:GetDescendants() do
				if not v34:IsA("BasePart") then
					continue
				end
				v_u_31.parts[v34] = v_u_30:ToObjectSpace(v34.CFrame)
			end
			local v35 = v_u_31.connections
			local v36 = v27.DescendantAdded
			table.insert(v35, v36:Connect(v33))
			local v37 = v_u_31.connections
			local v38 = v27.DescendantRemoving
			table.insert(v37, v38:Connect(function(p39)
				-- upvalues: (copy) v_u_31
				v_u_31.parts[p39] = nil
			end))
			v_u_2[p26] = v_u_31
		end
	end
end
local function v44(p41) -- name: forget
	-- upvalues: (copy) v_u_2
	local v42 = v_u_2[p41]
	if v42 then
		for _, v43 in v42.connections do
			v43:Disconnect()
		end
		v_u_2[p41] = nil
	end
end
for _, v45 in v1:GetTagged("ClothingSign") do
	task.spawn(v_u_24, v45)
end
v1:GetInstanceAddedSignal("ClothingStand"):Connect(function(p46)
	-- upvalues: (copy) v_u_40
	task.spawn(v_u_40, p46)
end)
v1:GetInstanceRemovedSignal("ClothingStand"):Connect(v44)
for _, v47 in v1:GetTagged("ClothingStand") do
	task.spawn(v_u_40, v47)
end