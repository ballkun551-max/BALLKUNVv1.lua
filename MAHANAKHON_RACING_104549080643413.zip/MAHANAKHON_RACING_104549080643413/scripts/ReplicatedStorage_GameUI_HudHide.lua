-- Path: ReplicatedStorage/GameUI/HudHide
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("StarterGui")
local v_u_4 = game:GetService("ProximityPromptService")
local v_u_5 = game:GetService("TextChatService")
local v_u_6 = {
	["changed"] = Instance.new("BindableEvent"),
	["KEEP"] = {
		["HudToggle"] = true,
		["DashcamViewPicker"] = true,
		["ControlLayout"] = true
	},
	["CONTROLS"] = {
		["GameDash"] = true,
		["TouchPedals"] = true,
		["TouchGui"] = true
	}
}
local v_u_7 = {
	Enum.CoreGuiType.Chat,
	Enum.CoreGuiType.PlayerList,
	Enum.CoreGuiType.Backpack,
	Enum.CoreGuiType.EmotesMenu,
	Enum.CoreGuiType.Health
}
local v_u_8 = { "BackgroundTransparency", "TextTransparency", "TextStrokeTransparency" }
local v_u_9 = { "BackgroundTransparency", "ImageTransparency" }
local v_u_10 = { "BackgroundTransparency", "ScrollBarImageTransparency" }
local v_u_11 = { "BackgroundTransparency" }
local v_u_12 = { "Transparency" }
local v_u_13 = v_u_1.LocalPlayer
local v_u_14 = {}
local v_u_15 = false
local v_u_16 = {}
local v_u_17 = {}
local v_u_18 = {}
local v_u_19 = nil
local v_u_20 = 0
local function v_u_22(p21) -- name: propsOf
	-- upvalues: (copy) v_u_12, (copy) v_u_8, (copy) v_u_9, (copy) v_u_10, (copy) v_u_11
	if p21:IsA("UIStroke") then
		return v_u_12
	elseif p21:IsA("TextLabel") or (p21:IsA("TextButton") or p21:IsA("TextBox")) then
		return v_u_8
	elseif p21:IsA("ImageLabel") or (p21:IsA("ImageButton") or p21:IsA("ViewportFrame")) then
		return v_u_9
	elseif p21:IsA("ScrollingFrame") then
		return v_u_10
	elseif p21:IsA("GuiObject") then
		return v_u_11
	else
		return nil
	end
end
local function v_u_29(p23) -- name: ghost
	-- upvalues: (copy) v_u_22, (ref) v_u_16
	for _, v24 in p23:GetDescendants() do
		local v25 = v_u_22(v24)
		if not v25 then
			continue
		end
		for _, v26 in v25 do
			local v27 = v24[v26]
			if v27 >= 1 then
				continue
			end
			local v28 = v_u_16[v24]
			if not v28 then
				v28 = {}
				v_u_16[v24] = v28
			end
			v28[v26] = v27
			v24[v26] = 1
		end
	end
end
local function v_u_34() -- name: unghost
	-- upvalues: (ref) v_u_16
	for v_u_30, v31 in v_u_16 do
		if not v_u_30.Parent then
			continue
		end
		for v_u_32, v_u_33 in v31 do
			pcall(function()
				-- upvalues: (copy) v_u_30, (copy) v_u_32, (copy) v_u_33
				v_u_30[v_u_32] = v_u_33
			end)
		end
	end
	v_u_16 = {}
end
local function v_u_37(p_u_35) -- name: switchOff
	-- upvalues: (ref) v_u_17, (ref) v_u_15
	if not v_u_17[p_u_35] then
		local v_u_36 = {
			["want"] = p_u_35.Enabled
		}
		v_u_36.conn = p_u_35:GetPropertyChangedSignal("Enabled"):Connect(function()
			-- upvalues: (copy) p_u_35, (copy) v_u_36, (ref) v_u_15
			if p_u_35.Enabled then
				v_u_36.want = true
				if v_u_15 then
					p_u_35.Enabled = false
				end
			end
		end)
		v_u_17[p_u_35] = v_u_36
		p_u_35.Enabled = false
	end
end
local function v_u_40() -- name: switchBack
	-- upvalues: (ref) v_u_17
	for v38, v39 in v_u_17 do
		v39.conn:Disconnect()
		if not (v38.Parent and v39.want) then
			continue
		end
		v38.Enabled = true
	end
	v_u_17 = {}
end
local function v_u_44() -- name: hideTags
	-- upvalues: (copy) v_u_1, (ref) v_u_18
	for _, v41 in v_u_1:GetPlayers() do
		local v42 = v41.Character
		if not v42 then
			continue
		end
		for _, v43 in v42:GetDescendants() do
			if not (v43:IsA("BillboardGui") and v43.Enabled) then
				continue
			end
			v_u_18[v43] = true
			v43:SetAttribute("GameHid", true)
			v43.Enabled = false
		end
	end
end
local function v_u_47() -- name: step
	-- upvalues: (copy) v_u_13, (copy) v_u_6, (copy) v_u_29, (ref) v_u_17, (copy) v_u_37, (ref) v_u_20, (copy) v_u_44
	local v45 = v_u_13:FindFirstChildOfClass("PlayerGui")
	if v45 then
		for _, v46 in v45:GetChildren() do
			if not v46:IsA("ScreenGui") or v_u_6.KEEP[v46.Name] then
				continue
			end
			if v_u_6.CONTROLS[v46.Name] then
				v_u_29(v46)
			else
				if not v46.Enabled and v_u_17[v46] then
					continue
				end
				v_u_37(v46)
			end
		end
		if os.clock() - v_u_20 > 0.5 then
			v_u_20 = os.clock()
			v_u_44()
		end
	end
end
local function v_u_73() -- name: apply
	-- upvalues: (ref) v_u_14, (ref) v_u_15, (ref) v_u_19, (copy) v_u_7, (copy) v_u_3, (copy) v_u_4, (copy) v_u_5, (ref) v_u_20, (copy) v_u_47, (copy) v_u_2, (copy) v_u_34, (copy) v_u_40, (ref) v_u_18, (copy) v_u_6
	local v48 = next(v_u_14) ~= nil
	if v48 ~= v_u_15 then
		v_u_15 = v48
		if v_u_15 then
			v_u_19 = {
				["core"] = {}
			}
			for _, v49 in v_u_7 do
				local v50 = v_u_3.GetCoreGuiEnabled
				local v51 = v_u_3
				local v52, v53 = pcall(v50, v51, v49)
				v_u_19.core[v49] = not v52 and true or v53
				local v54 = v_u_3.SetCoreGuiEnabled
				local v55 = v_u_3
				pcall(v54, v55, v49, false)
			end
			local v56 = v_u_3.SetCore
			local v57 = v_u_3
			pcall(v56, v57, "TopbarEnabled", false)
			local function v58()
				-- upvalues: (ref) v_u_19, (ref) v_u_4
				v_u_19.prompts = v_u_4.Enabled
				v_u_4.Enabled = false
			end
			pcall(v58)
			local function v60()
				-- upvalues: (ref) v_u_5, (ref) v_u_19
				local v59 = v_u_5:FindFirstChildOfClass("BubbleChatConfiguration")
				if v59 then
					v_u_19.bubbles = v59.Enabled
					v59.Enabled = false
				end
			end
			pcall(v60)
			v_u_20 = 0
			v_u_47()
			v_u_2:BindToRenderStep("HudHide", Enum.RenderPriority.Last.Value, v_u_47)
		else
			local v61 = v_u_2.UnbindFromRenderStep
			local v62 = v_u_2
			pcall(v61, v62, "HudHide")
			v_u_34()
			v_u_40()
			for v63 in v_u_18 do
				if not v63.Parent then
					continue
				end
				v63.Enabled = true
				v63:SetAttribute("GameHid", nil)
			end
			v_u_18 = {}
			if v_u_19 then
				for v64, v65 in v_u_19.core do
					local v66 = v_u_3.SetCoreGuiEnabled
					local v67 = v_u_3
					pcall(v66, v67, v64, v65)
				end
				local function v68()
					-- upvalues: (ref) v_u_19, (ref) v_u_4
					if v_u_19.prompts ~= nil then
						v_u_4.Enabled = v_u_19.prompts
					end
				end
				pcall(v68)
				local function v70()
					-- upvalues: (ref) v_u_5, (ref) v_u_19
					local v69 = v_u_5:FindFirstChildOfClass("BubbleChatConfiguration")
					if v69 and v_u_19.bubbles ~= nil then
						v69.Enabled = v_u_19.bubbles
					end
				end
				pcall(v70)
			end
			local v71 = v_u_3.SetCore
			local v72 = v_u_3
			pcall(v71, v72, "TopbarEnabled", true)
			v_u_19 = nil
		end
		v_u_6.changed:Fire(v_u_15)
	end
end
function v_u_6.set(p74, p75) -- name: set
	-- upvalues: (ref) v_u_14, (copy) v_u_73
	v_u_14[p74] = p75 and true or nil
	v_u_73()
end
function v_u_6.toggle() -- name: toggle
	-- upvalues: (ref) v_u_15, (ref) v_u_14, (copy) v_u_73
	if v_u_15 then
		v_u_14 = {}
	else
		v_u_14.manual = true
	end
	v_u_73()
end
function v_u_6.isHidden() -- name: isHidden
	-- upvalues: (ref) v_u_15
	return v_u_15
end
v_u_13.CharacterAdded:Connect(function()
	-- upvalues: (ref) v_u_15, (ref) v_u_20
	if v_u_15 then
		v_u_20 = 0
	end
end)
return v_u_6