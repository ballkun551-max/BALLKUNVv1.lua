-- Path: ReplicatedStorage/StickerZone
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = game:GetService("CollectionService")
local v_u_12 = {
	["TAG"] = "StickerZone",
	["contains"] = function(p2) -- name: contains
		-- upvalues: (copy) v_u_1
		for _, v3 in v_u_1:GetTagged("StickerZone") do
			if not (v3:IsA("BasePart") and v3:IsDescendantOf(workspace)) then
				continue
			end
			local v4 = v3.CFrame:PointToObjectSpace(p2)
			local v5 = v3.Size / 2
			local v6 = v4.X
			if math.abs(v6) > v5.X then
				continue
			end
			local v7 = v4.Y
			if math.abs(v7) > v5.Y then
				continue
			end
			local v8 = v4.Z
			if math.abs(v8) > v5.Z then
				continue
			end
			return true
		end
		return false
	end,
	["vehicleIn"] = function(p9) -- name: vehicleIn
		-- upvalues: (copy) v_u_12
		if not (p9 and p9.Parent) then
			return false
		end
		local v10 = p9:FindFirstChild("DriverSeat", true) or p9:FindFirstChild("VehicleSeat", true)
		local v11
		if v10 and v10:IsA("BasePart") then
			v11 = v10.Position
		else
			v11 = p9:GetPivot().Position
		end
		return v_u_12.contains(v11)
	end
}
return v_u_12