-- Path: StarterPlayer/PlayerModule/Types/ControlModuleData
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

return {}