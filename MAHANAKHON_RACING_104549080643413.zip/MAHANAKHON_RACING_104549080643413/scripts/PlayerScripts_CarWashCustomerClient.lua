-- Path: Players/ygggggg55551/PlayerScripts/CarWashCustomerClient
-- Class: LocalScript  true/Enum.RunContext.Legacy
-- Decompiled by BALL KUN Universal Map Dump

local v1 = game:GetService("Players")
local v_u_2 = game:GetService("ReplicatedStorage")
local v3 = game:GetService("RunService")
local v_u_4 = require(v_u_2:WaitForChild("CarWashShared"))
local _ = v_u_4.TEXT
local v_u_5 = v1.LocalPlayer
local v6 = v_u_5:WaitForChild("PlayerGui")
local v_u_7 = Instance.new("Folder")
v_u_7.Name = "CarWashCustomers"
v_u_7.Parent = workspace
local v_u_8 = game:GetService("CollectionService")
local v_u_9 = require(v_u_2:WaitForChild("MapRoads"))
local v_u_10 = CFrame.new(-1228.2, 2.022, 164.2, 0, 0, -1, 0, 1, 0, 1, 0, 0)
local function v_u_18(p11, p12) -- name: siteFrame
	-- upvalues: (copy) v_u_8, (copy) v_u_4, (copy) v_u_10
	if p11 then
		p11 = p11:GetAttribute("SiteFrame")
	end
	if typeof(p11) == "CFrame" then
		return p11
	else
		local v13 = (1 / 0)
		local v14 = nil
		for _, v15 in v_u_8:GetTagged(v_u_4.SITE_TAG) do
			if not (v15:IsA("Model") and v15:IsDescendantOf(workspace)) then
				continue
			end
			local v16 = not p12 and 0 or (v15:GetPivot().Position - p12.Position).Magnitude
			if v16 >= v13 then
				continue
			end
			v14 = v15:GetPivot()
			v13 = v16
		end
		if v14 then
			return v14
		else
			local v17 = workspace:FindFirstChild("Map")
			if v17 then
				v17 = v17:FindFirstChild("CarWashTX")
			end
			if v17 then
				return v17:GetPivot()
			else
				return v_u_10
			end
		end
	end
end
local function v_u_40(p19, p20) -- name: roadPoint
	-- upvalues: (copy) v_u_9
	local v21 = v_u_9.NODES
	local v22 = v_u_9.EDGES
	local v23 = nil
	for v24 = 1, #v22, 3 do
		local v25 = v22[v24]
		local v26 = v22[v24 + 1]
		local v27 = v21[2 * v25 - 1]
		local v28 = v21[2 * v25]
		local v29 = v21[2 * v26 - 1]
		local v30 = v21[2 * v26]
		local v31 = v29 - v27
		local v32 = v30 - v28
		local v33 = v31 * v31 + v32 * v32
		local v34
		if v33 > 0 then
			local v35 = ((p19.X - v27) * v31 + (p19.Z - v28) * v32) / v33
			v34 = math.clamp(v35, 0, 1)
		else
			v34 = 0
		end
		local v36 = v27 + v31 * v34
		local v37 = v28 + v32 * v34
		local v38 = (p19.X - v36) ^ 2 + (p19.Z - v37) ^ 2
		local v39 = math.sqrt(v38)
		if v39 >= p20 then
			continue
		end
		v23 = Vector3.new(v36, 0, v37)
		p20 = v39
	end
	return v23, p20
end
local v_u_41 = Font.new("rbxasset://fonts/families/BuilderSans.json", Enum.FontWeight.Bold)
local v_u_42 = {}
local v_u_43 = RaycastParams.new()
v_u_43.FilterType = Enum.RaycastFilterType.Exclude
v_u_43.RespectCanCollide = true
local function v_u_51(p44, p45) -- name: ground
	-- upvalues: (copy) v_u_7, (copy) v_u_5, (copy) v_u_43
	local v46 = { v_u_7 }
	if v_u_5.Character then
		local v47 = v_u_5.Character
		table.insert(v46, v47)
	end
	local v48 = workspace:FindFirstChild("SpawnedVehicles")
	if v48 then
		table.insert(v46, v48)
	end
	v_u_43.FilterDescendantsInstances = v46
	local v49 = workspace:Raycast(Vector3.new(p44, 3, p45), Vector3.new(0, -8, 0), v_u_43)
	if not v49 then
		return 0.85
	end
	local v50 = v49.Position.Y
	return math.clamp(v50, -0.5, 1.2)
end
local function v_u_84(p52) -- name: buildPath
	-- upvalues: (copy) v_u_51
	local v53 = {}
	for v54 = 1, #p52 - 1 do
		local v55 = v54 - 1
		local v56 = p52[math.max(v55, 1)]
		local v57 = p52[v54]
		local v58 = p52[v54 + 1]
		local v59 = v54 + 2
		local v60 = #p52
		local v61 = p52[math.min(v59, v60)]
		local v62 = (v58 - v57).Magnitude / 2
		local v63 = math.ceil(v62)
		local v64 = math.max(2, v63)
		for v65 = 0, v64 - 1 do
			local v66 = v65 / v64
			local v67 = v66 * v66
			local v68 = v66 * v66 * v66
			local v69 = 0.5 * (2 * v57 + (-v56 + v58) * v66 + (2 * v56 - 5 * v57 + 4 * v58 - v61) * v67 + (-v56 + 3 * v57 - 3 * v58 + v61) * v68)
			table.insert(v53, v69)
		end
	end
	local v70 = p52[#p52]
	table.insert(v53, v70)
	local v71 = 0
	local v72 = {}
	for v73, v74 in v53 do
		if v73 > 1 then
			local v75 = v74.X
			local v76 = v74.Z
			local v77 = Vector3.new(v75, 0, v76)
			local v78 = v53[v73 - 1].X
			local v79 = v53[v73 - 1].Z
			v71 = v71 + (v77 - Vector3.new(v78, 0, v79)).Magnitude
		end
		local v80 = {}
		local v81 = v74.X
		local v82 = v_u_51(v74.X, v74.Z)
		local v83 = v74.Z
		v80.p = Vector3.new(v81, v82, v83)
		v80.d = v71
		v72[v73] = v80
	end
	return {
		["list"] = v72,
		["total"] = v71
	}
end
local function v_u_99(p85, p86) -- name: along
	local v87 = p85.list
	if #v87 < 2 then
		return v87[1].p, Vector3.new(-1, -0, -0)
	else
		local v88 = p85.total
		local v89 = math.clamp(p86, 0, v88)
		local v90 = 1
		while v90 < #v87 - 1 and v87[v90 + 1].d < v89 do
			v90 = v90 + 1
		end
		local v91 = v87[v90]
		local v92 = v87[v90 + 1]
		local v93 = v92.d <= v91.d and 0 or (v89 - v91.d) / (v92.d - v91.d)
		local v94 = v92.p - v91.p
		local v95 = v94.X
		local v96 = v94.Z
		local v97 = Vector3.new(v95, 0, v96)
		local v98 = v91.p:Lerp(v92.p, v93)
		if v97.Magnitude > 0.001 then
			return v98, v97.Unit
		else
			return v98, Vector3.new(-1, -0, -0)
		end
	end
end
local function v_u_107(p100, p101, p102, p103) -- name: corner
	for _, v104 in { 0.25, 0.5, 0.75 } do
		local v105 = p101:Lerp(p102, v104)
		local v106 = p102:Lerp(p103, v104)
		table.insert(p100, v105:Lerp(v106, v104))
	end
end
local function v_u_152(p108, p109) -- name: drivePaths
	-- upvalues: (copy) v_u_107, (copy) v_u_84
	for _, v110 in {
		"Gate",
		"AisleIn",
		"RoadIn",
		"RoadInNear",
		"RoadOutNear",
		"RoadOut"
	} do
		if typeof(p108:GetAttribute(v110)) == "Vector3" then
			continue
		end
		return nil
	end
	local v111 = p108:GetAttribute("Gate")
	local v112 = p108:GetAttribute("AisleIn")
	local v113 = p108:GetAttribute("RoadIn")
	local v114 = p108:GetAttribute("RoadInNear")
	local v115 = p108:GetAttribute("RoadOutNear")
	local v116 = p108:GetAttribute("RoadOut")
	local v117 = v112.X
	local v118 = v112.Z
	local v119 = Vector3.new(v117, 0, v118).Unit
	local v120 = v111.X
	local v121 = v111.Z
	local v122 = Vector3.new(v120, 0, v121)
	local v123 = p109.Position
	local v124 = v123.X
	local v125 = v123.Z
	local v126 = Vector3.new(v124, 0, v125)
	local v127 = p109.LookVector
	local v128 = v127.X
	local v129 = v127.Z
	local v130 = Vector3.new(v128, 0, v129).Unit
	local v131 = v126 + v130 * (v122 - v126):Dot(v130)
	local v132 = v131 - v130 * 5
	local v133 = v132 - v119 * 11
	local v134 = v132 + v130 * 11
	local v135 = {}
	local v136 = v113.X
	local v137 = v113.Z
	local v138 = Vector3.new(v136, 0, v137)
	local v139 = v114.X
	local v140 = v114.Z
	__set_list(v135, 1, {v138, (Vector3.new(v139, 0, v140))})
	if (v133 - v122):Dot(v119) > 2 then
		local v141 = v122 - v130 * 5
		table.insert(v135, v141)
	end
	table.insert(v135, v133)
	v_u_107(v135, v133, v132, v134)
	table.insert(v135, v134)
	table.insert(v135, v126)
	local v142 = v131 + v130 * 7
	local v143 = v131 + v119 * 7
	local v144 = { v126, v142 }
	v_u_107(v144, v142, v131, v143)
	table.insert(v144, v143)
	local v145 = {}
	local v146 = v131 - v119 * 4
	local v147 = v115.X
	local v148 = v115.Z
	local v149 = Vector3.new(v147, 0, v148)
	local v150 = v116.X
	local v151 = v116.Z
	__set_list(v145, 1, {v143, v146, v122, v149, (Vector3.new(v150, 0, v151))})
	return v_u_84(v135), v_u_84(v144), v_u_84(v145)
end
local v_u_153 = {
	"Neck",
	"Waist",
	"LeftShoulder",
	"RightShoulder",
	"LeftElbow",
	"RightElbow",
	"LeftHip",
	"RightHip",
	"LeftKnee",
	"RightKnee",
	"Root",
	"LeftWrist",
	"RightWrist",
	"LeftAnkle",
	"RightAnkle"
}
local function v_u_157(p154) -- name: jointsOf
	-- upvalues: (copy) v_u_153
	local v155 = {}
	for _, v156 in p154:GetDescendants() do
		if not (v156:IsA("Motor6D") or v156:IsA("AnimationConstraint") and (v156.Attachment0 and v156.Attachment1)) or (not table.find(v_u_153, v156.Name) or v155[v156.Name]) then
			continue
		end
		v155[v156.Name] = v156
	end
	return v155
end
local v_u_158 = {
	["bike"] = {
		["LeftHip"] = { 78 },
		["RightHip"] = { 78 },
		["LeftKnee"] = { -72 },
		["RightKnee"] = { -72 },
		["LeftShoulder"] = { 62, 0, -6 },
		["RightShoulder"] = { 62, 0, 6 },
		["LeftElbow"] = { 22 },
		["RightElbow"] = { 22 }
	},
	["car"] = {
		["LeftHip"] = { 88 },
		["RightHip"] = { 88 },
		["LeftKnee"] = { -84 },
		["RightKnee"] = { -84 },
		["LeftShoulder"] = { 52, 0, -10 },
		["RightShoulder"] = { 52, 0, 10 },
		["LeftElbow"] = { 38 },
		["RightElbow"] = { 38 }
	}
}
local v_u_159 = {
	{ "Left", -1 },
	{ "Right", 1 }
}
local v_u_160 = Random.new()
local function v_u_169(p161, p162) -- name: turnBetween
	if p161.Magnitude < 0.0001 or p162.Magnitude < 0.0001 then
		return CFrame.identity
	end
	local v163 = p161.Unit
	local v164 = p162.Unit
	local v165 = v163:Dot(v164)
	local v166 = math.clamp(v165, -1, 1)
	local v167 = v163:Cross(v164)
	if v167.Magnitude < 0.00001 then
		if v166 > 0 then
			return CFrame.identity
		end
		local v168 = v163.X
		if math.abs(v168) < 0.9 then
			v167 = v163:Cross(Vector3.new(1, 0, 0))
		else
			v167 = v163:Cross(Vector3.new(0, 1, 0))
		end
	end
	return CFrame.fromAxisAngle(v167.Unit, (math.acos(v166)))
end
local function v_u_204(p170, p171, p172, p173, p174, p175) -- name: reach
	-- upvalues: (copy) v_u_169
	local v176
	if p171:IsA("Motor6D") then
		v176 = p171.C0
	else
		v176 = p171.Attachment0.CFrame
	end
	local v177
	if p171:IsA("Motor6D") then
		v177 = p171.C1
	else
		v177 = p171.Attachment1.CFrame
	end
	local v178
	if p172:IsA("Motor6D") then
		v178 = p172.C0
	else
		v178 = p172.Attachment0.CFrame
	end
	local v179
	if p172:IsA("Motor6D") then
		v179 = p172.C1
	else
		v179 = p172.Attachment1.CFrame
	end
	local v180
	if p173:IsA("Motor6D") then
		v180 = p173.C0
	else
		v180 = p173.Attachment0.CFrame
	end
	local v181 = p170 * v176
	local v182 = v181.Position
	local v183 = (v177.Position - v178.Position).Magnitude
	local v184 = (v179.Position - v180.Position).Magnitude
	if v183 >= 0.05 and v184 >= 0.05 then
		local v185 = p174 - v182
		local v186
		if v185.Magnitude > 0.0001 then
			v186 = v185.Unit
		else
			v186 = -v181.UpVector
		end
		local v187 = v185.Magnitude
		local v188 = v183 - v184
		local v189 = math.abs(v188) + 0.01
		local v190 = (v183 + v184) * 0.995
		local v191 = math.clamp(v187, v189, v190)
		local v192 = p175 - v182 - v186 * (p175 - v182):Dot(v186)
		local v193
		if v192.Magnitude > 0.0001 then
			v193 = v192.Unit
		else
			v193 = v181.LookVector
		end
		local v194 = (v183 * v183 + v191 * v191 - v184 * v184) / (2 * v183 * v191)
		local v195 = math.clamp(v194, -1, 1)
		local v196 = v182 + v186 * (v183 * v195)
		local v197 = 1 - v195 * v195
		local v198 = v196 + v193 * (v183 * math.sqrt(v197))
		local v199 = v182 + v186 * v191
		local v200 = (v181 * v177:Inverse() * v178).Position - v182
		local v201 = v181.Rotation:Inverse() * v_u_169(v200, v198 - v182) * v181.Rotation
		p171.Transform = v201
		local v202 = v181 * v201 * v177:Inverse() * v178
		local v203 = (v202 * v179:Inverse() * v180).Position - v202.Position
		p172.Transform = v202.Rotation:Inverse() * v_u_169(v203, v199 - v202.Position) * v202.Rotation
	end
end
local function v_u_212(p205) -- name: tuckPoseFor
	-- upvalues: (copy) v_u_2, (copy) v_u_160
	local v206 = v_u_2:FindFirstChild("TuckPoses")
	if v206 and type(p205) == "string" then
		local v207 = {}
		for _, v208 in v206:GetChildren() do
			if not v208:IsA("KeyframeSequence") or (v208:GetAttribute("Kind") == "Park" or typeof(v208:GetAttribute("AnchorOffset")) ~= "Vector3") then
				continue
			end
			local v209 = string.split
			local v210 = v208:GetAttribute("VehicleIds") or ""
			for _, v211 in v209(tostring(v210), ",") do
				if v211:match("^%s*(.-)%s*$") ~= p205 then
					continue
				end
				table.insert(v207, v208)
			end
		end
		if #v207 > 0 then
			return v207[v_u_160:NextInteger(1, #v207)]
		else
			return nil
		end
	else
		return nil
	end
end
local function v_u_218(p213) -- name: posesOf
	local v214 = nil
	for _, v215 in p213:GetChildren() do
		if not v215:IsA("Keyframe") or v214 and v215.Time >= v214.Time then
			continue
		end
		v214 = v215
	end
	local v216 = {}
	if v214 then
		for _, v217 in v214:GetDescendants() do
			if not v217:IsA("Pose") or v217.Weight <= 0 then
				continue
			end
			v216[v217.Name] = v217.CFrame
		end
	end
	return v216
end
local function v_u_282(p219, p220, p221) -- name: riderFor
	-- upvalues: (copy) v_u_160, (copy) v_u_212, (copy) v_u_218
	local v222 = p219:FindFirstChild("Chassis")
	local v223
	if v222 then
		v223 = v222:FindFirstChild("Seat")
	else
		v223 = v222
	end
	if not (v223 and (v223:IsA("Attachment") and (p221.Root and (p221.Waist and (p221.LeftHip and p221.RightHip))))) then
		return nil
	end
	local v224 = p219:FindFirstChild("SteerRoot")
	local v225 = p219:GetAttribute("RiderLean")
	local v226 = type(v225) ~= "number" and 9 or math.clamp(v225, 0, 30)
	local v227 = math.rad(v226)
	local v228 = {
		["w"] = 0,
		["speed"] = 0,
		["seed"] = nil,
		["seat"] = nil,
		["gripLeft"] = nil,
		["gripRight"] = nil,
		["footLeft"] = nil,
		["footRight"] = nil,
		["rootTilt"] = nil,
		["waistLean"] = nil,
		["headUp"] = nil,
		["seed"] = v_u_160:NextNumber(0, 6.28),
		["seat"] = p220:ToObjectSpace(v223.WorldCFrame)
	}
	local v229
	if v224 then
		v229 = v224:FindFirstChild("GripLeft")
	else
		v229 = v224
	end
	local v230
	if v229 and v229:IsA("Attachment") then
		v230 = p220:PointToObjectSpace(v229.WorldPosition)
	else
		v230 = nil
	end
	v228.gripLeft = v230
	if v224 then
		v224 = v224:FindFirstChild("GripRight")
	end
	local v231
	if v224 and v224:IsA("Attachment") then
		v231 = p220:PointToObjectSpace(v224.WorldPosition)
	else
		v231 = nil
	end
	v228.gripRight = v231
	local v232 = v222:FindFirstChild("FootLeft")
	local v233
	if v232 and v232:IsA("Attachment") then
		v233 = p220:PointToObjectSpace(v232.WorldPosition)
	else
		v233 = nil
	end
	v228.footLeft = v233
	local v234 = v222:FindFirstChild("FootRight")
	local v235
	if v234 and v234:IsA("Attachment") then
		v235 = p220:PointToObjectSpace(v234.WorldPosition)
	else
		v235 = nil
	end
	v228.footRight = v235
	v228.rootTilt = CFrame.Angles(-v227 * 0.35, 0, 0)
	v228.waistLean = v227 * 0.65 + 0.06981317007977318
	v228.headUp = v227 * 0.6 + 0.06981317007977318
	local v236 = v_u_212(p219:GetAttribute("VehicleId"))
	if v236 then
		v228.tp = v_u_218(v236)
		v228.anchor = v236:GetAttribute("AnchorOffset")
	end
	local v237 = p221.LeftHip
	local v238
	if v237:IsA("Motor6D") then
		v238 = v237.C0
	else
		v238 = v237.Attachment0.CFrame
	end
	local v239 = v238.Position
	local v240 = p221.RightHip
	local v241
	if v240:IsA("Motor6D") then
		v241 = v240.C0
	else
		v241 = v240.Attachment0.CFrame
	end
	local v242 = (v239 + v241.Position) / 2
	local v243
	if v228.tp then
		local v244 = CFrame.new(v228.anchor)
		local v245 = p221.Root
		local v246
		if v245:IsA("Motor6D") then
			v246 = v245.C0
		else
			v246 = v245.Attachment0.CFrame
		end
		local v247 = v244 * v246 * (v228.tp.LowerTorso or CFrame.identity)
		local v248 = p221.Root
		local v249
		if v248:IsA("Motor6D") then
			v249 = v248.C1
		else
			v249 = v248.Attachment1.CFrame
		end
		v243 = v247 * v249:Inverse() * v242 + Vector3.new(0, 0, 0.2)
	else
		v243 = Vector3.new(0, 0.3, 0.25)
	end
	local v250 = p221.Root
	local v251
	if v250:IsA("Motor6D") then
		v251 = v250.C0
	else
		v251 = v250.Attachment0.CFrame
	end
	local v252 = v251 * v228.rootTilt
	local v253 = p221.Root
	local v254
	if v253:IsA("Motor6D") then
		v254 = v253.C1
	else
		v254 = v253.Attachment1.CFrame
	end
	v228.upRootPos = v243 - v252 * v254:Inverse() * v242
	local v255 = p221.RightShoulder
	local v256 = p221.RightElbow
	local v257 = p221.RightWrist
	if v228.gripRight and (v255 and (v256 and v257)) then
		local v258
		if v255:IsA("Motor6D") then
			v258 = v255.C1
		else
			v258 = v255.Attachment1.CFrame
		end
		local v259 = v258.Position
		local v260
		if v256:IsA("Motor6D") then
			v260 = v256.C0
		else
			v260 = v256.Attachment0.CFrame
		end
		local v261 = (v259 - v260.Position).Magnitude
		local v262
		if v256:IsA("Motor6D") then
			v262 = v256.C1
		else
			v262 = v256.Attachment1.CFrame
		end
		local v263 = v262.Position
		local v264
		if v257:IsA("Motor6D") then
			v264 = v257.C0
		else
			v264 = v257.Attachment0.CFrame
		end
		local v265 = v261 + (v263 - v264.Position).Magnitude
		local v266 = v228.seat:PointToObjectSpace(v228.gripRight)
		local v267 = CFrame.new(v228.upRootPos)
		local v268 = p221.Root
		local v269
		if v268:IsA("Motor6D") then
			v269 = v268.C0
		else
			v269 = v268.Attachment0.CFrame
		end
		local v270 = v267 * v269 * v228.rootTilt
		local v271 = p221.Root
		local v272
		if v271:IsA("Motor6D") then
			v272 = v271.C1
		else
			v272 = v271.Attachment1.CFrame
		end
		local v273 = v270 * v272:Inverse()
		for _ = 1, 14 do
			local v274 = p221.Waist
			local v275
			if v274:IsA("Motor6D") then
				v275 = v274.C0
			else
				v275 = v274.Attachment0.CFrame
			end
			local v276 = v273 * v275 * CFrame.Angles(-v228.waistLean, 0, 0)
			local v277 = p221.Waist
			local v278
			if v277:IsA("Motor6D") then
				v278 = v277.C1
			else
				v278 = v277.Attachment1.CFrame
			end
			local v279 = v276 * v278:Inverse()
			local v280
			if v255:IsA("Motor6D") then
				v280 = v255.C0
			else
				v280 = v255.Attachment0.CFrame
			end
			if ((v279 * v280).Position - v266).Magnitude - 0.15 <= v265 * 0.97 then
				break
			end
			v228.waistLean = v228.waistLean + 0.04363323129985824
		end
	end
	local v281
	if v228.tp == nil then
		v281 = false
	else
		v281 = v_u_160:NextNumber() < 0.45
	end
	v228.tucker = v281
	return v228
end
local function v_u_302(p283, p284, p285) -- name: rideRoot
	local v286 = p283.rider
	if not v286 then
		return p284 * p283.seatRel
	end
	local v287 = p284.Position
	local v288 = (not v286.lastPos or p285 <= 0) and 0 or (v287 - v286.lastPos).Magnitude / p285
	v286.lastPos = v287
	local v289 = v286.speed
	local v290 = math.min(v288, 200) - v286.speed
	local v291 = p285 * 5
	v286.speed = v289 + v290 * math.min(1, v291)
	local v292 = v286.tucker and v286.speed > 15 and 1 or 0
	local v293 = v286.w
	local v294 = v292 - v286.w
	local v295 = -p285 * 2.5
	local v296 = p285 * 2.5
	local v297 = v293 + math.clamp(v294, v295, v296)
	v286.w = math.clamp(v297, 0, 1)
	v286.frame = p284
	local v298 = p284 * v286.seat
	local v299 = v298 * CFrame.new(v286.upRootPos)
	if not v286.tp or v286.w <= 0 then
		return v299
	end
	local v300 = v298 * CFrame.new(v286.anchor)
	local v301 = v286.w
	return v299:Lerp(v300, v301 * v301 * (3 - 2 * v301))
end
local function v_u_366(p303, p304) -- name: riderPose
	-- upvalues: (copy) v_u_159, (copy) v_u_204
	local v305 = p303.rider
	local v306 = p303.joints
	local v307 = v305.frame
	if v307 then
		local v308 = v305.w
		local v309 = v308 * v308 * (3 - 2 * v308)
		local v310 = v305.tp or {}
		local v311 = v307 * v305.seat
		local v312 = p304 * 2.4
		local v313 = math.sin(v312) * 0.020943951023931952
		local v314 = p304 * 0.45 + v305.seed
		local v315 = math.sin(v314) * 0.3839724354387525 * (1 - v309)
		local v316 = v305.rootTilt
		local v317 = CFrame.new
		local v318 = p304 * 11 + v305.seed
		local v319 = v316 * v317(0, math.sin(v318) * 0.015, 0)
		local v320 = v310.LowerTorso
		if v320 and v309 > 0 then
			v319 = v319:Lerp(v320, v309)
		end
		local v321 = CFrame.Angles
		local v322 = -v305.waistLean + v313
		local v323 = p304 * 0.45 + v305.seed
		local v324 = v321(v322, math.sin(v323) * 0.06981317007977318 * (1 - v309), 0)
		local v325 = v310.UpperTorso
		if v325 and v309 > 0 then
			v324 = v324:Lerp(v325, v309)
		end
		v306.Root.Transform = v319
		v306.Waist.Transform = v324
		if v306.Neck then
			local v326 = v306.Neck
			local v327 = CFrame.Angles(v305.headUp - v313, v315, 0)
			local v328 = v310.Head
			if v328 and v309 > 0 then
				v327 = v327:Lerp(v328, v309)
			end
			v326.Transform = v327
		end
		local v329 = p303.root.CFrame
		local v330 = v306.Root
		local v331
		if v330:IsA("Motor6D") then
			v331 = v330.C0
		else
			v331 = v330.Attachment0.CFrame
		end
		local v332 = v329 * v331 * v319
		local v333 = v306.Root
		local v334
		if v333:IsA("Motor6D") then
			v334 = v333.C1
		else
			v334 = v333.Attachment1.CFrame
		end
		local v335 = v332 * v334:Inverse()
		local v336 = v306.Waist
		local v337
		if v336:IsA("Motor6D") then
			v337 = v336.C0
		else
			v337 = v336.Attachment0.CFrame
		end
		local v338 = v335 * v337 * v324
		local v339 = v306.Waist
		local v340
		if v339:IsA("Motor6D") then
			v340 = v339.C1
		else
			v340 = v339.Attachment1.CFrame
		end
		local v341 = v338 * v340:Inverse()
		for _, v342 in v_u_159 do
			local v343 = v342[1]
			local v344 = v342[2]
			local v345 = v305["grip" .. v343]
			local v346 = v306[v343 .. "Shoulder"]
			local v347 = v306[v343 .. "Elbow"]
			local v348 = v306[v343 .. "Wrist"]
			if v345 and (v346 and (v347 and v348)) then
				local v349 = v307 * v345
				local v350
				if v346:IsA("Motor6D") then
					v350 = v346.C0
				else
					v350 = v346.Attachment0.CFrame
				end
				local v351 = (v341 * v350).Position
				local v352 = v_u_204
				local v353 = v349 + ((v351 - v349).Magnitude <= 0.001 and Vector3.new(0, 0, 0) or (v351 - v349).Unit * 0.15)
				local v354 = v344 * 1.2
				v352(v341, v346, v347, v348, v353, v351 + v311:VectorToWorldSpace((Vector3.new(v354, -1.2, 0.9))))
			end
			local v355 = v306[v343 .. "Hip"]
			local v356 = v306[v343 .. "Knee"]
			local v357 = v306[v343 .. "Ankle"]
			if not (v355 and (v356 and v357)) then
				continue
			end
			local v358 = v305["foot" .. v343]
			if v358 then
				local v359
				if v355:IsA("Motor6D") then
					v359 = v355.C0
				else
					v359 = v355.Attachment0.CFrame
				end
				local v360 = (v335 * v359).Position
				local v361 = v_u_204
				local v362 = v307 * v358 + v311.UpVector * 0.35
				local v363 = v344 * 0.5
				v361(v335, v355, v356, v357, v362, v360 + v311:VectorToWorldSpace((Vector3.new(v363, 0.4, -2.5))))
			end
			if v309 <= 0 then
				continue
			end
			for v364, v365 in {
				[v343 .. "UpperLeg"] = v355,
				[v343 .. "LowerLeg"] = v356,
				[v343 .. "Foot"] = v357
			} do
				if not v310[v364] then
					continue
				end
				v365.Transform = v365.Transform:Lerp(v310[v364], v309)
			end
		end
	end
end
local function v_u_414(p367, p368, p369) -- name: pose
	-- upvalues: (copy) v_u_153, (copy) v_u_366, (copy) v_u_158
	local v370 = p367.joints
	for _, v371 in v_u_153 do
		local v372 = v370[v371]
		if not v372 then
			continue
		end
		v372.Transform = CFrame.Angles(0, 0, 0)
	end
	if p368 == "ride" and p367.rider then
		v_u_366(p367, p369)
		return
	elseif p368 == "ride" then
		for v373, v374 in v_u_158[p367.kind] or v_u_158.bike do
			local v375 = v374[1]
			local v376 = v374[2]
			local v377 = v374[3]
			local v378 = v370[v373]
			if not v378 then
				continue
			end
			v378.Transform = CFrame.Angles(math.rad(v375 or 0), math.rad(v376 or 0), (math.rad(v377 or 0)))
		end
	elseif p368 == "walk" then
		local v379 = p369 * 8
		local v380 = math.sin(v379)
		local v381 = v380 * 26
		local v382 = v370.LeftHip
		if v382 then
			v382.Transform = CFrame.Angles(math.rad(v381 or 0), 0, 0)
		end
		local v383 = v380 * -26
		local v384 = v370.RightHip
		if v384 then
			v384.Transform = CFrame.Angles(math.rad(v383 or 0), 0, 0)
		end
		local v385 = -v380
		local v386 = -math.max(0, v385) * 30
		local v387 = v370.LeftKnee
		if v387 then
			v387.Transform = CFrame.Angles(math.rad(v386 or 0), 0, 0)
		end
		local v388 = -math.max(0, v380) * 30
		local v389 = v370.RightKnee
		if v389 then
			v389.Transform = CFrame.Angles(math.rad(v388 or 0), 0, 0)
		end
		local v390 = v380 * -18
		local v391 = v370.LeftShoulder
		if v391 then
			v391.Transform = CFrame.Angles(math.rad(v390 or 0), 0, 0)
		end
		local v392 = v380 * 18
		local v393 = v370.RightShoulder
		if v393 then
			v393.Transform = CFrame.Angles(math.rad(v392 or 0), 0, 0)
			return
		end
	else
		local v394 = p369 * 0.35
		local v395 = math.sin(v394) > 0.2
		if v395 then
			local v396 = v370.RightShoulder
			if v396 then
				v396.Transform = CFrame.Angles(0.6632251157578453, 0, 0.20943951023931956)
			end
			local v397 = v370.RightElbow
			if v397 then
				v397.Transform = CFrame.Angles(1.361356816555577, 0, 0)
			end
			local v398 = v370.LeftShoulder
			if v398 then
				v398.Transform = CFrame.Angles(0.5235987755982988, 0, -0.24434609527920614)
			end
			local v399 = v370.LeftElbow
			if v399 then
				v399.Transform = CFrame.Angles(1.2217304763960306, 0, 0)
			end
			local v400 = v370.Neck
			if v400 then
				v400.Transform = CFrame.Angles(-0.3839724354387525, 0, 0)
			end
		else
			local v401 = p369 * 0.7
			local v402 = math.sin(v401) * 25
			local v403 = v370.Neck
			if v403 then
				v403.Transform = CFrame.Angles(0.06981317007977318, math.rad(v402 or 0), 0)
			end
			local v404 = p369 * 0.7
			local v405 = math.sin(v404) * 8
			local v406 = v370.Waist
			if v406 then
				v406.Transform = CFrame.Angles(0, math.rad(v405 or 0), 0)
			end
			local v407 = v370.LeftShoulder
			if v407 then
				v407.Transform = CFrame.Angles(0.06981317007977318, 0, -0.05235987755982989)
			end
			local v408 = v370.RightShoulder
			if v408 then
				v408.Transform = CFrame.Angles(0.06981317007977318, 0, 0.05235987755982989)
			end
		end
		local v409 = p369 * 2
		local v410 = math.sin(v409) * 1.2
		local v411
		if v395 then
			v411 = 0
		else
			local v412 = p369 * 0.7
			v411 = math.sin(v412) * 8
		end
		local v413 = v370.Waist
		if v413 then
			v413.Transform = CFrame.Angles(math.rad(v410 or 0), math.rad(v411 or 0), 0)
		end
	end
end
local function v_u_419(p415) -- name: moodBubble
	-- upvalues: (copy) v_u_41
	local v416 = p415.person:FindFirstChild("Head")
	if v416 then
		local v417 = Instance.new("BillboardGui")
		v417.Name = "CustomerMood"
		v417.Size = UDim2.fromOffset(56, 56)
		v417.StudsOffset = Vector3.new(0, 2.5, 0)
		v417.MaxDistance = 110
		v417.LightInfluence = 0
		v417.Enabled = false
		local v418 = Instance.new("TextLabel")
		v418.Name = "Face"
		v418.BackgroundTransparency = 1
		v418.AnchorPoint = Vector2.new(0.5, 0.5)
		v418.Position = UDim2.fromScale(0.5, 0.5)
		v418.Size = UDim2.fromScale(1, 1)
		v418.Text = ""
		v418.TextScaled = true
		v418.FontFace = v_u_41
		v418.Parent = v417
		v417.Parent = v416
		p415.bubble = v417
		p415.face = v418
	end
end
local function v_u_486(p420) -- name: setup
	-- upvalues: (copy) v_u_42, (copy) v_u_152, (copy) v_u_18, (copy) v_u_10, (copy) v_u_40, (copy) v_u_84, (copy) v_u_7, (copy) v_u_157, (copy) v_u_282, (copy) v_u_419
	if v_u_42[p420] then
		return
	else
		local v421 = p420:WaitForChild("Vehicle", 10)
		local v422 = p420:WaitForChild("Customer", 10)
		local v423 = p420:GetAttribute("ParkFrame")
		local v424 = p420:GetAttribute("WaitSpot")
		if v421 and (v422 and (typeof(v423) == "CFrame" and (typeof(v424) == "CFrame" and not v_u_42[p420]))) then
			local v425 = {}
			local v426 = {}
			for _, v427 in v421:GetDescendants() do
				if not v427:IsA("BasePart") then
					continue
				end
				table.insert(v425, v427)
				local v428 = v427.CFrame
				table.insert(v426, v423:ToObjectSpace(v428))
			end
			local v429 = v421:FindFirstChildWhichIsA("VehicleSeat", true)
			local v430 = v422:Clone()
			local v431 = v430:FindFirstChild("HumanoidRootPart")
			local v432 = v430:FindFirstChildOfClass("Humanoid")
			if v431 and v432 then
				for _, v433 in v430:GetDescendants() do
					if not v433:IsA("Animator") then
						continue
					end
					v433:Destroy()
				end
				v431.Anchored = true
				local v434 = v432.HipHeight + v431.Size.Y / 2
				local v435 = {
					["folder"] = nil,
					["vehicle"] = nil,
					["person"] = nil,
					["root"] = nil,
					["kind"] = nil,
					["parts"] = nil,
					["offsets"] = nil,
					["park"] = nil,
					["waitSpot"] = nil,
					["standUp"] = nil,
					["seatRel"] = nil,
					["joints"] = nil,
					["t"] = 0,
					["folder"] = p420,
					["vehicle"] = v421,
					["person"] = v430,
					["root"] = v431,
					["kind"] = p420:GetAttribute("Kind") or "bike",
					["parts"] = v425,
					["offsets"] = v426,
					["park"] = v423,
					["waitSpot"] = v424,
					["standUp"] = v434
				}
				local v436
				if v429 then
					v436 = v423:ToObjectSpace(v429.CFrame) * CFrame.new(0, v429.Size.Y / 2 + v431.Size.Y / 2 + 0.35, 0)
				else
					v436 = CFrame.new(0, 2.6, 0)
				end
				v435.seatRel = v436
				v435.joints = {}
				local v437, v438, v439 = v_u_152(p420, v423)
				local v_u_440 = v_u_18(p420, v423) * v_u_10:Inverse()
				local v441 = v_u_440:Inverse() * v423.Position
				local v442 = v441.Z
				local v443 = v441.X
				local _, v_u_444 = v_u_40(v_u_440 * Vector3.new(-1172, 0, v442), 120)
				local function v455(p445, p446) -- name: here
					-- upvalues: (copy) v_u_440, (copy) v_u_444, (ref) v_u_40
					local v447 = {}
					for v448, v449 in p445 do
						local v450 = v_u_440 * v449
						local v451 = v450.X
						local v452 = v450.Z
						local v453 = Vector3.new(v451, 0, v452)
						if p446[v448] and v_u_444 then
							local v454 = v_u_40(v453, 200)
							if v454 and (v453 - v454).Magnitude > 0.01 then
								v453 = v454 + (v453 - v454).Unit * v_u_444
							end
						end
						v447[v448] = v453
					end
					return v447
				end
				if v437 then
					v435.arrive = v437
					v435.back = v438
					v435.away = v439
				else
					local v456 = v_u_84
					local v457 = {}
					local v458 = v442 + 75
					local v459 = Vector3.new(-1172, 0, v458)
					local v460 = v442 + 16
					local v461 = Vector3.new(-1172, 0, v460)
					local v462 = v442 + 3
					__set_list(v457, 1, {v459, v461, Vector3.new(-1187, 0, v462), Vector3.new(-1206, 0, v442), (Vector3.new(v443, 0, v442))})
					v435.arrive = v456((v455(v457, { true, true })))
					local v463 = v_u_84
					local v464 = {}
					local v465 = Vector3.new(v443, 0, v442)
					local v466 = Vector3.new(-1213, 0, v442)
					local v467 = v442 + 4
					local v468 = Vector3.new(-1206, 0, v467)
					local v469 = v442 + 10
					__set_list(v464, 1, {v465, v466, v468, (Vector3.new(-1202, 0, v469))})
					v435.back = v463((v455(v464, {})))
					local v470 = v_u_84
					local v471 = {}
					local v472 = v442 + 10
					local v473 = Vector3.new(-1202, 0, v472)
					local v474 = v442 + 2
					local v475 = Vector3.new(-1202, 0, v474)
					local v476 = v442 - 6
					local v477 = Vector3.new(-1190, 0, v476)
					local v478 = v442 - 22
					local v479 = Vector3.new(-1173, 0, v478)
					local v480 = v442 - 110
					__set_list(v471, 1, {v473, v475, v477, v479, (Vector3.new(-1173, 0, v480))})
					v435.away = v470((v455(v471, {
						[4] = true,
						[5] = true
					})))
				end
				v421.Parent = v_u_7
				v430.Name = "Customer"
				v430.Parent = v_u_7
				v435.joints = v_u_157(v430)
				if not (v435.joints.Root and v435.joints.LeftHip) then
					local v481 = v432.BuildRigFromAttachments
					pcall(v481, v432)
					v435.joints = v_u_157(v430)
				end
				if v435.kind == "bike" then
					local v482 = v_u_282
					local v483 = v435.joints
					local v484, v485 = pcall(v482, v421, v423, v483)
					if v484 and v485 then
						v435.rider = v485
						v435.seatRel = v485.seat * CFrame.new(v485.upRootPos)
					elseif not v484 then
						warn("CarWashCustomerClient: rider", v485)
					end
				end
				v_u_419(v435)
				v_u_42[p420] = v435
			else
				v430:Destroy()
			end
		else
			return
		end
	end
end
local function v_u_492(p487, p488) -- name: placeVehicle
	if p487.at ~= p488 then
		p487.at = p488
		local v489 = table.create(#p487.parts)
		for v490, v491 in p487.offsets do
			v489[v490] = p488 * v491
		end
		workspace:BulkMoveTo(p487.parts, v489, Enum.BulkMoveMode.FireCFrameChanged)
	end
end
local function v_u_555(p493, p494) -- name: step
	-- upvalues: (copy) v_u_4, (copy) v_u_99, (copy) v_u_492, (copy) v_u_302, (copy) v_u_414
	local v495 = p493.folder
	local v496 = v495:GetAttribute("Phase")
	local v497 = v495:GetAttribute("PhaseAt") or workspace:GetServerTimeNow()
	local v498 = workspace:GetServerTimeNow() - v497
	p493.t = p493.t + p494
	local v499 = "stand"
	local v500
	if v496 == "arrive" then
		local v501 = v_u_4.ARRIVE_TIME - 2
		if v498 < v501 then
			local v502 = v498 / v501
			local v503 = math.clamp(v502, 0, 1)
			local v504, v505 = v_u_99(p493.arrive, p493.arrive.total * (1 - (1 - v503) * (1 - v503)))
			local v506 = p493.park.LookVector
			local v507 = v506.X
			local v508 = v506.Z
			local v509 = Vector3.new(v507, 0, v508)
			if v503 > 0.98 and v509.Magnitude > 0.1 then
				v505 = v509.Unit
			end
			local v510 = CFrame.lookAt(v504, v504 + v505)
			v_u_492(p493, v510)
			v500 = v_u_302(p493, v510, p494)
			v499 = "ride"
		else
			v_u_492(p493, p493.park)
			local v511 = (v498 - v501) / 1.6
			local v512 = math.clamp(v511, 0, 1)
			local v513 = (p493.park * p493.seatRel).Position
			v500 = p493.waitSpot * CFrame.new(0, p493.standUp, 0)
			local v514 = v513:Lerp(v500.Position, v512 * v512 * (3 - 2 * v512))
			local v515 = v500.Position - v513
			local v516 = v515.X
			local v517 = v515.Z
			local v518 = Vector3.new(v516, 0, v517)
			if v512 < 1 then
				local v519 = CFrame.lookAt
				local v520
				if v518.Magnitude > 0.1 then
					v520 = v518.Unit
				else
					v520 = v500.LookVector
				end
				v500 = v519(v514, v514 + v520)
			end
			if v512 >= 1 then
				v499 = "stand"
			else
				v499 = "walk"
			end
		end
	elseif v496 == "leave" then
		if v498 < 1.4 then
			v_u_492(p493, p493.park)
			local v521 = v498 / 1.4
			local v522 = math.clamp(v521, 0, 1)
			local v523 = p493.waitSpot * CFrame.new(0, p493.standUp, 0)
			local v524 = (p493.park * p493.seatRel).Position
			local v525 = v523.Position:Lerp(v524, v522 * v522 * (3 - 2 * v522))
			local v526 = v524 - v523.Position
			local v527 = v526.X
			local v528 = v526.Z
			local v529 = Vector3.new(v527, 0, v528)
			local v530 = CFrame.lookAt
			local v531
			if v529.Magnitude > 0.1 then
				v531 = v529.Unit
			else
				v531 = v523.LookVector
			end
			v500 = v530(v525, v525 + v531)
			v499 = "walk"
		elseif v498 < 4.4 then
			local v532 = (v498 - 1.4) / 3
			local v533 = math.clamp(v532, 0, 1)
			local v534 = v533 * v533 * (3 - 2 * v533)
			local v535, v536 = v_u_99(p493.back, p493.back.total * v534)
			local v537 = -v536
			local v538 = CFrame.lookAt(v535, v535 + v537)
			v_u_492(p493, v538)
			v500 = v_u_302(p493, v538, p494)
			v499 = "ride"
		else
			local v539 = v498 - 1.4 - 3
			local v540 = v_u_4.LEAVE_TIME - 1.4 - 3
			local v541 = v539 / math.max(v540, 1)
			local v542 = math.clamp(v541, 0, 1)
			local v543, v544 = v_u_99(p493.away, p493.away.total * v542 * v542)
			local v545 = CFrame.lookAt(v543, v543 + v544)
			v_u_492(p493, v545)
			v500 = v_u_302(p493, v545, p494)
			v499 = "ride"
		end
	else
		v_u_492(p493, p493.park)
		v500 = p493.waitSpot * CFrame.new(0, p493.standUp, 0)
	end
	if v500 and p493.root.CFrame ~= v500 then
		p493.root.CFrame = v500
	end
	v_u_414(p493, v499, p493.t)
	if p493.face then
		local v546 = nil
		local v547 = v495:GetAttribute("ParkedAt")
		if v496 == "leave" then
			v546 = v_u_4.MOOD_DONE[v495:GetAttribute("Mood")] or v_u_4.MOOD_DONE.slow
		elseif (v496 == "wait" or v496 == "washing") and typeof(v547) == "number" then
			v546 = v_u_4.mood(workspace:GetServerTimeNow() - v547, p493.kind)
		elseif v496 == "arrive" and v499 ~= "ride" then
			v546 = v_u_4.MOODS[1][2]
		end
		local v548 = p493.bubble
		local v549
		if v546 == nil then
			v549 = false
		else
			v549 = v499 ~= "ride" and true or v496 == "leave"
		end
		v548.Enabled = v549
		if v546 and p493.face.Text ~= v546 then
			p493.face.Text = v546
			p493.popAt = p493.t
		end
		local v550 = 1 - (p493.t - (p493.popAt or -10)) / 0.35
		local v551 = math.max(0, v550)
		p493.face.Size = UDim2.fromScale(v551 * 0.35 + 1, v551 * 0.35 + 1)
		local v552 = p493.bubble
		local v553 = p493.t * 2.2
		local v554 = math.sin(v553) * 0.1 + 2.5
		v552.StudsOffset = Vector3.new(0, v554, 0)
	end
end
v3.Stepped:Connect(function(_, p556)
	-- upvalues: (copy) v_u_42, (copy) v_u_7, (copy) v_u_555
	for v557, v558 in v_u_42 do
		if v557.Parent then
			local v559 = v_u_555
			local v560, v561 = pcall(v559, v558, p556)
			if v560 then
				continue
			end
			warn("CarWashCustomerClient:", v561)
			local v562 = v_u_42[v557]
			if not v562 then
				continue
			end
			v_u_42[v557] = nil
			if v562.person then
				v562.person:Destroy()
			end
			if not v562.vehicle or v562.vehicle.Parent ~= v_u_7 then
				continue
			end
			v562.vehicle:Destroy()
		else
			local v563 = v_u_42[v557]
			if not v563 then
				continue
			end
			v_u_42[v557] = nil
			if v563.person then
				v563.person:Destroy()
			end
			if not v563.vehicle or v563.vehicle.Parent ~= v_u_7 then
				continue
			end
			v563.vehicle:Destroy()
		end
	end
end)
v6.ChildAdded:Connect(function(p564) -- name: watch
	-- upvalues: (copy) v_u_4, (copy) v_u_486
	if p564.Name == v_u_4.CUSTOMER_FOLDER and p564:IsA("Model") then
		task.spawn(v_u_486, p564)
	end
end)
v6.ChildRemoved:Connect(function(p565)
	-- upvalues: (copy) v_u_42, (copy) v_u_7
	if v_u_42[p565] then
		local v566 = v_u_42[p565]
		if not v566 then
			return
		end
		v_u_42[p565] = nil
		if v566.person then
			v566.person:Destroy()
		end
		if v566.vehicle and v566.vehicle.Parent == v_u_7 then
			v566.vehicle:Destroy()
		end
	end
end)
for _, v567 in v6:GetChildren() do
	if v567.Name ~= v_u_4.CUSTOMER_FOLDER or not v567:IsA("Model") then
		continue
	end
	task.spawn(v_u_486, v567)
end