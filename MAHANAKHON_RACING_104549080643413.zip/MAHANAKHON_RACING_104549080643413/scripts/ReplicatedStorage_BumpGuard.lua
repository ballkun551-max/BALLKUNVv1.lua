-- Path: ReplicatedStorage/BumpGuard
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = {
	["MARGIN"] = 1.5,
	["HOLD"] = 0.3,
	["GAIN"] = 150,
	["BACK"] = 6,
	["TURN"] = 2.5,
	["UP"] = 300,
	["SPIN"] = 30
}
local v_u_2 = OverlapParams.new()
v_u_2.FilterType = Enum.RaycastFilterType.Exclude
v_u_2.RespectCanCollide = true
function v_u_1.new(p3, p4, p5) -- name: new
	local v6 = {
		["root"] = nil,
		["ignore"] = nil,
		["at"] = (-1 / 0),
		["held"] = 0,
		["root"] = p3,
		["ignore"] = p5 or { p4 }
	}
	if not p4 then
		v6.offset = CFrame.identity
		v6.size = Vector3.new(4, 6, 4)
		return v6
	end
	local v7, v8 = p4:GetBoundingBox()
	v6.offset = p3.CFrame:ToObjectSpace(v7)
	v6.size = v8
	return v6
end
function v_u_1.touching(p9) -- name: touching
	-- upvalues: (copy) v_u_2, (copy) v_u_1
	local v10 = p9.root
	v_u_2.FilterDescendantsInstances = p9.ignore
	local v11 = workspace:GetPartBoundsInBox(v10.CFrame * p9.offset, p9.size + Vector3.new(1, 1, 1) * (v_u_1.MARGIN * 2), v_u_2)
	local v12 = v10.AssemblyRootPart
	for _, v13 in v11 do
		local v14 = v13.AssemblyRootPart
		if not v14 or (v14 == v12 or v14.Anchored) then
			continue
		end
		return v13
	end
	return nil
end
function v_u_1.reset(p15) -- name: reset
	p15.v = nil
	p15.w = nil
end
function v_u_1.step(p16, p17, p18, p19, p20) -- name: step
	-- upvalues: (copy) v_u_1
	local v21 = p16.root
	if v21.Anchored then
		v_u_1.reset(p16)
		return v21.AssemblyLinearVelocity
	end
	local v22 = v21.AssemblyLinearVelocity
	local v23 = v21.AssemblyAngularVelocity
	local v24 = os.clock()
	p16.hit = v_u_1.touching(p16)
	if p16.hit then
		p16.at = v24
	end
	local v25 = p16.v
	local v26 = p16.w
	local v27
	if v25 and v24 - p16.at < v_u_1.HOLD then
		local v28 = math.clamp(p17, 0.004166666666666667, 0.1)
		local v29 = p18 or 0
		local v30 = v_u_1.GAIN * v28
		local v31 = v22.X
		local v32 = v22.Z
		local v33 = Vector3.new(v31, 0, v32)
		local v34
		if typeof(p20) == "Vector3" then
			local v35 = p20.X
			local v36 = p20.Z
			v34 = Vector3.new(v35, 0, v36)
		else
			local v37 = v25.X
			local v38 = v25.Z
			v34 = Vector3.new(v37, 0, v38)
		end
		local v39 = v34.Magnitude
		local v40 = math.max(v39, v29) + v30
		if v39 > 1 then
			local v41 = v34 / v39
			local v42 = v33:Dot(v41)
			local v43 = v33 - v41 * v42
			local v44 = v_u_1.BACK
			local v45 = -math.max(v44, v29)
			local v46 = math.clamp(v42, v45, v40)
			local v47 = v39 * v_u_1.TURN * v28 + v30 + v29
			if v47 < v43.Magnitude then
				v43 = v43.Unit * v47
			end
			v33 = v41 * v46 + v43
		end
		if v40 < v33.Magnitude then
			v33 = v33.Unit * v40
		end
		local v48 = v22.Y
		local v49 = v25.Y
		local v50 = math.max(v49, p19 or 0) + v_u_1.UP * v28
		local v51 = math.min(v48, v50)
		local v52 = v33.X
		local v53 = v33.Z
		v27 = Vector3.new(v52, v51, v53)
		if (v27 - v22).Magnitude > 0.5 then
			v21.AssemblyLinearVelocity = v27
			p16.held = p16.held + 1
		else
			v27 = v22
		end
		local v54 = v23 - v26
		local v55 = v_u_1.SPIN * v28
		if v55 < v54.Magnitude then
			v23 = v26 + v54.Unit * v55
			v21.AssemblyAngularVelocity = v23
		end
	else
		v27 = v22
	end
	p16.v = v27
	p16.w = v23
	return v27
end
return v_u_1