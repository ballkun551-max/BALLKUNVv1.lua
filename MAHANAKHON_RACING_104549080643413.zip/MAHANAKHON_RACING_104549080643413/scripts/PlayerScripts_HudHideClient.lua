-- Path: Players/ygggggg55551/PlayerScripts/HudHideClient
-- Class: LocalScript  true/Enum.RunContext.Legacy
-- Decompiled by BALL KUN Universal Map Dump

local v1 = game:GetService("Players")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("TweenService")
local v4 = require(v2:WaitForChild("UiOwn")).Instance
local v5 = v2:WaitForChild("GameUI")
local v6 = require(v5:WaitForChild("Theme"))
local v_u_7 = require(v5:WaitForChild("HudHide"))
local v_u_8 = require(v2:WaitForChild("DashcamShared"))
if not v6.isTouch() then
	return
end
local v_u_9 = v1.LocalPlayer
local v_u_10 = TweenInfo.new(0.6, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
local v11 = Color3.fromRGB(16, 18, 24)
local v12 = v6.screen("HudToggle", 50, v_u_9:WaitForChild("PlayerGui"))
local v_u_13 = v4.new("TextButton")
v_u_13.Name = "HideUI"
v_u_13.AnchorPoint = Vector2.new(1, 0)
v_u_13.Position = UDim2.new(1, -12, 0, 110)
v_u_13.Size = UDim2.fromOffset(92, 32)
v_u_13.BackgroundColor3 = v11
v_u_13.BackgroundTransparency = 0.25
v_u_13.AutoButtonColor = true
v_u_13.Text = "Hide UI"
v_u_13.FontFace = v6.FONT_BOLD
v_u_13.TextSize = 14
v_u_13.TextColor3 = Color3.new(1, 1, 1)
v_u_13.Visible = false
v_u_13.Parent = v12
v4.new("UICorner", v_u_13).CornerRadius = UDim.new(0, 16)
local v_u_14 = v4.new("UIStroke")
v_u_14.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
v_u_14.Color = Color3.new(1, 1, 1)
v_u_14.Transparency = 0.75
v_u_14.Parent = v_u_13
local v_u_15 = v6.text({
	["Name"] = "Hint",
	["Text"] = "\224\185\129\224\184\149\224\184\176\224\184\149\224\184\163\224\184\135\224\184\153\224\184\181\224\185\137\224\184\173\224\184\181\224\184\129\224\184\132\224\184\163\224\184\177\224\185\137\224\184\135\224\185\128\224\184\158\224\184\183\224\185\136\224\184\173\224\185\129\224\184\170\224\184\148\224\184\135 UI",
	["TextSize"] = 13,
	["FontFace"] = nil,
	["TextColor3"] = nil,
	["TextXAlignment"] = nil,
	["AnchorPoint"] = nil,
	["Position"] = nil,
	["Size"] = nil,
	["TextStrokeTransparency"] = 0.4,
	["Visible"] = false,
	["Parent"] = nil,
	["FontFace"] = v6.FONT_BOLD,
	["TextColor3"] = Color3.new(1, 1, 1),
	["TextXAlignment"] = Enum.TextXAlignment.Right,
	["AnchorPoint"] = Vector2.new(1, 0.5),
	["Position"] = UDim2.new(0, -8, 0.5, 0),
	["Size"] = UDim2.fromOffset(220, 24),
	["Parent"] = v_u_13
})
local v_u_16 = 0
local function v_u_18(p17) -- name: look
	-- upvalues: (copy) v_u_3, (copy) v_u_13, (copy) v_u_10, (copy) v_u_14
	v_u_3:Create(v_u_13, v_u_10, {
		["BackgroundTransparency"] = p17 and 0.25 or 0.85,
		["TextTransparency"] = p17 and 0 or 0.6
	}):Play()
	v_u_3:Create(v_u_14, v_u_10, {
		["Transparency"] = p17 and 0.75 or 0.92
	}):Play()
end
local function v21(p19) -- name: refresh
	-- upvalues: (copy) v_u_13, (copy) v_u_18, (copy) v_u_15, (ref) v_u_16, (copy) v_u_7, (copy) v_u_3, (copy) v_u_10
	v_u_13.Text = p19 and "Show UI" or "Hide UI"
	v_u_18(true)
	if p19 then
		v_u_15.Visible = true
		v_u_15.TextTransparency = 0
		local v_u_20 = os.clock()
		v_u_16 = v_u_20
		task.delay(2.5, function()
			-- upvalues: (ref) v_u_16, (copy) v_u_20, (ref) v_u_7, (ref) v_u_18, (ref) v_u_3, (ref) v_u_15, (ref) v_u_10
			if v_u_16 == v_u_20 and v_u_7.isHidden() then
				v_u_18(false)
				v_u_3:Create(v_u_15, v_u_10, {
					["TextTransparency"] = 1,
					["TextStrokeTransparency"] = 1
				}):Play()
			end
		end)
	else
		v_u_16 = 0
		v_u_15.Visible = false
		v_u_15.TextStrokeTransparency = 0.4
	end
end
v_u_13.Activated:Connect(function()
	-- upvalues: (copy) v_u_7
	v_u_7.toggle()
end)
v_u_7.changed.Event:Connect(v21)
v21(v_u_7.isHidden())
local function v25() -- name: inCameraVehicle
	-- upvalues: (copy) v_u_9, (copy) v_u_8
	local v22 = v_u_9.Character
	if v22 then
		v22 = v_u_9.Character:FindFirstChildOfClass("Humanoid")
	end
	if v22 then
		v22 = v22.SeatPart
	end
	local v23 = workspace:FindFirstChild("SpawnedVehicles")
	if v22 then
		v22 = v22.Parent
	end
	while v22 and v22 ~= workspace do
		if v22.Parent == v23 then
			local v24 = v_u_8.PARTS_ATTR
			return type(v22:GetAttribute(v24)) == "string"
		end
		v22 = v22.Parent
	end
	return false
end
while true do
	task.wait(0.3)
	local v26 = v25()
	if not v26 and v_u_7.isHidden() then
		v_u_7.toggle()
	end
	if v_u_13.Visible == v26 then
		continue
	end
	v_u_13.Visible = v26
end