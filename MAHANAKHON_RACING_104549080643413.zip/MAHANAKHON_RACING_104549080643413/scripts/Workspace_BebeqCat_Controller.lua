-- Path: Workspace/BebeqCat/Controller
-- Class: Script  true/Enum.RunContext.Client
-- Decompiled by BALL KUN Universal Map Dump

local v1 = game:GetService("RunService")
local v_u_2 = game:GetService("Players")
local v3 = script.Parent
local v_u_4 = v3:WaitForChild("RootPart")
local v_u_5 = require(v3:WaitForChild("Config"))
for _, v6 in ipairs(v3:GetDescendants()) do
	if not v6:IsA("BasePart") then
		continue
	end
	v6.CanCollide = false
	v6.CanTouch = false
	v6.CanQuery = false
end
local v_u_7 = v_u_4.CFrame
local v_u_8 = {
	["kld1"] = v_u_4:FindFirstChild("Bone.019", true),
	["kld2"] = v_u_4:FindFirstChild("Bone.020", true),
	["kld3"] = v_u_4:FindFirstChild("Bone.021", true),
	["kldT"] = v_u_4:FindFirstChild("Bone.022", true),
	["klb1"] = v_u_4:FindFirstChild("Bone.023", true),
	["klb2"] = v_u_4:FindFirstChild("Bone.024", true),
	["klb3"] = v_u_4:FindFirstChild("Bone.025", true),
	["klbT"] = v_u_4:FindFirstChild("Bone.026", true),
	["kkd1"] = v_u_4:FindFirstChild("Bone.015", true),
	["kkd2"] = v_u_4:FindFirstChild("Bone.016", true),
	["kkd3"] = v_u_4:FindFirstChild("Bone.017", true),
	["kkdT"] = v_u_4:FindFirstChild("Bone.018", true),
	["kkb1"] = v_u_4:FindFirstChild("Bone.011", true),
	["kkb2"] = v_u_4:FindFirstChild("Bone.012", true),
	["kkb3"] = v_u_4:FindFirstChild("Bone.013", true),
	["kkbT"] = v_u_4:FindFirstChild("Bone.014", true),
	["ekor1"] = v_u_4:FindFirstChild("Bone.005", true),
	["ekor2"] = v_u_4:FindFirstChild("Bone.006", true),
	["ekor3"] = v_u_4:FindFirstChild("Bone.007", true),
	["ekor4"] = v_u_4:FindFirstChild("Bone.008", true),
	["ekor5"] = v_u_4:FindFirstChild("Bone.009", true),
	["ekor6"] = v_u_4:FindFirstChild("Bone.010", true),
	["leher"] = v_u_4:FindFirstChild("Bone.003", true),
	["kepala"] = v_u_4:FindFirstChild("Bone.004", true)
}
local v_u_9 = {}
for _, v10 in pairs(v_u_8) do
	if not v10 then
		continue
	end
	v_u_9[v10] = v10.Transform
end
local function v_u_51(p11, p12) -- name: animLegs
	-- upvalues: (copy) v_u_8, (copy) v_u_9
	local v13 = 0.3 * p12
	local v14 = 0.2 * p12
	local v15 = 0.1 * p12
	local v16 = 0.05 * p12
	local v17 = math.sin(p11)
	local v18 = -math.sin(p11)
	local v19 = v_u_8.kld1
	local v20 = v17 * v13
	if v19 then
		v19.Transform = (v_u_9[v19] or CFrame.new()) * CFrame.Angles(v20 or 0, 0, 0)
	end
	local v21 = v_u_8.kld2
	local v22 = math.max(0, v17) * v14
	if v21 then
		v21.Transform = (v_u_9[v21] or CFrame.new()) * CFrame.Angles(v22 or 0, 0, 0)
	end
	local v23 = v_u_8.kld3
	local v24 = math.max(0, v17) * v15
	if v23 then
		v23.Transform = (v_u_9[v23] or CFrame.new()) * CFrame.Angles(v24 or 0, 0, 0)
	end
	local v25 = v_u_8.kldT
	local v26 = math.max(0, v17) * v16
	if v25 then
		v25.Transform = (v_u_9[v25] or CFrame.new()) * CFrame.Angles(v26 or 0, 0, 0)
	end
	local v27 = v_u_8.kkb1
	local v28 = -v17 * v13
	if v27 then
		v27.Transform = (v_u_9[v27] or CFrame.new()) * CFrame.Angles(0, 0, v28 or 0)
	end
	local v29 = v_u_8.kkb2
	local v30 = -math.max(0, v17) * v14
	if v29 then
		v29.Transform = (v_u_9[v29] or CFrame.new()) * CFrame.Angles(0, 0, v30 or 0)
	end
	local v31 = v_u_8.kkb3
	local v32 = -math.max(0, v17) * v15
	if v31 then
		v31.Transform = (v_u_9[v31] or CFrame.new()) * CFrame.Angles(0, 0, v32 or 0)
	end
	local v33 = v_u_8.kkbT
	local v34 = -math.max(0, v17) * v16
	if v33 then
		v33.Transform = (v_u_9[v33] or CFrame.new()) * CFrame.Angles(0, 0, v34 or 0)
	end
	local v35 = v_u_8.kkd1
	local v36 = -v18 * v13
	if v35 then
		v35.Transform = (v_u_9[v35] or CFrame.new()) * CFrame.Angles(0, 0, v36 or 0)
	end
	local v37 = v_u_8.kkd2
	local v38 = -math.max(0, v18) * v14
	if v37 then
		v37.Transform = (v_u_9[v37] or CFrame.new()) * CFrame.Angles(0, 0, v38 or 0)
	end
	local v39 = v_u_8.kkd3
	local v40 = -math.max(0, v18) * v15
	if v39 then
		v39.Transform = (v_u_9[v39] or CFrame.new()) * CFrame.Angles(0, 0, v40 or 0)
	end
	local v41 = v_u_8.kkdT
	local v42 = -math.max(0, v18) * v16
	if v41 then
		v41.Transform = (v_u_9[v41] or CFrame.new()) * CFrame.Angles(0, 0, v42 or 0)
	end
	local v43 = v_u_8.klb1
	local v44 = v18 * v13
	if v43 then
		v43.Transform = (v_u_9[v43] or CFrame.new()) * CFrame.Angles(v44 or 0, 0, 0)
	end
	local v45 = v_u_8.klb2
	local v46 = math.max(0, v18) * v14
	if v45 then
		v45.Transform = (v_u_9[v45] or CFrame.new()) * CFrame.Angles(v46 or 0, 0, 0)
	end
	local v47 = v_u_8.klb3
	local v48 = math.max(0, v18) * v15
	if v47 then
		v47.Transform = (v_u_9[v47] or CFrame.new()) * CFrame.Angles(v48 or 0, 0, 0)
	end
	local v49 = v_u_8.klbT
	local v50 = math.max(0, v18) * v16
	if v49 then
		v49.Transform = (v_u_9[v49] or CFrame.new()) * CFrame.Angles(v50 or 0, 0, 0)
	end
end
local function v_u_95(p52) -- name: animIdle
	-- upvalues: (copy) v_u_8, (copy) v_u_9
	local v53 = v_u_8.kld1
	if v53 then
		v53.Transform = (v_u_9[v53] or CFrame.new()) * CFrame.Angles(0, 0, 0)
	end
	local v54 = v_u_8.kld2
	if v54 then
		v54.Transform = (v_u_9[v54] or CFrame.new()) * CFrame.Angles(0, 0, 0)
	end
	local v55 = v_u_8.kld3
	if v55 then
		v55.Transform = (v_u_9[v55] or CFrame.new()) * CFrame.Angles(0, 0, 0)
	end
	local v56 = v_u_8.kldT
	if v56 then
		v56.Transform = (v_u_9[v56] or CFrame.new()) * CFrame.Angles(0, 0, 0)
	end
	local v57 = v_u_8.kkb1
	if v57 then
		v57.Transform = (v_u_9[v57] or CFrame.new()) * CFrame.Angles(0, 0, 0)
	end
	local v58 = v_u_8.kkb2
	if v58 then
		v58.Transform = (v_u_9[v58] or CFrame.new()) * CFrame.Angles(0, 0, 0)
	end
	local v59 = v_u_8.kkb3
	if v59 then
		v59.Transform = (v_u_9[v59] or CFrame.new()) * CFrame.Angles(0, 0, 0)
	end
	local v60 = v_u_8.kkbT
	if v60 then
		v60.Transform = (v_u_9[v60] or CFrame.new()) * CFrame.Angles(0, 0, 0)
	end
	local v61 = v_u_8.kkd1
	if v61 then
		v61.Transform = (v_u_9[v61] or CFrame.new()) * CFrame.Angles(0, 0, 0)
	end
	local v62 = v_u_8.kkd2
	if v62 then
		v62.Transform = (v_u_9[v62] or CFrame.new()) * CFrame.Angles(0, 0, 0)
	end
	local v63 = v_u_8.kkd3
	if v63 then
		v63.Transform = (v_u_9[v63] or CFrame.new()) * CFrame.Angles(0, 0, 0)
	end
	local v64 = v_u_8.kkdT
	if v64 then
		v64.Transform = (v_u_9[v64] or CFrame.new()) * CFrame.Angles(0, 0, 0)
	end
	local v65 = v_u_8.klb1
	if v65 then
		v65.Transform = (v_u_9[v65] or CFrame.new()) * CFrame.Angles(0, 0, 0)
	end
	local v66 = v_u_8.klb2
	if v66 then
		v66.Transform = (v_u_9[v66] or CFrame.new()) * CFrame.Angles(0, 0, 0)
	end
	local v67 = v_u_8.klb3
	if v67 then
		v67.Transform = (v_u_9[v67] or CFrame.new()) * CFrame.Angles(0, 0, 0)
	end
	local v68 = v_u_8.klbT
	if v68 then
		v68.Transform = (v_u_9[v68] or CFrame.new()) * CFrame.Angles(0, 0, 0)
	end
	local v69 = v_u_8.leher
	local v70 = p52 * 1.5
	local v71 = math.sin(v70) * 0.06
	if v69 then
		v69.Transform = (v_u_9[v69] or CFrame.new()) * CFrame.Angles(v71 or 0, 0, 0)
	end
	local v72 = v_u_8.kepala
	local v73 = p52 * 1
	local v74 = math.sin(v73) * 0.08
	local v75 = p52 * 0.5
	local v76 = math.sin(v75) * 0.12
	if v72 then
		v72.Transform = (v_u_9[v72] or CFrame.new()) * CFrame.Angles(v74 or 0, v76 or 0, 0)
	end
	local v77 = v_u_8.ekor1
	local v78 = p52 * 3
	local v79 = math.sin(v78) * 0.35
	if v77 then
		v77.Transform = (v_u_9[v77] or CFrame.new()) * CFrame.Angles(0, v79 or 0, 0)
	end
	local v80 = v_u_8.ekor2
	local v81 = p52 * 3 + 0.5
	local v82 = math.sin(v81) * 0.4
	if v80 then
		v80.Transform = (v_u_9[v80] or CFrame.new()) * CFrame.Angles(0, v82 or 0, 0)
	end
	local v83 = v_u_8.ekor3
	local v84 = p52 * 3 + 1
	local v85 = math.sin(v84) * 0.45
	if v83 then
		v83.Transform = (v_u_9[v83] or CFrame.new()) * CFrame.Angles(0, v85 or 0, 0)
	end
	local v86 = v_u_8.ekor4
	local v87 = p52 * 3 + 1.5
	local v88 = math.sin(v87) * 0.5
	if v86 then
		v86.Transform = (v_u_9[v86] or CFrame.new()) * CFrame.Angles(0, v88 or 0, 0)
	end
	local v89 = v_u_8.ekor5
	local v90 = p52 * 3 + 2
	local v91 = math.sin(v90) * 0.4
	if v89 then
		v89.Transform = (v_u_9[v89] or CFrame.new()) * CFrame.Angles(0, v91 or 0, 0)
	end
	local v92 = v_u_8.ekor6
	local v93 = p52 * 3 + 2.5
	local v94 = math.sin(v93) * 0.35
	if v92 then
		v92.Transform = (v_u_9[v92] or CFrame.new()) * CFrame.Angles(0, v94 or 0, 0)
	end
end
local function v_u_122(p96, p97) -- name: animBodyWalk
	-- upvalues: (copy) v_u_8, (copy) v_u_9
	local v98 = v_u_8.leher
	local v99 = p96 * 1.4
	local v100 = math.sin(v99) * 0.03
	if v98 then
		v98.Transform = (v_u_9[v98] or CFrame.new()) * CFrame.Angles(v100 or 0, 0, 0)
	end
	local v101 = v_u_8.kepala
	local v102 = p97 * 2
	local v103 = math.sin(v102) * 0.04
	if v101 then
		v101.Transform = (v_u_9[v101] or CFrame.new()) * CFrame.Angles(v103 or 0, 0, 0)
	end
	local v104 = v_u_8.ekor1
	local v105 = p96 * 5
	local v106 = math.sin(v105) * 0.4
	if v104 then
		v104.Transform = (v_u_9[v104] or CFrame.new()) * CFrame.Angles(0, v106 or 0, 0)
	end
	local v107 = v_u_8.ekor2
	local v108 = p96 * 5 + 0.5
	local v109 = math.sin(v108) * 0.5
	if v107 then
		v107.Transform = (v_u_9[v107] or CFrame.new()) * CFrame.Angles(0, v109 or 0, 0)
	end
	local v110 = v_u_8.ekor3
	local v111 = p96 * 5 + 1
	local v112 = math.sin(v111) * 0.55
	if v110 then
		v110.Transform = (v_u_9[v110] or CFrame.new()) * CFrame.Angles(0, v112 or 0, 0)
	end
	local v113 = v_u_8.ekor4
	local v114 = p96 * 5 + 1.5
	local v115 = math.sin(v114) * 0.6000000000000001
	if v113 then
		v113.Transform = (v_u_9[v113] or CFrame.new()) * CFrame.Angles(0, v115 or 0, 0)
	end
	local v116 = v_u_8.ekor5
	local v117 = p96 * 5 + 2
	local v118 = math.sin(v117) * 0.5
	if v116 then
		v116.Transform = (v_u_9[v116] or CFrame.new()) * CFrame.Angles(0, v118 or 0, 0)
	end
	local v119 = v_u_8.ekor6
	local v120 = p96 * 5 + 2.5
	local v121 = math.sin(v120) * 0.4
	if v119 then
		v119.Transform = (v_u_9[v119] or CFrame.new()) * CFrame.Angles(0, v121 or 0, 0)
	end
end
local function v_u_129(p123, p124) -- name: faceToward
	local v125 = p124.X - p123.X
	local v126 = p124.Z - p123.Z
	local v127 = Vector3.new(v125, 0, v126)
	if v127.Magnitude < 0.01 then
		return CFrame.new(p123)
	end
	local v128 = CFrame.Angles(0, -1.1344640137963142, 0):VectorToWorldSpace(v127.Unit)
	return CFrame.lookAt(p123, p123 + v128, Vector3.new(0, 1, 0))
end
local function v_u_135(p130) -- name: getNearestPlayer
	-- upvalues: (copy) v_u_2, (copy) v_u_4
	local v131 = nil
	for _, v132 in ipairs(v_u_2:GetPlayers()) do
		local v133 = v132.Character
		if v133 then
			v133 = v133:FindFirstChild("HumanoidRootPart")
		end
		if not v133 then
			continue
		end
		local v134 = (v133.Position - v_u_4.Position).Magnitude
		if v134 >= p130 then
			continue
		end
		v131 = v132
		p130 = v134
	end
	return v131, p130
end
local v_u_136 = v_u_4.CFrame
local v_u_137 = v_u_4.Position.Y
local v_u_138 = RaycastParams.new()
v_u_138.FilterType = Enum.RaycastFilterType.Exclude
v_u_138.FilterDescendantsInstances = { v3 }
local function v_u_169(p139, p140, p141) -- name: moveCat
	-- upvalues: (copy) v_u_4, (copy) v_u_5, (copy) v_u_138, (ref) v_u_137, (copy) v_u_129, (ref) v_u_136
	local v142 = v_u_4.Position
	local v143 = p139.X
	local v144 = v142.Y
	local v145 = p139.Z
	local v146 = Vector3.new(v143, v144, v145) - v142
	local v147 = v146.Magnitude
	if v147 < 0.05 then
		return v147
	end
	local v148 = v147 / v_u_5.IDLE_DIST
	local v149 = p140 * math.clamp(v148, 0.15, 1) * p141
	local v150 = math.min(v149, v147)
	local v151 = v142 + v146.Unit * v150
	local v152 = v151.X
	local v153 = v151.Y + 5
	local v154 = v151.Z
	local v155 = Vector3.new(v152, v153, v154)
	local v156 = workspace:Raycast(v155, Vector3.new(0, -15, 0), v_u_138)
	local v157
	if v156 then
		v157 = v156.Position.Y + v_u_5.CAT_HALF_HEIGHT
	else
		v157 = v151.Y
	end
	local v158 = v_u_137
	local v159 = v157 - v_u_137
	local v160 = v_u_5.Y_LERP_SPEED * p141
	v_u_137 = v158 + v159 * math.min(v160, 1)
	local v161 = v151.X
	local v162 = v_u_137
	local v163 = v151.Z
	local v164 = Vector3.new(v161, v162, v163)
	local v165 = v_u_129
	local v166 = p139.X
	local v167 = v_u_137
	local v168 = p139.Z
	v_u_136 = v_u_136:Lerp(v165(v164, (Vector3.new(v166, v167, v168))), 0.15)
	v_u_4.CFrame = v_u_136
	return v147
end
local v_u_170 = "idle"
local v_u_171 = nil
local v_u_172 = 0
local v_u_173 = 0
v1.Heartbeat:Connect(function(p174)
	-- upvalues: (ref) v_u_172, (ref) v_u_170, (copy) v_u_135, (copy) v_u_5, (ref) v_u_171, (copy) v_u_4, (copy) v_u_169, (ref) v_u_173, (copy) v_u_51, (copy) v_u_122, (copy) v_u_129, (copy) v_u_95, (copy) v_u_7
	v_u_172 = v_u_172 + p174
	if v_u_170 == "idle" then
		local v175, _ = v_u_135(v_u_5.DETECT_RADIUS)
		if v175 then
			v_u_170 = "follow"
			v_u_171 = v175
		end
	elseif v_u_170 == "follow" or v_u_170 == "near" then
		local v176 = v_u_171
		if v176 then
			v176 = v_u_171.Character
		end
		if v176 then
			v176 = v176:FindFirstChild("HumanoidRootPart")
		end
		if v176 then
			local v177 = (v176.Position - v_u_4.Position).Magnitude
			if v_u_5.LOSE_RADIUS < v177 then
				v_u_170 = "returning"
				v_u_171 = nil
			elseif v_u_170 == "follow" and v177 <= v_u_5.IDLE_DIST then
				v_u_170 = "near"
			elseif v_u_170 == "near" and v_u_5.RESUME_DIST < v177 then
				v_u_170 = "follow"
			end
		else
			v_u_170 = "returning"
			v_u_171 = nil
		end
	end
	if v_u_170 == "follow" then
		local v178 = v_u_171
		if v178 then
			v178 = v_u_171.Character
		end
		if v178 then
			v178 = v178:FindFirstChild("HumanoidRootPart")
		end
		if v178 then
			local v179 = v_u_169(v178.Position, v_u_5.MOVE_SPEED, p174)
			local v180 = v_u_173
			local v181 = p174 * 6
			local v182 = v179 / v_u_5.IDLE_DIST
			v_u_173 = v180 + v181 * math.min(v182, 2)
			v_u_51(v_u_173, 1)
			v_u_122(v_u_172, v_u_173)
			return
		end
	else
		if v_u_170 == "near" then
			local v183 = v_u_171
			if v183 then
				v183 = v_u_171.Character
			end
			if v183 then
				v183 = v183:FindFirstChild("HumanoidRootPart")
			end
			if v183 then
				local v184 = v_u_129(v_u_4.Position, v183.Position)
				v_u_4.CFrame = v_u_4.CFrame:Lerp(v184, 0.08)
			end
			v_u_95(v_u_172)
			return
		end
		if v_u_170 == "returning" then
			local v185, _ = v_u_135(v_u_5.DETECT_RADIUS)
			if v185 then
				v_u_170 = "follow"
				v_u_171 = v185
				return
			end
			local v186 = v_u_169(v_u_7.Position, v_u_5.RETURN_SPEED, p174)
			if v186 > 0.5 then
				v_u_173 = v_u_173 + p174 * 5
				v_u_51(v_u_173, 0.85)
				v_u_122(v_u_172, v_u_173)
			else
				v_u_4.CFrame = v_u_4.CFrame:Lerp(v_u_7, 0.05)
				v_u_95(v_u_172)
			end
			if v186 < 0.15 then
				v_u_170 = "idle"
				return
			end
		else
			v_u_95(v_u_172)
		end
	end
end)
print("\226\156\133 [BebeqCat] Controller active.")