-- Path: Players/ygggggg55551/PlayerScripts/PCX160Client/Hud
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = game:GetService("Players")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = require(v2:WaitForChild("GameUI"):WaitForChild("Dash"))
local v_u_4 = require(v2:WaitForChild("GearShared"))
local v_u_5 = require(v2:WaitForChild("TuckKeyShared"))
local v6 = {}
local v_u_7 = nil
local v_u_8 = nil
local function v_u_11(p9, ...) -- name: call
	-- upvalues: (ref) v_u_7
	local v10 = v_u_7
	if v10 then
		v10 = v_u_7[p9]
	end
	if v10 then
		v10(...)
	end
end
local function v_u_18(p_u_12, ...) -- name: tap
	-- upvalues: (copy) v_u_11
	local v_u_13 = table.pack(...)
	return function()
		-- upvalues: (ref) v_u_11, (copy) p_u_12, (copy) v_u_13
		local v14 = v_u_11
		local v15 = p_u_12
		local v16 = v_u_13
		local v17 = v_u_13.n
		v14(v15, table.unpack(v16, 1, v17))
	end
end
local v_u_19 = {
	{ "R", "Start" },
	{ "Z / C", "Signals" },
	{ "X", "Hazards" },
	{ "K", "Stand" },
	{ "V", "Camera" },
	{ "Ctrl", "Wheelie" },
	{ "Shift", "Brake" },
	{ "S", "Reverse" },
	{ "G", "Tuck" },
	{ "M", "Mirrors" },
	{ "T", "Custom tail light" },
	{ "L", "RGB lights" },
	{ "P", "Tune" },
	{ "H", "Horn" },
	{ "U", "360 camera" },
	{ "Space", "Get off" }
}
local v_u_20 = {
	["Z / C"] = true,
	["X"] = true,
	["T"] = true,
	["L"] = true
}
local v_u_21 = {
	["left"] = true,
	["hazard"] = true,
	["right"] = true,
	["tail"] = true,
	["rainbow"] = true
}
local function v_u_29(p22) -- name: legendFor
	-- upvalues: (copy) v_u_19, (copy) v_u_5, (copy) v_u_1, (copy) v_u_4, (copy) v_u_20
	local v23 = table.clone(v_u_19)
	for v24, v25 in v23 do
		if v25[2] ~= "Tuck" then
			continue
		end
		v23[v24] = { v_u_5.label(v_u_5.keyOf(v_u_1.LocalPlayer)), "Tuck" }
	end
	local v26 = v_u_4.gears(p22)
	if v26 then
		local v27 = { "E / Q", ("Gear up / down (%d-speed)"):format(v26) }
		table.insert(v23, 2, v27)
	end
	if p22:GetAttribute("NoLights") == true then
		v23 = {}
		for _, v28 in v23 do
			if v_u_20[v28[1]] then
				continue
			end
			table.insert(v23, v28)
		end
	end
	return v23
end
v_u_1.LocalPlayer:GetAttributeChangedSignal("TuckKey"):Connect(function()
	-- upvalues: (ref) v_u_8, (copy) v_u_3, (copy) v_u_29
	if v_u_8 and v_u_3.isShown() then
		v_u_3.setLegend((v_u_29(v_u_8)))
	end
end)
function v6.start(p30, p31, p32) -- name: start
	-- upvalues: (ref) v_u_7, (ref) v_u_8, (copy) v_u_3, (copy) v_u_4, (copy) v_u_29, (copy) v_u_18, (copy) v_u_21
	v_u_7 = p30
	if p31 and p32 ~= false then
		v_u_8 = p31
		local v33 = v_u_4.gears(p31)
		local v34 = v_u_29(p31)
		local v35 = {
			{
				["id"] = "wheelie",
				["label"] = "Wheelie",
				["slot"] = "left",
				["hold"] = true,
				["press"] = nil,
				["release"] = nil,
				["press"] = v_u_18("onWheelie", true),
				["release"] = v_u_18("onWheelie", false)
			},
			{
				["id"] = "view",
				["label"] = "Camera",
				["slot"] = "left",
				["press"] = nil,
				["press"] = v_u_18("onView")
			},
			{
				["id"] = "horn",
				["label"] = "Horn",
				["slot"] = "center",
				["hold"] = true,
				["press"] = nil,
				["release"] = nil,
				["press"] = v_u_18("onHorn", true),
				["release"] = v_u_18("onHorn", false)
			},
			{
				["id"] = "left",
				["label"] = "\226\151\128",
				["slot"] = "center",
				["press"] = nil,
				["press"] = v_u_18("onIndicator", "Left")
			},
			{
				["id"] = "hazard",
				["label"] = "\226\154\160",
				["slot"] = "center",
				["press"] = nil,
				["press"] = v_u_18("onIndicator", "Hazard")
			},
			{
				["id"] = "right",
				["label"] = "\226\150\182",
				["slot"] = "center",
				["press"] = nil,
				["press"] = v_u_18("onIndicator", "Right")
			},
			{
				["id"] = "engine",
				["label"] = "Engine",
				["slot"] = "center",
				["press"] = nil,
				["press"] = v_u_18("onEngine")
			},
			{
				["id"] = "stand",
				["label"] = "P",
				["slot"] = "center",
				["press"] = nil,
				["press"] = v_u_18("onStand")
			},
			{
				["id"] = "tuck",
				["label"] = "Tuck",
				["primary"] = true,
				["press"] = nil,
				["press"] = v_u_18("onTuck")
			},
			{
				["id"] = "mirrors",
				["label"] = "Mirrors",
				["press"] = nil,
				["press"] = v_u_18("onMirrors")
			},
			{
				["id"] = "cam360",
				["label"] = "360",
				["press"] = nil,
				["press"] = v_u_18("onCam360")
			},
			{
				["id"] = "tail",
				["label"] = "Tail light",
				["press"] = nil,
				["press"] = v_u_18("onTailLight")
			},
			{
				["id"] = "paint",
				["label"] = "Tune",
				["press"] = nil,
				["press"] = v_u_18("onPaint")
			},
			{
				["id"] = "rainbow",
				["label"] = "RGB lights",
				["press"] = nil,
				["press"] = v_u_18("onRainbow")
			}
		}
		if p31:GetAttribute("NoLights") == true then
			v35 = {}
			for _, v36 in v35 do
				if v_u_21[v36.id] then
					continue
				end
				table.insert(v35, v36)
			end
		end
		if v33 then
			local v37 = {
				["id"] = "gearDown",
				["label"] = "Gear -",
				["press"] = nil,
				["press"] = v_u_18("onGearDown")
			}
			table.insert(v35, v37)
			local v38 = {
				["id"] = "gearUp",
				["label"] = "Gear +",
				["press"] = nil,
				["press"] = v_u_18("onGearUp")
			}
			table.insert(v35, v38)
		end
		v_u_3.show(p31, {
			["blinkFromChange"] = true,
			["gear"] = nil,
			["legend"] = nil,
			["controls"] = nil,
			["gear"] = v33 ~= nil,
			["legend"] = v34,
			["controls"] = v35
		})
	else
		v_u_8 = nil
		v_u_3.hide()
	end
end
function v6.stop() -- name: stop
	-- upvalues: (ref) v_u_7, (ref) v_u_8, (copy) v_u_3
	v_u_7 = nil
	v_u_8 = nil
	v_u_3.hide()
end
function v6.update(p39) -- name: update
	-- upvalues: (copy) v_u_3
	if v_u_3.isShown() then
		v_u_3.update({
			["kmh"] = p39.kmh,
			["rpm"] = not p39.engine and 0 or p39.rpm / 9000,
			["gear"] = p39.gear,
			["engine"] = p39.engine == true,
			["stand"] = p39.stand ~= "Up",
			["indicator"] = p39.indicator
		})
		v_u_3.setActive("engine", p39.engine == true)
		v_u_3.setActive("left", p39.indicator == "Left")
		v_u_3.setActive("right", p39.indicator == "Right")
		v_u_3.setActive("hazard", p39.indicator == "Hazard")
		v_u_3.setActive("stand", p39.stand ~= "Up")
		v_u_3.setActive("view", p39.view ~= "third")
		v_u_3.setActive("wheelie", p39.wheelie == true)
		v_u_3.setActive("tuck", p39.tuck == true)
		v_u_3.setActive("mirrors", p39.mirrors == true)
		v_u_3.setActive("cam360", p39.cam360 == true)
		v_u_3.setActive("tail", p39.tailLight == true)
		v_u_3.setActive("paint", p39.paintOpen == true)
		v_u_3.setActive("rainbow", p39.rainbow == true)
	end
end
return v6