-- Path: Players/ygggggg55551/PlayerScripts/RepairKitClient
-- Class: LocalScript  true/Enum.RunContext.Legacy
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = require(game:GetService("ReplicatedStorage"):WaitForChild("NetSeal"))
local v2 = game:GetService("Players")
local v3 = game:GetService("ReplicatedStorage")
local v4 = require(v3:WaitForChild("GameShared"))
local v5 = require(v3:WaitForChild("ShopShared"))
local v_u_6 = require(v3:WaitForChild("CareShared"))
local v_u_7 = require(v3:WaitForChild("GameUI"):WaitForChild("Toast"))
local v_u_8 = v2.LocalPlayer
local v_u_9 = v3:WaitForChild(v4.REMOTES):WaitForChild(v5.REMOTE)
local v_u_10 = {}
local v_u_11 = nil
local v_u_12 = false
local v_u_17 = {
	["RepairKit"] = {
		["action"] = "Repair",
		["object"] = nil,
		["object"] = function(p13) -- name: object
			-- upvalues: (copy) v_u_6
			local v14 = v_u_6.health(p13) + 0.5
			return ("Engine %d%%"):format((math.floor(v14)))
		end
	},
	["FuelCan"] = {
		["action"] = "Refuel",
		["object"] = nil,
		["object"] = function(p15) -- name: object
			-- upvalues: (copy) v_u_6
			local v16 = v_u_6.fuel(p15) + 0.5
			return ("Fuel %d%%"):format((math.floor(v16)))
		end
	}
}
local function v_u_34() -- name: addPrompts
	-- upvalues: (ref) v_u_11, (copy) v_u_17, (copy) v_u_10, (copy) v_u_8, (ref) v_u_12, (copy) v_u_1, (copy) v_u_9, (copy) v_u_7
	local v18 = v_u_11
	if v18 then
		v18 = v_u_17[v_u_11]
	end
	if v18 then
		local v19 = workspace:FindFirstChild("SpawnedVehicles")
		for v20, v21 in v_u_10 do
			if v20.Parent then
				v21.ObjectText = v18.object(v20)
			else
				v21:Destroy()
				v_u_10[v20] = nil
			end
		end
		for _, v_u_22 in not v19 and {} or v19:GetChildren() do
			local v23 = v_u_22:FindFirstChild("Chassis") or v_u_22.PrimaryPart
			if not v23 or (v_u_22:GetAttribute("OwnerUserId") ~= v_u_8.UserId or v_u_10[v_u_22]) then
				continue
			end
			local v_u_24 = v_u_11
			local v25 = Instance.new("ProximityPrompt")
			v25.Name = "RepairPrompt"
			v25.ActionText = v18.action
			v25.ObjectText = v18.object(v_u_22)
			v25.KeyboardKeyCode = Enum.KeyCode.R
			v25.Exclusivity = Enum.ProximityPromptExclusivity.AlwaysShow
			v25.UIOffset = Vector2.new(0, -40)
			v25.HoldDuration = 1.2
			v25.MaxActivationDistance = 10
			v25.RequiresLineOfSight = false
			v25.Parent = v23
			v25.Triggered:Connect(function()
				-- upvalues: (ref) v_u_12, (ref) v_u_10, (ref) v_u_1, (ref) v_u_9, (copy) v_u_24, (copy) v_u_22, (ref) v_u_7
				if not v_u_12 then
					v_u_12 = true
					for _, v26 in v_u_10 do
						v26:Destroy()
					end
					table.clear(v_u_10)
					task.spawn(function()
						-- upvalues: (ref) v_u_1, (ref) v_u_9, (ref) v_u_24, (ref) v_u_22, (ref) v_u_12, (ref) v_u_7
						local v27 = v_u_1.invoke
						local v28 = v_u_9
						local v29 = v_u_24
						local v30 = v_u_22
						local v31, v32, v33 = pcall(v27, v28, "Use", v29, v30)
						v_u_12 = false
						v_u_7.show(v31 and v33 and v33 or "Couldn\'t reach the shop", v31 and v32 and "ok" or "error")
					end)
				end
			end)
			v_u_10[v_u_22] = v25
		end
	end
end
local function v43(p35) -- name: watch
	-- upvalues: (ref) v_u_11, (copy) v_u_10, (copy) v_u_34
	p35.ChildAdded:Connect(function(p36)
		-- upvalues: (ref) v_u_11, (ref) v_u_10, (ref) v_u_34
		local v37
		if p36:IsA("Tool") then
			v37 = p36:GetAttribute("RepairKit") and "RepairKit" or (p36:GetAttribute("FuelCan") and "FuelCan" or nil)
		else
			v37 = nil
		end
		if v37 then
			v_u_11 = v37
			for _, v38 in v_u_10 do
				v38:Destroy()
			end
			table.clear(v_u_10)
			v_u_34()
		end
	end)
	p35.ChildRemoved:Connect(function(p39)
		-- upvalues: (ref) v_u_11, (ref) v_u_10
		local v40
		if p39:IsA("Tool") then
			v40 = p39:GetAttribute("RepairKit") and "RepairKit" or (p39:GetAttribute("FuelCan") and "FuelCan" or nil)
		else
			v40 = nil
		end
		if v40 then
			local v41
			if p39:IsA("Tool") then
				v41 = p39:GetAttribute("RepairKit") and "RepairKit" or (p39:GetAttribute("FuelCan") and "FuelCan" or nil)
			else
				v41 = nil
			end
			if v41 == v_u_11 then
				v_u_11 = nil
				for _, v42 in v_u_10 do
					v42:Destroy()
				end
				table.clear(v_u_10)
			end
		end
	end)
end
v_u_8.CharacterAdded:Connect(v43)
if v_u_8.Character then
	v43(v_u_8.Character)
end
task.spawn(function()
	-- upvalues: (ref) v_u_11, (ref) v_u_12, (copy) v_u_34
	while true do
		repeat
			task.wait(1)
		until v_u_11 and not v_u_12
		v_u_34()
	end
end)