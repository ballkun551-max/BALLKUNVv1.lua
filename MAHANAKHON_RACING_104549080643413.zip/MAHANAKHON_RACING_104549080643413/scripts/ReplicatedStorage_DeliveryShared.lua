-- Path: ReplicatedStorage/DeliveryShared
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = game:GetService("HttpService")
local v_u_58 = {
	["REMOTE"] = "Delivery",
	["APP_NAME"] = "QuickRider",
	["ARRIVE_RADIUS"] = 32,
	["ARRIVE_HEIGHT"] = 14,
	["HOLD_TIME"] = 1.5,
	["STOP_SPEED"] = 6,
	["SEARCH_TIME"] = { 4, 8 },
	["OFFER_TIME"] = 20,
	["SHOP_RANGES"] = {
		{
			["weight"] = 0.5,
			["range"] = nil,
			["range"] = { 120, 800 }
		},
		{
			["weight"] = 0.35,
			["range"] = nil,
			["range"] = { 800, 2000 }
		},
		{
			["weight"] = 0.15,
			["range"] = nil,
			["range"] = { 2000, 4000 }
		}
	},
	["HOME_RANGES"] = {
		{
			["weight"] = 0.3,
			["range"] = nil,
			["range"] = { 300, 1200 }
		},
		{
			["weight"] = 0.4,
			["range"] = nil,
			["range"] = { 1200, 3000 }
		},
		{
			["weight"] = 0.3,
			["range"] = nil,
			["range"] = { 3000, 7000 }
		}
	},
	["BASE_FEE"] = 80,
	["FEE_PER_STUD"] = 0.2,
	["RIDE_BASE_FEE"] = 60,
	["RIDE_FEE_PER_STUD"] = 0.24,
	["PICKUP_PER_STUD"] = 0.05,
	["FEE_TIERS"] = {
		{ 2500, 0.2 },
		{ 5000, 0.1 },
		{ (1 / 0), 0.06 }
	},
	["RIDE_FEE_TIERS"] = {
		{ 2500, 0.24 },
		{ 5000, 0.12 },
		{ (1 / 0), 0.07 }
	},
	["PICKUP_TIERS"] = {
		{ 1500, 0.05 },
		{ (1 / 0), 0.02 }
	},
	["FEE_CAP"] = 1000,
	["tiered"] = function(p2, p3) -- name: tiered
		local v4 = 0
		local v5 = 0
		for _, v6 in p3 do
			if p2 <= v4 then
				break
			end
			local v7 = v6[1]
			v5 = v5 + (math.min(p2, v7) - v4) * v6[2]
			v4 = v6[1]
		end
		return v5
	end,
	["fare"] = function(p8, p9, p10) -- name: fare
		-- upvalues: (copy) v_u_58
		local v11
		if p10 then
			v11 = v_u_58.RIDE_BASE_FEE
		else
			v11 = v_u_58.BASE_FEE
		end
		local v12 = v_u_58.tiered
		local v13
		if p10 then
			v13 = v_u_58.RIDE_FEE_TIERS
		else
			v13 = v_u_58.FEE_TIERS
		end
		local v14 = v11 + v12(p9, v13) + v_u_58.tiered(p8, v_u_58.PICKUP_TIERS)
		local v15 = v_u_58.FEE_CAP
		return math.min(v14, v15)
	end,
	["FARE_BANDS"] = {
		{
			["weight"] = 0.65,
			["range"] = nil,
			["pay"] = nil,
			["range"] = { 300, 3000 },
			["pay"] = { 800, 1200 }
		},
		{
			["weight"] = 0.25,
			["range"] = nil,
			["pay"] = nil,
			["range"] = { 3000, 4500 },
			["pay"] = { 1200, 1500 }
		},
		{
			["weight"] = 0.1,
			["range"] = nil,
			["pay"] = nil,
			["range"] = { 4500, 6800 },
			["pay"] = { 1500, 2500 }
		}
	},
	["BAND_PICKUP_SHARE"] = 0.25,
	["pickBand"] = function() -- name: pickBand
		-- upvalues: (copy) v_u_58
		local v16 = math.random()
		for _, v17 in v_u_58.FARE_BANDS do
			v16 = v16 - v17.weight
			if v16 > 0 then
				continue
			end
			return v17
		end
		return v_u_58.FARE_BANDS[#v_u_58.FARE_BANDS]
	end,
	["bandFare"] = function(p18, p19, p20) -- name: bandFare
		-- upvalues: (copy) v_u_58
		local v21 = p18.range[1]
		local v22 = p18.range[2]
		local v23 = (p19 + (p20 or 0) * v_u_58.BAND_PICKUP_SHARE - v21) / (v22 - v21)
		local v24 = math.clamp(v23, 0, 1)
		return p18.pay[1] + (p18.pay[2] - p18.pay[1]) * v24
	end,
	["CANCEL_COOLDOWN"] = { 15, 20 },
	["SKIP_COOLDOWN"] = { 15, 20 },
	["CANCEL_RATING_CUT"] = 0.01,
	["GRAB_FEE"] = { 1000, 2500 },
	["GRAB_DIST"] = { 400, 7000 },
	["EXTRA_PARCEL_FEE"] = 600,
	["jobFare"] = function(p25, p26, p27) -- name: jobFare
		-- upvalues: (copy) v_u_58
		local v28 = (p26 + p25 * 0.25 - v_u_58.GRAB_DIST[1]) / (v_u_58.GRAB_DIST[2] - v_u_58.GRAB_DIST[1])
		local v29 = math.clamp(v28, 0, 1)
		local v30 = (v_u_58.GRAB_FEE[1] + (v_u_58.GRAB_FEE[2] - v_u_58.GRAB_FEE[1]) * v29) * (1 + v_u_58.ratingBonus(p27))
		local v31 = v_u_58.GRAB_FEE[1]
		local v32 = v_u_58.GRAB_FEE[2]
		return math.clamp(v30, v31, v32)
	end,
	["TIP_CHANCE"] = 0.4,
	["BAND_TIP_CHANCE"] = 0.2,
	["RATING_KEEP"] = 20,
	["RATING_BONUS"] = {
		{ 4.8, 0.25 },
		{ 4.5, 0.15 },
		{ 4, 0.05 },
		{ 3, 0 },
		{ 0, -0.15 }
	},
	["ratingBonus"] = function(p33) -- name: ratingBonus
		-- upvalues: (copy) v_u_58
		for _, v34 in v_u_58.RATING_BONUS do
			if v34[1] > p33 then
				continue
			end
			return v34[2]
		end
		return 0
	end,
	["starsText"] = function(p35) -- name: starsText
		return string.rep("\226\152\133", p35) .. string.rep("\226\152\134", 5 - p35)
	end,
	["TIP"] = { 0.1, 0.25 },
	["METERS_PER_STUD"] = 0.28,
	["MENUS"] = {
		"Basil chicken rice + fried egg",
		"Pad Thai with shrimp",
		"Tom yum noodles",
		"Chicken rice x2",
		"Papaya salad + grilled chicken",
		"Crab fried rice",
		"Pork porridge with egg",
		"Thai iced tea x2",
		"Iced coffee + croissant",
		"Pork leg rice, large",
		"Creamy tom yum + rice",
		"10 pork skewers + sticky rice",
		"Wonton noodles, red pork",
		"Rice with 2 curries",
		"Smoothie + bread",
		"Pork omelette rice",
		"Shrimp wonton soup",
		"Bubble tea x3"
	},
	["CUSTOMERS"] = {
		"Bee",
		"Mint",
		"Ton",
		"Praew",
		"Oat",
		"Fon",
		"Keng",
		"Noon",
		"Boss",
		"Nan",
		"Pong",
		"Ann",
		"James",
		"Ploy",
		"Fah",
		"It",
		"Ja",
		"Kong",
		"Mod",
		"Peach"
	},
	["distanceText"] = function(p36) -- name: distanceText
		-- upvalues: (copy) v_u_58
		local v37 = p36 * v_u_58.METERS_PER_STUD
		if v37 >= 950 then
			return ("%.1f km"):format(v37 / 1000)
		end
		local v38 = v37 / 10 + 0.5
		local v39 = math.floor(v38) * 10
		return ("%d m"):format((math.max(10, v39)))
	end,
	["pickRange"] = function(p40) -- name: pickRange
		local v41 = math.random()
		for _, v42 in p40 do
			v41 = v41 - v42.weight
			if v41 > 0 then
				continue
			end
			return v42.range
		end
		return p40[#p40].range
	end,
	["timeText"] = function(p43) -- name: timeText
		local v44 = math.floor(p43)
		local v45 = math.max(0, v44)
		return ("%d:%02d"):format(v45 // 60, v45 % 60)
	end,
	["encode"] = function(p46) -- name: encode
		-- upvalues: (copy) v_u_1
		return v_u_1:JSONEncode(p46)
	end,
	["decode"] = function(p47) -- name: decode
		-- upvalues: (copy) v_u_1
		if type(p47) == "string" and p47 ~= "" then
			local v48 = v_u_1.JSONDecode
			local v49 = v_u_1
			local v50, v51 = pcall(v48, v49, p47)
			if v50 then
				return v51
			else
				return nil
			end
		else
			return nil
		end
	end,
	["target"] = function(p52, p53) -- name: target
		if p52 == "ToShop" then
			if p53 then
				p53 = p53.shop
			end
		elseif p52 == "ToHome" then
			if p53 then
				p53 = p53.home
			end
		else
			p53 = nil
		end
		local v54
		if p53 then
			local v55 = p53.x
			local v56 = p53.y
			local v57 = p53.z
			v54 = Vector3.new(v55, v56, v57)
		else
			v54 = p53
		end
		return v54, p53
	end
}
return v_u_58