-- Path: ReplicatedStorage/GameUI/Warp
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = {
	["changed"] = Instance.new("BindableEvent"),
	["isOpen"] = false,
	["open"] = function() -- name: open
		-- upvalues: (copy) v_u_1
		v_u_1.changed:Fire("open")
	end,
	["close"] = function() -- name: close
		-- upvalues: (copy) v_u_1
		v_u_1.changed:Fire("close")
	end,
	["toggle"] = function() -- name: toggle
		-- upvalues: (copy) v_u_1
		v_u_1.changed:Fire("toggle")
	end
}
return v_u_1