-- Path: ReplicatedStorage/VehicleFx
-- Class: ModuleScript  
-- Decompiled by BALL KUN Universal Map Dump

local v_u_1 = require(game:GetService("ReplicatedStorage"):WaitForChild("UiOwn")).Instance
local v_u_2 = require(game:GetService("ReplicatedStorage"):WaitForChild("NetSeal"))
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("Players")
local v_u_5 = game:GetService("RunService")
local v_u_6 = game:GetService("TweenService")
local v_u_7 = {
	["REMOTE_NAME"] = "VehicleFxRemote",
	["CRASH_SOUND"] = "rbxassetid://9116546326",
	["SCRAPE_SOUND"] = "rbxassetid://9116893799"
}
local function v_u_10(p8) -- name: sparkEmitter
	-- upvalues: (copy) v_u_1
	local v9 = v_u_1.new("ParticleEmitter")
	v9.Name = "VehicleSparks"
	v9.Texture = "rbxasset://textures/particles/sparkles_main.dds"
	v9.LightEmission = 1
	v9.LightInfluence = 0
	v9.Brightness = 5
	v9.Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(255, 252, 220)), ColorSequenceKeypoint.new(0.3, Color3.fromRGB(255, 196, 70)), ColorSequenceKeypoint.new(1, Color3.fromRGB(255, 70, 10)) })
	v9.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.22), NumberSequenceKeypoint.new(1, 0.03) })
	v9.Orientation = Enum.ParticleOrientation.VelocityParallel
	v9.Squash = NumberSequence.new(-2.2)
	v9.Lifetime = NumberRange.new(0.25, 0.65)
	v9.Speed = NumberRange.new(16, 42)
	v9.SpreadAngle = Vector2.new(40, 40)
	v9.Acceleration = Vector3.new(0, -140, 0)
	v9.Drag = 1.5
	v9.EmissionDirection = Enum.NormalId.Top
	v9.Rate = 0
	v9.Parent = p8
	return v9
end
local function v_u_16(p11, p12) -- name: pointAt
	-- upvalues: (copy) v_u_1
	local v13 = (not p12 or p12.Magnitude <= 0.001) and Vector3.new(0, 1, 0) or p12.Unit
	local v14 = v13:Cross(Vector3.new(0, 0, 1))
	if v14.Magnitude < 0.001 then
		v14 = v13:Cross(Vector3.new(1, 0, 0))
	end
	local v15 = v_u_1.new("Attachment")
	v15.Name = "VehicleFxPoint"
	v15.WorldCFrame = CFrame.fromMatrix(p11, v14.Unit, v13)
	v15.Parent = workspace.Terrain
	return v15
end
function v_u_7.burst(p17, p18, p19) -- name: burst
	-- upvalues: (copy) v_u_16, (copy) v_u_10, (copy) v_u_1, (copy) v_u_6, (copy) v_u_7, (copy) v_u_3
	local v20 = math.clamp(p19 or 1, 0.1, 1)
	local v21 = v_u_16(p17, p18)
	local v22 = v_u_10(v21)
	local v23 = 25 + 70 * v20
	v22:Emit((math.floor(v23)))
	local v24 = v_u_1.new("PointLight")
	v24.Color = Color3.fromRGB(255, 180, 80)
	v24.Range = 10 + 10 * v20
	v24.Brightness = 5
	v24.Shadows = false
	v24.Parent = v21
	v_u_6:Create(v24, TweenInfo.new(0.35), {
		["Brightness"] = 0
	}):Play()
	local v25 = v_u_7.CRASH_SOUND
	local v26 = 0.6 + 0.9 * v20
	local v27 = 0.95 + math.random() * 0.15
	local v28 = v_u_1.new("Sound")
	v28.SoundId = v25
	v28.Volume = v26
	v28.PlaybackSpeed = v27 or 1
	v28.RollOffMode = Enum.RollOffMode.InverseTapered
	v28.RollOffMinDistance = 12
	v28.RollOffMaxDistance = 220
	v28.Parent = v21
	v28:Play()
	v_u_3:AddItem(v21, 4.5)
end
function v_u_7.thud(p29, p30) -- name: thud
	-- upvalues: (copy) v_u_16, (copy) v_u_7, (copy) v_u_1, (copy) v_u_3
	local v31 = math.clamp(p30 or 0.5, 0.1, 1)
	local v32 = v_u_16(p29, Vector3.new(0, 1, 0))
	local v33 = v_u_7.CRASH_SOUND
	local v34 = 0.3 + 0.5 * v31
	local v35 = v_u_1.new("Sound")
	v35.SoundId = v33
	v35.Volume = v34
	v35.PlaybackSpeed = 0.7
	v35.RollOffMode = Enum.RollOffMode.InverseTapered
	v35.RollOffMinDistance = 12
	v35.RollOffMaxDistance = 220
	v35.Parent = v32
	v35:Play()
	v_u_3:AddItem(v32, 4.5)
end
local v_u_36 = {}
v_u_36.__index = v_u_36
function v_u_7.scraper() -- name: scraper
	-- upvalues: (copy) v_u_36, (copy) v_u_16, (copy) v_u_10, (copy) v_u_1, (copy) v_u_7
	local v37 = v_u_36
	local v38 = setmetatable({}, v37)
	v38.point = v_u_16(Vector3.new(0, -500, 0), Vector3.new(0, 1, 0))
	v38.sparks = v_u_10(v38.point)
	v38.sparks.Speed = NumberRange.new(10, 30)
	v38.sparks.SpreadAngle = Vector2.new(25, 60)
	v38.light = v_u_1.new("PointLight")
	v38.light.Color = Color3.fromRGB(255, 170, 70)
	v38.light.Range = 9
	v38.light.Brightness = 0
	v38.light.Shadows = false
	v38.light.Parent = v38.point
	v38.sound = v_u_1.new("Sound")
	v38.sound.SoundId = v_u_7.SCRAPE_SOUND
	v38.sound.Looped = true
	v38.sound.Volume = 0
	v38.sound.RollOffMode = Enum.RollOffMode.InverseTapered
	v38.sound.RollOffMinDistance = 10
	v38.sound.RollOffMaxDistance = 160
	v38.sound.Parent = v38.point
	return v38
end
function v_u_36.update(p39, p40, p41, p42) -- name: update
	local v43 = math.clamp(p40 or 0, 0, 1)
	if v43 <= 0 then
		p39.sparks.Rate = 0
		p39.light.Brightness = 0
		if p39.sound.IsPlaying then
			p39.sound:Stop()
		end
	else
		local v44 = (p42 or Vector3.new(0, 0, 0)) + Vector3.new(0, 0.6, 0)
		local v45 = v44:Cross(Vector3.new(0, 0, 1))
		if v45.Magnitude < 0.001 then
			v45 = v44:Cross(Vector3.new(1, 0, 0))
		end
		p39.point.WorldCFrame = CFrame.fromMatrix(p41, v45.Unit, v44.Unit)
		p39.sparks.Rate = 60 + 260 * v43
		p39.light.Brightness = 1 + 3 * v43 * (0.6 + 0.4 * math.random())
		p39.sound.Volume = 0.25 + 0.6 * v43
		p39.sound.PlaybackSpeed = 0.85 + 0.3 * v43
		if not p39.sound.IsPlaying then
			p39.sound:Play()
		end
	end
end
function v_u_36.destroy(p46) -- name: destroy
	p46.point:Destroy()
end
local v_u_47 = 0
local v_u_48 = false
local function v_u_53(p49) -- name: stepShake
	-- upvalues: (ref) v_u_47, (copy) v_u_5, (ref) v_u_48
	local v50 = v_u_47 - 3.5 * p49
	v_u_47 = math.max(0, v50)
	if v_u_47 <= 0 then
		v_u_5:UnbindFromRenderStep("VehicleFxShake")
		v_u_48 = false
	else
		local v51 = workspace.CurrentCamera
		local v52 = v_u_47 * 0.038397243543875255 * v_u_47
		v51.CFrame = v51.CFrame * CFrame.Angles((math.random() * 2 - 1) * v52, (math.random() * 2 - 1) * v52, (math.random() * 2 - 1) * v52 * 0.5)
	end
end
function v_u_7.shake(p54) -- name: shake
	-- upvalues: (ref) v_u_47, (ref) v_u_48, (copy) v_u_5, (copy) v_u_53
	local v55 = v_u_47
	local v56 = math.max(v55, p54 or 1)
	v_u_47 = math.clamp(v56, 0, 1.5)
	if not v_u_48 then
		v_u_48 = true
		v_u_5:BindToRenderStep("VehicleFxShake", Enum.RenderPriority.Camera.Value + 5, v_u_53)
	end
end
local v_u_57 = nil
function v_u_7.hint(p58, p59) -- name: hint
	-- upvalues: (copy) v_u_4, (ref) v_u_57, (copy) v_u_1, (copy) v_u_7, (copy) v_u_6
	local v60 = v_u_4.LocalPlayer
	if v60 then
		v60 = v_u_4.LocalPlayer:FindFirstChildOfClass("PlayerGui")
	end
	if v60 then
		if not (v_u_57 and (v_u_57.Parent and v_u_57.Parent.Parent)) then
			local v61 = v_u_1.new("ScreenGui")
			v61.Name = "VehicleHint"
			v61.ResetOnSpawn = false
			v61.DisplayOrder = 20
			v61.Parent = v60
			v_u_57 = v_u_1.new("TextLabel")
			v_u_57.AnchorPoint = Vector2.new(0.5, 0.5)
			v_u_57.Position = UDim2.fromScale(0.5, 0.74)
			v_u_57.Size = UDim2.fromOffset(460, 54)
			v_u_57.BackgroundColor3 = Color3.fromRGB(20, 20, 24)
			v_u_57.TextColor3 = Color3.fromRGB(255, 220, 120)
			v_u_57.Font = Enum.Font.GothamBold
			v_u_57.TextSize = 22
			v_u_57.Parent = v61
			local v62 = v_u_1.new("UICorner")
			v62.CornerRadius = UDim.new(0, 14)
			v62.Parent = v_u_57
		end
		v_u_57.Text = p58
		v_u_57.BackgroundTransparency = 0.25
		v_u_57.TextTransparency = 0
		local v_u_63 = {}
		v_u_7._hintToken = v_u_63
		task.delay(p59 or 2, function()
			-- upvalues: (ref) v_u_7, (copy) v_u_63, (ref) v_u_57, (ref) v_u_6
			if v_u_7._hintToken == v_u_63 and v_u_57 then
				v_u_6:Create(v_u_57, TweenInfo.new(0.4), {
					["BackgroundTransparency"] = 1,
					["TextTransparency"] = 1
				}):Play()
			end
		end)
	end
end
function v_u_7.report(p64, p65, p66) -- name: report
	-- upvalues: (copy) v_u_7, (copy) v_u_2
	local v67 = game:GetService("ReplicatedStorage"):FindFirstChild(v_u_7.REMOTE_NAME)
	if v67 then
		v_u_2.fire(v67, "Burst", p64, p65, p66)
	end
end
return v_u_7